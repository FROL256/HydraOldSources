#pragma once

#include "Formats.h"
#include "Device.h"
#include "Buffer.h"
#include "Textures.h"
#include "Pipeline.h"

#include <iostream>

namespace SGA
{
  void sga_test(); 
};
