#pragma once

namespace SGA
{

  struct IBuffer
  {

  };

  class D3D11Buffer : public IBuffer
  {
  public:

  };

  class GLBuffer : public IBuffer
  {
  public:

  };

  class CUDABuffer : public IBuffer
  {
  public:

  };


  template<class T>
  class Buffer 
  {
  public:
    Buffer(){ m_data = AllocData(4); m_capacity = 4; m_size = 0; }
    Buffer(const int a_size) {m_data = AllocData(a_size); m_capacity = a_size; m_size = 0;}
    Buffer(const Buffer& rhs)
    {
      m_data = NULL;
      *this = rhs;
    }

    Buffer& operator=(const Buffer& rhs) 
    {
      if(this==&rhs)
        return *this;

      m_size = rhs.size();
      m_capacity = rhs.capacity();
      FreeData();
      m_data = AllocData(m_capacity);
      for(int i=0;i<m_size;i++)
        m_data[i] = rhs[i];

      return *this;
    }

    virtual ~Buffer(){FreeData(); m_capacity = 0; m_size = 0;}

    // graphics API
    //
    //void copyHostToDevice(ID3D11Device* a_pDevice);
    //void copyDeviceToHost(ID3D11Device* a_pDevice);
    //void freeCPUData();

    // std::vector API (dynamic array)
    //

    typedef T* iterator;
    typedef const T* const_iterator;
    typedef T value_type;

    inline int size() const {return m_size;}
    inline int capacity() const {return m_capacity;}

    inline void push_back(const T& a_data)
    {
      if (m_size >= m_capacity)
        reserve(MemoryExpansionFactor()*m_capacity);

      m_data[m_size] = a_data;
      m_size++;
    }

    void reserve(int size)
    {
      if(size < m_capacity)
        return;

      T* new_data = AllocData(size);
      memcpy(new_data, m_data, sizeof(T)*min(m_size,size));
      FreeData();
      m_data = new_data;
      m_capacity = size;
    }

    void resize(int size)
    {
      if(size > m_capacity)
        reserve(MemoryExpansionFactor()*size);

      m_size = size;
    }

    void clear() {resize(0);}

    inline T& operator[](int i) 
    {
#ifndef NDEBUG
      if(i>=m_size)
      {
        int a = 2;
      }
#endif
      ASSERT(i<m_size);
      return m_data[i];
    }

    inline const T& operator[](int i) const
    {
#ifndef NDEBUG
      if(i>=m_size)
      {
        int a = 2;
      }
#endif
      ASSERT(i<m_size);
      return m_data[i];
    }

    const_iterator begin() const {return m_data;}
    iterator begin() {return m_data;}

    const_iterator end() const {return m_data+m_size;}
    iterator end() {return m_data+m_size;}


  protected:

    float MemoryExpansionFactor()
    {
      if(m_capacity < 64)
        return 4;
      else if(m_capacity < 1024)
        return 2;
      else
        return 1.5f;
    }

    T* AllocData(int size)
    {
      if(TypesEqual<T,char>::RET)
      {
        T* data = (T*)_aligned_malloc(size*sizeof(T), 16); 
        if(data==NULL)
          RUN_TIME_ERROR("Buffer(aligned), out of memory");
        return data;
      }
      else
        return new T[size];
    }

    void FreeData()
    {
      if(TypesEqual<T,char>::RET)
        _aligned_free(m_data);
      else
        delete [] m_data;
      m_data = NULL;
    }

    T* m_data;
    int m_capacity;
    int m_size;
    IBuffer* m_pRealBuffer;

  };


}



