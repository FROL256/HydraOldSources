
#include "SGA_lib.h"

void SGA::sga_test(){ std::cerr << "SGA test" << std::endl;}
