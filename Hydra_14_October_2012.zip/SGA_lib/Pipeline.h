#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include <iostream>
#include <string>

namespace SGA
{
  
  struct IPipeline
  {
    IPipeline(){}
    virtual ~IPipeline(){}

    virtual void SetShaderVariable(const std::string& name, MGML_MATH::VECTOR<3,float> var) = 0;
    virtual void SetShaderVariable(const std::string& name, const MGML_MATH::MATRIX<4,4,float>& var) = 0;
    virtual void SetShaderVariable(const std::string& name, float var) = 0;
    virtual void SetShaderVariable(const std::string& name, int var) = 0;
  };

  class D3D11Pipeline : public IPipeline
  {

  };

  class GLPipeline : public IPipeline
  {

  };

  class CUDAPipeline : public IPipeline
  {
  public:
    CUDAPipeline(){}
    ~CUDAPipeline(){}
    
    void SetShaderVariable(const std::string& name, MGML_MATH::VECTOR<3,float> var);
    void SetShaderVariable(const std::string& name, const MGML_MATH::MATRIX<4,4,float>& var);
    void SetShaderVariable(const std::string& name, float var);
    void SetShaderVariable(const std::string& name, int var);

  protected:
    template<class T>
    void SetShaderVariableGeneric(const std::string& name, const T& var)
    {
      T localVar = var;
      const char* msg = sga_cudaMemcpyToSymbol(name.c_str(), &localVar, sizeof(T));
      if(msg!=NULL)
        throw std::runtime_error(std::string("SetShaderVariable failed: ") + msg);
    }
  };


  class Pipeline
  {

  };


  class Program
  {

  };

}

