#pragma once
#include <iostream>

namespace SGA
{
  static std::string ToString(int i)
  {
    char buff[128];
    _itoa_s(i,buff,10);
    return std::string(buff);
  }


  static std::string ToString(unsigned int i)
  {
    char buff[128];
    _itoa_s(i,buff,10);
    return std::string(buff);
  }


  static void RunTimeError(const char* file, int line, std::string msg)
  {
    //throw std::runtime_error(std::string("Run time error at ") + file + std::string(", line ") + ToString(line) + ": " + msg);
  }

  template <typename A, typename B>
  struct TypesEqual
  {
    enum { RET = false };
  };

  template<typename A>
  struct TypesEqual<A, A>
  {
    enum { RET = true };
  };

}

#undef RUN_TIME_ERROR
#define RUN_TIME_ERROR(e) (SGA::RunTimeError(__FILE__,__LINE__,(e)))

#define VERIFY(cond) if(!(cond)) RUN_TIME_ERROR("Verification failed");

#define SAFE_CALL(call) try { (call); } catch(...) { std::cerr << "Error at: " << __FILE__ << ", line: " << __LINE__ << std::endl; throw;  }
