#pragma once

namespace SGA
{

  struct IDevice
  {

  };

  class D3D11Device : public IDevice
  {

  };

  class GLDevice : public IDevice
  {

  };

  class CUDADevice : public IDevice
  {

  };


  class Device
  {
  public:

  protected:
    IDevice* m_pRealDevice;
  };



}
