#include <cuda.h>

#include <cuda_runtime.h>
#include <cuda_gl_interop.h>

extern "C" const char* sga_cudaMemcpyToSymbol(const char* name, void* data, int a_size);
