#pragma once

namespace SGA
{

template<class T>
class Texture1D
{


};


template<class T>
class Texture2D
{


};


template<class T>
class Texture3D
{


};

}


