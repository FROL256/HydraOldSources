#pragma once

namespace SGA
{
  typedef enum DATA_FORMAT
  {
    FORMAT_UNKNOWN	                   = 0,
    FORMAT_R32G32B32A32_TYPELESS       = 1,
    FORMAT_R32G32B32A32_FLOAT          = 2,
    FORMAT_R32G32B32A32_UINT           = 3,
    FORMAT_R32G32B32A32_SINT           = 4,
    FORMAT_R32G32B32_TYPELESS          = 5,
    FORMAT_R32G32B32_FLOAT             = 6,
    FORMAT_R32G32B32_UINT              = 7,
    FORMAT_R32G32B32_SINT              = 8,
    FORMAT_R16G16B16A16_TYPELESS       = 9,
    FORMAT_R16G16B16A16_FLOAT          = 10,
    FORMAT_R16G16B16A16_UNORM          = 11,
    FORMAT_R16G16B16A16_UINT           = 12,
    FORMAT_R16G16B16A16_SNORM          = 13,
    FORMAT_R16G16B16A16_SINT           = 14,
    FORMAT_R32G32_TYPELESS             = 15,
    FORMAT_R32G32_FLOAT                = 16,
    FORMAT_R32G32_UINT                 = 17,
    FORMAT_R32G32_SINT                 = 18,
    FORMAT_R32G8X24_TYPELESS           = 19,
   

    
    FORMAT_R8G8B8A8_TYPELESS           = 27,
    FORMAT_R8G8B8A8_UNORM              = 28,
    FORMAT_R8G8B8A8_UNORM_SRGB         = 29,
    FORMAT_R8G8B8A8_UINT               = 30,
    FORMAT_R8G8B8A8_SNORM              = 31,
    FORMAT_R8G8B8A8_SINT               = 32,
    FORMAT_R16G16_TYPELESS             = 33,
    FORMAT_R16G16_FLOAT                = 34,
    FORMAT_R16G16_UNORM                = 35,
    FORMAT_R16G16_UINT                 = 36,
    FORMAT_R16G16_SNORM                = 37,
    FORMAT_R16G16_SINT                 = 38,
    FORMAT_R32_TYPELESS                = 39,
    FORMAT_D32_FLOAT                   = 40,
    FORMAT_R32_FLOAT                   = 41,
    FORMAT_R32_UINT                    = 42,
    FORMAT_R32_SINT                    = 43,
    FORMAT_R24G8_TYPELESS              = 44,
    
    FORMAT_R8G8_TYPELESS               = 48,
    FORMAT_R8G8_UNORM                  = 49,
    FORMAT_R8G8_UINT                   = 50,
    FORMAT_R8G8_SNORM                  = 51,
    FORMAT_R8G8_SINT                   = 52,
    FORMAT_R16_TYPELESS                = 53,
    FORMAT_R16_FLOAT                   = 54,
    FORMAT_D16_UNORM                   = 55,
    FORMAT_R16_UNORM                   = 56,
    FORMAT_R16_UINT                    = 57,
    FORMAT_R16_SNORM                   = 58,
    FORMAT_R16_SINT                    = 59,
    FORMAT_R8_TYPELESS                 = 60,
    FORMAT_R8_UNORM                    = 61,
    FORMAT_R8_UINT                     = 62,
    FORMAT_R8_SNORM                    = 63,
    FORMAT_R8_SINT                     = 64,
    FORMAT_A8_UNORM                    = 65,
    FORMAT_R1_UNORM                    = 66,
   
    FORMAT_B8G8R8A8_UNORM              = 87,
    FORMAT_B8G8R8X8_UNORM              = 88
   
  } FORMAT;


  int SizeOfFormat(FORMAT a_fmt);

};
