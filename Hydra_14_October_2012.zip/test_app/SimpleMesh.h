#pragma once


#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

using namespace MGML;

struct SimpleMesh
{
	virtual const Vertex4f* GetVertices() const = 0;
	virtual const unsigned int* GetIndices() const = 0;
  virtual void InvertNormals() = 0;
};