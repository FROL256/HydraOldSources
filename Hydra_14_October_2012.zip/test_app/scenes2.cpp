#include <gl/glew.h>

#include "scenes.h"
#include "../obj_loader2/load_model/glm.h"
#include "ObjImport.h"

#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

#pragma warning(disable:4305)

using MGML_MATH::rnd;

extern Camera* cam;

void MakeTestScene_DiffuseSphereOnPlane(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  RAYTR::Material materials[5];

  materials[0].ka.set(0.00,0.00,0.00);
  materials[0].kd.set(0.50,0.50,0.50);
  materials[0].ks.set(0.0,0.0,0.0);
  materials[0].reflection.set(0,0,0);
  materials[0].refraction.set(0,0,0);
  materials[0].IOR  = 1.0f;
  materials[0].SetBlinnPhongPower(60);

  materials[1] = materials[0];
  materials[1].ka.set(0.0,0.0,0.00);
  materials[1].kd.set(0.5,0.5,0.5);
  materials[1].ks.set(0.0,0.0,0.00);
  materials[1].SetSeparatedReflection(float3(0.0,0.0,0.00), float3(0.00, 0.00, 0.00));
  materials[1].reflectGlossiness = 1.0f;
  materials[1].fresnelIOR = 1.0f;
  materials[1].refraction.set(0,0,0);
  materials[1].IOR = 1.0f;
  materials[1].BRDF_id = RAYTR::Material::BRDF_BLINN;
  materials[1].SetBlinnPhongPower(40);

  materials[2] = materials[0];
  materials[2].kd.set(0.5,0.0,0.0);

  materials[3] = materials[0];
  materials[3].kd.set(0.0,0.5,0.0);

  materials[4] = materials[0];
  materials[4].kd.set(0.0,0.0,0.5);

  for(int i=0;i<5;i++)
    pRender->AddMaterial(materials[i]);


  HydraMaterial h_materials[5];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);
  h_materials[1].diffuse.color = float3(0.5,0.5,0.5);
  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.0,0.5);

  for(int i=0;i<5;i++)
    pRender->AddMaterial(h_materials[i]);

  
  // floor triangles
  const int numVert = 4;
  const int numIndices = 6;
  Vertex4f  vert[numVert];
  unsigned int indices[numIndices];

  // triangles
  float size = 15;
  vert[0].pos.set(-size,0,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,0,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,0,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,0,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  float wrap = 16.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);

  indices[0]=0;indices[1]=1;indices[2]=2;
  indices[3]=2;indices[4]=3;indices[5]=0;

  // floor
  pRender->AddTriangles(vert,numVert,indices,numIndices);


 
  float radius = 2;
  float radius2 = sinf(MGML_MATH::DEG_TO_RAD(60.f))*radius;

  Matrix4x4f mRot;
  mRot.SetRotationY(2*MGML_MATH::PI/3.0f);

  float4 pos1(0,0,radius,1);

  Sphere4f sph[4];

  //sph[0] = Sphere4f(mRot2*pos1 + float4(0,1.5,0,0),1.5);
  //sph[0].material_id = 1;

  sph[0] = Sphere4f(pos1 + float4(0,radius2,0,0),radius2);
  sph[0].material_id = 2;

  sph[1] = Sphere4f(mRot*pos1 + float4(0,radius2,0,0),radius2);
  sph[1].material_id = 3;

  sph[2] = Sphere4f(mRot*(mRot*pos1) + float4(0,radius2,0,0),radius2);
  sph[2].material_id = 4;

  pRender->AddSpheres(sph,3);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,12,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(2, 2);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}



void MakeTestScene_GlassDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  int chessTexId = LoadTextureToRender("data/texture2.bmp", pRender); //pRender->AddTexture(texture.getConstBuffer(), texture.width(), texture.height(), IGraphicsEngine::RGBA8);

  HydraMaterial materials[9];

  //
  //
  materials[0].ambient.color = float3(0,0,0);
  materials[0].diffuse.color = float3(0.85f,0.85f,0.85f);
  //materials[0].diffuse.color_texId = chessTexId;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.power   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;
  int FLOOR_MATERIAL = 0;
  
  //
  //
  materials[1].ambient.color    = float3(0,0,0);
  materials[1].diffuse.color    = float3(0.15f,0.15f,0.15f);
  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.power   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[1].reflection.color = float3(0.45f,0.45f,0.45f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].transparency.color = float3(0.65f,0.65f,0.65f);
  materials[1].transparency.fogColor      = float3(1,1,1);
  materials[1].transparency.fogMultiplyer = 0.25f; // 
  materials[1].transparency.exitColor     = float3(1,0,0); // interest effect
  materials[1].transparency.IOR           = 2.2f;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int PURE_WHITE_GLASS = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.power   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].transparency.color = float3(0.0,0.65f,0.0f);
  materials[2].transparency.fogColor      = float3(0,1,0);
  materials[2].transparency.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].transparency.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].transparency.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int DARK_GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0,0,0);
  materials[3].diffuse.color    = float3(0.15f,0.0f,0.0f);
  materials[3].specular.color   = float3(0.25f,0.0,0.0f);
  materials[3].specular.power   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.25f,0.0,0.0);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].transparency.color         = float3(0.65f,0.0,0.0);
  materials[3].transparency.fogColor      = float3(1,1,1);
  materials[3].transparency.fogMultiplyer = 0.0f;           // pure transparent glass
  materials[3].transparency.exitColor     = float3(0.65f,0,0);  // common practice
  materials[3].transparency.IOR           = 1.8f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int LITE_RED_GLASS = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.45f, 0.45f, 0.45f);
  int DIFFUSE_WHITE = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  materials[8].ambient.color    = float3(0,0,0);
  materials[8].diffuse.color    = float3(0.15f,0.15f,0.15f);
  materials[8].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[8].specular.power   = 60.0f;
  materials[8].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[8].reflection.color = float3(0.45f,0.45f,0.45f);
  materials[8].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[8].transparency.color = float3(0.65f,0.65f,0.65f);
  materials[8].transparency.fogColor      = float3(1,1,1);
  materials[8].transparency.fogMultiplyer = 0.25f; // 
  materials[8].transparency.exitColor     = float3(1,0,0); // interest effect
  materials[8].transparency.IOR           = 2.2f;
  materials[8].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRANSPARENCY_THIN_SURFACE;
  int THIN_PURE_WHITE_GLASS = 8;

  for(int i=0;i<9;i++)
    pRender->AddMaterial(materials[i]);



  AddFloor2(pRender, 255, FLOOR_MATERIAL);

  Matrix4x4f translate;
  Matrix4x4f rot;

  GLMmodel* bunny = glmReadOBJ("data/alex_meshes/bunny.obj");

  translate.SetTranslate(float3(3,-2,0));
  AddMeshFromOBJ(bunny,pRender,translate, PURE_WHITE_GLASS);

  translate.SetTranslate(float3(-3,-2,0));
  AddMeshFromOBJ(bunny,pRender,translate, DARK_GREEN_GLASS);

  glmDelete(bunny);

  
  Cube cube;
  Matrix4x4f t1;

  t1.Identity();
  t1.SetTranslate(vec3f(0,-2.25f,2));
  cube = Cube(t1,1,255, PURE_WHITE_GLASS); 
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);

  Sphere4f sph;
  sph = Sphere4f(vec4f(0, -2, -4,0), 1.0);
  sph.material_id = DIFFUSE_WHITE;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(-4, -2, -4,1), 1.0);
  sph.material_id = DIFFUSE_RED;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(4, -2, -4,1), 1.0);
  sph.material_id = DIFFUSE_YELLOW;
  pRender->AddSpheres(&sph,1);


  {
    const int numVert = 4;
    const int numIndices = 6;
    Vertex4f  vert[numVert];
    unsigned int indices[numIndices];

    // triangles
    float size = 1;
    vert[0].pos.set(-size,0,-size,1); vert[0].norm.set(0,1,0,1);
    vert[1].pos.set(-size,0,size,1);  vert[1].norm.set(0,1,0,1);
    vert[2].pos.set(size,0,size,1);   vert[2].norm.set(0,1,0,1);
    vert[3].pos.set(size,0,-size,1);  vert[3].norm.set(0,1,0,1);

    Matrix4x4f mTransform, mRot, mTransate;

    mRot.SetRotationX(MGML_MATH::DEG_TO_RAD(90.0f));
    mTransate.SetTranslate(float3(0,-2.0,0.0));

    mTransform = mTransate*mRot;

    for(int i=0;i<4;i++)
    {
      vert[i].pos = mTransform*vert[i].pos;
      vert[i].norm =  matrix4x4f_mult_normal4f(mTransform, vert[i].norm);
    }

    vert[0].material_id = THIN_PURE_WHITE_GLASS;
    vert[1].material_id = THIN_PURE_WHITE_GLASS;
    vert[2].material_id = THIN_PURE_WHITE_GLASS;
    vert[3].material_id = THIN_PURE_WHITE_GLASS;

    float wrap = 1.0f;
    vert[0].t.set(0,0); 
    vert[1].t.set(0,wrap);
    vert[2].t.set(wrap,wrap); 
    vert[3].t.set(wrap,0);

    indices[0]=0;indices[1]=1;indices[2]=2;
    indices[3]=2;indices[4]=3;indices[5]=0;

    pRender->AddTriangles(vert,numVert,indices,numIndices);
  }


  
  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(2,2.99,2);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);

}




unsigned char* LoadTexture(const std::string& a_fileName, int* pW, int* pH)
{
  if(!ilLoadImage(a_fileName.c_str()))
    RUN_TIME_ERROR("image " + a_fileName + " don't exists or it has unknown format");

  if(!ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE))
    RUN_TIME_ERROR("image " + a_fileName + " have unknown pixel format, OpenIL can not convert it");

  int w = ilGetInteger(IL_IMAGE_WIDTH);
  int h = ilGetInteger(IL_IMAGE_HEIGHT);
  int bpp = ilGetInteger(IL_IMAGE_BYTES_PER_PIXEL);
  int format = ilGetInteger(IL_IMAGE_FORMAT);

  int size = w * h * bpp;
  unsigned char* data = new unsigned char[size];

  ilCopyPixels(0,0,0,w,h,bpp,format,IL_UNSIGNED_BYTE,data);
  
  *pW = w;
  *pH = h;

  return data;
}

void MakeTestScene_ParallaxMappingDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  int chessTexId = LoadTextureToRender("data/texture1.bmp", pRender); //pRender->AddTexture(texture.getConstBuffer(), texture.width(), texture.height(), IGraphicsEngine::RGBA8);
    
  ilInit();
  iluInit();

  // rocks
  //
  int w=0,h=0;
  unsigned char* texData = LoadTexture("data/rock_height.dds", &w, &h);
  int displTextureId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rock_diffuse.dds", &w, &h);
  int diffuseTextureId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rock_bump.dds", &w, &h);
  int normalsTexId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;
  

  // rock wall
  //
  texData = LoadTexture("data/rockwall_diffuse.dds", &w, &h);
  int diffuseTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rockwall_height.dds", &w, &h);
  int displTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rockwall_bump.dds", &w, &h);
  int normalsTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  // four figures
  //
  texData = LoadTexture("data/relief_wood.jpg", &w, &h);
  int diffuseTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/relief_height.png", &w, &h);
  int displTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/relief_bump.png", &w, &h);
  int normalsTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  HydraMaterial materials[8];

  //
  //
  materials[0].ambient.color = float3(0.1,0.1,0.1);
  materials[0].diffuse.color = float3(0.20f,0.20f,0.20f);
  materials[0].diffuse.color_texId = diffuseTexture2Id;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.power   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.45f,0.45f,0.45f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].displacement.height = 0.04f;
  materials[0].displacement.normals_texId = normalsTexture2Id;
  materials[0].displacement.height_texId  = displTexture2Id;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;// | HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;
  int FLOOR_MATERIAL = 0;

  //
  //
  materials[1].ambient.color    = float3(0.05,0.05,0.05);
  materials[1].ambient.color_texId = diffuseTexture3Id;

  materials[1].diffuse.color    = float3(0.25f,0.25f,0.25f);
  materials[1].diffuse.color_texId = diffuseTexture3Id;
  
  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.power   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  
  materials[1].reflection.color = float3(0.25f,0.25f,0.25f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  
  materials[1].displacement.height = 0.1f;
  materials[1].displacement.normals_texId = normalsTexture3Id;
  materials[1].displacement.height_texId  = displTexture3Id;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;
  int DISPLACED_MATERIAL = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.power   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].transparency.color = float3(0.0,0.65f,0.0f);
  materials[2].transparency.fogColor      = float3(0,1,0);
  materials[2].transparency.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].transparency.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].transparency.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS;
  int GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0.05,0.05,0.05);
  materials[3].ambient.color_texId = diffuseTexture2Id;
  materials[3].diffuse.color    = float3(0.35f,0.35f,0.35f);
  materials[3].diffuse.color_texId = diffuseTexture2Id;
  materials[3].specular.color   = float3(0.3f,0.3f,0.3f);
  materials[3].specular.power   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].displacement.normals_texId = normalsTexture2Id;
  //materials[3].displacement.height_texId  = 0;//displTextureId;
  //materials[3].displacement.height = 0.00f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS;
  int DISPLACED_MATERIAL3 = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.0f, 0.45f, 0.0f);
  int DIFFUSE_GREEN = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  for(int i=0;i<8;i++)
    pRender->AddMaterial(materials[i]);

  AddFloor2(pRender, 255, FLOOR_MATERIAL, 4);

  Matrix4x4f translate;
  Matrix4x4f rot;

  Cube cube;
  Matrix4x4f t1;

  t1.Identity();
  t1.SetTranslate(vec3f(-2,-1.5,2));
  cube = Cube(t1,2,255, DISPLACED_MATERIAL); 
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);

  Sphere4f sph;
  sph = Sphere4f(vec4f(0, -2, -4,0), 1.0);
  sph.material_id = DIFFUSE_GREEN;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(-4, -2, -4,1), 1.0);
  sph.material_id = DIFFUSE_RED;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(4, -2, -4,1), 1.0);
  sph.material_id = DIFFUSE_YELLOW;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(3, -2, 2,1), 1.0);
  sph.material_id = DISPLACED_MATERIAL3;
  pRender->AddSpheres(&sph,1);


  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  flatLight2.pos.set(2,2.99,2);
  flatLight2.kc = 1;
  flatLight2.kl = 0.001;
  flatLight2.kq = 0.00001;
  flatLight2.intensity = 2.0f;
  //flatLight2.SetAreaLightSize(1.5f, 1.5f);
  //flatLight2.SetNormal(vec3f(0,-1.0f,0));
  //flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);


  RAYTR::Light pointLight;
  pointLight.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  pointLight.pos.set(-2,4,-4);
  pointLight.kc = 1;
  pointLight.kl = 0.001;
  pointLight.kq = 0.00001;

  pointLight.intensity = 2.0f;
  pRender->AddLight(pointLight);
}





void MakeTestScene_ParallaxMappingDemo2(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  int chessTexId = LoadTextureToRender("data/texture1.bmp", pRender); //pRender->AddTexture(texture.getConstBuffer(), texture.width(), texture.height(), IGraphicsEngine::RGBA8);

  ilInit();
  iluInit();

  // rocks
  //
  int w=0,h=0;
  unsigned char* texData = LoadTexture("data/rock_height.dds", &w, &h);
  int displTextureId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rock_diffuse.dds", &w, &h);
  int diffuseTextureId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rock_bump.dds", &w, &h);
  int normalsTexId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;


  // rock wall
  //
  texData = LoadTexture("data/rockwall_diffuse.dds", &w, &h);
  int diffuseTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rockwall_height.dds", &w, &h);
  int displTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rockwall_bump.dds", &w, &h);
  int normalsTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  // four figures
  //
  texData = LoadTexture("data/relief_wood.jpg", &w, &h);
  int diffuseTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/relief_height.png", &w, &h);
  int displTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/relief_bump.png", &w, &h);
  int normalsTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  HydraMaterial materials[8];

  //
  //
  materials[0].ambient.color = float3(0.1,0.1,0.1);
  materials[0].diffuse.color = float3(0.20f,0.20f,0.20f);
  materials[0].diffuse.color_texId = diffuseTexture2Id;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.power   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.45f,0.45f,0.45f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].displacement.height = 0.04f;
  materials[0].displacement.normals_texId = normalsTexture2Id;
  materials[0].displacement.height_texId  = displTexture2Id;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;// | HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;
  int FLOOR_MATERIAL = 0;

  //
  //
  materials[1].ambient.color    = float3(0.1,0.1,0.1);
  materials[1].ambient.color_texId = diffuseTexture3Id;

  materials[1].diffuse.color    = float3(0.25f,0.25f,0.25f);
  materials[1].diffuse.color_texId = diffuseTexture3Id;

  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.power   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].reflection.color = float3(0.25f,0.25f,0.25f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].displacement.height = 0.1f;
  materials[1].displacement.normals_texId = normalsTexture3Id;
  materials[1].displacement.height_texId  = displTexture3Id;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;
  int DISPLACED_MATERIAL = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.power   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].transparency.color = float3(0.0,0.65f,0.0f);
  materials[2].transparency.fogColor      = float3(0,1,0);
  materials[2].transparency.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].transparency.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].transparency.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS;
  int GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0.1,0.1,0.1);
  materials[3].ambient.color_texId = diffuseTexture2Id;
  materials[3].diffuse.color    = float3(0.35f,0.35f,0.35f);
  materials[3].diffuse.color_texId = diffuseTexture2Id;
  materials[3].specular.color   = float3(0.3f,0.3f,0.3f);
  materials[3].specular.power   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].displacement.normals_texId = normalsTexture2Id;
  //materials[3].displacement.height_texId  = 0;//displTextureId;
  //materials[3].displacement.height = 0.00f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS;
  int DISPLACED_MATERIAL3 = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.0f, 0.45f, 0.0f);
  int DIFFUSE_GREEN = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  for(int i=0;i<8;i++)
    pRender->AddMaterial(materials[i]);
    

/*
  HydraMaterial materials[8];

  //
  //
  materials[0].ambient.color = float3(0,0,0);
  materials[0].diffuse.color = float3(0.85f,0.85f,0.85f);
  //materials[0].diffuse.color_texId = chessTexId;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.power   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;
  int FLOOR_MATERIAL = 0;

  //
  //
  materials[1].ambient.color    = float3(0,0,0);
  materials[1].diffuse.color    = float3(0.15f,0.15f,0.15f);
  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.power   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[1].reflection.color = float3(0.25f,0.25f,0.25f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].refraction.color = float3(0.65f,0.65f,0.65f);
  materials[1].refraction.fogColor      = float3(1,1,1);
  materials[1].refraction.fogMultiplyer = 0.25f; // 
  materials[1].refraction.exitColor     = float3(1,0,0); // interest effect
  materials[1].refraction.IOR           = 2.2f;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int PURE_WHITE_GLASS = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.power   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].refraction.color = float3(0.0,0.65f,0.0f);
  materials[2].refraction.fogColor      = float3(0,1,0);
  materials[2].refraction.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].refraction.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].refraction.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int DARK_GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0,0,0);
  materials[3].diffuse.color    = float3(0.15f,0.0f,0.0f);
  materials[3].specular.color   = float3(0.25f,0.0,0.0f);
  materials[3].specular.power   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.25f,0.0,0.0);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].refraction.color         = float3(0.65f,0.0,0.0);
  materials[3].refraction.fogColor      = float3(1,1,1);
  materials[3].refraction.fogMultiplyer = 0.0f;           // pure transparent glass
  materials[3].refraction.exitColor     = float3(0.65f,0,0);  // common practice
  materials[3].refraction.IOR           = 1.8f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int LITE_RED_GLASS = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.45f, 0.45f, 0.45f);
  int DIFFUSE_WHITE = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  for(int i=0;i<8;i++)
    pRender->AddMaterial(materials[i]);
  */



/*
  HydraMaterial h_materials[5];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);
  h_materials[1].diffuse.color = float3(0.5,0.5,0.5);
  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.0,0.5);

  for(int i=0;i<5;i++)
    pRender->AddMaterial(h_materials[i]);
    */


  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(1,3.99,1);
  flatLight2.kc = 1;
  flatLight2.kl = 0.001;
  flatLight2.kq = 0.00001;
  flatLight2.intensity = 2.0f;
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);


  //RAYTR::Light pointLight;
  //pointLight.SetPointLight();
  //pointLight.pos.set(-2,4,-4);
  //pointLight.kc = 1;
  //pointLight.kl = 0.001;
  //pointLight.kq = 0.00001;

  //pointLight.intensity = 2.0f;
  //pRender->AddLight(pointLight);
}



void MakeTestScene_OpacityMapsDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  int chessTexId = LoadTextureToRender("data/texture2.bmp", pRender); //pRender->AddTexture(texture.getConstBuffer(), texture.width(), texture.height(), IGraphicsEngine::RGBA8);

  HydraMaterial materials[11];

  //
  //
  materials[0].ambient.color = float3(0,0,0);
  materials[0].diffuse.color = float3(0.85f,0.85f,0.85f);
  //materials[0].diffuse.color_texId = chessTexId;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.power   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;
  int FLOOR_MATERIAL = 0;

  //
  //
  materials[1].ambient.color    = float3(0,0,0);
  materials[1].diffuse.color    = float3(0.15f,0.15f,0.15f);
  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.power   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[1].reflection.color = float3(0.45f,0.45f,0.45f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].transparency.color = float3(0.65f,0.65f,0.65f);
  materials[1].transparency.fogColor      = float3(1,1,1);
  materials[1].transparency.fogMultiplyer = 0.25f; // 
  materials[1].transparency.exitColor     = float3(1,0,0); // interest effect
  materials[1].transparency.IOR           = 2.2f;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int PURE_WHITE_GLASS = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.power   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].transparency.color = float3(0.0,0.65f,0.0f);
  materials[2].transparency.fogColor      = float3(0,1,0);
  materials[2].transparency.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].transparency.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].transparency.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int DARK_GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0,0,0);
  materials[3].diffuse.color    = float3(0.15f,0.0f,0.0f);
  materials[3].specular.color   = float3(0.25f,0.0,0.0f);
  materials[3].specular.power   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.25f,0.0,0.0);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].transparency.color         = float3(0.65f,0.0,0.0);
  materials[3].transparency.fogColor      = float3(1,1,1);
  materials[3].transparency.fogMultiplyer = 0.0f;           // pure transparent glass
  materials[3].transparency.exitColor     = float3(0.65f,0,0);  // common practice
  materials[3].transparency.IOR           = 1.8f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int LITE_RED_GLASS = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.45f, 0.45f, 0.45f);
  int DIFFUSE_WHITE = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  // material with opacity map
  //
  int w,h;
  unsigned char* texData = LoadTexture("data/leafes.tga", &w, &h);
  int transpTexId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  materials[8].ambient.color    = float3(0.25,0.25,0.25);
  materials[8].ambient.color_texId = transpTexId;

  materials[8].diffuse.color    = float3(1.0f,1.0f,1.0f);
  materials[8].diffuse.color_texId = transpTexId;

  materials[8].specular.color   = float3(0.0f,0.0f,0.0f);
  materials[8].specular.power   = 1.0f;
  materials[8].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[8].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[8].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[8].transparency.color = float3(0,0,0);
  materials[8].transparency.color_texId = transpTexId;
  materials[8].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRANSPARENCY_THIN_SURFACE;
  int LEAFES_MATERIAL = 8;


  materials[9].ambient.color    = float3(0.0,0.0,0.0);
  materials[9].diffuse.color    = float3(1.0f,1.0f,1.0f);

  materials[9].specular.color   = float3(0.0f,0.0f,0.0f);
  materials[9].specular.power   = 1.0f;
  materials[9].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[9].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[9].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[9].transparency.color = float3(0.75,0,0.75);
  //materials[9].transparency.color_texId = transpTexId2;
  materials[9].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRANSPARENCY_THIN_SURFACE;
  int COLORED_GLASS_MATERIAL = 9;


  //
  //
  texData = LoadTexture("data/color_glass.bmp", &w, &h);
  for(int i=0;i<w*h;i++)
    texData[i*4+3] = unsigned char(1);
  int transpTexId2 = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  materials[10].ambient.color    = float3(0.0,0.0,0.0);
  materials[10].diffuse.color    = float3(1.0f,1.0f,1.0f);

  materials[10].specular.color   = float3(0.0f,0.0f,0.0f);
  materials[10].specular.power   = 1.0f;
  materials[10].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[10].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[10].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[10].transparency.color = float3(0.75,0.75,0.75);
  materials[10].transparency.color_texId = transpTexId2;
  materials[10].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRANSPARENCY_THIN_SURFACE;
  int COLORED_GLASS_MATERIAL2 = 10;


  for(int i=0;i<11;i++)
    pRender->AddMaterial(materials[i]);



  AddFloor2(pRender, 255, FLOOR_MATERIAL);

  Matrix4x4f translate;
  Matrix4x4f rot;

  GLMmodel* bunny = glmReadOBJ("data/alex_meshes/bunny.obj");

  translate.SetTranslate(float3(3,-2,0));
  AddMeshFromOBJ(bunny,pRender,translate, PURE_WHITE_GLASS);

  translate.SetTranslate(float3(-3,-2,0));
  AddMeshFromOBJ(bunny,pRender,translate, DIFFUSE_RED);

  glmDelete(bunny);


  Cube cube;
  Matrix4x4f t1;

  t1.Identity();
  t1.SetTranslate(vec3f(0,-2.25f,2));
  cube = Cube(t1,1,255, PURE_WHITE_GLASS); 
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);

  Sphere4f sph;
  sph = Sphere4f(vec4f(0, -2, -4,0), 1.0);
  sph.material_id = DIFFUSE_WHITE;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(-4, -2, -4,1), 1.0);
  sph.material_id = DIFFUSE_RED;
  pRender->AddSpheres(&sph,1);

  sph = Sphere4f(vec4f(4, -2, -4,1), 1.0);
  sph.material_id = DIFFUSE_YELLOW;
  pRender->AddSpheres(&sph,1);


  // first quad
  {
    const int numVert = 4;
    const int numIndices = 6;
    Vertex4f  vert[numVert];
    unsigned int indices[numIndices];

    // triangles
    float size = 1;
    vert[0].pos.set(-size,0,-size,1); vert[0].norm.set(0,1,0,1);
    vert[1].pos.set(-size,0,size,1);  vert[1].norm.set(0,1,0,1);
    vert[2].pos.set(size,0,size,1);   vert[2].norm.set(0,1,0,1);
    vert[3].pos.set(size,0,-size,1);  vert[3].norm.set(0,1,0,1);

    Matrix4x4f mTransform, mRot, mTransate;

    mRot.SetRotationX(MGML_MATH::DEG_TO_RAD(115.0f));
    mTransate.SetTranslate(float3(0,-2.0,0.0));

    mTransform = mTransate*mRot;

    for(int i=0;i<4;i++)
    {
      vert[i].pos = mTransform*vert[i].pos;
      vert[i].norm =  matrix4x4f_mult_normal4f(mTransform, vert[i].norm);
    }

    vert[0].material_id = LEAFES_MATERIAL;
    vert[1].material_id = LEAFES_MATERIAL;
    vert[2].material_id = LEAFES_MATERIAL;
    vert[3].material_id = LEAFES_MATERIAL;

    float wrap = 1.0f;
    vert[0].t.set(0,0); 
    vert[1].t.set(0,wrap);
    vert[2].t.set(wrap,wrap); 
    vert[3].t.set(wrap,0);

    indices[0]=0;indices[1]=1;indices[2]=2;
    indices[3]=2;indices[4]=3;indices[5]=0;

    pRender->AddTriangles(vert,numVert,indices,numIndices);
  }

  
  // second quad
  {
    const int numVert = 4;
    const int numIndices = 6;
    Vertex4f  vert[numVert];
    unsigned int indices[numIndices];

    // triangles
    float size = 1;
    vert[0].pos.set(-size,0,-size,1); vert[0].norm.set(0,1,0,1);
    vert[1].pos.set(-size,0,size,1);  vert[1].norm.set(0,1,0,1);
    vert[2].pos.set(size,0,size,1);   vert[2].norm.set(0,1,0,1);
    vert[3].pos.set(size,0,-size,1);  vert[3].norm.set(0,1,0,1);

    Matrix4x4f mTransform, mRot, mTransate;

    mRot.SetRotationX(MGML_MATH::DEG_TO_RAD(115.0f));
    mTransate.SetTranslate(float3(-2.0, -2.0, -2.0));

    mTransform = mTransate*mRot;

    for(int i=0;i<4;i++)
    {
      vert[i].pos = mTransform*vert[i].pos;
      vert[i].norm =  matrix4x4f_mult_normal4f(mTransform, vert[i].norm);
    }

    vert[0].material_id = COLORED_GLASS_MATERIAL;
    vert[1].material_id = COLORED_GLASS_MATERIAL;
    vert[2].material_id = COLORED_GLASS_MATERIAL;
    vert[3].material_id = COLORED_GLASS_MATERIAL;

    float wrap = 1.0f;
    vert[0].t.set(0,0); 
    vert[1].t.set(0,wrap);
    vert[2].t.set(wrap,wrap); 
    vert[3].t.set(wrap,0);

    indices[0]=0;indices[1]=1;indices[2]=2;
    indices[3]=2;indices[4]=3;indices[5]=0;

    pRender->AddTriangles(vert,numVert,indices,numIndices);
  }

  // third quad
  {
    const int numVert = 4;
    const int numIndices = 6;
    Vertex4f  vert[numVert];
    unsigned int indices[numIndices];

    // triangles
    float size = 1;
    vert[0].pos.set(-size,0,-size,1); vert[0].norm.set(0,1,0,1);
    vert[1].pos.set(-size,0,size,1);  vert[1].norm.set(0,1,0,1);
    vert[2].pos.set(size,0,size,1);   vert[2].norm.set(0,1,0,1);
    vert[3].pos.set(size,0,-size,1);  vert[3].norm.set(0,1,0,1);

    Matrix4x4f mTransform, mRot, mTransate;

    mRot.SetRotationX(MGML_MATH::DEG_TO_RAD(115.0f));
    mTransate.SetTranslate(float3(2.0, -2.0, -2.0));

    mTransform = mTransate*mRot;

    for(int i=0;i<4;i++)
    {
      vert[i].pos = mTransform*vert[i].pos;
      vert[i].norm =  matrix4x4f_mult_normal4f(mTransform, vert[i].norm);
    }

    vert[0].material_id = COLORED_GLASS_MATERIAL2;
    vert[1].material_id = COLORED_GLASS_MATERIAL2;
    vert[2].material_id = COLORED_GLASS_MATERIAL2;
    vert[3].material_id = COLORED_GLASS_MATERIAL2;

    float wrap = 1.0f;
    vert[0].t.set(0,0); 
    vert[1].t.set(0,wrap);
    vert[2].t.set(wrap,wrap); 
    vert[3].t.set(wrap,0);

    indices[0]=0;indices[1]=1;indices[2]=2;
    indices[3]=2;indices[4]=3;indices[5]=0;

    pRender->AddTriangles(vert,numVert,indices,numIndices);
  }


  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(2,2.99,2);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);

}




void MakeTestScene_GlossySphereInCornellBox(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);


  HydraMaterial h_materials[5];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);

  h_materials[1].diffuse.color  = float3(0.1, 0.1, 0.1);
  h_materials[1].specular.color = float3(0.5,0.5,0.5);
  h_materials[1].specular.power = 60;
  h_materials[1].reflection.color = h_materials[1].specular.color;
  h_materials[1].reflection.power = 500;

  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.5,0.0);

  for(int i=0;i<5;i++)
    pRender->AddMaterial(h_materials[i]);
  

  // triangles
  Vertex4f vert[4];
  uint sideIndices[6];

  float size = 4;

  // floor
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-size,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-size,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = 1;
  vert[1].material_id = 1;
  vert[2].material_id = 1;
  vert[3].material_id = 1;


  float wrap = 4.0f;
  //float wrap = 1.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);
  sideIndices[0]=0;sideIndices[1]=1;sideIndices[2]=2;
  sideIndices[3]=2;sideIndices[4]=3;sideIndices[5]=0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // top
  vert[0].pos.set(-size,size,-size,1); vert[0].norm.set(0,-1,0,1);
  vert[1].pos.set(-size,size,size,1);  vert[1].norm.set(0,-1,0,1);
  vert[2].pos.set(size, size,size,1);   vert[2].norm.set(0,-1,0,1);
  vert[3].pos.set(size, size,-size,1);  vert[3].norm.set(0,-1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // left wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(1,0,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(1,0,0,1);
  vert[2].pos.set(-size,size,size,1);   vert[2].norm.set(1,0,0,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(1,0,0,1);

  vert[0].material_id = 2;
  vert[1].material_id = 2;
  vert[2].material_id = 2;
  vert[3].material_id = 2;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // right wall
  vert[0].pos.set(size,-size,-size,1); vert[0].norm.set(-1,0,0,1);
  vert[1].pos.set(size,-size,size,1);  vert[1].norm.set(-1,0,0,1);
  vert[2].pos.set(size,size,size,1);   vert[2].norm.set(-1,0,0,1);
  vert[3].pos.set(size,size,-size,1);  vert[3].norm.set(-1,0,0,1);

  vert[0].material_id = 4;
  vert[1].material_id = 4;
  vert[2].material_id = 4;
  vert[3].material_id = 4;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // back wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,0,1,1);
  vert[1].pos.set(size,-size,-size,1);  vert[1].norm.set(0,0,1,1);
  vert[2].pos.set(size,size,-size,1);   vert[2].norm.set(0,0,1,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(0,0,1,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);


  Sphere4f sphere;
  sphere.pos.set(0,-2,0,1);
  sphere.setRadius(2.0f);
  sphere.material_id = 1;
  pRender->AddSpheres(&sphere, 1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}





void MakeTestScene_GlassSphereInCornellBox(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);


  HydraMaterial h_materials[6];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);

  h_materials[1].diffuse.color  = float3(0.1, 0.1, 0.1);
  h_materials[1].specular.color = float3(0.5,0.5,0.5);
  h_materials[1].specular.power = 60;
  h_materials[1].reflection.color = h_materials[1].specular.color;
  h_materials[1].reflection.power = 500;

  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.5,0.0);

  h_materials[5].ambient.color    = float3(0,0,0);
  h_materials[5].diffuse.color    = float3(0.15f,0.15f,0.15f);
  h_materials[5].specular.color   = float3(0.25f,0.25f,0.25f);
  h_materials[5].specular.power   = 60.0f;
  h_materials[5].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  h_materials[5].reflection.color = float3(0.45f,0.45f,0.45f);
  h_materials[5].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  h_materials[5].transparency.color = float3(0.65f,0.65f,0.65f);
  h_materials[5].transparency.fogColor      = float3(1,1,1);
  h_materials[5].transparency.fogMultiplyer = 0.25f; // 
  h_materials[5].transparency.exitColor     = float3(1,0,0); // interest effect
  h_materials[5].transparency.IOR           = 2.2f;
  h_materials[5].flags = HydraMaterial::DEFAULT_FLAGS;
  int THIN_PURE_WHITE_GLASS = 5;

  for(int i=0;i<6;i++)
    pRender->AddMaterial(h_materials[i]);


  // triangles
  Vertex4f vert[4];
  uint sideIndices[6];

  float size = 4;

  // floor
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-size,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-size,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = 1;
  vert[1].material_id = 1;
  vert[2].material_id = 1;
  vert[3].material_id = 1;


  float wrap = 4.0f;
  //float wrap = 1.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);
  sideIndices[0]=0;sideIndices[1]=1;sideIndices[2]=2;
  sideIndices[3]=2;sideIndices[4]=3;sideIndices[5]=0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // top
  vert[0].pos.set(-size,size,-size,1); vert[0].norm.set(0,-1,0,1);
  vert[1].pos.set(-size,size,size,1);  vert[1].norm.set(0,-1,0,1);
  vert[2].pos.set(size, size,size,1);   vert[2].norm.set(0,-1,0,1);
  vert[3].pos.set(size, size,-size,1);  vert[3].norm.set(0,-1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // left wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(1,0,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(1,0,0,1);
  vert[2].pos.set(-size,size,size,1);   vert[2].norm.set(1,0,0,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(1,0,0,1);

  vert[0].material_id = 2;
  vert[1].material_id = 2;
  vert[2].material_id = 2;
  vert[3].material_id = 2;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // right wall
  vert[0].pos.set(size,-size,-size,1); vert[0].norm.set(-1,0,0,1);
  vert[1].pos.set(size,-size,size,1);  vert[1].norm.set(-1,0,0,1);
  vert[2].pos.set(size,size,size,1);   vert[2].norm.set(-1,0,0,1);
  vert[3].pos.set(size,size,-size,1);  vert[3].norm.set(-1,0,0,1);

  vert[0].material_id = 4;
  vert[1].material_id = 4;
  vert[2].material_id = 4;
  vert[3].material_id = 4;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // back wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,0,1,1);
  vert[1].pos.set(size,-size,-size,1);  vert[1].norm.set(0,0,1,1);
  vert[2].pos.set(size,size,-size,1);   vert[2].norm.set(0,0,1,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(0,0,1,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);


  Sphere4f sphere;
  sphere.pos.set(0,-2,0,1);
  sphere.setRadius(2.0f);
  sphere.material_id = THIN_PURE_WHITE_GLASS;
  pRender->AddSpheres(&sphere, 1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}



