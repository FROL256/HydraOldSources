#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gl/glew.h>
#include <gl/glut.h> 

#pragma comment(lib, "RTE.lib")

#ifndef MGML_GUARDIAN
#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "Input.h"
#include "Cube.h"
#include "Prism.h"
#include "Camera.h"

#include "scenes.h"
#include "ColladaImport.h"
//#include "../gpu_rt/Fonts.h"

extern Input input; 

void DrawDebugBoxes(std::string fileName)
{
  static bool first = true;
  static int displayListId = 258;
  static std::vector<AABB3f> boxes;

  glColor3f(1,1,0);

  if(first)
  {
    boxes.reserve(100000);
    ifstream fin(fileName.c_str());
    while(!fin.eof())
    {
      AABB3f box;
      fin >> box.vmin.x >> box.vmin.y >> box.vmin.z;
      fin >> box.vmax.x >> box.vmax.y >> box.vmax.z;
      boxes.push_back(box);
    }

    glNewList(displayListId, GL_COMPILE_AND_EXECUTE);
    for(int i=0;i<boxes.size();i++)
    {
      DrawBox(boxes[i]);
    }
    glEndList();
  }
  else
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glCallList(displayListId);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }

  first = false;
}


void DrawDebugBoxesLayered(std::string fileName, int maxFiles)
{
  static bool first = true;
  static int displayListId = 300;
  static int filesDone = 0;
  static std::vector<int> displayLists;
  static std::vector<AABB3f> boxes;

  glColor3f(1,1,0);

  if(first)
  {
    boxes.reserve(20000);
    
    for(int i=0;i<maxFiles;i++)
    {
      boxes.resize(0);

      std::string fname = fileName + ToString(i) + ".txt";
      ifstream fin(fname.c_str());
      if(!fin.is_open())
        break;

      filesDone = i;

      while(!fin.eof())
      {
        AABB3f box;
        fin >> box.vmin.x >> box.vmin.y >> box.vmin.z;
        fin >> box.vmax.x >> box.vmax.y >> box.vmax.z;
        boxes.push_back(box);
      }

      glNewList(displayListId+i, GL_COMPILE_AND_EXECUTE);
      displayLists.push_back(displayListId+i);

      for(int i=0;i<boxes.size();i++)
        DrawBox(boxes[i]);
      
      glEndList();
    }
  }
  else
  {
    int id = MGML_MATH::MAX<int>(0,input.debugLayerDraw); 
    id = MGML_MATH::MIN<int>(id, filesDone);
    
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    
    glColor3f(1,1,0);
    glCallList(displayLists[id]);

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }

  first = false;
}




void DrawDebugPoints(std::string fileName)
{
  static bool first = true;
  static int displayListId = 257;
  static std::vector<float3> points;

  glColor3f(0,1,0);
  glEnable(GL_POINT_SMOOTH);
  glPointSize(4.0f);


  if(first)
  {
    points.reserve(20000);
    ifstream fin(fileName.c_str());
    while(!fin.eof())
    {
      float3 vmax;
      fin >> vmax.x >> vmax.y >> vmax.z;
      points.push_back(vmax);
    }

    glNewList(displayListId, GL_COMPILE_AND_EXECUTE);
    glBegin(GL_POINTS);
    for(int i=0;i<points.size();i++)
      glVertex3fv(points[i].M);
    glEnd();
    glEndList();
  }
  else
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glCallList(displayListId);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }

  first = false;
}

void DrawDebugTreeData2()
{
  static int displayListId = 260;
  static std::vector<float3> points;

  static IrradCacheOctreeAPI* pOctree = NULL;

  glColor3f(1,1,0);

  glEnable(GL_POINT_SMOOTH);
  glPointSize(3.0f);

  if(pOctree==NULL)
  {
    pOctree = new IC_Octree;
    pOctree->DebugLoad();

    glNewList(displayListId, GL_COMPILE_AND_EXECUTE);
    //pOctree->DebugDrawTree();
    glEndList();
  }
  else
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glColor3f(1,1,0);
    glCallList(displayListId);

    pOctree->DebugDrawLookUpResult(input.m_debugPos);

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }
}



void DrawDebugTreeData3()
{
  static int displayListId = 262;
  static std::vector<float3> points;

  static IrradCacheOctreeAPI* pOctree = NULL;

  glColor3f(1,1,0);

  glEnable(GL_POINT_SMOOTH);
  glPointSize(4.0f);

  std::vector<IrradianceCachePoint_Part1> m_iCache1;
  std::vector<IrradianceCachePoint_Part2> m_iCache2;
  std::vector<IrradianceCachePoint_Part3> m_iCache3;

  if(pOctree==NULL)
  {
    pOctree = new IC_Octree;
    
    ifstream fin1("part1.txt");
    ifstream fin2("part2.txt");
    ifstream fin3("part3.txt");
    ifstream other("bbox.txt");

    while(!fin1.eof())
    {
      IrradianceCachePoint_Part1 p1;
      IrradianceCachePoint_Part2 p2;
      IrradianceCachePoint_Part3 p3;

      fin1 >> p1.pos.x >> p1.pos.y >> p1.pos.z >> p1.materialId;
      fin2 >> p2.norm.x >> p2.norm.y >> p2.norm.z >> p2.active;
      fin3 >> p3.color.x >> p3.color.y >> p3.color.z >> p3.validityRadius;

      m_iCache1.push_back(p1);
      m_iCache2.push_back(p2);
      m_iCache3.push_back(p3);
    }
    
    AABB3f bBox;
    float maxSearchRadius;

    other >> bBox.vmin.x >> bBox.vmin.y >> bBox.vmin.z;
    other >> bBox.vmax.x >> bBox.vmax.y >> bBox.vmax.z;
    other >> maxSearchRadius;

    pOctree->SetBoundingBox(bBox);
    //pOctree->SetMaxSearchRadius(maxSearchRadius);

    pOctree->Insert(&m_iCache1[0], &m_iCache2[0], &m_iCache3[0], m_iCache1.size());
    pOctree->ConvertLayoutToLinearArray();
    pOctree->VerifyAndOutStatistic();

    glNewList(displayListId, GL_COMPILE_AND_EXECUTE);
    glBegin(GL_POINTS);
    for(int i=0;i<m_iCache1.size();i++)
      glVertex3fv(m_iCache1[i].pos.M);
    glEnd();
    glEndList();
  }
  else
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glColor3f(0,0,1);
    glBegin(GL_POINTS);
    glVertex3fv(input.m_debugPos.M);
    glEnd();

    glColor3f(1,0,0);
    glCallList(displayListId);

    pOctree->DebugDrawLookUpResult(input.m_debugPos);

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }
}

void DrawDebugSphereBox()
{
  AABB3f box(float3(1,1,1), float3(1.1,1.1,1.1));
  Sphere3f sphere(input.m_debugPos, 0.25f);

  if(MGML_MATH::Intersect<AABB3f,Sphere3f>::exec(box, sphere))
    glColor3f(1,0,0);
  else
    glColor3f(0,0,1);

  glDisable(GL_LIGHTING);
  glDisable(GL_TEXTURE_2D);

  glPushMatrix();
    glTranslatef(sphere.pos.x, sphere.pos.y, sphere.pos.z);
    glutWireSphere(sphere.r, 32, 32);
  glPopMatrix();

  glPushMatrix();
    glTranslatef(box.center().x, box.center().y, box.center().z);
    glutWireCube(box.vmax.x - box.vmin.x);
  glPopMatrix();

  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);
}



void DrawDebugSpheres(std::string fileName)
{
  static bool first = true;
  static int displayListId = 261;
  static std::vector<float3> points;
  static std::vector<float>  radises;

  glColor3f(1,1,0);

  if(first)
  {
    points.reserve(20000);
    radises.reserve(20000);
    ifstream fin(fileName.c_str());
    while(!fin.eof())
    {
      float3 vmax;
      fin >> vmax.x >> vmax.y >> vmax.z;
      points.push_back(vmax);

      float radius;
      fin >> radius;
      radises.push_back(radius);
    }

    glNewList(displayListId, GL_COMPILE_AND_EXECUTE);
    glColor3f(0.25,0.25,1);   
    for(int i=0;i<points.size();i++)
    {
      glPushMatrix();
      glTranslatef(points[i].x, points[i].y, points[i].z);
      glutWireSphere(radises[i], 16, 16);
      glPopMatrix();
    }
    glEndList();
  }
  else
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glCallList(displayListId);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }

  first = false;
}


void DrawDebugSpheres2(std::string fileName, int maxFiles)
{
  static bool first = true;
  static int displayListId = 300;
  static int filesDone = 0;
  static std::vector<int> displayLists;
  static std::vector<float3> points;
  static std::vector<float>  radises;

  glColor3f(1,1,0);

  if(first)
  {
    points.reserve(20000);
    radises.reserve(20000);

    
    for(int i=0;i<maxFiles;i++)
    {
      points.resize(0);
      radises.resize(0);

      std::string fname = fileName + ToString(i) + ".txt";
      ifstream fin(fname.c_str());
      if(!fin.is_open())
        break;

      filesDone = i;

      while(!fin.eof())
      {
        float3 vmax;
        fin >> vmax.x >> vmax.y >> vmax.z;
        points.push_back(vmax);

        float radius;
        fin >> radius;
        radises.push_back(radius);
      }

      glNewList(displayListId+i, GL_COMPILE_AND_EXECUTE);
      displayLists.push_back(displayListId+i);

      glBegin(GL_POINTS);
      for(int i=0;i<points.size();i++)
        glVertex3fv(points[i].M);
      
      /*for(int i=0;i<points.size();i++)
      {
        glPushMatrix();
        glTranslatef(points[i].x, points[i].y, points[i].z);
        glutWireSphere(radises[i], 16, 16);
        glPopMatrix();
      }*/

      glEnd();
      glEndList();
    }
  }
  else
  {
    int id = MGML_MATH::MAX<int>(0,input.debugLayerDraw); 
    id = MGML_MATH::MIN<int>(id, filesDone);
    
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glColor3f(0.25,0.25,1);   
    for(int i=0;i<id;i++)
      glCallList(displayLists[i]);
    
    glColor3f(1,1,0);
    glCallList(displayLists[id]);

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }

  first = false;
}


void DebugDrawRays(std::string fileNamePos, std::string fileNameDir, std::string fileNameColor)
{
  static bool first = true;
  static int displayListId = 301;

  if(first)
  {
    std::ifstream fin1(fileNamePos.c_str());
    std::ifstream fin2(fileNameDir.c_str());
    std::ifstream fin3(fileNameColor.c_str());
 
    std::vector<float3> m_debugRaysPos;
    std::vector<float3> m_debugRaysDir;
    std::vector<float3> m_debugRaysCol;

    m_debugRaysPos.reserve(10000); m_debugRaysPos.resize(0);
    m_debugRaysDir.resize(10000);  m_debugRaysDir.resize(0);
    m_debugRaysCol.resize(10000);  m_debugRaysCol.resize(0);

    char tmp[128];

    int i=0;
    while(!fin1.eof())
    {
      float3 pos, dir, col;

      fin1 >> pos.x >> pos.y >> pos.z; fin1.getline(tmp,128);
      fin2 >> dir.x >> dir.y >> dir.z; fin2.getline(tmp,128);
      fin3 >> col.x >> col.y >> col.z; fin3.getline(tmp,128);

      m_debugRaysPos.push_back(pos);
      m_debugRaysDir.push_back(dir);
      m_debugRaysCol.push_back(col);

      i++;
      if(fin1.eof() || fin2.eof())
        break;
    }

    glNewList(displayListId, GL_COMPILE_AND_EXECUTE);

    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);

    glColor3f(1,1,0);
    glBegin(GL_POINTS);
    for(int i=0;i<m_debugRaysPos.size();i++)
    {
      //glVertex3fv(m_debugRaysPos[i].M);
      glColor3f(m_debugRaysCol[i].x, m_debugRaysCol[i].y, m_debugRaysCol[i].z);
      glVertex3fv((m_debugRaysPos[i] + 0.5f*m_debugRaysDir[i]).M);
    }

    glEnd();
    glEndList();

    first = false;
  }
  else
  {
    glEnable(GL_COLOR);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glCallList(displayListId);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
  }


}

