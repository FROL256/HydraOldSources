#pragma once

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/GPU_Path_Tracer.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"

struct Input : public MGML_MATH::SSE_Aligned_Object
{
	Input();

	void reset() {cam_mov.set(0,0,0,1); printPerfInfo = false;}

	MGML::vec4f cam_rot, cam_mov;
  MGML::vec3f rayPos, rayRot;
	int mx,my;
	bool ldown;		// ������ ����� ������� ����?
	bool rdown;		// ������ ������ ������� ����?
	bool exit_status;
  bool drawAllGrid;
  bool pathTracingEnabled;
  bool relightEnabled;

	int trace_depth;
  int diffuse_trace_depth;
  int tree_level_visible;
	bool shadows;
  bool indirrectIllum;
  int AA;

  bool computeIrradianceCache;
  bool irradianceCacheCalculated;
  bool freeIrradianceCache;

  bool computeRadianceCache;
  bool radianceCacheCalculated;

  bool tracePhotonsDebug;
  bool photonTracingFinishedDebug;

  bool voxelizeNow;

  int  rcType;
  bool debugViewSHReconstructed;

  bool printPerfInfo;
  bool drawBlocks;
  bool drawRayStatInfo;
  bool drawIrradianceCachePixelPoints;
  bool saveImageNow;
  bool useFiltering;
  float icWSErrorTreshold;

  HANDLE m_sharedMemoryHandle;
  int ext_width;
  int ext_height;
  std::string ext_scene;
  std::string ext_renderer;
  bool animateLight;
  int accelStructConstructionMode;
  int debugLayerDraw;

  std::string inColladaFile;
  std::string inColladaProfile;

  GPU_Path_Tracer::RenderingParams pt_params;
  const char* inputXML;

  int m_debugIndex;
  float3 m_debugPos;

  float hdrStrength;
  float hdrPhi;
  float hdrGamma;

  void ReadXMLFromSharedMemory();
  void ReadXMLFromFile(const std::string& fileName);

	void Mouse(int button, int state, int x, int y); //��������� ������� ����
	void MouseMotion(int x, int y);                  //����������� ����
	void Keyboard(unsigned char key,int x,int y);   //�����
	void KeyboardSpecial(int key, int x, int y);   // ���� �����

  void SetCameraForTestPerf(std::string scene_name, int cam_number);


protected:

  void ReadXMLFromDoc(TiXmlDocument& a_doc);
};


