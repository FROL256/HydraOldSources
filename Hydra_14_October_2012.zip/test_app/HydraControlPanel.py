from Tkinter import *

import tkFileDialog
import mmap
import os
import ctypes
import time

# there is some thing like main class
#
class HydraControlPanel:

  # constructor
  #
  def __init__(self):
    
    #init shared memory and write header 
    #
    self.shmem = mmap.mmap(0, 32000, "RTE_benchmark_shmem")
    self.shmem.seek(0)
    self.shmem.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    self.mode = "draw"
		
    # create Tkinter object
    #
    self.root = Tk()
    self.root.title("Hydra Control Panel v0.1 alpha")
		
    self.animate_light = IntVar()
    self.animate_light.set(0)
   
    self.path_tracing = IntVar()
    self.path_tracing.set(0)
   
    self.computeIrradianceCache = IntVar()
    self.computeIrradianceCache.set(0)
    
    self.freeIrradianceCache = IntVar()
    self.freeIrradianceCache.set(0)
    self.irradianceCacheDone = False
    
    self.save_image = IntVar()
    self.save_image.set(0)
   
    grid_width = 16
   
    def hello(): 
      pass
      
    def help():
      root2 = Tk()
      root2.title("Help")
      msg = Message(root2, text="This is HydraRender demo. See http://ray-tracing.ru for additional information.")
      msg.config(bg='white', font=('times', 16), width = 512)
      msg.pack()
      
    menubar = Menu(self.root, tearoff=0)
    menubar.add_command(label="File", command=hello)
    menubar.add_command(label="Exit", command=self.exit_program)
    menubar.add_command(label="Help", command=help)
    self.root.config(menu=menubar)
    
    ''' TEXT ''' 
    text = Label(self.root, text="Control Buttons", width = grid_width)
    text.grid(row=0, column=1)
    
    text = Label(self.root, text="Quality presets", width = grid_width)
    text.grid(row=0, column=2)
    
    text = Label(self.root, text="Renderer and scene", width=22)
    text.grid(row=0, column=3)
    
    text = Label(self.root, text="render params", width = grid_width)
    text.grid(row=0, column=4)
    
    text = Label(self.root, text="params values", width = grid_width)
    text.grid(row=0, column=5)
    
    text = Label(self.root, text="BVH construction", width = grid_width)
    text.grid(row=0, column=6)
    
    text = Label(self.root, text="Path to scene file:  ")
    text.grid(row=8, column=1)
    
    text = Label(self.root, text="Collada profile name:  ")
    text.grid(row=9, column=1)
    
    ''' CHECKBUTTONS '''
    self.shadows = IntVar(self.root)
    self.shadowsX = Checkbutton(self.root, variable = self.shadows, onvalue="1", offvalue="0", command = self.reload_config, text = "Shadows    ")
    self.shadowsX.grid(row = 1, column = 2, sticky=E)
   
    #self.indirectIllum = IntVar(self.root)
    #self.indirectIllumX = Checkbutton(self.root, variable = self.indirectIllum, onvalue="1", offvalue="0", command = self.reload_config, text = "DiffBounce")
    #self.indirectIllumX.grid(row = 2, column = 2, sticky=E)

    text = Label(self.root, text="Depth  : ")
    text.grid(row=2, column=2)
    self.trace_depth = Spinbox(values=(1, 2, 3, 4, 5, 6, 7, 8, 9), command = self.reload_config, width = 2)
    self.trace_depth.grid(row=2, column = 2, sticky=E)    
   
    text = Label(self.root, text="DiffMax: ")
    text.grid(row=3, column=2)
    self.diff_trace_depth = Spinbox(values=(0, 1, 2, 3, 4, 5, 6, 7, 8), command = self.reload_config, width = 2)
    self.diff_trace_depth.grid(row=3, column = 2, sticky=E)
   
    
    self.relight = IntVar(self.root)
    self.relightX = Checkbutton(self.root, text = "Relighting", variable = self.relight, onvalue="1", offvalue="0", command = self.reload_config)
    self.relightX.grid(row = 4, column = 3, sticky=E)
    
    ''' OPTION '''
    self.scene = StringVar(self.root)
    self.scene.set("SomeColladaFile.dae") # default value
    self.sceneX = Entry(self.root, textvariable=self.scene)
    self.sceneX.grid(row = 8, column = 2, columnspan = 4, sticky = W+E+N+S)
    
    self.colladaProfile  = StringVar(self.root)
    self.colladaProfile2 = StringVar(self.root)
    self.colladaProfile.set("hydra_profile.xml") # default value
    self.colladaProfileX = Entry(self.root, textvariable=self.colladaProfile)
    self.colladaProfileX.grid(row = 9, column = 2, columnspan = 1, sticky = W+E+N+S)
    
    self.resolution = StringVar(self.root)
    self.resolution.set("1024x768") # default value
    self.resolutionX = OptionMenu(self.root, self.resolution, "512x512", "640x480", "1024x768", "1024x1024", "1280x1024", "1920x1200", command = self.restart_program)
    self.resolutionX.grid(row = 2, column = 3, sticky = W+E)
    
    self.anti_aliasing = StringVar(self.root)
    self.anti_aliasing.set("AA: 1x") # default value
    self.anti_aliasingX = OptionMenu(self.root, self.anti_aliasing, "AA: 1x", "AA: 4x", "AA: 16x", "AA: 64x", command = self.reload_config)
    self.anti_aliasingX.grid(row = 1, column = 3, sticky = W+E)
  
    self.renderer_type = StringVar(self.root)
    self.renderer_type.set("Ray Tracing") # default value
    self.renderer_typeX = OptionMenu(self.root, self.renderer_type, "Ray Tracing", "OpenGL", command = self.restart_program)
    self.renderer_typeX.grid(row = 3, column = 3, sticky = W+E)
    
    self.kd_tree_mode = StringVar(self.root)
    self.kd_tree_mode.set("quality")
    
    kd_tree = Radiobutton(self.root, text="quality", variable=self.kd_tree_mode, value="quality", command = self.restart_program)
    kd_tree.grid(row=1, column=6, sticky=W);
    
    kd_tree = Radiobutton(self.root, text="medium", variable=self.kd_tree_mode, value="medium", command = self.restart_program)
    kd_tree.grid(row=2, column=6, sticky=W);
    
    kd_tree = Radiobutton(self.root, text="fast", variable=self.kd_tree_mode, value="fast", command = self.restart_program)
    kd_tree.grid(row=3, column=6, sticky=W);
    
    ''' BUTTONS '''
    button_width  = grid_width
    button_height = 2
    
    button = Button(self.root, text = "Browse", command = self.load_collada_scene, width = button_width, height = button_height, bg="#551111", fg="white")
    button.grid(row=1, column=1, sticky = W+E+N+S)
    
    button = Button(self.root, text = "Restart", command = self.restart_program, width = button_width, height = button_height, bg="#DD0000", fg="white")
    button.grid(row=2, column=1, sticky = W+E+N+S)
   
    button = Button(self.root, text = "Path tracing", command = self.enable_path_tracing, width = button_width, height = button_height, bg="#00AA00", fg="white")
    button.grid(row=3, column=1, sticky = W+E+N+S)
    
    button = Button(self.root, text = "Irradiance Cache", command = self.irradiance_cache, width = button_width, height = button_height, bg="#AAAA00", fg="white")
    button.grid(row=4, column=1, sticky = W+E+N+S)
    
    button = Button(self.root, text = "Save Image Now", command = self.save_curr_image, width = button_width, height = button_height, bg="#AA00AA", fg="white")
    button.grid(row=5, column=1, sticky = W+E+N+S)
    
    #button = Button(self.root, text = "Animate Light", command = self.animate_mode, width = button_width, height = button_height, bg="blue", fg="white")
    #button.grid(row=5, column=1, sticky = W+E+N+S)
   
    button = Button(self.root, text = "Exit", command = self.exit_program, width = button_width, height = button_height, bg= "black", fg="white")
    button.grid(row=6, column=1, sticky = W+E+N+S)
    
    
    ''' PATH TRACING '''
    self.minRaysPerPixel = IntVar(); self.minRaysPerPixel.set(8)
    self.maxRaysPerPixel = IntVar(); self.maxRaysPerPixel.set(1000)
    self.qualityTreshold = DoubleVar(); self.qualityTreshold.set(0.01)
    self.useHDRQualityEstimation  = IntVar(); self.useHDRQualityEstimation.set(1)
    self.useLoyalEstimateFunction = IntVar(); self.useLoyalEstimateFunction.set(1)
    self.loaylEstimateFunctionTresholdInRays = IntVar(); self.loaylEstimateFunctionTresholdInRays.set(200)
    self.icWorldSpaceErrorTreshold = DoubleVar(); self.icWorldSpaceErrorTreshold.set(2.5)
    
    self.drawBlocks = IntVar(); self.drawBlocks.set(0)
    self.drawRaysStatInfo = IntVar(); self.drawRaysStatInfo.set(0)
    self.enableDOF = IntVar()
    self.dofLensRadius = DoubleVar(); self.dofLensRadius.set(0.05)
    self.dofFocalPlaneDist = DoubleVar(); self.dofFocalPlaneDist.set(8.0)

    
    Label(self.root, text = "minRaysPerPixel").grid(row=1, column=4)
    Entry(self.root, textvariable=self.minRaysPerPixel).grid(row=1, column=5, sticky=W)
    
    Label(self.root, text = "maxRaysPerPixel").grid(row=2, column=4)
    Entry(self.root, textvariable=self.maxRaysPerPixel).grid(row=2, column=5, sticky=W)
    
    Label(self.root, text = "qualityTreshold").grid(row=3, column=4)
    Entry(self.root, textvariable=self.qualityTreshold).grid(row=3, column=5, sticky=W)

    Label(self.root, text = "LE(rays) treshold").grid(row=6, column=4)
    Entry(self.root, textvariable=self.loaylEstimateFunctionTresholdInRays).grid(row=6, column=5, sticky=W)
    
    Label(self.root, text = "Irradiance Cache world space error treshold:").grid(row=9, column=3, columnspan = 2)
    Entry(self.root, textvariable=self.icWorldSpaceErrorTreshold).grid(row=9, column=5, sticky=W)
    
    Checkbutton(self.root, text = "HDR estimation", variable = self.useHDRQualityEstimation, onvalue="1", offvalue="0", command = self.reload_config).grid(row=4, column = 4, sticky=W)
    Checkbutton(self.root, text = "Loyal estimation", variable = self.useLoyalEstimateFunction, onvalue="1", offvalue="0", command = self.reload_config).grid(row=5, column = 4, sticky=W)
    
    Checkbutton(self.root, text = "Draw blocks", variable = self.drawBlocks, onvalue="1", offvalue="0", command = self.reload_config).grid(row=4, column = 5, sticky=W)
    Checkbutton(self.root, text = "Draw stat info", variable = self.drawRaysStatInfo, onvalue="1", offvalue="0", command = self.reload_config).grid(row=5, column = 5, sticky=W)
   
    Checkbutton(self.root, text = "Enable DOF", variable = self.enableDOF, onvalue="1", offvalue="0", command = self.reload_config).grid(row=4, column = 2, sticky=E)
    
    Label(self.root, text = "dofLensRadius").grid(row=5, column=2)
    Entry(self.root, textvariable=self.dofLensRadius).grid(row=5, column=3, sticky=W)
    
    Label(self.root, text = "dofFocalPlaneDist").grid(row=6, column=2)
    Entry(self.root, textvariable=self.dofFocalPlaneDist).grid(row=6, column=3, sticky=W)
    
    self.exe_path = StringVar(); self.exe_path.set("test_app.exe")
    Label(self.root, text = "Application type").grid(row=7, column=4)
    OptionMenu(self.root, self.exe_path, "test_app.exe", "HydraServer.exe", command = self.restart_program).grid(row=7, column=5)
    
    self.reload_config()
    
  #write xml to shmem; Call this function every timewhen you update input data
  #
  def reload_config(self, *args):
    
    ''' special code for collada profile '''
    if "colladaProfile" in self.__dict__.keys():
      path_to_scene = self.scene.get()
      profile_path  = self.colladaProfile.get()
      
      posOfSlash1 = path_to_scene.rfind('\\')
      posOfSlash2 = path_to_scene.rfind('/')
      posOfSlash  = max(posOfSlash1, posOfSlash2)
      
      if posOfSlash > 0:
        profile_path = path_to_scene[0:posOfSlash] + "/" + profile_path
        self.colladaProfile2.set(profile_path)
        
        #print profile_path
    
    xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> \n"
     
    for key in self.__dict__.keys():
      try:
        xmlString += "<" + key + "> " + str(self.__dict__[key].get()) + " </" + key + "> \n"
      except AttributeError: 
        try:
          if key != "shmem":
            xmlString += "<" + key + "> " + str(self.__dict__[key]) + " </" + key + "> \n"
        except AttributeError: 
          pass
       
    #print xmlString;
    self.shmem.seek(0)
    self.shmem.write(xmlString);

  
  #launch kernel program	
  #
  def restart_program(self, *args):
    self.reload_config()
    
    param1 = self.scene.get()
    path   = self.exe_path.get()
    
    if self.__dict__.has_key("core_process_id"):
      ctypes.windll.kernel32.TerminateProcess(int(self.core_process_id), -1)
    self.core_process_id = os.spawnv(os.P_NOWAIT, path, [path, param1])
    print "Hydra core restarted..."
  

  def enable_path_tracing(self):
    self.path_tracing.set( not(self.path_tracing.get()) );
    self.reload_config()
        
  def animate_mode(self):
    self.animate_light.set( not(self.animate_light.get()) )
    self.restart_program()
    
  def irradiance_cache(self):
    if not self.irradianceCacheDone:
      self.freeIrradianceCache.set(0)
      self.computeIrradianceCache.set(1)
      self.reload_config()
    
      time.sleep(0.1)
      self.computeIrradianceCache.set(0)
      self.reload_config()
      self.irradianceCacheDone = True
    else:
      self.freeIrradianceCache.set(1)
      self.irradianceCacheDone = False
      self.reload_config()
    
  def save_curr_image(self):
    self.save_image.set(1)
    self.reload_config()
    
    time.sleep(0.1)
    self.save_image.set(0)
    self.reload_config()
  
  def exit_program(self):
    if self.__dict__.has_key("core_process_id"):
      ctypes.windll.kernel32.TerminateProcess(int(self.core_process_id), -1)
    exit()
    
  def load_collada_scene(self): 
    filename = tkFileDialog.askopenfilename(filetypes = (("Collada files", "*.dae")
                                                        ,("XML files", "*.xml;")
                                                        ,("All files", "*.*") ))
    if filename: 
      try: 
        self.scene.set(filename)
      except: 
        tkMessageBox.showerror("Open Source File", "Failed to read file \n'%s'"%filename)


my_prog = HydraControlPanel()

#thats from Tkinter, need to call it whaen interface have been created
#
mainloop()
