#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gl/glew.h>
#include <gl/glut.h> 

#pragma comment(lib, "RTE.lib")

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "Input.h"
#include "Cube.h"
#include "Prism.h"
#include "Camera.h"

#include "scenes.h"
#include "ColladaImport.h"
//#include "../gpu_rt/Fonts.h"


#include "ReLight.h"
#include <sstream>

#include "../HDRCore/PostProcessEngine/image.h"
#include "../HDRCore/PostProcessEngine/filters/tonemappingfilter.h"
#include "../HDRCore/PostProcessEngine/filters/blurfilter.h"
#include "../HDRCore/PostProcessEngine/filters/boxfilter.h"


#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

using namespace MGML;
//using namespace RAYTR;
using namespace MGML_MATH;
using namespace std;

int WinWidth = 640;
int WinHeight = 480;

IGraphicsEngine* pRender = NULL;
IReLightProxy*   pReLightApp = NULL;
Input input;  

Camera* cam;

volatile bool pathTracingFinished = false;
int ticksOld = 0;
int ticksNew = 0;
bool stopCountTime = false;
bool firstPass = 0;

float flyRadius = 8.0f;


void SetVSync(bool sync)
{
  typedef bool (APIENTRY *PFNWGLSWAPINTERVALFARPROC)(int);

  PFNWGLSWAPINTERVALFARPROC wglSwapIntervalEXT = 0;

  wglSwapIntervalEXT = (PFNWGLSWAPINTERVALFARPROC)wglGetProcAddress("wglSwapIntervalEXT");

  if( wglSwapIntervalEXT )
    wglSwapIntervalEXT(sync);
}

void CreateSHImages(int resX, int resY, int numLayers)
{
  std::vector<float> coeffs(resX*resY*numLayers);
  std::ifstream fin("D:\\out\\buffer.bin", std::ios::binary);
  if(!fin.is_open())
    std::cerr << "can't open fucking file" << std::endl;
  fin.read((char*)(&coeffs[0]), coeffs.size()*sizeof(float));
  fin.close();

  ILuint imageID = ilGenImage();
  ilBindImage(imageID);

  char fileName[64];
  for(int layer=0;layer<numLayers;layer++)
  {
    sprintf(fileName, "D:\\out\\frame%d.jpg", layer);
    float* data = &coeffs[layer*resX*resY];
    ilTexImage(resX,resY,1,1,IL_LUMINANCE,IL_FLOAT,data);
    ilEnable(IL_FILE_OVERWRITE);
    ilSave(IL_JPG, fileName);
  }

  ilDeleteImages(1, &imageID); 
  ilDisable(IL_FILE_OVERWRITE);
}


void Init()
{
	try
	{
    input.reset();
    SetVSync(0);

		//pRender = new GPU_Ray_Tracer(WinWidth, WinHeight);
    pRender = new GPU_Path_Tracer(WinWidth, WinHeight);
    //pRender = new OpenGL_Render(WinWidth,WinHeight);

    pReLightApp = new TestReLightPoxy(pRender);

    cam = new Camera();

    cam->SetPerspectiveProjection(45.0f, float(WinWidth)/float(WinHeight), 0.1f, 10000.0f);    
    
    //std::cout << "sizeof(HydraMaterial): " << sizeof(HydraMaterial) << std::endl;

    //vec4f pos(3,-2,7,0);
    //vec4f lookAt(0,0,0,0);
    //cam->pos = pos;
    //cam->SetRotation(vec4f(30.0,0.1,0,0));
    //cam->LookAt(pos,lookAt);
    //cam->LookAt(pos, lookAt);

    Matrix4x4f mr,mt,ms, ms2;
    float k = 0.1f/0.025400;
    ms.SetScale(float3(k,k,k));

    /*
    float k2 = 1.0f;
    ms2.SetScale(float3(k2,k2,k2));
    mt.SetTranslate(float3(0,0,0));
    ImportSceneFromCollada(pRender, "data/cubes/cubes2.DAE", cam, mt*ms2);
    
    pRender->Clear(IGraphicsEngine::CLEAR_LIGHTS);

    if(input.animateLight)
      MakeSomePointLights(pRender);
    else
      MakeSomeLights(pRender); 
*/
    flyRadius = 4;
    
    
    //if(ServerMain(pRender)!=0)
      //RUN_TIME_ERROR("Hydra server failed");


    if(input.inColladaFile != "")
    {
      ImportSceneFromCollada(pRender, input.inColladaFile, cam, ms, input.inColladaProfile);
    }
    else
    {
      std::cerr << "empty input file, using standard teapot" << std::endl;

      //ImportSceneFromCollada(pRender, "data/teapot_in_box_cam.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapot/teapot_in_box_cam_fovY_zUp.DAE", cam, ms);  
      //ImportSceneFromCollada(pRender, "data/teapot/teapot_tesselated_in_box_2.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapot/teapot_tesselated_in_box_3.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapot/teapot_tesselated_in_box_4.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapot/teapot_sphere_light.DAE", cam, ms); 
      //ImportSceneFromCollada(pRender, "data/env_light_tests/BoxAndSpheres_fixed.DAE", cam, ms); 
      //ImportSceneFromCollada(pRender, "data/env_light_tests/BoxAndSpheres_spot_fixed.DAE", cam, ms); 

      //ImportSceneFromCollada(pRender, "data/lessons/bunny_diff_and_spec.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/lessons/transparency_dragoons.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/lessons/transparency_boxes.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/lessons/transparency_boxes_diffuse.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/lessons/transparent_bunny.dae", cam, ms);
 
      //ImportSceneFromCollada(pRender, "data/lessons/transparency_boxes_fog.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/lessons/transparency_spheres.dae", cam, ms);

      //ImportSceneFromCollada(pRender, "data/lights_tests/teapot_light_1.DAE", cam, ms);

      //ImportSceneFromCollada(pRender, "data/teapots_5_fixed.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapots_5_fixed_hydra.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapots_5_fixed_hydra_displ.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapots_5_fixed_hydra_displ2.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/box_with_torus_knot.dae", cam, ms);
      
      //ImportSceneFromCollada(pRender, "data/models/Office Corridor.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/conference_deep_exp.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/teapot_in_box_point_light.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/models/Kishore's Kitchen.vtdae", cam, ms);
      
      //ImportSceneFromCollada(pRender, "data/sponza/sponza.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/sponza/sponza_fixed.DAE", cam, ms);
      //ImportSceneFromCollada(pRender, "data/heads/head1_fixed.dae", cam, ms);
      //ImportSceneFromCollada(pRender, "data/head2/head2_fixed.dae", cam, ms);

      //ImportSceneFromCollada(pRender, "data/cornell_several_objects_fixed2.DAE", cam, ms);

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/box_with_bunny/box_with_bunny.DAE", cam, ms,
        //                              "data/test_scenes/lessons/box_with_bunny/hydra_profile.xml");
      
      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/cornell/box_with_several_objects.dae", cam, ms,
        //                              "data/test_scenes/lessons/cornell/hydra_profile.xml");

      ImportSceneFromCollada(pRender, "data/test_scenes/lessons/cornell_teapot/box_with_teaport.dae", cam, ms,
                                      "data/test_scenes/lessons/cornell_teapot/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/transparency_boxes/transparency_boxes.dae", cam, ms,
        //                              "data/test_scenes/lessons/transparency_boxes/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/transparency_dragons/transparency_dragoons.DAE", cam, ms,
        //                              "data/test_scenes/lessons/transparency_dragons/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/transparency_spheres/transparency_spheres.dae", cam, ms,
        //                              "data/test_scenes/lessons/transparency_spheres/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/box_and_spheres/cube_and_spheres.dae", cam, ms,
        //                              "data/test_scenes/lessons/box_and_spheres/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/box_and_spheres2/cube_and_spheres.dae", cam, ms,
        //                              "data/test_scenes/lessons/box_and_spheres2/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/sponza/sponza4.DAE", cam, ms,
        //                              "data/test_scenes/architect/sponza/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/crytek-sponza/sponza4.dae", cam, ms,
        //                              "data/test_scenes/architect/crytek-sponza/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/conference/conference.DAE", cam, ms,
        //                              "data/test_scenes/architect/conference/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/conference2/conference_max_2012_2.dae", cam, ms,
        //                              "data/test_scenes/architect/conference2/hydra_profile.xml"); 


      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/sibenik2/sibenik2.dae", cam, ms,
        //                              "data/test_scenes/architect/sibenik2/hydra_profile.xml");


      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/sibenik2/sibenik.dae", cam, ms,
        //                              "data/test_scenes/architect/sibenik2/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/Natural_History/Natural_History.DAE", cam, ms,
        //                              "data/test_scenes/architect/Natural_History/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/art_studio/art_studio.dae", cam, ms,
        //                              "data/test_scenes/architect/art_studio/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/art_studio2/art_studio_v2.dae", cam, ms,
        //                              "data/test_scenes/architect/art_studio2/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/art_studio3/art_studio.dae", cam, ms,
        //                              "data/test_scenes/architect/art_studio3/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/mad_science/mad.DAE", cam, ms,
        //                              "data/test_scenes/architect/mad_science/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/other/hairball/hairball.DAE", cam, ms,
        //                              "data/test_scenes/other/hairball/hydra_profile.xml"); 


      //ImportSceneFromCollada(pRender, "data/test_scenes/outdoor/lost_empire_minecraft/lost_empire.DAE", cam, ms,
        //                              "data/test_scenes/outdoor/lost_empire_minecraft/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/other/FairyForest/fairy000.DAE", cam, ms,
        //                              "data/test_scenes/other/FairyForest/hydra_profile.xml");
 

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/3dexport_Living+room_max/room1.DAE", cam, ms,
        //                              "data/test_scenes/architect/3dexport_Living+room_max/hydra_profile.xml");
    
       
      // lights

      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/lights/directional/box_with_teapot1.DAE", cam, ms, 
        //                              "data/test_scenes/lessons/lights/directional/hydra_profile.xml");
      
      //ImportSceneFromCollada(pRender, "data/test_scenes/lessons/lights/spot/box_with_teaport1.dae", cam, ms, 
        //                              "data/test_scenes/lessons/lights/spot/hydra_profile.xml");


      // blender
      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/blender_interior1/Interior.dae", cam, ms,
        //                              "data/test_scenes/architect/blender_interior1/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect/blender_car1/dodgechallenger.dae", cam, ms,
        //                              "data/test_scenes/architect/blender_car1/hydra_profile.xml");

      // IDST pack
      //

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect2/arch_class/class1.DAE", cam, ms, // works
      //                                "data/test_scenes/architect2/arch_class/hydra_profile.xml");

      //ImportSceneFromCollada(pRender, "data/test_scenes/architect2/renaissance/Renaissance.dae", cam, ms, // do not works
        //                              "data/test_scenes/architect2/renaissance/hydra_profile.xml");


      //MakeRefractionDemo(pRender); flyRadius = 4;
      //MakeRandomSpheresDemo(pRender); flyRadius = 4;
      //MakeSimpleDemo(pRender);
      //MakeSimpleDemo2(pRender);
      //MakeSpheresDemo(pRender); flyRadius = 20;
      //MakeChairDemo(pRender);
      //MakeManyChairsDemo(pRender); flyRadius = 20;
      //MakeCornellBoxDemo(pRender); flyRadius = 2;
      
      //input.cam_rot.set(-25,25,0,1);   // conf room, position 1
      //input.cam_mov = float4(0,0,-8,1);

      
      //MakeClassicCornellBoxDemo(pRender); flyRadius = 2;
      //MakeDiffuseSphereInCornellBox(pRender); flyRadius = 2;
      //MakeEmptyCornellBox(pRender);
      //MakeDragonInCornellBox2(pRender);
      //MakeDragonInCornellBox3(pRender);
      //MakeConferenceRoomDemo(pRender); input.SetCameraForTestPerf("Conference Room", 0);
      //MakeSodaHallDemo(pRender);
      
      //MakeSibenikDemo(pRender);
      //MakeCowDemo(pRender);
      //MakeDragonDemo(pRender);
      //MakeGraphiconLogoDemo(pRender);
      //MakeLebedevCowBRDFDemo(pRender);
      //MakeLebedevBRDFDemo(pRender); flyRadius = 4;
      //MakeLebedevCarsBRDFDemo(pRender); flyRadius = 4;
      //MakeLebedevCornellBRDFDemo(pRender); flyRadius = 2;
      //MakeLebedevPlaneDemo(pRender);
      //MakeAlexanderKharlamovDemo(pRender);

      //MakeTestScene_DiffuseSphereOnPlane(pRender);
      //MakeTestScene_GlassDemo(pRender);
      //MakeTestScene_OpacityMapsDemo(pRender);
      //MakeTestScene_GlassSphereInCornellBox(pRender);

      //MakeTestScene_ParallaxMappingDemo(pRender); flyRadius = 4;
      //MakeTestScene_ParallaxMappingDemo2(pRender);
      //MakeTestScene_GlossySphereInCornellBox(pRender);

      //pReLightApp->LoadCustomScene(input.ext_scene);

      //CreateSHImages(192*2, 192, 16);
     
    }
      //light2.color.set(1,1,1);
      //light2.intensity = 1.0f;
      //light2.pos.set(2,3,4);
      //pRender->AddPointLight(light2);

    Ray_Tracer* pRayTracer = dynamic_cast<Ray_Tracer*>(pRender);
    if(pRayTracer != 0 && !input.animateLight)
      pRayTracer->AddLightsAsGeometry();  // try to add lights as geometry if needed

		cout << "constructing acceleration structures (may take a very long time), please wait...\n";
    Timer treeBuildTimer;
    treeBuildTimer.start();
    float timeStart = treeBuildTimer.getElapsed();

    pRender->BuildAccelerationStructures(input.accelStructConstructionMode);
    
    float totalConstructionTime = treeBuildTimer.getElapsed() - timeStart;
    cout << "construction time: " << totalConstructionTime << "s" << endl;
	}
	catch(std::bad_alloc e)
	{
    cerr << std::endl;
		string err_msg = NotEnoughMemory();
		ALERT(err_msg);
		cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
		exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
	catch(...)
	{
    cerr << std::endl;
		cout << "Unexpected Exception!" << endl;
		exit(-1);
	}
}


//////////////////////////////////////////////////////////////////////////
////
void ShutDown()
{
  try
	{
    cerr << std::endl;
    delete pReLightApp;
		delete pRender;
    delete cam;
    pRender = 0;
	}
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
}


void Display()
{
  static int FramesCount = 0;
	static float FPS = 60; // ������� ������ � �������

	static float t_process = 1;
	static float omega = 0.5;
  static float path_tracing_time = 0.0f;
  static bool imageSaved = false;

  static Timer timer; 

	try
	{
    input.ReadXMLFromSharedMemory();

		if(input.exit_status) 
      exit(0);

    if(t_process > 1000)
      t_process = 1.0f;

    if(!input.pathTracingEnabled)
    { 
      t_process += (omega/FPS);

      int numLights = pRender->GetLightNumber();
      if(numLights > 0)
      { 
        RAYTR::Light light = pRender->GetLight(0);
        light.pos.x = flyRadius*sin(t_process);
        light.pos.z = flyRadius*cos(t_process);
        if(input.animateLight)
          pRender->SetLight(light, 0);
      }
    
      cam->Move(input.cam_mov);
      cam->SetRotation(input.cam_rot);
    }

    pRender->SetWorldViewMatrix((cam->GetWorldMatrix()*cam->GetViewMatrix()).L);
    pRender->SetProjectionMatrix(cam->GetProjectionMatrix().L);

    pRender->SetVariable("drawIrradianceCachePixelPoints", input.drawIrradianceCachePixelPoints);
    pRender->SetVariable("debugViewSH", input.debugViewSHReconstructed);
    pRender->SetVariable("g_debugLayerDraw", input.debugLayerDraw);

    pRender->SetVariable("g_saveRaySamples", input.useFiltering);
    pRender->SetVariable("g_gamma", input.hdrGamma);

    IGraphicsEngine::RenderState renderState;

    renderState.SetTraceDepth(input.trace_depth);
    renderState.SetDiffuseTraceDepth(input.diffuse_trace_depth);
    renderState.SetShadow(input.shadows);
    renderState.SetAA(input.AA);
    renderState.SetIndirrectIllumination(input.indirrectIllum);
    renderState.SetEnableRaysCounter(input.drawRayStatInfo);
    renderState.icWSErrorTreshold = input.icWSErrorTreshold;

    if(input.irradianceCacheCalculated || input.radianceCacheCalculated)
    {
      renderState.SetIndirrectIllumination(false);
      //renderState.SetDiffuseTraceDepth(0);
    }

    // voxels
    //
    if(input.voxelizeNow == true)
    {
      pRender->DebugCall("voxelizeDebug","");
      input.voxelizeNow = false;
    }

    // RC
    //
    if(input.computeRadianceCache && !input.radianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->ComputeRadianceCache(input.rcType);
        input.radianceCacheCalculated = true;
        input.computeRadianceCache = 0;
      }
    }
    else if(input.computeRadianceCache && input.radianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->FreeRadianceCache();
        input.radianceCacheCalculated = false;
        input.computeRadianceCache = 0;
      }
    }

    // IC
    //
    if(input.irradianceCacheCalculated && (input.computeIrradianceCache || input.freeIrradianceCache))
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->FreeIrradianceCache();
      }

      input.irradianceCacheCalculated = false;
      input.computeIrradianceCache    = false;
    }
    else if(input.computeIrradianceCache && !input.relightEnabled)
    {
       GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
       if(pathTracer!=0)
       {
         pathTracer->ComputeIrradianceCache();
       }

       input.irradianceCacheCalculated = true;
       input.computeIrradianceCache    = false;
    }

    // Photon maps Debug
    //
    if(input.tracePhotonsDebug && !input.photonTracingFinishedDebug)
    {
      pRender->DebugCall("TracePhotonsTest","");
      input.photonTracingFinishedDebug = true;
      input.tracePhotonsDebug = false;
    }
    else if(input.tracePhotonsDebug && input.photonTracingFinishedDebug)
    {
      input.photonTracingFinishedDebug = false;
      input.tracePhotonsDebug = false;
    }

    
    // PT
    //
    if(input.pathTracingEnabled)
    {
      if(firstPass)
      {
        timer.start();
        firstPass = false;
      }

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if (pathTracer!=0)
      {
        GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;
        
        if(input.inputXML == NULL)
        {
          pathTracerParams.drawBlocks       = input.drawBlocks;
          pathTracerParams.drawRaysStatInfo = input.drawRayStatInfo;
        }

        pathTracer->SetRenderingParams(pathTracerParams);

        pathTracer->BeginPathTracingPass(renderState);
        pathTracingFinished = pathTracer->EndPathTracingPass();

        if(!stopCountTime)
          path_tracing_time += timer.getElapsed();

        if(pathTracingFinished && stopCountTime == false || input.saveImageNow == true)
        {
          if(!input.saveImageNow && !pathTracingFinished)
            stopCountTime = true;
          
          if(!imageSaved)
          {
            std::cerr << "saving image" << std::endl;

            uint* imageData = new uint [WinWidth*WinHeight];
            pRender->GetLDRImage(imageData);

            std::stringstream fileName; fileName.precision(6);
            fileName << "hydra_" << path_tracing_time << ".png";
            SaveImageToFile(fileName.str(), WinWidth, WinHeight, imageData);

            std::cerr << "image saved" << std::endl;
            delete [] imageData;

            float4* hdrImageData = new float4[WinWidth*WinHeight];
            pRender->GetHDRImage(hdrImageData);

            std::stringstream fileName2;  fileName2.precision(6);
            fileName2 << "hydra_" << path_tracing_time << ".hdr";
            SaveHDRImageToFile(fileName2.str(), WinWidth, WinHeight, hdrImageData);

            std::cerr << "hdr image saved" << std::endl;
          
            PP_FILTERS::Image src, dst;
            PP_FILTERS::ToneMappingFilter filter;
            PP_FILTERS::ToneMappingFilter::Presets hrdPresets;

            hrdPresets.strength = input.hdrStrength;
            hrdPresets.phi      = input.hdrPhi;
            filter.SetPresets(hrdPresets);

            src.Load(fileName2.str().c_str());
            //src.CreateLocked((float*)hdrImageData, WinWidth, WinHeight, WinWidth*4, 4);

            /*float* data = src.GetPointer();
            float power = 1.0/input.hdrGamma;
            for(int i=0;i<WinWidth*WinHeight;i++)
            {
              data[i*3+0] = powf(data[i*3+0], power);
              data[i*3+1] = powf(data[i*3+1], power);
              data[i*3+2] = powf(data[i*3+2], power);
            }*/

            dst.CreateCopy(&src);
            filter.Apply(&dst, &src);

            std::stringstream fileName3;  fileName3.precision(6);
            fileName3 << "hydra_" << path_tracing_time << "_tm.png";
            dst.Save(fileName3.str());

            std::cerr << "tone mapped image saved" << std::endl;
            if(!input.saveImageNow)
            {
              input.saveImageNow = false;
              imageSaved = true;
              stopCountTime = true;
            }

            delete [] hdrImageData;
          }
        }
      }
    }
    else if (input.relightEnabled)
    {
        pReLightApp->DoRendering("out_relight_data");
        input.relightEnabled = false;
        exit(0);
    }
    else
    {
      pathTracingFinished = false;
      firstPass = true;
      FPS = 60;
      path_tracing_time = 0.0f;
      stopCountTime = false;

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if (pathTracer!=0)
        pathTracer->ResetPathTracing();
      imageSaved = false;

      pRender->BeginDrawScene(renderState); 

      OpenGL_Render* pCGE = dynamic_cast<OpenGL_Render*>(pRender);
      if(pCGE!=0)
      {
        //pCGE->SetDebugDrawIndex(input.m_debugIndex);
        
        //DrawDebugBoxes("boxes0.txt");
        //DrawDebugBoxesLayered("boxes", 6);
        DrawDebugSpheres("rc_spheres.txt");

        //DrawDebugPoints("points2.txt");
        //DrawDebugSphereBox();
        //DrawDebugTreeData3();
        //DrawDebugSpheres2("spheres", 20);
        //DebugDrawRays("debugRaysPos.txt", "debugRaysDir.txt", "debugRaysColor.txt");
      }

	    pRender->EndDrawScene();

    }

		glutSwapBuffers();
		input.reset();
	}
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
	
	// -----------------------  �������� �������� FPS. -----------------------
  FramesCount++;
	if(FramesCount > 1)
	{
    FPS = float(FramesCount)/(timer.getElapsed());
		FramesCount=0;
    timer.start();

    char Title[64];

    if(!input.pathTracingEnabled)
      sprintf(Title, "FPS=%.1f", FPS);
    else if (!pathTracingFinished)
      sprintf(Title, "path tracing: %.2f sec", path_tracing_time);
    else
      sprintf(Title, "path tracing: %.2f sec, finished!", path_tracing_time);

    glutSetWindowTitle(Title);

	}
 
	//\\ -----------------------  �������� �������� FPS. -----------------------
}


void Mouse(int button, int state, int x, int y) { input.Mouse(button,state,x,y); }
void MouseMotion(int x, int y) { input.MouseMotion(x,y); }
void Reshape(int Width,int Height) {  }               //��������� ��������� �������� ����
void Keyboard(unsigned char key,int x,int y){ input.Keyboard(key,x,y); }   //�����
void KeyboardSpecial(int key, int x, int y) { input.KeyboardSpecial(key,x,y);  }   // ���� �����
void Mouse(int button, int state, int x, int y); //��������� ������� ����
void Idle() { glutPostRedisplay(); } 

int main(int argc, char** argv)
{
  HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(h, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
  
  if(argc > 1)
  {
    input.inColladaFile = argv[1];
    
    if(argc>2)
      input.inColladaProfile = argv[2];

    if(argc>3)
      input.ReadXMLFromFile(argv[3]);

    for(int i=0;i<argc;i++)
      std::cout << "agrv[" << i << "] = " << argv[i] << std::endl;
  }
  
  input.ReadXMLFromSharedMemory();

  WinWidth  = input.ext_width;
  WinHeight = input.ext_height;

  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
	glutInitWindowSize(WinWidth,WinHeight);
	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)-WinWidth)/2, (glutGet(GLUT_SCREEN_HEIGHT)-WinHeight)/2);
	glutCreateWindow("NO FATE");
	
	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(KeyboardSpecial);
	glutReshapeFunc(Reshape);
	glutMouseFunc(Mouse);
	glutMotionFunc(MouseMotion);
	glutIdleFunc(Idle);
	
  glewInit();
  InitOpenIL();

	Init();
  atexit(ShutDown);
			
	glutMainLoop();
}


