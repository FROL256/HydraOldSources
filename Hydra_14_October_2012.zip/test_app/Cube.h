#pragma once

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "SimpleMesh.h"

using namespace MGML;

struct Cube : SimpleMesh
{
	Cube(){}
	Cube(const Matrix4x4f& matrix,
		 float size,
		 unsigned char text_id,
		 int mat_id, float wrap = 1.0f);

	const Vertex4f*		GetVertices() const {return vert;}
	const unsigned int* GetIndices() const  {return indices;}
  void InvertNormals();

protected:
	Vertex4f	 vert[4*6];
	unsigned int indices[6*6];
};