#include "Input.h"
#include "Camera.h"

extern Camera* cam;

Input::Input() 
{
  exit_status = false;
	trace_depth = 1;
	shadows = false;
  AA = 1;
  tree_level_visible = 0;
  rayPos.set(-5,5,-5);
  rayRot.set(0,0,0);
  drawAllGrid = false;
  pathTracingEnabled = false;
  animateLight = false;
  computeIrradianceCache = false;
  irradianceCacheCalculated   = false;
  indirrectIllum = false;
  relightEnabled = false;
  saveImageNow = false;
  icWSErrorTreshold = 2.5f;
  diffuse_trace_depth = 2;
  voxelizeNow  = false;
  useFiltering = false;
  rcType = 0;

  drawIrradianceCachePixelPoints = false;

  m_debugPos = float3(-2,0,0);

  //accelStructConstructionMode = BVH_CONSTRUCT_VERY_FAST;
  //accelStructConstructionMode = BVH_CONSTRUCT_FAST;
  accelStructConstructionMode = BVH_CONSTRUCT_QUALITY;
  //accelStructConstructionMode = KD_TREE_CONSTRUCT_FAST;
  //accelStructConstructionMode = KD_TREE_CONSTRUCT_QUALITY;

  m_debugIndex = 0;
  debugLayerDraw = 0;
  m_sharedMemoryHandle = OpenFileMappingA( FILE_MAP_READ, false, "RTE_benchmark_shmem" );

  inColladaFile = "";
  this->ext_width  = 1280;
  this->ext_height = 1024;
  //animateLight = true;
  //this->trace_depth = 3;
  //this->shadows = true;
  //this->pathTracingEnabled = true;
  //this->indirrectIllum = true;
  pt_params.minRaysPerPixel = 8;
  pt_params.maxRaysPerPixel = 1000;
  pt_params.qualityTreshold = 0.01f;
  pt_params.useHDRQualityEstimation = true;
  pt_params.useLoyalEstimateFunction = true;
  pt_params.loaylEstimateFunctionTresholdInRays = 200;
  pt_params.drawBlocks = false;
  pt_params.drawRaysStatInfo = true;

  pt_params.enableDOF = false;
  pt_params.dofLensRadius = 0.05f;
  pt_params.dofFocalPlaneDist = 8.0f;
  inputXML = NULL;

  hdrStrength = 8.0f;
  hdrPhi = 16.0f;
  hdrGamma = 2.2;
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::SetCameraForTestPerf(std::string scene_name, int cam_number)
{
  if(scene_name == "Conference Room")
  {
    cam_rot.set(20,65,0,1); // conf room, position 1
    cam->pos = float4(-35,2,14,1);
  }
}


//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::ReadXMLFromFile(const std::string& fileName)
{
  TiXmlDocument doc(fileName);

  if(doc.ErrorDesc() != NULL)
  {
    std::cerr << "xml read error: " << doc.ErrorDesc() << std::endl;
    return;
  }

  ReadXMLFromDoc(doc);
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::ReadXMLFromSharedMemory()
{
  static bool first = true;

  if(first)
  {
    inputXML = (const char *)MapViewOfFile (m_sharedMemoryHandle, FILE_MAP_READ, 0, 0, 0);
    first = false;
  }

  if(inputXML == 0)
    return;

  try
  {
    TiXmlDocument doc;
    doc.Parse(inputXML,0,TIXML_ENCODING_UTF8);
    ReadXMLFromDoc(doc);
  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
  
}


//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::ReadXMLFromDoc(TiXmlDocument& doc)
{
  TiXmlHandle docHandle(&doc);
  TiXmlElement* node;
  std::string text;

  node = docHandle.FirstChild( "resolution" ).Element();
  if (!node)
    throw std::runtime_error("Incorrect XML structure: resolution");
  std::string res_text = node->GetText();

  if (res_text == "512x512")
  {
    ext_width = 512;
    ext_height = 512;
  }
  else if (res_text == "640x480")
  {
    ext_width = 640;
    ext_height = 480;
  }
  else if (res_text == "1024x768")
  {
    ext_width = 1024;
    ext_height = 768;
  }
  else if (res_text == "1024x1024")
  {
    ext_width = 1024;
    ext_height = 1024;
  }
  else if (res_text == "1280x1024")
  {
    ext_width = 1280;
    ext_height = 1024;
  }
  else if (res_text == "1600x1200")
  {
    ext_width = 1600;
    ext_height = 1200;
  }
  else if (res_text == "1920x1200")
  {
    ext_width = 1920;
    ext_height = 1200;
  }
  else
  {
    ext_width = 1024;
    ext_height = 768;
    std::cout << "unknown resolution, default 1024x768 selected" << std::endl;
  }

  //const char* debugText = docHandle.FirstChild("kd_tree_mode").Element()->GetText();

  node = docHandle.FirstChild( "kd_tree_mode" ).Element();
  if(node != NULL)
  {
    std::string method = node->GetText();
    if(method == string("fast"))
      accelStructConstructionMode = BVH_CONSTRUCT_VERY_FAST;
    else if(method == string("medium"))
      accelStructConstructionMode = BVH_CONSTRUCT_FAST;
    else
      accelStructConstructionMode = BVH_CONSTRUCT_QUALITY;
  }

  node = docHandle.FirstChild( "scene" ).Element();
  if (!node)
    throw std::runtime_error("Incorrect XML structure: scene");
  this->ext_scene = node->GetText();

  node = docHandle.FirstChild( "renderer_type" ).Element();
  if (!node)
    throw std::runtime_error("Incorrect XML structure: renderer_type");
  this->ext_renderer = node->GetText();

  node = docHandle.FirstChild( "shadows" ).Element();
  if (!node)
    throw std::runtime_error("Incorrect XML structure: shadows");
  this->shadows = (bool)atoi(node->GetText());


  node = docHandle.FirstChild( "trace_depth" ).Element();
  if(node)
    this->trace_depth = atoi(node->GetText());
  
  node = docHandle.FirstChild( "diff_trace_depth" ).Element();
  if(node)
    diffuse_trace_depth = atoi(node->GetText());

  indirrectIllum = (diffuse_trace_depth > 0);


  node = docHandle.FirstChild( "anti_aliasing" ).Element();
  if (!node)
    throw std::runtime_error("Incorrect XML structure: anti_aliasing");
  std::string aa_text  = node->GetText();
  if (aa_text == "AA: 1x")
    this->AA = 1;
  else if(aa_text == "AA: 4x")
    this->AA = 4;
  else if(aa_text == "AA: 16x")
    this->AA = 16;
  else if(aa_text == "AA: 64x")
    this->AA = 64;

  node = docHandle.FirstChild( "path_tracing" ).Element();
  if (!node)
    RUN_TIME_ERROR("Incorrect XML structure: path_tracing");
  this->pathTracingEnabled = (bool)atoi(node->GetText());

  node = docHandle.FirstChild( "relight" ).Element();
  if (!node)
    RUN_TIME_ERROR("Incorrect XML structure: relight");

  std::string reLighEnable = node->GetText();
  this->relightEnabled = (bool)atoi(node->GetText());

  node = docHandle.FirstChild("computeIrradianceCache").Element();
  if(node)
    computeIrradianceCache = atoi(node->GetText());

  // path tracing params
  //
  node = docHandle.FirstChild("minRaysPerPixel").Element();
  if(node)
    pt_params.minRaysPerPixel = atoi(node->GetText());

  node = docHandle.FirstChild("maxRaysPerPixel").Element();
  if(node)
    pt_params.maxRaysPerPixel = atoi(node->GetText());

  node = docHandle.FirstChild("qualityTreshold").Element();
  if(node)
    pt_params.qualityTreshold = atof(node->GetText());

  node = docHandle.FirstChild("useHDRQualityEstimation").Element();
  if(node)
    pt_params.useHDRQualityEstimation = bool(atoi(node->GetText()));

  node = docHandle.FirstChild("useLoyalEstimateFunction").Element();
  if(node)
    pt_params.useLoyalEstimateFunction = bool(atoi(node->GetText()));

  node = docHandle.FirstChild("drawBlocks").Element();
  if(node)
    pt_params.drawBlocks = bool(atoi(node->GetText()));

  node = docHandle.FirstChild("drawRaysStatInfo").Element();
  if(node)
    pt_params.drawRaysStatInfo = bool(atoi(node->GetText()));

  node = docHandle.FirstChild("enableDOF").Element();
  if(node)
    pt_params.enableDOF = bool(atoi(node->GetText()));

  node = docHandle.FirstChild("dofLensRadius").Element();
  if(node)
    pt_params.dofLensRadius = atof(node->GetText());

  node = docHandle.FirstChild("dofFocalPlaneDist").Element();
  if(node)
    pt_params.dofFocalPlaneDist = atof(node->GetText());

  node = docHandle.FirstChild("loaylEstimateFunctionTresholdInRays").Element();
  if(node)
    pt_params.loaylEstimateFunctionTresholdInRays = atoi(node->GetText());

  node = docHandle.FirstChild("colladaProfile2").Element();
  if(node)
    if(node->GetText() != NULL)
      inColladaProfile = node->GetText();

  node = docHandle.FirstChild("hdr_strength").Element();
  if(node)
    hdrStrength = atof(node->GetText());

  node = docHandle.FirstChild("hdr_phi").Element();
  if(node)
    hdrPhi = atof(node->GetText());

  node = docHandle.FirstChild("save_image").Element();
  if(node)
    saveImageNow = bool(atoi(node->GetText()));

  node = docHandle.FirstChild("icWorldSpaceErrorTreshold").Element();
  if(node)
    icWSErrorTreshold = atof(node->GetText());

  node = docHandle.FirstChild("freeIrradianceCache").Element();
  if(node)
    freeIrradianceCache  = bool(atoi(node->GetText()));

}


//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::Mouse(int button, int state, int x, int y) //��������� ������� ����
{
	if (button==GLUT_LEFT_BUTTON)		//����� ������
	{
		switch (state)
		{
			case GLUT_DOWN:		//���� ������
				ldown=true;		//���������� ����
				mx=x;			//��������� ����������
				my=y;
				break;
			case GLUT_UP:
				ldown=false;
				break;
		}
	}
	if (button==GLUT_RIGHT_BUTTON)	//������ ������
	{
		switch (state)
		{
			case GLUT_DOWN:
				rdown=true;
				mx=x;
				my=y;
				break;
			case GLUT_UP:
				rdown=false;
				break;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::MouseMotion(int x, int y)                  //����������� ����
{
  if(ldown)		// ����� ������
	{
		cam_rot.M[0]+=0.1*(y-my);	//��������� ����� ��������
		cam_rot.M[1]+=0.1*(x-mx);
		mx=x;
		my=y;
	}
	if (rdown)	//������
	{
//		global_translate.M[0]+=0.01*(x-mx);	//����������� ����� �������� ���������
//		if (tt)
//			global_translate.M[2]+=0.01*(y-my);
//		else
//			global_translate.M[1]+=0.01*(my-y);
		mx=x;
		my=y;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::Keyboard(unsigned char key, int x, int y)
{

	switch(key)
	{
	case VK_ESCAPE:
		exit_status = true;
	break;
	
	case 'q':
	case 'Q':
		cam_rot.z -= 10.0f;
	break;
		
	case 'e':
	case 'E':
		cam_rot.z += 10.0f;
	break;

	case 'w':
	case 'W':
		cam_mov.z = -0.1f;
	break;
	
	case 's':
	case 'S':
		cam_mov.z = 0.1f;
	break;

	case 'a':
	case 'A':
		cam_mov.x = -0.1f;
	break;

	case 'd':
	case 'D':
		cam_mov.x = 0.1f;
	break;

	case 'r':
		cam_mov.y = 0.1f;
    break;

  case 'R':
    computeRadianceCache = !computeRadianceCache;
	  break;

	case 'f':
		cam_mov.y = -0.1f;
	break;

  case 'F':
    useFiltering = !useFiltering;
  break;

  case 'p':
    pathTracingEnabled = !pathTracingEnabled;
  break;

  case 'P':
    tracePhotonsDebug = !tracePhotonsDebug;
    break;

  case 'o':
  case 'O':
    relightEnabled = !relightEnabled;
    break;
   
  case 'I':
  case 'i':
    computeIrradianceCache = !computeIrradianceCache;
    break;

  case 'C':
  case 'c':
    indirrectIllum = !indirrectIllum;
    break;

	case '1':
		trace_depth=1;
	break;

  case '!':
    rcType = 0;
  break;

	case '2':
		trace_depth=2;
	break;

  case '@':
    rcType = 1;
  break;


	case '3':
		trace_depth=3;
	break;

	case '4':
		trace_depth=4;
	break;

	case '5':
		trace_depth=5;
	break;

  case '6':
		trace_depth=6;
	break;

  case '7':
		trace_depth=7;
	break;

  case '8':
		trace_depth=8;
	break;

  case '9':
		trace_depth=9;
	break;

	case 'Z':
	case 'z':
		shadows=!shadows;
	break;

  case 'G':
	case 'g':
		AA = 1;
	break;

  case 'H':
	case 'h':
		AA = 4;
	break;

  case 'J':
	case 'j':
		AA = 16;
	break;

  case 'K':
	case 'k':
		AA = 64;
	break;

  case '{':
  case '[':
    m_debugIndex--;
  break;

  case '}':
  case ']':
    m_debugIndex++;
    if(m_debugIndex<0)
      m_debugIndex=0;
    break;

  case '>':
  case '.':
    m_debugPos.x += 0.025f;
    break;
  
  case '<':
  case ',':
    m_debugPos.x -= 0.025f;
    break;

  case 'M':
  case 'm':
    drawBlocks = !drawBlocks;
    m_debugPos.y += 0.025f;
    break;

  case 'N':
  case 'n':
    drawRayStatInfo = !drawRayStatInfo;
    m_debugPos.y -= 0.025f;
    break;

  case 'V':
    voxelizeNow = true;
    break;

  case 'v':
    m_debugPos.z += 0.025f;
    break;

  case 'B':
  case 'b':
    drawIrradianceCachePixelPoints = !drawIrradianceCachePixelPoints;
    m_debugPos.z -= 0.025f;
    break;

  case '+':
    debugLayerDraw++;
    break;

  case '-':
    debugLayerDraw--;
    break;


  case 'T':
    debugViewSHReconstructed = !debugViewSHReconstructed;
    break;

	}

}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::KeyboardSpecial(int key, int x, int y)
{

}


