#include "Cube.h"

Cube::Cube(const Matrix4x4f& matrix, float size, unsigned char text_id, int mat_id, float wrap)
{

	// here we set materials and textures
	for(int i=0;i<24;i++)
	{
		vert[i].material_id = mat_id;
		//vert[i].texture_id[0]  = text_id;
	}

	// then not forget about texture coordinates
	for(int i=0;i<24;i+=4)
	{
		vert[i+0].t.set(0,0);
		vert[i+1].t.set(0,1*wrap);	
		vert[i+2].t.set(1*wrap,1*wrap);
		vert[i+3].t.set(1*wrap,0);
	}

	// geomenty of cube
	float a = size/2;
	vert[0].pos.set(-a,-a,-a,1);
	vert[1].pos.set(-a,a,-a,1);  	
	vert[2].pos.set(a,a,-a,1);  
	vert[3].pos.set(a,-a,-a,1);
	for(int i=0;i<4;i++)
		vert[i+0].norm.set(0,0,-1,0);

	vert[4].pos.set(-a,-a,a,1); 
	vert[5].pos.set(-a,a,a,1);  
	vert[6].pos.set(a,a,a,1);   
	vert[7].pos.set(a,-a,a,1);  
	for(int i=0;i<4;i++)
		vert[i+4].norm.set(0,0,1,0);

	vert[8].pos.set(-a,-a,-a,1); 
	vert[9].pos.set(-a,-a,a,1);  
	vert[10].pos.set(-a,a,a,1);   
	vert[11].pos.set(-a,a,-a,1);  
	for(int i=0;i<4;i++)
		vert[i+8].norm.set(-1,0,0,0);

	vert[12].pos.set(a,-a,-a,1); 
	vert[13].pos.set(a,-a,a,1);  
	vert[14].pos.set(a,a,a,1);   
	vert[15].pos.set(a,a,-a,1);  
	for(int i=0;i<4;i++)
		vert[i+12].norm.set(1,0,0,0);

	vert[16].pos.set(-a,-a,-a,1); 
	vert[17].pos.set(-a,-a,a,1);  
	vert[18].pos.set(a,-a,a,1);   
	vert[19].pos.set(a,-a,-a,1); 
	for(int i=0;i<4;i++)
		vert[i+16].norm.set(0,-1,0,0);

	vert[20].pos.set(-a,a,-a,1); 
	vert[21].pos.set(-a,a,a,1);  
	vert[22].pos.set(a,a,a,1);   
	vert[23].pos.set(a,a,-a,1); 
	for(int i=0;i<4;i++)
		vert[i+20].norm.set(0,1,0,0);

	// transform geometry with matrix
	for(int i=0;i<24;i++)
	{
		vert[i].pos = matrix*vert[i].pos;
		vert[i].norm = matrix*vert[i].norm;
		vert[i].norm.Normalize();
	}


	// set indices of verts that form triangles
	for(int i=0,j=0;i<36;i+=6,j+=4)
	{
		indices[i+0] = j+0;
		indices[i+1] = j+1;
		indices[i+2] = j+2;

		indices[i+3] = j+0;
		indices[i+4] = j+2;
		indices[i+5] = j+3;
	}

}


void Cube::InvertNormals()
{
	for(int i=0;i<24;i++)
	{
		vert[i].norm *= (-1);
  }
}