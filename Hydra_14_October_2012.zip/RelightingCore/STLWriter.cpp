#include "STLWriter.h"

bool STLWriter::Init(std::string& filename)
{
	fout.open(filename.c_str(), std::ios::out | std::ios::binary);
    if(!fout.is_open())
      return false;
	return true;
}

bool STLWriter::Close()
{
	fout.close();
	return true;
}

bool STLWriter::SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight)
{
	fout.write((char*)in_fpImage, 4*in_iWidth*in_iHeight*sizeof(float));
	return true;
}


