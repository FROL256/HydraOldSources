#include <string>
#include <vector>

class Parser
{
public:

	bool parseFile(const char * filename);

	int getType();
	int getImageWidth();
	int getImageHeight();
	void getOutputFile(std::string& output);
	void getInputFiles(std::vector<std::string>& input);
	void getLightCoeffs(std::vector<float>& coeffs);

private:

	int m_type;
	int m_width;
	int m_height;
	std::string m_output;
	std::vector<std::string> m_input;
	std::vector<float> m_coeffs;
};