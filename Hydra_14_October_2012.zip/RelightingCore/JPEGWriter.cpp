/*
#include "JPEGWriter.h"
#include "gmlsimpleimage.h"
#include "gmlsimpleimageloader.h"

bool JPEGWriter::Init(std::string& filename)
{
	m_fileName=filename;
	return true;
}

bool JPEGWriter::Close()
{
	return true;
}

bool JPEGWriter::SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight)
{
	gml::SimpleImage image;
	image.Create(in_iWidth,in_iHeight,gml::Image::F_RGB,gml::Image::R_BYTE);
	unsigned char * data=image.GetRawData();
	int bpl=image.GetBytesPerLine();
	for (int i=0; i<in_iWidth; i++)
		for (int j=0; j<in_iHeight; j++)
		{
			data[3*i+j*bpl]=(int)std::min(255.0f,255*in_fpImage[4*i+j*4*in_iWidth]);
			data[3*i+j*bpl+1]=(int)std::min(255.0f,255*in_fpImage[4*i+j*4*in_iWidth+1]);
			data[3*i+j*bpl+2]=(int)std::min(255.0f,255*in_fpImage[4*i+j*4*in_iWidth+2]);
		}
	gml::SimpleImageLoader loader;
	loader.SaveBitMap(m_fileName,image);
	return true;
}


  */