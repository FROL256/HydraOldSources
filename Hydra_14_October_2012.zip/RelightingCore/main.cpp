#include "STLReader.h"
#include "STLWriter.h"
#include <vector>
#include "relighter.h"
#include <Windows.h>
#include "parser.h"

#define TOTAL_NUMBER 20

int main(int argc, char **argv)
{
	DWORD t = GetTickCount();
	Parser p;
	if (argc < 2 || !p.parseFile(argv[1]))
	{
		printf("failed to load xml\n");
		return -1;
	}

	//get exe path
	std::string exepath;
#ifndef _WIN32_WCE
	char buffer[500];
#else
	wchar_t buffer[500];
#endif
	if (GetModuleFileName(NULL, buffer, 500) == 0)
		return false;
#ifndef _WIN32_WCE
	exepath = buffer;
#else
	exepath = ;//here to do for unicode
#endif

	int pos = exepath.find_last_of("\\");
	std::string dir = exepath;
	dir.resize(pos + 1);

	int w, h, lightCount;
	w = p.getImageWidth();
	h = p.getImageHeight();
	std::vector<std::string> files;
	std::vector<float> coeffs;
	p.getInputFiles(files);
	p.getLightCoeffs(coeffs);
	lightCount = files.size();
	
	float * image = new float [4 * w * h * TOTAL_NUMBER];
	float * lights = new float [3 * TOTAL_NUMBER];

	float * output;

	Relighter relighter(w, h, TOTAL_NUMBER);

	if (p.getType() == 1)  //update
	{
		//set current image
		relighter.GetResultingImage(&output);
		STLReader reader;
		std::string outputFile;
		p.getOutputFile(outputFile);
		reader.Init(dir + outputFile);
		reader.SerializeFloatImage(output, w, h);
		reader.Close();
	}

	for (int i=0; i<lightCount; i++)
	{
		int j = i % TOTAL_NUMBER;
		lights[3 * j + 0] = coeffs[3 * i];
		lights[3 * j + 1] = coeffs[3 * i + 1];
		lights[3 * j + 2] = coeffs[3 * i + 2];
		
		STLReader reader;
		reader.Init(dir + files[i]);
		reader.SerializeFloatImage((float*)(image + j * w * h * 4), w, h);
		reader.Close();

		if (j == TOTAL_NUMBER - 1)
			relighter.Relight(image, lights, TOTAL_NUMBER, w, h);
		//relighter.AddImageForRelight(image, lights);
	}

	relighter.Relight(image, lights, lightCount % TOTAL_NUMBER, w, h);
	relighter.GetResultingImage(&output);

	STLWriter writer;
	std::string outputFile;
	p.getOutputFile(outputFile);
	writer.Init(dir + outputFile);
	writer.SerializeFloatImage(output,w,h);
	writer.Close();
	
	delete [] lights;
	delete [] image;
	printf("Finished in: %d\n", GetTickCount() - t);
}