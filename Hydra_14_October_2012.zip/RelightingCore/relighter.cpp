#include "relighter.h"
#include <string.h>
#include <Windows.h>
#include <stdio.h>

bool Relighter::Relight(float * in_fpInputImages, float * in_fpLights,int in_iImageCount, 
		int in_iWidth, int in_iHeight)
{
	if (in_iImageCount <= 0) 
		return false;

	float light[3] = {1.0f, 1.0f, 1.0f};

	cublasStatus cb_status;

	//for each channel
	for (int i=0; i<3; i++)
	{
			cb_status = cublasSetVector(in_iWidth*in_iHeight*in_iImageCount, sizeof(float), in_fpInputImages+i, 4, m_gpuImage, 1);
			cb_status = cublasSetVector(m_width * m_height, sizeof(float), m_currentImage + i, 4, m_gpuImage + m_width * m_height * in_iImageCount, 1);
			cb_status = cublasSetVector(in_iImageCount, sizeof(float), in_fpLights + i, 3, m_gpuLights, 1);
			cb_status = cublasSetVector(1, sizeof(float), light + i, 3, m_gpuLights + in_iImageCount, 1);
			cublasSgemm('n', 'n', in_iWidth*in_iHeight, 1, in_iImageCount + 1, 1, m_gpuImage, in_iWidth*in_iHeight, m_gpuLights, in_iImageCount + 1, 0, m_gpuRes, in_iWidth*in_iHeight);
			cb_status = cublasGetError ();
			cb_status = cublasGetVector(in_iWidth*in_iHeight, sizeof(float), m_gpuRes, 1, m_currentImage + i, 4);
	}

	return true;
}

//not used
/*
bool Relighter::AddImageForRelight(float * in_fpInputImage, float * in_fpLight)
{
	float lights[2 * 3];

	lights[0] = in_fpLight[0];
	lights[1] = in_fpLight[1];
	lights[2] = in_fpLight[2];

	lights[3] = 1.0f;
	lights[4] = 1.0f;
	lights[5] = 1.0f;

	cublasStatus cb_status;

	//for each channel
	for (int i=0; i<3; i++)
	{
		cb_status = cublasSetVector(m_width * m_height, sizeof(float), in_fpInputImage + i, 4, m_gpuImage, 1);
		cb_status = cublasSetVector(m_width * m_height, sizeof(float), m_currentImage + i, 4, m_gpuImage + m_width * m_height, 1);
		cb_status = cublasSetVector(2, sizeof(float), lights + i, 3, m_gpuLights, 1);
		cublasSgemm('n', 'n', m_width*m_height, 1, 2, 1, m_gpuImage, m_width*m_height, m_gpuLights, 2, 0, m_gpuRes, m_width * m_height);
		cb_status = cublasGetError ();
		cb_status = cublasGetVector(m_width * m_height, sizeof(float), m_gpuRes, 1, m_currentImage + i, 4);
	}

	return true;

}
  */

bool Relighter::initCuda()
{
	culaStatus cl_status;
	cublasStatus cb_status;

	//cl_status = culaInitialize();
    //if (!checkStatus(cl_status)) return false;
	cb_status = cublasInit();

  //  checkStatus(cb_status);
	return true;
}

void Relighter::shutdownCuda()
{
	//culaShutdown();
	cublasShutdown();
}

/* Check for errors and exit if one occurred */
bool Relighter::checkStatus(culaStatus status)
{
    char buf[80];

    if(!status)
        return true;

    culaGetErrorInfoString(status, culaGetErrorInfo(), buf, sizeof(buf));
    //printf("%s\n", buf);

	shutdownCuda();
	return false;
}

bool Relighter::ResetAll( int in_iWidth, int in_iHeight, int imageCount )
{
   m_width = in_iWidth;
   m_height = in_iHeight;

   imageAdded = false;

   if (m_width <= 0 || m_height <= 0)
	   return false;

   if (m_currentImage)
	   delete [] m_currentImage;

   if (m_gpuLights)
   {
	   cublasFree(m_gpuImage);
	   cublasFree(m_gpuLights);
	   cublasFree(m_gpuRes);

	   shutdownCuda();
   }


   m_currentImage = new float [4 * m_width * m_height];

   if (!m_currentImage)
	   return false;

   memset(m_currentImage, 0, 4 * m_width * m_height * sizeof(float));
  
   if (!initCuda()) return false;

   cublasStatus cb_status;

   cb_status = cublasAlloc(m_width * m_height * (imageCount + 1), sizeof(float), (void**)&m_gpuImage);
   cb_status = cublasAlloc(imageCount + 1, sizeof(float), (void**)&m_gpuLights);
   cb_status = cublasAlloc(m_width * m_height, sizeof(float), (void**)&m_gpuRes);


  
   return true;
}

Relighter::Relighter( int in_iWidth, int in_iHeight, int imageCount) : m_currentImage(NULL), m_gpuImage(NULL), m_gpuRes(NULL), m_gpuLights(NULL)
{
	ResetAll(in_iWidth, in_iHeight, imageCount);
}

bool Relighter::GetResultingImage( float ** in_fpOutputImage )
{
	*in_fpOutputImage = m_currentImage;
	return true;
}

Relighter::~Relighter()
{
	if (m_currentImage)
		delete [] m_currentImage;

	if (m_gpuLights)
	{
		cublasFree(m_gpuImage);
		cublasFree(m_gpuLights);
		cublasFree(m_gpuRes);

		shutdownCuda();
	}
}