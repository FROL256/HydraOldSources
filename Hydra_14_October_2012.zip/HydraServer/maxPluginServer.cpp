#include "maxPluginServer.h"
#include "ImportVrscene.h"

#include <boost/archive/binary_iarchive.hpp>

#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

#define HEADER_COLLADA 100
#define HEADER_TEXTURE 101
#define SCENE_FILE 200
#define CONFIG_FILE 201
#define READ_COLLADA 202
#define READ_TEXTURE 203
#define READ_NEXT 204



float3 ComputeSmGroupNormal(std::vector <int> faceIndeces, int faceNum, const std::vector<int> &face_smoothgroups, int vertNum, float *face_normals)
{
  float3 v(0,0,0);
  int counter = 0;

  float3 faceNorm;
  faceNorm.x = face_normals[faceNum*3 + 0];
  faceNorm.y = face_normals[faceNum*3 + 1];
  faceNorm.z = face_normals[faceNum*3 + 2];

  v = faceNorm;

  for(int i = 0; i < faceIndeces.size(); i++)
  {
    float3 norm;
    norm.x = face_normals[faceIndeces[i]*3 + 0];
    norm.y = face_normals[faceIndeces[i]*3 + 1];
    norm.z = face_normals[faceIndeces[i]*3 + 2];

    if(face_smoothgroups[faceNum] == face_smoothgroups[faceIndeces[i]]) 
    {

      v.x += norm.x;
      v.y += norm.y;
      v.z += norm.z;
      counter++;
    }

  }
  v = v/counter;
  return normalize(v);
}

void ComputeVertexFaceIndeces(const GeometryObj &mesh, std::map<int, std::vector < int > > &vertexFaceIndeces)
{

  for (int i = 0; i < mesh.n_faces; i++) 
  {

    int index1 = mesh.pos_indeces[i*3+0];
    int index2 = mesh.pos_indeces[i*3+1];
    int index3 = mesh.pos_indeces[i*3+2];

      
    vertexFaceIndeces[index1].push_back(i);
    vertexFaceIndeces[index2].push_back(i);
    vertexFaceIndeces[index3].push_back(i);
  }
}


void ComputeBBox(const std::vector<GeometryObj> &geometry, const std::vector<SphereObj> &spheres, Matrix4x4f* res)
{
  Matrix4x4f &m = *res;

  float4 p_min = float4(geometry[0].bbox[0],geometry[0].bbox[1],geometry[0].bbox[2],1);
  float4 p_max = float4(geometry[0].bbox[3],geometry[0].bbox[4],geometry[0].bbox[5],1);

  struct s_bbox
  {
    float bbox[6];
  };

  vector<s_bbox> bboxes;

  for(vector<GeometryObj>::const_iterator geom = geometry.begin(); geom != geometry.end(); ++geom)
  {
    if(geom->positions.size()!=0)
    {
      s_bbox box;
      box.bbox[0] = geom->bbox[0];
      box.bbox[1] = geom->bbox[1];
      box.bbox[2] = geom->bbox[2];
      box.bbox[3] = geom->bbox[3];
      box.bbox[4] = geom->bbox[4];
      box.bbox[5] = geom->bbox[5];

      bboxes.push_back(box);
    }
  }
  for(vector<SphereObj>::const_iterator sph = spheres.begin(); sph != spheres.end(); ++sph)
  {
    s_bbox box;
    box.bbox[0] = sph->bbox[0];
    box.bbox[1] = sph->bbox[1];
    box.bbox[2] = sph->bbox[2];
    box.bbox[3] = sph->bbox[3];
    box.bbox[4] = sph->bbox[4];
    box.bbox[5] = sph->bbox[5];

    bboxes.push_back(box);
  }

  for(vector<s_bbox>::const_iterator bb = bboxes.begin(); bb != bboxes.end(); ++bb)
	{
    if ( bb->bbox[0] < p_min.x ) p_min.x = bb->bbox[0];
    if ( bb->bbox[1] < p_min.y ) p_min.y = bb->bbox[1];
    if ( bb->bbox[2] < p_min.z ) p_min.z = bb->bbox[2];

    if ( bb->bbox[3] > p_max.x ) p_max.x = bb->bbox[3];
    if ( bb->bbox[4] > p_max.y ) p_max.y = bb->bbox[4];
    if ( bb->bbox[5] > p_max.z ) p_max.z = bb->bbox[5];
  }

  float sizeX = p_max.x - p_min.x;
  float sizeY = p_max.y - p_min.y;
  float sizeZ = p_max.z - p_min.z;

  AABB4f box(p_min, p_max);
  float4 center = box.center(); center.w = 1.0f;

  Matrix4x4f mTranslate, mRotate, mScale;

  mTranslate.SetTranslate(-1.0f*center);

  float maxSize = sizeX;

  if(sizeY > maxSize) maxSize = sizeY;
  if(sizeZ > maxSize) maxSize = sizeZ;


  mScale.SetScale(float3((1.0f/maxSize)*3, (1.0f/maxSize)*3, (1.0f/maxSize)*3));

  mRotate = Matrix4x4f( 1,0,0,0,
                        0,0,1,0,
                        0,-1,0,0,
                        0,0,0,1);

  

  m = mRotate*mScale*mTranslate;
}



int LoadDump(std::string name)
{
	std::ifstream is;
	is.open(name.c_str());
	if (!is)
		return 1;
	boost::archive::binary_iarchive ar( is );

	std::vector<GeometryObj> geometry;
	std::vector<MaterialObj> materials;
	std::vector<LightObj> lights;
	SceneTree* tree;

	ar & geometry;
	ar & materials;
	ar & lights;
	ar & tree;

	return 0;
}


void LoadGeometry(IGraphicsEngine* pRender, const std::vector<GeometryObj> &geometry,
                  const std::vector<SphereObj> &spheres, std::map<int, int> &materialIDs, int mat_size)
{ 

  Matrix4x4f m_externTransform;
  Matrix4x4f mScale;
  mScale.SetScale(float3(10,10,10));

  ComputeBBox(geometry, spheres, &m_externTransform);

  m_externTransform = mScale*m_externTransform;

  LoadSpheres(pRender, spheres, m_externTransform);

  int geom_obj = 0;

	for(vector<GeometryObj>::const_iterator geom = geometry.begin(); geom != geometry.end(); ++geom)
	{
    if(geom->positions.size()!=0)
    {

      std::map <int, std::vector <int> > vertexFaceIndeces;
      float *face_normals;
      face_normals = new float[geom->n_faces*3];

      ComputeVertexFaceIndeces(geometry[geom_obj], vertexFaceIndeces);

 		  int N_vertices = geom->n_faces*3;
		  int N_indices = geom->n_faces*3;

		  Vertex4f* v = new Vertex4f[N_vertices];
		  uint* indices = new uint[N_indices];

		  Matrix4x4f mTransform;

		  mTransform = Matrix4x4f(geom->m[0], geom->m[1], geom->m[2], geom->m[3],
					                     geom->m[4], geom->m[5], geom->m[6], geom->m[7],
					                     geom->m[8], geom->m[9], geom->m[10], geom->m[11],
					                     geom->m[12], geom->m[13], geom->m[14], geom->m[15]);

      mTransform.Transpose();


		  for(int i=0; i<geom->n_faces; i++)
		  {
			  int index1 = geom->pos_indeces[i*3+0];
			  int index2 = geom->pos_indeces[i*3+1];
			  int index3 = geom->pos_indeces[i*3+2];

        float4 v1Pos = float4(geom->positions[index1*3], geom->positions[index1*3+1], geom->positions[index1*3+2], 1);
        float4 v2Pos = float4(geom->positions[index2*3], geom->positions[index2*3+1], geom->positions[index2*3+2], 1);
        float4 v3Pos = float4(geom->positions[index3*3], geom->positions[index3*3+1], geom->positions[index3*3+2], 1);

        float4 v1PosTransformed = m_externTransform*v1Pos;
        float4 v2PosTransformed = m_externTransform*v2Pos; 
        float4 v3PosTransformed = m_externTransform*v3Pos; 


			  v[i*3+0].pos = v1PosTransformed;
			  v[i*3+1].pos = v2PosTransformed;
			  v[i*3+2].pos = v3PosTransformed;
        

        if(geom->tex_coords.size()!=0)
        {
			    v[i*3+0].t = float2(geom->tex_coords[i*2], geom->tex_coords[i*2+1]);
			    v[i*3+1].t = float2(geom->tex_coords[i*2], geom->tex_coords[i*2+1]);
			    v[i*3+2].t = float2(geom->tex_coords[i*2], geom->tex_coords[i*2+1]);
        }

			  indices[i*3+0] = i*3+0;
			  indices[i*3+1] = i*3+1;
			  indices[i*3+2] = i*3+2;

        int matID = geom->material_id[i];

        v[i*3+0].material_id = materialIDs[matID];
        v[i*3+1].material_id = materialIDs[matID];
        v[i*3+2].material_id = materialIDs[matID];


     
        float4 norm = normalize(cross(v2PosTransformed-v1PosTransformed, v3PosTransformed-v1PosTransformed));
        face_normals[i*3 + 0] = norm.x;
        face_normals[i*3 + 1] = norm.y;
        face_normals[i*3 + 2] = norm.z;


		  }
      for(int i=0; i<geom->n_faces; i++)
      {
        int index1 = geom->pos_indeces[i*3+0];
        int index2 = geom->pos_indeces[i*3+1];
        int index3 = geom->pos_indeces[i*3+2];


        std::vector <int> vn1 = vertexFaceIndeces[index1];
        float3 norm = ComputeSmGroupNormal(vn1, i, geom->face_smoothgroups, 0, face_normals);
        float4 norm4(norm.x, norm.y, norm.z, 1);
        v[i*3+0].norm = norm4;

        std::vector <int> vn2 = vertexFaceIndeces[index2];
        norm = ComputeSmGroupNormal(vn2, i, geom->face_smoothgroups, 1, face_normals);
        norm4 = float4(norm.x, norm.y, norm.z, 1);
        v[i*3+1].norm = norm4;

        std::vector <int> vn3 = vertexFaceIndeces[index3];
        norm = ComputeSmGroupNormal(vn3, i, geom->face_smoothgroups, 2, face_normals);
        norm4 = float4(norm.x, norm.y, norm.z, 1);
        v[i*3+2].norm = norm4;
        
      }


 		  pRender->AddTriangles(v, N_vertices, indices, N_indices);

      delete [] v;
      delete [] indices;
      delete [] face_normals;

      geom_obj++;
    }
	}
	
}


void LoadLights(IGraphicsEngine* pRender, const std::vector<LightObj> &lights)
{
	for (vector<LightObj>::const_iterator li = lights.begin(); li != lights.end(); ++li)
	{
		RAYTR::Light light;

		light.intensity = 1.0f;
		light.color = float3(1,1,1);
		light.pos = float3(0,0,0);	

		light.intensity = li->intensity;

		light.color = float3(li->color[0], li->color[1], li->color[2]);

		pRender->AddLight(light);
	}

}


int LoadMaterials(IGraphicsEngine* pRender, const std::vector<MaterialObj> &materials, std::map<int, int> &materialIDs)
{
	int mat_size = materials.size();
	int i =0;

	for (vector<MaterialObj>::const_iterator mat = materials.begin(); mat != materials.end(); ++mat)
	{
    HydraMaterial material;

		if(mat->shading=="PHONG")
		{
			material.specular.brdf_id = HydraMaterial.BRDF_PHONG;
		}
		else if (mat->shading=="BLINN")
		{
			material.specular.brdf_id = HydraMaterial.BRDF_BLINN;
		}
		else
		{
			material.specular.brdf_id = HydraMaterial.BRDF_PHONG;
		}

		material.ambient.color  = 0.05f*float3(mat->ambient_color);
		material.diffuse.color  = float3(mat->diffuse_color);
    material.diffuse.radiance = 2.0;
    material.specular.color = 0.75f*float3(mat->specular_color);
    
    material.reflection.color = 0.5*material.specular.color;

    material.specular.power = 100*mat->shininess;

    //material.refraction.color = mat->transparency*material.reflection.color;
    //material.refraction.fogColor  = material.refraction.color;
    //material.refraction.exitColor = material.refraction.color;

    //rt_materials[i].specular.fresnelIOR = mat->IOR;
    //material.specular.glossiness = mat->shininess;
    //material.specular.power = mat->shine_strength;

    int materialId = pRender->AddMaterial(material);

    materialIDs[mat->id] = materialId;
	}

  return mat_size;

}

void LoadSpheres(IGraphicsEngine* pRender, const std::vector<SphereObj> &spheres, const Matrix4x4f &m)
{
  for (vector<SphereObj>::const_iterator sph = spheres.begin(); sph != spheres.end(); ++sph)
  {
    Sphere4f sphere;
    sphere.pos = float4(sph->center[0], sph->center[1], sph->center[2], sph->center[3]);
    sphere.setRadius(sph->radius);
    sphere.material_id = sph->material_id;

    sphere.pos = m*sphere.pos;

    sphere.setRadius(sphere.r*m.GetCol(0)[0]);

    pRender->AddSpheres(&sphere,1);
    
  }
}

int LoadTextureFrom(IGraphicsEngine* pRender, std::string file_name, map<std::string,int> texIDs)
{

  ilInit();
  iluInit();

  if(!ilLoadImage(file_name.c_str()))
  {
    cout<<"image doesn't exist or has unknown format: "<<file_name<<"\n";
    return 0;
  }

  if(!ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE))
  {
    cout<<"image has unknown pixel format that OpenIL couldn't convert: "<<file_name<<"\n";
    return 0;
  }

  int w = ilGetInteger(IL_IMAGE_WIDTH);
  int h = ilGetInteger(IL_IMAGE_HEIGHT);
  int bpp = ilGetInteger(IL_IMAGE_BYTES_PER_PIXEL);
  int format = ilGetInteger(IL_IMAGE_FORMAT);

  int size = w * h * bpp;
  unsigned char* data = new unsigned char[size];

  ilCopyPixels(0,0,0,w,h,bpp,format,IL_UNSIGNED_BYTE,data);

  int ind = pRender->AddTexture(data, w, h);
  texIDs[file_name] = ind;
}

int ServerFileMain(IGraphicsEngine* pRender, Input* input)
{
  //boost::array<char, 1024> buf;
  //size_t file_size = 0;
  const unsigned int buff_size = 16384;
  int res = CONFIG_FILE;

  try
  {
    unsigned short tcp_port = 1234;

    std::cout <<"listen on port " << tcp_port << std::endl;

    boost::asio::io_service io_service;
    boost::asio::ip::tcp::acceptor acceptor(io_service, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), tcp_port));
    while(1)
    {
      if(res == SCENE_FILE)
        break;
      boost::system::error_code error;
      boost::asio::ip::tcp::socket socket(io_service);

      acceptor.accept(socket);      
      std::cout << "get client connection." << std::endl;

      std::ofstream f("C:/[Derp]/pluginFiles/serv_test.DERP",std::ios_base::binary); 

      unsigned int count = 0; 

      while(1) 
      { 
        boost::array<char, buff_size> buf; 
        boost::system::error_code error;

        size_t len = socket.read_some(boost::asio::buffer(buf), error);

        count += len;
        
        if (error == boost::asio::error::eof ) 
        { 
          std::cout << "Read a total of " << count << " bytes " << std::endl;

          f.write(buf.data(),len); 

          size_t file_size = f.tellp();
          std::cout << "File size " << file_size << std::endl;
          f.close();   
          break; 
        }
        else if (error) 
        {
          throw boost::system::system_error(error); 
        }
        else 
        {
          f.write(buf.data(),len);
        }
      }

      if(res == CONFIG_FILE)
        res = ReadDump("C:/[Derp]/pluginFiles/serv_test.DERP", pRender, READ_NEXT);
      else if(res == HEADER_COLLADA)
        res = ReadDump("C:/[Derp]/pluginFiles/serv_test.DERP", pRender, READ_COLLADA);
      else if(res == HEADER_TEXTURE)
        res = ReadDump("C:/[Derp]/pluginFiles/serv_test.DERP", pRender, READ_TEXTURE);
    }
  }
  catch (std::exception& e)
  {
    std::cerr << "Error : " << e.what() << std::endl;
  }
  catch (boost::system::error_code& e)
  {
    std::cerr << "Error : " << e.message() << std::endl;
  }
  return 0;
}


int ReadDump(std::string name, IGraphicsEngine* pRender, int headerRecvd)
{
  static std::string next_file_name = "";

  if(headerRecvd == READ_NEXT)
  {  
    TransferContents transfer;
    
    int mat_size = 0;

    std::ifstream ifs(name.c_str(), std::ios_base::binary);
    if (!ifs)
    {
      std::cout << "failed to open " << name << std::endl;
      return 0;
    }
    else
    {
      std::cout << "successfully opened " << name << std::endl;
    }

    boost::archive::binary_iarchive ar( ifs );

    static Included incl;

    ar & transfer;

    switch (transfer.contents)
    {
      case transfer.CONFIG:
      {
        ar & incl;

        std::cout << "settings read" << std::endl;
        ifs.close();

        return CONFIG_FILE;
      }
      case transfer.SCENE:
      {
        std::vector<GeometryObj> geometry;
        std::vector<SphereObj> spheres;
        std::vector<MaterialObj> materials;
        std::vector<LightObj> lights;
        std::map<int, int> materialIDs;

        if(incl.materials)
        {
          ar & materials;

          std::cout << "materials read" << std::endl;

          mat_size = LoadMaterials(pRender, materials, materialIDs);
        }

        if(incl.geometry)
        {
          for(int i = 0; i < incl.geomObjNum; i++)
          {
            GeometryObj geom;
            ar & geom;
            geometry.push_back(geom);
          }       

          std::cout << "geometry read" << std::endl;

          if(incl.spheres)
          {
            ar & spheres;

            std::cout << "spheres read" << std::endl;
          }

          LoadGeometry(pRender, geometry, spheres, materialIDs, mat_size);
        }

        if(incl.lights)
        {
          ar & lights;

          std::cout << "lights read" << std::endl;

          LoadLights(pRender, lights);
        }

        ifs.close();

        std::cout << "SCENE LOADING COMPLETE" << std::endl;

        return SCENE_FILE;
      }
      case transfer.HEADER:
      {
          Header head;
          ar & head;

          std::cout << "header read" << std::endl;
          ifs.close();

          if(head.contents == head.COLLADA_PROFILE)
            return HEADER_COLLADA;
          if(head.contents == head.TEXTURE_FILE)
            return HEADER_TEXTURE;


          size_t found = head.file_name.find(".hhh");
          if (found != std::string::npos)
            head.file_name.erase(found, 4);

          next_file_name = head.file_name;
      }
    }//switch
  }//if
  else if(headerRecvd == READ_COLLADA)
  {
    std::cout << "Collada profile received" << std::endl;
    std::rename(name.c_str(), next_file_name.c_str());
    return CONFIG_FILE;
  }
  else if(headerRecvd == READ_TEXTURE)
  {
    std::cout << "Texture file received" << std::endl;
    std::rename(name.c_str(), next_file_name.c_str());
    return CONFIG_FILE;
  }

  return 0;
  //TODO: Debugging vrscene import. Remove this later.
  /*vrscene::vrsceneImport import("C:/[Derp]/pluginFiles/box_vraymtl.vrscene");
  import.parseFile();

  std::string res;
  if (import.getValue("TexFresnel", "brdf0_fresnel", "fresnel_ior", res))
    std::cout << "TexFresnel brdf0_fresnel : fresnel_ior = " << res;
  else
    std::cout << "Can't find requested parameter";
  std::cout << std::endl;*/

}


int LoadSceneDump(std::string sceneDumpName, std::string configName, IGraphicsEngine* pRender)
{
  int mat_size = 0;

  std::ifstream ifs_conf(configName.c_str(), std::ios_base::binary);
  if (!ifs_conf)
  {
    std::cout << "failed to open " << configName << std::endl;
    return 0;
  }
  else
  {
    std::cout << "successfully opened " << configName << std::endl;
  }

  boost::archive::binary_iarchive ar_conf( ifs_conf );

  TransferContents transfer;

  Included incl;

  ar_conf & transfer;

  ar_conf & incl;

  ifs_conf.close();

  std::ifstream ifs(sceneDumpName.c_str(), std::ios_base::binary);
  if (!ifs)
  {
    std::cout << "failed to open " << sceneDumpName << std::endl;
    return 0;
  }
  else
  {
    std::cout << "successfully opened " << sceneDumpName << std::endl;
  }

  boost::archive::binary_iarchive ar( ifs );

  ar & transfer;

  std::vector<GeometryObj> geometry;
  std::vector<SphereObj> spheres;
  std::vector<MaterialObj> materials;
  std::vector<LightObj> lights;
  std::map<int, int> materialIDs;
  if(incl.materials)
  {
    ar & materials;

    std::cout << "materials read" << std::endl;

    mat_size = LoadMaterials(pRender, materials, materialIDs);
  }

  if(incl.geometry)
  {
    for(int i = 0; i < incl.geomObjNum; i++)
    {
      GeometryObj geom;
      ar & geom;
      geometry.push_back(geom);
    }       

    std::cout << "geometry read" << std::endl;

    if(incl.spheres)
    {
      ar & spheres;

      std::cout << "spheres read" << std::endl;
    }

    LoadGeometry(pRender, geometry, spheres, materialIDs, mat_size);
  }

  if(incl.lights)
  {
    ar & lights;

    std::cout << "lights read" << std::endl;

    LoadLights(pRender, lights);
  }

  ifs.close();

  std::cout << "SCENE LOADING COMPLETE" << std::endl;

  return 1;
}