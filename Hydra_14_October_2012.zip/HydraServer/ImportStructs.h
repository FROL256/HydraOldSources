struct GeometryObj
{
  float m[16];
	int n_verts;
	int n_faces;
	std::string mesh_id;
  std::vector<int> material_id;
	std::vector<float> positions;
	std::vector<int> pos_indeces;
  std::vector<int> face_smoothgroups;
	std::vector<float> tex_coords;
  float bbox[6];

	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & m;
      ar & n_verts;
		  ar & n_faces;
		  ar & mesh_id;
		  ar & material_id;
		  ar & positions;
		  ar & pos_indeces;
      ar & face_smoothgroups;
		  ar & tex_coords;
      ar & bbox;
    }

};


struct LightObj
{
	std::string lightType;
	std::string shadowType;
	std::string spotShape;
	bool useGlobal;
	bool absMapBias;
	bool overshoot;
	float color[3];
	float intensity;
	float aspect;
	float hotsize;
	float fallsize;
	float attenStart;
	float attenEnd;
	float TDist;
	float mapBias;
	float mapRange;
	float mapSize;
	float rayBias;

	float m[16];

	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & lightType;
		  ar & shadowType;
		  ar & spotShape;
		  ar & useGlobal;
		  ar & absMapBias;
		  ar & overshoot;
		  ar & color;
		  ar & intensity;
		  ar & aspect;
		  ar & hotsize;
		  ar & fallsize;
		  ar & attenStart;
		  ar & attenEnd;
		  ar & TDist;
		  ar & mapBias;
		  ar & mapRange;
		  ar & mapSize;
		  ar & rayBias;
		  ar & m;
    }


};

struct TextureObj
{
	std::string texName;
	std::string texClass;
	std::string texAmount;
	std::string mapName;
	std::string texFilter;
	std::string mapType;

	bool texInvert;

	float uOffset;
	float vOffset;
	float uTiling;
	float vTiling;
	float angle;
	float blur;
	float blurOffset;
	float noiseAmt;
	float noiseSize;
	int noiseLevel;
	float noisePhase;

	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & texName;
		  ar & texClass;
		  ar & texAmount;
		  ar & mapName;
		  ar & texFilter;
		  ar & mapType;

		  ar & texInvert;

		  ar & uOffset;
		  ar & vOffset;
		  ar & uTiling;
		  ar & vTiling;
		  ar & angle;
		  ar & blur;
		  ar & blurOffset;
		  ar & noiseAmt;
		  ar & noiseSize;
		  ar & noiseLevel;
		  ar & noisePhase;
    }

    TextureObj()
    {
      bool texInvert = false;

      float uOffset = 0;
      float vOffset = 0;
      float uTiling = 0;
      float vTiling = 0;
      float angle = 0;
      float blur = 0;
      float blurOffset = 0;
      float noiseAmt = 0;
      float noiseSize = 0;
      int noiseLevel = 0;
      float noisePhase = 0;
    }
};

struct MaterialObj
{
	bool sub;

	int id;
	std::string name;
	float ambient_color[3];
	float diffuse_color[3];
	float specular_color[3];
	float shininess;
	float shine_strength;
	float transparency;
	//float wire_size;
	std::string shading;
  float opacity;
  float IOR;
	float opacity_falloff;
	float self_illumination;
	bool twosided;
	/*bool wire;
	bool wire_units; //true - units, false - pixels*/
	bool falloff; //true - out, false - in
	bool facemap;
	bool soften;
	std::string transparency_type;
	int num_subMat;

	std::vector<TextureObj> textures;


	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & sub;

		  ar & id;
		  ar & name;
		  ar & ambient_color;
		  ar & diffuse_color;
		  ar & specular_color;
		  ar & shininess;
		  ar & shine_strength;
		  ar & transparency;
		 // ar & wire_size;
		  ar & shading;
		  ar & opacity_falloff;
		  ar & self_illumination;
		  ar & twosided;
		 /* ar & wire;
		  ar & wire_units; */
		  ar & falloff; 
		  ar & facemap;
		  ar & soften;
		  ar & transparency_type;
		  ar & num_subMat;

		  ar & textures;
    }

    MaterialObj()
    {
      float ambient_color[3] = {0,0,0};
      float diffuse_color[3] = {0,0,0};
      float specular_color[3] = {0,0,0};
      float shininess = 0;
      float shine_strength = 0;
      float transparency = 0;
      std::string shading = "";
      float opacity = 0;
      float IOR = 0;
      float opacity_falloff = 0;
      float self_illumination = 0;
      bool twosided = false;
      bool falloff = false; 
      bool facemap = false;
      bool soften = false;
      std::string transparency_type = "";
    }

};

struct SceneTree 
{
	std::vector<SceneTree*> children;
	std::string name;

	SceneTree() 
	{
	}

	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
        ar & children;
        ar & name;
    }
};

struct TransferContents
{
  enum {SCENE, TEXTURE_FILES, VRSCENE_FILE, CONFIG, RENDER_SETTINGS, HEADER};
  int contents;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & contents;
  }

};

struct Header
{
  enum {COLLADA_PROFILE, TEXTURE_FILE};
  int contents;
  std::string file_name;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & contents;
    ar & file_name;
  }

};

struct Included
{
	bool geometry;
	bool lights;
	bool materials;
	bool tree;
  bool spheres;

  std::string sceneDumpName;
  std::string colladaProfile;

  std::string render_type;

  int geomObjNum;
  int imgObjNum;

  std::string AccType;
  std::string ConstrMode;

	template <class Archive>
	void serialize(Archive& ar, unsigned int version)
    {
      ar & geometry;
      ar & lights;
		  ar & materials;
		  ar & tree;
      ar & spheres;

      ar & sceneDumpName;

      ar & geomObjNum;
      ar & imgObjNum;  

      ar & AccType;
      ar & ConstrMode;
    }
};

struct SphereObj
{
  float m[16];
  float center[4];
  float radius;
  std::string mesh_id;
  int material_id;
  float bbox[6];
  template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & m;
      ar & center;
		  ar & radius;
		  ar & mesh_id;
		  ar & material_id;
      ar & bbox;
    }
};
