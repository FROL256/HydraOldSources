#ifndef MAXPL_H
#define MAXPL_H

#include <boost/asio.hpp>

#include <boost/serialization/string.hpp>
#include <boost/serialization/vector.hpp>

#include <string>
#include <vector>


#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "ImportStructs.h"
#include "../test_app/Input.h"

const bool HYDRA_SERVER_DEBUG = false;

template<class T>
static void DEBUG_PRINT2(const std::string before, const T& x, const std::string after="")
{
  static ofstream log("hydra_log.txt", ios::app);

  if(HYDRA_SERVER_DEBUG)
    log << before.c_str() << x << " " << after.c_str() << std::endl;
}


int LoadDump(std::string name);
void LoadGeometry(IGraphicsEngine* pRender, const std::vector<GeometryObj> &geometry, const std::vector<SphereObj> &spheres, std::map<int, int> &materialIDs, int mat_size);
void LoadLights(IGraphicsEngine* pRender, const std::vector<LightObj> &lights);
int LoadMaterials(IGraphicsEngine* pRender, const std::vector<MaterialObj> &materials, std::map<int, int> &materialIDs);
void LoadTextureFile(IGraphicsEngine* pRender, std::string file_name, map<std::string,int> texIDs);
void LoadSpheres(IGraphicsEngine* pRender, const std::vector<SphereObj> &spheres, const Matrix4x4f &m);
int ReadDump(std::string name, IGraphicsEngine* pRender, int headerRecvd);
int LoadSceneDump(std::string sceneDumpName, std::string configName, IGraphicsEngine* pRender);
int ServerFileMain(IGraphicsEngine* pRender, Input* input);

#endif