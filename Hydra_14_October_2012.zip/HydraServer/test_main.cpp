#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gl/glew.h>
#include <gl/glut.h> 

#pragma comment(lib, "RTE.lib")

#ifndef MAXPL_H
#include "maxPluginServer.h"
#endif

#ifndef MGML_GUARDIAN
#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "../test_app/Input.h"
//#include "Cube.h"
//#include "Prism.h"
//#include "../test_app/Camera.h"

//#include "scenes.h"
#include "ColladaImport.h"
//#include "../gpu_rt/Fonts.h"


//#include "../test_app/ReLight.h"
#include <sstream>

using namespace MGML;
//using namespace RAYTR;
using namespace MGML_MATH;
using namespace std;

int WinWidth = 640;
int WinHeight = 480;

IGraphicsEngine* pRender = NULL;
//IReLightProxy*   pReLightApp = NULL;
Input input;  

Camera* cam;

volatile bool pathTracingFinished = false;
int ticksOld = 0;
int ticksNew = 0;
bool stopCountTime = false;
bool firstPass = 0;

float flyRadius = 8.0f;

bool g_importFromFile = false;


void SetVSync(bool sync)
{
  typedef bool (APIENTRY *PFNWGLSWAPINTERVALFARPROC)(int);

  PFNWGLSWAPINTERVALFARPROC wglSwapIntervalEXT = 0;

  wglSwapIntervalEXT = (PFNWGLSWAPINTERVALFARPROC)wglGetProcAddress("wglSwapIntervalEXT");

  if( wglSwapIntervalEXT )
    wglSwapIntervalEXT(sync);
}


void Init()
{
  try
  {

    SetVSync(0);

    //pRender = new GPU_Ray_Tracer(WinWidth, WinHeight);
   pRender = new GPU_Path_Tracer(WinWidth, WinHeight);
    //pRender = new OpenGL_Render(WinWidth,WinHeight);

    //pReLightApp = new TestReLightPoxy(pRender);

    cam = new Camera();

    //std::cout << "sizeof(HydraMaterial): " << sizeof(HydraMaterial) << std::endl;

    //vec4f pos(3,-2,7,0);
    //vec4f lookAt(0,0,0,0);
    //cam->pos = pos;
    //cam->SetRotation(vec4f(30.0,0.1,0,0));
    //cam->LookAt(pos,lookAt);
    //cam->LookAt(pos, lookAt);

    Matrix4x4f mr,mt,ms, ms2;
    float k = 0.1f/0.025400;
    ms.SetScale(float3(k,k,k));

    /*
    float k2 = 1.0f;
    ms2.SetScale(float3(k2,k2,k2));
    mt.SetTranslate(float3(0,0,0));
    ImportSceneFromCollada(pRender, "data/cubes/cubes2.DAE", cam, mt*ms2);

    pRender->Clear(IGraphicsEngine::CLEAR_LIGHTS);

    if(input.animateLight)
    MakeSomePointLights(pRender);
    else
    MakeSomeLights(pRender); 
    */
    flyRadius = 4;


    if(g_importFromFile)
      LoadSceneDump("C:/[Derp]/pluginFiles/test.DERP", "C:/[Derp]/pluginFiles/derp.CONF", pRender);
    else
      ServerFileMain(pRender, &input); 

    //if(ServerMain(pRender)!=0)
    //RUN_TIME_ERROR("Hydra server failed");

   
    /*RAYTR::Light flatLight2;
    flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
    flatLight2.pos.set(0,8.0,0);
    //flatLight2.pos.set(0,0.95,0);
    flatLight2.kc = 1;
    flatLight2.kl = 0.001;
    flatLight2.kq = 0.0001;
    flatLight2.intensity = 2.5f;
    flatLight2.color.set(1.0f,1.0f,1.0f);
    flatLight2.SetAreaLightSize(1.5f, 1.5f);
    //flatLight2.SetAreaLightSize(0.5f, 0.5f);
    flatLight2.SetNormal(vec3f(0,-1.0f,0));
    flatLight2.UseShadingModelCorrect();

    pRender->AddLight(flatLight2); */

    RAYTR::Light pointLight;
    pointLight.SetLighType(RAYTR::Light::LIGHT_TYPE_SKY);
    pointLight.pos.set(0,10000,0);
    pointLight.kc = 1;
    pointLight.kl = 0.0;
    pointLight.kq = 0.0;
    pointLight.intensity = 2.0f;
    pointLight.color.set(1.0f,1.0f,1.0f);
    pRender->AddLight(pointLight);

    Ray_Tracer* pRayTracer = dynamic_cast<Ray_Tracer*>(pRender);
    if(pRayTracer != 0 && !input.animateLight)
      pRayTracer->AddLightsAsGeometry();  // try to add lights as geometry if needed

    cout << "constructing acceleration structures (may take a very long time), please wait...\n";
    Timer treeBuildTimer;
    treeBuildTimer.start();
    float timeStart = treeBuildTimer.getElapsed();

    pRender->BuildAccelerationStructures(input.accelStructConstructionMode);
    //pRender->BuildAccelerationStructures(KD_TREE_CONSTRUCT_QUALITY);
    //pRender->BuildAccelerationStructures(KD_TREE_CONSTRUCT_FAST);
    //pRender->BuildAccelerationStructures(KD_TREE_CONSTRUCT_VERY_FAST);

    float totalConstructionTime = treeBuildTimer.getElapsed() - timeStart;
    cout << "construction time: " << totalConstructionTime << "s" << endl;
  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
}


//////////////////////////////////////////////////////////////////////////
////
void ShutDown()
{
  try
  {
    cerr << std::endl;
    //delete pReLightApp;
    delete pRender;
    delete cam;
    pRender = 0;
  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
}


void Display()
{
  static int FramesCount = 0;
  static float FPS = 60; // ������� ������ � �������

  static float t_process = 1;
  static float omega = 0.5;
  static bool  firstFrame = true;
  static float path_tracing_time = 0.0f;

  static Timer timer; 

  try
  {
    input.ReadXMLFromSharedMemory();

    if(input.exit_status) 
      exit(0);

    pRender->SetVariable("g_debugLayerDraw", input.debugLayerDraw);

    if(t_process > 1000)
      t_process = 1.0f;

    if(!input.pathTracingEnabled)
    { 
      t_process += (omega/FPS);

      int numLights = pRender->GetLightNumber();
      if(numLights > 0)
      { 
        RAYTR::Light light = pRender->GetLight(0);
        light.pos.x = flyRadius*sin(t_process);
        light.pos.z = flyRadius*cos(t_process);
        if(input.animateLight)
          pRender->SetLight(light, 0);
      }

      cam->Move(input.cam_mov);
      cam->SetRotation(input.cam_rot);
    }


    pRender->SetWorldViewMatrix((cam->GetWorldMatrix()*cam->GetViewMatrix()).L);
    pRender->SetProjectionMatrix(cam->GetProjectionMatrix().L);

    pRender->SetVariable("drawIrradianceCachePixelPoints", input.drawIrradianceCachePixelPoints);

    IGraphicsEngine::RenderState renderState;

    renderState.SetTraceDepth(input.trace_depth);
    renderState.SetShadow(input.shadows);
    renderState.SetAA(input.AA);
    renderState.SetIndirrectIllumination(input.indirrectIllum);
    renderState.SetEnableRaysCounter(input.drawRayStatInfo);
    //renderState.SetColorShadow(true);

    if(input.computeIrradianceCache && !input.relightEnabled)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->ComputeIrradianceCache();
      }

      input.computeIrradianceCache = false;
    }
    else if(input.pathTracingEnabled && !firstFrame)
    {
      if(firstPass)
      {
        timer.start();
        firstPass = false;
      }

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if (pathTracer!=0)
      {
        GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;

        if(input.inputXML == NULL)
        {
          pathTracerParams.drawBlocks       = input.drawBlocks;
          pathTracerParams.drawRaysStatInfo = input.drawRayStatInfo;
        }

        pathTracer->SetRenderingParams(pathTracerParams);

        pathTracer->BeginPathTracingPass(renderState);
        pathTracingFinished = pathTracer->EndPathTracingPass();

        if(!stopCountTime)
          path_tracing_time += timer.getElapsed();

        if(pathTracingFinished && stopCountTime == false)
        {
          stopCountTime = true;

          std::cerr << "saving image" << std::endl;

          uint* imageData = new uint [WinWidth*WinHeight];
          pRender->GetLDRImage(imageData);

          std::stringstream fileName;
          fileName.precision(6);
          fileName << "hydra_" << path_tracing_time << ".png";

          SaveImageToFile(fileName.str(), WinWidth, WinHeight, imageData);

          std::cerr << "image saved" << std::endl;
          delete [] imageData;
        }
      }
    }
    else if (input.relightEnabled)
    {
      //pReLightApp->DoRendering("out_relight_data");
      input.relightEnabled = false;
      exit(0);
    }
    else if(!firstFrame)
    {
      pathTracingFinished = false;
      firstPass = true;
      FPS = 60;
      path_tracing_time = 0.0f;
      stopCountTime = false;

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if (pathTracer!=0)
        pathTracer->ResetPathTracing();

      pRender->BeginDrawScene(renderState); 
      OpenGL_Render* pCGE = dynamic_cast<OpenGL_Render*>(pRender);
      if(pCGE!=0)
      {
        pCGE->SetDebugDrawIndex(input.m_debugIndex);

        //DrawDebugBoxes("points1.txt");
        //DrawDebugPoints("points2.txt");
        //DrawDebugSphereBox();
        //DrawDebugTreeData3();
        //DrawDebugSpheres("spheres.txt");
        //DrawDebugSpheres2("spheres", 20);
      }

      pRender->EndDrawScene();

    }

    glutSwapBuffers();

    input.reset();
    firstFrame = false;
  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }

  // -----------------------  �������� �������� FPS. -----------------------
  FramesCount++;
  if(FramesCount > 1)
  {
    FPS = float(FramesCount)/(timer.getElapsed());
    FramesCount=0;
    timer.start();

    char Title[64];

    if(!input.pathTracingEnabled)
      sprintf(Title, "FPS=%.1f", FPS);
    else if (!pathTracingFinished)
      sprintf(Title, "path tracing: %.2f sec", path_tracing_time);
    else
      sprintf(Title, "path tracing: %.2f sec, finished!", path_tracing_time);

    glutSetWindowTitle(Title);

  }

  //\\ -----------------------  �������� �������� FPS. -----------------------
}


void Mouse(int button, int state, int x, int y) { input.Mouse(button,state,x,y); }
void MouseMotion(int x, int y) { input.MouseMotion(x,y); }
void Reshape(int Width,int Height) {  }               //��������� ��������� �������� ����
void Keyboard(unsigned char key,int x,int y){ input.Keyboard(key,x,y); }   //�����
void KeyboardSpecial(int key, int x, int y) { input.KeyboardSpecial(key,x,y);  }   // ���� �����
void Mouse(int button, int state, int x, int y); //��������� ������� ����
void Idle() { glutPostRedisplay(); } 

int main(int argc, char** argv)
{
  HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(h, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);

  if(argc > 1)
  {
    input.inColladaFile = argv[1];
    if(argc>2)
      input.ReadXMLFromFile(argv[2]);

    for(int i=0;i<argc;i++)
      std::cout << "agrv[" << i << "]" << argv[i] << std::endl;
  }

  input.ReadXMLFromSharedMemory();

  WinWidth  = input.ext_width;
  WinHeight = input.ext_height;

  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
  glutInitWindowSize(WinWidth,WinHeight);
  glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)-WinWidth)/2, (glutGet(GLUT_SCREEN_HEIGHT)-WinHeight)/2);
  glutCreateWindow("NO FATE");

  glutDisplayFunc(Display);
  glutKeyboardFunc(Keyboard);
  glutSpecialFunc(KeyboardSpecial);
  glutReshapeFunc(Reshape);
  glutMouseFunc(Mouse);
  glutMotionFunc(MouseMotion);
  glutIdleFunc(Idle);

  glewInit();
  InitOpenIL();

  Init();
  atexit(ShutDown);

  glutMainLoop();
}


