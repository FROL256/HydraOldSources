#ifndef __HYDRALOG__H
#define __HYDRALOG__H

#include <time.h>
#include <fstream>
#include <string>



class HydraLogger
{
  std::ofstream outp;
  std::string name;

  public:
    HydraLogger(){}
    ~HydraLogger(){outp.close();}

    void OpenLogFile(std::string file)
    {
      name = file;
      outp.open(name.c_str(), std::ios::app);
    }
    
    template<class T>
    void Print (const T& x)
    {
      time_t rawtime;
      struct tm * timeinfo;

      time (&rawtime);
      timeinfo = localtime (&rawtime);

      outp << asctime (timeinfo) << "  " << x << std::endl;
    }
    
    template<class T>
    void PrintValue (std::string varName, const T& x)
    {
      time_t rawtime;
      struct tm * timeinfo;

      time ( &rawtime );
      timeinfo = localtime (&rawtime);

      outp << asctime (timeinfo) << "  " << varName << " : " << x << std::endl;
    }

};

#endif