#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>
#include <il\il.h>
#include <il\ilu.h>


#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;

int g_duplicatedVertices = 0;
int g_goodVertices = 0;


///////////////////////////////////////////////
///////////////////////////////////////////////

struct SceneGraph : public MGML_MATH::SSE_Aligned_Object
{
  SceneGraph(string n) 
  {
    instNode_url = "";
    children.clear();
    name = n;
  }

  SceneGraph(const SceneGraph& other)
  {
    m = other.m;
    children = other.children;
    instNode_url = other.instNode_url;
    geometry_id = other.geometry_id;
    name = other.name;
    //matrix = other.matrix;
  }

  SceneGraph() 
  {
  }

  virtual ~SceneGraph()
  {
    for(int i=0;i<children.size();i++)
      delete children[i];
    children.clear();
  }

  Matrix4x4f m;
  vector<SceneGraph*> children;
  string instNode_url;
  string geometry_id;
  string name;

};

Matrix4x4f GetTransformFromNode(TiXmlNode* a_node);
void findLeafNumber(SceneGraph* root, int* num);
SceneGraph* findSubtreeById(string id, SceneGraph* root);
void ConstructSceneTree(TiXmlNode* node, SceneGraph* root);
void TreeMatrixMultiply(SceneGraph* root, const Matrix4x4f& m, DynamicArray<Matrix4x4f> *matrices, vector<string> *meshes);

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void BuildInstList(TiXmlNode* scene, TiXmlNode* nodes_lib, InstList* pResult)
{
  SceneGraph* scnTree = new SceneGraph ("model");

  vector<string>*           meshes   = &(pResult->mesh_ids);
  DynamicArray<Matrix4x4f>* matrices = &(pResult->matrices);

  matrices->reserve(5000);
  meshes->reserve(5000);

  Matrix4x4f identityMatrix;
  ConstructSceneTree(scene, scnTree);
  TreeMatrixMultiply(scnTree, identityMatrix, matrices, meshes);

  delete scnTree; scnTree = NULL;
}


///////////////////////////////////////////////
///////////////////////////////////////////////
class ColladaMeshParams
{
public:
  vector<int>& indices_pos;
  vector<int>& indices_norm;
  vector<int>& indices_tex;

  int numTriangles;
  int numVertexAttributes;
  int numIndices;

  bool hasPos;
  bool hasNorm;
  bool hasTex;

  int offset_pos;
  int offset_norm;
  int offset_tex;

  ColladaMeshParams::ColladaMeshParams(vector<int>& pos, vector<int>& norm, vector<int>& tex) : indices_pos(pos), indices_norm(norm), indices_tex(tex)
  {
    numTriangles = 0;
    numVertexAttributes = 0;
    numIndices = 0;
    hasPos = true;
    hasNorm = false;
    hasTex = false;
    offset_pos = 0;
    offset_norm = 1;
    offset_tex = 2;
  }
};


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GetIndicesPoly(TiXmlNode* pPoly, vector<int>& tmpArr, ColladaMeshParams meshParams)
{
  const char* str = pPoly->ToElement()->GetText();

  tmpArr.resize(0);
  NumericParser::ExtractArrayFromString<int>(str, &tmpArr);

  if(tmpArr.size() != meshParams.numVertexAttributes*3)
    RUN_TIME_ERROR("tag <p> have less than needed indices at");

  for(int k=0;k<3;k++)
  {
    meshParams.indices_pos.push_back(tmpArr[k*meshParams.numVertexAttributes+meshParams.offset_pos]);

    if(meshParams.hasNorm)
      meshParams.indices_norm.push_back(tmpArr[k*meshParams.numVertexAttributes+meshParams.offset_norm]);

    if(meshParams.hasTex)
      meshParams.indices_tex.push_back(tmpArr[k*meshParams.numVertexAttributes+meshParams.offset_tex]);
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GetIndicesTri(TiXmlElement* pArray, vector<int>& tmpArr, ColladaMeshParams meshParams)
{
  const char* str = pArray->ToElement()->GetText();

  tmpArr.resize(0);
  NumericParser::ExtractArrayFromString<int>(str, &tmpArr);

  for(int v_id=0; v_id < meshParams.numTriangles*3; v_id++)
  {
    meshParams.indices_pos.push_back(tmpArr[v_id*meshParams.numVertexAttributes+meshParams.offset_pos]);

    if(meshParams.hasNorm)
      meshParams.indices_norm.push_back(tmpArr[v_id*meshParams.numVertexAttributes+meshParams.offset_norm]);

    if(meshParams.hasTex)
      meshParams.indices_tex.push_back(tmpArr[v_id*meshParams.numVertexAttributes+meshParams.offset_tex]);
  }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ProcessGeometryElement(ObjectDataList::iterator p,
                                           map<string, vector<float> >& geometry, 
                                           map<string, vector<int> >& geometry_order,
                                           vector<int>& tmpArr,
                                           TiXmlElement* pGeometryElement,
                                           string geometryId)
{

  if(pGeometryElement == 0)
    RUN_TIME_ERROR("Geometry with id " + geometryId + "not found in COLLADA XML");

  TiXmlElement* pMesh = pGeometryElement->FirstChildElement("mesh"); 

  if(pMesh==0)
    RUN_TIME_ERROR(geometryId + ": <mesh> not found in <geometry>");

  for(TiXmlNode* nextSource = pMesh->FirstChild("source"); nextSource!=0; nextSource = pMesh->IterateChildren("source", nextSource))
  {
    TiXmlElement* pArray = nextSource->FirstChildElement("float_array");

    string key = "unknown";

    if(pArray != 0)
    {
      int numElems = StringTo<int>(pArray->Attribute("count"));
      key = ToLowerCase(pArray->ToElement()->Attribute("id"));

      const char* str = pArray->ToElement()->GetText();
      if(str == NULL)
      {
        std::cerr << "Collada parsing ALERT! " << key.c_str() << " xml node array is empty!\nfile: " << __FILE__ << ", line: " << __LINE__ << std::endl;
        continue;
      }
      //if(str == NULL)
        //RUN_TIME_ERROR(key + " xml node array is empty!");

      geometry[key] = vector<float>();   
      geometry[key].reserve(numElems + 10);

      NumericParser::ExtractArrayFromString<float>(str, &geometry[key], numElems);
    }

    TiXmlNode* pStrideInfo = GetNode(nextSource, "technique_common", "accessor");
    if(pStrideInfo!=NULL)
      p->second[key + "_stride"] = pStrideInfo->ToElement()->Attribute("stride");

  }

  string tkey;
  bool hasTriangles = false;

  if(pMesh->FirstChildElement("triangles") != 0)
  {
    tkey = "triangles";
    hasTriangles = true;
  }
  else if(pMesh->FirstChildElement("polygons") != 0)
  {
    tkey = "polygons";
    hasTriangles = true;
  }

  if(!hasTriangles)
    return;

  for(TiXmlNode* nextTri = pMesh->FirstChild(tkey); nextTri!=0; nextTri = pMesh->IterateChildren(tkey, nextTri))
  {  
    int numTriangles = atoi(nextTri->ToElement()->Attribute("count"));

    int numVertexAttributes = 0;
    for(TiXmlNode* attr = nextTri->FirstChild("input"); attr!=NULL; attr = nextTri->IterateChildren("input", attr))
      numVertexAttributes++;

    // ��� ���������� ������. �������� �����:
    // <input semantic="VERTEX" source="#mesh1-geometry-vertex" offset="0"/>
    // <input semantic="NORMAL" source="#mesh1-geometry-normal" offset="1"/>
    // <input semantic="TEXCOORD" source="#mesh1-geometry-uv" offset="2" set="0"/>
    TiXmlElement* iList = nextTri->ToElement();
    TiXmlElement* pPosDesc  = FindElemByAttribute(iList, "input", "semantic", "VERTEX");
    TiXmlElement* pNormDesc = FindElemByAttribute(iList, "input", "semantic", "NORMAL");
    TiXmlElement* pTexDesc  = FindElemByAttribute(iList, "input", "semantic", "TEXCOORD");

    if(pTexDesc==0)
      pTexDesc  = FindElemByAttribute(iList, "input", "semantic", "TEXCOORD0");

    nextTri->FirstChildElement("input");

    bool hasPos = (pPosDesc!=0);
    bool hasNorm = (pNormDesc!=0);
    bool hasTex = (pTexDesc!=0);

    if(!hasPos)
      RUN_TIME_ERROR(string("tag <triangles> have no positions at") + nextTri->ToElement()->GetText());

    string matRef = "";

    //  <polygons material="_22___Default" count="32">
    //
    if( nextTri->ToElement()->Attribute("material") == NULL)
    {
      //std::cerr << "Collada parsing ALERT!" << std::endl;
      //std::cerr << "No 'material' attribute on <polygons> or <triangles> tag; geometryId = " << geometryId.c_str() << std::endl;
      //RUN_TIME_ERROR(std::string("No 'material' attribute on <polygons> or <triangles> tag"));
      matRef = m_materialsRemembered.begin()->first;
      m_defferedErrorMesasages["material_less_geometry"] = string("No 'material' attribute on <polygons> or <triangles> tag; geometryId = ") + geometryId;
    }
    else
      matRef = nextTri->ToElement()->Attribute("material");

    string key1 = ToLowerCase(geometryId + "-" + matRef + "_pos");
    string key2 = ToLowerCase(geometryId + "-" + matRef + "_norm");
    string key3 = ToLowerCase(geometryId + "-" + matRef + "_tex");

    geometry_order[key1] = vector<int>();
    geometry_order[key2] = vector<int>(); 
    geometry_order[key3] = vector<int>();  

    ColladaMeshParams meshParams(geometry_order[key1], geometry_order[key2], geometry_order[key3]);

    meshParams.numIndices = numVertexAttributes*numTriangles*3;
    meshParams.numTriangles = numTriangles;
    meshParams.numVertexAttributes = numVertexAttributes;
    meshParams.hasNorm = hasNorm;
    meshParams.hasPos = hasPos;
    meshParams.hasTex = hasTex;

    meshParams.indices_pos.reserve(meshParams.numTriangles*3 + 10);
    if(meshParams.hasNorm)
      meshParams.indices_norm.reserve(meshParams.numTriangles*3 + 10);
    if(meshParams.hasTex)
      meshParams.indices_tex.reserve(meshParams.numTriangles*3 + 10);

    TiXmlElement* pArray = nextTri->FirstChildElement("p");

    if(tkey == "triangles" && pArray != 0)
    { 
      GetIndicesTri(pArray, tmpArr, meshParams);
    } 
    else if(tkey == "polygons" && pArray != 0)
    {
      for(TiXmlNode* pPoly = nextTri->FirstChild("p"); pPoly!=0; pPoly = nextTri->IterateChildren("p", pPoly))
        GetIndicesPoly(pPoly, tmpArr, meshParams);
    }
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportGeometry(ObjectDataList* pOut_list,
                                   map<string, vector<float> > *geom,
                                   map<string, vector<int>> *geom_order,
                                   InstList *pInstList)
{ 
  Timer timer(true);

  ObjectDataList& plist = *pOut_list;
  plist.clear();

  map<string, vector<float> > &geometry = *geom;
  map<string, vector<int> > &geometry_order = *geom_order;

  vector<int> tmpArr; tmpArr.reserve(100000);

  TiXmlElement* geometry_lib = m_root->FirstChildElement("library_geometries");
  if(!geometry_lib)
    RUN_TIME_ERROR("'library_geometries' not found in XML");

  TiXmlNode* nextGeometryInLib = 0;
  for(TiXmlNode* nextGeometryInLib = geometry_lib->FirstChild("geometry"); nextGeometryInLib!=0; nextGeometryInLib = geometry_lib->IterateChildren("geometry", nextGeometryInLib))
  {
    map<string,string> geometryParams; 
    // <geometry id="mesh1-geometry" name="mesh1-geometry"> 
    // name: geometryParams["COLLADA_name"] = nextGeometryInLib->ToElement()->Attribute("name");  
    //
    geometryParams["id"] = nextGeometryInLib->ToElement()->Attribute("id");
    plist[ geometryParams["id"] ] = geometryParams;
  }

  std::cout << "Importing geometry(1.0), time = " << timer.getElapsed() << endl;
  timer.start();

  ObjectDataList::iterator p;
  for(p=plist.begin();p!=plist.end();++p)
  {
    string geometryId = p->second["id"];
    TiXmlElement* pGeometryElement = ColladaParser::FindElemByAttribute(geometry_lib, "geometry", "id", geometryId);
    ProcessGeometryElement(p, geometry, geometry_order, tmpArr, pGeometryElement, geometryId);
  }

  std::cout << "Importing geometry(1.1), time = " << timer.getElapsed() << endl;
  timer.start();

  // <library_visual_scenes> �������� ����� �������� �������� � ����������������
  // ����� �������������.
  TiXmlNode* vis_lib = m_root->FirstChild("library_visual_scenes");
  if(vis_lib!=0)
  { 
    TiXmlNode* scene = vis_lib->FirstChild("visual_scene");
    if(scene==0)
      RUN_TIME_ERROR("empty <library_visual_scenes>");

    TiXmlNode* nodes_lib = m_root->FirstChild("library_nodes");
    BuildInstList(scene, nodes_lib, pInstList);
  } // if


  // print deffered messages
  //
  std::map<std::string, std::string>::iterator err;
  for(err = m_defferedErrorMesasages.begin(); err != m_defferedErrorMesasages.end(); ++err)
  {
    std::cerr << "collada parsing geometry error " << err->first << ": " << std::endl;
    std::cerr << err->second << std::endl;
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
void ComputeSimpleFlatNormals(Vertex4f* v, uint* indices, int N_indices)
{
  for(int i=0;i<N_indices;i+=3)
  {
    float4 A = v[indices[i+0]].pos;
    float4 B = v[indices[i+1]].pos;
    float4 C = v[indices[i+2]].pos;

    float4 norm = normalize(cross((A-B),(A-C)));

    v[indices[i+0]].norm = norm;
    v[indices[i+1]].norm = norm;
    v[indices[i+2]].norm = norm;
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
bool IsSphere(const std::string& mat_key_pos, Vertex4f* v, int N_vertices, Sphere4f* pSphere)
{
  bool isSphere = false;
  float radius = 0;
  float4 center(0,0,0,1);
  int sphereMaterialId = v[0].material_id;

  if (mat_key_pos.find("sphere") < mat_key_pos.length() && N_vertices > 0) 
  {
    isSphere = true;

    // calc center
    //
    center.set(0,0,0,1);
    for(int i=0;i<N_vertices;i++)
      center += v[i].pos;
    center *= (1.0f/N_vertices);
    center.w = 1;

    // assume we have deninite radius
    //
    radius = length(v[0].pos - center);
    float epsilon = 0.001f;

    for(int i=0;i<N_vertices;i++)
    {
      if( abs(length(v[i].pos - center) - radius) > epsilon)
      {
        isSphere = false;
        break;
      }
    }
  }

  pSphere->pos = center;
  pSphere->setRadius(radius);
  pSphere->material_id = sphereMaterialId;

  return isSphere;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
std::string CutCrapFromString(const std::string& a_str, const std::string& a_crap)
{
  std::string res;

  size_t pos = a_str.find(a_crap);

  if(pos!=std::string::npos)
    res = a_str.substr(0,pos) + a_str.substr(pos+4, a_str.size());
  else
    res = a_str;

  return res;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
bool FindPositionArray(std::string& key_pos, const std::string& geomName, const map<string, vector<float> >& geom)
{
  key_pos  = geomName + "-position-array";
  bool geomTagHasPositions = (geom.find(key_pos) != geom.end());

  // find positions
  //
  if(!geomTagHasPositions) 
  {
    key_pos  = geomName + "-positions-array";
    geomTagHasPositions = (geom.find(key_pos) != geom.end());
  }

  if(!geomTagHasPositions) 
  {
    key_pos  = geomName + "-position-array";
    geomTagHasPositions = (geom.find(key_pos) != geom.end());
  }

  if(!geomTagHasPositions) 
  {
    key_pos = CutCrapFromString(geomName, "-lib") + "-position-array";
    geomTagHasPositions = (geom.find(key_pos) != geom.end());
  }

  return geomTagHasPositions;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
bool FindNormalArray(std::string& key_norm, const std::string& geomName, const map<string, vector<float> >& geom)
{
  key_norm = geomName + "-normal-array";
  bool geomTagHasNormals = (geom.find(key_norm)!= geom.end());

  if(!geomTagHasNormals)
  {
    key_norm = geomName + "-normal0-array";
    geomTagHasNormals = (geom.find(key_norm) != geom.end());
  }

  if(!geomTagHasNormals)
  {
    key_norm = geomName + "-normal-array";
    geomTagHasNormals = (geom.find(key_norm) != geom.end());
  }

  if(!geomTagHasNormals)
  {
    key_norm = geomName + "-normals-array";
    geomTagHasNormals = (geom.find(key_norm) != geom.end());
  }

  if(!geomTagHasNormals) 
  {
    key_norm = CutCrapFromString(geomName, "-lib") + "-normal0-array";
    geomTagHasNormals = (geom.find(key_norm) != geom.end());
  }

  return geomTagHasNormals;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
bool FindTexCoordArray(std::string& key_tex, const std::string& geomName, const map<string, vector<float> >& geom)
{
  key_tex  = geomName + "-uv-array";
  bool geomTagHasTexCoords = (geom.find(key_tex) != geom.end());

  // find text coords
  //
  if(!geomTagHasTexCoords)
  {
    key_tex  = geomName + "-uv0-array";
    geomTagHasTexCoords = (geom.find(key_tex) != geom.end());
  }

  if(!geomTagHasTexCoords)
  {
    key_tex  = geomName + "-map1-array";
    geomTagHasTexCoords = (geom.find(key_tex) != geom.end());
  }

  if(!geomTagHasTexCoords) 
  {
    key_tex = CutCrapFromString(geomName, "-lib") + "-uv0-array";
    geomTagHasTexCoords = (geom.find(key_tex) != geom.end());
  }

  return geomTagHasTexCoords;
}




//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
void GeometryStorage::ImportModelToRender(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& m_transform)
{
  std::string geomName = ToLowerCase(p->second["id"]);

  string key_pos, key_norm, key_tex;

  bool geomTagHasPositions = FindPositionArray(key_pos, geomName, this->geom_data);
  bool geomTagHasNormals   = FindNormalArray(key_norm,  geomName, this->geom_data);
  bool geomTagHasTexCoords = FindTexCoordArray(key_tex, geomName, this->geom_data);

  if(!geomTagHasPositions)
  {
    std::cerr << "Collada parsing ALERT! no positions found on geometry: " << key_pos.c_str() << std::endl;
    std::cerr << "file: " << __FILE__ << ", line: " << __LINE__ << std::endl;
    return;
  }
  //RUN_TIME_ERROR(string("no positions found on geometry: " + key_pos));

  const vector<float>& pos_array  = this->geom_data[key_pos];
  const vector<float>& norm_array = this->geom_data[key_norm];
  const vector<float>& tex_array  = this->geom_data[key_tex];

  int stridePos  = 3;
  int strideNorm = 3;
  int strideTex  = 2;

  if(p->second.find(key_pos + "_stride") != p->second.end())
    stridePos = atoi(p->second[key_pos + "_stride"].c_str());

  if(p->second.find(key_norm + "_stride") != p->second.end())
    strideNorm = atoi(p->second[key_norm + "_stride"].c_str());

  if(p->second.find(key_tex + "_stride") != p->second.end())
    strideTex = atoi(p->second[key_tex + "_stride"].c_str());

  ASSERT(stridePos > 0);
  ASSERT(strideNorm > 0);
  ASSERT(strideTex > 0);

  int vPosSize  = pos_array.size()/stridePos;
  int vNormSize = norm_array.size()/strideNorm;
  int vTexSize  = tex_array.size()/strideTex;

  if(vPosSize == vNormSize && vPosSize == vTexSize)
  {
    int numVertices  = vPosSize; 
    int numTriangles = numVertices/3;
    g_goodVertices += numVertices;

    std::vector<uint> indices; indices.reserve(numVertices);
    std::vector<int>  materialIndices; materialIndices.reserve(numTriangles); 

    // for each material
    //
    int next_material=0;
    for(vector<string>::const_iterator material = this->mat_names.begin(); material != this->mat_names.end(); ++material)
    {
      int currMaterialId  = this->mat_indices[next_material];

      string mat_key_pos  = ToLowerCase(p->second["id"] + "-" + *material + "_pos");
      const vector<int>& pos_indices = this->geom_indices[mat_key_pos]; 
      
      // for spheres only
      //
      if (mat_key_pos.find("sphere") < mat_key_pos.length() && pos_indices.size() > 0)
      {
        int vertNumbers = pos_indices.size();
        Vertex4f* tempVertices = new Vertex4f[vertNumbers];
        for(int i=0;i<vertNumbers;i++)
        {
          int index  = pos_indices[i];
          float4 pos = m_transform*float4(pos_array[index*stridePos+0], pos_array[index*stridePos+1], pos_array[index*stridePos+2], 1);
          tempVertices[i].pos = pos;
        }

        Sphere4f sphere;

        if(IsSphere(mat_key_pos, &tempVertices[0], vertNumbers, &sphere))
        {
          sphere.material_id = currMaterialId;
          pRender->AddSpheres(&sphere,1);
          next_material++;
          delete [] tempVertices; 
          continue;
        }

        delete [] tempVertices; 
      }
      //\\ for spheres

      for(int i=0;i<pos_indices.size();i++)
        indices.push_back(pos_indices[i]);

      for(int i=0;i<pos_indices.size()/3;i++)
        materialIndices.push_back(currMaterialId);

      next_material++;
    }

    if(indices.size() > 0)
    {
      ASSERT(pos_array.size() > 0);
      ASSERT(norm_array.size() > 0);
      ASSERT(tex_array.size() > 0);
      ASSERT(materialIndices.size() > 0);

      pRender->DeclareVertexInputLayout(IGraphicsEngine::VERTEX_POSITION | IGraphicsEngine::VERTEX_NORMAL | IGraphicsEngine::VERTEX_UV | IGraphicsEngine::VERTEX_MATERIAL_ID);

      pRender->SetVertexPositionPointer(&pos_array[0], stridePos*sizeof(float));
      pRender->SetVertexNormalPointer(&norm_array[0], strideNorm*sizeof(float));
      pRender->SetVertexUVPointer(&tex_array[0],  strideTex*sizeof(float));

      pRender->AddTriangles(m_transform, &indices[0], indices.size(),  pos_array.size()/stridePos,
                                         &materialIndices[0], materialIndices.size());

    }

  }
  else
  {
    int next_material=0;

    for(vector<string>::const_iterator material = this->mat_names.begin(); material != this->mat_names.end(); ++material)
    {
      string mat_key_pos  = ToLowerCase(p->second["id"] + "-" + *material + "_pos");
      string mat_key_norm = ToLowerCase(p->second["id"] + "-" + *material + "_norm");
      string mat_key_tex  = ToLowerCase(p->second["id"] + "-" + *material + "_tex");

      const vector<int>& pos_indices    = this->geom_indices[mat_key_pos]; 
      const vector<int>& norm_indices   = this->geom_indices[mat_key_norm];  
      const vector<int>& tex_indices_my = this->geom_indices[mat_key_tex];  

      int N_indices_pos  = pos_indices.size();  
      int N_indices_norm = norm_indices.size();    
      int N_indices_tex  = tex_indices_my.size(); 

      bool vertHasPositions = (N_indices_pos  > 0);
      bool vertHasNormals   = (N_indices_norm > 0);
      bool vertHasTexCoord  = (N_indices_tex  > 0);

      if(vertHasNormals && norm_array.size() == 0)
        RUN_TIME_ERROR("normals were missed in collada file");

      if(vertHasTexCoord && tex_indices_my.size() == 0)
        RUN_TIME_ERROR("tex coords were missed in collada file");

      int N_indices = MGML_MATH::MAX(N_indices_pos, N_indices_norm, N_indices_tex);
      int N_vertices = N_indices;

      uint* indices = new uint[N_indices];
      Vertex4f* v = new Vertex4f [N_indices];

      g_duplicatedVertices += N_indices;

      int texId = INVALID_TEXTURE;

      for(int i=0;i<N_indices;i++)
      {
        int pos_i  = pos_indices[i];
        int tex_i  = vertHasTexCoord ? tex_indices_my[i] : -1;

        v[i].pos = float4(pos_array[pos_i*stridePos+0], pos_array[pos_i*stridePos+1], pos_array[pos_i*stridePos+2], 1);
        v[i].pos = m_transform*v[i].pos;

        if(vertHasNormals)
        {
          int norm_i = norm_indices[i];
          v[i].norm  = float4(norm_array[norm_i*strideNorm+0], norm_array[norm_i*strideNorm+1], norm_array[norm_i*strideNorm+2], 0);  
          v[i].norm  = matrix4x4f_mult_normal4f(m_transform, v[i].norm);
        }

        if(vertHasTexCoord)
        {
          int tex_i = tex_indices_my[i];
          v[i].t = float2(tex_array[tex_i*strideTex+0], tex_array[tex_i*strideTex+1]);
        }
        else
          v[i].t = float2(0,0);

        v[i].material_id = this->mat_indices.at(next_material);

        indices[i] = i;
      }

      // ���������� �������, ���� �� ���
      if(!vertHasNormals)
        ComputeSimpleFlatNormals(v, indices, N_indices);

      Sphere4f sphere;

      if(IsSphere(mat_key_pos, v, N_vertices, &sphere))
        pRender->AddSpheres(&sphere,1);
      else
        pRender->AddTriangles(v, N_vertices, indices, N_indices);

      delete [] v;
      delete [] indices;
      next_material++;
    }
  }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//// 
void ImportGeometryFromCollada(IGraphicsEngine* pRender, 
                               ColladaParser::ObjectDataList& a_geomData,
                               GeometryStorage& geomStorage, const Matrix4x4f& a_mTransform,
                               InstList& instances)
{
  g_duplicatedVertices = 0;
  g_goodVertices = 0;

  ColladaParser::ObjectDataList::iterator p;

  for(p=a_geomData.begin(); p!=a_geomData.end(); ++p)
    p->second["rendered"] = "0";

  // instance objects
  //
  for(int i = 0; i < instances.mesh_ids.size(); i++)
  {
    const string& mesh = instances.mesh_ids[i];
    ColladaParser::ObjectDataList::iterator q = a_geomData.find(mesh);

    if(q != a_geomData.end())
    {
      Matrix4x4f mTransfrom = a_mTransform*(instances.matrices[i]);

      geomStorage.ImportModelToRender(pRender, q, mTransfrom);
      q->second["rendered"] = "1";
    } 
  }

  // instance objects that were not placed to the instance list
  //
  for (p=a_geomData.begin(); p!=a_geomData.end(); ++p)
    if(p->second["rendered"]=="0")
      geomStorage.ImportModelToRender(pRender, p, a_mTransform);

  std::cerr << "ImportFromCollada: vertices dublicates: " << 100.0f*float(g_duplicatedVertices)/float(g_duplicatedVertices+g_goodVertices) << "%" << std::endl;

}




//// utils
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void findLeafNumber(SceneGraph* root, int* num)
{
  if(root->children.size() == NULL)
  {
    (*num)++;
  }
  else
  {
    for(unsigned int i = 0; i < root->children.size(); i++)
    {
      findLeafNumber(root->children.at(i), num);
    }
  }
}

SceneGraph* findSubtreeById(string id, SceneGraph* root)
{
  SceneGraph* subtr;
  for(unsigned int i = 0; i < root->children.size(); i++)
  {
    if(root->children.at(i)->name == id)
    {
      subtr = root->children.at(i);
      return subtr;
    }
    findSubtreeById(id, root->children.at(i));
  }

  return NULL;
}


void ConstructSceneTree(TiXmlNode* node, SceneGraph* root)
{

  for(TiXmlNode* nextNode = node->FirstChild("node"); nextNode!=0; nextNode = node->IterateChildren("node", nextNode))
  {
    const char* id = nextNode->ToElement()->Attribute("id");

    if(id==0)
      continue;

    SceneGraph *newNode = new SceneGraph(id);
    string url = "";
    string geometry_id = "";

    // �������� ������ �� ������ ������ (library_nodes) �� ������ ���� � ���
    //
    if(nextNode->FirstChildElement("instance_node") != NULL)
    {
      //instance_node url="#selene"
      url = nextNode->FirstChildElement("instance_node")->ToElement()->Attribute("url");
      url = url.substr(1,url.size() - 1); // cut off '#' // TODO: check this it really '#'
    }

    newNode->instNode_url = url;

    // �������� ������ �� ������� ������ �� ������
    //
    if(nextNode->FirstChildElement("instance_geometry") != NULL)
    {
      geometry_id = nextNode->FirstChildElement("instance_geometry")->ToElement()->Attribute("url");
      geometry_id = geometry_id.substr(1,geometry_id.size() - 1); // cut off '#'
    }
    newNode->geometry_id = geometry_id;

    newNode->m = GetTransformFromNode(nextNode);

    root->children.push_back(newNode);
    ConstructSceneTree(nextNode, root->children.at(root->children.size()-1));
  }
}


void TreeMatrixMultiply(SceneGraph* root, const Matrix4x4f& m, DynamicArray<Matrix4x4f> *matrices, vector<string> *meshes)
{
  Matrix4x4f currMatrix = m*(root->m);

  if(root->children.size() == 0)
  {
    matrices->push_back(currMatrix);
    meshes->push_back(root->geometry_id);
  }

  for(unsigned int i=0; i<root->children.size(); i++)
    TreeMatrixMultiply(root->children.at(i), currMatrix, matrices, meshes);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void findAllLeafs(vector<string> *meshes, vector<Matrix4x4f*> *matrices, SceneGraph* root)
{
  if(root->children.size() == NULL)
  {
    meshes->push_back(root->geometry_id);
    matrices->push_back(&root->m);
  }
  else
  {
    for(unsigned int i = 0; i < root->children.size(); i++)
    {
      findAllLeafs(meshes, matrices, root->children.at(i));
    }
  }
}

