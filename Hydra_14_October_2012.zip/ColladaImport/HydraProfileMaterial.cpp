#include "HydraProfiles.h"
#include "ColladaImport.h"

using std::string;

ColladaMaterialImportProfile::ColladaMaterialImportProfile(TiXmlElement* a_node)
{
  m_pProfileNode = a_node;


}

void ColladaMaterialImportProfile::Transform(ObjectParameters& a_data)
{
  ObjectParameters& materialProperties = a_data;

  if( GetText(m_pProfileNode, "global_import_flags", "disable_emission") == string("1"))
  {
    materialProperties["emission_color"]   = "0 0 0";
    materialProperties["emission_texture"] = "";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_ambient") == string("1"))
  {
    materialProperties["ambient_color"]   = "0 0 0";
    materialProperties["ambient_texture"] = "";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_diffuse") == string("1"))
  {
    materialProperties["diffuse_color"] = "0 0 0";
    materialProperties["diffuse_texture"] = "";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_diffuse_radiance") == string("1"))
  {
    materialProperties["diffuse_radiance"] = "1.0f";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_specular") == string("1"))
  {
    materialProperties["specular_color"] = "0 0 0";
    materialProperties["specular_texture"] = "";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_reflectivity") == string("1"))
  {
    materialProperties["reflectivity_color"] = "0 0 0";
    materialProperties["reflectivity_texture"] = "";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_transparency") == string("1"))
  {
    materialProperties["transparency_color"] = "0 0 0";
    materialProperties["transparency_texture"] = "";
  }

  if( GetText(m_pProfileNode, "global_import_flags", "disable_bump") == string("1"))
  {
    materialProperties["displacement_height"] = "0";
    materialProperties["displacement_height_texture"] = "";
    materialProperties["displacement_normals_texture"] = "";
  }

}
