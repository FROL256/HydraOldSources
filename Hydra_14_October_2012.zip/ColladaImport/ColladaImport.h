#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"
#include "Camera.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"
using std::string;

#include "HydraProfiles.h"

#include <sstream>
#include <stdlib.h>

const bool COLLADA_DEBUG = false;

template<class T>
static void DEBUG_PRINT(const std::string before, const T& x, const std::string after="")
{
  static ofstream colladaLog("collada_parsing_log.txt", ios::app);

  if(COLLADA_DEBUG)
    colladaLog << before.c_str() << x << " " << after.c_str() << std::endl;
}

void ImportSceneFromCollada(IGraphicsEngine* pRender, const std::string fileName, Camera* camera, const Matrix4x4f& a_mat, const std::string a_profilePath = "");

const char* GetText(TiXmlNode*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*, const char*, const char*);

TiXmlNode* GetNode(TiXmlNode*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*, const char*, const char*);


//TiXmlElement* GetElement(TiXmlNode*, const char*);
//TiXmlElement* GetElement(TiXmlNode*, const char*, const char*);
//TiXmlElement* GetElement(TiXmlNode*, const char*, const char*, const char*);
//TiXmlElement* GetElement(TiXmlNode*, const char*, const char*, const char*, const char*);

Matrix4x4f GetTransformFromNode(TiXmlNode*);


///////////////////////////////////////////////
///////////////////////////////////////////////

struct NumericParser
{

protected:
  typedef long long int uint64_t;

  inline static uint64_t mystrtol(const char *&a_str, uint64_t val = 0 ) 
  {
    for ( char c; ( c = *a_str ^ '0' ) <= 9; ++ a_str ) val = val * 10 + c;
    return val;
  }

  inline static float mystrtof(const char *&a_str ) 
  {
    static float const exp_table[] = { 1e38, 1e37, 1e36, 1e35, 1e34, 1e33, 1e32, 1e31, 1e30, 1e29, 1e28, 1e27, 1e26, 1e25, 1e24, 1e23, 1e22, 1e21, 
      1e20, 1e19, 1e18, 1e17, 1e16, 1e15, 1e14, 1e13, 1e12, 1e11, 1e10, 1e9, 1e8, 1e7, 1e6, 1e5, 1e4, 1e3, 1e2, 10, 
      1, 0.1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10, 1e-11, 1e-12, 1e-13, 1e-14, 1e-15, 1e-16, 1e-17, 
      1e-18, 1e-19, 1e-20, 1e-21, 1e-22, 1e-23, 1e-24, 1e-25, 1e-26, 1e-27, 1e-28, 1e-29, 1e-30, 1e-31, 1e-32, 1e-33, 
      1e-34, 1e-35, 1e-36, 1e-37, 1e-38};

    static float const *exp_lookup = &exp_table[38];

    // read sign
    //
    float sign = 1.0f;
    if(*a_str == '-') 
    {
      sign = -1.0f;
      a_str++;
    }

    // read integer part
    //
    uint64_t val = mystrtol( a_str ); // read integer part
    int neg_exp = 0;
    if ( *a_str == '.' )              // read fractional part
    { 
      char const *fracs = ++ a_str;
      val = mystrtol( a_str, val );
      neg_exp = a_str - fracs;
    }

    if ( ( *a_str | ('E'^'e') ) == 'e' ) // read exp if number has it
    {
      neg_exp += (*(++a_str)) == '-'? mystrtol( ++ a_str ) : - mystrtol( ++ a_str );
    }

    if(neg_exp < -38) neg_exp = -38;
    if(neg_exp > 38)  neg_exp = 38;

    return float(val)*exp_lookup[neg_exp]*sign;
  }

public:

  inline static float NextFloat(const char*& a_str)
  {
    float result = mystrtof(a_str);
    while(*a_str == ' ' || *a_str == '\n' || *a_str == '\t') a_str++;
    return result;
  }

  inline static int NextInt(const char*& a_str)
  {
    int sign = 1;
    if(*a_str == '-') 
    {
      sign = -1;
      a_str++;
    }

    int result = mystrtol(a_str);
    if(*a_str == '0') a_str++;
    while(*a_str == ' ' || *a_str == '\n' || *a_str == '\t') a_str++;
    return result*sign;
  }

  //////////////////////////////////////////////////////////////////////////////////////////////////////
  //// 
  template<class T>
  static void ExtractArrayFromString(const char* strValue, vector<T>* pResult, int a_size)
  {
    std::istringstream stream(strValue);
    T data;

    while(!stream.eof())
    {
      stream >> data;
      pResult->push_back(data);
    }
  }


  template<class T>
  static void ExtractArrayFromString(const char* strValue, vector<T>* pResult) { ExtractArrayFromString<T>(strValue, pResult, -1); }


  template<>
  static void ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult, int a_size)
  {
    const char* str = in_str;

    pResult->resize(a_size);
    int i=0;
    while(*str != '\0' && i < pResult->size())
    {
      (*pResult)[i] = NextFloat(str);
      i++;
    }
  }

  template<>
  static void ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult)
  {
    const char* str = in_str;

    while(*str != '\0')
      pResult->push_back(NextFloat(str));
  }

  template<>
  static void ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult)
  {
    register const char* str = in_str;

    while(*str != '\0')
      pResult->push_back(NextInt(str));
  }

  template<>
  static void ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult, int a_size)
  {
    const char* str = in_str;

    pResult->resize(a_size);
    int i=0;
    while(*str != '\0' && i < pResult->size())
    {
      (*pResult)[i] = NextInt(str);
      i++;
    }
  }

};


namespace STR_CNV
{
  
  template <class T>
  static T StringTo(const std::string& str)  {return Type(str);}

  template <>
  static float StringTo<float>(const std::string& str)  
  {
    float res;
    if(sscanf(str.c_str(), "%f",&res) != 1)
      return 0.0f;
    return res;
  }

  template <>
  static int StringTo<int>(const std::string& str)  
  {
    int res;
    if(sscanf(str.c_str(), "%d",&res) != 1)
      return 0;
    return res;
  }

  template <>
  static float2 StringTo<float2>(const std::string& str)  
  {
    float2 res;
    if(sscanf(str.c_str(), "%f %f",&res.x, &res.y) != 2)
      return float2(0,0);
    return res;
  }

  template <>
  static float3 StringTo<float3>(const std::string& str)  
  {
    float3 res;
    if(sscanf(str.c_str(), "%f %f %f", &res.x, &res.y, &res.z) != 3)
      return float3(0,0,0);
    return res;
  }

  template <>
  static float4 StringTo<float4>(const std::string& str)  
  {
    float4 res;
    if(sscanf(str.c_str(), "%f %f %f %f", &res.x, &res.y, &res.z, &res.w) != 4)
      return float4(0,0,0,0);
    return res;
  }

  template <>
  static Matrix4x4f StringTo<Matrix4x4f>(const std::string& str)  
  {
    Matrix4x4f r;
    if(sscanf(str.c_str(),"%f %f %f %f \
                           %f %f %f %f \
                           %f %f %f %f \
                           %f %f %f %f", 
                           &r.L[0], &r.L[1], &r.L[2], &r.L[3],
                           &r.L[4], &r.L[5], &r.L[6], &r.L[7],
                           &r.L[8], &r.L[9], &r.L[10], &r.L[11],
                           &r.L[12], &r.L[13], &r.L[14], &r.L[15]) != 16)
      RUN_TIME_ERROR("Can not convert string to Matrix4x4f");
    return r;
  }

  static std::string ToLowerCase(const std::string& a_str)
  {
    std::string str = a_str;
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
  }

  static void TransformToLowerCase(std::string& key)
  {
    std::transform(key.begin(), key.end(), key.begin(), ::tolower);
  }

};

std::string MatrixToString(const Matrix4x4f& m);

class InstList;

class ColladaParser
{

public:

   ColladaParser();
   ~ColladaParser();

   typedef std::map<std::string, std::string> ObjectData;
   typedef std::map<std::string, ObjectData>  ObjectDataList;

   void LoadXML(const std::string& a_fileName);

   void ImportLights(ObjectDataList* pOut_list);
   void ImportMaterials(ObjectDataList* pOut_list);
   void ImportTextures(ObjectDataList* pOut_list);  // no needs in using it directly it will be called from ImportMaterials, but you still can
   void ImportCameras(ObjectDataList* pOut_list);
   void ImportGeometry(ObjectDataList* pOut_list, map<string, vector<float> > *geom, map<string, vector<int> > *geom_order, InstList *geometryAttribs);

   Matrix4x4f GetTransformMatrix(){return m_globalTransform;}

   const std::string& GetLastParsedXML() const {return m_lastXMLPath;}

   //
   //
   static void ParseHydraMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialHydraNode);
   void ParseStandartMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData);
   void ParseExtraMaterialData(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData);
   
   static void ParseHydraLight(TiXmlNode* node, map<string,string>* p);
   
   TiXmlElement* LoadXMLAndGetFirstElement(const std::string& a_profilePath, const std::string& a_str);

   static std::string CutOffColladaEffectsShit(const std::string& a_name);

   TiXmlElement* GetElement(const std::string& a_name);
   TiXmlElement* GetRoot() {return m_root;}

   IHydraMaterialImportProfile* m_pHydraMatProfile;

protected:

   TiXmlElement* ColladaParser::FindEffectNode(TiXmlElement* pEffectsLib, const std::string& materialName);
   TiXmlElement* FindElemByAttribute(TiXmlElement* a_node, const std::string& a_nodeName, const std::string& a_attributeName, const std::string& a_attributeValue);

   std::string FindTexturePath(const ObjectDataList& list, const std::string& key, const std::string& val, const std::string& second_val) const;
   std::string ColladaParser::FindTargetTransform(TiXmlNode* pObjectsTransform, TiXmlNode* nextNode);
   void ColladaParser::InstanceLightObjects(TiXmlNode* pNode, ObjectDataList& plist, ObjectDataList& plist2);

   void ColladaParser::ProcessGeometryElement(ObjectDataList::iterator p, map<string, vector<float> >& geometry, map<string, vector<int> >& geometry_order, vector<int>& tmpArr, TiXmlElement* pGeometryElement, string geometryId);

   void CreateExporterProfiles(TiXmlNode* root);

   TiXmlDocument m_doc;
   TiXmlElement* m_root;
   Matrix4x4f m_globalTransform;

   ObjectDataList m_materialsRemembered;

   std::string m_lastXMLPath;

   std::map<std::string,std::string> m_defferedErrorMesasages;

};

struct InstList
{
  vector<string>           mesh_ids;
  DynamicArray<Matrix4x4f> matrices;
};


class GeometryStorage
{
public:

  void ImportModelToRender(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& m_transform);

  map<string, vector<float> > geom_data;
  map<string, vector<int> >   geom_indices;
 
  vector<string>              mat_names;
  vector<int>                 mat_indices;
};


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
class EmptyDataConverter
{
public:
  virtual void ConvertData(void* data, int w, int h) {}
};

class BumpMapConverter : public EmptyDataConverter
{
public:
  BumpMapConverter(bool flags[4]) {for(int i=0;i<4;i++) m_convertFlags[i] = flags[i];}
  void ConvertData(void* data, int w, int h);

protected:
  bool m_convertFlags[4];
};


class AlphaFromRedChannel : public EmptyDataConverter
{
public:
  AlphaFromRedChannel(){} 
  void ConvertData(void* data, int w, int h);

protected:

};


//////////////////////////////////////////////////////////////////////////////////////////////////////
////

class ITextureImporter
{
public:

  ITextureImporter(){}
  virtual ~ITextureImporter(){}

  virtual int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false, bool displacement = false) = 0;
  virtual void SetCurrentPathToMainFile(const std::string& path) = 0;
  virtual void ResetCurrentPath() = 0;

  virtual int  GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex) {return INVALID_TEXTURE;}

  virtual std::map<std::string, int>& GetCache() {return m_cache;}

protected:

  virtual int  CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex) {return INVALID_TEXTURE;}

  virtual std::string GetAbsolutePath(const std::string& path) {return "";}
  virtual bool HeightFileHasChanged(const std::string& heightPath, const std::string& heightPath2);

  std::map<std::string, int> m_cache;
  std::map<std::string, int> m_bumpCache;
};


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
class ColladaTextureImporter : public ITextureImporter
{
public:
  ColladaTextureImporter();
  ~ColladaTextureImporter();


  int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false, bool displacement = false);
  void SetCurrentPathToMainFile(const std::string& path);
  void ResetCurrentPath();

  virtual int GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex);

protected:

  int  CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex);

  ColladaTextureImporter(const ColladaTextureImporter& rhs){}
  ColladaTextureImporter& operator=(const ColladaTextureImporter& rhs) {return* this;}

  std::string GetPathToFolder(const std::string& pathToFile);
  std::string GetAbsolutePath(const std::string& path);

  std::string m_pathToXML;
  std::string m_pathToXMLFolder;
  std::string m_oldPath;
  int m_chdirResult;
  bool m_pathWasChanged;

  std::map<std::string, int> m_normalMapCache;
};



//////////////////////////////////////////////////////////////////////////////////////////////////////
////

inline static float3 GetFloat3(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<float3>(a_param->second[a_name] );
  else
    return float3(0,0,0);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////

inline static float GetFloat(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<float>(a_param->second[a_name] );
  else
    return 0.0f;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
static std::string GetString(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  return a_param->second[a_name];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
static int GetBRDFType(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  std::string brdfType = a_param->second[a_name];
  int BRDF_id;
  if(brdfType == "phong")
    BRDF_id = RAYTR::HydraMaterial::BRDF_PHONG;
  else if (brdfType=="blinn")
    BRDF_id = RAYTR::HydraMaterial::BRDF_BLINN;
  else if (brdfType=="cook-torrance")
    BRDF_id = RAYTR::HydraMaterial::BRDF_COOK_TORRANCE;
  else 
    BRDF_id = RAYTR::HydraMaterial::BRDF_PHONG;

  return BRDF_id;
}


// TODO: - create correct function
static float VRayGlosinessToCosinePower(float glosiness)
{
  return  1.0f/fmaxf(1e-6f,(1.0f - pow(glosiness, 0.001f)));
}




class IGeometryImporter
{
public:

  virtual void ImportGeometry(IGraphicsEngine* pRender, const Matrix4x4f& a_globalTransform);

};

class ColladaGeometryImporter : public IGeometryImporter
{
public:
  ColladaGeometryImporter(ColladaParser* a_parser) {m_pColladaParser = a_parser;}

protected:

  ColladaParser* m_pColladaParser;


};


class IMaterialImporter
{
public:
  IMaterialImporter(){}
  virtual ~IMaterialImporter(){}

  virtual float3 GetTransparency(std::map<string,string>& params) {return float3(0,0,0);}

protected:


};

class OpenColladaMaterialImporter : public IMaterialImporter
{
public:

  OpenColladaMaterialImporter(){}
  ~OpenColladaMaterialImporter(){}

  float3 GetTransparency(std::map<string,string>& params);

protected:

};





IMaterialImporter* CreateMaterialImporter(TiXmlNode* a_xmlRoot);
  


void ImportLightsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_lights,
                             const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter);

void ImportHydraMaterialsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_materials,
                                     vector<string> *material_names, vector<int>* mat_indices, ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter);

void ImportCamerasFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_cameras, 
                              Camera* camera, const Matrix4x4f& a_mat);


void ImportGeometryFromCollada(IGraphicsEngine* pRender, 
                               ColladaParser::ObjectDataList& a_geometry,
                               GeometryStorage& geomStorage, const Matrix4x4f& a_mTransform,
                               InstList& geometryAttribs);

void ReplaceMaterialsWithProfile(ColladaParser::ObjectDataList& a_materialsList, const std::string& a_profilePath, TiXmlElement* a_mat_lib);
void ReplaceLightsWithProfile(ColladaParser::ObjectDataList& a_lightsList, const std::string& a_profilePath, TiXmlElement* lib);
void ReplaceCamerasWithProfile(ColladaParser::ObjectDataList& a_camList, const std::string& a_profilePath);

HydraMaterial HydraMaterialFromStringMap(ColladaParser::ObjectDataList::iterator p, IGraphicsEngine* pRender, ITextureImporter* pTexImporter);
RAYTR::Light  HydraLightFromStringMap(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& a_mTransform);

void SaveImageToFile(const std::string& a_fileName, int w, int h, unsigned int* data);
void SaveHDRImageToFile(const std::string& a_fileName, int w, int h, float4* data);

int LoadTextureToRender(const std::string& a_fileName, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL);
void InitOpenIL();

