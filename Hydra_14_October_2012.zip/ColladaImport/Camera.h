#pragma once

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

using namespace MGML;

struct Camera : public MGML_MATH::SSE_Aligned_Object
{

  Camera() : pos(0,0,10,1) {}
  virtual ~Camera(){}
	
  virtual void Move(const vec4f& pos);
  virtual void SetRotation(const vec4f& rot);
  virtual void LookAt(const vec4f& pos, const vec4f& lookAt);
  
  virtual void SetPerspectiveProjection(float fovy, float aspect, float zNear, float zFar);
  
  virtual Matrix4x4f GetWorldMatrix() const;
  virtual Matrix4x4f GetViewMatrix() const;
  virtual Matrix4x4f GetProjectionMatrix() const { return mProjection;}
  
  vec4f pos;

protected:

  Matrix4x4f mWorld;
  Matrix4x4f mView;
  Matrix4x4f mProjection;

  void CreateFrustumMatrix(float result[16], float left, float right, float bottom, float top, float nearVal, float farVal);
	
};