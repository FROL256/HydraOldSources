#include "Camera.h"

void Camera::Move(const vec4f& move)
{
	pos += GetViewMatrix()*move;

  vec4f pos2 = pos;
  pos2 *= (-1); 
  pos2.w = 1;

  Matrix4x4f mt;
  mt.SetTranslate(pos2); mt.Transpose();

  mWorld = mt;
}

void Camera::LookAt(const vec4f& pos, const vec4f& lookAt)
{
  vec4f from = pos;
  vec4f to = lookAt;
 
  vec4f dir=from-to;
  vec4f a1(0,0,0,1);  // ��������� ��������
  vec4f a2(0,0,-1,1); // ������� ��������� �� 0,0,0 � 0,0,h2(��� � glu)
  vec4f a,b,c;
  a=a2-a1;
  b=to-from;    
  c=a->*b;
  float angle=acos(dot(a,b)/(a.len()*b.len()));

  Matrix4x4f mTranslate, mRot;
  mTranslate.SetTranslate(from);
  mRot.SetRotation(angle,c);

  RUN_TIME_ERROR("Camera::LookAt(2) not implemented");
}

void Camera::SetRotation(const vec4f& in_rot)
{
  Matrix4x4f mx,my,mz;

  vec3f r;
  r.x = MGML_MATH::DEG_TO_RAD(in_rot.x);
  r.y = MGML_MATH::DEG_TO_RAD(in_rot.y);
  r.z = MGML_MATH::DEG_TO_RAD(in_rot.z);
  mx.SetRotationX(r.x);
  my.SetRotationY(r.y);
  mz.SetRotationZ(r.z);

  mView = mz*my*mx;
}


void Camera::CreateFrustumMatrix(float result[16], float left, float right, float bottom, float top, float nearVal, float farVal)
{
  result[0] = 2.0f*nearVal/(right-left);
  result[1] = 0.0f;
  result[2] = 0.0f;
  result[3] = 0.0f;
  result[4] = 0.0f;
  result[5] = 2.0f*nearVal/(top-bottom);
  result[6] = 0.0f;
  result[7] = 0.0f;
  result[8] = (right+left)/(right-left);
  result[9] = (top+bottom)/(top-bottom);
  result[10] = -(farVal+nearVal)/(farVal-nearVal);
  result[11] = -1.0f;
  result[12] = 0.0f;
  result[13] = 0.0f;
  result[14] = -(2.0f*farVal*nearVal)/(farVal-nearVal);
  result[15] = 0.0f;
}

void Camera::SetPerspectiveProjection(float fovy, float aspect, float zNear, float zFar)
{
  float ymax = zNear * tanf(fovy * 3.141592654f / 360.0f);
  float ymin = -ymax;
  float xmin = ymin * aspect;
  float xmax = ymax * aspect;

  CreateFrustumMatrix(mProjection.L, xmin, xmax, ymin, ymax, zNear, zFar);
}

Matrix4x4f Camera::GetWorldMatrix() const
{
  return mWorld;
}


Matrix4x4f Camera::GetViewMatrix() const
{
  return mView;
}
