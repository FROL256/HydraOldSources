#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>
#include <il\il.h>
#include <il\ilu.h>


#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportCameras(ObjectDataList* pOut_list)
{
  ObjectDataList& plist = *pOut_list;
  plist.clear();


  TiXmlElement* cameras_lib = m_root->FirstChildElement("library_cameras");
  if(cameras_lib)
  {

    TiXmlNode* nextCameraInLib = 0;
    for(TiXmlNode* nextCameraInLib = cameras_lib->FirstChild("camera"); nextCameraInLib!=0; nextCameraInLib = cameras_lib->IterateChildren("camera", nextCameraInLib))
    {
      map<string,string> cameraParams; 
      // <camera id="Camera-camera" name="Camera-camera"> 
      // name: cameraParams["COLLADA_name"] = nextCameraInLib->ToElement()->Attribute("name");  
      cameraParams["id"] = nextCameraInLib->ToElement()->Attribute("id");    
      plist[ cameraParams["id"] ] = cameraParams;

    }

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      string cameraId = p->second["id"];
      string cam_url = "#" + p->second["id"];
      TiXmlElement* pCameraElement = FindElemByAttribute(cameras_lib, "camera", "id", cameraId);

      if(pCameraElement == 0)
        RUN_TIME_ERROR("Camera with id " + cameraId + "not found in COLLADA XML");

      TiXmlElement* pProjectionType = pCameraElement->FirstChildElement("optics")->FirstChildElement("technique_common")->FirstChildElement();

      p->second["projection_type"] = pProjectionType->ValueStr();

      for(TiXmlNode* pParam = pProjectionType->FirstChildElement(); pParam != 0; pParam = pProjectionType->IterateChildren(pParam))
      {
        TiXmlElement* pElem = pParam->ToElement();
        p->second[pElem->ValueStr()] = pElem->GetText();
      }

      string cut_camId;

      // cut tails
      //
      if(cameraId.substr(cameraId.size()-7,cameraId.size()) == "-camera")
        cut_camId = cameraId.substr(0,cameraId.size()-7);
      else if(cameraId.substr(cameraId.size()-4,cameraId.size()) == "-lib")
        cut_camId = cameraId.substr(0,cameraId.size()-4);
      else
        cut_camId = cameraId;
      //
      //RUN_TIME_ERROR("cameraId have incorrect tail");


      TiXmlElement* pScenes = m_root->FirstChildElement("library_visual_scenes");
      TiXmlNode* nextScene = 0;
      for(TiXmlNode* nextScene = pScenes->FirstChild("visual_scene"); nextScene!=0; nextScene = pScenes->IterateChildren("visual_scene", nextScene))
      {
        TiXmlElement* pCurrScene = nextScene->ToElement();
        for(TiXmlNode* nextNode = pCurrScene->FirstChild("node"); nextNode!=0; nextNode = pCurrScene->IterateChildren("node", nextNode))
        {

          //
          //
          if(nextNode->ToElement()->Attribute("id") == NULL)
          {
            p->second["matrix"] = MatrixToString(Matrix4x4f());
          }
          else if(nextNode->ToElement()->Attribute("id") == cut_camId)
          {
            Matrix4x4f mTransform = GetTransformFromNode(nextNode);
            p->second["matrix"] = MatrixToString(mTransform);
            p->second["translate"] = GetText(nextNode,"translate");
          }
          else if(nextNode->ToElement()->Attribute("id") == (cut_camId + "_Target"))
          {
            p->second["look_at"] = GetText(nextNode, "translate");
          }

        }
      }

    }


    //cerr << endl;
    //for(p=plist.begin();p!=plist.end();++p)
    //{
    //  cerr << "Collada cameras: "<< p->second["id"] << endl;
    //  map<string,string>::const_iterator attr;
    //  for(attr = p->begin(); attr!=p->end(); ++attr)
    //    cerr << attr->first.c_str() << ": " << attr->second.c_str() << endl; 
    //  cerr << "------------------------------------" << endl;
    //}
  }

}



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ReplaceCamerasWithProfile(ColladaParser::ObjectDataList& a_camList, const std::string& a_profilePath)
{

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportCamerasFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_cameras, Camera* camera, const Matrix4x4f& a_mat)
{
  ColladaParser::ObjectDataList::iterator p;

  for (p=a_cameras.begin(); p!=a_cameras.end(); ++p)
  {  
    if(p->second["matrix"] != "")
    {
      float4 cam_pos = float4(0,0,0,0);
      float4 look_at = float4(0,0,0,1);

      if(p->second["translate"]!="")
        cam_pos = to_float4(StringTo<float3>(p->second["translate"]),1);

      //Matrix4x4f cameraPosTransform = StringTo<Matrix4x4f>(p->second["matrix"]);
      //cam_pos = a_mat*cameraPosTransform*cam_pos;
    
      camera->pos = a_mat*cam_pos;

      //if(p->second["look_at"]!="")
      //  look_at = to_float4(StringTo<float3>(p->second["look_at"]),1);
      //look_at =  a_mat*cameraPosTransform*look_at;
      //camera->LookAt(cam_pos, look_at);


      //camera_matrix = a_mat*camera_matrix;
      //vec4f zero_vec (0,0,0,0);
      //camera->pos = camera_matrix.GetCol(3);
      //camera->world_matrix = camera_matrix;
      //camera->mrot = camera_matrix;
      //camera->mrot.SetCol(3, zero_vec);
      //camera->mrot.SetRow(3, zero_vec);
    }
    else
    {
      // ������ �� ���������
      // 

    }

  }

}


