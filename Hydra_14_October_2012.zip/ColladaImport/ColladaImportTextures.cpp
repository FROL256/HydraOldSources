//#define _WIN32
//#define IL_STATIC_LIB
//#define IL_USE_PRAGMA_LIBS

//#define _UNICODE
//#define IL_STATIC_LIB

#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>

#include <direct.h> // getcwd in WINDOWS

#include <boost/filesystem.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp>
#include <ctime>


using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportTextures(ObjectDataList* pOut_list)
{
  ObjectDataList& plist = *pOut_list;
  plist.clear();


  TiXmlElement* images_lib = m_root->FirstChildElement("library_images");
  if(images_lib)
  {

    TiXmlNode* nextImageInLib = 0;
    for(TiXmlNode* nextImageInLib = images_lib->FirstChild("image"); nextImageInLib!=0; 
                   nextImageInLib = images_lib->IterateChildren("image", nextImageInLib))
    {
      map<string,string> imageParams; 
      // <image id="__Metal_Corrogated_Shiny_1-image" name="__Metal_Corrogated_Shiny_1-image" format="JPEG" height=640 width=480 depth=1> 
      // name: imageParams["COLLADA_name"] = nextImageInLib->ToElement()->Attribute("name"); 
      // optional. format: imageParams["COLLADA_format"] = nextImageInLib->ToElement()->Attribute("format");
      // optional. height: imageParams["COLLADA_height"] = nextImageInLib->ToElement()->Attribute("height");
      // optional. width: imageParams["COLLADA_width"] = nextImageInLib->ToElement()->Attribute("width");
      // optional. depth: imageParams["COLLADA_depth"] = nextImageInLib->ToElement()->Attribute("depth");
      imageParams["id"] = nextImageInLib->ToElement()->Attribute("id");    
      plist[ imageParams["id"] ] = imageParams;

    }

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      string imageId = p->second["id"];
      TiXmlElement* pImageElement = FindElemByAttribute(images_lib, "image", "id", imageId);

      if(pImageElement == 0)
        RUN_TIME_ERROR("Image with id " + imageId + "not found in COLLADA XML");

      for(TiXmlNode* pParam = pImageElement->FirstChildElement(); pParam != 0; pParam = pImageElement->IterateChildren(pParam))
      {
        TiXmlElement* pElem = pParam->ToElement();
        p->second[pElem->ValueStr()] = pElem->GetText();
      }
    }

    //cerr << endl;
    //for(p=plist.begin();p!=plist.end();++p)
    //{
    //  cerr << "Collada images: "<< (*p)["id"] << endl;
    //  map<string,string>::const_iterator attr;
    //  for(attr = p->begin(); attr!=p->end(); ++attr)
    //    cerr << attr->first.c_str() << ": " << attr->second.c_str() << endl; 
    //  cerr << "------------------------------------" << endl;
    //}
  }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void InitOpenIL()
{
  ilInit();
  iluInit();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int LoadTextureToRender(const std::string& a_fileName, IGraphicsEngine* pRender, EmptyDataConverter* pConverter)
{
  ILuint imageName = ilGenImage();
  ilBindImage(imageName);

  if(!ilLoadImage(a_fileName.c_str()))
  {
    fprintf(stderr, "image %s don't exists or it has unknown format\n", a_fileName.c_str());
    ilDeleteImages(1, &imageName); 
    return INVALID_TEXTURE;
  }

  ILinfo ImageInfo;
  iluGetImageInfo(&ImageInfo);
  if( ImageInfo.Origin == IL_ORIGIN_UPPER_LEFT )
    iluFlipImage();

  //if(!ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE))
    //RUN_TIME_ERROR("image " + a_fileName + " have unknown pixel format, OpenIL can not convert it");

  int w   = ilGetInteger(IL_IMAGE_WIDTH);
  int h   = ilGetInteger(IL_IMAGE_HEIGHT);
  int bpp = ilGetInteger(IL_IMAGE_BYTES_PER_PIXEL);

  if(bpp > 1 && pConverter != NULL) // have alpha already, do not overwrite it! 
  {
    AlphaFromRedChannel* pAlphaConverter = dynamic_cast<AlphaFromRedChannel*>(pConverter);
    if(pAlphaConverter != NULL)
      pConverter = NULL; // kill alpha converter
  }

  if(bpp <= 4)
  {
    if(!ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE))
      RUN_TIME_ERROR("image " + a_fileName + " have unknown pixel format, OpenIL can not convert it");

    bpp = ilGetInteger(IL_IMAGE_BYTES_PER_PIXEL);
    ASSERT(bpp == 4);
  }
  else if(bpp <= 16)
  {
    if(!ilConvertImage(IL_RGBA, IL_FLOAT))
      RUN_TIME_ERROR("image " + a_fileName + " have unknown pixel format, OpenIL can not convert it");

    bpp = ilGetInteger(IL_IMAGE_BYTES_PER_PIXEL);
    ASSERT(bpp == 16);
  }


  int size = w*h*bpp;
  unsigned char* data = new unsigned char[size];


  int format = IL_UNSIGNED_BYTE;
  if(bpp == 16) format = IL_FLOAT;
  if(bpp == 8)  format = IL_UNSIGNED_SHORT;

  ilCopyPixels(0,0,0,w,h,bpp,IL_RGBA,format,data);
  ilDeleteImages(1,&imageName); 


  if(pConverter!=NULL)
    pConverter->ConvertData(data, w, h);

  int id = pRender->AddTexture(data, w, h, bpp); //  bpp can be used as format
  delete [] data;

  return id;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void SaveImageToFile(const std::string& a_fileName, int w, int h, unsigned int* data)
{
  ILenum Error;
  while ((Error = ilGetError()) != IL_NO_ERROR);

  ILuint imageID = ilGenImage();
  ilBindImage(imageID);

  ilTexImage(w,h,1,4,IL_RGBA,IL_UNSIGNED_BYTE,data);
  ilEnable(IL_FILE_OVERWRITE);
  ilSave(IL_PNG, a_fileName.c_str());

  while ((Error = ilGetError()) != IL_NO_ERROR)
    fprintf(stderr,"SaveImageToFile; \n OpenIL error, can save image: %d: %s\n", Error, iluErrorString(Error));

  ilDeleteImages(1, &imageID); 
  ilDisable(IL_FILE_OVERWRITE);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void SaveHDRImageToFile(const std::string& a_fileName, int w, int h, float4* data)
{
  ILenum Error;
  while ((Error = ilGetError()) != IL_NO_ERROR);

  ILuint imageID = ilGenImage();
  ilBindImage(imageID);

  ilTexImage(w,h,1,4,IL_RGBA,IL_FLOAT,data);
  ilEnable(IL_FILE_OVERWRITE);
  ilSave(IL_HDR, a_fileName.c_str());

  while ((Error = ilGetError()) != IL_NO_ERROR)
    fprintf(stderr,"SaveImageToFile; \n OpenIL error, can't save image: %d: %s\n", Error, iluErrorString(Error));

  ilDeleteImages(1, &imageID); 
  ilDisable(IL_FILE_OVERWRITE);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void BumpMapConverter::ConvertData(void* a_data, int w, int h)
{
  unsigned char* data = (unsigned char*)a_data;

  for(int i=0;i<w*h;i++)
  {
    unsigned int r = unsigned int(data[i*4+0]);
    unsigned int g = unsigned int(data[i*4+1]);
    unsigned int b = unsigned int(data[i*4+2]);

    unsigned int average = (r+g+b)/3;

    if(m_convertFlags[0])
      average = 255 - average;

    data[i*4+0] = unsigned char(average);
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void AlphaFromRedChannel::ConvertData(void* a_data, int w, int h)
{
  unsigned char* data = (unsigned char*)a_data;

  for(int i=0;i<w*h;i++)
    data[i*4+3] = data[i*4+0];
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaTextureImporter::GetPathToFolder(const std::string& pathToFile)
{
  int symbolsCount = 0;
  for(int i=pathToFile.size()-1;i>=0;i--)
  {
    if(pathToFile[i] == '\\' || pathToFile[i] == '/')
      break;
    symbolsCount++;
  }

  return pathToFile.substr(0,pathToFile.size() - symbolsCount);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaTextureImporter::ColladaTextureImporter() : m_chdirResult(-1), m_pathWasChanged(false)
{
  
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaTextureImporter::~ColladaTextureImporter()
{
  ResetCurrentPath();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaTextureImporter::GetAbsolutePath(const std::string& a_path)
{
  if(a_path == "")
    return "";

  std::string abs_path_str = "";
  std::string path = a_path;
  
  if(path.size() > 8 && path.substr(0,8) == "file:///")
    path = path.substr(8, path.size());

  else if(path.size() > 7 && path.substr(0,7) == "file://")
    path = path.substr(7, path.size());

  for(int i=0;i<path.size();i++)
  {
    if(path[i] == '\\')
      path[i] = '/';
  }

  boost::filesystem::path bst_path(path);
  boost::filesystem::path abs_path = system_complete(bst_path);

  return abs_path.string();
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int  ColladaTextureImporter::AddTextureIfExists(const std::string& a_path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter, bool muteWarning, bool a_displacementTexture)
{
  std::map<std::string, int>& cache = m_cache;
  std::string path = a_path;

  if(path != "")
  {
    std::string abs_path_str = GetAbsolutePath(path);

    if(cache.find(abs_path_str) == cache.end()) // do not load this texture again if we done this once
    {
      bool fileExists = false;
      fstream fin;
      fin.open(abs_path_str.c_str(), ios::in);
      if( fin.is_open() )
        fileExists=true;
      fin.close();

      int id = INVALID_TEXTURE;
      if(fileExists)
        id = LoadTextureToRender(abs_path_str, pRender, pConverter);
      else if(!muteWarning)
        std::cerr << "texture " + abs_path_str + " does not exists!" << std::endl;

      cache[abs_path_str] = id;
      return id;
    }
    else
      return cache[abs_path_str]; 
  }

  return INVALID_TEXTURE;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaTextureImporter::SetCurrentPathToMainFile(const std::string& pathToXML)
{
  char oldPath[256];
  getcwd(oldPath, 256);

  m_pathToXMLFolder = GetPathToFolder(pathToXML);
  m_chdirResult     = chdir(m_pathToXMLFolder.c_str());
  m_pathToXML       = pathToXML;
  m_oldPath         = std::string(oldPath);

  m_pathWasChanged = true;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaTextureImporter::ResetCurrentPath()
{
  if(m_pathWasChanged == false)
    return;

  if(m_chdirResult==0)
  {
    if(chdir(m_oldPath.c_str())!=0)
      std::cerr << "can't chdir back '.exe' dir, crap! perhaps some textures will not be loaded" << std::endl;
    else
      m_pathWasChanged = false;
  }
  else
    std::cerr << "can't chdir; perhaps some textures were not loaded" << std::endl;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
bool ITextureImporter::HeightFileHasChanged(const std::string& a_fileName, const std::string& a_fileName2)
{
  boost::filesystem::path p1(GetAbsolutePath(a_fileName));
  boost::filesystem::path p2(GetAbsolutePath(a_fileName2));

  if ( boost::filesystem::exists(p1) && boost::filesystem::exists(p1) )
  {
    std::time_t t1 = boost::filesystem::last_write_time(p1);
    std::time_t t2 = boost::filesystem::last_write_time(p2);

    return (t1 > t2);
  }
  
  return false;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int ColladaTextureImporter::GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex)
{
  std::map<std::string, int>& cache = m_normalMapCache;

  if(cache.find(pathToHeightTex) != cache.end())
  {
    return cache[pathToHeightTex];
  }
  else
  {
    std::cerr << "WARNING, missed normalmap for texture " << pathToHeightTex.c_str() << std::endl;
    int id = this->CalculateNormalMapFromDisplacement(heightTexId, pRender, pathToHeightTex);
    cache[pathToHeightTex] = id;
    return id;
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int ColladaTextureImporter::CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const string& pathToHeightTex)
{
  std::string pathWithoutExt   = pathToHeightTex.substr(0, pathToHeightTex.size()-4);
  std::string oldNormalmapPath = pathWithoutExt + "_normalmap_calculated.png";

  bool heightDataHasChanged = !HeightFileHasChanged(oldNormalmapPath,pathToHeightTex);

  int idCachedTex = this->AddTextureIfExists(oldNormalmapPath, pRender, NULL, true);
  if(idCachedTex!=INVALID_TEXTURE && !heightDataHasChanged)
  {
    std::cerr << "normalmap was loaded from normalmap cache" << std::endl;
    return idCachedTex;
  }

  typedef unsigned char uchar;

  uint w,h;
  pRender->GetTextureDesc(heightTexId, &w, &h, NULL);

  vec4ub* height = new vec4ub[w*h];
  pRender->GetTextureData(heightTexId, height);

  vec4ub* normalmapData = new vec4ub[w*h];

  for (uint y = 1; y < h-1; y++)
  {
    int offsetY = y*w;
    int offsetYPlusOne  = (y+1)*w;
    int offsetYMinusOne = (y-1)*w;

    for (uint x = 1; x < w-1; x++)
    {
      float diff[8];

      diff[0] = height[offsetY + x].x - height[offsetYMinusOne + x - 1].x;
      diff[1] = height[offsetY + x].x - height[offsetYMinusOne + x].x;
      diff[2] = height[offsetY + x].x - height[offsetYMinusOne + x + 1].x;
      diff[3] = height[offsetY + x].x - height[offsetY + x - 1].x;
      diff[4] = height[offsetY + x].x - height[offsetY + x + 1].x;
      diff[5] = height[offsetY + x].x - height[offsetYPlusOne + x - 1].x;
      diff[6] = height[offsetY + x].x - height[offsetYPlusOne + x].x;
      diff[7] = height[offsetY + x].x - height[offsetYPlusOne + x + 1].x;

      float scale = 255.0f;

      float3 v38[8];
      v38[0] = float3(-diff[0], -diff[0], scale);
      v38[1] = float3(0.f, -diff[1], scale);
      v38[2] = float3(diff[2], -diff[2], scale);
      v38[3] = float3(-diff[3], 0.f, scale);
      v38[4] = float3(diff[4], 0.f, scale);
      v38[5] = float3(-diff[5], diff[5], scale);
      v38[6] = float3(0.f, diff[6], scale);
      v38[7] = float3(diff[7], diff[7], scale);

      float3 res(0,0,0);
      for(int i=0;i<8;i++)
        res += v38[i];

      res.z *= 0.19f;
      res.x *= -1.0f;

      res = normalize(res);
      
      float3 cr;
      cr.x = 0.5*res.x + 0.5;
      cr.y = 0.5*res.y + 0.5;
      cr.z = res.z;

      normalmapData[offsetY + x] = vec4ub( uchar(cr.x*255.0f), uchar(cr.y*255.0f), uchar(cr.z*255.0f), 255);
    }
  }

  // borders
  //

  for(uint x=0;x<w;x++)
  {
    normalmapData[0*w+x]     = normalmapData[1*w+x];
    normalmapData[(h-1)*w+x] = normalmapData[(h-2)*w+x];
  }

  for(uint y=0;y<h;y++)
  {
    normalmapData[y*w+0]   = normalmapData[y*w+1];
    normalmapData[y*w+w-1] = normalmapData[y*w+w-2];
  }

  int id = pRender->AddTexture(normalmapData, w, h);

  // save image
  //
  vec4ub* normalmapData2 = new vec4ub[w*h];
  for (int y = 0; y < h; y++)
  {
    int offsetY  = y*w;
    int offset2Y = (h-y-1)*w;
 
    for (int x = 0; x < w; x++)
      normalmapData2[offset2Y+x] = normalmapData[offsetY+x];
  }

  // save calculated and old height images
  //
  ILenum Error;
  while ((Error = ilGetError()) != IL_NO_ERROR);

  ILuint imageID = ilGenImage();
  ilBindImage(imageID);

  std::string path = GetAbsolutePath(oldNormalmapPath);

  //
  //
  ilTexImage(w,h,1,4,IL_RGBA,IL_UNSIGNED_BYTE,normalmapData2);
  ilEnable(IL_FILE_OVERWRITE);
  ilSave(IL_PNG, path.c_str());

  while ((Error = ilGetError()) != IL_NO_ERROR)
    fprintf(stderr, "CalculateNormalMapFromDisplacement; \n OpenIL error, can't save normalmap: %d: %s\n", Error, iluErrorString(Error));

  ilDeleteImages(1, &imageID); 
  ilDisable(IL_FILE_OVERWRITE);
  // \\ save image

  delete [] height;
  delete [] normalmapData;
  delete [] normalmapData2;

  std::cerr << "normalmap was calculated" << std::endl;

  return id;
}

