#include "ColladaImport.h"
#include <algorithm>
#include <hash_map>
#include <il\il.h>
#include <il\ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaParser::ColladaParser()
{
  m_root = NULL;
  m_pHydraMatProfile = NULL;

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaParser::~ColladaParser()
{
  delete m_pHydraMatProfile;  m_pHydraMatProfile = NULL;
 
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::CreateExporterProfiles(TiXmlNode* root)
{

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::LoadXML(const std::string& a_fileName)
{
  m_doc.LoadFile(a_fileName,TIXML_ENCODING_UTF8);

  if(m_doc.Error())
    RUN_TIME_ERROR(std::string(m_doc.ErrorDesc()) + " " + a_fileName);

  m_lastXMLPath = a_fileName;
  //m_doc.ToLower(TIXML_ENCODING_UTF8);

  TiXmlHandle docHandle(&m_doc);
  TiXmlElement* root = m_root = docHandle.FirstChild( "COLLADA" ).Element();

  if(root->Attribute("version")!=NULL)
    cout <<"COLLADA version: " << root->Attribute("version") << endl;

  CreateExporterProfiles(root);

  //
  //
  TiXmlElement* node = NULL;
  
  if(root->FirstChildElement("asset")!= NULL)
    node = root->FirstChildElement("asset")->FirstChildElement("unit");


  m_globalTransform.Identity();

  DEBUG_PRINT("initial matrix: \n", m_globalTransform);

  if(node)
  {
    float scale = StringTo<float>(node->Attribute("meter"));
    Matrix4x4f mScale;
    mScale.SetScale(float3(scale, scale, scale));

    DEBUG_PRINT("scale matrix: \n", mScale);

    m_globalTransform = m_globalTransform*mScale;

    DEBUG_PRINT("transform(1) matrix: \n", m_globalTransform);
  }

  if(root->FirstChildElement("asset")!= NULL)
    node = root->FirstChildElement("asset")->FirstChildElement("up_axis");

  if(node)
  {
    // in RTE like in OpenGL Up axis is y; and z aim to you from the screen.
    //

    Matrix4x4f mRot;

    string upAxis = node->GetText(); 
    if(upAxis == "Y_UP")
      mRot.Identity(); // ���� ��� ��. X ������; Y �����; Z �� ��� �� ������.
    else if(upAxis == "Z_UP")
    {
      mRot = Matrix4x4f(1,0,0,0,
                        0,0,1,0,
                        0,-1,0,0,
                        0,0,0,1);
    }
    else if(upAxis == "X_UP")
    {
      // �� ��������� ���
      //
      mRot = Matrix4x4f(0,1,0,0,
                        -1,0,0,0,
                        0,0,1,0,
                        0,0,0,1);
    }
    else
      RUN_TIME_ERROR("incorrect UP axis in asset->up_axis node");
      

    m_globalTransform = m_globalTransform*mRot;
  }

  DEBUG_PRINT("transform(2) matrix: \n", m_globalTransform);

  int a = 2;
  //m_doc.Parse(,0,TIXML_ENCODING_UTF8);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::LoadXMLAndGetFirstElement(const std::string& a_profilePath, const std::string& a_str)
{
  if(a_profilePath=="")
    return NULL;

  m_doc.LoadFile(a_profilePath, TIXML_ENCODING_UTF8);

  if(m_doc.Error())
  {
    fprintf(stderr, "Can't load collada profile %s \n", (std::string(m_doc.ErrorDesc()) + " " + a_profilePath).c_str());
    return NULL;
  }

  TiXmlHandle docHandle(&m_doc);
  m_root = docHandle.FirstChild("COLLADA").Element();
  return m_root->FirstChildElement(a_str);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::GetElement(const std::string& a_name)
{
  if(m_root)
    return m_root->FirstChildElement(a_name);
  return NULL;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportSceneFromCollada(IGraphicsEngine* pRender, const std::string a_fileName, Camera* camera, const Matrix4x4f& a_mat, const std::string a_profilePath)
{
  cerr << "importing " + a_fileName << endl;

  ColladaParser      colladaParser;

  colladaParser.LoadXML(a_fileName);
  Matrix4x4f mGlobalTransform = a_mat*colladaParser.GetTransformMatrix();

  DEBUG_PRINT("scaled transform(3) matrix: \n", mGlobalTransform);

  ColladaParser::ObjectDataList data;

  // load collada profile
  //
  ColladaParser profileLoader;
  if(a_profilePath != "")
    profileLoader.LoadXML(a_profilePath);

  TiXmlElement* materials_lib = profileLoader.GetElement("library_materials");
  TiXmlElement* lights_lib    = profileLoader.GetElement("library_lights");
  
  ITextureImporter* pTexImporter  = new ColladaTextureImporter;
  IMaterialImporter* pMatImporter = CreateMaterialImporter(colladaParser.GetRoot());

  pTexImporter->SetCurrentPathToMainFile(colladaParser.GetLastParsedXML());

  cout << "Importing lights..." << endl;
  colladaParser.ImportLights(&data);
  ReplaceLightsWithProfile(data, a_profilePath, lights_lib);
  ImportLightsFromCollada(pRender, data, mGlobalTransform, pTexImporter);

  cout << "Importing materials..." << endl;
  colladaParser.ImportMaterials(&data);
  ReplaceMaterialsWithProfile(data, a_profilePath, materials_lib);
  
  GeometryStorage    geomStorage;

  ImportHydraMaterialsFromCollada(pRender, data, &geomStorage.mat_names, &geomStorage.mat_indices, pTexImporter, pMatImporter);

  pTexImporter->ResetCurrentPath();

  delete pTexImporter; pTexImporter = NULL;
  delete pMatImporter; pMatImporter = NULL;

  InstList instances;
  cout << "Importing geometry..." << endl;
  colladaParser.ImportGeometry(&data, &geomStorage.geom_data, &geomStorage.geom_indices, &instances);
  ImportGeometryFromCollada(pRender, data, geomStorage, mGlobalTransform, instances);

  cout << "Importing cameras..." << endl;
  colladaParser.ImportCameras(&data);
  ImportCamerasFromCollada(pRender, data, camera, mGlobalTransform);

  //ReplaceCamerasWithProfile();
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaParser::FindTexturePath(const ObjectDataList& list, const std::string& key, const std::string& val, const std::string& second_val) const
{
  for(ObjectDataList::const_iterator p = list.begin(); p!= list.end(); ++p)
  {
    ObjectData::const_iterator p2 = p->second.find(key);
    if(p2 != p->second.end() && p2->second == val)
    {
       ObjectData::const_iterator p3 = p->second.find(second_val);
       if(p3 != p->second.end())
         return p3->second;
       else
         return "";
    }
  }

  return "";
}



