#define MGML_GUARDIAN

//#define DRIVER_BUGS

#pragma warning(disable:4996) // ��������


#ifndef __CUDACC__

  #define WIN32_LEAN_AND_MEAN
//	#include <d3d9.h> 
	#include <string>
	#include <vector>
	#include <list>
	#include <map>
	#include <fstream>
	#include <algorithm>
	#include <windows.h>
	#include <glut.h>  

#else

typedef unsigned int UINT;
typedef unsigned char BYTE;

#define _RDTSC(ts) \
		__asm rdtsc \
		__asm mov DWORD PTR [ts], eax \
		__asm mov DWORD PTR [ts+4], edx

#endif

typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  BYTE;

//typedef unsigned short uint16;
//typedef unsigned int uint32;
//typedef unsigned long long int uint64;

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif

// if you want to disable SIMD operations just comment that
#ifndef __CUDACC__
	#ifndef MGML_MATH_SIMD_GUARDIAN
		#include "MGML_MATH_SIMD.h"
	#endif
#else
	#ifndef MGML_MATH_CUDA_SIMD_GUARDIAN
		#include "MGML_MATH_CUDA_SIMD.h" 
	#endif
#endif

#ifndef MGML_MATH_INTERSECTIONS_GUARDIAN
	#include "MGML_MATH_INTERSECTIONS.h"
#endif

#ifndef MGML_GRAPHICS
	#include "MGML_GRAPHICS.h" 
#endif


#ifndef __CUDACC__


  //#include "MGML_IMAGE.h"
  #include "MGML_ERROR.h"
  #include "MGML_MEMORY.h" 

  #include <map>
  //#include "MGML_MESH.h"

	//#ifndef MGML_IMAGE_GUARDIAN
	//	#include "MGML_IMAGE.h"
	//#endif

  #include "shared_ptr.h"

#endif



namespace IMAGES
{
	class IMAGE;
};



namespace MGML
{

	typedef MGML_MATH::VECTOR<2,float> vec2f;
	typedef MGML_MATH::VECTOR<3,float> vec3f;
	typedef MGML_MATH::VECTOR<4,float> vec4f;

	typedef MGML_MATH::VECTOR<2,double> vec2d;
	typedef MGML_MATH::VECTOR<3,double> vec3d;
	typedef MGML_MATH::VECTOR<4,double> vec4d;

	typedef MGML_MATH::VECTOR<2,int> vec2i;
	typedef MGML_MATH::VECTOR<3,int> vec3i;
	typedef MGML_MATH::VECTOR<4,int> vec4i;

	typedef MGML_MATH::VECTOR<2,UINT> vec2ui;
	typedef MGML_MATH::VECTOR<3,UINT> vec3ui;
	typedef MGML_MATH::VECTOR<4,UINT> vec4ui;

	typedef MGML_MATH::VECTOR<2,unsigned char> vec2ub;
	typedef MGML_MATH::VECTOR<3,unsigned char> vec3ub;
	typedef MGML_MATH::VECTOR<4,unsigned char> vec4ub;

	typedef MGML_MATH::MATRIX<2,2,float>  Matrix2x2f;
	typedef MGML_MATH::MATRIX<3,3,float>  Matrix3x3f;
	typedef MGML_MATH::MATRIX<3,4,float>  Matrix3x4f;
	typedef MGML_MATH::MATRIX<4,3,float>  Matrix4x3f;
	typedef MGML_MATH::MATRIX<4,4,float>  Matrix4x4f;

	typedef MGML_MATH::QUATERNION<float>  quatf;
	typedef MGML_MATH::QUATERNION<double> quatd;
	typedef MGML_MATH::QUATERNION<int>    quati;
 
	typedef MGML_MATH::LINE<3,float>	    Line3f;
	typedef MGML_MATH::LINE<4,float>	    Line4f;

	typedef MGML_MATH::RAY<4,float>	      Ray4f;
	typedef MGML_MATH::RAY<3,float>	      Ray3f;

	typedef MGML_MATH::SEGMENT<4,float>	  Segment4f;
	typedef MGML_MATH::SEGMENT<3,float>	  Segment3f;

  typedef MGML_MATH::SPHERE<3,float>	  Sphere3f;
	typedef MGML_MATH::SPHERE<4,float>	  Sphere4f;

  typedef MGML_MATH::PACKED_SPHERE3<float>  PackedSphere3f;
	typedef MGML_MATH::PACKED_SPHERE3<double> PackedSphere3d;

	typedef MGML_MATH::AABB<4,float>	    AABB4f;
	typedef MGML_MATH::AABB<3,float>	    AABB3f;
	typedef MGML_MATH::BOX<4,float>			  Box4f;
	typedef MGML_MATH::BOX<3,float>			  Box3f;

	typedef MGML_MATH::PLANE<3,float>	    Plane3f;
	typedef MGML_MATH::PLANE<4,float>	    Plane4f;

	typedef MGML_MATH::TRIANGLE<3,float>  Triangle3f;
	typedef MGML_MATH::TRIANGLE<4,float>  Triangle4f;

	typedef MGML_GRAPHICS::VERTEX<3,float>  Vertex3f;
	typedef MGML_GRAPHICS::VERTEX<4,float>  Vertex4f;

  typedef MGML_GRAPHICS::VERTEX<3,double> Vertex3d;
	typedef MGML_GRAPHICS::VERTEX<4,double>	Vertex4d;

	typedef MGML_GRAPHICS::VERTEX<3,int>	 Vertex3i;
	typedef MGML_GRAPHICS::VERTEX<4,int>	 Vertex4i;

	typedef MGML_GRAPHICS::MATERIAL<3> Material;
	typedef MGML_GRAPHICS::Triangle Triangle;


	typedef MGML_GRAPHICS::D3D_HAL		D3D_HAL;	
	typedef MGML_GRAPHICS::OpenGL_HAL	OpenGL_HAL;


	//typedef IMAGES::IMAGE	            Image;
    
	/*
	typedef MGML_GRAPHICS::MESH<4,
								float,
								MGML_GRAPHICS::OpenGL_HAL,
								Triangle>		Mesh;
	 */

#ifndef __CUDACC__

	inline universal_call vec3f to_vec3f(const vec4f& rhs)
	{
		return vec3f(rhs.M[0],rhs.M[1],rhs.M[2]);
	}

  static Matrix4x4f SafeInverse(const Matrix4x4f& m1)
  {
    float tmp[12]; // temp array for pairs
    Matrix4x4f m;

    // calculate pairs for first 8 elements (cofactors)
    //
    tmp[0]  = m1.M[2][2] * m1.M[3][3];
    tmp[1]  = m1.M[2][3] * m1.M[3][2];
    tmp[2]  = m1.M[2][1] * m1.M[3][3];
    tmp[3]  = m1.M[2][3] * m1.M[3][1];
    tmp[4]  = m1.M[2][1] * m1.M[3][2];
    tmp[5]  = m1.M[2][2] * m1.M[3][1];
    tmp[6]  = m1.M[2][0] * m1.M[3][3];
    tmp[7]  = m1.M[2][3] * m1.M[3][0];
    tmp[8]  = m1.M[2][0] * m1.M[3][2];
    tmp[9]  = m1.M[2][2] * m1.M[3][0];
    tmp[10] = m1.M[2][0] * m1.M[3][1];
    tmp[11] = m1.M[2][1] * m1.M[3][0];

    // calculate first 8 m1.Ments (cofactors)
    //
    m.M[0][0]  = tmp[0] * m1.M[1][1] + tmp[3] * m1.M[1][2] + tmp[4]  * m1.M[1][3];
    m.M[0][0] -= tmp[1] * m1.M[1][1] + tmp[2] * m1.M[1][2] + tmp[5]  * m1.M[1][3];
    m.M[1][0]  = tmp[1] * m1.M[1][0] + tmp[6] * m1.M[1][2] + tmp[9]  * m1.M[1][3];
    m.M[1][0] -= tmp[0] * m1.M[1][0] + tmp[7] * m1.M[1][2] + tmp[8]  * m1.M[1][3];
    m.M[2][0]  = tmp[2] * m1.M[1][0] + tmp[7] * m1.M[1][1] + tmp[10] * m1.M[1][3];
    m.M[2][0] -= tmp[3] * m1.M[1][0] + tmp[6] * m1.M[1][1] + tmp[11] * m1.M[1][3];
    m.M[3][0]  = tmp[5] * m1.M[1][0] + tmp[8] * m1.M[1][1] + tmp[11] * m1.M[1][2];
    m.M[3][0] -= tmp[4] * m1.M[1][0] + tmp[9] * m1.M[1][1] + tmp[10] * m1.M[1][2];
    m.M[0][1]  = tmp[1] * m1.M[0][1] + tmp[2] * m1.M[0][2] + tmp[5]  * m1.M[0][3];
    m.M[0][1] -= tmp[0] * m1.M[0][1] + tmp[3] * m1.M[0][2] + tmp[4]  * m1.M[0][3];
    m.M[1][1]  = tmp[0] * m1.M[0][0] + tmp[7] * m1.M[0][2] + tmp[8]  * m1.M[0][3];
    m.M[1][1] -= tmp[1] * m1.M[0][0] + tmp[6] * m1.M[0][2] + tmp[9]  * m1.M[0][3];
    m.M[2][1]  = tmp[3] * m1.M[0][0] + tmp[6] * m1.M[0][1] + tmp[11] * m1.M[0][3];
    m.M[2][1] -= tmp[2] * m1.M[0][0] + tmp[7] * m1.M[0][1] + tmp[10] * m1.M[0][3];
    m.M[3][1]  = tmp[4] * m1.M[0][0] + tmp[9] * m1.M[0][1] + tmp[10] * m1.M[0][2];
    m.M[3][1] -= tmp[5] * m1.M[0][0] + tmp[8] * m1.M[0][1] + tmp[11] * m1.M[0][2];

    // calculate pairs for second 8 m1.Ments (cofactors)
    //
    tmp[0]  = m1.M[0][2] * m1.M[1][3];
    tmp[1]  = m1.M[0][3] * m1.M[1][2];
    tmp[2]  = m1.M[0][1] * m1.M[1][3];
    tmp[3]  = m1.M[0][3] * m1.M[1][1];
    tmp[4]  = m1.M[0][1] * m1.M[1][2];
    tmp[5]  = m1.M[0][2] * m1.M[1][1];
    tmp[6]  = m1.M[0][0] * m1.M[1][3];
    tmp[7]  = m1.M[0][3] * m1.M[1][0];
    tmp[8]  = m1.M[0][0] * m1.M[1][2];
    tmp[9]  = m1.M[0][2] * m1.M[1][0];
    tmp[10] = m1.M[0][0] * m1.M[1][1];
    tmp[11] = m1.M[0][1] * m1.M[1][0];

    // calculate second 8 m1.Ments (cofactors)
    //
    m.M[0][2]  = tmp[0]  * m1.M[3][1] + tmp[3]  * m1.M[3][2] + tmp[4]  * m1.M[3][3];
    m.M[0][2] -= tmp[1]  * m1.M[3][1] + tmp[2]  * m1.M[3][2] + tmp[5]  * m1.M[3][3];
    m.M[1][2]  = tmp[1]  * m1.M[3][0] + tmp[6]  * m1.M[3][2] + tmp[9]  * m1.M[3][3];
    m.M[1][2] -= tmp[0]  * m1.M[3][0] + tmp[7]  * m1.M[3][2] + tmp[8]  * m1.M[3][3];
    m.M[2][2]  = tmp[2]  * m1.M[3][0] + tmp[7]  * m1.M[3][1] + tmp[10] * m1.M[3][3];
    m.M[2][2] -= tmp[3]  * m1.M[3][0] + tmp[6]  * m1.M[3][1] + tmp[11] * m1.M[3][3];
    m.M[3][2]  = tmp[5]  * m1.M[3][0] + tmp[8]  * m1.M[3][1] + tmp[11] * m1.M[3][2];
    m.M[3][2] -= tmp[4]  * m1.M[3][0] + tmp[9]  * m1.M[3][1] + tmp[10] * m1.M[3][2];
    m.M[0][3]  = tmp[2]  * m1.M[2][2] + tmp[5]  * m1.M[2][3] + tmp[1]  * m1.M[2][1];
    m.M[0][3] -= tmp[4]  * m1.M[2][3] + tmp[0]  * m1.M[2][1] + tmp[3]  * m1.M[2][2];
    m.M[1][3]  = tmp[8]  * m1.M[2][3] + tmp[0]  * m1.M[2][0] + tmp[7]  * m1.M[2][2];
    m.M[1][3] -= tmp[6]  * m1.M[2][2] + tmp[9]  * m1.M[2][3] + tmp[1]  * m1.M[2][0];
    m.M[2][3]  = tmp[6]  * m1.M[2][1] + tmp[11] * m1.M[2][3] + tmp[3]  * m1.M[2][0];
    m.M[2][3] -= tmp[10] * m1.M[2][3] + tmp[2]  * m1.M[2][0] + tmp[7]  * m1.M[2][1];
    m.M[3][3]  = tmp[10] * m1.M[2][2] + tmp[4]  * m1.M[2][0] + tmp[9]  * m1.M[2][1];
    m.M[3][3] -= tmp[8]  * m1.M[2][1] + tmp[11] * m1.M[2][2] + tmp[5]  * m1.M[2][0];

    // calculate matrix inverse
    //
    float k = 1.0f / (m1.M[0][0] * m.M[0][0] + m1.M[0][1] * m.M[1][0] + m1.M[0][2] * m.M[2][0] + m1.M[0][3] * m.M[3][0]);

    for(int i=0;i<16;i++)
      m.L[i] *= k;

    return m;
  }

#else

  inline universal_call vec3f to_vec3f(const vec4f& rhs)
	{
    vec3f res;
    res.set(rhs.M[0],rhs.M[1],rhs.M[2]);
		return res;
	}
#endif

	#ifdef __CUDACC__


	#endif

  class Float16Compressor
  {
    typedef int int32_t;
    typedef unsigned int uint32_t;
    typedef unsigned short uint16_t; 

    union Bits
    {
      float f;
      int32_t si;
      uint32_t ui;
    };

    static int const shift = 13;
    static int const shiftSign = 16;

    static int32_t const infN = 0x7F800000; // flt32 infinity
    static int32_t const maxN = 0x477FE000; // max flt16 normal as a flt32
    static int32_t const minN = 0x38800000; // min flt16 normal as a flt32
    static int32_t const signN = 0x80000000; // flt32 sign bit

    static int32_t const infC = infN >> shift;
    static int32_t const nanN = (infC + 1) << shift; // minimum flt16 nan as a flt32
    static int32_t const maxC = maxN >> shift;
    static int32_t const minC = minN >> shift;
    static int32_t const signC = signN >> shiftSign; // flt16 sign bit

    static int32_t const mulN = 0x52000000; // (1 << 23) / minN
    static int32_t const mulC = 0x33800000; // minN / (1 << (23 - shift))

    static int32_t const subC = 0x003FF; // max flt32 subnormal down shifted
    static int32_t const norC = 0x00400; // min flt32 normal down shifted

    static int32_t const maxD = infC - maxC - 1;
    static int32_t const minD = minC - subC - 1;

  public:

    static uint16_t compress(float value)
    {
      Bits v, s;
      v.f = value;
      uint32_t sign = v.si & signN;
      v.si ^= sign;
      sign >>= shiftSign; // logical shift
      s.si = mulN;
      s.si = s.f * v.f; // correct subnormals
      v.si ^= (s.si ^ v.si) & -(minN > v.si);
      v.si ^= (infN ^ v.si) & -((infN > v.si) & (v.si > maxN));
      v.si ^= (nanN ^ v.si) & -((nanN > v.si) & (v.si > infN));
      v.ui >>= shift; // logical shift
      v.si ^= ((v.si - maxD) ^ v.si) & -(v.si > maxC);
      v.si ^= ((v.si - minD) ^ v.si) & -(v.si > subC);
      return v.ui | sign;
    }

    static float decompress(uint16_t value)
    {
      Bits v;
      v.ui = value;
      int32_t sign = v.si & signC;
      v.si ^= sign;
      sign <<= shiftSign;
      v.si ^= ((v.si + minD) ^ v.si) & -(v.si > subC);
      v.si ^= ((v.si + maxD) ^ v.si) & -(v.si > maxC);
      Bits s;
      s.si = mulC;
      s.f *= v.si;
      int32_t mask = -(norC > v.si);
      v.si <<= shift;
      v.si ^= (s.si ^ v.si) & mask;
      v.si |= sign;
      return v.f;
    }
  };


};





///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
namespace MGML_TESTS
{
#ifndef __CUDACC__

 void test_all(std::ostream& out);
 void test_mgml_types_sizes(std::ostream& out);
 void test_mgml_mat_vec_op(std::ostream& out);
 void test_mgml_vec_func(std::ostream& out);
 void test_operators(std::ostream& out);
 void test_kd_tree(std::ostream& out);

 

#endif
};