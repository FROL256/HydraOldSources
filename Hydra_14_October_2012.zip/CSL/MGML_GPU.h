#define MGML_GPU_GUARDIAN

namespace RAYTR
{

  static const float PI = ((float)3.141592654f);

#ifndef __CUDACC__

  #ifndef MGML_GUARDIAN
    #include "MGML.h"
  #endif

  typedef MGML::vec4f float4;
  typedef MGML::vec3f float3;
  typedef MGML::vec2f float2;

  typedef MGML::vec4i int4;
  typedef MGML::vec3i int3;
  typedef MGML::vec2i int2;

  typedef MGML_MATH::VECTOR<2,unsigned short> ushort2;
  typedef MGML_MATH::VECTOR<3,unsigned short> ushort3;
  typedef MGML_MATH::VECTOR<4,unsigned short> ushort4;

  typedef MGML_MATH::VECTOR<2,short> short2;
  typedef MGML_MATH::VECTOR<3,short> short3;
  typedef MGML_MATH::VECTOR<4,short> short4;

  static inline float3 make_float3(float a, float b, float c) { return float3(a,b,c);}
  static inline float4 make_float4(float a, float b, float c, float d) { return float4(a,b,c,d);}

  static float3 to_float3(const float4& v) {return float3(v.x,v.y,v.z);}
  static float4 to_float4(const float3& v, float w) {return float4(v.x,v.y,v.z,w);}

  static inline float fmaxf(float a, float b) { return MGML_MATH::MAX<float>(a,b); } 
  static inline float fminf(float a, float b) { return MGML_MATH::MIN<float>(a,b); } 

  static inline float  clamp(float  x, float a, float b) {return fminf(fmaxf(x,a),b);}
  static inline float3 clamp(float3 x, float a, float b) { return float3(fminf(fmaxf(x.x,a),b), fminf(fmaxf(x.y,a),b), fminf(fmaxf(x.z,a),b)); }

  static inline float  coordAbsMax (const float3 u) { return fmaxf(fmaxf(fmaxf(abs(u.x), abs(u.y)), abs(u.z)), 1.0f); }

  static inline float3 PointEpsilon(const float3 u) { return make_float3(1e-6f*fmaxf(abs(u.x),1.0f), 1e-6f*fmaxf(abs(u.y),1.0f), 1e-6f*fmaxf(abs(u.z),1.0f)); }

#else

  #include "float4.cuh"

  #define universal_call __host__ __device__


  template<bool>
  struct STATIC_ASSERT;

  template<>
  struct STATIC_ASSERT<true> {};

  #include <stdlib.h>
  #include <stdio.h>
  #include <string.h>
  #include <math.h>

  #ifdef __CUDACC__ 

    #ifdef __DEVICE_EMULATION__
      #undef ASSERT 
      #define ASSERT(_expression) \
      if(!(_expression)) { fprintf(stderr,"Assertion failed. File: %s, Line %d\n",__FILE__,__LINE__); \
      abort(); }
    #else
      #define ASSERT(_expression) ((void)0)
    #endif

  #endif

  typedef unsigned int uint;
  typedef unsigned short ushort;

  #define EPSILON_E5M (1e-5f)
  #define EPSILON_E6M (1e-6f)
  #define EPSILON_E7M (1e-7f)
  #define EPSILON_E8M (1e-8f)

  template <class T> inline universal_call T MIN(T a, T b){ return a <= b ? a : b; }
  template <class T> inline universal_call T MAX(T a, T b){ return a > b ? a : b; }

  template <class T> inline universal_call T MIN(T a,T b,T c)
  {
    if(a <= b && a <= c)
      return a;
    else if(b <= a && b <= c)
      return b;
    else
      return c;
  }

  template <class T> inline universal_call T MAX(T a,T b,T c)
  { 
    if(a >= b && a >= c)
      return a;
    else if(b >= a && b >= c)
      return b;
    else
      return c;
  }


  static void RunTimeError(const char* file, int line, const char* msg)
  {
    fprintf(stderr, "Run time error at %s, line %d : %s \n",file,line,msg);
    fflush(stderr);
    abort();
  }

  #undef RUN_TIME_ERROR
  #define RUN_TIME_ERROR(e) (RunTimeError(__FILE__,__LINE__,(e)))

  #define VERIFY(cond) if(!(cond)) RUN_TIME_ERROR("Verification failed");

  #undef  HOST_ASSERT
  #ifdef  NDEBUG
    #define HOST_ASSERT(_expression) ((void)0)
  #else
    #define HOST_ASSERT(_expression) if(!(_expression)) RUN_TIME_ERROR("Assertion failed ");
  #endif

#endif

  struct float4x3
  {
    float4 row[3];
  };

  struct float4x4
  {
    float4 row[4];
  };


  static universal_call float3 operator*(const float4x3& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
    return res;
  }

  static universal_call float4 operator*(const float4x4& m, const float4& v)
  {
    float4 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w*v.w;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w*v.w;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w*v.w;
    res.w = m.row[3].x*v.x + m.row[3].y*v.y + m.row[3].z*v.z + m.row[3].w*v.w;
    return res;
  }

  static universal_call float3 operator*(const float4x4& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
    return res;
  }

  static universal_call float3 mul3x4(const float4x3& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
    return res;
  }

  static universal_call float3 mul3x3(const float4x3& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
    return res;
  }

  struct float3x3
  {
    float3 row[3];
  };

  static universal_call float3x3 make_float3x3(const float3& a, const float3& b, const float3& c)
  {
    float3x3 m;
    m.row[0] = a;
    m.row[1] = b;
    m.row[2] = c;
    return m;
  }

  static universal_call float3x3 make_float3x3_by_columns(const float3& a, const float3& b, const float3& c)
  {
    float3x3 m;
    m.row[0].x = a.x;
    m.row[1].x = a.y;
    m.row[2].x = a.z;

    m.row[0].y = b.x;
    m.row[1].y = b.y;
    m.row[2].y = b.z;

    m.row[0].z = c.x;
    m.row[1].z = c.y;
    m.row[2].z = c.z;
    return m;
  }

  static universal_call float3 operator*(const float3x3& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
    return res;
  }

  static universal_call float3x3 operator*(const float3x3& m1, const float3x3& m2)
  {
    float3 column1 = m1*make_float3(m2.row[0].x, m2.row[1].x, m2.row[2].x);
    float3 column2 = m1*make_float3(m2.row[0].y, m2.row[1].y, m2.row[2].y);
    float3 column3 = m1*make_float3(m2.row[0].z, m2.row[1].z, m2.row[2].z);

    return make_float3x3_by_columns(column1, column2, column3);
  }

  static universal_call float3x3 inverse(const float3x3& a)
  {
    float det = a.row[0].x * (a.row[1].y * a.row[2].z - a.row[1].z * a.row[2].y) -
                a.row[0].y * (a.row[1].x * a.row[2].z - a.row[1].z * a.row[2].x) +
                a.row[0].z * (a.row[1].x * a.row[2].y - a.row[1].y * a.row[2].x);

    float3x3 b;
    b.row[0].x =  (a.row[1].y * a.row[2].z - a.row[1].z * a.row[2].y);
    b.row[0].y = -(a.row[0].y * a.row[2].z - a.row[0].z * a.row[2].y);
    b.row[0].z =  (a.row[0].y * a.row[1].z - a.row[0].z * a.row[1].y);
    b.row[1].x = -(a.row[1].x * a.row[2].z - a.row[1].z * a.row[2].x);
    b.row[1].y =  (a.row[0].x * a.row[2].z - a.row[0].z * a.row[2].x);
    b.row[1].z = -(a.row[0].x * a.row[1].z - a.row[0].z * a.row[1].x);
    b.row[2].x =  (a.row[1].x * a.row[2].y - a.row[1].y * a.row[2].x);
    b.row[2].y = -(a.row[0].x * a.row[2].y - a.row[0].y * a.row[2].x);
    b.row[2].z =  (a.row[0].x * a.row[1].y - a.row[0].y * a.row[1].x);

    float s = 1.0f/det;
    b.row[0] *= s;
    b.row[1] *= s;
    b.row[2] *= s;

    return b;
  }

  struct PackedShort2
  {
    universal_call void SetX(int a_x) { data = (data & 0xFFFF0000) | (a_x & 0x0000FFFF);}
    universal_call void SetY(int a_y) { data = (data & 0x0000FFFF) | ( (a_y << 16) & 0xFFFF0000);}

    universal_call int GetX() { return data & 0x0000FFFF;}
    universal_call int GetY() { return (data & 0xFFFF0000) >> 16;}
    
    universal_call void IncX() {data++;}
    universal_call void IncY() {data += 0x00010000;}

    universal_call void DecX() {data--;}
    universal_call void DecY() {data -= 0x00010000;}

    int data;
  };


}

