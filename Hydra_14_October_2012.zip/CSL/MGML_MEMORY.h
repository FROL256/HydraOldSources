// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once

#include <valarray>
#include <vector>
#include <queue>

#include "MGML_ERROR.h"

using namespace MGML_ERROR;

namespace MGML_MEMORY
{


  template<class T>
  class DynamicArray 
  {
  public:
    DynamicArray(){ m_data = AllocData(4); m_capacity = 4; m_size = 0; }
    DynamicArray(const int a_size) {m_data = AllocData(a_size); m_capacity = a_size; m_size = a_size;}
    DynamicArray(const DynamicArray& rhs)
    {
      m_data = NULL;
      *this = rhs;
    }

    DynamicArray& operator=(const DynamicArray& rhs) 
    {
      if(this==&rhs)
        return *this;

      m_size = rhs.size();
      m_capacity = rhs.capacity();
      FreeData();
      m_data = AllocData(m_capacity);
      for(int i=0;i<m_size;i++)
        m_data[i] = rhs[i];

      return *this;
    }

    virtual ~DynamicArray(){FreeData(); m_capacity = 0; m_size = 0;}

    typedef T* iterator;
    typedef const T* const_iterator;
    typedef T value_type;


    inline int size() const {return m_size;}
    inline int capacity() const {return m_capacity;}

    inline void push_back(const T& a_data)
    {
      if (m_size >= m_capacity)
        reserve(MemoryExpansionFactor()*m_capacity);

      m_data[m_size] = a_data;
      m_size++;
    }

    void reserve(int size)
    {
      if(size < m_capacity)
        return;

      T* new_data = AllocData(size);
      memcpy(new_data, m_data, sizeof(T)*min(m_size,size));
      FreeData();
      m_data = new_data;
      m_capacity = size;
    }

    void resize(int size)
    {
      if(size > m_capacity)
        reserve(MemoryExpansionFactor()*size);

      m_size = size;
    }

    void clear() {resize(0);}

    inline T& operator[](int i) 
    {
      #ifndef NDEBUG
      if(i>=m_size)
      {
        int a = 2;
      }
      #endif
      ASSERT(i<m_size);
      return m_data[i];
    }

    inline const T& operator[](int i) const
    {
      #ifndef NDEBUG
      if(i>=m_size)
      {
        int a = 2;
      }
      #endif
      ASSERT(i<m_size);
      return m_data[i];
    }

    const_iterator begin() const {return m_data;}
    iterator begin() {return m_data;}

    const_iterator end() const {return m_data+m_size;}
    iterator end() {return m_data+m_size;}


  protected:

    float MemoryExpansionFactor()
    {
      if(m_capacity < 64)
        return 4;
      else if(m_capacity < 1024)
        return 2;
      else
        return 1.5f;
    }

    T* AllocData(int size)
    {
      if(MPMG::TypesEqual<T,char>::RET)
      {
        T* data = (T*)_aligned_malloc(size*sizeof(T), 16); 
        if(data==NULL)
          RUN_TIME_ERROR("DynamicArray(aligned), out of memory");
        return data;
      }
      else
        return new T[size];
    }

    void FreeData()
    {
      if(MPMG::TypesEqual<T,char>::RET)
        _aligned_free(m_data);
      else
        delete [] m_data;
      m_data = NULL;
    }

    T* m_data;
    int m_capacity;
    int m_size;

  };





////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////  Matrix  ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

template
<
	int n,						// ����������� ������� (2D 3D 4D ���.)
	class T,					// ��� ���������
	class TR,					// ��� �����. ������ (�������� �� ��������� T&)
	template <class> class vec	// �����, �������������� ��� ������������� �������
>
class Matrix
{

public:

	template<int m> class slice;
	template<int m> class slice_iter;
	template<int m> class cslice_iter;

	Matrix(const size_t _s[n]) 
	{
		for(int i=0,len = 1;i<n;i++)
			s[i] = _s[i];
		v = new vec<T>(len_arr());
		set_strides();
	}
	Matrix(const Matrix& m2) 
	{
		for(int i=0;i<n;i++)  s[i] = 0;
		v = new vec<T>(m2.const_array().size());
		*this = m2;
		set_strides();
	}
	Matrix()
	{
		for(int i=0,len = 1;i<n;i++) 
			s[i] =0;
		v = new vec<T>(0);
		set_strides();
	}
	~Matrix(){ delete v;}

	Matrix<n,T,TR,vec>& operator=(const Matrix<n,T,TR,vec>& m2);

	inline size_t len_arr() const
	{
		size_t len = 1;
		for(int i=0;i<n;i++) len*=s[i];
		return len;
	}

	
	void resize(size_t N[n]) 
	{ 
		delete v;
		size_t len = 1;
		for(int i=0;i<n;i++)
		{
			s[i] = N[i];
			len*=s[i];
		}
		v = new vec<T>(len); 
		set_strides();
	}

	template<int coord> 
	inline size_t size() const {return s[coord];}
	
	template<int coord>
	inline size_t stride() const {return strides[coord];}

	size_t offset(const size_t _s[n]) const
	{
		register int offset = 0;
		for(int i=0;i<n-1;i++) 
			offset += strides[i]*_s[i];
		offset += _s[n-1];

		return offset;
	}

	inline vec<T>& array() {return *v;}
	inline const vec<T>& const_array() const {return *v;}

	inline slice_iter<n-1> row(size_t i)
	 { return slice_iter<n-1>(v,slice<n-1>(i*stride<0>(),s+1));  }

	inline cslice_iter<n-1> row(size_t i) const
	 { return cslice_iter<n-1>(v,slice<n-1>(i*stride<0>(),s+1));  }

	inline TR operator()(const size_t _s[n]) { return array()[offset(_s)]; }
	inline T  operator()(const size_t _s[n]) const { return const_array()[offset(_s)]; }

	inline slice_iter<n-1> operator[](size_t i) {return row(i);}
	inline cslice_iter<n-1> operator[](size_t i) const {return row(i);}

	template<int m>
	class slice
	{
	public:

		inline slice(size_t start_,const size_t* ss): _start(start_)
		 { for(int i=0;i<m;i++) sz[i]=ss[i]; }

		inline size_t stride() const
		{
			size_t res=1;
			for(int i=1;i<m;i++)
				res *= sz[i];
			return res;
		}

		inline size_t size() const
		{
			size_t res=1;
			for(int i=0;i<m;i++) res *= sz[i];
			return res;
		}

		inline size_t start() const { return _start; }
		inline const size_t* get_sz() const {return sz;}

	protected:
		size_t _start;
		size_t sz[m];

	};

	template<int m>
	class slice_iter
	{
		typedef slice_iter<m-1> TypeRef;

	public:
		inline slice_iter(vec<T>* _v,const slice<m>& _s): v(_v),s(_s) {}

		inline slice_iter<m>& operator++(){curr++;return *this;}
		inline TypeRef operator[](size_t i) {return ref(curr = i);}
		inline TypeRef operator()(size_t i) {return ref(curr = i);}
		inline TypeRef operator*(){return ref(curr);}
		inline size_t size() {return s.size();}
	
	protected:
		vec<T>*  v;
		slice<m> s;
		size_t	 curr;

		inline TypeRef ref(size_t i) const 
		 { return TypeRef(v,slice<m-1>(i*s.stride() + s.start(),s.get_sz()+1) ); }
	};

	template<>
	class slice_iter<1>
	{

	public:
		slice_iter(vec<T>* _v,const slice<1>& _s): v(_v),s(_s) {}
		
		inline slice_iter<1>& operator++(){curr++;return *this;}
		inline TR operator[](size_t i) {return ref(curr = i);}
		inline TR operator()(size_t i) {return ref(curr = i);}
		inline TR operator*(){return ref(curr);}
		inline size_t size() {return s.size();}

	protected:
		vec<T>*  v;
		slice<1> s;
		size_t	 curr;

		inline TR ref(size_t i) const { return (*v)[s.start() + i*s.stride()]; }
	};

	template<int m>
	class cslice_iter
	{
		typedef cslice_iter<m-1> TypeRef;

	public:
		inline cslice_iter(const vec<T>* _v,const slice<m>& _s): v(_v),s(_s) {}

		inline cslice_iter<m>& operator++(){curr++;return *this;}
		inline TypeRef operator[](size_t i) {return ref(curr = i);}
		inline TypeRef operator()(size_t i) {return ref(curr = i);}
		inline TypeRef operator*(){return ref(curr);}
		inline size_t size() {return s.size();}
	
	protected:
		const vec<T>*  v;
		slice<m> s;
		size_t	 curr;

		inline TypeRef ref(size_t i) const 
		 { return TypeRef(v,slice<m-1>(i*s.stride() + s.start(),s.get_sz()+1) ); }
	};

	template<>
	class cslice_iter<1>
	{

	public:
		cslice_iter(const vec<T>* _v,const slice<1>& _s): v(_v),s(_s) {}
		
		inline slice_iter<1>& operator++(){curr++;return *this;}
		inline T operator[](size_t i) {return ref(curr = i);}
		inline T operator()(size_t i) {return ref(curr = i);}
		inline T operator*(){return ref(curr);}
		inline size_t size() {return s.size();}

	protected:
		const vec<T>*  v;
		slice<1> s;
		size_t	 curr;

		inline T ref(size_t i) const { return (*v)[s.start() + i*s.stride()]; }
	};

protected:

	inline void set_strides()
	{
		for(int i=0;i<n-1;i++)
		{
			strides[i] = 1;
			for(int j=i+1;j<n;j++) 
				strides[i]*= s[j];
		}
	}

	vec<T>*		 v; 
	size_t		 s[n];
	size_t       strides[n-1];

};



// 
//
template<class T, int threadId = 0>
class FastList
{
public:

  class Elem
  {
  public:

    friend class FastList;
  protected:
    T m_data;
    Elem* m_next;
  };

  class iterator
  {
  public:

    iterator() {m_elem = 0;}
    iterator(Elem* a_elem) { m_elem = a_elem; }

    bool operator==(const iterator& a_it) const { return (a_it.m_elem == m_elem); }
    bool operator!=(const iterator& a_it) const { return !(*this == a_it); }

    iterator operator++()
    {
      ASSERT(m_elem!=0);
      m_elem = m_elem->m_next;
      return iterator(m_elem);
    }

    iterator operator++(int)
    {
      iterator prev = *this;
      ++(*this);
      return prev;
    }

    T* operator->() const 
    {
      ASSERT(m_elem!=0);
      return &(m_elem->m_data);
    }

    T& operator*() 
    { 
      ASSERT(m_elem!=0);
      return m_elem->m_data;
    }

    friend class const_iterator;
    friend class FastList;

  protected:
    Elem* m_elem;
  };


  class const_iterator
  {
  public:

    const_iterator() {m_elem = 0;}
    const_iterator(const Elem* a_elem) { m_elem = a_elem; }
    const_iterator(const iterator& p) { m_elem = p.m_elem; }

    bool operator==(const_iterator a_it) const { return (a_it.m_elem == m_elem); }
    bool operator!=(const_iterator a_it) const { return !(*this == a_it); }

    const_iterator operator++()
    {
      ASSERT(m_elem!=0);
      m_elem = m_elem->m_next;
      return const_iterator(m_elem);
    }

    const_iterator operator++(int)
    {
      iterator prev = *this;
      ++(*this);
      return prev;
    }

    const T* operator->() const 
    {
      ASSERT(m_elem!=0);
      return &(m_elem->m_data);
    }

    const T& operator*() const 
    { 
      ASSERT(m_elem!=0);
      return m_elem->m_data;
    }


  protected:
    const Elem* m_elem;
  };


  FastList() { m_head = 0; m_size=0; }

  inline bool empty() const {return (m_head == 0);}
  inline void Reset() { m_head = 0;m_size = 0;} // you must Reset all your lists after Free call, or delete them 

  inline const_iterator begin() const { return const_iterator(m_head);}
  inline const_iterator end() const { return const_iterator(0);}

  inline iterator begin() { return iterator(m_head);}
  inline iterator end() { return iterator(0);}

  inline void push_front(const T& a_data)
  {
    Elem *newElem = m_freeList;

#ifndef NDEBUG
    if(newElem==NULL)
      std::cerr << "out of memory for " << typeid(this).name() << std::endl;
#endif
    ASSERT(newElem!=0);
    
    m_freeList = newElem->m_next;
    newElem->m_next = m_head;
    newElem->m_data = a_data;
    m_head = newElem;
    m_size++;
  }

  inline void pop_front()
  {
    ASSERT(m_head != 0);

    Elem* next = m_head->m_next;
    m_head->m_next = m_freeList;
    m_freeList = m_head;
    m_head = next; 
    m_size--;
  }

  void clear()
  {
    while(m_head != 0)
      pop_front();

    m_size = 0;
  }

  size_t size() const
  {
    return m_size;
  }

  inline void erase_next(iterator p)
  {
     Elem* next = p.m_elem->m_next;
     ASSERT(next!=NULL);

     // (p -> next -> next-next) =>  (p -> next-next)
     //
     p.m_elem->m_next = next->m_next;
     
     // add next to free memory list 
     //
     next->m_next = m_freeList;
     m_freeList = next;
     m_size--;
  }

  static void Allocate(int a_size)
  {
    m_memory = (Elem*)_aligned_malloc(a_size*sizeof(Elem), 16); //new Elem[a_size];
    m_totalMemory = a_size*sizeof(Elem);
    T defaultData;

    //if(TypesEqual<T,int>::RET)
      //defaultData = 0;

    for(int i=0;i<a_size-1;i++)
    {
      if(!TypesEqual<T,int>::RET)
        m_memory[i].m_data = defaultData;
      m_memory[i].m_next = m_memory + i + 1;
    }
    m_memory[a_size-1].m_next = 0;

    m_freeList = m_memory;
    
  }

  static void Free() 
  { 
    //memset(m_memory,0xBB,m_totalMemory);
    //delete [] m_memory; 
    _aligned_free(m_memory);
    m_memory = 0;
  }

  static int GetFreeMemoryInElements()
  {
    int counter = 0;
    Elem* elem = m_freeList;

    while(elem->m_next!=NULL)
    {
      counter++;
      elem = elem->m_next;
    }

    return counter;
  }

  static float GetPercentOfFreeMemory()
  {
    float free_mem = (float)GetFreeMemoryInElements()*sizeof(Elem);
    float total_mem = (float)m_totalMemory;
    return free_mem/total_mem;
  }

protected:
  static Elem* m_memory;
  static Elem* m_freeList;
  static int m_totalMemory;

  Elem* m_head;
  int m_size;
};

template<class T, int threadId> typename FastList<T,threadId>::Elem* FastList<T,threadId>::m_memory = NULL;
template<class T, int threadId> typename FastList<T,threadId>::Elem* FastList<T,threadId>::m_freeList = NULL;
template<class T, int threadId> int FastList<T,threadId>::m_totalMemory = 0;


template<class PrimitiveList>
struct ArraySlice
{
  typedef typename PrimitiveList::iterator   iterator;
  typedef typename PrimitiveList::value_type value_type;

  ArraySlice(){}
  ArraySlice(iterator a_begin, iterator a_end, int currAxis = 0) 
  {
    m_begin = a_begin; 
    m_end = a_end;
    m_axis = currAxis;
    m_lastSplitIndex = 0;
  }

  
  inline int axis() const {return m_axis;}
  inline int size() const {return (int)(m_end-m_begin);}

  inline const value_type& operator[](int i) const {return *(m_begin+i);}
  inline value_type& operator[](int i) {return *(m_begin+i);}

  inline iterator& begin() { return m_begin; }
  inline iterator& end() { return m_end; }

  iterator m_begin;
  iterator m_end;
  int m_axis;
  int m_lastSplitIndex;
};




};

template<class T>
class Pool
{
public:

  Pool()
  {
    m_data=NULL;
    m_capacity=0;
    m_size=0;
  }

  virtual ~Pool()
  {
    delete [] m_data;
    m_data=NULL;
  }

  void reserve(int size)
  {
    delete [] m_data;
    m_data = new T[size];
    m_capacity=size;
    m_size=0;
  }

  void reserve(int size, const T& defaultValue)
  {
    delete [] m_data;
    m_data = new T[size];
    for(int i=0;i<size;i++)
      m_data[i] = defaultValue;

    m_capacity=size;
    m_size=0;
  }

  void resize(int a_size) 
  {
    if(a_size < 0 || a_size > m_capacity)
      RUN_TIME_ERROR(std::string("Pool, resize, out of ragne ") + typeid(T).name());

    m_size = a_size; 
  }

  int size() const {return m_size;}
  int capacity() const {return m_capacity;}

  inline T* New()
  {
    if (m_size >= m_capacity)
      RUN_TIME_ERROR(std::string("out of memory for ") + typeid(T).name());

    T* elem = m_data+m_size;
    m_size++;
    return elem;
  }

  inline T& operator[](int i) 
  {
    ASSERT(i<m_size);
    return m_data[i];
  }

  inline const T& operator[](int i) const
  {
    ASSERT(i<m_size);
    return m_data[i];
  }

protected:
  T* m_data;
  int m_capacity;
  int m_size;
};


template <typename T,
unsigned long T_ALIGNMENT=16,
unsigned long T_BLOCKSIZE=8>
class aligned_BlockAlloc : public std::allocator<T>
{
private:
  typedef std::allocator<T>  BASE_TYPE;

public:
  aligned_BlockAlloc() {}
  aligned_BlockAlloc& operator=(const aligned_BlockAlloc &r){
    BASE_TYPE::operator=(r);
    return *this;
  }

  pointer allocate(size_type n, const void *hint){
    pointer p = NULL;
    unsigned long byteCount = sizeof(T) * n;
    unsigned long byteCountLeft = byteCount % T_BLOCKSIZE;
    if(byteCountLeft){
      byteCount += T_BLOCKSIZE -  byteCountLeft;
    }
    if(!hint){
      p = reinterpret_cast<pointer>(_aligned_malloc(byteCount,T_ALIGNMENT));
    }else{
      p = reinterpret_cast<pointer>(_aligned_realloc((void*)hint,byteCount,T_ALIGNMENT));
    }
    return p;
  }

  void deallocate(pointer p, size_type n){
    _aligned_free(p);
  }

  void construct(pointer p, const T &val){
    new(p) T(val);
  }

  void destroy(pointer p){
    p->~T();
  }
};



////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////  Binary_Tree  ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////


template<class NodeData, class Allocator = std::allocator<NodeData> >
class Binary_Tree
{
public:


	struct Node
	{
		Node()
		{
			m_Data = 0xFFFFFFFF;
			data = NodeData();
		}
		

		void SetLeftOffset(unsigned int a_Left)
		{
			register int mask = a_Left & 0x3fffffff;
			register int m_Data2 = m_Data & 0xc0000000;
			m_Data = m_Data2 | mask;
		}


		unsigned int GetLeftOffset() const 
			{ return m_Data & 0x3FFFFFFF;}

		unsigned int GetRightOffset() const 
			{ return GetLeftOffset()+1;}


		bool HasLeftChild() const
			{ return !((m_Data & 0x80000000) >> 31); } // one bit for right sub-tree empty flag

		bool HasRightChild() const
			{ return !((m_Data & 0x40000000) >> 30); } // one bit for right sub-tree empty flag

		bool Leaf() const 
			{ return !HasLeftChild() & !HasRightChild();}  // one bit to know - is there a leaf?


		void SetLeftChildEmpty(bool arg)
		{
			register int mask = ((int)arg) << 31;
			register int m_Data2 = m_Data & 0x7fffffff;
			m_Data = m_Data2 | mask;
		}

		void SetRightChildEmpty(bool arg)
		{
			register int mask = ((int)arg) << 30;
			register int m_Data2 = m_Data & 0xbfffffff;
			m_Data = m_Data2 | mask;
		}


		NodeData data;
	protected:
		int m_Data;
		
	};
	

	Binary_Tree()
	{
		nodes_array.resize(0);
		nodes_top = 1;
		//Node* pThisNode = getCurrNode();
	}

	size_t GetRootOffset() {return 0;}

	const Node& GetNodeByOffset(size_t offset) const
	{
		ASSERT(offset < nodes_top);
		return nodes_array[offset];
	}

	Node& GetNodeByOffset(size_t offset)
	{
		ASSERT(offset < nodes_top);
		return nodes_array[offset];
	}

	void Print(std::ostream& out)
	{
		out << "Tree: " << endl;
		print(out,GetRootOffset(),0);
	}

	struct compare_simple
	{
		int operator()(const NodeData& n1, const NodeData& n2)
			{ return n1 < n2;}
	};

	template<class Compare>
	void Build(NodeData* a_DataArray, unsigned int a_Num, Compare cmp)
	{
		nodes_array.resize(a_Num*3-1);
		
		tmp_arr.resize(0);
		tmp_arr.reserve(a_Num);

		for(size_t i=0;i<a_Num;i++)
			tmp_arr.push_back(a_DataArray[i]);

		std::sort(tmp_arr.begin(),tmp_arr.end(),cmp);

//		std::vector<NodeData>::const_iterator p;
//		for(p=tmp_arr.begin();p!=tmp_arr.end();++p)
//		{
//			std::cout << *p <<" ";
//		}
//		std::cout << std::endl;

		subdivide(0,tmp_arr.size()-1,GetRootOffset());

		Reorganize_memory_layout_BFS(nodes_queue);

		tmp_arr.resize(0);
	}

	std::vector<Node>& GetNodesArray() { return nodes_array; }

protected:
	std::vector<Node> nodes_array;
	size_t nodes_top;

	std::vector<NodeData> tmp_arr;
	
	// for advanced memory layout
	std::queue<size_t> nodes_queue;

	Binary_Tree(const Binary_Tree& rhs){}
	Binary_Tree& operator=(const Binary_Tree& rhs)
		{return *this;}

	void print(std::ostream& out,size_t offs,int deep)
	{
		for(int i=0;i<deep;i++)
			out << " ";

		const Node& node = GetNodeByOffset(offs);
		out <<"offs: " << offs << ", data: " << node.data << std::endl;

		if(node.HasLeftChild())
			print(out,node.GetLeftOffset(),deep+2);

		if(node.HasRightChild())
			print(out,node.GetRightOffset(),deep+2);
		
	}

	size_t NewNodePair()
	{
		if(nodes_top+2 >= nodes_array.size())
			RUN_TIME_ERROR("Binary_Tree, too many elements");

		Node nodes[2];
		nodes_array[nodes_top+0] = nodes[0];
		nodes_array[nodes_top+1] = nodes[1];
		nodes_top+=2;

		return nodes_top-2;
	}

	void subdivide(size_t begin, size_t end, size_t curr_offset)
	{
		size_t size = end-begin+1;
		if(size == 1)
		{
			Node* pThisNode = &GetNodeByOffset(curr_offset);
			pThisNode->data = tmp_arr[begin];
			pThisNode->SetRightChildEmpty(true);
			pThisNode->SetLeftChildEmpty(true);

			return;
		}
		else if(size == 2)
		{
			Node* pThisNode    = &GetNodeByOffset(curr_offset);
			size_t left_offset = NewNodePair();
			pThisNode->data    = tmp_arr[begin+1];
			pThisNode->SetRightChildEmpty(true);
			pThisNode->SetLeftChildEmpty(false);
			pThisNode->SetLeftOffset((unsigned int)left_offset);

			Node* pLeftNode	   = &GetNodeByOffset(left_offset);
			pLeftNode->data    = tmp_arr[begin];
			pLeftNode->SetRightChildEmpty(true);
			pLeftNode->SetLeftChildEmpty(true);

			return;
		}
		//	throw Error("Error in Binary_Tree building algorithm");
	
		size_t	median		= begin + (size-1)/2;
		size_t	begin_left	= begin;
		size_t	end_left	= median-1;
		size_t	begin_right	= median+1;
		size_t	end_right	= end;

		Node* pThisNode     = &GetNodeByOffset(curr_offset);
		size_t left_offset  = NewNodePair();
		size_t right_offset = left_offset+1;

		
		pThisNode->SetRightChildEmpty(false);
		pThisNode->SetLeftChildEmpty(false);
		pThisNode->SetLeftOffset((unsigned int)left_offset);
		pThisNode->data = tmp_arr[median];

		subdivide(begin_left, end_left,	left_offset);
		subdivide(begin_right,end_right,right_offset);
		
	}

	void BFS_traversal(size_t a_Offset, std::queue<size_t>& a_Queue)
	{
		std::queue<size_t> s_Queue;

		s_Queue.push(a_Offset);
		while(!s_Queue.empty())
		{

			const Node& node = GetNodeByOffset(s_Queue.front());
			a_Queue.push(s_Queue.front());
			s_Queue.pop();


			if(node.HasLeftChild())
			{
				s_Queue.push(node.GetLeftOffset());
				s_Queue.push(node.GetRightOffset());
			}
		}
	}

	void Reorganize_memory_layout_BFS(std::queue<size_t>& a_Queue)
	{
		size_t offs = GetRootOffset();
		BFS_traversal(offs,a_Queue);
		std::vector<Node>	nodes_array2(nodes_top);
		std::vector<size_t>	new_by_old_offs(nodes_top);

		ASSERT(a_Queue.size() == nodes_top);

		size_t i = 0;
		while(!a_Queue.empty())
		{
			size_t new_offs = i;
			size_t old_offs = a_Queue.front();
			a_Queue.pop();

			new_by_old_offs[old_offs] = (unsigned int)new_offs;
			i++;
		}

		for(size_t i = 0;i<nodes_top;i++)
		{
			size_t new_offs = new_by_old_offs[i]; 
			nodes_array2[new_offs] = nodes_array[i];

			size_t old_left_offs = nodes_array[i].GetLeftOffset();
			size_t new_left_offs;
			if(nodes_array[i].HasLeftChild())
				new_left_offs = new_by_old_offs[old_left_offs];
			else
				new_left_offs = 0xFFFFFFFF;
			
			nodes_array2[new_offs].SetLeftOffset((unsigned int)new_left_offs);
		}

		nodes_array.resize(nodes_array2.size());
		for(size_t i=0;i<nodes_array2.size();i++)
			nodes_array[i] = nodes_array2[i];
	}
};




////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////  Matrix  ///////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
//======================================================================================================
// 
//======================================================================================================
template
<
	int n,
	class T,					// ��� ���������
	class TR,					// ��� �����. ��������� (T ��� T&)
	template <class> class vec	// �����, �������������� ��� ������������� �������
>
MGML_MEMORY::Matrix<n,T,TR,vec>& MGML_MEMORY::Matrix<n,T,TR,vec>::operator=(const Matrix<n,T,TR,vec>& m2)
{
	if(v->size() < m2.const_array().size())	 
	{
		delete v;
		int n1 = m2.const_array().size();
		v = new vec<T>(m2.const_array().size());
	}
	
	*v  = m2.const_array();

	for(int i=0;i<n;i++)
		s[i] = m2.s[i];

	set_strides();

	return *this;
}

