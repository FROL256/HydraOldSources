#define MGML_GPU_GUARDIAN

namespace RAYTR
{

#ifndef __CUDACC__

  #ifndef MGML_GUARDIAN
    #include "../CSL/MGML.h"
  #endif

  typedef MGML::vec4f float4;
  typedef MGML::vec3f float3;
  typedef MGML::vec2f float2;

  typedef MGML::vec4i int4;
  typedef MGML::vec3i int3;
  typedef MGML::vec2i int2;

  static inline float3 make_float3(float a, float b, float c) { return float3(a,b,c);}
  static inline float4 make_float4(float a, float b, float c, float d) { return float4(a,b,c,d);}

  static float3 to_float3(const float4& v) {return float3(v.x,v.y,v.z);}
  static float4 to_float4(const float3& v, float w) {return float4(v.x,v.y,v.z,w);}

#else

  #include "float4.cuh"

  #define universal_call __host__ __device__


  template<bool>
  struct STATIC_ASSERT;

  template<>
  struct STATIC_ASSERT<true> {};

  #include <stdlib.h>
  #include <stdio.h>
  #include <string.h>
  #include <math.h>

  #ifdef __CUDACC__ 

    #ifdef __DEVICE_EMULATION__
      #undef ASSERT 
      #define ASSERT(_expression) \
      if(!(_expression)) { fprintf(stderr,"Assertion failed. File: %s, Line %d\n",__FILE__,__LINE__); \
      abort(); }
    #else
      #define ASSERT(_expression) ((void)0)
    #endif

  #endif

  typedef unsigned int uint;
  typedef unsigned short ushort;

  #define EPSILON_E5M (1e-5f)
  #define EPSILON_E6M (1e-6f)
  #define EPSILON_E7M (1e-7f)
  #define EPSILON_E8M (1e-8f)

  template <class T> inline universal_call T MIN(T a, T b){ return a <= b ? a : b; }
  template <class T> inline universal_call T MAX(T a, T b){ return a > b ? a : b; }

  template <class T> inline universal_call T MIN(T a,T b,T c)
  {
    if(a <= b && a <= c)
      return a;
    else if(b <= a && b <= c)
      return b;
    else
      return c;
  }

  template <class T> inline universal_call T MAX(T a,T b,T c)
  { 
    if(a >= b && a >= c)
      return a;
    else if(b >= a && b >= c)
      return b;
    else
      return c;
  }


  static void RunTimeError(const char* file, int line, const char* msg)
  {
    fprintf(stderr, "Run time error at %s, line %d : %s \n",file,line,msg);
    fflush(stderr);
    abort();
  }

  #undef RUN_TIME_ERROR
  #define RUN_TIME_ERROR(e) (RunTimeError(__FILE__,__LINE__,(e)))

  #define VERIFY(cond) if(!(cond)) RUN_TIME_ERROR("Verification failed");

  #undef  HOST_ASSERT
  #ifdef  NDEBUG
    #define HOST_ASSERT(_expression) ((void)0)
  #else
    #define HOST_ASSERT(_expression) if(!(_expression)) RUN_TIME_ERROR("Assertion failed ");
  #endif

#endif

  struct float3x4
  {
    float4 row[3];
  };

  static universal_call float3 operator*(const float3x4& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
    return res;
  }

  static universal_call float3 mul3x4(const float3x4& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
    return res;
  }

  static universal_call float3 mul3x3(const float3x4& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
    return res;
  }

  struct float3x3
  {
    float3 row[3];
  };

  static universal_call float3 operator*(const float3x3& m, const float3& v)
  {
    float3 res;
    res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
    res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
    res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
    return res;
  }

  struct PackedShort2
  {
    universal_call void SetX(int a_x) { data = (data & 0xFFFF0000) | (a_x & 0x0000FFFF);}
    universal_call void SetY(int a_y) { data = (data & 0x0000FFFF) | ( (a_y << 16) & 0xFFFF0000);}

    universal_call int GetX() { return data & 0x0000FFFF;}
    universal_call int GetY() { return (data & 0xFFFF0000) >> 16;}
    
    universal_call void IncX() {data++;}
    universal_call void IncY() {data += 0x00010000;}

    universal_call void DecX() {data--;}
    universal_call void DecY() {data -= 0x00010000;}

    int data;
  };

}
