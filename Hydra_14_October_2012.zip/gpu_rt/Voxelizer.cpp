#include "Common_Graphics_Engine.h"
#include "Voxelizer.h"

struct VoxelData // for Anton and his custom needs
{
  enum {EMPTY = 1};

  VoxelData() { m_flags = EMPTY;}
  bool Empty() const { return (m_flags & EMPTY);}
 
  int m_flags; // please use bit fields, either 'bit flags' to store boolean values
};



typedef unsigned char uint8;


uint8 DownSampler(uint8 data[8])
{
  uint8 res = 0;

  for(int i=0;i<8;i++)
    if(data[i] != 0)
      res = 1;

  return res;
}




VoxelStorage<unsigned char>& Common_Graphics_Engine::VoxelizeAllGeometry()
{
  std::cout << "voxelization has began ..." << std::endl;
  
  AABB3f twickedBox = AABB3f(m_bBox.vmin - PointEpsilon(m_bBox.vmin),  m_bBox.vmax + PointEpsilon(m_bBox.vmax));

  m_voxelData.Resize(64,64,64);
  m_voxelData.SetBoundingBox(twickedBox);

  Array3D<uint8>& voxels = m_voxelData.GetArrayMipLevel(0);

  for(int x=0;x<64;x++)
    for(int y=0;y<64;y++)
      for(int z=0;z<64;z++)
        voxels(x,y,z) = 0;

  VoxelizeAllSpheres();
  VoxelizeAllTriangles();

  m_voxelData.GenerateMips(DownSampler);

  std::cout << "voxelization has finished." << std::endl;

  return m_voxelData;
}

template<class Data>
void RasterizeSphereTo3DArray(const Sphere4f& a_sph, VoxelStorage<Data>& voxelStorage)
{
  AABB3f box = voxelStorage.GetBoundingBox();

  Array3D<uint8>& voxels = voxelStorage.GetArrayMipLevel(0);

  float3 spherePos   = to_float3(a_sph.pos);
  float  sphereRadius = a_sph.r;

  float3 sphBBoxVmin = spherePos - float3(a_sph.r, a_sph.r, a_sph.r);
  float3 sphBBoxVmax = spherePos + float3(a_sph.r, a_sph.r, a_sph.r);

  float3 t1 = (sphBBoxVmin - box.vmin)/(box.vmax-box.vmin);
  float3 t2 = (sphBBoxVmax - box.vmin)/(box.vmax-box.vmin);

  float3   startVoxelf = t1*float3(voxels.size().x, voxels.size().y, voxels.size().z);
  float3   endVoxelf   = t2*float3(voxels.size().x, voxels.size().y, voxels.size().z);

  int3     startVoxel = int3(startVoxelf.x, startVoxelf.y, startVoxelf.z);
  int3     endVoxel   = int3(endVoxelf.x+0.5f, endVoxelf.y+0.5f,   endVoxelf.z+0.5f);

  if(startVoxel.x == endVoxel.x) endVoxel.x = MGML_MATH::MIN<int>(endVoxel.x+1, voxels.size().x-1);
  if(startVoxel.y == endVoxel.y) endVoxel.y = MGML_MATH::MIN<int>(endVoxel.y+1, voxels.size().y-1);
  if(startVoxel.z == endVoxel.z) endVoxel.z = MGML_MATH::MIN<int>(endVoxel.z+1, voxels.size().z-1);

  float voxelSize = (box.vmax.x - box.vmin.x)/float(voxels.size().x);

  for(int x=startVoxel.x; x<endVoxel.x; x++)
  {
    for(int y=startVoxel.y; y<endVoxel.y; y++)
    {
      for(int z=startVoxel.z; z<endVoxel.z; z++)
      {
        AABB3f voxelBox;

        voxelBox.vmin = float3( box.vmin.x + x*voxelSize, box.vmin.y + y*voxelSize, box.vmin.z + z*voxelSize);
        voxelBox.vmax = voxelBox.vmin + 1.0f*float3(voxelSize,voxelSize,voxelSize);

        if(length(voxelBox.vmin - spherePos) < sphereRadius && length(voxelBox.vmax - spherePos) < sphereRadius)
          ;
        else if(MGML_MATH::Intersect<AABB3f, Sphere3f>::exec(voxelBox, Sphere3f(spherePos, sphereRadius)) )
          voxels(x,y,z) = 1;

      }
    }
  }

}



void Common_Graphics_Engine::VoxelizeAllSpheres()
{
  for(int sphId = 0; sphId < m_spheres.size(); sphId++)
    RasterizeSphereTo3DArray<uint8>(m_spheres[sphId], m_voxelData);
}


// slow implementation, waiting for Anton's fast rasterizer
//
template<class Data>
void RasterizeTriangleTo3DArray(const float3& A, const float3& B, const float3& C, VoxelStorage<Data>& voxelStorage)
{
  AABB3f box = voxelStorage.GetBoundingBox();

  Array3D<uint8>& voxels = voxelStorage.GetArrayMipLevel(0);

  AABB3f triBox;
  triBox.include(A);
  triBox.include(B);
  triBox.include(C);

  typedef MGML_MATH::TRIANGLE<3,float> MyTriangle;
  MyTriangle tri(A,B,C);

  float3 t1 = (triBox.vmin - box.vmin)/(box.vmax-box.vmin);
  float3 t2 = (triBox.vmax - box.vmin)/(box.vmax-box.vmin);

  float3   startVoxelf = t1*float3(voxels.size().x, voxels.size().y, voxels.size().z);
  float3   endVoxelf   = t2*float3(voxels.size().x, voxels.size().y, voxels.size().z);

  int3     startVoxel = int3(startVoxelf.x, startVoxelf.y, startVoxelf.z);
  int3     endVoxel   = int3(endVoxelf.x+0.5f, endVoxelf.y+0.5f,   endVoxelf.z+0.5f);

  if(startVoxel.x == endVoxel.x) endVoxel.x = MGML_MATH::MIN<int>(endVoxel.x+1, voxels.size().x-1);
  if(startVoxel.y == endVoxel.y) endVoxel.y = MGML_MATH::MIN<int>(endVoxel.y+1, voxels.size().y-1);
  if(startVoxel.z == endVoxel.z) endVoxel.z = MGML_MATH::MIN<int>(endVoxel.z+1, voxels.size().z-1);

  float voxelSize = (box.vmax.x - box.vmin.x)/float(voxels.size().x);

  for(int x=startVoxel.x; x<endVoxel.x; x++)
  {
    for(int y=startVoxel.y; y<endVoxel.y; y++)
    {
      for(int z=startVoxel.z; z<endVoxel.z; z++)
      {
        AABB3f voxelBox;

        voxelBox.vmin = float3( box.vmin.x + x*voxelSize, box.vmin.y + y*voxelSize, box.vmin.z + z*voxelSize);
        voxelBox.vmax = voxelBox.vmin + 1.0f*float3(voxelSize,voxelSize,voxelSize);

        if(MGML_MATH::Intersect<AABB3f,AABB3f>::exec(triBox,voxelBox))
          if(MGML_MATH::Intersect<AABB3f,MyTriangle>::exec(voxelBox,tri))
            voxels(x,y,z) = 1;
      }
    }
  }

}


void Common_Graphics_Engine::VoxelizeAllTriangles()
{
  for(int triOffs = 0; triOffs < m_index.size(); triOffs+=3)
  {
    int iA = m_index[triOffs+0];
    int iB = m_index[triOffs+1];
    int iC = m_index[triOffs+2];

    float3 A = to_float3(GetVertexPos(iA));
    float3 B = to_float3(GetVertexPos(iB));
    float3 C = to_float3(GetVertexPos(iC));

    RasterizeTriangleTo3DArray<uint8>(A,B,C,m_voxelData);
  }
}


