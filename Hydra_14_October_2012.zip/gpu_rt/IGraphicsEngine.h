// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#include <string>

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#ifndef KD_TREE_GUARDIAN
	#include "../kd_tree_builder/kd_tree.h"
#endif

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

using namespace MGML;

#ifdef CERF_DLL_EXPORTS
	#define DLL_API __declspec(dllexport)
#else
	#define DLL_API __declspec(dllimport)
#endif


class DLL_API IGraphicsEngine
{
public:

	typedef unsigned int uint;
	enum {MAX_KD_TREE_NODES = 1000000, MAX_VERTEX_ATTRIBUTES = 10};

  IGraphicsEngine(int w, int h);
  virtual ~IGraphicsEngine();

  enum INPUT_TEXTURE_FORMAT{ RGBA8 = 4, RGBA16F = 8, RGBA32F = 16};
  
  // RTE API v 1.0
  //
  virtual vec2ui  AddTriangles(const Vertex4f* v,int N_vertices, const uint* indices,int N_indices, int a_flags = 0) = 0;
  virtual uint	  AddMaterial(const RAYTR::Material& mat) = 0; // deprecated
  virtual uint	  AddMaterial(const RAYTR::HydraMaterial& mat) = 0;
  virtual uint	  AddSpheres(const Sphere4f* s,int N_spheres) = 0;
  virtual uint    AddTexture(const void* memory, uint w, uint h, uint format = RGBA8) = 0;
  virtual uint    AddLight(const RAYTR::Light& light) = 0;

  // RTE API v 2.0
  //

  enum VERTEX_ATTRIB{ VERTEX_POSITION = 1,
                      VERTEX_NORMAL = 2, 
                      VERTEX_UV = 4,
                      VERTEX_TANGENT = 8,
                      VERTEX_MATERIAL_ID = 16,
                      VERTEX_USER_DEFINED = 32};

  enum CLEAR_FLAGS{ CLEAR_MATERIALS = 1, 
                    CLEAR_GEOMETRY = 2, 
                    CLEAR_LIGHTS = 4,
                    CLEAR_TEXTURES = 8,
                    CLEAR_ALL = CLEAR_MATERIALS | CLEAR_GEOMETRY | CLEAR_LIGHTS | CLEAR_TEXTURES};

  enum INPUT_PRIMITIVES { INPUT_PRIMITIVE_TRIANGLES = 1,
                          INPUT_PRIMITIVE_SPHERES = 2};

  enum GEOM_TYPE{ INPUT_GEOMETRY_STATIC = 0,
                  INPUT_GEOMETRY_DYNAMIC = 1};

  virtual void DeclareVertexInputLayout(int layout, int numUserDefinedAttributes = 0) throw (std::runtime_error) = 0;

  virtual void ReserveMemoryFor(int primTypes, int a_maxPrims) throw (std::runtime_error) = 0;

  // fixed function pipeline
  //
  virtual void SetVertexPositionPointer(const float* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexNormalPointer(const float* v,   int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexUVPointer(const float* v,       int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexTangentPointer(const float* v,  int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexMaterialIdPointer(const int* v, int bytePitch) throw (std::runtime_error) = 0; // deprecated

  // programmable pipeline
  //
  virtual void SetVertexAttributePointer(const char* attrName, const double* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const float* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const int* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const short* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const char* v, int bytePitch) throw (std::runtime_error) = 0;

  virtual int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount, int a_flags = 0) = 0;

  // RTE API v 2.1
  //
  virtual int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount,
                            const int* a_materialIndices, int a_matIdNum, int a_flags = 0) = 0; // ignore VertexMaterialIdPointer

  // RTE general
  //
  class DLL_API RenderState
  {
  public:
    RenderState();
    ~RenderState();

    void SetTraceDepth(int);
    int  GetTraceDepth() const;

    void SetDiffuseTraceDepth(int);
    int  GetDiffuseTraceDepth() const;

    void SetShadow(bool);
    bool GetShadow() const;

    void SetAA(int);
    int  GetAA() const;

    void SetIndirrectIllumination(bool);
    bool GetIndirrectIllumination() const;

    void  SetTraceProceedingsTreshold(float);
    float GetTraceProceedingsTreshold() const ;

    bool  GetEnableRaysCounter() const ;
    void  SetEnableRaysCounter(bool);

    float icWSErrorTreshold;

  protected: 
    int m_AA : 8;
    int m_traceDepth : 8;
    int m_diffTraceDepth : 8;
    
    bool m_shadows: 1;
    bool m_giEnabled : 1;
    bool m_enableRaysCount : 1;

    float m_traceProceedsTreshold;
  };

	virtual void BeginDrawScene(RenderState a_renderState) = 0;			// you can do some thing between this calls
	virtual void EndDrawScene() = 0;			                          // \\ you can do some thing between this calls

	virtual void DrawScene(const RenderState a_renderState) { BeginDrawScene(a_renderState); EndDrawScene(); }

	virtual void BuildAccelerationStructures(uint mode) = 0;

  virtual void Clear(int a_flags = CLEAR_ALL) = 0;

  virtual void SetLight(const RAYTR::Light& light,int index) = 0;	
  virtual int  GetLightNumber() const = 0;
  virtual const RAYTR::Light& GetLight(int index) const = 0;
 
  virtual void SetWorldViewMatrix(const float mat[16]) = 0;
  virtual void SetProjectionMatrix(const float mat[16]) = 0;

  virtual const float* GetWorldViewMatrix() const = 0;
  virtual const float* GetProjectionMatrix() const = 0;

	virtual const RAYTR::Material&		GetMaterial(int index) const = 0;          // deprecated
  virtual void SetMaterial(const RAYTR::Material& mat, unsigned int N) = 0;    // depracated

  virtual void SetVariable(const std::string& a_name, int a_val){}
  virtual void SetVariable(const std::string& a_name, float a_val){}

  virtual void GetTextureDesc(uint texId, uint* w, uint* h, uint* format = NULL) = 0;
  virtual void GetTextureData(uint texId, void* data) = 0;

  virtual void GetLDRImage(uint* data) const = 0;
  virtual void GetHDRImage(float4* data) const = 0;

  virtual void DebugCall(const std::string& a_name, const std::string& a_params){}

private:
	IGraphicsEngine(const IGraphicsEngine& rhs){}
	IGraphicsEngine& operator=(const IGraphicsEngine& rhs)
		{return *this;}
};
