// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include "Common_Graphics_Engine.h"
#include "Fonts.h"

#include "../kd_tree_builder/KdTreeBuilderRef_vfrolov.h"
#include "../bvh_builder/BVHBuilderRef_vfrolov.h"

using namespace MGML_MATH;

Common_Graphics_Engine::Common_Graphics_Engine(int w, int h): IGraphicsEngine(w,h)
{
  width = w;
  height = h;

  screen_buffer = new uint [width*height];

  for(int i=0;i<MAX_VERTEX_ATTRIBUTES;i++) 
    m_vertAttr[i] = NULL;

  m_currInputLayout = 0;
  m_pKdTreeBuilder = NULL;
  m_pBVHBuilder = NULL;

  pWorld_matrix = new Matrix4x4f;
  m_lightsWasAddedAsGeometry = 0;

  m_dataVerifyed        = false;
  m_dirtyMaterials      = true;
  m_dirtyHydraMaterials = true;
  m_dirtyLights         = true;
  m_accelStructuresDirty = true;
  m_materialsWasTransformed = false;
  m_debugLayer = 0;

  BuildFont();

  //std::cerr << "precomputing SH data" << std::endl;
  // precompute hemisphere data - 32*32, 64*64, 128*128, 256*256 
  //
  Timer timer(true);
  int numSamplesPerSector = 32; 
  for(int i=0;i<HEMISPHERE_SEQUENCE_NUM;i++)
  {
    CreateSphericalDistribution(m_sphereUniformArray[i], numSamplesPerSector);         // cosine 
    CreateSphericalDistribution(m_sphereUniformArray2[i], numSamplesPerSector, false); // uniform
    //CreateCubeMapDistribution(m_cubeUniformArray[i], numSamplesPerSector/2); // sqr(numSamplesPerSector) == samples per cube face
    numSamplesPerSector *= 2;
  }
  PrecomputeSHCoeffs(m_shCoeffsArray);  

  //std::cerr << "SH coeffs calculations time = " << timer.getElapsed() << std::endl;

  ReserveMemoryFor(INPUT_PRIMITIVE_TRIANGLES, 1000000); // reserve
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Common_Graphics_Engine::~Common_Graphics_Engine()
{
  delete pWorld_matrix; pWorld_matrix = NULL;
  delete m_pKdTreeBuilder; m_pKdTreeBuilder = NULL;
  
  delete [] screen_buffer; screen_buffer = NULL;

  for(int i=0;i<MAX_VERTEX_ATTRIBUTES;i++) 
    { delete [] m_vertAttr[i]; m_vertAttr[i] = NULL; }

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::DrawLights()
{
  if(m_lightsWasAddedAsGeometry)
    return;

  glDisable(GL_LIGHTING);
  glDisable(GL_TEXTURE_2D);

  glPushMatrix();

  //float3 camPos = this->GetCamMatrix();
  //glTranslatef();
  //glLoadIdentity();
  //glMultMatrixf(pWorld_matrix->L);

  for(int i=0;i<m_lights.size();i++)
  {
    const RAYTR::Light* pLight = &m_lights[i];

    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA || pLight->GetLightType() == Light::LIGHT_TYPE_SPOT)
    {
      // draw normal
      glColor3f(0,0,1);
      glBegin(GL_LINES);
        glVertex3fv(pLight->pos.M);
        glVertex3fv((pLight->pos+pLight->GetNormal()).M);
      glEnd();
    }

    //glColor3f(0,1,0);
    //DebugDrawPoints();
    
    glColor3fv(pLight->color.M);
    glPushMatrix();
    glTranslatef(pLight->pos.x, pLight->pos.y, pLight->pos.z);
    
    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA)
    { 
      Matrix4x4f mRot;
      pLight->GetMatrixRotation(mRot.L);
     
      glPushMatrix();
      glMultMatrixf(mRot.L);

      vec2f size = pLight->GetAreaLightSize();

      glBegin(GL_TRIANGLE_STRIP);
        glVertex3f(-size.x, 0, -size.y);
        glVertex3f(-size.x, 0, size.y);
        glVertex3f(size.x, 0, -size.y);
        glVertex3f(size.x, 0, size.y);
      glEnd();
      glPopMatrix();
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPHERICAL)
    {
      glutSolidSphere(pLight->GetSphericalLightRadius(),20,20);
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_POINT)
    {
      glutSolidSphere(0.05f,10,10);
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPOT)
    {
      Matrix4x4f mRot;
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          mRot.M[i][j] = pLight->GetAreaLightRotationMatrix()[i*3+j];

      glMultMatrixf(mRot.L);
      glRotatef(-90,1,0,0);
      glutSolidCone(0.10f,0.20f,20,20);
    }

    //glutSolidSphere(pLight->radius,20,20);
    glPopMatrix();
  }

  glPopMatrix();
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);

}


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::Clear(int a_flags)
{
  if(a_flags & CLEAR_MATERIALS)
  {
    m_materials.resize(0);
    m_triangleMaterialId.clear();
  }

  if(a_flags & CLEAR_GEOMETRY)
  {
    m_spheres.clear();
    m_index.clear();
    m_triangleMaterialId.clear();
    m_vertPos.clear();
    m_vertNorm.clear();
    m_vertTexCoord.clear();
    m_vertTangent.clear();
  }

  if(a_flags & CLEAR_LIGHTS)
    m_lights.resize(0);

  if(a_flags & CLEAR_TEXTURES) //#UNCHECKED
  {
    for(int i=0;i<m_images.size();i++)
      m_images[i].FreeData();
    m_images.resize(0);
  }
}


/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddMaterial(const RAYTR::Material& mat)
{
  m_materials.push_back(mat);
  m_dirtyMaterials = true;
  m_dirtyHydraMaterials = true;
  return (unsigned int)m_materials.size()-1;
}

/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddMaterial(const RAYTR::HydraMaterial& mat)
{
  if (mat.ambient.color_texId != INVALID_TEXTURE && mat.ambient.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for ambient.color");

  if (mat.diffuse.color_texId != INVALID_TEXTURE && mat.diffuse.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for diffuse.color");

  if (mat.specular.color_texId != INVALID_TEXTURE && mat.specular.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for specular.color");

  if (mat.reflection.color_texId != INVALID_TEXTURE && mat.reflection.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for reflection.color");

  if (mat.transparency.color_texId != INVALID_TEXTURE && mat.transparency.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for refraction.color");

  if (mat.displacement.normals_texId != INVALID_TEXTURE && mat.displacement.normals_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for mat.displacement.normals_texId");

  if (mat.displacement.height_texId != INVALID_TEXTURE && mat.displacement.height_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for mat.displacement.height_texId");

  m_hydraMaterials.push_back(mat);
  m_dirtyHydraMaterials = true;
  return (unsigned int)m_hydraMaterials.size()-1;
}


/////////////////////////////////////////////////////////////////////////////////////
////
vec2ui Common_Graphics_Engine::AddTriangles(const Vertex4f* v, int N_vertices,
                                            const unsigned int* indices,int N_indices, int a_flags)
{ 
  Matrix4x4f identityMatrix;
  vec2ui res(m_vertPos.size(), m_index.size());

  this->DeclareVertexInputLayout(VERTEX_POSITION | VERTEX_NORMAL | VERTEX_UV | VERTEX_MATERIAL_ID);
  this->SetVertexPositionPointer((const float*)&v[0].pos, sizeof(Vertex4f));
  this->SetVertexNormalPointer((const float*)&v[0].norm, sizeof(Vertex4f));
  this->SetVertexUVPointer((const float*)&v[0].t, sizeof(Vertex4f));
  this->SetVertexMaterialIdPointer((const int*)&v[0].material_id, sizeof(Vertex4f));
  this->AddTriangles(identityMatrix, indices, N_indices, N_vertices, a_flags);

  return res;
}

/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddSpheres(const Sphere4f* s,int N_spheres)
{
  int oldSize = m_spheres.size();
  for(int i=0;i<N_spheres;i++)
    m_spheres.push_back(s[i]);
  return oldSize;
}


/////////////////////////////////////////////////////////////////////////////////////
////
uint Common_Graphics_Engine::AddLight(const RAYTR::Light& a_light)
{
  m_lights.push_back(a_light);
  m_dirtyLights = true;
  return m_lights.size()-1;
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetLight(const RAYTR::Light& a_light,int index)
{
  if(index >= m_lights.size())
    RUN_TIME_ERROR("SetLight: no light with this index: " + ToString(index));
  
  m_dirtyLights = true;
  m_lights[index] = a_light;
}

/////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::GetLightNumber() const { return m_lights.size(); }

/////////////////////////////////////////////////////////////////////////////////////
////
const RAYTR::Light& Common_Graphics_Engine::GetLight(int index) const
{
  if(index >= m_lights.size())
    RUN_TIME_ERROR("No lights with this index: " + ToString(index));

  return m_lights[index];
}

/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddTexture(const void* memory,uint w,uint h, uint a_format)
{
  if(w == 0 || w > 16384)
    RUN_TIME_ERROR("AddTexture, incorrect width");

  if(h == 0 || h > 16384)
    RUN_TIME_ERROR("AddTexture, incorrect height");

  if(m_images.size() == 0)
    m_images.reserve(100);

  m_images.push_back(ImageStorage());
  m_images[m_images.size()-1].SetData((const unsigned char*)memory, w, h, w*h*sizeof(unsigned int), a_format);

  return m_images.size()-1;
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::BuildAccelerationStructures(uint a_constructionMode)
{ 
  if(m_hydraMaterials.size() == 0 && m_materials.size() != 0)
    TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);

  KdTreeUserInput input(this);

  if(a_constructionMode <= KD_TREE_CONSTRUCT_VERY_FAST) //  see enum
  {
    delete m_pKdTreeBuilder;
    m_pKdTreeBuilder = new KdTreeBuilderRef_vfrolov;

    AccelStructSettings  presets;
    presets.flags = AccelStructSettings::INPUT_TRIANGLES | AccelStructSettings::INPUT_SPHERES;

    if(a_constructionMode == KD_TREE_CONSTRUCT_QUALITY)
      presets.flags |= AccelStructSettings::CONSTRUCT_QUALITY;
    else if (a_constructionMode == KD_TREE_CONSTRUCT_FAST)
      presets.flags |= AccelStructSettings::CONSTRUCT_FAST;
    else
      presets.flags |= AccelStructSettings::CONSTRUCT_VERY_FAST;

    presets.maxDeep = 64;
    presets.maxPrimInLeaf = 100;
    presets.recomendedPrimInLeaf = 4;

    m_pKdTreeBuilder->Build(&input, presets);

    m_pKdTreeBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);
  }
  else if(a_constructionMode <= BVH_CONSTRUCT_VERY_FAST)
  {
    delete m_pBVHBuilder;
    m_pBVHBuilder = new BVHBuilderRef_vfrolov;

    AccelStructSettings  presets;
    presets.flags = AccelStructSettings::INPUT_TRIANGLES | AccelStructSettings::INPUT_SPHERES;

    if(a_constructionMode == BVH_CONSTRUCT_QUALITY)
      presets.flags |= AccelStructSettings::CONSTRUCT_QUALITY;
    else if (a_constructionMode == BVH_CONSTRUCT_FAST)
      presets.flags |= AccelStructSettings::CONSTRUCT_FAST;
    else
      presets.flags |= AccelStructSettings::CONSTRUCT_VERY_FAST;

    presets.maxDeep = 64;
    presets.maxPrimInLeaf = 32;
    presets.recomendedPrimInLeaf = 4;

    m_pBVHBuilder->Build(&input, presets);

    m_pBVHBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);

  }
  else
  {
    RUN_TIME_ERROR("Unknown acceleration structure selected");
  }

  m_accelStructuresDirty = false;

  VoxelizeAllGeometry();
}


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetMaterial(const RAYTR::Material& a_mat, unsigned int a_N)
{
  if(a_N >= m_materials.size())
    RUN_TIME_ERROR("SetMaterial: No material with this index");

  m_dirtyMaterials = true;
  m_materials[a_N] = a_mat;
}

/////////////////////////////////////////////////////////////////////////////////////
////
const RAYTR::Material& Common_Graphics_Engine::GetMaterial(int index) const
{
  if(index >= m_materials.size())
    RUN_TIME_ERROR("GetMaterial: No material with this index");

  return m_materials[index];
}	


/////////////////////////////////////////////////////////////////////////////////////
////
const Matrix4x4f& Common_Graphics_Engine::GetCamMatrix() const
{
  return (*pWorld_matrix);
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::DebugDrawAccelStruct()
{

  //vec3f farPos = g_debugRay.pos + g_debugRay.dir*1000.0f;
  //glColor3f(0,0,1);
  //glBegin(GL_LINES);
  //glVertex3fv(g_debugRay.pos.M);
  //glVertex3fv(farPos.M);
  //glEnd();

} 


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::VerifyData()
{
  return; 
  
  // works very slow because start from the begining each time!!!
  //

  //for (int i=0;i<m_vertPos.size();i++)
  //{
  //  int matId = GetVertexMaterialId(i);
  //  if (matId < 0 || (matId >= m_materials.size() && matId >= m_hydraMaterials.size()))
  //    RUN_TIME_ERROR("No material found, id: " + ToString(matId) + " vertex id:" + ToString(i));

  //  if(m_textures.size() > 0)
  //  {
  //    //int texId = m_materials[matId].textureId[0];
  //    //if ( (texId< 0 || texId >= m_textures.size()) && texId != 255)
  //      //RUN_TIME_ERROR("No texture found, id: " + ToString(texId) + " vertex id:" + ToString(i));
  //  }
  //}

  //for(int i=0;i<m_index.size();i++)
  //{
  //  int index = m_index[i];
  //  if(index >= m_vertPos.size())
  //    RUN_TIME_ERROR("incorrect index" + ToString(index) + "at position " + ToString(i));
  //}
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::VerifyAllData()
{
  if(m_materials.size() == 0)
    std::cerr << "WARNING: materials (deprecated) were not set" << std::endl;

  if(m_hydraMaterials.size() == 0)
    std::cerr << "WARNING: materials (hydra) were not set" << std::endl;

  if(m_lights.size() == 0)
    std::cerr << "WARNING: lights (deprecated) were not set" << std::endl;

  if(m_images.size() == 0)
    std::cerr << "WARNING: textures were not set" << std::endl;

  if(m_accelStructuresDirty)
    std::cerr << "WARNING: acceleration structures were not build" << std::endl;

  m_dataVerifyed = true;
}


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::TransformDeprecatedMaterialsToHydraMarerials(std::vector<RAYTR::Material>& oldMats, std::vector<RAYTR::HydraMaterial>* a_newMats)
{
  std::vector<RAYTR::HydraMaterial>& newMats = *a_newMats;
  
  newMats.reserve(oldMats.size() + newMats.size());

  for(int i=0;i<oldMats.size();i++)
  {
    const RAYTR::Material& mat = oldMats[i];
    HydraMaterial   newMat;

    newMat.flags = HydraMaterial::DEFAULT_FLAGS;

    // ambient
    //
    newMat.ambient.color = mat.ka;

    if(mat.IsLight())
    {
      newMat.ambient.light_multiplyer = 20;
      newMat.ambient.color /= newMat.ambient.light_multiplyer;
      newMat.flags |= HydraMaterial::THIS_IS_LIGHT;
    }

    // diffuse
    //
    newMat.diffuse.color = mat.kd;
    for(int j=0;j<mat.texturesUsed;j++)
      if(mat.textureFlags[j] & RAYTR::Material::TEX_STORE_DIFFUSE_COLOR || mat.textureFlags[j] & RAYTR::Material::TEX_COMBINE_MULT_COLOR)
        newMat.diffuse.color_texId = mat.textureId[j];
    
    newMat.diffuse.radiance = 2.0f;

    //if(i==2)
      //newMat.diffuse.radiance = 8.0f;


    // specular
    //
    newMat.specular.color = mat.ks;
    newMat.specular.power = mat.GetPhongPower();
    
    if(mat.BRDF_id == RAYTR::Material::BRDF_BLINN)
      newMat.specular.brdf_id = HydraMaterial::BRDF_BLINN;
    else if(mat.BRDF_id == RAYTR::Material::BRDF_PHONG)
      newMat.specular.brdf_id = HydraMaterial::BRDF_PHONG;
    else
    {
      newMat.specular.brdf_id   = HydraMaterial::BRDF_COOK_TORRANCE;
      newMat.specular.roughness = mat.GetRoughness();
    }

    for(int j=0;j<mat.texturesUsed;j++)
      if(mat.textureFlags[j] & RAYTR::Material::TEX_COMBINE_MULT_COLOR)
        newMat.specular.color_texId = mat.textureId[j];

    newMat.specular.fresnelIOR = mat.fresnelIOR;
    
    // reflection
    //
    if(mat.HasSeparatedReflection())
    {
      newMat.reflection.brdf_id = mat.BRDF_id;
      newMat.reflection.color   = mat.reflection;
    }
    else
    {
      newMat.reflection = newMat.specular;
      newMat.reflection.brdf_id = mat.BRDF_id;
      newMat.reflection.color   = mat.ks;
    }

    newMat.reflection.power = 1.0f/fmaxf(1e-6f,(1.0f - pow(mat.refractGlossiness, 0.001f))); //VRayGlosinessToCosinePower(mat.reflectGlossiness);
    
    // refraction
    //
    newMat.transparency.color      = mat.refraction;
    newMat.transparency.IOR        = mat.IOR;
    newMat.transparency.glossiness = mat.refractGlossiness;
    newMat.transparency.fogColor  = mat.refraction;
    newMat.transparency.fogMultiplyer = mat.fogMultiplier;

    if(length(mat.refraction) > 1e-4f)
      newMat.flags |= HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
    
    newMats.push_back(newMat);
  }

  oldMats.resize(0);

  m_materialsWasTransformed = true;
}


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::CalcTangentSpace()
{
  int vertexCount   = m_vertPos.size();
  int triangleCount = m_index.size()/3; 

  float4 *tan1 = new float4[vertexCount * 2];
  float4 *tan2 = tan1 + vertexCount;
  ZeroMemory(tan1, vertexCount * sizeof(float4) * 2);

  for (long a = 0; a < triangleCount; a++)
  {
    long i1 = m_index[3*a+0];
    long i2 = m_index[3*a+1];
    long i3 = m_index[3*a+2];

    const float4& v1 = m_vertPos[i1];
    const float4& v2 = m_vertPos[i2];
    const float4& v3 = m_vertPos[i3];

    const float2& w1 = m_vertTexCoord[i1];
    const float2& w2 = m_vertTexCoord[i2];
    const float2& w3 = m_vertTexCoord[i3];

    float x1 = v2.x - v1.x;
    float x2 = v3.x - v1.x;
    float y1 = v2.y - v1.y;
    float y2 = v3.y - v1.y;
    float z1 = v2.z - v1.z;
    float z2 = v3.z - v1.z;

    float s1 = w2.x - w1.x;
    float s2 = w3.x - w1.x;
    float t1 = w2.y - w1.y;
    float t2 = w3.y - w1.y;

    float r = 1.0f / (s1 * t2 - s2 * t1);
    float4 sdir((t2 * x1 - t1 * x2) * r, (t2 * y1 - t1 * y2) * r, (t2 * z1 - t1 * z2) * r, 1);
    float4 tdir((s1 * x2 - s2 * x1) * r, (s1 * y2 - s2 * y1) * r, (s1 * z2 - s2 * z1) * r, 1);

    tan1[i1] += sdir;
    tan1[i2] += sdir;
    tan1[i3] += sdir;

    tan2[i1] += tdir;
    tan2[i2] += tdir;
    tan2[i3] += tdir;
  }

  m_vertTangent.resize(vertexCount);

  for (long a = 0; a < vertexCount; a++)
  {
    const float4& n = m_vertNorm[a];
    const float4& t = tan1[a];

    // Gram-Schmidt orthogonalization
    m_vertTangent[a] = normalize(t - n * dot(n, t));

    // Calculate handedness
    m_vertTangent[a].w = (dot(cross(n, t), tan2[a]) < 0.0f) ? -1.0f : 1.0f;
  }

  delete [] tan1;
}






/////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::KdTreeUserInput::GetNumTriangles() const throw (std::runtime_error)
{
  ASSERT(m_data->m_index.size()%3 == 0);
  return m_data->m_index.size()/3;
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::KdTreeUserInput::GetTriangle(int index, float A[3], float B[3], float C[3]) const throw (std::runtime_error)
{
  int iA = m_data->m_index[3*index+0];
  int iB = m_data->m_index[3*index+1];
  int iC = m_data->m_index[3*index+2];

  float4 aPos = m_data->GetVertexPos(iA);
  float4 bPos = m_data->GetVertexPos(iB);
  float4 cPos = m_data->GetVertexPos(iC);

  for(int i=0;i<3;i++)
  {
    A[i] = aPos.M[i];
    B[i] = bPos.M[i];
    C[i] = cPos.M[i];
  }
}

/////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::KdTreeUserInput::GetNumSpheres() const throw (std::runtime_error)
{
  return m_data->m_spheres.size();
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::KdTreeUserInput::GetSphere(int index, float sph_pos[3], float* sph_r) const throw (std::runtime_error)
{ 
  float4 spPos = m_data->GetSpherePos(index);
  sph_pos[0] = spPos.M[0];
  sph_pos[1] = spPos.M[1];
  sph_pos[2] = spPos.M[2];

  *sph_r = m_data->GetSphereRadius(index);
}

/////////////////////////////////////////////////////////////////////////////////////
////
int Common_Graphics_Engine::KdTreeUserInput::WriteTriangle(int index, void* pAddressToWrite, int maxBytesPermitToRight) const throw (std::runtime_error)
{
  ObjectList::Triangle t;

  int A_offs = m_data->m_index[3*index+0];
  int B_offs = m_data->m_index[3*index+1];
  int C_offs = m_data->m_index[3*index+2];
 
  int matId = m_data->GetTriangleMaterialId(index); 

  ASSERT(matId < m_data->m_hydraMaterials.size());
  const HydraMaterial& material = m_data->m_hydraMaterials[matId];
  
  if(!(material.flags & HydraMaterial::TRANSPARENCY_THIN_SURFACE))
    matId = 0xFFFFFFFF;

  //t.selfIndex = 3*index;

#if TRIANGLE_LAYOUT == VERTEX_TRIANGLE_LAYOUT
  
  t.v1 = m_data->GetVertexPos(A_offs);
  t.v2 = m_data->GetVertexPos(B_offs);
  t.v3 = to_vec3f(m_data->GetVertexPos(C_offs));

  int* pFlags = (int*)(&t.v1.w); // put matId
  *pFlags = matId;

#elif TRIANGLE_LAYOUT == INDEX_TRIANGLE_LAYOUT

  t.v[0] = m_data->m_index[3*index+0];
  t.v[1] = m_data->m_index[3*index+1];
  t.v[2] = m_data->m_index[3*index+2];

#elif TRIANGLE_LAYOUT == MATRIX_TRIANGLE_LAYOUT

  float3 A = to_vec3f(m_data->GetVertexPos(A_offs));
  float3 B = to_vec3f(m_data->GetVertexPos(B_offs));
  float3 C = to_vec3f(m_data->GetVertexPos(C_offs));
  float3 N = normalize(cross(A-C,B-C)); 

  MGML::Matrix4x4f m1;

  m1.M[0][0] = A.x-C.x;
  m1.M[1][0] = A.y-C.y;
  m1.M[2][0] = A.z-C.z;

  m1.M[0][1] = B.x-C.x;
  m1.M[1][1] = B.y-C.y;
  m1.M[2][1] = B.z-C.z;

  m1.M[0][2] = N.x-C.x;
  m1.M[1][2] = N.y-C.y;
  m1.M[2][2] = N.z-C.z;

  m1.M[0][3] = C.x;
  m1.M[1][3] = C.y;
  m1.M[2][3] = C.z;

  m1 = MGML::SafeInverse(m1);

  for(int i=0;i<3;i++)
  {
    t.m.row[i].x = m1.M[i][0];
    t.m.row[i].y = m1.M[i][1];
    t.m.row[i].z = m1.M[i][2];
    t.m.row[i].w = m1.M[i][3];
  }

  // swap rows
  //
  float4 temp[3];
  temp[0] = t.m.row[0];
  temp[1] = t.m.row[1];
  temp[2] = t.m.row[2];

  t.m.row[0] = temp[2];
  t.m.row[1] = temp[0];
  t.m.row[2] = temp[1];

#else
  RUN_TIME_ERROR("uups");
#endif

  if(sizeof(ObjectList::Triangle) > maxBytesPermitToRight)
    throw std::runtime_error("Common_Graphics_Engine::KdTreeUserInput::WriteTriangle: out of memory for primitive list data, can not write triangle to list");

  ObjectList::Triangle* result = (ObjectList::Triangle*)pAddressToWrite;
  *result = t;
  
  // a shit
  //
  ASSERT(sizeof(ObjectList::Triangle) % sizeof(float4) == 0);
  
  const char* primListBegin;
  if(m_data->m_pBVHBuilder != NULL)
    primListBegin = m_data->m_pBVHBuilder->GetPrimitiveListsArray();
  else if(m_data->m_pKdTreeBuilder != NULL)
    primListBegin = m_data->m_pKdTreeBuilder->GetPrimitiveListsArray();
  else
    RUN_TIME_ERROR("accel struct was not found");

  int offsetInBytes  = (char*)(pAddressToWrite) - primListBegin;
  int offsetInFloat4 = offsetInBytes/sizeof(float4);

  if(offsetInFloat4 >= m_data->m_tempPrimIndex.size())
    m_data->m_tempPrimIndex.resize(offsetInFloat4+1);
 
  m_data->m_tempPrimIndex[offsetInFloat4] = 3*index;
  
  int newSize = max(m_data->m_tempPrimIndex.size(), offsetInFloat4+1);
  if(newSize > m_data->m_tempPrimIndex.size())
    m_data->m_tempPrimIndex.resize(newSize);

  return sizeof(ObjectList::Triangle);
}

/////////////////////////////////////////////////////////////////////////////////////
////
int Common_Graphics_Engine::KdTreeUserInput::WriteSphere(int index, void* pAddressToWrite, int maxBytesPermitToRight) const throw (std::runtime_error)
{
  ObjectList::Sphere s;

  s.pos = to_float3(m_data->GetSpherePos(index));
  s.r = m_data->GetSphereRadius(index);
  //s.selfIndex = index;

  if(sizeof(ObjectList::Sphere) > maxBytesPermitToRight)
    throw std::runtime_error("Common_Graphics_Engine::KdTreeUserInput::WriteSphere: out of memory for primitive list data, can not write sphere to list");

  ObjectList::Sphere* result = (ObjectList::Sphere*)pAddressToWrite;
  *result = s;

  // a shit
  //
  ASSERT(sizeof(ObjectList::Sphere) % sizeof(float4) == 0);

  const char* primListBegin;
  if(m_data->m_pBVHBuilder != NULL)
    primListBegin = m_data->m_pBVHBuilder->GetPrimitiveListsArray();
  else if(m_data->m_pKdTreeBuilder != NULL)
    primListBegin = m_data->m_pKdTreeBuilder->GetPrimitiveListsArray();
  else
    RUN_TIME_ERROR("accel struct was not found");

  int offsetInBytes  = (char*)(pAddressToWrite) - primListBegin;
  int offsetInFloat4 = offsetInBytes/sizeof(float4);

  if(offsetInFloat4 >= m_data->m_tempPrimIndex.size())
     m_data->m_tempPrimIndex.resize(offsetInFloat4+1);

  m_data->m_tempPrimIndex[offsetInFloat4] = index;

  int newSize = max(m_data->m_tempPrimIndex.size(), offsetInFloat4+1);
  if(newSize > m_data->m_tempPrimIndex.size())
    m_data->m_tempPrimIndex.resize(newSize);

  return sizeof(ObjectList::Sphere);
}

/////////////////////////////////////////////////////////////////////////////////////
////
int Common_Graphics_Engine::KdTreeUserInput::WritePrimListProlog(void* pAddressToWrite, int maxBytesPermitToRight,
                                                                 int a_numTriangles, int a_numSpheres, int a_numPoints, 
                                                                 int a_numCustomPrimitives[32]) const throw (std::runtime_error) 
{
  ObjectList objList;
  objList.SetNumSpheres(a_numSpheres);
  objList.SetNumTriangles(a_numTriangles);
 
  int leafSize = a_numSpheres*sizeof(ObjectList::Sphere) + a_numTriangles*sizeof(ObjectList::Triangle) + sizeof(ObjectList);

  if(leafSize >= maxBytesPermitToRight)
    RUN_TIME_ERROR("Common_Graphics_Engine::KdTreeUserInput::WritePrimListProlog: out of memory for primitive list, can not write prim list prolog");

  ObjectList* objListPointer = (ObjectList*)pAddressToWrite;
  *objListPointer = objList; // save object list counters
 
  return sizeof(ObjectList);
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVariable(const std::string& a_name, int a_val)
{
  if(a_name == "g_debugLayerDraw")
  {
    m_debugLayer = a_val;
  }
  else if(a_name == "drawIrradianceCachePixelPoints")
  {
    m_drawIrradianceCachePixelPoints = a_val;
  }
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVariable(const std::string& a_name, float a_val)
{

}

