// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once

#include "IGraphicsEngine.h"
//#include "Common_Graphics_Engine.h"
#include "Ray_Tracer.h"

#include "../SGA_lib/SGA_lib.h"

#include <map>

using namespace MGML_ERROR;

class DLL_API GPU_Ray_Tracer: public Ray_Tracer // ,public Singleton
{
	typedef Ray_Tracer Base;

public:

  GPU_Ray_Tracer(int w, int h, int flags = 0);
	~GPU_Ray_Tracer();

	void BeginDrawScene(RenderState a_renderState);			// account multithreading
	void EndDrawScene();			// account multithreading

	void BuildAccelerationStructures(uint in_maxNodes = MAX_KD_TREE_NODES);

  void PrintPerfInfo(std::ostream& out);

	Ray_Tracer::RT_Core* GetRTCore();

	class DLL_API RT_Core : public Base::RT_Core
	{
	public:

		//void TraverseRays(Ray* in_out_rays, RAYTR::Hit* out_hits, size_t in_N);
		//void TraverseRays(Ray* in_out_rays, RAYTR::Hit* out_hits, size_t in_width, size_t in_height);
	};

  void GetLDRImage(uint* data) const;
  void GetHDRImage(float4* data) const;

  void SetVariable(const std::string& a_name, int a_val);
  void SetVariable(const std::string& a_name, float a_val);

protected:

  GPU_Ray_Tracer(const GPU_Ray_Tracer&);
  GPU_Ray_Tracer& operator=(const GPU_Ray_Tracer&);

	virtual void CopyDynamicDataToGPU();
  void InitPBO(GLuint* a_pBuffer);
  void LoadStaticDataToGPU();

  void PrintMaterialParametersOffsets(const string& a_fileName);

  void PrepareTexturesToTextureArrays(std::vector<ImageStorage*>* texArrays);
  std::vector<ImageStorage*> m_texArrays[TEX_ARRAYS_NUMBER];

  void CreateEnvMapTextures();
  void CreateMegaTextures();
  void LoadDefferedMegaTexturesToGPU();
  void Pack1ChannelTexTo4ThChannel(int bytesOffsetInMaterial, int bytesOffset2InMaterial);
  std::map<std::string, MegaTexStorageProxy*> m_defferedMegaTexHash;

  RT_Core m_core;

  float m_avgRaysPerPixel;
  int m_startScreenBlockListSize;
  GLuint m_pixelBufferObject;
  GLuint m_screenTexture;

  bool  m_rtOnlyVarDrawRaysStatInfo;

  SGA::IPipeline* m_pipeline;
 
};