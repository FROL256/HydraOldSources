#pragma once

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif

#include <queue>


template<typename Data>
struct Array3D
{
  Array3D();
  Array3D(int a_sizeX, int a_sizeY, int a_sizeZ);

  inline const Data& operator()(int x, int y, int z) const;
  inline Data& operator()(int x, int y, int z);

  inline int3 size() const {return int3(m_sizeX,m_sizeY,m_sizeZ);}
  
  void resize(int a_sizeX, int a_sizeY, int a_sizeZ);

protected:

  int m_sizeX;
  int m_sizeY;
  int m_sizeZ;

  std::vector<Data> m_data;
};

static int CalcMipsNumber(int res)
{
  int levels = 0;

  while(res != 0)
  {
    levels++;
    res = (res >> 1);
  }

  return levels-1;
}


template<typename Data>
struct VoxelStorage
{
  VoxelStorage() : m_mipsNumber(0) { }
  VoxelStorage(int a_sizeX, int a_sizeY, int a_sizeZ);
  virtual ~VoxelStorage(){}

  void SetBoundingBox(const AABB3f& aabb);
  AABB3f GetBoundingBox() const { return m_box;}

  typedef typename Data(*DownSampleFunc)(Data a_data[8]);

  void GenerateMips(DownSampleFunc a_func);

  const Array3D<Data>& GetArrayMipLevel(int n) const;
  Array3D<Data>& GetArrayMipLevel(int n);


  void Resize(int a_sizeX, int a_sizeY, int a_sizeZ);
  void Clear();

protected:

  void DownSampleArray3D(Array3D<Data>& from, Array3D<Data>& to, DownSampleFunc a_func);

  void DebugOutArray3DToFile(const char* file, const Array3D<Data>& outVoxels);

  AABB3f m_box;

  enum {MAX_MIPS = 64};
  Array3D<Data> m_data[MAX_MIPS];
  int m_mipsNumber;

};





template<typename Data>
Array3D<Data>::Array3D()
{
  m_sizeX = 0;
  m_sizeY = 0;
  m_sizeZ = 0;
}

template<typename Data>
Array3D<Data>::Array3D(int a_sizeX, int a_sizeY, int a_sizeZ)
{
  this->resize(a_sizeX,a_sizeY,a_sizeZ);
}

template<typename Data>
void  Array3D<Data>::resize(int a_sizeX, int a_sizeY, int a_sizeZ)
{
  m_data.resize(a_sizeX*a_sizeY*a_sizeZ);
  m_sizeX = a_sizeX;
  m_sizeY = a_sizeY;
  m_sizeZ = a_sizeZ;
}


template<typename Data>
inline const Data& Array3D<Data>::operator()(int x, int y, int z) const
{
  x = clamp(x, 0, m_sizeX-1);
  y = clamp(y, 0, m_sizeY-1);
  z = clamp(z, 0, m_sizeZ-1);

  int index = z*m_sizeX*m_sizeY + y*m_sizeX + x;

  return m_data[index];
}

template<typename Data>
inline Data& Array3D<Data>::operator()(int x, int y, int z)
{
  x = clamp(x, 0, m_sizeX-1);
  y = clamp(y, 0, m_sizeY-1);
  z = clamp(z, 0, m_sizeZ-1);

  int index = z*m_sizeX*m_sizeY + y*m_sizeX + x;

  return m_data[index];
}


template<typename Data>
void VoxelStorage<Data>::Clear()
{
  for(int i=0;i<m_mipsNumber;i++)
    m_data[i] = Array3D<Data>(0,0,0);
  m_mipsNumber = 0;
}

template<typename Data>
VoxelStorage<Data>::VoxelStorage(int a_sizeX, int a_sizeY, int a_sizeZ)
{
  Resize(a_sizeX, a_sizeY, a_sizeZ);
}

template<typename Data>
void VoxelStorage<Data>::Resize(int a_sizeX, int a_sizeY, int a_sizeZ)
{
  if(a_sizeX != a_sizeY || a_sizeX != a_sizeZ)
    RUN_TIME_ERROR("VoxelStorage::Resize do not support non cubic 3D textures for now, sizes are not equal!");

  m_data[0].resize(a_sizeX, a_sizeY, a_sizeZ);
  m_mipsNumber = 0; //CalcMipsNumber(m_data[0].size().x);
}


template<typename Data>
void VoxelStorage<Data>::SetBoundingBox(const AABB3f& aabb)
{
  float3 center  = aabb.center();
  float3 boxSize = aabb.vmax - aabb.vmin;

  float  maxSize = MGML_MATH::MAX<float>(boxSize.x, boxSize.y, boxSize.z);

  m_box.vmin = center - 0.5f*float3(maxSize,maxSize,maxSize);
  m_box.vmax = center + 0.5f*float3(maxSize,maxSize,maxSize);
}

template<typename Data>
const Array3D<Data>& VoxelStorage<Data>::GetArrayMipLevel(int n) const 
{ 
  if(n < 0 || n > m_mipsNumber)
    RUN_TIME_ERROR("VoxelStorage<Data>::GetMipLevel, n is out of range");

  return m_data[n]; 
}

template<typename Data>
Array3D<Data>& VoxelStorage<Data>::GetArrayMipLevel(int n) 
{ 
  if(n < 0 || n > m_mipsNumber)
    RUN_TIME_ERROR("VoxelStorage<Data>::GetMipLevel, n is out of range");

  return m_data[n]; 
}


template<typename Data>
void VoxelStorage<Data>::GenerateMips(DownSampleFunc a_func)
{
  int levels = CalcMipsNumber(m_data[0].size().x);

  for(int mip=0; mip < levels-1; mip++)
  {
    int3 sz = m_data[mip].size();
    m_data[mip+1].resize(sz.x >> 1, sz.y >> 1, sz.z >> 1);
    DownSampleArray3D(m_data[mip], m_data[mip+1], a_func);
  }

  //DebugOutArray3DToFile("boxes0.txt", m_data[0]);
  //DebugOutArray3DToFile("boxes1.txt", m_data[1]);
  //DebugOutArray3DToFile("boxes2.txt", m_data[2]);
  //DebugOutArray3DToFile("boxes3.txt", m_data[3]);
  //DebugOutArray3DToFile("boxes4.txt", m_data[4]);
  //DebugOutArray3DToFile("boxes5.txt", m_data[5]);

  m_mipsNumber = levels;
}


template<typename Data>
void VoxelStorage<Data>::DownSampleArray3D(Array3D<Data>& from, Array3D<Data>& out, DownSampleFunc a_func)
{
  ASSERT(from.size().x == 2*out.size().x);

  Data data[8];

  for(int x=0; x<out.size().x; x++)
  {
    for(int y=0; y<out.size().y; y++)
    {
      for(int z=0; z<out.size().z; z++)
      {
        data[0] = from(2*x+0, 2*y+0, 2*z+0);
        data[1] = from(2*x+1, 2*y+0, 2*z+0);

        data[2] = from(2*x+0, 2*y+1, 2*z+0);
        data[3] = from(2*x+1, 2*y+1, 2*z+0);
        
        data[4] = from(2*x+0, 2*y+0, 2*z+1);
        data[5] = from(2*x+1, 2*y+0, 2*z+1);
        
        data[6] = from(2*x+0, 2*y+1, 2*z+1);
        data[7] = from(2*x+1, 2*y+1, 2*z+1);

        out(x,y,z) = a_func(data);
      }
    }
  }
}



template<typename Data>
void VoxelStorage<Data>::DebugOutArray3DToFile(const char* file, const Array3D<Data>& outVoxels)
{
  std::ofstream fout(file);

  float voxelSize = (m_box.vmax.x - m_box.vmin.x)/float(outVoxels.size().x);

  for(int x=0; x<outVoxels.size().x; x++)
  {
    for(int y=0; y<outVoxels.size().y; y++)
    {
      for(int z=0; z<outVoxels.size().z; z++)
      {
        float3 vmin = float3( m_box.vmin.x + x*voxelSize, 
                              m_box.vmin.y + y*voxelSize, 
                              m_box.vmin.z + z*voxelSize);

        float3 vmax = vmin + 1.0f*float3(voxelSize,voxelSize,voxelSize);

        if(outVoxels(x,y,z) != 0)
        {
          fout << vmin << std::endl;
          fout << vmax << std::endl << std::endl;
        }
      }
    }
  }


}
