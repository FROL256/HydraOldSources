// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#define RTLIB_GUARDIAN

#ifndef CONFIG_GUARDIAN
  #include "../kd_tree_builder/config.h"
#endif

enum {GPU_RT_MEMORY_SAFE_MODE = 1, GPU_RT_MEMORY_FULL_SIZE_MODE = 2};

#ifndef ACCEL_STRUCT_GUARDIAN
  #include "../kd_tree_builder/AccelerationStructure.h" 
#endif

#ifndef KD_TREE_LAYOUT_GUARDIAN
  #include "../kd_tree_builder/kd_tree_layout.h"
#endif

#ifndef BVH_LAYOUT_GUARDIAN
  #include "../bvh_builder/BVH_layout.h"
#endif

#ifndef TRANSIT_PRIMITIVES_GUARDIAN
  #include "Transit_Primitives.h"
#endif

#ifndef MATERIAL_GUARDIAN
  #include "Material.h"
#endif

#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif


#define BLOCK_SIZE_X 16
#define BLOCK_SIZE_Y 16
#define WARP_SIZE 32

#define Z_ORDER_BLOCK_SIZE 16

const int CMP_RESULTS_BLOCK_SIZE = 256;

#define HRT_RAY_MISS 0xFFFFFFFE
#define HRT_RAY_HIT 0xFFFFFFFF

#define DELTA_RAY 1e-5f

#define TEX_ARRAYS_NUMBER 9
#define TEX_ARRAYS_MIN_SIZE 32
#define TEX_ARRAYS_MAX_SIZE 16384

#define HEMISPHERE_SEQUENCE_NUM 4
#define RC_CUBE_SIZE 4

namespace RAYTR
{

enum RAY_TYPES {EYE_RAY,
				        SHADOW_RAY,
				        REFLECTED_RAY,
				        REFRACTED_RAY};

enum ACCELERATION_STRUCRURES {ACCEL_STRUCT_KD_TREE, 
                              ACCEL_STRUCT_BVH,
                              ACCEL_STRUCT_HIERARHICAL_GRID};


#ifdef __CUDACC__

#include "float4.cuh"

static __device__ uint encodeNormal(float3 n)
{
  short x = (short)(n.x*32767.0f);
  short y = (short)(n.y*32767.0f);

  ushort sign = (n.z >= 0) ? 0 : 1;

  int sx = (int(x & 0xfffe) | sign);
  int sy = (int(y & 0xfffe) << 16 );

  return (sx | sy);
}

static __device__ float3 decodeNormal(uint a_data)
{ 
  const float divInv = 1.0f/32767.0f;
  
  short2 a_enc;

  a_enc.x = short(a_data & 0x0000FFFF);
  a_enc.y = short(int(a_data & 0xFFFF0000) >> 16);

  float sign = (a_enc.x & 0x0001) ? -1.0f : 1.0f;

  float x = short(a_enc.x & 0xfffe)*divInv;
  float y = short(a_enc.y & 0xfffe)*divInv;
  float z = sign*sqrtf(fmaxf(1.0f - x*x - y*y, 0.0f));

  return make_float3(x,y,z);
}


#endif

struct RaySample1
{
  float3   color;
  unsigned short x,y;     // screen x and y 
};

struct RaySample2
{
  float3 pos;
  uint   compressedNorm;
};

struct RaySampleOther
{
  float u,v;
};


struct HitPosNorm
{
  float3 pos;
  uint norm_xy;

#ifdef __CUDACC__
  
  __device__ float3 GetNormal() const { return decodeNormal(norm_xy); }
  __device__ void SetNormal(float3 a_norm) { norm_xy = encodeNormal(normalize(a_norm)); }

#endif

};

struct HitTexCoord
{
  float  tex_u;
  float  tex_v;
};


struct HitMatRef
{ 
  int    m_data;

#ifndef __CUDACC__
  HitMatRef() {m_data = 0;}
#endif

  universal_call int GetHitType() const {return (m_data & 0xF0000000) >> 28;}
  universal_call int GetMaterialId() const {return m_data & 0x0FFFFFFF;}

  universal_call void SetMaterialId(int a_mat_id) 
  {
    register int mask =  a_mat_id & 0x0FFFFFFF;
    register int m_data2 = m_data & 0xF0000000;
    m_data = m_data2 | mask;
  }

  universal_call void SetHitType(int a_id) 
  {
    register int mask =  a_id << 28;
    register int m_data2 = m_data & 0x0FFFFFFF;
    m_data = m_data2 | mask;
  }

};

struct Hit_Part4
{
  uint tangentCompressed;
  uint bitangentCompressed;
};


/////////////////////////////////
struct __align__(8) Lite_Hit
{

  static inline universal_call int MakeObjectId(unsigned int a_id, unsigned int a_objType)
  {
    return (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000);
  }

  inline universal_call void SetObjectId(unsigned int a_id)
  { object_id = ( a_id & 0x3FFFFFFF) | (object_id & 0xC0000000); }

  inline universal_call unsigned int GetObjectId() const
  { return object_id & 0x3FFFFFFF; }

  inline universal_call void SetObjectType(unsigned int a_type)
  { object_id = ( ((a_type << 30) & 0xC0000000) | (object_id & 0x3FFFFFFF) ) ; }

  inline universal_call unsigned int GetObjectType() const
  { return (object_id & 0xC0000000) >> 30; }

  inline universal_call static Lite_Hit Make(float t, unsigned int a_id, unsigned int a_objType)
  {
     Lite_Hit hit;
     hit.t = t;
     hit.object_id = (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000); 
     return hit;
  }

  enum {TRIANGLE, SPHERE, BOX, NONE};

  //protected:

  float t;
  unsigned int  object_id; // we can use 2 bits of object_id to store object_type
};


struct RayFlags
{
  unsigned char  diffuseBounceNum;
  unsigned char  bounceNum;
  unsigned short otherFlags;
};




}


using namespace RAYTR;

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

enum HRT_ERROR_CODES
{ 
		HRT_NO_MEMORY_AVALIABLE = 1,
		HRT_INCORRECT_SIZE = 2,
		HRT_ZERO_SIZE = 3,
    HRT_INCORRECT_INTERNAL_PARAMETER = 4,
		HRT_UNEXPECTED_FUNCTION_FAIL = 5
};


extern "C" const char* hrtGetErrorMessage(int err_code);
extern "C" int hrtInit(int w,int h, int a_flags);
extern "C" int hrtDelete();
extern "C" int hrtPrintInfo();

extern "C" int hrtBeginTrace(uint AA);
extern "C" int hrtEndTrace(unsigned int* buffer);
extern "C" int hrtMapGLScreenBuffers();

extern "C" int hrtTraceClientRays1D(const float4* cpu_ray_pos, const float4* cpu_ray_dir, int a_size);
extern "C" int hrtGetColor(float4* cpu_color, int a_size);

extern "C" int hrtMegaBlockTrace1D(float4* rpos, float4* rdir, float4* finalColor, int a_size);

//extern "C" int hrtSetWorldMatrix(const float* matrix);
extern "C" int hrtSetSpheres(const sphere4* spheres,int n);
extern "C" int hrtSetCommonVertexAttributes(const float4* vPos, const float4* vNorm, const float2* vTexCoord, const int* vMaterialIndices, int n);
extern "C" int hrtSetTangentAtrributes(const float4* vTan, int n);
extern "C" int hrtSetIndices32(const unsigned int* indices,int n);
extern "C" int hrtSetMaterialIndices32(const int* indices, int n);

extern "C" int hrtSetCurrAccelStructType(int a_type);
extern "C" int hrtSetWorldObjectListData(const char* in_objListData, uint in_sizeInBytes);
extern "C" int hrtSetPrmitiveListIndexData(const int* in_primListIndexData, uint in_size);

extern "C" int hrtSetWorldKdTree(const box3& box, const KdTreeNode* root, unsigned int nodes_count);
extern "C" int hrtSetWorldBVH(const BVHNode* root, unsigned int nodes_count);
      
extern "C" int hrtSetHydraMaterials(const RAYTR::HydraMaterial* materials,int n);

extern "C" int hrtSetLights(const RAYTR::Light* a_lights, int n);


extern "C" int hrtShadePass(int a_size, const float4* rpos, const uint* ldir, // light position
                            const HitPosNorm* hitPos, const HitTexCoord* hitNorm, const HitMatRef* matData,  const Lite_Hit* in_hits,
                            const ushort4* in_shadows, float4* inout_color);

extern "C" int hrtPostShadePass(int a_size, float4* rpos, float4* rdir,
                                const HitPosNorm* hitPos, const HitTexCoord* hitNorm, const HitMatRef* matData,
                                float4* inout_color, float2* aux_color, const int* a_inCompactIndices, int* a_outCompactIndices,
                                const float4* in_shaderColor, const Lite_Hit* in_liteHits,
                                RayFlags* pt_flags, uint* a_stencilBuffer, float4* out_rpos, float4* out_rdir);


extern "C" int hrtOctreeLookUpPass(int a_size, const HitPosNorm* in_hitPos, const HitTexCoord* in_hitNorm, const HitMatRef* in_matData, const Hit_Part4* in_tangent, 
                                   float4* inout_color, const ushort2* in_xy, ushort4* out_fullScreenIrradiance);

extern "C" int hrtComputeHitPass(int a_size, const float4* rpos, const float4* rdir, const Lite_Hit* in_hits,
                                 HitPosNorm* out_hitPos, HitTexCoord* out_hitNorm, HitMatRef* out_matData, Hit_Part4* out_hitTangent, unsigned int* a_stencilBuffer);

extern "C" int hrtTraverseRays1D(float4* gpu_rpos, float4* gpu_rdir, Lite_Hit* gpu_out_hit, int a_size);
extern "C" int hrtTraverseMegaBlock(float4* gpu_rpos, float4* gpu_rdir, Lite_Hit* gpu_out_hit, int a_size);
extern "C" int hrtTraceShadowRays(const HitPosNorm* in_hitPos, ushort4* shadows, uint* light_pos, int a_size);


extern "C" int hrtResetZOrderTo(float4* gpu_color, int w, int h);

extern "C" int hrtSetWindowResolution(int w, int h);
extern "C" int hrtVerifySystem();
extern "C" int hrtGetPerfInfo(float*, int index);
extern "C" size_t hrtGetAvaliableMemoryAmount();

extern "C" int hrtSetPBO(int a_pbo);
extern "C" int hrtGetMegaBlockSize();
extern "C" int hrtSetFlags(int bits,int value);
extern "C" int hrtSetVariableF(int name, float value);
extern "C" int hrtSetVariableI(int name, int value);

extern "C" int hrtDumpFloat4Buffer(const float4* a_gpu_buff, int size, const char* fileName);
extern "C" int hrtDumpBuffer(const void* a_gpu_buff, int byteSize, const char* fileName);
extern "C" int hrtLoadBuffer(const char* a_gpu_buff, int byteSize, const char* fileName);

extern "C" int hrtGetBuffer(const char* a_buffName, void* data, int byteSize);

extern "C" float hrtGetRaysPerSec();
extern "C" float hrtGetSamplesPerSec();
extern "C" float hrtGetTraceTimePerCent();

extern "C" int hrtStorePositionsAndNormalsForIC(int a_size);
extern "C" int hlmAllocIrradianceCacheFullScreenBuffers(int size, int allocPart = 2);
extern "C" int hlmFreeIrradianceCacheFullScreenBuffers();
extern "C" int hlmCalcSurfaceDiscontinuity(float* discontinuityMips, float* pixelSize);
extern "C" int hlmCalcRadianceDiscontinuity(float* a_discontinuityCPU, int a_size, int a_minPixelStep);


extern "C" int hrtClearMegaTextures();
extern "C" int hrtAddMegaTexture4ub(const char* usage, bool outOfCore, const char* data, int width, int height, const float4* lut, int lutSize);

extern "C" int hrtCreateEnvLightMapCube(int w, int h, const void* data[6]);

extern "C" int hrtCreateEnvLightMapSphereHDR(int w, int h, const float* data);
extern "C" int hrtCreateEnvLightMapSphereLDR(int w, int h, const unsigned char* data);

// ray samples filtering
//
extern "C" int hrtPutRaySamplesColorXY(float4* a_data, const float4* a_geomData, int a_size, int a_offsetFirstPixel);
extern "C" int hrtPutRaySamplesGeom(const float4* a_geomData, int a_size, int a_layer);
extern "C" int hrtPutRaySamplesUV(const float4* a_uv, int a_size, int a_layer);
extern "C" int hrtPutRaySamplesShadow(const uint* a_uv, int a_size, int a_layer);

enum {AA_STRATIFICATION_X = 1, AA_STRATIFICATION_Y = 1};

enum FLAG_BITS{HRT_COMPUTE_SHADOWS = 1,
               HRT_DISABLE_SHADING = 2,     // need this flag for photon trace and bidirectional path tracing
               HRT_COMPUTE_INDIRRECT_LIGHTING = 4,
               HRT_USE_RANDOM_RAYS   = 8,
               HRT_SAVE_SURFACE_DATA = 16,
               HRT_TRACE_DEPTH       = 32,
               HRT_COMPUTE_IRRADIANCE_CACHE   = 64,
               HRT_SCREEN_BUFFER_16_BIT_FLOAT = 128, // not used(!)
               HRT_IRRDAIANCE_CACHE_FIND_SECONDARY = 256,
               HRT_USE_PATH_TRACING_INSTEAD_OF_RT  = 512,
               HRT_DISABLE_BUMP = 1024,
               HRT_ENV_MAP_CUBEMAP_ACTIVE   = 2048,
               HRT_ENV_MAP_SPHEREMAP_ACTIVE = 4096,
               HRT_STORE_RAY_SAMPLES    = 8192,
               HRT_USE_HDR_ESTIMATION   = 16384,
               HRT_RC_HARMONICS         = 32768,
               HRT_RC_CUBEMAPS          = 65536,
               HRT_DIFFUSE_PHOTON_TRACING = 65536*2,
               HRT_CAUSTIC_PHOTON_TRACING = 65536*4,
               HRT_PHOTON_GARTHER_ENABLED = 65536*8,
               HRT_DUMMY                  = 65536*16, 
              };

enum VARIABLE_NAMES { HRT_TRACE_PROCEEDINGS_TRESHOLD = 1, HRT_ACCEPTABLE_PATH_TRACING_PIXEL_ERROR = 2,
                      HRT_DEBUG_DRAW_LAYER = 3,
                      HRT_ENABLE_DOF, HRT_DOF_LENS_RADIUS, HRT_DOF_FOCAL_PLANE_DIST,
                      HRT_DISABLE_MRAYS_COUNTERS, HRT_FIRST_BOUNCE_STORE_CACHE, HRT_IC_WS_ERROR_TRESHOLD,
                      HRT_DEBUG_SH_ENVIRONMENT, HRT_IC_HARMONIC_MEAN,
};


// globals for GPU


static __constant__ unsigned short MortonTable256[] = 
{
  0x0000, 0x0001, 0x0004, 0x0005, 0x0010, 0x0011, 0x0014, 0x0015, 
  0x0040, 0x0041, 0x0044, 0x0045, 0x0050, 0x0051, 0x0054, 0x0055, 
  0x0100, 0x0101, 0x0104, 0x0105, 0x0110, 0x0111, 0x0114, 0x0115, 
  0x0140, 0x0141, 0x0144, 0x0145, 0x0150, 0x0151, 0x0154, 0x0155, 
  0x0400, 0x0401, 0x0404, 0x0405, 0x0410, 0x0411, 0x0414, 0x0415, 
  0x0440, 0x0441, 0x0444, 0x0445, 0x0450, 0x0451, 0x0454, 0x0455, 
  0x0500, 0x0501, 0x0504, 0x0505, 0x0510, 0x0511, 0x0514, 0x0515, 
  0x0540, 0x0541, 0x0544, 0x0545, 0x0550, 0x0551, 0x0554, 0x0555, 
  0x1000, 0x1001, 0x1004, 0x1005, 0x1010, 0x1011, 0x1014, 0x1015, 
  0x1040, 0x1041, 0x1044, 0x1045, 0x1050, 0x1051, 0x1054, 0x1055, 
  0x1100, 0x1101, 0x1104, 0x1105, 0x1110, 0x1111, 0x1114, 0x1115, 
  0x1140, 0x1141, 0x1144, 0x1145, 0x1150, 0x1151, 0x1154, 0x1155, 
  0x1400, 0x1401, 0x1404, 0x1405, 0x1410, 0x1411, 0x1414, 0x1415, 
  0x1440, 0x1441, 0x1444, 0x1445, 0x1450, 0x1451, 0x1454, 0x1455, 
  0x1500, 0x1501, 0x1504, 0x1505, 0x1510, 0x1511, 0x1514, 0x1515, 
  0x1540, 0x1541, 0x1544, 0x1545, 0x1550, 0x1551, 0x1554, 0x1555, 
  0x4000, 0x4001, 0x4004, 0x4005, 0x4010, 0x4011, 0x4014, 0x4015, 
  0x4040, 0x4041, 0x4044, 0x4045, 0x4050, 0x4051, 0x4054, 0x4055, 
  0x4100, 0x4101, 0x4104, 0x4105, 0x4110, 0x4111, 0x4114, 0x4115, 
  0x4140, 0x4141, 0x4144, 0x4145, 0x4150, 0x4151, 0x4154, 0x4155, 
  0x4400, 0x4401, 0x4404, 0x4405, 0x4410, 0x4411, 0x4414, 0x4415, 
  0x4440, 0x4441, 0x4444, 0x4445, 0x4450, 0x4451, 0x4454, 0x4455, 
  0x4500, 0x4501, 0x4504, 0x4505, 0x4510, 0x4511, 0x4514, 0x4515, 
  0x4540, 0x4541, 0x4544, 0x4545, 0x4550, 0x4551, 0x4554, 0x4555, 
  0x5000, 0x5001, 0x5004, 0x5005, 0x5010, 0x5011, 0x5014, 0x5015, 
  0x5040, 0x5041, 0x5044, 0x5045, 0x5050, 0x5051, 0x5054, 0x5055, 
  0x5100, 0x5101, 0x5104, 0x5105, 0x5110, 0x5111, 0x5114, 0x5115, 
  0x5140, 0x5141, 0x5144, 0x5145, 0x5150, 0x5151, 0x5154, 0x5155, 
  0x5400, 0x5401, 0x5404, 0x5405, 0x5410, 0x5411, 0x5414, 0x5415, 
  0x5440, 0x5441, 0x5444, 0x5445, 0x5450, 0x5451, 0x5454, 0x5455, 
  0x5500, 0x5501, 0x5504, 0x5505, 0x5510, 0x5511, 0x5514, 0x5515, 
  0x5540, 0x5541, 0x5544, 0x5545, 0x5550, 0x5551, 0x5554, 0x5555
};

static inline universal_call uint ZIndex(ushort x,ushort y)
{
  return	MortonTable256[y >> 8]   << 17 | 
          MortonTable256[x >> 8]   << 16 |
          MortonTable256[y & 0xFF] <<  1 | 
          MortonTable256[x & 0xFF];
}

static inline universal_call unsigned short ExtractXFromZIndex(unsigned int zIndex)
{
  int result = 0;
  for(int i=0;i<16;i++)
    result |= ((1 << 2*i) & zIndex) >> i;
  return (unsigned short)result;
}


static inline universal_call unsigned short ExtractYFromZIndex(unsigned int zIndex)
{
  int result = 0;
  for(int i=0;i<16;i++)
    result |= ((1 << (2*i+1)) & zIndex ) >> i;
  return (unsigned short)(result >> 1);
}




#ifdef __CUDACC__

#include <cuda.h>
#include <cuda_runtime.h>
#include "cutilStuff.h"

#include <iostream>
#include <fstream>

struct Hardware_Ray_Tracer
{
	Hardware_Ray_Tracer();
	~Hardware_Ray_Tracer();

  void InitTexRefs();
  void BindAllTexRefs();
  void UnbindAllTexRefs();

  void SetCurrLight(const int in_lightIndex);

  int GpuMemSet(void* in_gpuBuffer,int value, int size);
  int GpuMemSetF(void* in_gpuBuffer, float value, int in_size);
  int CalcPersistentThreadsAndResetWarpCounter(int size, int regCount, int myThreadCount, bool debugOutput = false);

	int width,height;

	int numSpheres;
	int numVertices;
	int numIndices;
  
  RAYTR::Light* m_lights;
  int m_numLights;

  bool m_colorShadows;

	sphere4* sphere_memory;
	uint* index_memory;
  float4* m_triangleMatrices;

  // ACCEL STRUCTURES
	char* world_kd_tree_memory;
	char* m_primListMemory;
  BVHNode* m_worldBVH;
  uint*    m_primIndices;

  int m_kdTreeSize;
  int m_bvhSize;
  int m_primListSize;
  int m_primListIndicesSize;

  float4* m_vertPositionsAndMatIndex; // x,y,z - positions; __float_as_int(w) - material id
  float4* m_vertNormals;
  float4* m_vertTangent;
  float2* m_vertTexCoord;
  uint*   m_vertCompressedNormals;

  int*    m_matIndicesPerTriangle;
  int     m_numMaterialIndicesPerTriangle;

  // struct ray-permmanent ?
  float4*   m_raysPos;
  float4*   m_raysDir;
  
  float4*   m_raysPos2;
  float4*   m_raysDir2;
  
  int*      m_compactionIndices[2];
  // \\ used for rays compaction

  ushort2*  m_xy; // full screen

  //
  //
  uint*        m_shadowLightVector;
	Lite_Hit*	   hits;
  HitPosNorm*  m_hitPos;
  HitTexCoord* m_hitUV0;
  HitMatRef*   m_hitMaterial;
  Hit_Part4*   m_hitTangent;
  float*       m_frustumDepth;
	ushort4*     shadows;
  

  //
  //
  struct PhotonMapOutput
  {
    HitPosNorm*  m_pPosNorm;
    ushort4*     m_pColor;
    int          m_maxSize;
    int          m_currSize;
  }photonmap;

  enum {MAX_LEAFES_INTERSECT = 32};
  enum {POINT_LIGHT_SHADING_TYPE, 
        SPOT_LIGHT_SHADING_TYPE, 
        FLAT_LIGHT_SAMPLE_SHADING_TYPE};

  float4* m_color;
  float4* m_color3;

  float4* m_shaderColor; // 
  float2* m_auxNextColor; // store green and blue component when reflect or refract ray

  HydraMaterial* m_hydraMaterials;
  uint m_hydraMaterialsSize;

  uint m_PBO;
  uint* m_pboBuffer;

  uint* m_stencilBuffer;
  RayFlags* m_pathFlags;

  int m_currAccelStruct;
  bool m_useInputRays;
  bool m_colectIrradiance;
  bool m_storeDepth;

  int m_gpuNumber;
  int m_traceDepthCounter;
  int MEGA_BLOCK_SIZE;

  IrradianceCachePoint_Part1* m_cpu_lightCache1;
  IrradianceCachePoint_Part2* m_cpu_lightCache2;
  int m_lastCacheOffset;
  
  ushort4* m_fullScreenIrradiance;
  
  int m_traceDepth;
  float m_ray_traversal_time;
  int m_traversed_rays;
  float m_sampleEvalTime;
  int m_evaledSamples;
  bool m_skipThreadSyncronisation; // static bool SKIP_CUDA_THREAD_SYNC = true;
  bool m_firstBounceStoreCache;


  int g_flags;

  cudaDeviceProp m_devProp;
  
  int m_debugDrawLayer;
  float m_icWSErrorTreshold;
  
  ushort* m_tempBuffers[16];
  float4* m_tempCachePosBuffer;
  int     m_tempCachePosBufferSize;

  enum {MEGA_TEX_MAX_NUMBER = 4};
  cudaArray* m_megaTexturesData[MEGA_TEX_MAX_NUMBER];
  void*      m_megaTexPinnedData[MEGA_TEX_MAX_NUMBER];
  float4* m_megaTexLUTs[MEGA_TEX_MAX_NUMBER];
  int m_megaTexDataTop;

  bool m_shadingTextureSWEnabled;
  bool m_normalmapTextureSWEnabled;

  cudaArray* m_pEnvMap;
  bool m_debugShEnvMap;

  inline bool RaySamplesSavingEnabled() const { return ((g_flags & HRT_STORE_RAY_SAMPLES) && (g_flags & HRT_USE_RANDOM_RAYS));}
  int m_raySampleNumber;
  int m_icHarmonicMean;
};

typedef Hardware_Ray_Tracer HRT;

//struct Hardware_Light_Cache
//{
//  IrradianceCachePoint_Part1* m_part1;
//  IrradianceCachePoint_Part2* m_part2;
//  IrradianceCachePoint_Part3* m_part3;
//};



__constant__ int  window_size[2];
__constant__ float pWorldKdTreeBox[sizeof(box3)/sizeof(float)];

__constant__ float g_sceneBoundingSphereDiameter;

__constant__ RAYTR::Light cm_light;

__constant__ int cm_maxThread;

__constant__ int cm_megaBlockSize; 
__constant__ int cm_multiSampleBlockSize[2]; 

__constant__ int g_flags;
__constant__ int g_currBounce;
__constant__ int g_maxBounce;
__constant__ int g_diffuseMaxBounce;

__constant__ float g_traceProocedingsTreshold;
__constant__ float g_pathTraceError;

__constant__ int g_AAScaleX;
__constant__ int g_AAScaleY;

__constant__ float g_dofFocalPlaneDist;
__constant__ float g_dofLensRadius;
__constant__ int   g_dofEnable;

__constant__ int   g_useLoyalEstimationFunction;
__constant__ int   g_loyalEstimationFunctionTresholdInRays;

__constant__ int g_threadZeroOffset;

__constant__ float cm_gamma[2];
__constant__ float cm_koefGamma[2];

//__constant__ float4* cm_triangleAddress;
//__constant__ int*    cm_triIndAddress;

__constant__ float3  cm_icache_kd_tree_box[2];

// path tracing and irradiance cache constants
//
__constant__ int cm_raysPerPixel = 1;
__constant__ int cm_zBlocks;
__constant__ int cm_maxThreadId;
__constant__ int cm_oddEvenStep = 0;

__constant__ int cm_hemisphereRaysSize[4];
__constant__ int cm_hemRaysIndex = 1;

__constant__ float3 cm_octreeCenter;
__constant__ float  cm_octreeSize;
__constant__ float  g_serchRadiusSquare; 
__constant__ float  g_searchRadius; 
__constant__ float  g_searchRadiusInv; 

__constant__ float  g_cubemapSize;

__constant__ float4x4 g_mViewProjInv;
__constant__ float4x4 g_mWorldViewInv;

__constant__ float g_gamma = 2.2f;

static __device__ int g_warpCounter; // Work counter for persistent threads.

static __device__ int g_stencilMask[32] = {
  0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080,
  0x00000100, 0x00000200, 0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000,
  0x00010000, 0x00020000, 0x00040000, 0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000,
  0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000
};

__constant__ int g_disablePOMbecauseOfSpeed = 0;
__constant__ int g_envmapUseSHReconstruction = 0;
__constant__ int g_debugLayerDraw = 0;


#define PERSISTENT_THREAD_ID(tid,BLOCK_SIZE)    \
__shared__ int s_nextWarpId[(BLOCK_SIZE)/32];   \
int& nextWarpId = s_nextWarpId[threadIdx.x/32]; \
if(threadIdx.x % 32 == 0)                       \
nextWarpId = atomicAdd(&g_warpCounter, 32);     \
tid = nextWarpId + threadIdx.x % 32;            \
if(tid >= cm_maxThread) return;

//#define STENCIL_TEST(tid) \
  // if(!(tex1Dfetch(stencil_tex, (tid) >> 5) & (1 << ((tid)&0x0000001f) ))) \
    // return;

#define STENCIL_TEST2(tid, a_size) \
  if( (tid) >= (a_size) || !(tex1Dfetch(stencil_tex, (tid) >> 5) & (1 << ((tid)&0x0000001f) ))) \
  return;

//#define STENCIL_TEST(tid) \
  //if(!(tex1Dfetch(stencil_tex, (tid) >> 5) & g_stencilMask[(tid)&0x0000001f]) ) \
    //return;

//inline __host__ int blocks(int N, int threadsPerBlock) { return (N/threadsPerBlock)+1; } 
inline __host__ int blocks(int N, int threadsPerBlock)   { return (N + threadsPerBlock - 1)/threadsPerBlock; }

inline __device__ int Index2D(int x, int y) { return y*window_size[0] + x; }
inline __device__ int Index2D(int x, int y, int pitch) { return y*pitch + x; }
inline __device__ int IndexZBlock2D(int x, int y) 
{ 
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint zIndex = ZIndex(zOrderX, zOrderY);

  uint wBlocks = window_size[0]/Z_ORDER_BLOCK_SIZE;
  uint blockX = x/Z_ORDER_BLOCK_SIZE;
  uint blockY = y/Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex; 
}


//////////////////////////////////////////////////////////////////////////////////
////
__host__ void SafeGpuMemSet(void* in_gpuBuffer,int value, int size, char* file, int line);
#define SAFE_GPU_MEMSET(buff,value,size) SafeGpuMemSet((buff),(value),(size),__FILE__,__LINE__)


texture<uint4 , 1, cudaReadModeElementType> sph_tex;

texture<float4, 1, cudaReadModeElementType> vert_pos_tex;
texture<float4, 1, cudaReadModeElementType> vert_tangent_tex;
texture<float2, 1, cudaReadModeElementType> vert_texCoord_tex;
texture<uint , 1, cudaReadModeElementType>  vert_indices_tex;
texture<uint , 1, cudaReadModeElementType>  triMatInd_tex;
texture<uint, 1, cudaReadModeElementType>   vertNormCompressed_tex;

texture<uint2 , 1, cudaReadModeElementType> world_kd_tree_tex;
texture<float4, 1, cudaReadModeElementType> bvh_tex;
texture<float4, 1, cudaReadModeElementType> primLists_tex;
texture<uint,   1, cudaReadModeElementType> primIndices_tex;
texture<float,  1, cudaReadModeElementType> shmat_tex;

texture<float4, 1, cudaReadModeElementType> real_color_tex;

// path tracing and irradiance cache textures
//
texture<float4, 1, cudaReadModeElementType> icache1_tex;
texture<float4, 1, cudaReadModeElementType> icache2_tex;

texture<uint4, 1, cudaReadModeElementType> zblocks_tex;

texture<float4, 1, cudaReadModeElementType> pathTracingColor_tex;

texture<float4, 1, cudaReadModeElementType> hemisphereRaysDir_tex;

texture<float4, 1, cudaReadModeElementType> iCachePos_tex;
texture<float4, 1, cudaReadModeElementType> iCacheNorm_tex;
texture<float4, 1, cudaReadModeElementType> iCacheColor_tex;

texture<float4, 1, cudaReadModeElementType> iCacheCompressed1_tex;
texture<uint4,  1, cudaReadModeElementType> iCacheCompressed2_tex;

texture<float2, 1, cudaReadModeElementType> octree_tex;
texture<uint,   1, cudaReadModeElementType> icache_indices_tex;

texture<uint, 1, cudaReadModeElementType>   stencil_tex;


texture<float4, 2, cudaReadModeElementType>          input4fTemp1_tex;
texture<float, 2, cudaReadModeElementType>           input1fTemp1_tex;
texture<unsigned short, 2, cudaReadModeElementType>  input1hTemp1_tex;

texture<float, 2, cudaReadModeElementType>  surfDiscMip0_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip1_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip2_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip3_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip4_tex;

__constant__ int g_hdrEnvMap = 0;
texture<uchar4,  2, cudaReadModeNormalizedFloat>  envMap;
texture<ushort4, 2, cudaReadModeNormalizedFloat>  envMap2;

texture<uchar4, cudaTextureTypeCubemap, cudaReadModeNormalizedFloat>  envMapCube;

template<class Data>
struct SWTexture
{
  int width;
  int height;
  const Data* data;
};

__constant__ SWTexture<uchar4> shadingTextureSW;
__constant__ SWTexture<uchar4> normalmapTextureSW;

texture<uchar4, 2, cudaReadModeNormalizedFloat> shadingTexture;
texture<uchar4, 2, cudaReadModeNormalizedFloat> transparencyTexture;
texture<uchar4, 2, cudaReadModeNormalizedFloat> normalmapTexture;

texture<float4, 1, cudaReadModeElementType> shadingTextureLUT;
texture<float4, 1, cudaReadModeElementType> transparencyTextureLUT;
texture<float4, 1, cudaReadModeElementType> normalmapTextureLUT;

//__constant__ float 



#endif
