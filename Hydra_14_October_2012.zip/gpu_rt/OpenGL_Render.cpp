// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include "OpenGL_Render.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
OpenGL_Render::OpenGL_Render(int w, int h, bool a_wireFrame): Common_Graphics_Engine(w,h)
{
  BuildFont();

	float z_near  = 0.1f;
	float z_far   = 1e4f;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective( 45.0f, (GLfloat)w/(GLfloat)h, z_near, z_far);

	glMatrixMode(GL_MODELVIEW);
	glClearColor(0.0,0.0,0.25,0);

	QuadrObj=gluNewQuadric(); 

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_TEXTURE_2D);
	glClearDepth(1.0f);									
	
	glDepthFunc(GL_LEQUAL);
	glFrontFace(GL_CCW);

	glEnable(GL_LIGHTING);

	init_scene_list = true;
  m_wireFrame = a_wireFrame;

  // debug data
  //
  m_debugRaysPos = m_debugRaysDir = NULL;
  m_debugOctree = NULL;
  m_debugBoxes = NULL;
  m_degugDrawIndex = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
OpenGL_Render::~OpenGL_Render()
{
  delete m_debugOctree;

  KillFont();
  delete [] m_debugBoxes;
  delete [] m_debugRaysPos;
  delete [] m_debugRaysDir;
} 


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
unsigned int OpenGL_Render::AddTexture(const void* memory, unsigned int w, unsigned int h, unsigned int format)
{
  return Base::AddTexture(memory,w,h,format);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::setLights()
{
	for(int i=0;i<m_lights.size();i++)
	{
		GLuint light_index;
		switch(i)
		{
		case 0:
			light_index = GL_LIGHT0;
			break;

		case 1:
			light_index = GL_LIGHT1;
			break;

		case 2:
			light_index = GL_LIGHT2;
			break;

		case 3:
			light_index = GL_LIGHT3;
			break;

		case 4:
			light_index = GL_LIGHT4;
			break;

		case 5:
			light_index = GL_LIGHT5;
			break;
			
		case 6:
			light_index = GL_LIGHT6;
			break;

		case 7:
			light_index = GL_LIGHT7;
			break;

		default:
			RUN_TIME_ERROR("Can not use more than 8 lights, num: " + ToString(i));
		};
		
		glEnable(light_index);
		glLightfv (light_index, GL_POSITION, m_lights[i].pos.M);

		vec3f ambient = m_lights[i].color*0.15f;
		vec3f diffuse = m_lights[i].color*0.8f;
		vec3f specular = m_lights[i].color*1.0f;

		glLightfv (light_index, GL_AMBIENT,  (0.25f*ambient).M);
		glLightfv (light_index, GL_DIFFUSE,  (0.5f*diffuse).M);
		glLightfv (light_index, GL_SPECULAR, specular.M);

		float kc = m_lights[i].kc;
		float kl = m_lights[i].kl;
		float kq = m_lights[i].kq;
		vec4f v_kc(kc,kc,kc,kc);
		vec4f v_kl(kl,kl,kl,kl);
		vec4f v_kq(kq,kq,kq,kq);

		//glLightfv (light_index, GL_CONSTANT_ATTENUATION,	v_kc.M);
		//glLightfv (light_index, GL_LINEAR_ATTENUATION,		v_kl.M);
	  //glLightfv (light_index, GL_QUADRATIC_ATTENUATION,	v_kq.M);

	}
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::BeginDrawScene(RenderState a_renderState)
{
  m_lastRenderState = a_renderState;

  if(!m_dataVerifyed)
    VerifyAllData();

  if(!m_materialsWasTransformed)
  {
    TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);
    m_materialsWasTransformed = true;
  }

  //glEnable(GL_CULL_FACE);
  //glCullFace(GL_BACK);

	//CopyDataToGPU();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

  Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
  Matrix4x4f mProj  = Matrix4x4f(m_projectionMatrixData);

  glMatrixMode(GL_PROJECTION);
  glLoadMatrixf(mProj.L);

  glMatrixMode(GL_MODELVIEW);
  glLoadMatrixf(mWorldView.L);
	
  //glLoadIdentity();
	//glMultMatrixf(pWorld_matrix->L);

	setLights();
	DrawLights();
	glPushMatrix();

  glEnable(GL_LIGHTING);
  glDisable(GL_TEXTURE_2D);
	for(int i=0;i<m_spheres.size();i++)
	{
    const RAYTR::HydraMaterial& mat = m_hydraMaterials[m_spheres[i].material_id];
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat.ambient.color.M);
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat.diffuse.color.M);
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat.specular.color.M);
    
    vec3f color = mat.diffuse.color;
    glColor3fv(color.M);

		glPushMatrix();
			vec4f pos = m_spheres[i].pos;
			glTranslatef(pos.x, pos.y, pos.z);
			gluSphere(QuadrObj,m_spheres[i].r, 20, 20);
		glPopMatrix();
	}
  glEnable(GL_TEXTURE_2D);

	if(init_scene_list)
  {
		all_scene_list.Init(&m_index[0], uint(m_index.size()), this);
		init_scene_list = false;
    //CalcTangentSpace();
	}

	all_scene_list.Draw();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	
  glColor3f(0,1,0);
  
  /*
  if(m_pKdTreeBuilder!=NULL)
  {
    const KdTree* pKdTree = (const KdTree*)m_pKdTreeBuilder->GetSpecificDataStructurePointer("vfrolov_KdTree");
    
    if(pKdTree!= NULL && pKdTree->DebugTree() != NULL)
      pKdTree->DebugDrawDynamicTree();
    else if(pKdTree!= NULL)
      pKdTree->Draw();
  }
 
  
  if(m_pBVHBuilder!=NULL)
  {
    BVHTree* pBVHTree = (BVHTree*)m_pBVHBuilder->GetSpecificDataStructurePointer("vfrolov_BVHTree");
    glColor3f(0,1,1);
    if(pBVHTree!= NULL)
    {
      pBVHTree->SetDebugNodeIndex(m_degugDrawIndex);
      pBVHTree->Draw();
    }
  }*/
  

  //glColor3f(1,1,0);
  //DebugDrawTangents();
  //DebugDrawNormals();
  
  //glColor3f(1,0,0);
  //DebugDrawRays();
  //DebugDrawPoints();
  //DebugDrawSphericalDistribution();
  //DebugDrawColoredPoints();
  //DebugDrawBoxes();

  //glColor3f(0,0,1);
  //DebugDrawCurrRayPacket();
	
  glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);

  glPopMatrix();

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::EndDrawScene()
{
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::GL_List::Init(const uint* indices,	uint num_ind, const OpenGL_Render* a_render)
{
	if(num_ind < 3)
		RUN_TIME_ERROR("OpenGL_Render::GL_List::Init: Less than one triangle: " + ToString(num_ind));

	render = a_render;


  if(render->m_wireFrame)
  {
    uint begin = 0, end = 3;

    glNewList(lists_num,GL_COMPILE);
    glColor3f(1,1,1);
    glDisable(GL_LIGHTING);
    glBegin(GL_LINES);
    for(size_t i=0;i<num_ind;i+=3)
    {
      int iA = render->m_index[i+0];
      int iB = render->m_index[i+1];
      int iC = render->m_index[i+2];

      float4 A = render->m_vertPos[iA];
      float4 B = render->m_vertPos[iB];
      float4 C = render->m_vertPos[iC];
     
      glVertex3fv(A.M);
      glVertex3fv(B.M);

      glVertex3fv(A.M);
      glVertex3fv(C.M);

      glVertex3fv(B.M);
      glVertex3fv(C.M);
    }
    glEnd();
    glEnable(GL_LIGHTING);
    glEndList();

    lists_num++;
  }
  else
  {
    glEnableClientState(GL_VERTEX_ARRAY); 
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    int counter = 2;

    uint begin = 0, end = 3;
    for(size_t i=3;i<num_ind;i+=3)
    {
      //int matIdPrev = render->m_vertMaterialId[indices[i-3]];
      //int matId = render->m_vertMaterialId[indices[i]];

      int matIdPrev = render->m_triangleMaterialId[i/3-1];
      int matId = render->m_triangleMaterialId[i/3];

      bool draw_prev_triangles = false;

      if(matIdPrev!=matId)
      {
        draw_prev_triangles = true;
      }
      else if(i == num_ind-3)
      {
        draw_prev_triangles = true;
        end+=3;
      }

      if(!draw_prev_triangles)
        end+=3;
      else
      {
        const RAYTR::HydraMaterial& mat = render->m_hydraMaterials[matIdPrev];
        const int gl_type = GL_FLOAT;
        const int dim = 4;

        glNewList(lists_num,GL_COMPILE);
        // set material
        glMaterialfv (GL_FRONT_AND_BACK,GL_AMBIENT, mat.ambient.color.M);
        glMaterialfv (GL_FRONT_AND_BACK,GL_DIFFUSE, mat.diffuse.color.M);
        glMaterialfv (GL_FRONT_AND_BACK,GL_SPECULAR, mat.specular.color.M);

        vec3f color = mat.diffuse.color;
        glColor3fv(color.M);
        // set texture
        if(mat.diffuse.color_texId < render->m_images.size())
        {
          glEnable(GL_TEXTURE_2D);
          //render->m_textures[mat.diffuse.color_texId].SetAsActiveTexture();
        }
        else
          glDisable(GL_TEXTURE_2D);

        glVertexPointer(3, gl_type,  sizeof(float4), (float*)(&render->m_vertPos[0]));
        glNormalPointer(gl_type,     sizeof(float4), (float*)(&render->m_vertNorm[0]));
        glTexCoordPointer(2,gl_type, sizeof(float2), (float*)(&render->m_vertTexCoord[0]));

        glPushMatrix();
        glDrawElements(GL_TRIANGLES,end-begin,GL_UNSIGNED_INT,begin+indices);
        glPopMatrix();

        glEndList();
        lists_num++;

        begin = end;
        end+=3;
      }
    }

    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
  }
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawNormals()
{
  glBegin(GL_LINES);
  for(int i=0;i<m_vertPos.size();i++)
  {
    //std::cout << GetVertexNorm(i) << std::endl;
    glVertex3fv(GetVertexPos(i).M);
    glVertex3fv((GetVertexPos(i) + 0.1f*GetVertexNorm(i)).M);
  }
  glEnd();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawSphericalDistribution()
{
  int index = MGML_MATH::MIN<int>(m_lastRenderState.GetTraceDepth()-1, 3);

  glBegin(GL_POINTS);
  for(int i=0;i<m_sphereUniformArray[index].size();i++)
    glVertex3fv(m_sphereUniformArray[index][i].M);
  glEnd();

  glColor3f(1,0.5,0.0);
  int index2 = index-1;
  if(index2 >= 0)
  {
    glBegin(GL_POINTS);
    for(int i=0;i<m_sphereUniformArray[index2].size();i++)
      glVertex3fv(m_sphereUniformArray[index2][i].M);
    glEnd();
  }

  glColor3f(1,0,0.0);
  int index3 = index-2;
  if(index3 >= 0)
  {
    glBegin(GL_POINTS);
    for(int i=0;i<m_sphereUniformArray[index3].size();i++)
      glVertex3fv(m_sphereUniformArray[index3][i].M);
    glEnd();
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawCurrRayPacket()
{
  if(m_degugDrawIndex*WARP_SIZE >= m_sphereUniformArray[1].size())
    return;

  int index = MGML_MATH::MIN<int>(m_lastRenderState.GetTraceDepth()-1, 3);

  glBegin(GL_LINES);
  for(int i=m_degugDrawIndex*WARP_SIZE;i<m_degugDrawIndex*WARP_SIZE+WARP_SIZE;i++)
  {
    glVertex3f(0,0,0);
    glVertex3fv(m_sphereUniformArray[index][i].M);
  }
  glEnd();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawColoredPoints()
{
  glBegin(GL_POINTS);
  for(int i=0;i<DEBUG_RAYS_SIZE;i++)
  {
    glColor3fv((m_debugRaysDir[i]*2).M);
    glVertex3fv(m_debugRaysPos[i].M);
  }
  glEnd();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawBoxes()
{
  for(int i=0;i<m_numDebugBoxes;i++)
  {
    float3 cent  = m_debugBoxes[i].center();
    float3 scale = m_debugBoxes[i].vmax - m_debugBoxes[i].vmin;

    glPushMatrix();
      glTranslatef(cent.x,cent.y,cent.z);
      glScalef(scale.x,scale.y,scale.z);
      glutWireCube(1);
    glPopMatrix();
  }


}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawRays()
{
  glBegin(GL_LINES);
  for(int i=0;i<DEBUG_RAYS_SIZE;i+=16)
  {
    glVertex3fv(m_debugRaysPos[i].M);
    glVertex3fv((m_debugRaysPos[i] + 0.10f*m_debugRaysDir[i]).M);
  }
  glEnd();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void OpenGL_Render::DebugDrawPoints()
{
  glBegin(GL_POINTS);
  for(int i=0;i<DEBUG_RAYS_SIZE;i++)
    glVertex3fv(m_debugRaysPos[i].M);
  glEnd();
}


void OpenGL_Render::DebugDrawTangents()
{
 /* glBegin(GL_LINES);
  for(int i=0;i<m_vertTangent.size();i++)
  {
    float4 tan = m_vertTangent[i];
    glVertex3fv(m_vertPos[i].M);
    glVertex3fv((m_vertPos[i] + 0.5f*tan).M);
  }
  glEnd();
  */
}



