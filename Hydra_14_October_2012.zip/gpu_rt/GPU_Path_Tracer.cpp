#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "IrradianceCache.h"


using MGML_MATH::EPSILON_E5;

void GPU_Path_Tracer::CheckBlockListF(GPU_Path_Tracer::BlockList* pList, const char* file, int line)
{
  GPU_Path_Tracer::BlockList::iterator p;
  int counter = 0;
  for(p=pList->begin(); p!= pList->end(); ++p)
  {
    if(p->index == 0)
      counter++;
  }

  if(counter > 1)
  {
    string c = ToString(counter);
    RunTimeError(file,line,"there are " + c + " blocks with index == 0");
  }

}

#define CHECK_LIST(plist) CheckBlockListF((plist),__FILE__,__LINE__)

/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::GPU_Path_Tracer(int w, int h, int flags) : Base(w,h,flags)
{
  m_pathTracingState = STATE_BEGIN;
  hmctInit(w,h);
  hlmInit();

  SetRaysPerPixel(1);

  m_blocksArray.resize((w*h)/(ZBlock::GetSize()));
  m_avgRaysPerPixel = 0;
  m_startScreenBlockListSize = 0;
  m_debugICacheFileOutput = false;

  for(int i=0;i<HEMISPHERE_SEQUENCE_NUM;i++)
  {
    hlmInitHemisphereRaysTexture(0, i, &m_sphereUniformArray[i][0], m_sphereUniformArray[i].size());
    hlmInitHemisphereRaysTexture(1, i, &m_sphereUniformArray2[i][0], m_sphereUniformArray2[i].size());
    hlmInitSHCoefficient(&m_shCoeffsArray[0], m_shResPhi, m_shResTheta, m_sphLayersNum);
  }

  m_pRC = NULL;
  m_pPhotonMap = hlmCreatePhotonMap(1000000);
  m_pCausticPhotonMap = hlmCreatePhotonMap(1000000);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::~GPU_Path_Tracer()
{
  hlmDeletePhotonMap(m_pCausticPhotonMap); m_pCausticPhotonMap = NULL;
  hlmDeletePhotonMap(m_pPhotonMap); m_pPhotonMap = NULL;
  delete m_pRC; m_pRC = NULL;

  BlockList::Free();
  hlmDelete();
  hmctDelete();
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::SetRenderingParams(const RenderingParams& a_params)
{
  m_params = a_params;
  hrtSetFlags(HRT_USE_HDR_ESTIMATION, m_params.useHDRQualityEstimation);
  
  m_pipeline->SetShaderVariable("g_pathTraceError",    a_params.qualityTreshold);
  m_pipeline->SetShaderVariable("g_dofEnable",         a_params.enableDOF);
  m_pipeline->SetShaderVariable("g_dofLensRadius",     a_params.dofLensRadius);
  m_pipeline->SetShaderVariable("g_dofFocalPlaneDist", a_params.dofFocalPlaneDist);

  m_pipeline->SetShaderVariable("g_useLoyalEstimationFunction", a_params.useLoyalEstimateFunction);
  m_pipeline->SetShaderVariable("g_loyalEstimationFunctionTresholdInRays", a_params.loaylEstimateFunctionTresholdInRays);

  m_rtOnlyVarDrawRaysStatInfo = m_params.drawRaysStatInfo;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::MakeScreenBlockList(BlockList* pList)
{ 
  while(!pList->empty())
    pList->pop_front();

  int BLOCK_NUMBER = m_blocksArray.size();
  
  BlockList::Free();
  BlockList::Allocate(BLOCK_NUMBER+10);
  
  m_zBlocksCoordByIndex.clear();
  for(int i=0;i<BLOCK_NUMBER;i++)
  {
    int x = (i*Z_ORDER_BLOCK_SIZE)%width; 
    int y = (i*ZBlock::GetSize() - x*Z_ORDER_BLOCK_SIZE)/width;
    m_zBlocksCoordByIndex[i] = vec2i(x,y); //  ������ ��� ���������

    pList->push_front(ZBlock(i,10000));
  }

  hmctGenerateEyeInitialRays();
  hmctClearColorBuffers();

  m_avgRaysPerPixel = 0; // zero when start

  // this variable need for the last pass of path tracing because i have some errors with
  // small size of kernel. so i need some hack. just reset this variable to 1 or 2
  m_lastPass = START_LAST_PASS;
  m_megaBlockPathTraceInProcess = false;
  forceEnd = false;
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DoMegaBlock(BlockList& a_blockList, RenderState a_renderState)
{
  if(a_blockList.empty() || forceEnd)
    return;
 
  const int zblocksInParallelNumber = hrtGetMegaBlockSize()/(ZBlock::GetSize()*m_currRaysPerPixel);

  // fetch first zblocksInParallelNumber ZBlocks from list and make array of it
  //
  int counter = 0;
  while(!a_blockList.empty() && counter < zblocksInParallelNumber)
  {
    m_blocksArray[counter] = *(a_blockList.begin());
    a_blockList.pop_front();
    counter++;
  }

  bool unprocessedTilesExists = (a_blockList.size() != 0);


  hmctSetZBlocks(&m_blocksArray[0], counter);

  for(int i=0;i<2;i++) // because eof odd and even sequences
  {
    ASSERT(counter*ZBlock::GetSize() <= hrtGetMegaBlockSize());
    hmctMegaBlockPathTraceSM(counter, 0);
  
    // compare old blocks colors with new, recompute and store the new result
    hmctCompareAndStoreResult(&m_blocksArray[0], counter);
  }

  m_pathTracingPassNumber += 2;


  // extract unprocessed block to separate array
  //
  std::vector<ZBlock> blockesInQueue; blockesInQueue.reserve(1000);
  while(!a_blockList.empty())
  {
    blockesInQueue.push_back(*(a_blockList.begin()));
    a_blockList.pop_front();
  }

  // now see the block quality metric and if it is too small, discard this block from the list
  //
  float maxError = 0.0f;
  float avgError = 0.0f;
  for(int i=0;i<counter;i++)
  {
    float error = 0;

    if (!BlockFinished(m_blocksArray[i], &error))
      a_blockList.push_front(m_blocksArray[i]);
    else
      m_avgRaysPerPixel += m_blocksArray[i].counter;

    if(error > maxError)
      maxError = error;
    avgError += error;
  }

  // push unprocessed blocks back to make them first in queue
  //
  for(int i=0;i<blockesInQueue.size();i++)
    a_blockList.push_front(blockesInQueue[i]);

  if(a_blockList.size() == 0)
    return;

  const int NBLOCKS = hrtGetMegaBlockSize()/ZBlock::GetSize();
  if(a_blockList.size()*m_currRaysPerPixel*2 <= NBLOCKS && !unprocessedTilesExists)
    SetRaysPerPixel(m_currRaysPerPixel*2);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::BlockFinished(const ZBlock& block, float* a_outDiff)
{
  // multi-jittered sampling (stratification)
  // stratification require, that we can stop only on each 4-th (2x2), 9-th (3x3), 16-th(4x4) or e.t.c steps
  //
  if(block.counter%(AA_STRATIFICATION_X*AA_STRATIFICATION_Y) != 0)
    return false; 

  float scale = 0.5f/CMP_RESULTS_BLOCK_SIZE;

  if(a_outDiff!=NULL)
    *a_outDiff = block.diff;

  float fewSampling = (m_params.minRaysPerPixel)/(block.counter + 1.0f);
  //float muchSampling = m_params.maxRaysPerPixel/(block.counter+1);

  scale *= fmaxf(fminf(fewSampling*fewSampling, 1.0f), 2.0f);

  if(block.counter > m_params.loaylEstimateFunctionTresholdInRays && m_params.useLoyalEstimateFunction) // a hack
  {
    float alpha = 1.0f - (float)block.counter/(float)m_params.maxRaysPerPixel;
    float kScale2 = alpha*alpha;
    if(kScale2 > 0.5f)  kScale2 = 0.5f;
    if(kScale2 < 0.25f) kScale2 = 0.25f;
    scale *= kScale2;
  }

  bool summErrorOk = (block.diff*scale < m_params.qualityTreshold);
  bool maxErrorOk  = false;

  return ((summErrorOk || maxErrorOk) && block.counter >= m_params.minRaysPerPixel) || (block.counter >= m_params.maxRaysPerPixel);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::ResetPathTracing()
{
  m_pathTracingState = STATE_BEGIN;
  m_pathTracingPassNumber = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::PathTracingFinished() const 
{ return m_screenBlockList.empty();}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::BeginPathTracingPass(RenderState a_renderState)
{
  GPU_Ray_Tracer::calcRayMatrix();
  GPU_Ray_Tracer::CopyDynamicDataToGPU();

  hrtMapGLScreenBuffers();

  int NTimes = (width*height)/hrtGetMegaBlockSize(); 
  if(NTimes < 2) NTimes = 2;

  switch (m_pathTracingState)
  {
  case STATE_BEGIN:

    MakeScreenBlockList(&m_screenBlockList);
    SetRaysPerPixel(1);

    hrtSetFlags(HRT_USE_RANDOM_RAYS, 1);
    hrtSetFlags(HRT_COMPUTE_SHADOWS, a_renderState.GetShadow());
    hrtSetFlags(HRT_TRACE_DEPTH, a_renderState.GetTraceDepth());
    hrtSetFlags(HRT_COMPUTE_INDIRRECT_LIGHTING, a_renderState.GetIndirrectIllumination());
    hrtSetFlags(HRT_COMPUTE_IRRADIANCE_CACHE | HRT_IRRDAIANCE_CACHE_FIND_SECONDARY, 0);

    hrtSetVariableF(HRT_IC_WS_ERROR_TRESHOLD, a_renderState.icWSErrorTreshold);
    hrtSetVariableF(HRT_TRACE_PROCEEDINGS_TRESHOLD, a_renderState.GetTraceProceedingsTreshold());
    hrtSetVariableI(HRT_DISABLE_MRAYS_COUNTERS, int(!a_renderState.GetEnableRaysCounter()));

    m_pipeline->SetShaderVariable("g_diffuseMaxBounce", a_renderState.GetDiffuseTraceDepth());

    m_startScreenBlockListSize = (int)m_screenBlockList.size();

    for(int i=0;i<NTimes;i++)
      DoMegaBlock(m_screenBlockList, a_renderState);

    m_pathTracingState = STATE_TRACING;
    break;

  case STATE_TRACING:

    if(m_screenBlockList.empty())
      m_pathTracingState = STATE_FINISHED;
    else
    {
      for(int i=0;i<NTimes;i++)
        DoMegaBlock(m_screenBlockList, a_renderState);
      
      if(m_screenBlockList.empty())
      {
        m_avgRaysPerPixel /= m_startScreenBlockListSize;
        m_avgRaysPerPixel *= m_currRaysPerPixel;
        m_pathTracingState = STATE_FINISHED;
      }
        
    }

    break;

  case STATE_FINISHED:
    break;
  }

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::EndPathTracingPass()
{
  hmctCopyColorToScreenBuffer();
  
  GPU_Ray_Tracer::EndDrawScene();
  
  DegudDrawActiveBlocksAndStatisticsData();

  return m_screenBlockList.empty() || forceEnd;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DumpBufferToFile(const char* a_buffName, const char* a_fileName)
{
  if(hmctDumpDataBuffer(a_buffName, a_fileName) != 0)
    RUN_TIME_ERROR("can't save color buffer, may be you need to create 'out_relight_data' folder");
}



/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DegudDrawActiveBlocksAndStatisticsData()
{
  int counter=0;
  if(m_params.drawBlocks)
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glViewport(0,0, width, height);
    // set up the projection matrix
    glMatrixMode(GL_PROJECTION);
    // clear any previous transform and set to the identity matrix
    glLoadIdentity();

    // just use an orthographic projection
    glOrtho(0,width,0,height, -1,1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClear(GL_DEPTH_BUFFER_BIT);

    glColor3f(1,0,0);
    glBegin(GL_LINES);

    int size = Z_ORDER_BLOCK_SIZE;
    BlockList::iterator p;
    for(p=m_screenBlockList.begin();p!=m_screenBlockList.end();++p)
    {
      vec2i coord = m_zBlocksCoordByIndex[p->index];

      if(p->counter!=0)
      {
        glVertex2f(coord.x, coord.y);
        glVertex2f(coord.x+size, coord.y);

        glVertex2f(coord.x+size, coord.y);
        glVertex2f(coord.x+size, coord.y+size);

        glVertex2f(coord.x+size, coord.y+size);
        glVertex2f(coord.x, coord.y+size);

        glVertex2f(coord.x, coord.y+size);
        glVertex2f(coord.x, coord.y);
      }
      counter++;
    }

    glEnd();
  }
  
  if(m_params.drawRaysStatInfo)
  {
    glClear(GL_DEPTH_BUFFER_BIT);
    glPushAttrib(103010); //GL_RASTER_POSITION_UNCLIPPED_IBM
    glColor3f(1,1,0);

    float startY = height - 20;
  
    glRasterPos2f(10, startY-80);
    glPrint("RAYS_PER_PIXEL: %d", m_currRaysPerPixel);

    glRasterPos2f(10, startY-60);
    glPrint("ACTIVE_TILES  : %d", counter);
    glPopAttrib();
  }
}



void GPU_Path_Tracer::DebugCall(const std::string& a_name, const std::string& a_params)
{
  Base::DebugCall(a_name, a_params);
  
  if(a_name == "TracePhotonsTest")
  {
    m_pPhotonMap->TracePhotons();
    m_pPhotonMap->DebugSaveToFile("phPos.txt", "phNorm.txt", "phColor.txt");

    std::cout << "TracePhotonsTest called" << std::endl;
  }


}

