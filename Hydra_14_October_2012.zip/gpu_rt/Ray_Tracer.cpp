// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include "Ray_Tracer.h"

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::Ray_Tracer(int w, int h): Common_Graphics_Engine(w,h)
{
  m_LebedevBRDFs = new LebedevMaterial[MAX_LEBEDEV_BRDFS];
  m_numLebedevBRDFs = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::~Ray_Tracer()
{
  delete m_LebedevBRDFs;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::calcRayMatrix()
{
  if(m_camMatrixWasSet)
  {
	  //pWorld_matrix->Inverse();
    (*pWorld_matrix) = SafeInverse(*pWorld_matrix);
	  pWorld_matrix->Transpose(); // cause OpenGL store matrix by columns 
    m_camMatrixWasSet = false;
  }

  Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
  Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);

  Matrix4x4f mProjInverse      = SafeInverse(mProj).GetTranspose();
  Matrix4x4f mWorldViewInverse = SafeInverse(mWorldView).GetTranspose();

  memcpy(m_projectInvMatrixData, mProjInverse.L, 16*sizeof(float));
  memcpy(m_worldViewInvMatrixData, mWorldViewInverse.L, 16*sizeof(float));
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::RT_Core::SetMatrix(const MGML::Matrix4x4f &m)
{ 
	mRaysTransfrom = m;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
int Ray_Tracer::AddLebedevMaterial(const LebedevMaterial& a_mat)
{
  if (m_numLebedevBRDFs + 1 >= MAX_LEBEDEV_BRDFS) 
    RUN_TIME_ERROR("Too many Andrey's Lebedev materials");

  m_LebedevBRDFs[m_numLebedevBRDFs] = a_mat;
  m_numLebedevBRDFs++;
  return m_numLebedevBRDFs-1;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::AddLightsAsGeometry()
{
  TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);

  const float lightIntensityValue = 1.0f;

  for(int lightIndex=0; lightIndex < m_lights.size(); lightIndex++)
  {
    Light* pLight = &m_lights[lightIndex];

    if( pLight->GetLightType() == Light::LIGHT_TYPE_POINT || 
        pLight->GetLightType() == Light::LIGHT_TYPE_SPOT  || 
        pLight->GetLightType() == Light::LIGHT_TYPE_DIRECTIONAL ||
        pLight->GetLightType() == Light::LIGHT_TYPE_SKY ||
        !(pLight->flags & Light::LIGHT_AS_GEOMETRY))
      continue;

    RAYTR::HydraMaterial material;
    material.ambient.color = pLight->color*lightIntensityValue;
    material.ambient.light_multiplyer = 20;
    material.flags |= HydraMaterial::THIS_IS_LIGHT;
    material.ambient.light_id = lightIndex;

    //RAYTR::Material material;
    //material.ka = pLight->color*lightIntensityValue*20;
    //material.SetThisIsLight(true, lightIndex);

    int addedMaterialId = this->AddMaterial(material);

    // now add geometry of light
    
    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA)
    {
      // quad triangles
      const int numVert = 4;
      const int numIndices = 6;
      Vertex4f  vert[numVert];
      unsigned int indices[numIndices];

      // triangles
      vec2f size = pLight->GetAreaLightSize();
      vert[0].pos.set(-size.x, 0, -size.y, 1); vert[0].norm = to_float4(pLight->GetNormal(),1);
      vert[1].pos.set(-size.x, 0, size.y, 1);  vert[1].norm = to_float4(pLight->GetNormal(),1);
      vert[2].pos.set(size.x, 0, size.y, 1);   vert[2].norm = to_float4(pLight->GetNormal(),1);
      vert[3].pos.set(size.x, 0, -size.y, 1);  vert[3].norm = to_float4(pLight->GetNormal(),1);

      Matrix4x4f mTransform, mRotation, mTranslate;
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          mRotation.M[i][j] = pLight->GetMatrixElem(i,j);
      mTranslate.SetTranslate(pLight->pos);
      mTransform = mTranslate*mRotation;

      for(int i=0;i<4;i++)
      {
        vert[i].pos = mTransform*vert[i].pos;
        vert[i].material_id = addedMaterialId;
      }

      indices[0]=0;indices[1]=1;indices[2]=2;
      indices[3]=2;indices[4]=3;indices[5]=0;

      this->AddTriangles(vert,numVert,indices,numIndices);
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPHERICAL)
    {      
      Sphere4f sph;
      sph = Sphere4f(vec4f(pLight->pos.x, pLight->pos.y, pLight->pos.z,1), pLight->GetSphericalLightRadius());
      sph.material_id = addedMaterialId;
      int id = this->AddSpheres(&sph,1);
      pLight->SetPrimitiveId(id);
    }
    else
      RUN_TIME_ERROR("AddLightsAsGeometry: unknown light type");
  }

  m_lightsWasAddedAsGeometry = true;
}