// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include <GL/glew.h>

#include "../MegaTexture/MegaTexture/MegaTextureManager.h"

#include "GPU_Ray_Tracer.h"
#include "Fonts.h"

#include <map>
#include <string>

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

using std::map;
using std::string;

bool USE_PBO = true; 

///////////////////////////////////////////////////////////////////////////////////
////
GPU_Ray_Tracer::GPU_Ray_Tracer(int w, int h, int flags): Ray_Tracer(w,h) 
{
  m_pipeline = new SGA::CUDAPipeline();

  hrtInit(width, height, flags);

  InitPBO(&m_pixelBufferObject);

  m_rtOnlyVarDrawRaysStatInfo = false;

#ifdef PRINT_SHMAT_OFFSETS
    PrintMaterialParametersOffsets("hmat_offsets.h");
#endif
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::InitPBO(GLuint* a_pBuffer)
{
  GLuint& pixelBuffer = *a_pBuffer;

  while (glGetError() != GL_NO_ERROR); // ��������� �� ������� ��� ������ OpenGL.
  
  ASSERT(screen_buffer!=0);
  for(int i=0;i<width*height;i++)
    screen_buffer[i] = 0x000000FF;

  for(int i=0;i<(width/2)*height;i++)
    screen_buffer[i] = 0x00FF0000;

  glewInit();

  if(USE_PBO)
  {
    glEnable(GL_TEXTURE_2D);

    // Init screen texture
    glGenTextures(1,&m_screenTexture);
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, screen_buffer);

    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    /* ������������ ������������ ��� ������ ����� �� �������� */
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    /* ��������� �������� � �������� ������� */
    glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    // \\ end init texture

    pixelBuffer = 0;
    glGenBuffers(1, &pixelBuffer);
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, pixelBuffer);
    glBufferData(GL_PIXEL_UNPACK_BUFFER, width * height*sizeof(int), screen_buffer, GL_DYNAMIC_COPY);

    hrtSetPBO(pixelBuffer);
  }
}

///////////////////////////////////////////////////////////////////////////////////
////
GPU_Ray_Tracer::~GPU_Ray_Tracer()
{
  hrtDelete();
  delete [] m_pipeline;

  if(USE_PBO)
  {
    glDeleteBuffers(1, &m_pixelBufferObject);
    glDeleteTextures( 1, &m_screenTexture);
  }
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::BeginDrawScene(RenderState a_renderState)
{
  m_rtOnlyVarDrawRaysStatInfo = a_renderState.GetEnableRaysCounter();
  m_lastRenderState = a_renderState;

	calcRayMatrix();
	CopyDynamicDataToGPU();

  hrtSetFlags(HRT_USE_RANDOM_RAYS, 0);
  hrtSetFlags(HRT_COMPUTE_SHADOWS, a_renderState.GetShadow());
  hrtSetFlags(HRT_COMPUTE_INDIRRECT_LIGHTING, a_renderState.GetIndirrectIllumination());
  hrtSetFlags(HRT_TRACE_DEPTH, a_renderState.GetTraceDepth());
  hrtSetFlags(HRT_COMPUTE_IRRADIANCE_CACHE | HRT_IRRDAIANCE_CACHE_FIND_SECONDARY,0);

  m_pipeline->SetShaderVariable("g_diffuseMaxBounce", a_renderState.GetDiffuseTraceDepth());

  //hrtSetFlags(HRT_USE_PATH_TRACING_INSTEAD_OF_RT | HRT_USE_RANDOM_RAYS, 1);

  hrtSetVariableF(HRT_IC_WS_ERROR_TRESHOLD, a_renderState.icWSErrorTreshold);
  hrtSetVariableF(HRT_TRACE_PROCEEDINGS_TRESHOLD, a_renderState.GetTraceProceedingsTreshold());
  hrtSetVariableI(HRT_DEBUG_DRAW_LAYER, m_debugLayer);
  hrtSetVariableI(HRT_DISABLE_MRAYS_COUNTERS, int(!a_renderState.GetEnableRaysCounter()));

	hrtBeginTrace(a_renderState.GetAA());
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::EndDrawScene()
{

  if(!USE_PBO)
  {
    hrtEndTrace(screen_buffer);
    glDrawPixels(width, height, GL_RGBA, GL_UNSIGNED_BYTE, screen_buffer);
  }
  else
  {
    hrtEndTrace(0);

    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_pixelBufferObject);

    // copy color from PBO to texture
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, (GLvoid*)0); 

    glViewport(0,0, width, height);
    // set up the projection matrix
    glMatrixMode(GL_PROJECTION);
    // clear any previous transform and set to the identity matrix
    glLoadIdentity();
    // just use an orthographic projection
    glOrtho(-10,10,-10,10,-1,1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    float size = 10;
    float wrap = 1.0f;

    glColor3f(1,1,1);
    glBegin(GL_TRIANGLE_STRIP);

    glTexCoord2f(0.0f,0.0f);
    glVertex2f(-size,-size);

    glTexCoord2f(0.0f,wrap);
    glVertex2f(-size,size); 

    glTexCoord2f(wrap,0.0f);
    glVertex2f(size,-size);

    glTexCoord2f(wrap,wrap);
    glVertex2f(size,size);  

    glEnd();

    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
  }


  glClear(GL_DEPTH_BUFFER_BIT);  
 
  if(m_drawIrradianceCachePixelPoints && m_selectedIrradianceCachePoints.size() > 0)
    DrawICRecords();

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0,width,0,height, -1,1);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glClear(GL_DEPTH_BUFFER_BIT);

  if(m_rtOnlyVarDrawRaysStatInfo)
  {
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glColor3f(1,1,0);
    glPushAttrib(103010); //GL_RASTER_POSITION_UNCLIPPED_IBM
    int traceTimePerCent = (int)(hrtGetTraceTimePerCent()+0.5f);
    float raysPerSec = hrtGetRaysPerSec();
    float samplesPerSec = hrtGetSamplesPerSec();
    int mrays = (int)(raysPerSec*1e-6f + 0.5f);
    int msamples = (int)(samplesPerSec*1e-6f + 0.5f);
    
    float startY = height - 20;

    glRasterPos2f(10, startY-0);
    glPrint("M(Rays)/sec   : %d", mrays);
    
    glRasterPos2f(10, startY-20);
    glPrint("M(Samples)/sec: %d", msamples);

    glRasterPos2f(10, startY-40);
    glPrint("trace per cent: %d", traceTimePerCent);
    
    glPopAttrib();
    glEnable(GL_TEXTURE_2D);
  }

  // just draw lights with OpenGL 
  glClearDepth(1.0f);									
  glDepthFunc(GL_LEQUAL);
  glClear(GL_DEPTH_BUFFER_BIT);

  float z_near  = 0.1f;
  float z_far   = 1e5f;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective( 45.0f, (GLfloat)width/(GLfloat)height, z_near, z_far);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  Matrix4x4f mat = *pWorld_matrix;

  mat.Transpose();
  mat = SafeInverse(mat); //Inverse();

  glPushMatrix();
  glMultMatrixf(mat.L);
  Base::DrawLights();
  glPopMatrix();

}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::GetLDRImage(uint* data) const
{
  hrtGetBuffer("LDRColorBuffer", data, width*height*sizeof(uint));
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::GetHDRImage(float4* data) const
{
  hrtGetBuffer("HDRColorBuffer", data, width*height*sizeof(float4));
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::CopyDynamicDataToGPU()
{  
  if(m_dirtyLights && m_lights.size() > 0)
    hrtSetLights(&m_lights[0], int(m_lights.size()));
	
  if(m_dirtyHydraMaterials)
  {
    if(m_hydraMaterials.size() > 0)
      hrtSetHydraMaterials(&m_hydraMaterials[0], int(m_hydraMaterials.size()));
  }
  
  m_pipeline->SetShaderVariable("g_mViewProjInv", Matrix4x4f(m_projectInvMatrixData));
  m_pipeline->SetShaderVariable("g_mWorldViewInv", Matrix4x4f(m_worldViewInvMatrixData));

  m_dirtyMaterials = false;
  m_dirtyHydraMaterials = false;
  m_dirtyLights = false;
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::LoadStaticDataToGPU()
{
  if(!m_dataVerifyed)
    VerifyAllData();

  if(m_index.size() > 0)
  {
    hrtSetCommonVertexAttributes(&m_vertPos[0], &m_vertNorm[0], &m_vertTexCoord[0], NULL, m_vertPos.size());
    //hrtSetTangentAtrributes(&m_vertTangent[0], m_vertTangent.size());
    hrtSetIndices32(&m_index[0], int(m_index.size()));
    hrtSetMaterialIndices32(&m_triangleMaterialId[0], int(m_triangleMaterialId.size()));
  }

  if(m_spheres.size() > 0)
    hrtSetSpheres(&m_spheres[0], int(m_spheres.size()));

  CreateMegaTextures();

  if(m_lights.size() > 0)
  {
    printf("sizeof(RAYTR::Light) = %d \n", sizeof(RAYTR::Light));
    hrtSetLights(&m_lights[0], int(m_lights.size()));
  }
  else
    std::cerr << "hrt warning: lights were not set" <<std::endl;

  // free memory
  //
  //m_textures       = std::vector<Image>();
  m_images         = std::vector<ImageStorage>();
  //m_vertMaterialId = std::vector<int>();

  m_vertNorm     = DynamicArray<float4>();
  m_vertTangent  = DynamicArray<float4>();
  m_vertTexCoord = std::vector<float2>();

  //m_index  = std::vector<uint>();
  //m_vertPos = DynamicArray<float4>();
  //m_spheres = DynamicArray<Sphere4f>();
  //m_triangleMaterialId = std::vector<int>();
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::BuildAccelerationStructures(uint in_constructionMode)
{
  LoadStaticDataToGPU();

  Base::BuildAccelerationStructures(in_constructionMode);

  // free unnecesary data
  m_triangleMaterialId = std::vector<int>();

  if(in_constructionMode <= KD_TREE_CONSTRUCT_VERY_FAST)
  {
    m_pKdTreeBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);

    hrtSetWorldKdTree(m_bBox, m_pKdTreeBuilder->GetKdTree(), m_pKdTreeBuilder->GetKdTreeArraySize());
    hrtSetWorldObjectListData(m_pKdTreeBuilder->GetPrimitiveListsArray(), m_pKdTreeBuilder->GetPrimitiveListsArraySize());
    hrtSetPrmitiveListIndexData(&m_tempPrimIndex[0], m_tempPrimIndex.size());
    hrtSetCurrAccelStructType(ACCEL_STRUCT_KD_TREE);

    // �������� ������
    //
    delete m_pKdTreeBuilder;
    m_pKdTreeBuilder = NULL;
  }
  else if(in_constructionMode <= BVH_CONSTRUCT_VERY_FAST)
  {
    hrtSetWorldBVH(m_pBVHBuilder->GetBVH(), m_pBVHBuilder->GetBVHArraySize());
    hrtSetWorldObjectListData(m_pBVHBuilder->GetPrimitiveListsArray(), m_pBVHBuilder->GetPrimitiveListsArraySize()); 
    hrtSetPrmitiveListIndexData(&m_tempPrimIndex[0], m_tempPrimIndex.size());
    hrtSetCurrAccelStructType(ACCEL_STRUCT_BVH);

    m_pBVHBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);

    // �������� ������
    //
    delete m_pBVHBuilder;
    m_pBVHBuilder = NULL;
  }

  float3 boxSize   = m_bBox.vmax - m_bBox.vmin;
  float maxBoxSize = MGML_MATH::MAX(boxSize.x, boxSize.y, boxSize.z);
  m_pipeline->SetShaderVariable("g_sceneBoundingSphereDiameter",maxBoxSize);

  // free geometry and other data
  //
  m_index    = std::vector<uint>();
  m_vertPos  = DynamicArray<float4>();
  m_spheres  = DynamicArray<Sphere4f>();
  m_tempPrimIndex = DynamicArray<int>();

  std::cerr << "loading megatextures to GPU..." << std::endl;
  LoadDefferedMegaTexturesToGPU();

  std::cerr << std::endl;
  hrtPrintInfo();
  std::cerr << std::endl;

  //hrtMemorizeTexRefs();

}



///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::PrintPerfInfo(std::ostream& out)
{

}


//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::RT_Core* GPU_Ray_Tracer::GetRTCore()
{
	return &m_core;
}

///////////////////////////////////////////////////////////////////////////////////
////


void GPU_Ray_Tracer::PrepareTexturesToTextureArrays(std::vector<ImageStorage*>* texArrays)
{
  for(int i=0;i<TEX_ARRAYS_NUMBER;i++)
    texArrays[i].clear();

  std::vector<int*> texIdsFromMaterials;

  texIdsFromMaterials.reserve(2*m_materials.size());
  for(int i=0;i<m_materials.size();i++)
    for(int j=0;j<m_materials[i].texturesUsed;j++)
      texIdsFromMaterials.push_back(&m_materials[i].textureId[j]);

  for (int i=0;i<m_images.size();i++)
  {
    ImageStorage* pImage = &m_images[i];
    ImageStorage* pFound = NULL;
    int counter = 0;

    for (int currSize = TEX_ARRAYS_MIN_SIZE; currSize <= TEX_ARRAYS_MAX_SIZE; currSize*=2)
    {
      if(pImage->width() == currSize && pImage->height() == currSize)
      {
        pFound = pImage;
        break;
      }
      counter++;
    }

    if(pFound==NULL)
    {
      std::cerr << "image (" << i << "), named " << "UnknownName" << " have bad resolution, only squares of power 2 can be used; \nlike 256x256 or 512x512; gretear or equal 32 and less or equal 8192"; 
    }
    else
    {
      texArrays[counter].push_back(pFound);
      int newIndex = (counter << 24) | (int(texArrays[counter].size()-1));

      for(int j=0;j<texIdsFromMaterials.size();j++)
      {
        int* pId = texIdsFromMaterials[j];
        if(*(pId) == i)
          *(pId) = newIndex;
      }
    }
  }

  return;
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::PrintMaterialParametersOffsets(const string& a_fileName)
{
  ofstream out(a_fileName.c_str());

  out << "#define " << "HMAT_AMBIENT_COLOR_X_OFFSET" << " " << HMAT_AMBIENT_COLOR_X_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_COLOR_Y_OFFSET" << " " << HMAT_AMBIENT_COLOR_Y_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_COLOR_Z_OFFSET" << " " << HMAT_AMBIENT_COLOR_Z_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET" << " " << HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_LIGHT_ID_OFFSET" << " " << HMAT_AMBIENT_LIGHT_ID_OFFSET << std::endl; 
  
  out << "#define " << "HMAT_DIFFUSE_COLOR_X_OFFSET" << " " << HMAT_DIFFUSE_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_Y_OFFSET" << " " << HMAT_DIFFUSE_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_Z_OFFSET" << " " << HMAT_DIFFUSE_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_RADIANCE_OFFSET" << " " << HMAT_DIFFUSE_RADIANCE_OFFSET << std::endl;

  out << "#define " << "HMAT_SPECULAR_COLOR_X_OFFSET" << " " << HMAT_SPECULAR_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_Y_OFFSET" << " " << HMAT_SPECULAR_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_Z_OFFSET" << " " << HMAT_SPECULAR_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_POWER_OFFSET" << " " << HMAT_SPECULAR_POWER_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_ROUGHNESS_OFFSET" << " " << HMAT_SPECULAR_ROUGHNESS_OFFSET << std::endl;
  //out << "#define " << "HMAT_SPECULAR_GLOSSINESS_OFFSET" << " " << HMAT_SPECULAR_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_FRESNEL_IOR_OFFSET" << " " << HMAT_SPECULAR_FRESNEL_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_BRDF_ID_OFFSET" << " " << HMAT_SPECULAR_BRDF_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_REFLECTION_COLOR_X_OFFSET" << " " << HMAT_REFLECTION_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_Y_OFFSET" << " " << HMAT_REFLECTION_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_Z_OFFSET" << " " << HMAT_REFLECTION_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_POWER_OFFSET" << " " << HMAT_REFLECTION_POWER_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_ROUGHNESS_OFFSET" << " " << HMAT_REFLECTION_ROUGHNESS_OFFSET << std::endl;
  //out << "#define " << "HMAT_REFLECTION_GLOSSINESS_OFFSET" << " " << HMAT_REFLECTION_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_FRESNEL_IOR_OFFSET" << " " << HMAT_REFLECTION_FRESNEL_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_BRDF_ID_OFFSET" << " " << HMAT_REFLECTION_BRDF_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_REFRACTION_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_MULT_OFFSET" << " " << HMAT_REFRACTION_FOG_MULT_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_GLOSSINESS_OFFSET" << " " << HMAT_REFRACTION_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_IOR_OFFSET" << " " << HMAT_REFRACTION_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_HEIGHT_OFFSET" << " " << HMAT_DISPLACEMENT_HEIGHT_OFFSET << std::endl;
  
  out << "#define " << "HMAT_FLAGS_OFFSET" << " " << HMAT_FLAGS_OFFSET << std::endl;

  out << "#define " << "HMAT_AMBIENT_COLOR_TEX_ID_OFFSET" << " " << HMAT_AMBIENT_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET" << " " << HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_POWER_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_POWER_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_ROUGHNESS_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_ROUGHNESS_TEX_ID_OFFSET << std::endl;
  //out << "#define " << "HMAT_SPECULAR_GLOSSINESS_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_GLOSSINESS_TEX_ID_OFFSET << std::endl;
  //out << "#define " << "HMAT_SPECULAR_FRESNEL_IOR_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_FRESNEL_IOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_POWER_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_POWER_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_ROUGHNESS_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_ROUGHNESS_TEX_ID_OFFSET << std::endl;
  //out << "#define " << "HMAT_REFLECTION_GLOSSINESS_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_GLOSSINESS_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_FRESNEL_IOR_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_FRESNEL_IOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_TEX_ID_OFFSET" << " " << HMAT_REFRACTION_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_IOR_TEX_ID_OFFSET" << " " << HMAT_REFRACTION_IOR_TEX_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET" << " " << HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET" << " " << HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET << std::endl;

  out.close();
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::Pack1ChannelTexTo4ThChannel(int bytesOffsetInMaterial, int bytesOffset2InMaterial)
{
  for(int i=0;i<m_hydraMaterials.size();i++)
  {
    HydraMaterial& mat = m_hydraMaterials[i];
    int texIdTo   = *((int*)((char*)&mat + bytesOffsetInMaterial));
    int texIdFrom = *((int*)((char*)&mat + bytesOffset2InMaterial));

    if(texIdTo==INVALID_TEXTURE || texIdFrom == INVALID_TEXTURE)
      continue;

    if(texIdTo == texIdFrom)
      continue;

    int w1 = m_images[texIdTo].width();
    int h1 = m_images[texIdTo].height();

    int w2 = m_images[texIdFrom].width();
    int h2 = m_images[texIdFrom].height();

    if(w1!=w2 || h1!=h2)
      RUN_TIME_ERROR("input 'paired' textures have different resolution. Check relosution of normalmap/displacement, specular/power, refl/power and e.t.c.");

    vec4ub* data1 = (vec4ub*)(m_images[texIdTo].GetData());
    vec4ub* data2 = (vec4ub*)(m_images[texIdFrom].GetData());

    for(int y=0;y<h1;y++)
    {
      int offsetY = y*w1;
      for(int x=0;x<w1;x++)
        data1[offsetY+x].w = data2[offsetY+x].x;
    }
  }

  //for(int i=0;i<m_hydraMaterials.size();i++)
  //{
  //  HydraMaterial& mat = m_hydraMaterials[i];
  //  int texIdFrom = *((int*)((char*)&mat + bytesOffset2InMaterial));
  //  if(texIdFrom != INVALID_TEXTURE)
  //    m_textures[texIdFrom].FreeData();
  //}
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::CreateEnvMapTextures()
{
  for(int i=0;i<m_lights.size();i++)
  {
    bool validCubeTextures = true;
    for(int j=0;j<6;j++)
      validCubeTextures = validCubeTextures && (m_lights[i].texCudeIndices[j] != INVALID_TEXTURE);

    if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY && validCubeTextures)
    {
      int index0 = m_lights[i].texCudeIndices[0];
      if(index0 <= m_images.size() && index0 >= 0)
      {
        const void* data[6];

        for(int j=0;j<6;j++)
        {
          int imgIndex = m_lights[i].texCudeIndices[j];
          data[j] = m_images[imgIndex].GetConstData();
        }

        hrtCreateEnvLightMapCube(m_images[index0].width(), m_images[index0].height(), data);
        hrtSetFlags(HRT_ENV_MAP_CUBEMAP_ACTIVE, 1);
        break;
      }
    }
    else if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY && m_lights[i].sphTexIndex != INVALID_TEXTURE)
    {
      int index0 = m_lights[i].sphTexIndex;
      ImageStorage* pImage = &m_images[index0];

      if(m_images[index0].GetFormat() == ImageStorage::RGBA32F)
        hrtCreateEnvLightMapSphereHDR(pImage->width(), pImage->height(), (const float*)pImage->GetConstData());
      else if(m_images[index0].GetFormat() == ImageStorage::RGBA8)
        hrtCreateEnvLightMapSphereLDR(pImage->width(), pImage->height(), (const unsigned char*)pImage->GetConstData());

      hrtSetFlags(HRT_ENV_MAP_SPHEREMAP_ACTIVE, 1);
      break;
    }
  }
}



///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::CreateMegaTextures()
{
  CreateEnvMapTextures();

  std::cerr << "assembling mega-textures, total tex num = " << m_images.size() << std::endl;

  if(m_hydraMaterials.size() == 0 && m_materials.size() != 0)
    TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);

  HydraMaterial testMat;
  Pack1ChannelTexTo4ThChannel((char*)&testMat.displacement.normals_texId - (char*)&testMat, (char*)&testMat.displacement.height_texId - (char*)&testMat);

  std::vector<int*> shadingTextureIds;
  std::vector<int*> transparencyTextureIds;
  std::vector<int*> displacementTextureIds;

  for(int i=0;i<m_hydraMaterials.size();i++)
  {
    HydraMaterial& mat = m_hydraMaterials[i];

    if(mat.ambient.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.ambient.color_texId);

    if(mat.diffuse.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.diffuse.color_texId);

    if(mat.specular.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.specular.color_texId);

    if(mat.specular.power_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.specular.power_texId);

    if(mat.reflection.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.reflection.color_texId);

    if(mat.reflection.power_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.reflection.power_texId);

  
    if(mat.transparency.color_texId != INVALID_TEXTURE)
      transparencyTextureIds.push_back(&mat.transparency.color_texId);

    if(mat.displacement.normals_texId != INVALID_TEXTURE)
      displacementTextureIds.push_back(&mat.displacement.normals_texId);
  }

  std::map< std::string, std::vector<int*>* > megaTexIndicesData;


  megaTexIndicesData["shadingTexture"]         = &shadingTextureIds;
  megaTexIndicesData["transparencyTexture"]    = &transparencyTextureIds;
  megaTexIndicesData["normalmapTexture"]       = &displacementTextureIds;

  std::map< std::string, std::vector<int*>* >::iterator p;

  hrtClearMegaTextures();

  int   totalBytes = 0;
  float unusedBytes = 0;

  for(p=megaTexIndicesData.begin(); p!= megaTexIndicesData.end(); ++p)
  {
    const std::string& name = p->first;
    std::vector<int*>& idArray = *(p->second);

    MegaTextureManager<char,4> megaTexCompiler;

    MegaTextureManager<char,4>::SizeArray    sizeArray;
    std::vector<const char*> dataArray;
 
    char dummy[4] = {255,255,255,255};
    sizeArray.push_back(pair<int,int>(1,1));
    dataArray.push_back(dummy);

    std::map<int,int> processedTextures;
    int counter = 1;

    for(int i=0;i<idArray.size();i++)
    {
      int id = *(idArray[i]);

      if(id >= m_images.size())
        RUN_TIME_ERROR("a problem with megatexture indices found");

      if(processedTextures.find(id) != processedTextures.end())
      {
        *(idArray[i]) = processedTextures[id];
        continue;
      }

      sizeArray.push_back( pair<int,int>(m_images[id].width(), m_images[id].height()) );
      dataArray.push_back( (char*)m_images[id].GetData());

      *(idArray[i]) = counter; // IMPORTANT!!! Alternate textures id in HydraMaterial data structure. i+1 because 0 is a 1x1 texture = 1.0f.
      processedTextures[id] = counter;
      counter++; 
    }


    int width = 0, height = 0;
    megaTexCompiler.CalculateOffsets(sizeArray, &width, &height);
    const std::vector<float>& lookUpTable = megaTexCompiler.GetLookUpTable();

    char* megaTexData = new char [4*width*height];
    
    megaTexCompiler.BuildImage(dataArray, sizeArray, megaTexData, width, height);

    m_defferedMegaTexHash[name] = new MegaTexStorageProxy(name.c_str(), (unsigned char*)megaTexData, width, height, 4*width*height, ImageStorage::RGBA8, lookUpTable);
    
    /*
    int maxBytesPermitToPlaceOnGPU = 200*1024*1024; // 200 MB
    bool outOfCore = (p->first == "shadingTexture" && width*height*4 > maxBytesPermitToPlaceOnGPU);

    if(outOfCore)
      std::cerr << "texture " << p->first.c_str() << " was placed io pinned memory" << std::endl;

    hrtAddMegaTexture4ub(name.c_str(), outOfCore, megaTexData, width, height, (float4*)(&lookUpTable[0]), int(lookUpTable.size()/4));
    */
    
    if(width > 32 && height > 32)
    {
      totalBytes  += megaTexCompiler.GetUsedBytes();
      unusedBytes += float(megaTexCompiler.GetUsedBytes())*(megaTexCompiler.GetBlackAreasPercent()/100.0f);
    }

    delete [] megaTexData;
  }

  if(m_hydraMaterials.size() != 0)
    hrtSetHydraMaterials(&m_hydraMaterials[0], int(m_hydraMaterials.size())); // update materials.

  for(int i=0;i<m_images.size();i++)
    m_images[i].FreeData();

  if(totalBytes > 0)
  {
    std::cerr << "MegaTex: total memory  " << float(totalBytes)/(1024.0f*1024.0f)  << " MBytes" << std::endl;
    std::cerr << "MegaTex: unused memory " << 100.0f*unusedBytes/float(totalBytes) << "\%" << std::endl;
  }
}


void GPU_Ray_Tracer::LoadDefferedMegaTexturesToGPU()
{
  typedef std::map<std::string, MegaTexStorageProxy*>::iterator MegaTexIterator; 
  MegaTexIterator p;

  std::vector<MegaTexIterator> megaTexIerators; megaTexIerators.reserve(10);

  megaTexIerators.push_back(m_defferedMegaTexHash.find("transparencyTexture"));
  megaTexIerators.push_back(m_defferedMegaTexHash.find("shadingTexture"));
  megaTexIerators.push_back(m_defferedMegaTexHash.find("normalmapTexture"));

  for(p = m_defferedMegaTexHash.begin(); p!= m_defferedMegaTexHash.end(); ++p)
  {
    if(p->second == NULL) continue;
    
    bool alreadyhasThisTex = false;
    for(int i=0;i<megaTexIerators.size();i++)
    {
      if(p == megaTexIerators[i])
      {
        alreadyhasThisTex = true;
        break;
      }
    }
    if(alreadyhasThisTex) continue;

    megaTexIerators.push_back(p);
  }

  for(int i=0;i<megaTexIerators.size();i++)
  {
    p = megaTexIerators[i];
    if(p->second == NULL) 
      continue;

    const std::string& name = p->first;
   
    int width  = p->second->width();
    int height = p->second->height();
    const char* megaTexData = (const char*)(p->second->GetData());

    const std::vector<float>& lookUpTable = p->second->GetLut();
    
    size_t bytesLeft = hrtGetAvaliableMemoryAmount();
    bool outOfCore = (p->first == "shadingTexture" && width*height*4 > bytesLeft) ||
                     (p->first == "normalmapTexture" && width*height*4 > bytesLeft);

    if(outOfCore)
      std::cerr << "texture " << p->first.c_str() << " was placed io pinned memory" << std::endl;

    hrtAddMegaTexture4ub(name.c_str(), outOfCore, megaTexData, width, height, (float4*)(&lookUpTable[0]), int(lookUpTable.size()/4));
    delete p->second; p->second = NULL;
  }

}



void GPU_Ray_Tracer::SetVariable(const std::string& a_name, int a_val)
{
  Base::SetVariable(a_name, a_val);

  if(a_name == "debugViewSH")
  {
    hrtSetVariableI(HRT_DEBUG_SH_ENVIRONMENT,a_val);
  }
  else if(a_name == "g_saveRaySamples")
  {
    hrtSetFlags(HRT_STORE_RAY_SAMPLES, a_val);
  }
  else if(a_name == "g_debugLayerDraw")
  {
    m_pipeline->SetShaderVariable(a_name, a_val);
  }

}


void GPU_Ray_Tracer::SetVariable(const std::string& a_name, float a_val)
{
  Base::SetVariable(a_name, a_val);

  m_pipeline->SetShaderVariable(a_name, a_val);

}
