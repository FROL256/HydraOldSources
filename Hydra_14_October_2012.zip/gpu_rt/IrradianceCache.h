#pragma once

#include "IGraphicsEngine.h"
#include "Ray_Tracer.h"
#include "GPU_Ray_Tracer.h"

#ifndef OCTREE_GUARDIAN
#include "Octree.h"
#endif

#ifndef RTLIB_GUARDIAN
#include "rtlib.h"
#endif



#ifndef PATH_TRACING_GUARDIAN
#include "path_tracing.h"
#endif

namespace RAYTR
{

  
  class IrradianceCacheDataSet
  {
    typedef IrradianceCachePoint_Part1 Part1;
    typedef IrradianceCachePoint_Part2 Part2;
    typedef IrradianceCachePoint_Part3 Part3;

  public:
    
    IrradianceCacheDataSet(){}
    IrradianceCacheDataSet(int a_maxDataSize, int a_width, int a_height);
    ~IrradianceCacheDataSet();

    int size() const {return m_data1.size();}
    void SetMinPixelStep(int a_step) {m_minPixelStep = a_step;}

    void AnalizeScreenSpaceSurface(float3 a_camPos);
    void AnalizeScreenSpaceRadiance(float3 a_camPos);

    void ComputeRadiance();
    float2 MiniMaximizeValidityRadiuses();
    float2 MiniMaximizeValidityRadiuses(float a_minRadius, float a_maxRadius);
    int SelectFewPointsWithLargeError(int maxNewPoints, bool a_lastPass);



    struct SortIndices
    {
      int oldIndex;
      int newIndex;

      bool operator<(const SortIndices& rhs) const {return newIndex < rhs.newIndex;}
    };

    struct Group
    {
      Group(int a, int b, const AABB3f& a_box): begin(a), end(b), box(a_box)  {} 
      int begin;
      int end;
      AABB3f box;
    };

    struct CandidatePoint 
    {
      float3 norm;
      float3 pos;
      float  error;
      int oldIndex;
    };


    //protected:

    //void SelectNewSataSetFromCandiates();
    void GroupPointsWith3DZCurve(IrradianceCachePoint_Part1* a_iTempCache1, IrradianceCachePoint_Part2* a_iTempCache2, int a_recordedPointsNum, std::vector<SortIndices>& sorted, std::vector<Group>& a_groups);
    void SelectCanditatesWithUniqueNormal(const IrradianceCachePoint_Part1* iTempCache1, const IrradianceCachePoint_Part2* iTempCache2, const std::vector<SortIndices>& sorted, const std::vector<Group>& groups, std::vector<CandidatePoint>& candidates);


    inline int Index2D(int x, int y) const { return y*m_screenWidth + x; }
    inline int IndexZBlock2D(int x, int y) const 
    {
      uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
      uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

      uint zIndex = ZIndex(zOrderX, zOrderY);

      uint wBlocks = m_screenWidth/Z_ORDER_BLOCK_SIZE;
      uint blockX = x/Z_ORDER_BLOCK_SIZE;
      uint blockY = y/Z_ORDER_BLOCK_SIZE;

      return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
    }

    static int SpreadBits(int x, int offset)
    {
      if ((x < 0) || (x > 1023))
        RUN_TIME_ERROR("SpreadBits, out of range for x");

      if ((offset < 0) || (offset > 2))
        RUN_TIME_ERROR("SpreadBits, out of range for offset");

      x = (x | (x << 10)) & 0x000F801F;
      x = (x | (x <<  4)) & 0x00E181C3;
      x = (x | (x <<  2)) & 0x03248649;
      x = (x | (x <<  2)) & 0x09249249;

      return x << offset;
    }

    static int GetMortonNumber(int x, int y, int z)
    {
      return SpreadBits(x, 0) | SpreadBits(y, 1) | SpreadBits(z, 2);
    }


    const Part1* GetData1() const { return &m_data1[0];}
    const Part2* GetData2() const { return &m_data2[0];}
    const Part3* GetData3() const { return &m_data3[0];}

    DynamicArray<Part1> m_data1;
    DynamicArray<Part2> m_data2;
    DynamicArray<Part3> m_data3;
    AABB3f m_bBox;

    std::vector<float>  m_savedPixelSize;
    std::vector<float>  m_savedPixelDist;
    std::vector<bool>   m_screenHasPoint;
    std::vector<float>  m_allPixelsSize;

    HydraMaterial* pHydraMaterials;
    int pointsWithMaxError;

    int m_screenWidth;
    int m_screenHeight;

    int m_currPassNumber;
    int m_maxPassNumber;
    int m_minPixelStep;

    static float avgSamplesPerPoint;
  };



};

