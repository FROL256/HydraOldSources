#define LIGHT_GUARDIAN

#ifndef MGML_GPU_GUARDIAN
  #include "../CSL/MGML_GPU.h"
#endif

namespace RAYTR
{

  struct Light
  {
    enum {LIGHT_TYPE_POINT, LIGHT_TYPE_SPOT, LIGHT_TYPE_DIRECTIONAL, LIGHT_TYPE_SKY,
          LIGHT_TYPE_AREA, LIGHT_TYPE_SPHERICAL, LIGHT_TYPE_MESH};

    enum FLAGS{ LIGHT_ACTIVE = 1, 
                LIGHT_COMPUTE_AREA_SHADING = 2, 
                LIGHT_AS_GEOMETRY = 4,
                LIGHT_ENV_USE_SIMPLE_COLOR = 8};

  
    #ifndef __CUDACC__
    Light()
    {
      intensity = 1.0f;
      color = make_float3(1,1,1);
      kc = 1.0;
      kl = 0;
      kq = 0;
      flags = LIGHT_ACTIVE | LIGHT_COMPUTE_AREA_SHADING | LIGHT_AS_GEOMETRY;
 
      m_spotCutoffAngleCos[0] = cos(3.141592654f/6.0f);
      m_spotCutoffAngleCos[1] = cos(3.141592654f/2.0f);

      m_spotExponent[0] = 1.0f;
      m_spotExponent[1] = 1.0f;

      SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);

      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          M[i][j] = 0;

      M[0][0] = M[1][1] = M[2][2] = 1.0f;
    }
    ~Light(){}
    #endif

    void UseShadingModelCorrect() { flags = flags | LIGHT_COMPUTE_AREA_SHADING; }
    void UseShadingModelFast() { flags = flags & (~LIGHT_COMPUTE_AREA_SHADING); } // flags.LIGHT_COMPUTE_AREA_SHADING = flase

    void SetLighType(int a_type) {m_type = a_type;}
    

    /*void SetLookAt(float3 a_norm)
    {
      m_norm = normalize(a_norm);
      
      float3 default_norm = make_float3(0,-1,0);
      float3 v = cross(m_norm, default_norm);

      if(length(v) < EPSILON_E5M)
      {
        for(int i=0;i<3;i++)
          for(int j=0;j<3;j++)
            M[i][j] = 0;

        M[0][0] = M[1][1] = M[2][2] = 1.0f;
      }
      else
      {
        float theta = dot(m_norm,default_norm); 

        float cos_t = cos(theta);
        float sin_t = sin(theta);

        M[0][0] = (1.0f-cos_t)*v.x*v.x + cos_t;
        M[0][1] = (1.0f-cos_t)*v.x*v.y - sin_t*v.z;
        M[0][2] = (1.0f-cos_t)*v.x*v.z + sin_t*v.y;

        M[1][0] = (1.0f-cos_t)*v.y*v.x + sin_t*v.z;
        M[1][1] = (1.0f-cos_t)*v.y*v.y + cos_t;
        M[1][2] = (1.0f-cos_t)*v.y*v.z - sin_t*v.x;

        M[2][0] = (1.0f-cos_t)*v.x*v.z - sin_t*v.y;
        M[2][1] = (1.0f-cos_t)*v.z*v.y + sin_t*v.x;
        M[2][2] = (1.0f-cos_t)*v.z*v.z + cos_t;
      }
    }*/

    void SetMatrixRotation(const float* a_m)
    {
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          M[i][j] = a_m[i*4+j];
    }

    void GetMatrixRotation(float* a_m) const
    {
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          a_m[i*4+j] = M[i][j];
    }

    void SetAreaLightSize(float sz_x, float sz_y)
    {
      #ifndef __CUDACC__
      if(m_type != LIGHT_TYPE_AREA)
        RUN_TIME_ERROR("Incorrect 'Light' structure: attempt to set SetAreaLightSize of non-area light; \n \
                        only LIGHT_TYPE_AREA have SetAreaLightSize function");
      #endif

      m_size.x = sz_x;
      m_size.y = sz_y;
    }

    void SetSphericalLightRadius(float a_r)
    {
      #ifndef __CUDACC__
      if(m_type != LIGHT_TYPE_SPHERICAL)
        RUN_TIME_ERROR("Incorrect 'Light' structure: attempt to SetSphericalLightRadius of non-spherical light; \n \
                        only LIGHT_TYPE_SPHERICAL have SetSphericalLightRadius function");
      #endif

      m_size.x = a_r;
    }

    void SetActive(bool a_active)
    {
      if(a_active)
        flags = flags | LIGHT_ACTIVE;
      else
        flags = flags & (~LIGHT_ACTIVE); // flags.LIGHT_ACTIVE = false;
    }

    inline universal_call float GetSphericalLightRadius() const 
    {
      ASSERT(m_type == LIGHT_TYPE_SPHERICAL);
      return m_size.x;
    }

    inline universal_call float2 GetAreaLightSize() const 
    {
      ASSERT(m_type == LIGHT_TYPE_AREA);
      return m_size;
    }

    inline universal_call float3 GetNormal() const 
    {
      ASSERT(m_type == LIGHT_TYPE_AREA || m_type == LIGHT_TYPE_SPOT);
      return m_norm;
    }

    inline universal_call const float* GetAreaLightRotationMatrix() const 
    {
      ASSERT(m_type == LIGHT_TYPE_AREA || m_type == LIGHT_TYPE_SPOT);
      return L;
    }

    inline universal_call bool IsAreaShadingModelCorrect() const
    {
      if(m_type == LIGHT_TYPE_AREA || m_type == LIGHT_TYPE_SPHERICAL)
        return (flags & LIGHT_COMPUTE_AREA_SHADING);
      else
        return false;
    }

    inline universal_call bool Active() const
    {
      return (flags & LIGHT_ACTIVE);
    }

    inline universal_call int GetLightType() const { return m_type; }

    inline universal_call float GetAttenuation(float3 point_pos) const
    {
      float dist = length(pos - point_pos); 
      return 1.0f/(kc + kl*dist + kq*dist*dist);  
    }

    inline universal_call float GetSpotLightCutoff(int i) const 
    {
      ASSERT(i < SPOT_REGIONS);
      return m_spotCutoffAngleCos[i];
    }

    inline universal_call float GetSpotLightExponent(int i) const 
    {
      ASSERT(i < SPOT_REGIONS);
      return m_spotExponent[i];
    }
    
    inline universal_call float GetMatrixElem(int i, int j) const { return M[i][j]; }

    inline universal_call void SetPrimitiveId(int a_id){ m_spotCutoffAngleCos[1] = *( (float*)(&a_id) ); }
    
#ifdef __CUDACC__
    inline __device__ int  GetPrimitiveId() const {return __float_as_int(m_spotCutoffAngleCos[1]);} 
#endif

    inline universal_call void  SetAORayLength(float a_length){ m_spotCutoffAngleCos[1] = a_length; }
    inline universal_call float GetAORayLength() const {return m_spotCutoffAngleCos[1];}    

    float3 pos;
    float3 color;
    float  intensity;
    float  kc, kl, kq;

  //protected:
    
    int m_type;

    float3 m_norm; // for directional lights
    float2 m_size; // for area lights

    enum {SPOT_REGIONS = 2}; // number of conuces for spot lights (SPOT and SPOT_AREA)
    float m_spotCutoffAngleCos[SPOT_REGIONS];
    float m_spotExponent[SPOT_REGIONS]; 

    union
    {
      float M[3][3];
      float L[9];

      int texCudeIndices[6];
      int sphTexIndex;
    };


    int    flags;

  };




}