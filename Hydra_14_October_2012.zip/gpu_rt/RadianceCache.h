#pragma once

#define N_BANDS 4
#define NUM_SH_FUNCTIONS (N_BANDS*N_BANDS)

#ifdef __CUDACC__

#else

#include "Voxelizer.h"


struct RadianceCache
{
public:

  RadianceCache();
  virtual ~RadianceCache();

  virtual void Build(const VoxelStorage<unsigned char>& a_voxels);

  virtual void InsertRecords(const float4* a_recordsData, int a_numRecords); // (x,y,z) -> pos; w -> sphere radius

  virtual void GenerateNewRecordPositions(); 
  virtual void EvaluateRadiance() = 0;

protected:

  DynamicArray<float4> m_rcPositions;

  int m_selfId;
};

struct SHRadianceCache  : public RadianceCache
{
  SHRadianceCache(){}

  void EvaluateRadiance();
};

struct CBMRadianceCache : public RadianceCache
{
  CBMRadianceCache(){}

  void EvaluateRadiance();
};


#endif

