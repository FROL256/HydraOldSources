#pragma once

class IPhotonMap
{
public:
  IPhotonMap(){}
  IPhotonMap(int a_maxPhotons){}
  virtual ~IPhotonMap(){}

  virtual void Clear() = 0;
  virtual void TracePhotons() = 0;
  virtual void SortPhotons() = 0;
 
  virtual bool  Full() const = 0;
  virtual float EnegryScale() const = 0;

  virtual void  SetMaxPhotons(int a_maxPhotons) = 0;
  virtual int   GetMaxPhotons()  const = 0;
  virtual int   GetCurrPhotons() const = 0;

  virtual void  DebugSaveToFile(const char* posName, const char* posNormName, const char* colorNormName){}

protected:

  IPhotonMap(const IPhotonMap& rhs) {}
  IPhotonMap& operator=(const IPhotonMap& ths) {return *this;}

};

IPhotonMap* hlmCreatePhotonMap(int a_maxPhotons, bool a_caustic = false);
void hlmDeletePhotonMap(IPhotonMap* a_pPhotonMap);


#ifdef __CUDACC__

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#include "float4.cuh"

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

class ILight;

class PhotonMap : public IPhotonMap
{
public:
  PhotonMap(int a_maxPhotons, bool a_caustic);
  ~PhotonMap();

  void Clear();
  void TracePhotons();
  void SortPhotons();
  
  bool  Full() const;
  float EnegryScale() const;
  void  SetMaxPhotons(int a_maxPhotons);
  int   GetMaxPhotons()  const;
  int   GetCurrPhotons() const;

  void  DebugSaveToFile(const char* posName, const char* posNormName, const char* colorNormName);

protected:

  PhotonMap(const PhotonMap& rhs) {}
  PhotonMap& operator=(const PhotonMap& ths) {return *this;}

  int GetCurrPhotonsOnGPU();

  thrust::device_vector<HitPosNorm> m_photonsPosNorm;
  thrust::device_vector<ushort4>    m_photonsColor;
  int m_maxPhotons;
  int m_currPhotons;
  bool m_causticMap;

  std::vector<ILight*> m_lights;

  void BeforePhotonsTrace();
  void AfterPhotonsTrace();
  int m_oldShadowValue;
  int m_oldDiffBounceValue; 
  int m_oldShadingValue;
};


#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif

class ILight
{
public:
  ILight(){}
  virtual ~ILight() {}

  virtual void EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size) = 0;
  virtual float GetIntensity() const = 0;

protected:
  ILight(const ILight& rhs) {}
  ILight& operator=(const ILight& rhs) { return *this; }
};

class AreaLight : public ILight
{
public:
  AreaLight();
  AreaLight(const RAYTR::Light& a_lightPOD);

  void EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  float GetIntensity() const;

protected:

  float3 pos;
  float3 norm;
  float2 size;
  float m_intensity;

  union
  {
    float mRot[3][3];
    float mRotL[9];
  };

};


ILight* CreateLight(const RAYTR::Light& a_lightPOD);






#endif


