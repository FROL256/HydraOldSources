#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "RadianceCache.h"
#include "Voxelizer.h"

/////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::ComputeRadianceCache(int a_type)
{
  delete m_pRC; m_pRC = NULL;

  if(a_type == 0)
    m_pRC = new SHRadianceCache();
  else if(a_type == 1)
    m_pRC = new CBMRadianceCache();

  if(1)
  {
    m_pRC->Build(m_voxelData);
    //voxelData.Clear();
  }
  else
   m_pRC->GenerateNewRecordPositions();
  
  m_pRC->EvaluateRadiance();

  std::cout << "radiance cache calculated" << std::endl;
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::FreeRadianceCache()
{
  delete m_pRC; m_pRC = NULL;
  std::cout << "radiance cache destroyed" << std::endl;
}


/////////////////////////////////////////////////////////////////////////////////////////////
////
RadianceCache::RadianceCache()
{
  m_selfId = hlmCreateRadianceCache();
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
RadianceCache::~RadianceCache()
{
  hrtSetFlags(HRT_RC_HARMONICS | HRT_RC_CUBEMAPS, 0);
  hlmDestroyRadianceCache(m_selfId);
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void RadianceCache::Build(const VoxelStorage<unsigned char>& a_voxelStorage) 
{
  typedef unsigned char uint8;

  const Array3D<uint8>& voxels = a_voxelStorage.GetArrayMipLevel(2);
  
  AABB3f box = a_voxelStorage.GetBoundingBox();
  float voxelSize = (box.vmax.x - box.vmin.x)/float(voxels.size().x);

  m_rcPositions.reserve(m_rcPositions.size() + 16384);

  for(int x=0;x<voxels.size().x;x++)
  {
    float cx = float(x)+0.5f;
    for(int y=0;y<voxels.size().y;y++)
    {
      float cy = float(y)+0.5f;
      for(int z=0;z<voxels.size().z;z++)
      {
        float cz = float(z)+0.5f;

        bool placeRecord = (voxels(x,y,z) == 1);
        
        //if(!placeRecord)
        if(0)
        {
          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y+1,z) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y+1,z) == 1); 
          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y-1,z) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y-1,z) == 1); 

          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y,z-1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y,z-1) == 1); 

          if(!placeRecord) placeRecord = (voxels(x,y+1,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x,y+1,z) == 1) && (voxels(x,y,z-1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x,y-1,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x,y-1,z) == 1) && (voxels(x,y,z-1) == 1); 
        }


        if(placeRecord)
        {
          float3 center = float3( box.vmin.x + cx*voxelSize, box.vmin.y + cy*voxelSize, box.vmin.z + cz*voxelSize);
          float r = 0.75f*voxelSize;
          m_rcPositions.push_back(float4(center.x, center.y, center.z, r));
        } 
      }
    }
  }

  //std::ofstream fout("rc_spheres.txt");
  //for(int i=0;i<m_rcPositions.size();i++)
    //fout << m_rcPositions[i] << std::endl;

}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void RadianceCache::InsertRecords(const float4* a_recordsData, int a_numRecords)
{
  int oldSize = m_rcPositions.size();
  m_rcPositions.resize(m_rcPositions.size() + a_numRecords);

  for(int i=0;i<a_numRecords;i++)
    m_rcPositions[oldSize+i] = a_recordsData[i];
}


void RadianceCache::GenerateNewRecordPositions()
{
  m_rcPositions.resize(0);
  m_rcPositions.push_back(float4(0,0,0,0));
}

void SHRadianceCache::EvaluateRadiance()
{
  if(m_rcPositions.size() == 0)
    return;

  hlmComputeRadianceCacheRecordsHarmonics(m_selfId, 1, &m_rcPositions[0], m_rcPositions.size());

  hrtSetFlags(HRT_RC_HARMONICS, 1);
}


void CBMRadianceCache::EvaluateRadiance()
{
  if(m_rcPositions.size() == 0)
    return;

  hlmComputeRadianceCacheRecordsCubeMaps(m_selfId, 1, &m_rcPositions[0], m_rcPositions.size());

  hrtSetFlags(HRT_RC_CUBEMAPS, 1);
}

