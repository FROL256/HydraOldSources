#pragma once

#include "IGraphicsEngine.h"
#include "Ray_Tracer.h"
#include "GPU_Ray_Tracer.h"
#include "IrradianceCache.h"
#include "RadianceCache.h"
#include "PhotonMap.h"

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
  #include "path_tracing.h"
#endif

class DLL_API GPU_Path_Tracer: public GPU_Ray_Tracer // ,public Singleton
{
  typedef GPU_Ray_Tracer Base;

public:
  
  GPU_Path_Tracer(int w, int h, int flags = 0);
  ~GPU_Path_Tracer();

  struct DLL_API RenderingParams
  { 
    RenderingParams()
    {
      qualityTreshold = 1.0f;
      minRaysPerPixel = 8;
      maxRaysPerPixel = 1000;
      useHDRQualityEstimation = true;
      drawBlocks = false;
      useReferencePathTracingAlgorithm = false;

      enableDOF = false;
      dofLensRadius = 1.0f;
      dofFocalPlaneDist = 10.0f;

      useLoyalEstimateFunction = false;
      loaylEstimateFunctionTresholdInRays = 200;
    }

    float qualityTreshold;
    short minRaysPerPixel;
    short maxRaysPerPixel;
    bool  useHDRQualityEstimation;
    bool  drawBlocks;
    bool  drawRaysStatInfo;
    bool  useReferencePathTracingAlgorithm;
    bool  enableDOF;
    float dofLensRadius;
    float dofFocalPlaneDist;
    bool  useLoyalEstimateFunction;
    float loaylEstimateFunctionTresholdInRays;
  };

  void SetRenderingParams(const RenderingParams& a_params);
  void BeginPathTracingPass(RenderState a_renderState);			
  bool EndPathTracingPass();        // synch path tracing. return true if path tracing has finished	
  bool PathTracingFinished() const; // return true if path tracing has finished
  void ResetPathTracing();
  void DumpBufferToFile(const char* a_buffName, const char* a_fileName);

  void SetRaysPerPixel(int a_num) 
    {m_currRaysPerPixel = a_num;  hmctSetRaysPerPixel(m_currRaysPerPixel);}

  void ComputeIrradianceCache();
  void FreeIrradianceCache();

  void ComputeRadianceCache(int a_type);
  void FreeRadianceCache();

  void DebugCall(const std::string& a_name, const std::string& a_params);

protected:

  GPU_Path_Tracer(const GPU_Path_Tracer& rhs);
  GPU_Path_Tracer& operator=(const GPU_Path_Tracer& rhs);

  typedef MGML_MEMORY::FastList<ZBlock> BlockList; 
  //typedef std::list<ZBlock> BlockList; 
  
  void MakeScreenBlockList(BlockList*);
  void DoMegaBlock(BlockList&, RenderState);
  bool BlockFinished(const ZBlock& block, float* a_blockDiff);
  void DegudDrawActiveBlocksAndStatisticsData();
  void CheckBlockListF(GPU_Path_Tracer::BlockList* pList, const char* file, int line);
  
  void InsertPointsInOctree(const RAYTR::IrradianceCacheDataSet& a_dataSet, IrradCacheOctreeAPI* pOctree);

  // data
  //
  enum PATH_TRACING_STATES {STATE_BEGIN, STATE_TRACING, STATE_FINISHED};
  enum {START_LAST_PASS=32};
  int m_pathTracingState;
  int m_pathTracingPassNumber;

  BlockList m_screenBlockList;
  std::vector<ZBlock> m_blocksArray;

  //int m_blocksArraySize;
  int m_lastPass;
  bool m_megaBlockPathTraceInProcess;
  bool forceEnd;
  std::map<int, vec2i> m_zBlocksCoordByIndex;

  RenderingParams m_params;
  int m_currRaysPerPixel;

  bool m_debugICacheFileOutput;


  RadianceCache* m_pRC;
  IPhotonMap* m_pPhotonMap;
  IPhotonMap* m_pCausticPhotonMap;
};

