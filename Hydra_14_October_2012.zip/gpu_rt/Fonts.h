#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gl/glut.h>
#include <windows.h>

#ifdef CERF_DLL_EXPORTS
  #define DLL_API __declspec(dllexport)
#else
  #define DLL_API __declspec(dllimport)
#endif

// Build Our Bitmap Font
void DLL_API BuildFont();
void DLL_API KillFont();
void DLL_API glPrint(const char *fmt, ...);