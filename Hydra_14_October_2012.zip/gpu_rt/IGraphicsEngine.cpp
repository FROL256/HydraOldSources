#include "IGraphicsEngine.h"

IGraphicsEngine::IGraphicsEngine(int w,int h){}
IGraphicsEngine::~IGraphicsEngine(){}

IGraphicsEngine::RenderState::RenderState()
{
  m_traceDepth  = 4;
  m_diffTraceDepth = 2;
  m_AA  = 0;

  m_shadows = 1;
  m_traceProceedsTreshold = 1e-4f;
  m_enableRaysCount = true;
  icWSErrorTreshold = 2.5f;
}

IGraphicsEngine::RenderState::~RenderState(){}

void IGraphicsEngine::RenderState::SetDiffuseTraceDepth(int d) {m_diffTraceDepth = d;}
int  IGraphicsEngine::RenderState::GetDiffuseTraceDepth() const {return m_diffTraceDepth;}

bool IGraphicsEngine::RenderState::GetEnableRaysCounter() const {return m_enableRaysCount;}
void IGraphicsEngine::RenderState::SetEnableRaysCounter(bool a_val) {m_enableRaysCount = a_val;}

void IGraphicsEngine::RenderState::SetTraceDepth(int a_depth)
{
  if(a_depth > 9)
    throw Error("RendertState: too big trace depth, 9 max");

  m_traceDepth = a_depth;
}

int  IGraphicsEngine::RenderState::GetTraceDepth() const  { return m_traceDepth; }
void IGraphicsEngine::RenderState::SetShadow(bool a_shadow) { m_shadows = a_shadow; }

bool IGraphicsEngine::RenderState::GetShadow() const {return (bool)m_shadows;}

void IGraphicsEngine::RenderState::SetAA(int a_AA)
{
  if(a_AA > 256)
    throw Error("RendertState: too big AA multi sample value, 256 rays per pixel max");

  m_AA = a_AA;
}

int  IGraphicsEngine::RenderState::GetAA() const { return m_AA; }

void IGraphicsEngine::RenderState::SetIndirrectIllumination(bool a_val)
{ m_giEnabled = a_val; }

bool IGraphicsEngine::RenderState::GetIndirrectIllumination() const 
 {return m_giEnabled; }

void  IGraphicsEngine::RenderState::SetTraceProceedingsTreshold(float a_treshold)
{
  if(a_treshold > 0.1f || a_treshold < 1e-5f)
    RUN_TIME_ERROR("IGraphicsEngine::SetTraceProceedingsTreshold : incorrect 'TraceProceedings' treshold value, restricted by interval [1e-5,0.1]");
}

float IGraphicsEngine::RenderState::GetTraceProceedingsTreshold() const { return m_traceProceedsTreshold; }

