#pragma once
#define PATH_TRACING_GUARDIAN

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif


namespace RAYTR
{
  struct ZBlock
  {

  #ifndef __CUDACC__
    ZBlock() {index = 0; diff = 100; counter = 0;}
    ZBlock(int a_index, float a_diff)
    {
      index  = a_index;
      diff   = a_diff;
      diff2 = 0.01f*a_diff;
      counter = 0;
    }
  #endif

    static universal_call int GetSize() { return Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE; }

    universal_call int GetOffset() const { return index*GetSize(); }
    universal_call bool operator<(const ZBlock& rhs) const { return (diff < rhs.diff);}

    int index;   // just block offset
    int counter; // how many times this block was traced?
    float diff;  // difference with color buffer. the stop criterion as a matter of fact
    float diff2; // relative difference (in %)
  };

};

#ifdef __CUDACC__

#include "random_mc.h"
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>


template<typename T> static inline T* get_pointer(thrust::device_vector<T>& rhs) { return thrust::raw_pointer_cast(&rhs[0]); }
template<typename T> static inline const T* get_pointer(const thrust::device_vector<T>& rhs) { return thrust::raw_pointer_cast(&rhs[0]); }

template<typename T> static inline T* get_pointer(thrust::host_vector<T>& rhs) { return &rhs[0]; }
template<typename T> static inline const T* get_pointer(const thrust::host_vector<T>& rhs) { return &rhs[0]; }

struct RandomGenerator // : public Singleton
{
  void Resize(int a_numThreads) {Init(a_numThreads);}

  void Init(int a_numThreads)
  {
    CUDA_SAFE_CALL(cudaFree(m_data1));
    CUDA_SAFE_CALL(cudaFree(m_data2));

    if(USE_SIMPLE_RANDOM)
      m_data1 = NULL;
    else
      CUDA_SAFE_CALL(cudaMalloc((void**) &m_data1, a_numThreads*sizeof(int4)));
    
    CUDA_SAFE_CALL(cudaMalloc((void**) &m_data2, a_numThreads*sizeof(int)));

    InitRandomGenerator_kernel<<< a_numThreads/512, 512>>>(m_data1, m_data2);
    CUT_CHECK_ERROR("Kernel execution failed"); 

    // save pointers in constant memory; Warning, this is thread unsafe
    //
    CUDA_SAFE_CALL(cudaMemcpyToSymbol(cm_rndData1, &m_data1, sizeof(int4*)));
    CUDA_SAFE_CALL(cudaMemcpyToSymbol(cm_rndData2, &m_data2, sizeof(int*)));
  }

  RandomGenerator() 
  {
    m_data1 = 0; 
    m_data2 = 0;
  }

  ~RandomGenerator()
  {
    CUDA_SAFE_CALL(cudaFree(m_data1)); m_data1 = NULL;
    CUDA_SAFE_CALL(cudaFree(m_data2)); m_data2 = NULL;
  }


  int4* m_data1;
  int*  m_data2;
};

enum {RAY_GRAMMAR_SPECULAR = 1, RAY_GRAMMAR_DIFFUSE_REFLECTION = 2, 
      RAY_GRAMMAR_REFLECTION = 4, RAY_GRAMMAR_REFRACTION=8, RAY_GRAMMAR_OUT_OF_SCENE = 16};


struct Hardware_Monte_Carlo_Tracer
{
  Hardware_Monte_Carlo_Tracer();

  float4* m_pathTraceColor;
  float4* m_pathTraceColor2;
  
  float4* m_displacedRaysPos;
  float4* m_displacedRaysDir;

  ZBlock* m_blocks;
  ushort4* m_pixelOddDiff;
  ushort4* m_pixelEvenDiff;
  int m_zBlocksNumber;

  int  m_numRandNumbers;
  int m_raysPerPixel;
  int m_stepNumber;

  RandomGenerator m_randomGenerator;
};



#endif

extern "C" int hmctInit(int w, int h);
extern "C" int hmctDelete();
extern "C" int hmctGenerateEyeInitialRays();
extern "C" int hmctSetZBlocks(ZBlock* cpu_buffer, int a_N);
extern "C" int hmctMegaBlockPathTraceSM(int a_NBlocks, int zbId);


extern "C" int hmctCompareAndStoreResult(ZBlock* out_cpu_zblocks, int a_NBlocks);


extern "C" int hmctCopyColorToScreenBuffer();

extern "C" int hmctClearColorBuffers();
extern "C" int hmctSetRaysPerPixel(int a_rays);


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////
extern "C" int hlmInit();
extern "C" int hlmDelete();


extern "C" int hlmInitHemisphereRaysTexture(int hemisphereId, int index, float4* cpu_dir, int nRays);
extern "C" int hlmInitSHCoefficient(float* coeffs, int w, int h, int layers);

extern "C" int hlmGetFullScreenPositions(IrradianceCachePoint_Part1* cpu_data1, IrradianceCachePoint_Part2* cpu_data2, int size);


extern "C" int hlmReallocAndSetIrradianceCahce(const IrradianceCachePoint_Part1* cpu_data1,
                                               const IrradianceCachePoint_Part2* cpu_data2,
                                               const IrradianceCachePoint_Part3* cpu_data3, int a_size);

extern "C" int hlmComputeRadiance(int index, const IrradianceCachePoint_Part1* cpu_data1, const IrradianceCachePoint_Part2* cpu_data2, IrradianceCachePoint_Part3* cpu_data3, float* cpuErrors, int a_size);

extern "C" int hlmSetIrradianceCahceOctree(const OctreeNode* octree, int a_nodesNum, const int* pointsIndices, int indicesNum, const float3& center, float boxSize);
extern "C" int hlmSetIrradianceCahcePoints(const IrradianceCachePoint_Part1* data1, const IrradianceCachePoint_Part2* data2, const IrradianceCachePoint_Part3* data3, int n_points);

extern "C" int hlmFindMoreIrradianceCachePoints(IrradianceCachePoint_Part1* cpu_data1, IrradianceCachePoint_Part2* cpu_data2, int a_MaxSize, int* a_pRecordedPoints);
extern "C" int hlmFindIrradianceGapsScreenSpace(IrradianceCachePoint_Part1* cpu_data1, IrradianceCachePoint_Part2* cpu_data2, int a_MaxSize, float a_treshold, int* a_pRecordedPoints);


extern "C" int hlmCreateRadianceCache();
extern "C" int hlmDestroyRadianceCache(int a_objectId);

extern "C" int hlmClearRadianceCache(int a_objectId);
extern "C" int hlmComputeRadianceCacheRecordsHarmonics(int a_objectId,int index, float4* in_pos, int a_size); // return last size of rc buffer
extern "C" int hlmComputeRadianceCacheRecordsCubeMaps(int a_objectId, int index, float4* in_pos, int a_size); // return last size of rc buffer


extern "C" int  hmctDumpDataBuffer(const char* a_buffName, const char* a_fileName);

