// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
//
#ifndef KD_TREE_GUARDIAN
#include "kd_tree.h"
#endif

using namespace RAYTR;

using MGML_MATH::MAX;
using MGML_MATH::MIN;
using MGML_MATH::lerp;
using MGML_MATH::clamp;


////////////////////////////////////////////////////////////////////////////
////
void RAYTR::KdTree::ReleaseDynamicTreeRes(Node* a_node)
{
  if(a_node==NULL)
    return;

  if(a_node->Leaf())
  {
    delete a_node->pPrimitiveList; // #WARNING if change vector to simple array, delete []
    a_node->pPrimitiveList = NULL;
  }
  else
  {
    ReleaseDynamicTreeRes(a_node->left);
    ReleaseDynamicTreeRes(a_node->right);
  }
}

////////////////////////////////////////////////////////////////////////////
////
void RAYTR::KdTree::DynamicTreeToArrayLayout(KdTreeNode* curr_node, const Node* a_node)
{
  if(a_node->Leaf()) 
  {
    curr_node->SetLeaf(1);

    if(a_node->pPrimitiveList != NULL && a_node->pPrimitiveList->size() > 0)
      InsertListInLeaf(curr_node, *a_node->pPrimitiveList);
    else
      curr_node->SetObjectListOffsetInBytes(-1); // empty

    return;
  }
  else
  {
    curr_node->SetSplitPos(a_node->split);
    curr_node->SetAxis(a_node->splitAxis);

    KdTreeNode *left,*right;
    NewNodePair(curr_node, &left, &right);

    //curr_node->SetLeftOffset();

    DynamicTreeToArrayLayout(left, a_node->left);
    DynamicTreeToArrayLayout(right, a_node->right);
  }
}


