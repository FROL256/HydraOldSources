// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#ifndef KD_TREE_GUARDIAN
	#include "kd_tree.h"
#endif

#include <omp.h>
#include <math.h>
#include <stdlib.h>


using namespace RAYTR;

using MGML_MATH::MIN;
using MGML_MATH::MAX;

void* KdTreeNode::operator new(size_t size)
{
	  void* ptr = _aligned_malloc(size,8);
	  if(!ptr)
		  throw std::bad_alloc("_aligned_malloc(): unsufficient memory");
	  return ptr;
}

////////////////////////////////////////////////////////////////////////////
////
void KdTreeNode::operator delete(void* raw_memory)
{
	  if(!raw_memory) return;

	  _aligned_free(raw_memory);
}
////////////////////////////////////////////////////////////////////////////
////
void* KdTreeNode::operator new[](size_t size)
{
	  void* ptr = _aligned_malloc(size,8);
	  if(!ptr)
		  throw std::bad_alloc("_aligned_malloc(): unsufficient memory");
	  return ptr;
}
////////////////////////////////////////////////////////////////////////////
////
void KdTreeNode::operator delete[](void* raw_memory)
{
	 if(!raw_memory) return;
	 _aligned_free(raw_memory);
}


////////////////////////////////////////////////////////////////////////////
////
AABB3f ObjectList::GetBoundingBox(const Triangle* in_t)
{
  AABB3f res;

  for (int axis=0; axis < 3;axis++)
  {
    float A,B,C;
    throw Error("ERROR IN CODE: ObjectList::GetBoundingBox");
    //A = in_t->v[0].M[axis];
	  //B = in_t->v[1].M[axis];
	  //C = in_t->v[2].M[axis];

    res.vmax[axis] = MGML_MATH::MAX(A,B,C);
    res.vmin[axis] = MGML_MATH::MIN(A,B,C);
  }

  return res;
}

////////////////////////////////////////////////////////////////////////////
////
AABB3f ObjectList::GetBoundingBox(const Sphere* in_s)
{
  AABB3f res;

  for (int axis=0;axis<3;axis++)
  {
    res.vmax[axis] = in_s->pos[axis] + in_s->r;
    res.vmin[axis] = in_s->pos[axis] - in_s->r;
  }

  return res;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////


KdTree::KdTree()
{
	m_root = NULL;
	m_kdNodesTop = 1;						// one node we already have
	
  m_root2 = NULL;

	// initialise these constants from config file
	NUM_PRIMS_IN_LEAF	 = 16;
  BINNING_PLANES_NUMBER = 128;
	
  EMPTY_NODE_COST_TRAVERSE = 0;
  OBJECT_LIST_MAX_MEMORY_SIZE = 400*1024*1024;
  SAH_OVERSPLIT_TRESHOLD = 1.0f;

  // remember for statistics
  //
  m_stat.m_pAccelStruct = this;
  //cout << "Plain primitive size: " << sizeof(PlainPrimitive) << endl;

  QuadrObj = gluNewQuadric(); 
}
////////////////////////////////////////////////////////////////////////////
////
KdTree::~KdTree()
{
	delete [] m_root;
}


////////////////////////////////////////////////////////////////////////////
////
void KdTree::Build()
{
  //Build2(mode);
  //return;

  m_progressBar = 0;

  std::cerr << "constructing kd-tree...\n";
  int primitivesNumber = GetTotalPrims();

  delete [] m_vspheresMemory;
  delete [] m_vtrianglesMemory;
  m_vspheresMemory = new VSphere[m_pInputData->GetNumSpheres()];
  m_vtrianglesMemory = new VTriangle [m_pInputData->GetNumTriangles()];


  PrimitiveList plist;
  plist.reserve(GetTotalPrims());

  AABB3f boundingBoxOfScene;

  unsigned int numTriangles = m_pInputData->GetNumTriangles();
  for(unsigned int i=0;i<numTriangles;i++)
  {
    m_vtrianglesMemory[i].ConstructTriangle(3*i, this);
    PrimitiveRef triRef(m_vtrianglesMemory+i);
    plist.push_back(triRef);
    boundingBoxOfScene.include(triRef.Box());
  }

  m_useEarlySplitCliping = false;

  if(m_useEarlySplitCliping)
  {
    m_stat.Clear();
    EarlySplitClipping(plist, boundingBoxOfScene); 
  }

  unsigned int numSpheres = m_pInputData->GetNumSpheres();
  for(unsigned int i=0;i<numSpheres;i++)
  {
    m_vspheresMemory[i].ConstructSphere(i, this);
    PrimitiveRef sphRef(m_vspheresMemory+i);
    plist.push_back(sphRef);
    boundingBoxOfScene.include(sphRef.Box());
  }
  m_bBox = boundingBoxOfScene;
  for(int i=0;i<3;i++)
  {
    m_bBox.vmin[i] -= MGML_MATH::EPSILON_E5*(m_bBox.vmax[i]-m_bBox.vmin[i]);
    m_bBox.vmax[i] += MGML_MATH::EPSILON_E5*(m_bBox.vmax[i]-m_bBox.vmin[i]);
  }

  m_kdNodesSize = MGML_MATH::MIN<uint>(40*plist.size() + 10000, MAX_NUM_NODES);
  delete [] m_root;
  m_root = new KdTreeNode [m_kdNodesSize];

  m_objListData.reserve((plist.size() + 10000)*sizeof(RAYTR::ObjectList::Triangle)*1);


  //fourth - start kd-tree building
  m_kdNodesTop = 1;
  m_stat.Clear();
  m_buildTimer.start();
  Subdivide(m_root, m_bBox, m_settings.maxDeep, plist, 0.f, 1.f);
  //Subdivide(m_root, m_bBox, 16, plist, 0.f, 1.f);

  std::cerr << std::endl;
  std::cerr << "kd-tree info: " << std::endl;
  m_debugOutKdTree = false;
  DebugCollectStatistics();
  OutStatistics();
  std::cerr << std::endl;

  //verifyObjectList();
  //DebugTest(root,0);

  //fifth - free unnecessary memory
  FreeList(plist);

  std::cerr << "total prims: " << GetTotalPrims() << std::endl;
}

////////////////////////////////////////////////////////////////////////////
////
void KdTree::Subdivide(KdTreeNode* a_currNode,	const AABB3f& a_box, int a_currDeep, PrimitiveList& plist, float a_progressStart, float a_progressEnd)
{
  if(a_currDeep == 0 || (int)plist.size() <= m_settings.recomendedPrimInLeaf) 
  {
    InsertListInLeaf(a_currNode,plist);
    return;
  }

  if(m_buildTimer.getElapsed() >= 1.0f)
  {
    fprintf(stderr, "KdTreeBuilder, progress: %.0f%% \r", a_progressStart*100.0f);
    m_buildTimer.start();
  }

  SplitData split;

  if(GetContructionMode() == KD_TREE_CONSTRUCT_QUALITY || GetContructionMode() == KD_TREE_CONSTRUCT_FAST)
  {
    if(m_useEarlySplitCliping)
      split = FindObjectSplit(plist, a_box);
    else
      split = FindSplitPosGoldenCutSAH(plist, a_box);

    //split = FindSplitPosGoldenCutSAH_MultiThreaded(plist, a_box);
    //split = FindSplitPosTrivialSAH(plist, a_box);
    //split = FindSplitPosSortSAH(plist, a_box);
  }
  else
    split = FindSplitPosCenter(a_box);

  if(!split.subdivideNext && (int)plist.size() > m_settings.recomendedPrimInLeaf*4 && a_currDeep > 1 && !m_useEarlySplitCliping)
    split = FindSplitPosCenter(a_box);

  if(!split.subdivideNext)
  {
    if((int)plist.size() <= m_settings.maxPrimInLeaf)
    {
      InsertListInLeaf(a_currNode,plist);
      return;
    }
    else
      RUN_TIME_ERROR("KdTreeBuilder, (prims in leaf) >  (KdTreeSettings.maxPrimInLeaf); KdTreeBuilder can not fulfil input requirements\n Current KdTreeSettings.maxPrimInLeaf = " + ToString(m_settings.maxPrimInLeaf));
  }

  a_currNode->SetAxis(split.axis);
  a_currNode->SetSplitPos(split.pos);

  // get two new boxes
  AABB3f leftBox  = a_box, rightBox = a_box;

  leftBox.vmax.M[split.axis]  = split.pos;
  rightBox.vmin.M[split.axis] = split.pos;

  PrimitiveList leftList,rightList;
  PrimitiveList::const_iterator p;

  leftList.reserve(plist.size());
  rightList.reserve(plist.size());

  if(GetContructionMode() == KD_TREE_CONSTRUCT_VERY_FAST)
  {
    for(int i=0;i<plist.size();i++)
    {
      const AABB3f& box = plist[i].Box();
      if(box.vmin[split.axis] <= split.pos) 
        leftList.push_back(plist[i]);

      if(box.vmax[split.axis] >= split.pos) 
        rightList.push_back(plist[i]);
    }
  }
  else
  {
    // correct box-primitive intersection
    //
    for(uint i=0;i<plist.size();i++)
    {
      if (plist[i].AxisAligned(split.axis, split.pos) && !(m_settings.flags & AccelStructSettings::BOUNDARY_PRIMS_BOTH_LEFT_AND_RIGHT))
      {
        if (split.primsOnLeftSide <= split.primsOnRightSide)
          leftList.push_back(plist[i]);
        else
          rightList.push_back(plist[i]);
      }
      else 
      {
        bool overlapLeft  = plist[i].IntersectWithAABB(leftBox);
        bool overlapRight = plist[i].IntersectWithAABB(rightBox);

        if(overlapLeft && overlapLeft)
        {
          PrimitiveRef leftRef = plist[i], rightRef = plist[i];

          SplitReference(plist[i], &leftRef, &rightRef, split.pos, split.axis);

          leftList.push_back(leftRef);
          rightList.push_back(rightRef);

          m_stat.dublicates++;
        }
        else if(overlapLeft)
          leftList.push_back(plist[i]);
        else if(overlapRight)
          rightList.push_back(plist[i]);
      }
    }
  }

  KdTreeNode *left,*right;
  NewNodePair(a_currNode, &left, &right);

  PrimitiveList empty;
  plist.swap(empty); // free memory

  float progressMid = MGML_MATH::lerp(a_progressStart, a_progressEnd, (float)rightList.size() / (float)(leftList.size() + rightList.size()));

  if(leftList.size() > 0)
    Subdivide(left, leftBox, a_currDeep-1,leftList, a_progressStart, progressMid);
  else
  {
    left->SetLeaf(true);
    left->SetObjectListOffsetInBytes(-1); // empty
  }

  leftList.swap(empty); // free memory

  if(rightList.size() > 0)
    Subdivide(right, rightBox, a_currDeep-1,rightList, progressMid, a_progressEnd);
  else
  {
    right->SetLeaf(true);
    right->SetObjectListOffsetInBytes(-1); // empty
  }	

}


////////////////////////////////////////////////////////////////////////////
////
void KdTree::DrawBox(const AABB3f& a_box) const
{
	float3 cent  = a_box.center();
	float3 scale = a_box.vmax - a_box.vmin;

	glPushMatrix();
		glTranslatef(cent.x,cent.y,cent.z);
		glScalef(scale.x,scale.y,scale.z);
		glutWireCube(1);
	glPopMatrix();

}

////////////////////////////////////////////////////////////////////////////
////
KdTree::SplitData KdTree::FindSplitPosCenter(const AABB& box)
{
	float a = box.vmax.x - box.vmin.x;
  float b = box.vmax.y - box.vmin.y;
  float c = box.vmax.z - box.vmin.z;
	
	float split_pos = 0;
	uint split_axis = 0;

	if(a >= b && b >= c) // a - max
	{
		split_axis = 0;
		split_pos = 0.5f*a + box.vmin.x;
	}
	else if(b >= a && a >= c) //b - max
	{
		split_axis = 1;
		split_pos = 0.5f*b + box.vmin.y;
	}
	else // c - max
	{
		split_axis = 2;
		split_pos = 0.5f*c + box.vmin.z;
	}

	SplitData res;
	res.axis = split_axis;
	res.pos  = split_pos;
	res.subdivideNext = true;
	return res;
}

////////////////////////////////////////////////////////////////////////////
////
KdTree::SplitData KdTree::FindSplitPosCenter(const AABB3f& box)
{
  AABB4f box2(to_float4(box.vmin,0), to_float4(box.vmax,0) );
  return FindSplitPosCenter(box2);
}


////////////////////////////////////////////////////////////////////////////
////
void KdTree::NewNodePair(KdTreeNode* curr_node, KdTreeNode** left, KdTreeNode** right)
{
	curr_node->SetLeaf(0);
	curr_node->SetLeftOffset(m_kdNodesTop); 

  //if(kd_node_top >= m_kd_node_size)
    //return;

	if(m_kdNodesTop >= m_kdNodesSize)
    RUN_TIME_ERROR("KdTree::subdivide: out of range KdTreeNode array");

	int offs1 = curr_node->GetLeftOffset();
	int offs2 = curr_node->GetRightOffset();

	*left =  m_root + curr_node->GetLeftOffset();
	*right = m_root + curr_node->GetRightOffset();

	(*left)->SetLeaf(0);
	(*right)->SetLeaf(0);

	//left->setUpOffset(curr_node - root);
	//right->setUpOffset(curr_node - root);

	m_kdNodesTop += 2; // pair
}

////////////////////////////////////////////////////////////////////////////
////
void KdTree::InsertListInLeaf(KdTreeNode* curr_node, const PrimitiveList& plist)
{
  PrimitiveList plist2;
  plist2.reserve(plist.size());

  // remove duplicates
  //
  for(int i=0;i<plist.size();i++)
  {
    bool foudDuplicate = false;

    for(int j=i+1;j<plist.size();j++)
    {
      if(plist[i].GetRealPrimitivePointer()==plist[j].GetRealPrimitivePointer()) // the same prim
      {
        foudDuplicate = true;
        break;
      }
    }

    if (!foudDuplicate)
      plist2.push_back(plist[i]);
  }

  int offset = PushListInObjectListBuffer(plist2);
  
  curr_node->SetLeaf(1);
  curr_node->SetObjectListOffsetInBytes(offset/sizeof(float4));
}




