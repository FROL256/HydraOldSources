#include "KdTreeBuilderRef_vfrolov.h"
#include "kd_tree.h"

////////////////////////////////////////////////////////////////////////////
////
KdTreeBuilderRef_vfrolov::KdTreeBuilderRef_vfrolov()
{ 
  m_pMyKdTree = new RAYTR::KdTree;
}

////////////////////////////////////////////////////////////////////////////
////
KdTreeBuilderRef_vfrolov::~KdTreeBuilderRef_vfrolov()
{
  delete m_pMyKdTree;
}

////////////////////////////////////////////////////////////////////////////
////
void KdTreeBuilderRef_vfrolov::Build(const IKdTreeBuilder::InputData* pInData, AccelStructSettings settings)
{
  m_pMyKdTree->SetSettings(settings);
  m_pMyKdTree->SetInputData(pInData);
  m_pMyKdTree->Build();
}

////////////////////////////////////////////////////////////////////////////
////
KdTreeNode* KdTreeBuilderRef_vfrolov::GetKdTree() const throw (std::runtime_error)
{
  return m_pMyKdTree->GetRoot();
}

////////////////////////////////////////////////////////////////////////////
////
int  KdTreeBuilderRef_vfrolov::GetKdTreeArraySize() const throw (std::runtime_error)
{
  return m_pMyKdTree->GetNumNodes();
}

////////////////////////////////////////////////////////////////////////////
////
const char* KdTreeBuilderRef_vfrolov::GetPrimitiveListsArray() const throw (std::runtime_error)
{
  return m_pMyKdTree->GetObjData();
}

////////////////////////////////////////////////////////////////////////////
////
int KdTreeBuilderRef_vfrolov::GetPrimitiveListsArraySize() const throw (std::runtime_error)
{
  return m_pMyKdTree->GetObjDataSize();
}

////////////////////////////////////////////////////////////////////////////
////
AccelStructStatistics KdTreeBuilderRef_vfrolov::GetStatistics() const throw (std::runtime_error)
{
  return m_pMyKdTree->GetStatistics();
}

////////////////////////////////////////////////////////////////////////////
////
void KdTreeBuilderRef_vfrolov::GetBoundingBox(float a_vmin[3], float a_vmax[3]) const throw (std::runtime_error)
{
  AABB4f box = m_pMyKdTree->GetBoundingBox();

  for(int i=0;i<3;i++)
  {
    a_vmin[i] = box.vmin[i];
    a_vmax[i] = box.vmax[i];
  }
}

////////////////////////////////////////////////////////////////////////////
////
const void* KdTreeBuilderRef_vfrolov::GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const
{
  if(a_dataStructureName == "vfrolov_KdTree")
  {
    return m_pMyKdTree;
  }

  return NULL;
}

////////////////////////////////////////////////////////////////////////////
////
int KdTreeBuilderRef_vfrolov::MemoryExpansionFactor(AccelStructSettings settings) const
{
  return RAYTR::CalcKdTreeMemoryExpansionFactor(settings);
}




