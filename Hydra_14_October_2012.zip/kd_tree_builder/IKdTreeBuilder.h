#pragma once

#include <iostream>

#ifndef KD_TREE_LAYOUT_GUARDIAN
  #include "../kd_tree_builder/kd_tree_layout.h"
#endif

#pragma warning(disable:4290) // warning about unsupported exeption specifications, like 'throw (std::runtime_error)' by msvc compiler

struct AccelStructSettings
{
  enum POSSIBLE_FLAGS {
    INPUT_TRIANGLES = 1,
    INPUT_SPHERES = 2,
    INPUT_POINTS = 4,
    INPUT_CUSTOM_PRIMITIVE = 8,
    CONSTRUCT_QUALITY = 16,
    CONSTRUCT_FAST = 32,
    CONSTRUCT_VERY_FAST = 64,
    BOUNDARY_PRIMS_BOTH_LEFT_AND_RIGHT = 128 // ���� ���� ����������, �� ������� �������� ��������� ��������� � ��� ���������
  };

  int maxDeep;
  int maxPrimInLeaf;
  int recomendedPrimInLeaf;
  int flags;
};

const int kdb_defaultFlags = AccelStructSettings::INPUT_TRIANGLES | AccelStructSettings::CONSTRUCT_QUALITY | AccelStructSettings::BOUNDARY_PRIMS_BOTH_LEFT_AND_RIGHT;

struct AccelStructStatistics
{
  int emptyNodes;
  int totalNodes;
  int leafes;
  float avgPrimInLeaf;
  float avgDeep;
  float relativeSAH; //  = (1000*exactSAH_Value) / (SurfaceArea(root)*totalPrims)

  int notEmptyLeafesNum;
  int maxDeep;
  int maxPrimsInLeaf;
  int primitiveListMemorySize;
  int dublicates;
  int totalPrims;
};


class IKdTreeBuilder
{
public:

  IKdTreeBuilder(){}
  virtual ~IKdTreeBuilder(){}
  
  struct InputData
  {
    virtual int  GetNumTriangles() const throw (std::runtime_error) 
      { throw std::runtime_error("IKdTreeBuilder::InputData::GetNumTriangles() have to be overrided when using triangles"); return 0;}
    
    virtual void GetTriangle(int index, float A[3], float B[3], float C[3]) const throw (std::runtime_error) 
      { throw std::runtime_error("IKdTreeBuilder::InputData::GetTriangle() have to be overrided when using triangles"); }

    virtual int  GetNumPoints() const throw (std::runtime_error) 
      { throw std::runtime_error("IKdTreeBuilder::InputData::GetNumPoints() have to be overrided when using triangles"); return 0;}
    
    virtual void GetPoint(int index, float verts[3]) const throw (std::runtime_error) 
      { throw std::runtime_error("IKdTreeBuilder::InputData::GetPoint() have to be overrided when using triangles");}

    virtual int  GetNumSpheres() const throw (std::runtime_error) 
      { throw std::runtime_error("IKdTreeBuilder::InputData::GetNumSpheres() have to be overrided when using triangles"); return 0;}
    
    virtual void GetSphere(int index, float sph_pos[3], float* sph_r) const throw (std::runtime_error) 
      { throw std::runtime_error("IKdTreeBuilder::InputData::GetSphere() have to be overrided when using triangles");}

    // layout
    //
    virtual int WriteTriangle(int index, void* pAddressToWrite, int maxBytesPermitToRight) const throw (std::runtime_error)  
      { throw std::runtime_error("IKdTreeBuilder::InputData::WriteTriangle have to be overrided when using triangles"); return 0; } 
    
    virtual int WritePoint(int index, void* pAddressToWrite, int maxBytesPermitToRight) const throw (std::runtime_error)      
      { throw std::runtime_error("IKdTreeBuilder::InputData::WritePoint have to be overrided when using points"); return 0; }  

    virtual int WriteSphere(int index, void* pAddressToWrite, int maxBytesPermitToRight) const throw (std::runtime_error)    
      { throw std::runtime_error("IKdTreeBuilder::InputData::WriteSphere have to be overrided when using spheres"); return 0; }  

    virtual int WritePrimListProlog(void* pAddressToWrite, int maxBytesPermitToRight, int a_numTriangles, 
                                    int a_numSpheres, int a_numPoints, int a_numCustomPrimitives[32]) const throw (std::runtime_error)  // 32 ���� ��������� ���������� ����� ��� ����������?
      { throw std::runtime_error("IKdTreeBuilder::InputData::WriteSphere have to be overrided when using spheres"); return 0; }
  };


  virtual void Build(const InputData* pInData, AccelStructSettings settings) throw (std::runtime_error) = 0;

  virtual KdTreeNode* GetKdTree() const throw (std::runtime_error) = 0;
  virtual int GetKdTreeArraySize() const throw (std::runtime_error) = 0;

  virtual const char* GetPrimitiveListsArray() const throw (std::runtime_error) = 0;
  virtual int GetPrimitiveListsArraySize() const throw (std::runtime_error) = 0;

  virtual AccelStructStatistics GetStatistics() const throw (std::runtime_error) = 0;

  virtual void GetBoundingBox(float vmin[3], float vmax[3]) const throw (std::runtime_error) = 0;
 
  // this function calculates approximately memory usage factor
  // for example, if MemoryUsageFactor == 2 and you have N prims, the output buffer may require 2*N*siseof(YourSpecificPrimitiveStructure)
  //
  virtual int MemoryExpansionFactor(AccelStructSettings settings) const = 0;

  // NEVER use this function. For Developers only. 
  //
  virtual const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const {return NULL;}

private:
  IKdTreeBuilder(const IKdTreeBuilder& arg){}
  IKdTreeBuilder& operator=(const IKdTreeBuilder& arg) {return *this;}
};


