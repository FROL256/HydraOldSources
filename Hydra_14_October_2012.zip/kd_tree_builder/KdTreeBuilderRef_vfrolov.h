#ifndef KD_TREE_BUILDER_REF_VFROLOV_GUARDIAN
#define KD_TREE_BUILDER_REF_VFROLOV_GUARDIAN

#include "IKdTreeBuilder.h"

namespace RAYTR
{
  class KdTree;
}

class KdTreeBuilderRef_vfrolov : public IKdTreeBuilder
{
public:

  KdTreeBuilderRef_vfrolov();
  ~KdTreeBuilderRef_vfrolov();

  void Build(const InputData* pInData, AccelStructSettings settings) throw (std::runtime_error);

  KdTreeNode* GetKdTree() const throw (std::runtime_error);
  int GetKdTreeArraySize() const throw (std::runtime_error);

  const char* GetPrimitiveListsArray() const throw (std::runtime_error);
  int GetPrimitiveListsArraySize() const throw (std::runtime_error);

  AccelStructStatistics GetStatistics() const throw (std::runtime_error);
  void GetBoundingBox(float vmin[3], float vmax[3]) const throw (std::runtime_error);

  const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const;

  int MemoryExpansionFactor(AccelStructSettings settings) const;

protected:
  // closed copy constructor and operator=()
  //
  KdTreeBuilderRef_vfrolov(const KdTreeBuilderRef_vfrolov& arg){}
  KdTreeBuilderRef_vfrolov& operator=(const KdTreeBuilderRef_vfrolov& arg) {return *this;}

  RAYTR::KdTree* m_pMyKdTree;
};

#endif
