// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#define ACCEL_STRUCT_GUARDIAN

#pragma warning(disable:4800) // cobversion int to bool, performance warning
#pragma warning(disable:4018) //  warning C4018: <: �������������� ����� �� ������ � ��� �����

#ifndef __CUDACC__

  #ifndef MGML_GUARDIAN
	  #include "../CSL/MGML.h"
  #endif

  #ifndef TIMER_GUARDIAN
    #include "../CSL/Timer.h"
  #endif

  #include "IKdTreeBuilder.h"

  using MGML::vec3f;
  using MGML::vec4f;
  using MGML::vec2i;
  using MGML::AABB3f;
  using MGML::AABB4f;
  using MGML::PackedSphere3f;
  using MGML::to_vec3f;

  using MGML_MATH::SurfaceArea;
  using MGML_MATH::Volume;


  #include <memory>
  #include <list>
  #include <vector>
  #include <map>
  #include <algorithm>

  using std::list;
  using std::vector;
  using std::map;
  using namespace MGML_ERROR;
#endif

#ifndef CONFIG_GUARDIAN
  #include "config.h"
#endif

#ifndef MGML_GPU_GUARDIAN
  #include "../CSL/MGML_GPU.h"
#endif


namespace RAYTR
{

  inline universal_call int GetOctIndex(float3 pos)
  {
    int x1 = (int)(pos.x < 0);
    int y1 = (int)(pos.y < 0);
    int z1 = (int)(pos.z < 0);

    return x1 + (y1 << 1) + (z1 << 2);
  }

  inline universal_call int GetOctIndex(int3 pos)
  {
    int x1 = (int)(pos.x < 0);
    int y1 = (int)(pos.y < 0);
    int z1 = (int)(pos.z < 0);

    return x1 + (y1 << 1) + (z1 << 2);
  }


enum {KD_TREE_CONSTRUCT_QUALITY, KD_TREE_CONSTRUCT_FAST, KD_TREE_CONSTRUCT_VERY_FAST,
      BVH_CONSTRUCT_QUALITY, BVH_CONSTRUCT_FAST, BVH_CONSTRUCT_VERY_FAST};


#ifndef __CUDACC__

static int CalcKdTreeMemoryExpansionFactor(AccelStructSettings settings)
{
  return 15;
}

static int CalcBVHMemoryExpansionFactor(AccelStructSettings settings)
{
  if(settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    return 4;
  else if(settings.flags & AccelStructSettings::CONSTRUCT_FAST)
    return 2;
  else
    return 1;

}
#endif




///////////////////////////////////////////////////////////////////////////////////////////
struct IrradianceCachePoint_Part1
{
  float3 pos;
  int materialId;
};

struct IrradianceCachePoint_Part2
{
  float3 norm;
  int    active; // add point in irradiance cache if it's active

#ifndef __CUDACC__
  __host__ float GetInterpolationError () const { return *( (float*)(&active));}
  __host__ void  SetInterpolationError (float a_val) {  *( (float*)(&active)) = a_val;  }
#else
  __device__ float GetInterpolationError () const { return __int_as_float(active); }
  __device__ void  SetInterpolationError (float a_val) {  active = __float_as_int(a_val);  }
#endif
};

struct IrradianceCachePoint_Part3
{
  float3 color;
  float  validityRadius;
};


struct IrradianceCacheCompressed
{
  ushort3 norm;
  ushort3 color;
  float   validityRadius;
};

// ��������� ����� �����:
// ������ 16 ���� - ���� ���������� ObjectList
// ������� ���� ������������, ����� �����. ������ ����������� ��������� �� float4 (��� uint4)
class ObjectList
{

public:

	enum { TRIANGLE = 0,
		     SPHERE   = 1,
		     BOX      = 2};

#if TRIANGLE_LAYOUT == INDEX_TRIANGLE_LAYOUT
  
  struct Triangle
  {
    int v[3];
    unsigned int selfIndex;
  };

#elif TRIANGLE_LAYOUT == VERTEX_TRIANGLE_LAYOUT

  struct Triangle
  {
    float4 v1;
    float4 v2;
    float3 v3;
    unsigned int selfIndex;
  };

#elif TRIANGLE_LAYOUT == MATRIX_TRIANGLE_LAYOUT
  
  struct Triangle
  {
    float4x3 m;
  };

#endif

  struct Sphere
  {
    float3 pos;
    float r;
  };

#ifndef __CUDACC__

  ObjectList() { m_triangleCount=m_spheresCount=dummy1=dummy2=0; }

  static AABB3f GetBoundingBox(const Triangle* in_t);
  static AABB3f GetBoundingBox(const Sphere* in_s);

  inline Triangle* GetTriangles() const 
  { 
    return  (Triangle*)( ((char*)this) + sizeof(ObjectList));
  }

  inline const Sphere* GetSpheres() const 
  { 
    return  (const Sphere*) ( (char*)this + sizeof(ObjectList) + m_triangleCount*sizeof(Triangle) );
  }
#endif

	inline universal_call int GetNumTriangles() const { return m_triangleCount; }

	inline universal_call void SetNumTriangles(unsigned int num) { m_triangleCount = num;}

  inline universal_call int GetNumSpheres() const {return m_spheresCount;}

	inline universal_call void SetNumSpheres(unsigned int num) { m_spheresCount = num;}

  inline universal_call int GetNumPrimitives() const {return GetNumTriangles() + GetNumSpheres(); }


//protected:

	int m_triangleCount;
	int m_spheresCount;
  int dummy1;
  int dummy2;
};




#ifndef __CUDACC__

#include "fmin.h"
#include "../kd_tree_builder/IKdTreeBuilder.h"

#include "../csl/MGML_MEMORY.h"

using MGML_MEMORY::DynamicArray;

////////////////////////////////////////////////////////////////////////////
////
static void DrawBox(const AABB4f& a_box)
{
  vec4f cent  = a_box.center();
  vec4f scale = a_box.vmax - a_box.vmin;

  glPushMatrix();
  glTranslatef(cent.x,cent.y,cent.z);
  glScalef(scale.x,scale.y,scale.z);
  glutWireCube(1);
  glPopMatrix();
}

////////////////////////////////////////////////////////////////////////////
////
static void DrawBox(const AABB3f& a_box)
{
  vec3f cent  = a_box.center();
  vec3f scale = a_box.vmax - a_box.vmin;

  glPushMatrix();
  glTranslatef(cent.x,cent.y,cent.z);
  glScalef(scale.x,scale.y,scale.z);
  glutWireCube(1);
  glPopMatrix();
}

static inline bool SplitCloseToBoxBoundary(float split, int axis, const AABB3f& a_box)
{
  float3 boxSize = a_box.vmax - a_box.vmin;
  float maxBoxSize = MGML_MATH::MAX(boxSize.x, boxSize.y, boxSize.z);
  float epsilon = boxSize[axis]==0 ? 1e-3f*maxBoxSize : 1e-2f*boxSize[axis];

  if(split < a_box.vmin[axis] || split > a_box.vmax[axis])
    return true;

  ASSERT(split >= a_box.vmin[axis] && split <= a_box.vmax[axis]);

  return ( (split-a_box.vmin[axis]) < epsilon || (a_box.vmax[axis]-split) < epsilon );
}

static inline bool SplitCloseToBoxBoundary(float split, int axis, const AABB4f& a_box)
{
  AABB3f box(to_float3(a_box.vmin), to_float3(a_box.vmax));
  return SplitCloseToBoxBoundary(split, axis, box);
}

class AccelerationStructure : public MGML_MATH::SSE_Aligned_Object
{

protected:

  typedef MGML_MATH::SPHERE<4,float>    Sphere;
  typedef MGML_MATH::TRIANGLE<3,float>  Triangle;
	typedef MGML_MATH::AABB<4,float>		  AABB;

  enum {MAX_DEPTH = 64,
		    MAX_NUM_NODES = 10000000,
		    MAX_PRIMS_IN_LEAF = 1024};

public:

  AccelerationStructure();
  virtual ~AccelerationStructure();

  virtual const AABB4f GetBoundingBox() const;
  virtual void SetBoundingBox(const AABB4f& a_box) 
  {
    m_bBox = AABB3f(to_float3(a_box.vmin), to_float3(a_box.vmax));
  }

  virtual const char*	GetObjData() const;
	virtual unsigned int GetObjDataSize() const;

  virtual const ObjectList*	GetObjListByOffsetInBytes(uint offset) const;
	
  virtual void Build() = 0;
  virtual void Draw() const = 0;

  int GetTotalPrims() const {return m_pInputData->GetNumTriangles() + m_pInputData->GetNumSpheres();}

  void SetInputData(const IKdTreeBuilder::InputData* a_pInputData) {m_pInputData = a_pInputData;} 
  void SetSettings(AccelStructSettings settings) {m_settings = settings;}

  AccelStructStatistics GetStatistics() const { return *(&m_stat); }

  
protected:
  AccelerationStructure(const AccelerationStructure& rhs) {}
  AccelerationStructure& operator=(const AccelerationStructure& rhs) { return *this; }

  struct SplitData
	{
    SplitData() 
    {
      pos = 1e38f;
      sah = 1e38f;
      axis = -1;
      subdivideNext = false;
      primsOnLeftSide = primsOnRightSide = 0;
    }

		float	pos;
		int		axis;
    float sah;
		bool	subdivideNext;
    int   primsOnLeftSide;
    int   primsOnRightSide;

    // for BVH only
    //
    AABB3f leftBounds;
    AABB3f rightBounds;
	};
 
  struct PrimitiveRef;
  template<int axis>
  struct MyBoxLessMax
  {
    inline bool operator()(const PrimitiveRef& p1, const PrimitiveRef& p2) const 
    { 
      const AABB3f& box1 = p1.Box();
      const AABB3f& box2 = p2.Box();

      //if(box1.vmax[axis] < box2.vmax[axis])
      //  return true;
      //else if (box1.vmax[axis] == box2.vmax[axis])
      //  return (box1.vmin[axis] < box2.vmin[axis]);

      return (box1.vmax[axis] < box2.vmax[axis]); 
    }
  };

  struct VPrimitive;

  struct PrimitiveRef
  {
    PrimitiveRef() {m_prim=NULL; }
    PrimitiveRef(VPrimitive* pPrim) 
    {
      m_prim = pPrim; 
      m_box.vmin = pPrim->m_box.vmin; 
      m_box.vmax = pPrim->m_box.vmax;
    }

    inline AABB3f& Box() {return m_box;}
    inline const AABB3f& Box() const {return m_box;}
    
    inline bool AxisAligned(int axis, float split) const  
    {
      //float epsilon = 1e-6f*abs(m_box.vmax[axis]);
      //return (m_box.vmax[axis]-m_box.vmin[axis] < epsilon) && (abs(m_box.vmin[axis]-split) < epsilon);
      return (m_box.vmin[axis] == m_box.vmax[axis]) && (m_box.vmin[axis]==split);
    }
    inline bool ExistSplitOnThatPlane(int axis, float split) const {return (m_flags & HAS_SPLIT) && AxisAligned(axis, split);}
    inline void MemorizeExistSplit(int axis, float split)   { if(AxisAligned(axis, split)) m_flags = m_flags | HAS_SPLIT; }

    VPrimitive* operator->() {return m_prim;}
    const VPrimitive* operator->() const {return m_prim;}

    inline int GetPrimIndex() const {return m_prim->GetPrimIndex();}
    inline int GetPrimType() const {return m_prim->GetPrimType();}
    inline int SizeInBytes() const {return m_prim->SizeInBytes();}
    inline bool IntersectWithAABB(const AABB3f& b) const {return m_prim->IntersectWithAABB(b);}
    //inline bool IntersectWithAABB(const AABB3f& b) const 
    //{
    //  AABB4f box(to_float4(b.vmin,0), to_float4(b.vmax,0));
    //  return m_prim->IntersectWithAABB(box);
    //}

    inline bool Valid() const {return m_prim->IntersectWithAABB(m_box);}

    enum {HAS_SPLIT=1, IN_LEFT_BOX=2, IN_RIGHT_BOX=4};

    inline void MemorizeInLeftBox() {m_flags = m_flags | IN_LEFT_BOX;}
    inline void MemorizeInRightBox() {m_flags = m_flags | IN_RIGHT_BOX;}

    inline bool InLeftBox() const { return (bool)(m_flags & IN_LEFT_BOX);}
    inline bool InRightBox() const { return (bool)(m_flags & IN_RIGHT_BOX);}

    inline VPrimitive* GetRealPrimitivePointer() {return m_prim;}
    inline const VPrimitive* GetRealPrimitivePointer() const {return m_prim;}

  protected:

    AABB3f m_box;
    VPrimitive* m_prim;
    int m_flags;
  };

  friend struct PrimitiveRef;

  void GetTriangleVertices(int triIndex, float4* A, float4* B, float4* C) const;
  void GetTriangleVertices(int triIndex, float3* A, float3* B, float3* C) const;

  struct VPrimitive: public MGML_MATH::SSE_Aligned_Object
  {
    VPrimitive(){m_inLeftBox = false; thisAccelStruct = NULL; m_primitiveIndex = (uint)-1;}

    virtual int GetPrimType() const = 0;
		virtual int SizeInBytes() const = 0;
    virtual bool IntersectWithAABB(const AABB3f& b) const = 0;
    virtual vec2i IntersectAxisAlignedPlane(float coord, int axis) const = 0;
    virtual bool Valid() const {return true;}

    inline int GetPrimIndex() const {return m_primitiveIndex;}
    
    inline void MemorizeInLeftBox() {m_inLeftBox = true;}
    inline void MemorizeInRightBox() {m_inLeftBox = false;}
    
    inline bool InLeftBox() const { return m_inLeftBox; }
    inline bool InRightBox() const {return !m_inLeftBox; }

    AABB3f m_box;
    uint m_primitiveIndex;
    AccelerationStructure* thisAccelStruct;
    bool m_inLeftBox;
    float m_aux;
  };

  struct VTriangle : public VPrimitive
  {
    VTriangle(){}
    VTriangle(int a_id, AccelerationStructure* t);
    void ConstructTriangle(int a_id, AccelerationStructure* t);

    int GetPrimType() const;
    int SizeInBytes() const;
    bool  IntersectWithAABB(const AABB3f& b) const;
    vec2i IntersectAxisAlignedPlane(float coord, int axis) const;
    bool Valid() const;

    void GetVertexPositions(Triangle* t) const;
  };

  struct VSphere : public VPrimitive
  {
    VSphere(){}
    VSphere(int a_id, AccelerationStructure* t);
    void ConstructSphere(int a_id, AccelerationStructure* t);

    int GetPrimType() const;
    int SizeInBytes() const;
    bool IntersectWithAABB(const AABB3f& b) const;
    vec2i IntersectAxisAlignedPlane(float coord, int axis) const;
    bool Valid() const;
  };

  VTriangle* m_vtrianglesMemory;
  VSphere* m_vspheresMemory;

public:
  
  typedef std::vector<PrimitiveRef> PrimitiveList;
  typedef MGML_MEMORY::ArraySlice<PrimitiveList> PrimitiveListSlice;


  float EstimateCost(const AABB& box, float split_pos, int split_axis, size_t lsumm, size_t rsumm) const;
  float EMPTY_NODE_COST_TRAVERSE;


protected:

  // for SAH
  SplitData FindSplitPosSortSAH(PrimitiveList& plist, const AABB3f& a_Box);
  SplitData FindSplitPosTrivialSAH(const PrimitiveList& plist,const AABB3f& a_Box);
  SplitData FindSplitPosGoldenCutSAH(const PrimitiveList& plist,const AABB3f& a_Box);
  SplitData FindSplitPosGoldenCutSAH_MultiThreaded(const PrimitiveList& plist,const AABB3f& a_Box);

  virtual uint GetContructionMode();

  virtual int PushListInObjectListBuffer(const PrimitiveList& plist);
  //virtual int PushListInObjectListBuffer(PrimitiveListSlice& plist);
  virtual AABB3f CalcBindingBox(const PrimitiveList& plist);
  void FreeList(PrimitiveList& pList);
  
  bool FoundAlreadySplitedAAReferences(const AABB3f& a_box, PrimitiveList& plist, float min_split, int min_axis);
  void SplitReference(const PrimitiveRef& ref, PrimitiveRef* left, PrimitiveRef* right, float splitPos, int splitAxis);
 
  void EarlySplitClipping(PrimitiveList& plist, const AABB3f& boundingBoxOfScene);
  PrimitiveList SubdividePrimitive(PrimitiveRef triRef);
  inline bool HaveToBeToSplited(const PrimitiveRef& prim) const { return SurfaceArea(prim.Box()) > m_minPrimSA_OK;}
  float SurfaceAreaOfTriangle(const PrimitiveRef& prim);
  float SubdivMetric(PrimitiveRef triRef);
  
  virtual float PrimsSubdivideFactor() const = 0;
  virtual float MemoryExpansionFactor(AccelStructSettings settings) const = 0;

  const IKdTreeBuilder::InputData* m_pInputData;
  AccelStructSettings m_settings;

  AABB3f m_bBox;
  
  DynamicArray<char> m_objListData;
  std::vector<int>   m_tempPrimitiveIndices;
  void ConvertPrimIndicesToRealObjectListData(const std::vector<int>& a_tempPrimitiveIndices, DynamicArray<char>& a_objListData);

  Timer m_buildTimer;

  //std::vector<AABB3f> m_debugBoxes;
  std::ofstream m_outFile;

  struct StatInfo : public AccelStructStatistics
	{
		StatInfo();

    virtual void Clear();
    virtual void Print(std::ostream& out, int totalPrimsNum);

    AccelerationStructure* m_pAccelStruct;
	} m_stat;

  friend struct StatInfo;

  float m_progressBar;
  float SAH_OVERSPLIT_TRESHOLD;
  float m_minPrimSA_OK;
  float m_sceneBBoxSA;

  int m_primsCountBeforeEarlySplitClipping;
};



template<int axis>
struct SAH_F
{
  SAH_F(const AABB4f& a_box, const AccelerationStructure::PrimitiveList& a_plist, const AccelerationStructure* a_pKdTree)
  {
    m_box = a_box;
    m_pList = &a_plist;
    thisKdTree = a_pKdTree;
    m_pBoxMin = NULL;
    m_pBoxMax = NULL;
  }

  // exact SAH evaluation
  //
  double operator()(float split) const
  {
    const AccelerationStructure::PrimitiveList& plist = *m_pList;

    if(plist.size() > 8)
    {
      const __m128* pBoxMin = (const __m128*)m_pBoxMin;
      const __m128* pBoxMax = (const __m128*)m_pBoxMax;

      int size2 = max(plist.size() - plist.size()%4, 0)/4;

      register __m128  vSplit = _mm_set1_ps(split);
      register __m128i one    = _mm_set1_epi32(1);
      register __m128i qleft  = _mm_set1_epi32(0);
      register __m128i qright = _mm_set1_epi32(0);     

      for(int i=0;i<size2;i++)
      {
        register __m128i a = _mm_and_si128(_mm_castps_si128(_mm_cmpge_ps(pBoxMax[i], vSplit)), one);
        register __m128i b = _mm_and_si128(_mm_castps_si128(_mm_cmple_ps(pBoxMin[i], vSplit)), one);

        qleft  = _mm_add_epi32(qleft,  b); 
        qright = _mm_add_epi32(qright, a); 
      }

      int summLeft=0, summRight=0;
      if(size2 > 0)
      {
        __m128i qleft1 = qleft;
        __m128i qright1 = qright;
        summLeft  = qleft1.m128i_i32[0] + qleft1.m128i_i32[1] + qleft1.m128i_i32[2] + qleft1.m128i_i32[3];
        summRight = qright1.m128i_i32[0] + qright1.m128i_i32[1] + qright1.m128i_i32[2] + qright1.m128i_i32[3];
      }

      int roundedSize = max(plist.size() - plist.size()%4, 0);

      for(uint i=roundedSize;i<plist.size();i++)
      {
        register const AABB3f& box = plist[i].Box();

        if(box.vmax[axis] < split)
          summLeft++;
        else if(box.vmin[axis] > split)
          summRight++;
        else
        {
          summLeft++;
          summRight++;
        }
      }

      m_primsOnLeftSide  = summLeft;
      m_primsOnRightSide = summRight;
      return (double)thisKdTree->EstimateCost(m_box, split, axis, summLeft, summRight);
    }
    else
    {
      int summLeft=0, summRight=0;

      for(uint i=0;i<plist.size();i++)
      {
        register const AABB3f& box = plist[i].Box();

        if(box.vmax[axis] < split)
          summLeft++;
        else if(box.vmin[axis] > split)
          summRight++;
        else
        {
          summLeft++;
          summRight++;
        }
      }

      m_primsOnLeftSide  = summLeft;
      m_primsOnRightSide = summRight; 
      return (double)thisKdTree->EstimateCost(m_box, split, axis, summLeft, summRight);
    }
  }

  inline int GetPrimsOnLeftSide()  const { return m_primsOnLeftSide;}
  inline int GetPrimsOnRightSide() const { return m_primsOnRightSide; }

  AABB4f m_box;

  const AccelerationStructure::PrimitiveList* m_pList;
  const AccelerationStructure* thisKdTree;
  const float* m_pBoxMin;
  const float* m_pBoxMax;
  mutable int m_primsOnLeftSide;
  mutable int m_primsOnRightSide;
};





#endif


};

