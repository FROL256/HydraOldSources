// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#ifndef KD_TREE_GUARDIAN
	#include "kd_tree.h"
#endif

using namespace RAYTR;

/////////////////////////////////////////////////////////////////////////////////////////
////
float KdTree::GetExactSah()
{
  return GetExactSahRec(0, m_bBox);
}

float KdTree::GetExactSahRec(int a_nodeOffset, const AABB3f& a_box)
{
   KdTreeNode node = GetNodeByOffset(a_nodeOffset);

   if(node.Leaf())
   {
      if(node.Empty())
        return 0;

      ObjectList* objList = (ObjectList*)(GetObjData() + node.GetObjectListOffsetInBytes()*sizeof(float4));

      return SurfaceArea(a_box)*(objList->GetNumPrimitives());
   }
   else
   {
     AABB3f leftBox  = a_box, rightBox = a_box;
     leftBox.vmax.M [node.GetAxis()] = node.GetSplitPos();
     rightBox.vmin.M[node.GetAxis()] = node.GetSplitPos();

     return GetExactSahRec(node.GetLeftOffset(), leftBox) + GetExactSahRec(node.GetRightOffset(), rightBox);
   }
}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugCollectStatistics()
{
  if(m_debugOutKdTree)
    m_outFile.open("kd.txt");

  DebugCollectStatisticsRec(m_root,0);

  m_stat.relativeSAH = 1000*GetExactSah()/(SurfaceArea(m_bBox)*GetTotalPrims());
  m_stat.avgPrimInLeaf /= m_stat.notEmptyLeafesNum;
  m_stat.avgDeep /= m_stat.totalNodes;
  
  if(m_debugOutKdTree)
    m_outFile.close();
}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugCollectStatistics(Node* node)
{
  if(m_debugOutKdTree)
    m_outFile.open("kd.txt");

  DebugCollectStatisticsRec(node,0);

  m_stat.avgPrimInLeaf /= m_stat.notEmptyLeafesNum;

  if(m_debugOutKdTree)
    m_outFile.close();
}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugCollectStatisticsRec(const KdTree::Node* node, uint curr_deep)
{
  m_stat.totalNodes++;

  //for(int i=0;i<curr_deep;i++)
   // m_outFile << "--";
  
  if(node==NULL)
  {
    m_stat.emptyNodes++;
    //m_outFile << "leaf: 0" << ", deep = " << curr_deep << std::endl;
    return;
  }

  if((int)curr_deep > m_stat.maxDeep)
    m_stat.maxDeep = curr_deep;

  if(!node->Leaf())
  {
    //m_outFile << "node" << ", axis: ";
    //if(node->splitAxis==0)
    //  m_outFile << "x";
    //else if(node->splitAxis==1)
    //  m_outFile << "y";
    //else if(node->splitAxis==2)
    //  m_outFile << "z";
    //else
    //  throw Error("AAA");
    //m_outFile <<", split: " << node->split;
    //m_outFile << std::endl;

    DebugCollectStatisticsRec(node->left, curr_deep+1);
    DebugCollectStatisticsRec(node->right, curr_deep+1);
  }
  else
  {
    m_stat.leafes++;

    int primNum;
    if(node->pPrimitiveList==NULL)
      primNum = 0;
    else
      primNum = node->pPrimitiveList->size();

    m_stat.totalPrims += primNum;

    //if (curr_deep > 19)
      //m_debugBoxes.push_back(node->box);

    //m_outFile << "leaf: " << primNum << ", deep = " << curr_deep << std::endl; 
    if (primNum > 0)
    {
      m_stat.avgPrimInLeaf += primNum;
      m_stat.notEmptyLeafesNum++;

      if(m_stat.maxPrimsInLeaf < primNum)
        m_stat.maxPrimsInLeaf = primNum;
    }
    else
      m_stat.emptyNodes++;
  }

}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugCollectStatisticsRec(const KdTreeNode* node, uint curr_deep)
{
  //if(m_debugOutKdTree)
    //for(uint i=0;i<curr_deep;i++)
      //m_outFile << "--";

  m_stat.totalNodes++;
  m_stat.avgDeep += curr_deep;

	if(curr_deep > (uint)m_stat.maxDeep)
		m_stat.maxDeep = curr_deep;

	if(!node->Leaf())
	{
    /*if(m_debugOutKdTree)
    {
      m_outFile << "node" << ", axis: ";
      if(node->GetAxis()==0)
        m_outFile << "x";
      else if(node->GetAxis()==1)
        m_outFile << "y";
      else if(node->GetAxis()==2)
        m_outFile << "z";
      else
        throw Error("AAA");
      m_outFile <<", split: " << node->GetSplitPos();
      m_outFile << std::endl;
    }*/

    //int offs = node->GetLeftOffset(); // for debug only
		const KdTreeNode* left  = m_root + node->GetLeftOffset();
		const KdTreeNode* right = m_root + node->GetRightOffset();

		DebugCollectStatisticsRec(left,curr_deep+1);
		DebugCollectStatisticsRec(right,curr_deep+1);
	}
	else
	{
		m_stat.leafes++;

		int offs = node->GetObjectListOffsetInBytes();
		if(offs >= 0)
		{
			ObjectList* pList = (ObjectList*)(m_objListData.begin() + offs*sizeof(float4));
			
			int N_tri = pList->GetNumPrimitives();
			int N_sph = pList->GetNumSpheres();

			m_stat.avgPrimInLeaf += N_tri + N_sph;
			m_stat.notEmptyLeafesNum++;
			if(m_stat.maxPrimsInLeaf < N_tri + N_sph)
				m_stat.maxPrimsInLeaf = N_tri + N_sph;

      if(m_debugOutKdTree)
        m_outFile << "leaf: " <<  N_tri + N_sph << ", deep = " << curr_deep << std::endl; 
		}
		else
		{
			m_stat.emptyNodes++;
      //if(m_debugOutKdTree)
        //m_outFile << "leaf: empty" << std::endl; 
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::OutStatistics()
{
  m_stat.Print(std::cerr, GetTotalPrims());
}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugTest(const KdTreeNode* node,int deep)
{
	if(!node->Leaf())
	{
		const KdTreeNode* left  = m_root + node->GetLeftOffset();
		const KdTreeNode* right = m_root + node->GetRightOffset();

		for(int i=0;i<deep;i++)
			std::cerr << " ";
		std::cerr << "node, offs: " << (int)(node-m_root) << " ";

		int axis = node->GetAxis();
		char ax = 0;
		switch(axis)
		{
			case 0:	ax = 'X'; break;
			case 1:	ax = 'Y'; break;
			case 2:	ax = 'Z'; break;
		}

		DebugTest(left,deep+1);
		DebugTest(right,deep+1);
	}
	else
	{
		for(int i=0;i<deep;i++)
			std::cerr << " ";
		int offs = 	node->GetObjectListOffsetInBytes();
		if(offs >= 0)
		{
			ObjectList* pList = (ObjectList*)(m_objListData.begin() + offs);

			int N_tri = pList->GetNumTriangles();
			int N_sph = pList->GetNumSpheres();

			std::cerr << "T:" << N_tri << ", S:" << N_sph;

			pList++;
			int* indices = ((int*)pList);
			int summ = N_tri*3 + N_sph;
			std::cerr <<  " [";
			for(int i=0;i<summ;i++)
				std::cerr << indices[i] << ", ";
			std::cerr <<  "] ";

			std::cerr << "{b_offs: " << offs << "} ";

		}
		else
		{
			std::cerr << "empty";
		}
		std::cerr <<", offs: " << (int)(node-m_root) << " ";

		int axis = node->GetAxis();
		char ax = 0;
		switch(axis)
		{
			case 0:	ax = 'X'; break;
			case 1:	ax = 'Y'; break;
			case 2:	ax = 'Z'; break;
		}
		std::cerr << "("<< ax << ")" << std::endl;
		
	}
}

/////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::verifyObjectList()
{

  std::cerr << "sizeof(PackedSphere3f)" << sizeof(PackedSphere3f) << std::endl;
  std::cerr << "sizeof(Triangle)" << sizeof(ObjectList::Triangle) << std::endl;
  std::cerr << "sizeof(Sphere)" << sizeof(ObjectList::Sphere) << std::endl;

  char* pList = m_objListData.begin();

  while(pList < m_objListData.end())
  {
    ObjectList* pList2 = (ObjectList*)pList;
    uint nTri = pList2->GetNumTriangles();
    uint nSph = pList2->GetNumSpheres();

    std::cerr << "offset: " << (pList - m_objListData.begin()) << ", prims: " << nTri << " " << nSph << std::endl;
    pList += sizeof(ObjectList) + sizeof(ObjectList::Triangle)*nTri + sizeof(ObjectList::Sphere)*nSph;
  }


}



////////////////////////////////////////////////////////////////////////////
////
void KdTree::Draw() const
{
  DrawBox(m_bBox);
  if(m_root != 0)
    DrawNode(m_bBox, GetRootOffset());
}

////////////////////////////////////////////////////////////////////////////
////
void KdTree::DrawNode(const AABB3f& a_Box, int offset) const
{
  ASSERT(m_root!=0);

  KdTreeNode node =	GetNodeByOffset(offset);
  if(node.Leaf() && node.Empty())
    return;

  glColor3f(0,1,0);
  DrawBox(a_Box);  

  if(node.Leaf())
    return;

  int splitAxis = node.GetAxis();
  float splitPos = node.GetSplitPos();

  AABB3f leftBox  = a_Box, rightBox = a_Box;

  leftBox.vmax.M[splitAxis]  = splitPos;
  rightBox.vmin.M[splitAxis] = splitPos;

  DrawNode(leftBox, node.GetLeftOffset());
  DrawNode(rightBox, node.GetRightOffset());
}

void KdTree::DebugDrawDynamicTree() const
{
  DebugDrawNode(m_root2);

  glColor3f(0,0,1);
  //for(int i=0;i<m_debugBoxes.size();i++)
    //::DrawBox(m_debugBoxes[i]);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugDrawNode(Node* a_node) const
{
  if(a_node==NULL)
    return;

  glColor3f(0,1,0);
  ::DrawBox(a_node->box);

  //if(a_node->Leaf())
    //DebugLeafDrawGeometry(a_node);
 
  DebugDrawNode(a_node->left);
  DebugDrawNode(a_node->right);
  
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugLeafDrawGeometry(const Node* node) const
{
  if(node->pPrimitiveList==NULL)
    return;

  PrimitiveList& plist = *(node->pPrimitiveList);

  glColor3f(1,1,0);

  for(uint i=0;i<plist.size();i++)
  {
    if(plist[i].GetPrimType() == ObjectList::TRIANGLE)
    {
      typedef MGML_MATH::TRIANGLE<3,float> MyTriangle;

      MyTriangle t;
      GetTriangleVertices(plist[i].GetPrimIndex(), &t.A, &t.B, &t.C);

      glBegin(GL_TRIANGLES);
        glVertex3fv(t.A.M);
        glVertex3fv(t.B.M);
        glVertex3fv(t.C.M);
      glEnd();
    }
    else if(plist[i].GetPrimType() == ObjectList::SPHERE)
    {
      Sphere sph;
      m_pInputData->GetSphere(plist[i].GetPrimIndex(), sph.pos.M, &sph.r);

      glPushMatrix();
        vec4f pos = sph.pos;
        glTranslatef(sph.pos.x, sph.pos.y, sph.pos.z);
        gluSphere(QuadrObj, sph.r, 20, 20);
      glPopMatrix();
    }
    else
      throw Error("DebugLeafDrawGeometry, undefined type");
  }

}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void KdTree::DebugLeafDrawGeometry(KdTreeNode a_node) const
{
  int objectListOffset = a_node.GetObjectListOffsetInBytes();
  const char* primListPtr = this->GetObjData() + objectListOffset;
  ObjectList* primList = (ObjectList*)primListPtr;

  glColor3f(1,1,0);

  ObjectList::Triangle* pTriangles = (ObjectList::Triangle*)(primListPtr+sizeof(ObjectList));

 // for(int i=0;i<primList->GetNumTriangles();i++)
 // {
 //   glBegin(GL_TRIANGLES);
 //     glVertex3fv(pTriangles[i].v1.M);
 //     glVertex3fv(pTriangles[i].v2.M);
 //     glVertex3fv(pTriangles[i].v3.M);
 //   glEnd();
 // }

  ObjectList::Sphere* pSpheres = (ObjectList::Sphere*)(primListPtr+sizeof(ObjectList)+sizeof(ObjectList::Triangle)*primList->GetNumTriangles());

  for(int i=0;i<primList->GetNumSpheres();i++)
  {
    glPushMatrix();
      float3 pos = pSpheres[i].pos;
      glTranslatef(pos.x, pos.y, pos.z);
      gluSphere(QuadrObj, pSpheres[i].r, 20, 20);
    glPopMatrix();
  }

}





