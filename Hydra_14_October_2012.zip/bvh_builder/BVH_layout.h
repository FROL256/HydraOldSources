// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#define BVH_LAYOUT_GUARDIAN

#ifndef __CUDACC__
#ifndef universal_call
#define  universal_call
#endif

#ifndef __host__
#define __host__
#endif

#ifndef __device__
#define __device__
#endif

#include <malloc.h>
#include <stdio.h>
#include <iostream>


#endif


// a know about bit fields, but in CUDA they didn't work
struct BVHNode
{
  
 #ifndef __CUDACC__
   
   BVHNode() { m_leftOffsetAndLeaf = 0xffffffff; } 

   static void* operator new(size_t size)
   {
	  void* ptr = _aligned_malloc(size,16);
	  if(!ptr)
		  throw std::bad_alloc("_aligned_malloc(): unsufficient memory");
	  return ptr;
   }

   static void operator delete(void* raw_memory)
   {
	  if(!raw_memory) return;

	  _aligned_free(raw_memory);
   }

  // ����� �������������� new[] ��� ��� ����� �� ��������
  // �������� ������� sse � �������� ��������, ������������� � ������������ ������
  static void* operator new[](size_t size)
  {
	  void* ptr = _aligned_malloc(size,16);
	  if(!ptr)
		  throw std::bad_alloc("_aligned_malloc(): unsufficient memory");
	  return ptr;
  }

  static void operator delete[](void* raw_memory)
  {
	  if(!raw_memory) return;
	  _aligned_free(raw_memory);
  }

#endif

  static inline universal_call int IS_LEAF(int a_leftOffsetAndLeaf) {return a_leftOffsetAndLeaf & 0x80000000;}
  static inline universal_call int EXTRACT_OFFSET(int a_leftOffsetAndLeaf) {return a_leftOffsetAndLeaf & 0x7fffffff;}
  static inline universal_call int PACK_LEAF_AND_OFFSET(int a_leftOffset, int leaf) {return (a_leftOffset & 0x7fffffff) | (leaf & 0x80000000);}

  inline universal_call void SetLeaf(unsigned int a_Leaf) { m_leftOffsetAndLeaf = (m_leftOffsetAndLeaf & 0x7fffffff) | ((a_Leaf) << 31); }
  inline universal_call unsigned int Leaf() const  { return (m_leftOffsetAndLeaf & 0x80000000) >> 31; }
  inline universal_call void SetLeftOffset(unsigned int in_offset) { m_leftOffsetAndLeaf = (m_leftOffsetAndLeaf & 0x80000000) | (in_offset & 0x7fffffff); }

  inline universal_call void SetObjectListOffset(unsigned int in_offset)
  {
    if(Leaf())
      SetLeftOffset(in_offset);
  }

  inline universal_call unsigned int GetLeftOffset() const  { return m_leftOffsetAndLeaf & 0x7fffffff; }  
  inline universal_call unsigned int GetRightOffset() const { return GetLeftOffset()+1; }
  inline universal_call unsigned int GetObjectListOffset() const  { return GetLeftOffset(); }
  inline universal_call void SetUpOffset(unsigned int in_offset) { m_escapeIndex = in_offset;}
  inline universal_call unsigned int GetUpOffset() const  { return m_escapeIndex; }  

  #ifndef __CUDACC__
  struct float3 
  {
    float x,y,z;
  };
  #endif
  
  float3 m_boxMin;
  unsigned int m_leftOffsetAndLeaf;
  
  float3 m_boxMax;
  unsigned int m_escapeIndex;
};




