#include "BVHTree.h"

#include <queue>
#include <vector>

using MGML_MATH::MIN;
using MGML_MATH::MAX;

using namespace RAYTR;



void BVHTree::MakeBVHMoreCacheFriendly()
{
  int cnunkSize = 32; // 1 + 1 + 2 + 4 + 8 + 16 = 32

  std::queue<const BVHNode*> nodesQueue;
  std::vector<const BVHNode*> nodesStack;
  std::vector<int> nodesOffsets;
  std::vector<int> nodesOffsetsOld;

  std::vector<bool> doChildsInOtherWay(GetNumNodes());
  for(int i=0;i<doChildsInOtherWay.size();i++)
    doChildsInOtherWay[i] = false;
  
  nodesOffsets.reserve(cnunkSize);
  nodesOffsetsOld.reserve(GetNumNodes()*1.5 + 1);
  nodesStack.reserve(GetNumNodes());

  bool rootOfTheTree = true;
  nodesOffsets.push_back(0);
  nodesQueue.push(GetRoot());

  const BVHNode* node = NULL;

  while( !(nodesStack.size() == 0 && nodesQueue.empty()) )
  {

    while(nodesOffsets.size() < cnunkSize && !nodesQueue.empty())
    {
      node = nodesQueue.front();
      int nodeOffset = int(node - GetRoot());

      nodesOffsets.push_back(nodeOffset);
      nodesQueue.pop();

      if(node->Leaf() || doChildsInOtherWay[nodeOffset])
        continue;

      const BVHNode* left  = GetNode(node->GetLeftOffset());
      const BVHNode* right = GetNode(node->GetRightOffset());

      nodesQueue.push(left);
      nodesQueue.push(right);
    }

    if(rootOfTheTree)
    {
      nodesOffsetsOld.insert(nodesOffsetsOld.end(), nodesOffsets.begin()+1, nodesOffsets.end());
      rootOfTheTree = false;
    }
    else
      nodesOffsetsOld.insert(nodesOffsetsOld.end(), nodesOffsets.begin(), nodesOffsets.end());
    nodesOffsets.resize(0);


    // now put all nodes we have in queue in separate stack
    //
    while(!nodesQueue.empty())
    {
      nodesStack.push_back(nodesQueue.front());
      nodesQueue.pop();
    }

    // put last element back to the queue, but be careful with it's right brother
    // we can not divide brothers
    //
    if(nodesStack.size() > 0)
    {
      if(nodesStack.size() == 1)
      {
        nodesQueue.push(nodesStack[0]);
        nodesStack.pop_back();
      }
      else
      {
        const BVHNode* leftBrother  = nodesStack[nodesStack.size()-2];
        const BVHNode* rightBrother = nodesStack[nodesStack.size()-1];

        int leftOffset  = int(leftBrother - GetRoot());
        int rightOffset = int(rightBrother - GetRoot());

        if(rightOffset == leftOffset+1) 
        {
          nodesQueue.push(leftBrother);
          nodesQueue.push(rightBrother);

          nodesStack.pop_back();
          nodesStack.pop_back();

          if(!rightBrother->Leaf())
          {
            const BVHNode* rightLeft  = GetNode(rightBrother->GetLeftOffset());
            const BVHNode* rightRight = GetNode(rightBrother->GetRightOffset());

            nodesStack.push_back(rightLeft);
            nodesStack.push_back(rightRight);

            doChildsInOtherWay[rightOffset] = true;
          }

        }
        else // not a brothers
        {
          nodesQueue.push(nodesStack[nodesStack.size()-1]);
          nodesStack.pop_back();
        }

      }

    }
    

  }

  nodesStack = std::vector<const BVHNode*>(); // free memory
  nodesQueue = std::queue<const BVHNode*>();  // free memory

  // save array that will help us to find new offset if we know the old one
  //
  std::vector<int> nodesOffsetsNew(GetNumNodes());

  for(int i=0;i<nodesOffsetsOld.size();i++)
  {
    int oldOffset = nodesOffsetsOld[i];
    int newOffset = i;

    nodesOffsetsNew[oldOffset] = newOffset; 
  }

  std::vector<BVHNode> reorderedNodes(GetNumNodes());

  for(int i=0;i<reorderedNodes.size();i++)
  {
    int oldOffset = nodesOffsetsOld[i];
    int newOffset = i;

    const BVHNode* node = GetNode(oldOffset);

    BVHNode newNode = *node;

    if(!node->Leaf())
    {
      int oldLeftOffset = node->GetLeftOffset();
      int newLeftOffset = nodesOffsetsNew[oldLeftOffset];

      newNode.SetLeftOffset(newLeftOffset);
    }

    reorderedNodes[newOffset] = newNode;
  }

  std::vector<int> test1;
  std::vector<int> test2;

  test1.resize(GetNumNodes());
  test2.resize(GetNumNodes());

  for(int i=0;i<GetNumNodes();i++)
  {
    test1[i] = m_root[i].GetLeftOffset();
    test2[i] = reorderedNodes[i].GetLeftOffset();
  }

  //DepthFirstTestTraversal(GetRoot(), GetRoot(), test1);
  //DepthFirstTestTraversal(&reorderedNodes[0], &reorderedNodes[0], test2);

  // copy data back to original array
  //
  for(int i=0;i<reorderedNodes.size();i++)
    m_root[i] = reorderedNodes[i];

}


/////////////////////////////////////////////////////////////////////////////////////////////////////
////
void BVHTree::DepthFirstTestTraversal(const BVHNode* a_root, const BVHNode* node, std::vector<int>& a_outIndices)
{
  a_outIndices.push_back(node->GetLeftOffset());
  
  if(!node->Leaf())
  {
    const BVHNode* left  = a_root + node->GetLeftOffset();
    const BVHNode* right = a_root + node->GetRightOffset();

    DepthFirstTestTraversal(a_root, left, a_outIndices);
    DepthFirstTestTraversal(a_root, right, a_outIndices);
  }
}


/////////////////////////////////////////////////////////////////////////////////////////////////////
////
void BVHTree::ThreadMemData::FreeData()
{
  plist2_for_InsertListInLeaf = PrimitiveList();
  currList_FindObjectSplit    = PrimitiveList();
  rightBounds_FindObjectSplit = std::vector<AABB3f>();
}


