#pragma once

#include "IBVHBuilder.h"

#ifndef BVH_LAYOUT_GUARDIAN
  #include "BVH_layout.h"
#endif


#ifndef ACCEL_STRUCT_GUARDIAN
  #include "../kd_tree_builder/AccelerationStructure.h" 
#endif 

#include "../csl/MGML_MEMORY.h"

using MGML_MEMORY::DynamicArray;

namespace RAYTR
{
  ////////////////////////////////////////////////////////////////////////////
  ////
  static void SetBoundingBoxData(BVHNode* a_currNode, const AABB3f& a_box)
  {
    a_currNode->m_boxMin.x = a_box.vmin.x;
    a_currNode->m_boxMin.y = a_box.vmin.y;
    a_currNode->m_boxMin.z = a_box.vmin.z;
    a_currNode->m_boxMax.x = a_box.vmax.x;
    a_currNode->m_boxMax.y = a_box.vmax.y;
    a_currNode->m_boxMax.z = a_box.vmax.z;
  }

  ////////////////////////////////////////////////////////////////////////////
  ////
  static const AABB3f GetBoundingBoxData(const BVHNode* a_currNode)
  {
    return AABB3f(float3(a_currNode->m_boxMin.x, a_currNode->m_boxMin.y, a_currNode->m_boxMin.z),
                  float3(a_currNode->m_boxMax.x, a_currNode->m_boxMax.y, a_currNode->m_boxMax.z));
  }


class BVHTree : public AccelerationStructure
{
public:
  BVHTree();
  ~BVHTree();

  const BVHNode* GetRoot() const {return m_root.begin();}
  int GetNumNodes() const {return m_root.size();}

  const BVHNode* GetNode(int offset) const {return m_root.begin() + offset;}

  void Build();
  void Draw() const;

  void SetDebugNodeIndex(int a_val) { m_degugNodeIndex = a_val; }

  float MemoryExpansionFactor(AccelStructSettings settings) const;

protected:

  BVHTree(const BVHTree& rhs) {}
  BVHTree& operator=(const BVHTree& rhs) { return *this; }

  void Subdivide(BVHNode* a_Node, const AABB3f& a_Box, int a_Depth, PrimitiveListSlice& plist, float a_progressStart, float a_progressEnd);
  void InsertListInLeaf(BVHNode* curr_node, PrimitiveListSlice& plist);
  SplitData FindObjectSplit(PrimitiveListSlice plists, const AABB3f& a_box);

  void MakeBVHMoreCacheFriendly();
  void DepthFirstTestTraversal(const BVHNode* a_root, const BVHNode* node, std::vector<int>& a_outIndices);

  void SetEscapeIndex(BVHNode* a_node, int a_escapeIndex);
  void NewNodePair(BVHNode* curr_node, BVHNode** left, BVHNode** right);
  

  void DebugCollectStatistics();
  void DebugCollectStatistics(const BVHNode* a_node, int a_deep);
  void DrawNode(const BVHNode* a_node) const;
  float GetExactSahRec(int a_nodeOffset);
  void DebugLeafDrawGeometry(const BVHNode* node) const;


  float PrimsSubdivideFactor() const {return MemoryExpansionFactor(m_settings);}

  PrimitiveList m_allPrimsSorted; 

  void SortPrimitives(PrimitiveListSlice a_slice, int dim);
  void CalcBounds(PrimitiveListSlice currList, std::vector<AABB3f>& rightBounds, SplitData& res, int dim);

  DynamicArray<BVHNode> m_root;
 
  int m_degugNodeIndex;

  bool m_debugOutBVH;

  int m_glListId;
  mutable bool m_glListCreated;

  // avoid a of dynamic memory allocation and deallocation; one for thread
  //
  struct ThreadMemData 
  {
    void FreeData(); 

    PrimitiveList plist2_for_InsertListInLeaf;
    PrimitiveList currList_FindObjectSplit;
    std::vector<AABB3f> rightBounds_FindObjectSplit;

  };

  ThreadMemData m_memData[1];

};



}
