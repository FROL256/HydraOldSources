#include "BVHTree.h"

#include <queue>

using MGML_MATH::MIN;
using MGML_MATH::MAX;

using namespace RAYTR;

////////////////////////////////////////////////////////////////////////////
////
BVHTree::BVHTree()
{
  EMPTY_NODE_COST_TRAVERSE = 0;
  SAH_OVERSPLIT_TRESHOLD = 1.0f;

  m_debugOutBVH = false;
  m_degugNodeIndex = 0;

  m_glListId = 257;
  m_glListCreated = false;

}

////////////////////////////////////////////////////////////////////////////
////
BVHTree::~BVHTree()
{

}


////////////////////////////////////////////////////////////////////////////
////
void BVHTree::Build()
{
  m_progressBar = 0;

  std::cerr << "adding primitives to input bvh...\n";

  m_buildTimer.start();

  int primitivesNumber = GetTotalPrims();

  delete [] m_vspheresMemory;
  delete [] m_vtrianglesMemory;
  m_vspheresMemory   = new VSphere[m_pInputData->GetNumSpheres()];
  m_vtrianglesMemory = new VTriangle [m_pInputData->GetNumTriangles()];


  PrimitiveList& plist = m_allPrimsSorted;
  plist.reserve(GetTotalPrims());

  AABB3f boundingBoxOfScene;

  unsigned int numTriangles = m_pInputData->GetNumTriangles();
  for(unsigned int i=0;i<numTriangles;i++)
  {
    m_vtrianglesMemory[i].ConstructTriangle(3*i, this);

    if(m_vtrianglesMemory[i].Valid())
    {
      PrimitiveRef triRef(m_vtrianglesMemory+i); 
      boundingBoxOfScene.include(triRef.Box());
      plist.push_back(triRef);
    }
  }

  //std::cerr << "total prims: " << GetTotalPrims() << std::endl;
  std::cerr << "total prims: " << plist.size() << std::endl;

  m_stat.Clear();

  if(plist.size() < 2000000)
    EarlySplitClipping(plist, boundingBoxOfScene); // m_vtrianglesMemory => plist
  
  unsigned int numSpheres = m_pInputData->GetNumSpheres();
  for(unsigned int i=0;i<numSpheres;i++)
  {
    m_vspheresMemory[i].ConstructSphere(i, this);
    PrimitiveRef sphRef(m_vspheresMemory+i);
    plist.push_back(sphRef);
    boundingBoxOfScene.include(sphRef.Box());
  }

  m_root.reserve(plist.size());
  m_objListData.reserve(plist.size()*(sizeof(RAYTR::ObjectList::Triangle)));
  //m_tempPrimitiveIndices.reserve(plist.size() + 1000);

  float bvhMem = float(m_root.capacity()*sizeof(BVHNode))/(1024.0f*1024.0f);
  float objListMem = float(m_objListData.capacity())/(1024.0f*1024.0f);
  float vprimMemory = float(sizeof(VSphere)*m_pInputData->GetNumSpheres() + sizeof(VTriangle)*m_pInputData->GetNumTriangles())/(1024.0f*1024.0f);
  float primitiveRefMemory = plist.size()*sizeof(PrimitiveRef)*2/(1024.0f*1024.0f);

  std::cerr << "building bvh...\n";

  // third - set global binding box
  m_bBox = boundingBoxOfScene; 

  //fourth - start kd-tree building
  m_root.push_back(BVHNode());
  AABB3f box = boundingBoxOfScene;


  std::sort(plist.begin(), plist.end(), MyBoxLessMax<0>());

  m_memData[0].FreeData(); // aux storage for building tree

  Subdivide(m_root.begin(), box, m_settings.maxDeep, PrimitiveListSlice(plist.begin(), plist.end()), 0.f, 1.f);
  plist = PrimitiveList();
  
  m_memData[0].FreeData(); // aux storage for building tree

  int oldPrecision = std::cerr.precision(4);
  std::cerr << "Memory taken by BVH nodes: " << bvhMem << " MBytes" << std::endl;
  std::cerr << "Memory taken total       : " << bvhMem + objListMem << " MBytes" << std::endl;
  std::cerr << "Memory taken for building: " << bvhMem + objListMem + vprimMemory + primitiveRefMemory <<  " MBytes" << std::endl;
  std::cerr.precision(oldPrecision);
  std::cerr << std::endl;

  //MakeBVHMoreCacheFriendly();

  SetEscapeIndex(m_root.begin(), 0);

  std::cerr << std::endl;
  std::cerr << "bvh-tree info: " << std::endl;
  
  //m_debugOutBVH = true;
  DebugCollectStatistics();
  m_stat.m_pAccelStruct = this;
  m_stat.Print(std::cerr, GetTotalPrims());

  //fifth - free unnecessary memory
  FreeList(plist);

  delete [] m_vspheresMemory; m_vspheresMemory = NULL;
  delete [] m_vtrianglesMemory; m_vtrianglesMemory = NULL;

}






////////////////////////////////////////////////////////////////////////////
////
void BVHTree::InsertListInLeaf(BVHNode* curr_node, PrimitiveListSlice& plist)
{
  //PrimitiveList plist2;
  //plist2.reserve(plist.size());

  // avoid dynamic memory allocation each time 
  PrimitiveList& plist2 = m_memData[0].plist2_for_InsertListInLeaf; 
  plist2.resize(0);

  // remove duplicates
  //
  for(int i=0;i<plist.size();i++)
  {
    bool foudDuplicate = false;

    for(int j=i+1;j<plist.size();j++)
    {
      if(plist[i].GetRealPrimitivePointer()==plist[j].GetRealPrimitivePointer()) // the same prim
      {
        foudDuplicate = true;
        break;
      }
    }

    if (!foudDuplicate)
      plist2.push_back(plist[i]);
  }

  int offset = PushListInObjectListBuffer(plist2);

  curr_node->SetLeaf(1);
  curr_node->SetObjectListOffset(offset/sizeof(float4));
}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::SortPrimitives(PrimitiveListSlice currList, int dim)
{
  switch(dim)
  {
  case 0:
    std::sort(currList.begin(), currList.end(), MyBoxLessMax<0>());
    break;
  case 1:
    std::sort(currList.begin(), currList.end(), MyBoxLessMax<1>());
    break;
  case 2:
    std::sort(currList.begin(), currList.end(), MyBoxLessMax<2>());
    break;
  }
}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::CalcBounds(PrimitiveListSlice currList, std::vector<AABB3f>& rightBounds, SplitData& res, int dim)
{
  // Sweep right to left and determine bounds.
  //
  AABB3f rightBounds1;
  for (uint i = currList.size() - 1; i > 0; i--)
  {
    rightBounds1.include(currList[i].Box());
    rightBounds[i-1] = rightBounds1;
  }

  // Sweep left to right and select lowest SAH.
  //
  AABB3f leftBounds;
  for (uint i = 1; i < currList.size(); i++)
  {
    leftBounds.include(currList[i-1].Box());

    const AABB3f& leftBox  = leftBounds;
    const AABB3f& rightBox = rightBounds[i-1];

    float primsOnLeftSide  = float(i);
    float primsOnRightSide = float(currList.size() - i);

    float sah = EMPTY_NODE_COST_TRAVERSE + SurfaceArea(leftBox)*primsOnLeftSide + SurfaceArea(rightBox) * primsOnRightSide;

    // calc left and right nodes intersection penalty
    //
    //leftBox.intersect(rightBox);
    //sah += 0.1f*SurfaceArea(leftBox)*(primsOnLeftSide + primsOnRightSide);

    if (sah < res.sah)
    {
      res.sah = sah;
      res.axis = dim;
      res.primsOnLeftSide = i;
      res.primsOnRightSide = currList.size() - i;
      res.leftBounds  = leftBox;
      res.rightBounds = rightBox;
    }
  }
}


////////////////////////////////////////////////////////////////////////////
////
BVHTree::SplitData BVHTree::FindObjectSplit(PrimitiveListSlice a_plist, const AABB3f& a_box)
{
  BVHTree::SplitData res;
  res.sah = SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size();
  res.subdivideNext = false;
  res.axis = -1;

  //std::vector<AABB3f> rightBounds(a_plist.size());
  //PrimitiveList       currList(a_plist.size());
  
  // avoid dynamic memory allocation each time 
  std::vector<AABB3f>& rightBounds = m_memData[0].rightBounds_FindObjectSplit; rightBounds.resize(a_plist.size());
  PrimitiveList&       currList = m_memData[0].currList_FindObjectSplit; currList.resize(a_plist.size());
  
  int axisOrder[3];

  if(a_plist.axis() == 1)
  {
    axisOrder[0] = 1;
    axisOrder[1] = 2;
    axisOrder[2] = 0;
  }
  else if(a_plist.axis() == 2)
  {
    axisOrder[0] = 2;
    axisOrder[1] = 0;
    axisOrder[2] = 1;
  }
  else
  {
    axisOrder[0] = 0;
    axisOrder[1] = 1;
    axisOrder[2] = 2;
  }

  for (int axisNum=0;axisNum<3;axisNum++)
  {
    int dim = axisOrder[axisNum];

    // copy data to appropriate memory location
    //
    std::copy(a_plist.begin(), a_plist.end(), currList.begin());

    if(axisNum!=0)
      SortPrimitives(PrimitiveListSlice(currList.begin(), currList.end()), dim);

    CalcBounds(PrimitiveListSlice(currList.begin(), currList.end()), rightBounds, res, dim);

  } // for (int dim=0;dim<3;dim++)


  res.subdivideNext = (res.axis != -1) && (res.sah < SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size());
  res.pos = res.leftBounds.vmax[res.axis];

  if(res.subdivideNext)
  {
    if(res.axis == axisOrder[2])
      std::copy(currList.begin(), currList.end(), a_plist.begin());
    else
    {
      SortPrimitives(a_plist, res.axis);
      CalcBounds(a_plist, rightBounds, res, res.axis);
    }
  }

  res.subdivideNext = (res.axis != -1) && (res.sah < SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size());
  res.pos = res.leftBounds.vmax[res.axis];

  return res;
}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::Subdivide(BVHNode* a_currNode, const AABB3f& a_box, int a_currDeep, PrimitiveListSlice& plist, float a_progressStart, float a_progressEnd)
{
  SetBoundingBoxData(a_currNode, a_box);

  int a_prevSplitAxis = plist.axis();

  if(a_currDeep == 0 || (int)plist.size() <= m_settings.recomendedPrimInLeaf) 
  {
    InsertListInLeaf(a_currNode, plist);
    return;
  }

  if(m_buildTimer.getElapsed() >= 1.0f)
  {
    fprintf(stderr, "BVHBuilder, progress: %.0f%% \r", a_progressStart*100.0f);
    m_buildTimer.start();
  }

  SplitData split = FindObjectSplit(plist, a_box); 

  if(!split.subdivideNext)
  {
    InsertListInLeaf(a_currNode, plist);
    return;
  }

  // split primitives and construct subtrees
  //
  BVHNode *leftNode = NULL, *rightNode = NULL;
  NewNodePair(a_currNode, &leftNode, &rightNode);

  PrimitiveList::iterator middle = plist.begin() + split.primsOnLeftSide;
  PrimitiveListSlice leftList(plist.begin(), middle, split.axis);
  PrimitiveListSlice rightList(middle, plist.end(),  split.axis);

  float progressMid = MGML_MATH::lerp(a_progressStart, a_progressEnd, (float)leftList.size() / (float)(leftList.size() + rightList.size()));

  if(leftList.size()==0)  RUN_TIME_ERROR("BVH never contain 0 prims in leaf");
  if(rightList.size()==0) RUN_TIME_ERROR("BVH never contain 0 prims in leaf");

  Subdivide(leftNode,  split.leftBounds,  a_currDeep-1, leftList,  a_progressStart, progressMid);
  Subdivide(rightNode, split.rightBounds, a_currDeep-1, rightList, progressMid, a_progressEnd);
}



////////////////////////////////////////////////////////////////////////////
////
void BVHTree::NewNodePair(BVHNode* curr_node, BVHNode** left, BVHNode** right)
{
  curr_node->SetLeaf(0);
  curr_node->SetLeftOffset(m_root.size()); 

  m_root.push_back(BVHNode());
  m_root.push_back(BVHNode());

  int offs1 = curr_node->GetLeftOffset();
  int offs2 = curr_node->GetRightOffset();

  *left =  m_root.begin() + curr_node->GetLeftOffset();
  *right = m_root.begin() + curr_node->GetRightOffset();

  (*left)->SetLeaf(1);
  (*right)->SetLeaf(1);
}


////////////////////////////////////////////////////////////////////////////
////
void BVHTree::SetEscapeIndex(BVHNode* a_node, int a_escapeIndex)
{
  a_node->SetUpOffset(a_escapeIndex);

  if(!a_node->Leaf())
  {
    int leftOffset  = a_node->GetLeftOffset();
    int rightOffset = a_node->GetRightOffset();

    BVHNode* left  = m_root.begin() + leftOffset;
    BVHNode* right = m_root.begin() + rightOffset;

    SetEscapeIndex(left, rightOffset);
    SetEscapeIndex(right, a_escapeIndex);
  }
}

////////////////////////////////////////////////////////////////////////////
////
float BVHTree::MemoryExpansionFactor(AccelStructSettings settings) const
{
  return CalcBVHMemoryExpansionFactor(settings);
}


