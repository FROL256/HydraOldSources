#include "IBVHBuilder.h"

#ifndef BVH_LAYOUT_GUARDIAN
  #include "BVH_layout.h"
#endif

namespace RAYTR
{
 class BVHTree;
};


class BVHBuilderRef_vfrolov : public IBVHBuilder
{
public:

  BVHBuilderRef_vfrolov();
  ~BVHBuilderRef_vfrolov();

  void Build(const InputData* pInData, AccelStructSettings settings) throw (std::runtime_error);

  const BVHNode* GetBVH() const throw (std::runtime_error);
  int GetBVHArraySize() const throw (std::runtime_error);

  const char* GetPrimitiveListsArray() const throw (std::runtime_error);
  int GetPrimitiveListsArraySize() const throw (std::runtime_error);

  AccelStructStatistics GetStatistics() const throw (std::runtime_error);
  void GetBoundingBox(float vmin[3], float vmax[3]) const throw (std::runtime_error);

  const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const;

  int MemoryExpansionFactor(AccelStructSettings settings) const;

protected:
  // closed copy constructor and operator=()
  //
  BVHBuilderRef_vfrolov(const BVHBuilderRef_vfrolov& arg){}
  BVHBuilderRef_vfrolov& operator=(const BVHBuilderRef_vfrolov& arg) {return *this;}

  RAYTR::BVHTree* m_pMyBVH;
};

