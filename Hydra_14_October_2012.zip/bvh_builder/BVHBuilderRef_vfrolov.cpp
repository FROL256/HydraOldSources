#include "BVHBuilderRef_vfrolov.h"
#include "BVHTree.h"

////////////////////////////////////////////////////////////////////////////
////
BVHBuilderRef_vfrolov::BVHBuilderRef_vfrolov()
{ 
  m_pMyBVH = new RAYTR::BVHTree;
}

////////////////////////////////////////////////////////////////////////////
////
BVHBuilderRef_vfrolov::~BVHBuilderRef_vfrolov()
{
  delete m_pMyBVH;
}

////////////////////////////////////////////////////////////////////////////
////
void BVHBuilderRef_vfrolov::Build(const IBVHBuilder::InputData* pInData, AccelStructSettings settings) throw (std::runtime_error)
{
  m_pMyBVH->SetSettings(settings);
  m_pMyBVH->SetInputData(pInData);
  m_pMyBVH->Build();
}

////////////////////////////////////////////////////////////////////////////
////
const BVHNode* BVHBuilderRef_vfrolov::GetBVH() const throw (std::runtime_error)
{
  return m_pMyBVH->GetRoot();
}

////////////////////////////////////////////////////////////////////////////
////
int  BVHBuilderRef_vfrolov::GetBVHArraySize() const throw (std::runtime_error)
{
  return m_pMyBVH->GetNumNodes();
}

////////////////////////////////////////////////////////////////////////////
////
const char* BVHBuilderRef_vfrolov::GetPrimitiveListsArray() const throw (std::runtime_error)
{
  return m_pMyBVH->GetObjData();
}

////////////////////////////////////////////////////////////////////////////
////
int BVHBuilderRef_vfrolov::GetPrimitiveListsArraySize() const throw (std::runtime_error)
{
  return m_pMyBVH->GetObjDataSize();
}

////////////////////////////////////////////////////////////////////////////
////
AccelStructStatistics BVHBuilderRef_vfrolov::GetStatistics() const throw (std::runtime_error)
{
  return m_pMyBVH->GetStatistics();
}

////////////////////////////////////////////////////////////////////////////
////
void BVHBuilderRef_vfrolov::GetBoundingBox(float a_vmin[3], float a_vmax[3]) const throw (std::runtime_error)
{
  AABB4f box = m_pMyBVH->GetBoundingBox();

  for(int i=0;i<3;i++)
  {
    a_vmin[i] = box.vmin[i];
    a_vmax[i] = box.vmax[i];
  }
}

////////////////////////////////////////////////////////////////////////////
////
const void* BVHBuilderRef_vfrolov::GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const
{
  if(a_dataStructureName == "vfrolov_BVHTree")
  {
    return m_pMyBVH;
  }

  return NULL;
}

int BVHBuilderRef_vfrolov::MemoryExpansionFactor(AccelStructSettings settings) const
{
  return RAYTR::CalcBVHMemoryExpansionFactor(settings);
}


