#include "winsock2.h"
#include "Max.h"
#include "bmmlib.h"
#include "meshadj.h"
#include "modstack.h"
#include "stdmat.h"
#include "templt.h"
#include "render.h"
#include <float.h>		// Include these guys, otherwise sqrt() doesn't work!
#include <math.h>
#include <notify.h>



// Prototype for a utility function used for string table resources
TCHAR *GetString(int id);
