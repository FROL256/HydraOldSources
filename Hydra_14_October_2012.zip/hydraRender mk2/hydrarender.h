#ifndef __HYDRARENDER_H__
#define __HYDRARENDER_H__
#include "maxincl.h"
#include <ITabDialog.h>

#include <ctime>
#include <iostream>
#include <fstream>
#include <vector>
#include <boost/asio.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include "../HydraServer/ImportStructs.h"
#include "../HydraServer/HydraLogger.h"


#define HYDRAREND_CLASS_ID	Class_ID(0x396b67e8, 0x429e6794)
#define DUMMTL_CLASS_ID		Class_ID(0x10707f46, 0x40f5941)


#define RENDERNAME "Hydra Render mk2"



#define BIGFLOAT (float(1.0e30))


class HydraRender;


class MtlKeeper 
{
public:
  BOOL	AddMtl(Mtl* mtl);
  int		GetMtlID(Mtl* mtl);
  int		Count();
  Mtl*	GetMtl(int id);

  Tab<Mtl*> mtlTab;
};


class HydraRenderParams : public RenderGlobalContext {
public:
	RendType	rendType;				
	int			nMinx;
	int			nMiny;
	int			nMaxx;
	int			nMaxy;
	int			nNumDefLights;			// The default lights passed into the renderer
	Point2		scrDUV;
	DefaultLight*	pDefaultLights;
	FrameRendParams*	pFrp;			// Frame specific members
	RendProgressCallback*	progCallback;	// Render progress callback


	// Standard options
	// These options are configurable for all plugin renderers
	BOOL		bVideoColorCheck;
	BOOL		bForce2Sided;
	BOOL		bRenderHidden;
	BOOL		bSuperBlack;
	BOOL		bRenderFields;
	BOOL		bNetRender;

	// Render effects
	Effect*		effect;

	HydraRenderParams();
	void		SetDefaults();
	void		ComputeViewParams(const ViewParams&vp);
	Point3		RayDirection(float sx, float sy);

	int				NumRenderInstances();
  RenderInstance*	GetRenderInstance(int i);
};

// For calculation of view to screen coords
class MyView : public View {
public:
	HydraRenderParams*	pRendParams;
	Point2		ViewToScreen(Point3 p);
};



class HydraRender: public Renderer, public ITabDialogObject {
public:
	BOOL		bOpen;					// Indicate that Open() has been called
	int			nCurNodeID;				// Node counter
	int			nNumFaces;				// Face counter
	INode*		pScene;					// Root node of scene
	INode*		pViewNode;				// Camera node if available
	ViewParams	view;					// View parameters
	MyView		theView;				// View to screen calculation
	MtlBaseLib	mtls;					// List of all materials

	BOOL		bFirstFrame;			// Indicate that this is the first frame
	BOOL		bUvMessageDone;			// indicate that we have already warned the 


	HydraRenderParams	rendParams;			// Render parameters

	HydraRender();

	void		GetViewParams(INode* vnode, ViewParams& vp, TimeValue t);
	void		BeginThings();			// Called before rendering has started
	void		EndThings();			// Called after rendering has finished
	int			LoadMapFiles(TimeValue t, HWND hWnd, BOOL firstFrame);
	int			BuildMapFiles(TimeValue t);
	IOResult	Save(ISave *isave);
	IOResult	Load(ILoad *iload);
	RefTargetHandle	Clone(RemapDir &remap);

	int			Open(INode* scene, INode* vnode, ViewParams* viewPar, RendParams& rpar, HWND hwnd, DefaultLight* defaultLights=NULL, int numDefLights=0, RendProgressCallback* prog = NULL);
	int			Render(TimeValue t, Bitmap* tobm, FrameRendParams &frp, HWND hwnd, RendProgressCallback* prog, ViewParams* viewPar);
	void		Close(HWND hwnd, RendProgressCallback* prog = NULL);

	int			CheckAbort(int done, int total);
	void		SetProgTitle(const TCHAR *title);

	// Create the use interface dialog
	RendParamDlg*	CreateParamDialog(IRendParams *ir,BOOL prog);
	// Called by Max when Max is reset
	void		ResetParams();
	void		DeleteThis();
	Class_ID	ClassID();
	void		GetClassName(TSTR& s);

	// Get extension interfaces. Used to return the
	// ITabDialogObject interface for the renderer
    using Renderer::GetInterface;
	BaseInterface* GetInterface ( Interface_ID id );

	// ITabDialogObject
	// Add your tab(s) to the dialog. This will only be called if
	// both this object and the dialog agree that the tab should
	// be added. Dialog is the address of the dialog.
	virtual void AddTabToDialog ( ITabbedDialog* dialog, ITabDialogPluginTab* tab );

	// Return true if the tabs added by the ITabDialogPluginTab tab
	// are acceptable for this dialog. Dialog is the dialog being
	// filtered.
	virtual int AcceptTab ( ITabDialogPluginTab* tab );

	virtual RefResult NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID,  RefMessage message);


  std::string server_IP;

  HydraLogger plugin_log; 
  Included incl;
  bool bIncludeNormals;
  bool bIncludeTextureCoords;
  int		nMeshFrameStep;
  int		nKeyFrameStep;
  TimeValue	nStaticFrame;

 // Interface*	ip;
  int			nTotalNodeCount;
  int			nCurNode;
  MtlKeeper	mtlList;
  std::map<std::string,int> material_dict;

  int DoExport(INode* root);

  void ExportMesh(INode* node, TimeValue t, GeometryObj* geom, SphereObj* sphere, bool* IsSphere);
  BOOL TMNegParity(Matrix3 &m);
  TriObject* GetTriObjectFromNode(INode *node, TimeValue t, int &deleteIt);
  Point3	GetVertexNormal(Mesh* mesh, int faceNo, RVertex* rv);
  void	make_face_uv(Face *f, Point3 *tv);
  void PreProcess(INode* node, int& nodeCount);
  BOOL nodeEnum(INode* node, std::vector<LightObj>* li, std::vector<SphereObj>* spheres, SceneTree* tree, boost::archive::binary_oarchive& ar, int& geomObjNum); 
  void ExportNodeHeader(INode* node, TCHAR* type);
  void ExportGeomObject(INode* node, GeometryObj* geom, SphereObj* sphere, bool* IsSphere);
  void ExportMaterialList(std::vector<MaterialObj>* materials);
  void DumpMaterial(Mtl* mtl, int mtlID, int subNo, MaterialObj* mat);
  void NullMaterial(MaterialObj* mat);
  void ExportNodeTM(INode* node, GeometryObj* geom);
  void ExportNodeTM(INode* node, LightObj* li);
  void ExportLightObject(INode* node, LightObj* li);
  void ExportLightSettings(LightState* ls, GenLight* light, TimeValue t, LightObj* li);
  void DumpTexture(Texmap* tex, Class_ID cid, int subNo, float amt, TextureObj* texture);
  void DumpUVGen(StdUVGen* uvGen, TextureObj* texture);
  Point3 ComputeAverageNormal(std::vector < std::pair <Point3, int> > vn, int smGr);
  Point3 GetVertexNormal2(Mesh* mesh, int faceId, int vertexId);


  int DumpSceneFile(std::vector<MaterialObj> &materials, std::vector<LightObj> &lights,
    std::vector<SphereObj> &spheres, SceneTree* tree, INode* root);

  int FileTransfer(std::string name);
  void CreateConfigFile(std::string name);
  void CreateHeaderFile(std::string name, std::string type);
  void CreateMaterialsXML(std::string name, const std::vector<MaterialObj> &materials);
  // void CreateRenderSettingsFile(std::string name);

  inline BOOL	GetIncludeNormals()			{ return bIncludeNormals; }
  inline BOOL	GetIncludeTextureCoords()	{ return bIncludeTextureCoords; }
  inline int	GetMeshFrameStep()			{ return nMeshFrameStep; }
  inline int	GetKeyFrameStep()			{ return nKeyFrameStep; }
  inline TimeValue GetStaticFrame()		{ return nStaticFrame; }


  inline void SetMeshFrameStep(int val)			{ nMeshFrameStep = val; }
  inline void SetKeyFrameStep(int val)			{ nKeyFrameStep = val; }
  inline void SetStaticFrame(TimeValue val)		{ nStaticFrame = val; }


};



#endif // __HYDRARENDER_H__
