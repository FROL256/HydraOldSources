#include "HydraRender.h"

using boost::asio::ip::tcp;

static BOOL exportSelected;


int	HydraRender::DoExport(INode* root)
{

  plugin_log.Print("Entering HydraRender::DoExport");

  nTotalNodeCount = 0;
  nCurNode = 0;
  PreProcess(root, nTotalNodeCount);	

  std::vector<MaterialObj> materials;

  ExportMaterialList(&materials);

  int numChildren = root->NumberOfChildren();
  std::vector<LightObj> lights;
  std::vector<SphereObj> spheres;
  SceneTree* tree;
  tree = new SceneTree;
  tree->name = "root";


  int geomObjNum = DumpSceneFile(materials, lights, spheres, tree, root);


  incl.geomObjNum = geomObjNum;

  std::string configFile("C:/[Derp]/pluginFiles/derp.CONF");

  CreateConfigFile(configFile);

  delete tree;

  if(!FileTransfer(configFile))
  {
    plugin_log.Print("Config file transfer failed");
    return 0;
  }


  std::string path = GetCOREInterface()->GetCurFilePath();

  std::string sceneFileName = GetCOREInterface()->GetCurFileName();

  size_t found = path.find(sceneFileName);
  if (found != std::string::npos)
    path.erase(found, sceneFileName.size());

 

  std::vector<MaterialObj>::iterator mat;
  for(mat = materials.begin(); mat != materials.end(); ++mat)
  {
    std::vector<TextureObj>::iterator tex;
    for(tex = mat->textures.begin(); tex != mat->textures.end(); ++tex)
    {
      if(tex->mapName != "")
      {

        std::string texFilePath = path + tex->mapName;

        std::string header(texFilePath+".hhh");

        CreateHeaderFile(header, "TEXTURE_FILE");

        if(!FileTransfer(header))
        {
          plugin_log.Print("Texture file header transfer failed");
          return 0;
        }      

        if(!FileTransfer(texFilePath))
        {
          plugin_log.Print("Texture file header transfer failed");
          plugin_log.PrintValue("Missing texture file: ", texFilePath);
          return 0;
        }      
      }
    }
  }
  
  
  std::string header(incl.colladaProfile+".hhh");

  CreateHeaderFile(header, "COLLADA_PROFILE");

  if(!FileTransfer(header))
  {
    plugin_log.Print("Collada profile header transfer failed");
    return 0;
  }

  if(!FileTransfer(incl.colladaProfile))
  {
    plugin_log.Print("Collada profile file transfer failed");
    return 0;
  }

  if(!FileTransfer(incl.sceneDumpName))
  {
    plugin_log.Print("Scene file transfer failed");
    return 0;
  }

  plugin_log.Print("Leaving HydraRender::DoExport");

  return 1;
}

void HydraRender::CreateConfigFile(std::string name)
{
  plugin_log.Print("Creating config file");

  std::ofstream configFile;
  configFile.open (name.c_str(), std::ios_base::binary);
  boost::archive::binary_oarchive ar(configFile);

  TransferContents transferConf;
  transferConf.contents = transferConf.CONFIG;

  ar & transferConf;

  ar & incl;

  configFile.close();

  plugin_log.Print("Config file created");
}

/*void HydraRender::CreateRenderSettingsFile(std::string name)
{
plugin_log.Print("Creating render settings file");

std::ofstream settingsFile;
settingsFile.open (name.c_str(), std::ios_base::binary);
boost::archive::binary_oarchive ar(settingsFile);

TransferContents transferSettings;
transferSettings.contents = transferSettings.RENDER_SETTINGS;

ar & transferSettings;

ar & settings;

settingsFile.close();

plugin_log.Print("Render settings file created");
}*/
void HydraRender::CreateHeaderFile(std::string name, std::string type)
{
  plugin_log.PrintValue("Creating header file ", type);

  std::ofstream headerFile;
  headerFile.open (name.c_str(), std::ios_base::binary);
  boost::archive::binary_oarchive ar(headerFile);

  Header head;
  if(type == "COLLADA_PROFILE")
    head.contents = head.COLLADA_PROFILE;
  else if (type == "TEXTURE_FILE")
    head.contents = head.TEXTURE_FILE;

  head.file_name = name;

  TransferContents transferConf;
  transferConf.contents = transferConf.HEADER;

  ar & transferConf;

  ar & head;

  headerFile.close();

  plugin_log.Print("Header file created");
}

void HydraRender::CreateMaterialsXML(std::string name, const std::vector<MaterialObj> &materials)
{
  plugin_log.Print("Creating materials XML file");

  std::ofstream matFile;
  matFile.open (name.c_str(), std::ios_base::binary);

  matFile<<"<library_materials>\n";

  std::vector<MaterialObj>::const_iterator mat;

  for(mat = materials.begin(); mat != materials.end(); ++mat)
  {
    matFile<<"\t<material name=\""<<mat->name<<"\">\n";

      matFile<<"\t<hydra>\n";

        matFile<<"\t<specular>\n";
          matFile<<"\t<brdf>"<<mat->shading<<"</brdf>\n";
          matFile<<"\t<color sid=\"specular\">"<<mat->specular_color[0]<<" "<<mat->specular_color[1]<<" "<<mat->specular_color[2]<<"</color>\n";
          matFile<<"\t<cos_power>"<<mat->shininess<<"</cos_power>\n";
        matFile<<"\t</specular>\n";

        matFile<<"\t<ambient>\n";
         matFile<<"\t<color sid=\"ambient\">"<<mat->ambient_color[0]<<" "<<mat->ambient_color[1]<<" "<<mat->ambient_color[2]<<"</color>\n";
        matFile<<"\t</specular>\n";

        matFile<<"\t<diffuse>\n";
          matFile<<"\t<color sid=\"diffuse\">"<<mat->diffuse_color[0]<<" "<<mat->diffuse_color[1]<<" "<<mat->diffuse_color[2]<<"</color>\n";
        matFile<<"\t</diffuse>\n";
      
      matFile<<"\t</hydra>\n";

    matFile<<"\t</material>\n";
  }

  matFile<<"</library_materials>\n";

  matFile.close();

  plugin_log.Print("Materials XML file created");
}


int HydraRender::DumpSceneFile(std::vector<MaterialObj> &materials, std::vector<LightObj> &lights, std::vector<SphereObj> &spheres, SceneTree* tree, INode* root)
{
  int numChildren = root->NumberOfChildren();

  plugin_log.Print("Exporting & creating scene dump");

  std::ofstream dump;
  dump.open (incl.sceneDumpName.c_str(), std::ios_base::binary);
  boost::archive::binary_oarchive ar( dump );

  TransferContents transferScene;
  transferScene.contents = transferScene.SCENE;

  ar & transferScene;

  if(incl.materials)
  {
    ar & materials;
    plugin_log.Print("Materials........OK");
  }

  int geomObjNum = 0;

  for (int idx=0; idx<numChildren; idx++) 
  {
    nodeEnum(root->GetChildNode(idx), &lights, &spheres, tree, ar, geomObjNum);
  }

  plugin_log.Print("Geometry........OK");

  if(spheres.size() != 0)
    incl.spheres = true;
  else 
    incl.spheres = false;
  if(incl.spheres)
  {
    plugin_log.Print("Spheres ?");
    ar & spheres;
  } 
  if(incl.lights)
  {
    plugin_log.Print("Lights ?");
    ar & lights;
    plugin_log.Print("Lights........OK");
  }
  if(incl.tree)
  {
    plugin_log.Print("Tree ?");
    ar & tree;
    plugin_log.Print("Tree........OK");
  }


  dump.close();
  plugin_log.Print("Scene dump created.");

  return geomObjNum;

}

int HydraRender::FileTransfer(std::string name)
{
  try
  {
    const unsigned int port = 1234; //port the server listen
    const unsigned int buff_size = 16384; //size of the send buffer

    std::string server_ip_or_host =server_IP+":1234";
    size_t pos = server_ip_or_host.find(':'); 

    std::string port_string = server_ip_or_host.substr(pos+1);
    server_ip_or_host = server_ip_or_host.substr(0, pos);

    boost::asio::io_service io_service;
    tcp::resolver resolver(io_service);
    tcp::resolver::query query(server_ip_or_host, port_string);
    tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
    tcp::resolver::iterator end;
    tcp::socket socket(io_service);

    boost::system::error_code error = boost::asio::error::host_not_found;

    while (error && endpoint_iterator != end)
    {
      socket.close();
      socket.connect(*endpoint_iterator++, error);
    }

    if (error)
    {
      plugin_log.Print(error);
      return 0;
    }

    plugin_log.PrintValue("connected to ", server_ip_or_host);

    std::ifstream file(name.c_str(), std::ios_base::binary); 

    char* buff = new char[buff_size];

    unsigned int count = 0;

    plugin_log.Print("Start sending file contents...");

    while( !file.eof() ) 
    { 
      memset(buff,0,buff_size); 
      file.read(buff,buff_size); 

      boost::system::error_code ignored_error;
      unsigned int len = file.gcount(); 

      boost::asio::write(socket, boost::asio::buffer(buff,len), boost::asio::transfer_all(), ignored_error); 
      count+=len;
    }
    file.close(); 

    delete [] buff; 
    buff = 0;

    plugin_log.PrintValue("Bytes sent: ", count);
  }
  catch (std::exception& e)
  {
    plugin_log.Print(e.what());
  }
  return 1;
}


void HydraRender::ExportMaterialList(std::vector<MaterialObj>* materials)
{
  if (!incl.materials)
  {
    return;
  }

  int numMtls = mtlList.Count();
  int newMtlIndex = 0;

  for (int i = 0; i < numMtls; i++) 
  {
    int subMats = mtlList.GetMtl(i)->NumSubMtls();
    if(subMats == 0)
    {
      MaterialObj mat;
      DumpMaterial(mtlList.GetMtl(i), newMtlIndex, -1, &mat);
      materials->push_back(mat);
      material_dict[mat.name] = newMtlIndex;
      newMtlIndex++;
    }
    else
    {
      for(int j = 0; j < subMats; j++)
      {
        Mtl* subMtl = mtlList.GetMtl(i)->GetSubMtl(j);
        if (subMtl) 
        {
          MaterialObj mat;
          DumpMaterial(subMtl, 0, newMtlIndex, &mat);
          materials->push_back(mat);
          material_dict[mat.name] = newMtlIndex;
          newMtlIndex++;
        }    
      }
    }

  }
}

void HydraRender::DumpMaterial(Mtl* mtl, int mtlID, int subNo, MaterialObj* mat)
{
  int i;
  TimeValue t = GetStaticFrame();

  if (!mtl) return;

  TSTR className;
  mtl->GetClassName(className);


  if (subNo == -1) 
  {
    mat->id = mtlID;
    mat->sub = 0;
  }
  else
    mat->id = subNo;

  mat->name = mtl->GetName();

  if (mtl->NumSubMtls() == 0)  
  {

    if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0)) 
    {
      StdMat* std = (StdMat*)mtl;

      mat->ambient_color[0] = std->GetAmbient(t).r;
      mat->ambient_color[1] = std->GetAmbient(t).g;
      mat->ambient_color[2] = std->GetAmbient(t).b;

      mat->diffuse_color[0] = std->GetDiffuse(t).r;
      mat->diffuse_color[1] = std->GetDiffuse(t).g;
      mat->diffuse_color[2] = std->GetDiffuse(t).b;

      mat->specular_color[0] = std->GetSpecular(t).r;
      mat->specular_color[1] = std->GetSpecular(t).g;
      mat->specular_color[2] = std->GetSpecular(t).b;

      mat->shininess = std->GetShininess(t);
      mat->shine_strength = std->GetShinStr(t);
      mat->transparency = std->GetXParency(t);
      //mat->wire_size = std->WireSize(t);


      switch(std->GetShading()) 
      {
      case SHADE_CONST:
        mat->shading = "CONST";
        break;
      case SHADE_PHONG:
        mat->shading = "PHONG";
        break;
      case SHADE_METAL:
        mat->shading = "METAL";
        break;
      case SHADE_BLINN:
        mat->shading = "BLINN";
        break;
      default:
        mat->shading = "OTHER";
        break;
      }
      mat->opacity = std->GetOpacity(t);
      mat->IOR = std->GetIOR(t);
      mat->opacity_falloff = std->GetOpacFalloff(t);
      mat->self_illumination = std->GetSelfIllum(t);

      mat->twosided = std->GetTwoSided();
      /*	mat->wire = std->GetWire();
      mat->wire_units = std->GetWireUnits();*/
      mat->falloff = std->GetFalloffOut();

      mat->facemap = std->GetFaceMap();
      mat->soften = std->GetSoften();

      switch (std->GetTransparencyType()) 
      {
      case TRANSP_FILTER:
        mat->transparency_type = "FILTER";
        break;
      case TRANSP_SUBTRACTIVE:
        mat->transparency_type = "SUBTRACTIVE";
        break;
      case TRANSP_ADDITIVE:
        mat->transparency_type = "ADDITIVE";
        break;
      default: 
        mat->transparency_type = "OTHER";
        break;
      }
    }
    else 
    {
      mat->ambient_color[0] = mtl->GetAmbient(t).r;
      mat->ambient_color[1] = mtl->GetAmbient(t).g;
      mat->ambient_color[2] = mtl->GetAmbient(t).b;

      mat->diffuse_color[0] = mtl->GetDiffuse(t).r;
      mat->diffuse_color[1] = mtl->GetDiffuse(t).g;
      mat->diffuse_color[2] = mtl->GetDiffuse(t).b;

      mat->specular_color[0] = mtl->GetSpecular(t).r;
      mat->specular_color[1] = mtl->GetSpecular(t).g;
      mat->specular_color[2] = mtl->GetSpecular(t).b;

      mat->shininess = mtl->GetShininess(t);
      mat->shine_strength = mtl->GetShinStr(t);
      mat->transparency = mtl->GetXParency(t);
      //mat->wire_size = mtl->WireSize(t);

      mat->opacity = 0;
      mat->IOR = 0;
      mat->opacity_falloff = 0;
      mat->self_illumination = 0;
    }

    for (i=0; i<mtl->NumSubTexmaps(); i++) 
    {
      Texmap* subTex = mtl->GetSubTexmap(i);
      float amt = 1.0f;
      if (subTex) {
        // If it is a standard material we can see if the map is enabled.
        if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0)) 
        {
          if (!((StdMat*)mtl)->MapEnabled(i))
            continue;
          amt = ((StdMat*)mtl)->GetTexmapAmt(i, 0);

        }
        TextureObj tex;
        DumpTexture(subTex, mtl->ClassID(), i, amt, &tex);
        mat->textures.push_back(tex);
      }
    }
  } //if NumSubMat == 0
  /*else if (mtl->NumSubMtls() > 0)  
  {

  }*/
}

void HydraRender::NullMaterial(MaterialObj* mat)
{
  mat->ambient_color[0] = 0;
  mat->ambient_color[1] = 0;
  mat->ambient_color[2] = 0;

  mat->diffuse_color[0] = 0;
  mat->diffuse_color[1] = 0;
  mat->diffuse_color[2] = 0;

  mat->specular_color[0] = 0;
  mat->specular_color[1] = 0;
  mat->specular_color[2] = 0;

  mat->shininess = 0;
  mat->shine_strength = 0;
  mat->transparency = 0;

  mat->shading = "PHONG";

  mat->opacity = 0;
  mat->IOR = 0;
  mat->opacity_falloff = 0;
  mat->self_illumination = 0;

  mat->twosided = 0;
  mat->falloff = 0;

  mat->facemap = 0;
  mat->soften = 0;

  mat->transparency_type = "FILTER";

}

void HydraRender::DumpTexture(Texmap* tex, Class_ID cid, int subNo, float amt, TextureObj* texture)
{
  if (!tex) return;

  TSTR className;
  tex->GetClassName(className);

  texture->texName = tex->GetName();
  texture->texClass = className;

  // If we include the subtexture ID, a parser could be smart enough to get
  // the class name of the parent texture/material and make it mean something.
  //fprintf(pStream,"%s\t%s %d\n", indent.data(), ID_TEXSUBNO, subNo);

  texture->texAmount = amt;

  // Is this a bitmap texture?
  // We know some extra bits 'n pieces about the bitmap texture
  if (tex->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00)) 
  {
    TSTR mapName = ((BitmapTex *)tex)->GetMapName();
    texture->mapName = mapName;


    StdUVGen* uvGen = ((BitmapTex *)tex)->GetUVGen();
    if (uvGen) 
    {
      DumpUVGen(uvGen, texture);
    }

    TextureOutput* texout = ((BitmapTex*)tex)->GetTexout();
    texture->texInvert = texout->GetInvert();

    switch(((BitmapTex*)tex)->GetFilterType()) 
    {
    case FILTER_PYR:
      texture->texFilter = "PYR";
      break;
    case FILTER_SAT:
      texture->texFilter = "SAT";
      break;
    default:
      texture->texFilter = "NONE";
      break;
    }
  }

  // TODO: manage with SubTexmaps() - wtf is that. 
  //

  /*
  for (int i=0; i<tex->NumSubTexmaps(); i++) 
  {
  DumpTexture(tex->GetSubTexmap(i), tex->ClassID(), i, 1.0f, indentLevel+1);
  }*/
}

void HydraRender::DumpUVGen(StdUVGen* uvGen, TextureObj* texture)
{
  int mapType = uvGen->GetCoordMapping(0);
  TimeValue t = GetStaticFrame();

  switch (mapType) 
  {
  case UVMAP_EXPLICIT:
    texture->mapType = "EXPLICIT";
    break;
  case UVMAP_SPHERE_ENV: 
    texture->mapType = "SPHERE_ENV";
    break;
  case UVMAP_CYL_ENV:  
    texture->mapType = "CYL_ENV";
    break;
  case UVMAP_SHRINK_ENV: 
    texture->mapType = "SHRINK_ENV"; 
    break;
  case UVMAP_SCREEN_ENV: 
    texture->mapType = "SCREEN_ENV";
    break;
  }

  texture->uOffset = uvGen->GetUOffs(t);
  texture->vOffset = uvGen->GetVOffs(t);
  texture->uTiling = uvGen->GetUScl(t);
  texture->vTiling = uvGen->GetVScl(t);
  texture->angle = uvGen->GetAng(t);
  texture->blur = uvGen->GetBlur(t);
  texture->blurOffset = uvGen->GetBlurOffs(t);
  texture->noiseAmt =uvGen->GetNoiseAmt(t);
  texture->noiseSize = uvGen->GetNoiseSize(t);
  texture->noiseLevel = uvGen->GetNoiseLev(t);
  texture->noisePhase = uvGen->GetNoisePhs(t);
}



void HydraRender::ExportNodeTM(INode* node, GeometryObj* geom)
{
  //Matrix3 pivot = node->GetNodeTM(GetStaticFrame());
  Matrix3 pivot = node->GetObjectTM(GetStaticFrame());

  Point3 row1, row2, row3, row4;

  row1 = pivot.GetRow(0);
  row2 = pivot.GetRow(1);
  row3 = pivot.GetRow(2);
  row4 = pivot.GetRow(3);

  geom->m[0] = row1[0];
  geom->m[1] = row1[1];
  geom->m[2] = row1[2];
  geom->m[3] = 0;

  geom->m[4] = row2[0];
  geom->m[5] = row2[1];
  geom->m[6] = row2[2];
  geom->m[7] = 0;

  geom->m[8] = row3[0];
  geom->m[9] = row3[1];
  geom->m[10] = row3[2];
  geom->m[11] = 0;

  geom->m[12] = row4[0];
  geom->m[13] = row4[1];
  geom->m[14] = row4[2];
  geom->m[15] = 1;
}

void HydraRender::ExportNodeTM(INode* node, LightObj* li)
{
  Matrix3 pivot = node->GetObjectTM(GetStaticFrame());


  Point3 row1, row2, row3, row4;

  row1 = pivot.GetRow(0);
  row2 = pivot.GetRow(1);
  row3 = pivot.GetRow(2);
  row4 = pivot.GetRow(3);

  li->m[0] = row1[0];
  li->m[1] = row1[1];
  li->m[2] = row1[2];
  li->m[3] = 0;

  li->m[4] = row2[0];
  li->m[5] = row2[1];
  li->m[6] = row2[2];
  li->m[7] = 0;

  li->m[8] = row3[0];
  li->m[9] = row3[1];
  li->m[10] = row3[2];
  li->m[11] = 0;

  li->m[12] = row4[0];
  li->m[13] = row4[1];
  li->m[14] = row4[2];
  li->m[15] = 1;
}

void HydraRender::ExportGeomObject(INode* node, GeometryObj* geom, SphereObj* sphere, bool* IsSphere)
{
  ObjectState os = node->EvalWorldState(GetStaticFrame());
  if (!os.obj)
    return;

  // Targets are actually geomobjects, but we will export them
  // from the camera and light objects, so we skip them here.
  if (os.obj->ClassID() == Class_ID(TARGET_CLASS_ID, 0))
    return;

  geom->mesh_id = node->GetName();

  ExportNodeTM(node, geom);

  if (incl.geometry) 
  {
    ExportMesh(node, GetStaticFrame(), geom, sphere, IsSphere);
  }

  if(*IsSphere == true)
  {
    for(int j = 0; j < 16; j++)
    {
      sphere->m[j] = geom->m[j];
    }
    sphere->mesh_id = node->GetName();
  }

  if (incl.materials) 
  {
    Mtl* mtl = node->GetMtl();
    if (mtl) 
    {
      if(*IsSphere == true)
      {
        std::string matName = mtl->GetName();
        sphere->material_id = material_dict[matName];
      }
      /*int mtlID = mtlList.GetMtlID(mtl);
      if (mtlID >= 0) 
      {
      if(*IsSphere == true)
      sphere->material_id = mtlID;
      }*/
    }
  }
}


void HydraRender::ExportLightObject(INode* node, LightObj* li)
{
  TimeValue t = GetStaticFrame();

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj) 
  {
    return;
  }

  GenLight* light = (GenLight*)os.obj;
  struct LightState ls;
  Interval valid = FOREVER;

  light->EvalLightState(t, valid, &ls);

  switch(ls.type) 
  {
  case OMNI_LIGHT:
    li->lightType = "OMNI";
    break;
  case TSPOT_LIGHT:
    li->lightType = "TSPOT";
    break;
  case DIR_LIGHT:
    li->lightType = "DIR";
    break;
  case FSPOT_LIGHT:
    li->lightType = "FSPOT";
    break;
  }

  ExportNodeTM(node, li);

  int shadowMethod = light->GetShadowMethod();
  if(shadowMethod == LIGHTSHADOW_NONE)
    li->shadowType = "NONE";
  else if(shadowMethod == LIGHTSHADOW_MAPPED) 
    li->shadowType = "SHADOW_MAP";
  else
    li->shadowType = "SHADOW_RAY";

  if(light->GetSpotShape() == RECT_LIGHT)
    li->spotShape = "RECT";
  else
    li->spotShape = "CIRCLE";

  li->useGlobal = light->GetUseGlobal();
  li->absMapBias = light->GetAbsMapBias();
  li->overshoot = light->GetOvershoot();

  // Export light settings for frame 0
  ExportLightSettings(&ls, light, t, li);

}

void HydraRender::ExportLightSettings(LightState* ls, GenLight* light, TimeValue t, LightObj* li)
{

  li->color[0] = ls->color.r;
  li->color[1] = ls->color.g;
  li->color[2] = ls->color.b;
  li->intensity = ls->intens;
  li->aspect = ls->aspect;

  if (ls->type != OMNI_LIGHT) 
  {
    li->hotsize = ls->hotsize;
    li->fallsize = ls->fallsize;
  }
  if (ls->type != DIR_LIGHT && ls->useAtten) 
  {
    li->attenStart = ls->attenStart;
    li->attenEnd = ls->attenEnd;
  }

  li->TDist = light->GetTDist(t, FOREVER);
  li->mapBias = light->GetMapBias(t, FOREVER);
  li->mapRange = light->GetMapRange(t, FOREVER);
  li->mapSize = light->GetMapSize(t, FOREVER);
  li->rayBias = light->GetRayBias(t, FOREVER);

}


void HydraRender::ExportMesh(INode* node, TimeValue t, GeometryObj* geom, SphereObj* sphere, bool* IsSphere)
{
  int i;
  Mtl* nodeMtl = node->GetMtl();
  Matrix3 tm = node->GetObjTMAfterWSM(t);
  BOOL negScale = TMNegParity(tm);
  int vx1, vx2, vx3;
  TSTR indent;

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj || os.obj->SuperClassID()!=GEOMOBJECT_CLASS_ID) {
    return; // Safety net. This shouldn't happen.
  }

  // Order of the vertices. Get 'em counter clockwise if the objects is
  // negatively scaled.
  if (negScale) 
  {
    vx1 = 2;
    vx2 = 1;
    vx3 = 0;
  }
  else 
  {
    vx1 = 0;
    vx2 = 1;
    vx3 = 2;
  }

  BOOL needDel;
  TriObject* tri = GetTriObjectFromNode(node, t, needDel); 
  if (!tri) 
  {
    return;
  }

  Mesh* mesh = &tri->GetMesh();


  geom->n_verts = mesh->getNumVerts();
  geom->n_faces = mesh->getNumFaces();


  for (i=0; i<mesh->getNumVerts(); i++) {
    Point3 v = tm * mesh->verts[i];

    geom->positions.push_back(v[0]);
    geom->positions.push_back(v[1]);
    geom->positions.push_back(v[2]);

    if(i==0)
    {
      geom->bbox[0] = v[0];
      geom->bbox[1] = v[1];
      geom->bbox[2] = v[2];

      geom->bbox[3] = v[0];
      geom->bbox[4] = v[1];
      geom->bbox[5] = v[2];
    }
    else 
    {
      if ( v[0] < geom->bbox[0] ) geom->bbox[0] = v[0];
      if ( v[1] < geom->bbox[1] ) geom->bbox[1] = v[1];
      if ( v[2] < geom->bbox[2] ) geom->bbox[2] = v[2];

      if ( v[0] > geom->bbox[3] ) geom->bbox[3] = v[0];
      if ( v[1] > geom->bbox[4] ) geom->bbox[4] = v[1];
      if ( v[2] > geom->bbox[5] ) geom->bbox[5] = v[2];
    }

  }

  Face* f;

  for (i=0; i<mesh->getNumFaces(); i++) 
  {
    f = &mesh->faces[i];
    geom->face_smoothgroups.push_back(f->smGroup);

    int nodeSubMtls = nodeMtl->NumSubMtls();
    if(nodeSubMtls == 0)
    {
      geom->material_id.push_back(material_dict[nodeMtl->GetName().data()]);
    }
    else
    {
      int subMatId = mesh->faces[i].getMatID();
      Mtl* faceMat = nodeMtl->GetSubMtl(subMatId);
      geom->material_id.push_back(material_dict[faceMat->GetName().data()]);
    } 

    geom->pos_indeces.push_back(mesh->faces[i].v[vx1]);
    geom->pos_indeces.push_back(mesh->faces[i].v[vx2]);
    geom->pos_indeces.push_back(mesh->faces[i].v[vx3]);

  }
  if (GetIncludeTextureCoords()) 
  {
    // If not, export standard tverts
    int numTVx = mesh->getNumTVerts();

    if (numTVx) 
    {
      for (i=0; i<numTVx; i++) 
      {
        UVVert tv = mesh->tVerts[i];
      }
      for (i=0; i<mesh->getNumFaces(); i++) 
      {
        geom->tex_coords.push_back(mesh->tvFace[i].t[vx1]);
        geom->tex_coords.push_back(mesh->tvFace[i].t[vx2]);
      }
    }
  }


  *IsSphere = false;
  float radius = 0;
  Point3 center(0,0,0);
  //std::string sphereMaterialName = nodeMtl->GetName();;

  std::string SphereName;
  SphereName = node->NodeName();


  if (SphereName.find("Sphere") != std::string::npos || SphereName.find("sphere") != std::string::npos) 
  {
    *IsSphere = true;

    // calculate center
    //
    center.x = 0;
    center.y = 0;
    center.z = 0;

    for(int i = 0; i < geom->n_verts; i++)
    {
      Point3 v = tm * mesh->verts[i];
      center += v;
    }

    center *= (1.0f/geom->n_verts);

    // assume we have definite radius

    Point3 p1 = tm * mesh->verts[0];
    Point3 rad;
    rad = p1 - center;
    radius = rad.FLength();
    float epsilon = 0.001f;

    for(int i=0;i<geom->n_verts;i++)
    {
      Point3 v = tm * mesh->verts[i];
      Point3 temp;
      temp = v - center;
      if( abs(temp.FLength() - radius) > epsilon )
      {
        IsSphere = false;
        break;
      }
    }
  }

  if(*IsSphere == true)
  {
    sphere->center[0] = center.x; 
    sphere->center[1] = center.y;
    sphere->center[2] = center.z;
    sphere->center[3] = 1;

    sphere->radius = radius;

    for(int j = 0; j < 6; j++)
    {
      sphere->bbox[j] = geom->bbox[j];
    }
  }

  /*******************/


  if (needDel) 
  {
    delete tri;
  }
}


BOOL HydraRender::TMNegParity(Matrix3 &m)
{
  return (DotProd(CrossProd(m.GetRow(0),m.GetRow(1)),m.GetRow(2))<0.0)?1:0;
}


TriObject* HydraRender::GetTriObjectFromNode(INode *node, TimeValue t, int &deleteIt)
{
  deleteIt = FALSE;
  Object *obj = node->EvalWorldState(t).obj;
  if (obj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0))) { 
    TriObject *tri = (TriObject *) obj->ConvertToType(t, 
      Class_ID(TRIOBJ_CLASS_ID, 0));
    // Note that the TriObject should only be deleted
    // if the pointer to it is not equal to the object
    // pointer that called ConvertToType()
    if (obj != tri) deleteIt = TRUE;
    return tri;
  }
  else {
    return NULL;
  }
}


static Point3 basic_tva[3] = { 
  Point3(0.0,0.0,0.0),Point3(1.0,0.0,0.0),Point3(1.0,1.0,0.0)
};
static Point3 basic_tvb[3] = { 
  Point3(1.0,1.0,0.0),Point3(0.0,1.0,0.0),Point3(0.0,0.0,0.0)
};
static int nextpt[3] = {1,2,0};
static int prevpt[3] = {2,0,1};

void HydraRender::make_face_uv(Face *f, Point3 *tv)
{
  int na,nhid,i;
  Point3 *basetv;
  /* make the invisible edge be 2->0 */
  nhid = 2;
  if (!(f->flags&EDGE_A))  nhid=0;
  else if (!(f->flags&EDGE_B)) nhid = 1;
  else if (!(f->flags&EDGE_C)) nhid = 2;
  na = 2-nhid;
  basetv = (f->v[prevpt[nhid]]<f->v[nhid]) ? basic_tva : basic_tvb; 
  for (i=0; i<3; i++) {  
    tv[i] = basetv[na];
    na = nextpt[na];
  }
}

void HydraRender::PreProcess(INode* node, int& nodeCount)
{
  nodeCount++;

  mtlList.AddMtl(node->GetMtl());

  for (int c = 0; c < node->NumberOfChildren(); c++) 
  {
    PreProcess(node->GetChildNode(c), nodeCount);
  }

}

BOOL HydraRender::nodeEnum(INode* node, std::vector<LightObj>* lights, std::vector<SphereObj>* spheres, SceneTree* tree, boost::archive::binary_oarchive& ar, int& geomObjNum) 
{
  if(exportSelected && node->Selected() == FALSE)
    return TREE_CONTINUE;

  nCurNode++;
  //ip->ProgressUpdate((int)((float)nCurNode/nTotalNodeCount*100.0f)); 

  // Stop recursing if the user pressed Cancel 
  /*if (ip->GetCancel())
  return FALSE;*/

  // Only export if exporting everything or it's selected
  if(!exportSelected || node->Selected()) {

    // The ObjectState is a 'thing' that flows down the pipeline containing
    // all information about the object. By calling EvalWorldState() we tell
    // max to evaluate the object at end of the pipeline.
    ObjectState os = node->EvalWorldState(0); 

    // The obj member of ObjectState is the actual object we will export.
    if (os.obj) {

      // We look at the super class ID to determine the type of the object.
      switch(os.obj->SuperClassID()) {
      case GEOMOBJECT_CLASS_ID: 
        {
          SceneTree *newNode = new SceneTree();
          newNode->name = node->GetName();
          tree->children.push_back(newNode);
          GeometryObj geom;
          SphereObj sphere;
          bool IsSphere = false;
          ExportGeomObject(node, &geom, &sphere, &IsSphere); 
          if(IsSphere)
          {
            spheres->push_back(sphere);
          }
          else
          {
            if (geom.n_faces != 0)
            {
              ar & geom;
              geomObjNum++;	
            }
          }
          break;
        }
      case LIGHT_CLASS_ID:
        {
          LightObj li;
          ExportLightObject(node, &li); 
          lights->push_back(li);
          break;
        }
      default:
        {
          SceneTree *newNode = new SceneTree();
          newNode->name = node->GetName();
          tree->children.push_back(newNode);
          delete newNode;
          break;
        }

      }
    }
  }	

  // For each child of this node, we recurse into ourselves 
  // until no more children are found.
  for (int c = 0; c < node->NumberOfChildren(); c++) {
    if (!nodeEnum(node->GetChildNode(c), lights, spheres, tree->children.at(tree->children.size()-1), ar, geomObjNum)) //tree->children.at(tree->children.size()-1)
      return FALSE;
  }

  return TRUE;
}

BOOL MtlKeeper::AddMtl(Mtl* mtl)
{
  if (!mtl) {
    return FALSE;
  }

  int numMtls = mtlTab.Count();
  for (int i=0; i<numMtls; i++) {
    if (mtlTab[i] == mtl) {
      return FALSE;
    }
  }
  mtlTab.Append(1, &mtl, 25);

  return TRUE;
}

int MtlKeeper::GetMtlID(Mtl* mtl)
{
  int numMtls = mtlTab.Count();
  for (int i=0; i<numMtls; i++) {
    if (mtlTab[i] == mtl) {
      return i;
    }
  }
  return -1;
}

int MtlKeeper::Count()
{
  return mtlTab.Count();
}

Mtl* MtlKeeper::GetMtl(int id)
{
  return mtlTab[id];
}