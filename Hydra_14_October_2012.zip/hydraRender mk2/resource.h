//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by cjrender.rc
//
#define IDS_YES                         1
#define IDS_NO                          2
#define IDS_LIB_DESCRIPTION             3
#define IDS_TAB_ROLLOUT                 4
#define IDD_CCJRENDERDLG                101
#define IDD_CCJRENDERDLG_PROG           102
#define IDC_AA_NONE                     1001
#define IDC_AA_MEDIUM                   1002
#define IDC_AA_HIGH                     1003
#define IDC_REFLENV                     1004
#define IDC_ANTIALIAS                   1005
#define IDC_PROG_DEPTH                  1006
#define IDC_PROG_ANTIALIAS              1007
#define IDC_PROG_REFLENV                1008
#define IDC_GEOMETRY                    1011
#define IDC_MATERIALS                   1012
#define IDC_LIGHTS                      1013
#define IDC_NAME                        1014
#define IDC_RESOLUTION                  1016
#define IDC_SHADOWS                     1017
#define IDC_MINRAYS                     1018
#define IDC_MAXRAYS                     1019
#define IDC_HDRESTIMATION               1020
#define IDC_LIGHTON                     1021
#define IDC_ALGORITHM                   1022
#define IDC_IRRADTYPE                   1023
#define IDC_ACCTYPE                     1024
#define IDC_CONSTRMODE                  1025
#define IDC_AA                          1026
#define IDC_RTBUFFERSIZE                1027
#define IDC_RELIGHTING                  1028
#define IDC_PARALLEL                    1029
#define IDC_SHOWBLOCKS                  1030
#define IDC_SHOWMRAYS                   1031
#define IDC_COMBO1                      1031
#define IDC_DUMP_PATH                   1032
#define IDC_COLLADA_PATH                1033
#define IDC_SERVER_IP                   1034
#define IDC_RENDER                      1035
#define IDC_DEPTH                       1109
#define IDC_DEPTH_SPIN                  1110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
