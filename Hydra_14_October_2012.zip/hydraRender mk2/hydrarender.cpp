#include "hydrarender.h"

BMM_Color_64 colTo64(Color c)
{
  BMM_Color_64 bc;

  // Clamp the colors
  c.ClampMinMax();

  bc.r = (WORD)(c.r * 65535.0);
  bc.g = (WORD)(c.g * 65535.0);
  bc.b = (WORD)(c.b * 65535.0);

  return bc;
}


HydraRender::HydraRender()
{
	rendParams.renderer = this;

  server_IP = "127.0.0.1";

  plugin_log.OpenLogFile("C:/[Derp]/pluginFiles/plugin_log.txt");
  incl.geometry = true;
  incl.spheres = false;
  incl.lights = false;
  incl.materials = true;
  incl.tree = false;
  bIncludeNormals  =  FALSE;
  bIncludeTextureCoords = TRUE;
  nKeyFrameStep = 5;
  nMeshFrameStep = 5;
  nStaticFrame = 0;

  incl.sceneDumpName = "C:/[Derp]/pluginFiles/test.DERP";
  incl.colladaProfile = "c:/[Derp]/colladaProfiles/profile.xml";
  incl.render_type = "Ray_Tracer";

  incl.AccType = "bvh";
  incl.ConstrMode = "quality";

  incl.imgObjNum = 0;
}


void HydraRender::ResetParams()
{
	DebugPrint(_T("**** Resetting parameters.\n"));

	rendParams.SetDefaults();
}


void HydraRender::DeleteThis()
{
	delete this;
}


Class_ID HydraRender::ClassID()
{
	return HYDRAREND_CLASS_ID;
}


void HydraRender::GetClassName(TSTR& s)
{
	s = RENDERNAME;
}


int HydraRender::Open(INode *scene,INode *vnode,ViewParams* viewPar,RendParams& rpar,HWND hwnd,DefaultLight* defaultLights,int numDefLights, RendProgressCallback* prog)
{
	int idx;

  plugin_log.Print("Entering HydraRender::Open");


	// Suspend undo, macro recorder, animation, auto backup, and maintain the "Save Required" flag 
	SuspendAll uberSuspend(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

	// Important!! This has to be done here in MAX Release 2!
	// Also enable it again in Renderer::Close()
	GetCOREInterface()->DisableSceneRedraw();

	if (!rpar.inMtlEdit) {
		BroadcastNotification(NOTIFY_PRE_RENDER, (void*)(RendParams*)&rpar);	// skk
		}

	// Get options from RenderParams
	// These are the options that are common to all renderers
	rendParams.bVideoColorCheck = rpar.colorCheck;
	rendParams.bForce2Sided = rpar.force2Side;
	rendParams.bRenderHidden = rpar.rendHidden;
	rendParams.bSuperBlack = rpar.superBlack;
	rendParams.bRenderFields = rpar.fieldRender;
	rendParams.bNetRender = rpar.isNetRender;
	rendParams.rendType = rpar.rendType;

	// Default lights
	rendParams.nNumDefLights = numDefLights;
	rendParams.pDefaultLights = defaultLights;

	// Support Render effects
	rendParams.effect = rpar.effect;



	// Flag we use when reporting errors
	bFirstFrame = TRUE;
	bUvMessageDone = FALSE;

	// Initialize node counter
	nCurNodeID = -1;  //skk


  DoExport(scene);

  plugin_log.Print("Leaving HydraRender::Open");

	return 1; 	
}


void HydraRender::Close(HWND hwnd, RendProgressCallback* prog)
{
  plugin_log.Print("Entering HydraRender::Close");

	GetCOREInterface()->EnableSceneRedraw();

  plugin_log.Print("Leaving HydraRender::Close");

}


void HydraRender::SetProgTitle(const TCHAR *title) 
{
	if (rendParams.progCallback) rendParams.progCallback->SetTitle(title);
}


int HydraRender::Render(TimeValue t, Bitmap* tobm, FrameRendParams &frp, HWND hwnd, RendProgressCallback* prog, ViewParams* viewPar)
{

  plugin_log.Print("Entering HydraRender::Render");


	int i;
	int nExitStatus = 1;

	if (!tobm || !bOpen) {
		return 0; // No output bitmap, not much we can do.
	}
	

	// Suspend undo, macro recorder, animation, auto backup, and maintain the "Save Required" flag 
	SuspendAll uberSuspend(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

	// Update progress window
	if (prog) {
		prog->SetTitle("Preparing to render...");
	}

	// Render progress callback
	rendParams.progCallback = prog;	

	// Setup ViewParams:
	rendParams.devWidth = tobm->Width();
	rendParams.devHeight = tobm->Height();
	rendParams.devAspect = tobm->Aspect();


	// Get the frame
	rendParams.time = t;
	// Get the FrameRenderParams. These are parameters that can be animated
	// so they are different every frame
	rendParams.pFrp = &frp;


  if (prog) 
  {
    prog->SetTitle("Rendering...");
  }

  rendParams.nMinx = 0;
  rendParams.nMiny = 0;
  rendParams.nMaxx = rendParams.devWidth;
  rendParams.nMaxy = rendParams.devHeight;

  Color24 red24 (1, 0, 0);


  for (int y = rendParams.nMiny; y < rendParams.nMaxy; y++) 
  {

    for (int x = rendParams.nMinx; x < rendParams.nMaxx; x++) 
    {

      Color col(0.5f,0.0f,0.0f);

      BMM_Color_64 col64; 
      col64 = colTo64(col);


      tobm->PutPixels(x, y, 1, &col64);
    }

    // Update the output every 10 scanlines
    if (y%10 == 0 || y == rendParams.devHeight-1) 
    {
      Rect r;
      r.top = y-10;
      r.bottom = y;
      r.left = 0;
      r.right = tobm->Width();

      tobm->ShowProgressLine(y-1);

      tobm->RefreshWindow(&r);
    }

    // Update progress bar and check for cancel
    if (prog && (prog->Progress(y, rendParams.devHeight-1) == RENDPROG_ABORT)) 
    {
      tobm->ShowProgressLine(-1);	// Clear progress line
      return 0;
      break;
    }

  }

  tobm->ShowProgressLine(-1);	// Clear progress line


  RenderInfo* ri = tobm->AllocRenderInfo();
  if (ri) 
  {
    ri->projType = rendParams.projType?ProjParallel:ProjPerspective;
    ri->kx = rendParams.xscale;
    ri->ky = rendParams.yscale;
    ri->xc = (float)rendParams.xc;
    ri->yc = (float)rendParams.xc;
    ri->fieldRender = FALSE;	
    ri->fieldOdd = FALSE;		
    ri->renderTime[0] = rendParams.time;
    ri->worldToCam[0] = rendParams.worldToCam;
    ri->camToWorld[0] = rendParams.camToWorld;
  }

  tobm->RefreshWindow(NULL);
  if (tobm->GetWindow())
    UpdateWindow(tobm->GetWindow());

	if (prog) {
		prog->SetTitle("Done.");
	}

	return nExitStatus;
}


void HydraRender::GetViewParams(INode* vnode, ViewParams& vp, TimeValue t)
{
}


#define ENUMMISSING FILE_ENUM_MISSING_ONLY|FILE_ENUM_1STSUB_MISSING|FILE_ENUM_SKIP_VPRENDER_ONLY

int HydraRender::LoadMapFiles(TimeValue t, HWND hWnd, BOOL firstFrame)
{

	return 1;
}


int HydraRender::BuildMapFiles(TimeValue t)
{
	return 1;
}



RefTargetHandle HydraRender::Clone(RemapDir &remap)
{
	HydraRender* newRend = new HydraRender();

	BaseClone(this, newRend, remap);
	return newRend;
}


IOResult HydraRender::Save(ISave *isave)
{
	return IO_OK; 
}


IOResult HydraRender::Load(ILoad *iload)
{
	return IO_OK;
}

RefResult HydraRender::NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID,  RefMessage message) {

	return REF_DONTCARE;
}


HydraRenderParams::HydraRenderParams()
{
	SetDefaults();

	envMap = NULL;
	atmos = NULL;
	rendType = RENDTYPE_NORMAL;
	nMinx = 0;
	nMiny = 0;
	nMaxx = 0;
	nMaxy = 0;
	nNumDefLights = 0;
	scrDUV = Point2(0.0f, 0.0f);
	pDefaultLights = NULL;
	pFrp = NULL;
	bVideoColorCheck = 0;
	bForce2Sided = FALSE;
	bRenderHidden = FALSE;
	bSuperBlack = FALSE;
	bRenderFields = FALSE;
	bNetRender = FALSE;

	renderer = NULL;
	projType = PROJ_PERSPECTIVE;
	devWidth = 0;
	devHeight = 0;
	xscale = 0;
	yscale = 0;
	xc = 0;
	yc = 0;
	antialias = FALSE;
	nearRange = 0;
	farRange = 0;
	devAspect = 0;
	frameDur = 0;
	time = 0;
	wireMode = FALSE;
	inMtlEdit = FALSE;
	fieldRender = FALSE;
	first_field = FALSE;
	field_order = FALSE;
	objMotBlur = FALSE;
	nBlurFrames = 0;
}

void HydraRenderParams::SetDefaults()
{
}


#define VIEW_DEFAULT_WIDTH ((float)400.0)

void HydraRenderParams::ComputeViewParams(const ViewParams&vp)
{
}


Point3 HydraRenderParams::RayDirection(float sx, float sy)
{
	Point3 p;
	p.x = -(sx-xc)/xscale; 
	p.y = -(sy-yc)/yscale; 
	p.z = -1.0f;
	return Normalize(p);
}


int HydraRenderParams::NumRenderInstances()
{

  return 0;
}

RenderInstance* HydraRenderParams::GetRenderInstance(int i)
{

	return NULL;
}


Point2 MyView::ViewToScreen(Point3 p)
{
	return pRendParams->MapToScreen(p);
}



