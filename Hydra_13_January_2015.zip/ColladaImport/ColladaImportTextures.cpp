#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>

#include <direct.h> // getcwd in WINDOWS

//#include <boost/filesystem.hpp>
//#include <boost/filesystem/path.hpp>
//#include <boost/filesystem/operations.hpp>
#include <ctime>

//#include <il/il.h>
//#include <il/ilu.h>
//#pragma comment(lib, "devil.lib")
//#pragma comment(lib, "ilu.lib")

#include <FreeImage.h>
#pragma comment(lib, "FreeImage.lib")

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportTextures(ObjectDataList* pOut_list)
{
  ObjectDataList& plist = *pOut_list;
  plist.clear();


  TiXmlElement* images_lib = m_root->FirstChildElement("library_images");
  if(images_lib)
  {

    TiXmlNode* nextImageInLib = 0;
    for(TiXmlNode* nextImageInLib = images_lib->FirstChild("image"); nextImageInLib!=0;
                   nextImageInLib = images_lib->IterateChildren("image", nextImageInLib))
    {
      ColladaParser::ObjectData imageParams;
      // <image id="__Metal_Corrogated_Shiny_1-image" name="__Metal_Corrogated_Shiny_1-image" format="JPEG" height=640 width=480 depth=1>
      // name: imageParams["COLLADA_name"] = nextImageInLib->ToElement()->Attribute("name");
      // optional. format: imageParams["COLLADA_format"] = nextImageInLib->ToElement()->Attribute("format");
      // optional. height: imageParams["COLLADA_height"] = nextImageInLib->ToElement()->Attribute("height");
      // optional. width: imageParams["COLLADA_width"] = nextImageInLib->ToElement()->Attribute("width");
      // optional. depth: imageParams["COLLADA_depth"] = nextImageInLib->ToElement()->Attribute("depth");
      imageParams["id"] = nextImageInLib->ToElement()->Attribute("id");
      plist[ imageParams["id"] ] = imageParams;

    }

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      string imageId = p->second["id"];
      TiXmlElement* pImageElement = FindElemByAttribute(images_lib, "image", "id", imageId);

      if(pImageElement == 0)
        RUN_TIME_ERROR("Image with id " + imageId + "not found in COLLADA XML");

      for(TiXmlNode* pParam = pImageElement->FirstChildElement(); pParam != 0; pParam = pImageElement->IterateChildren(pParam))
      {
        TiXmlElement* pElem = pParam->ToElement();
        p->second[pElem->ValueStr()] = pElem->GetText();
      }
    }

  }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int LoadTextureToRender(const std::wstring& a_fileName, IGraphicsEngine* pRender, EmptyDataConverter* pConverter)
{
  const wchar_t* filename = a_fileName.c_str();

  FREE_IMAGE_FORMAT fif = FIF_UNKNOWN; // image format
  FIBITMAP *dib(NULL), *converted(NULL);           
  BYTE* bits(NULL);                    // pointer to the image data
  unsigned int width(0), height(0);    //image width and height
 


  //check the file signature and deduce its format
  //if still unknown, try to guess the file format from the file extension
  //
  fif = FreeImage_GetFileTypeU(filename, 0);
  if(fif == FIF_UNKNOWN) 
    fif = FreeImage_GetFIFFromFilenameU(filename);

  if(fif == FIF_UNKNOWN)
  {
    std::wcerr << L"FreeImage failed to guess file image format: " << a_fileName.c_str() << std::endl;
    return INVALID_TEXTURE;
  }

  //check that the plugin has reading capabilities and load the file
  //
  if(FreeImage_FIFSupportsReading(fif))
    dib = FreeImage_LoadU(fif, filename);
  else
  {
    std::wcerr << L"FreeImage does not support file image format: " << a_fileName.c_str() << std::endl;
    return INVALID_TEXTURE;
  }

  bool invertY = false; //(fif != FIF_BMP);

  if(!dib)
  {
    std::wcerr << L"FreeImage failed to load image: " << a_fileName.c_str() << std::endl;
    return INVALID_TEXTURE;
  }

  unsigned int bitsPerPixel = FreeImage_GetBPP(dib);

  int bytesPerPixel = 4;          
  if(bitsPerPixel <= 32) // bits per pixel
  {
    converted = FreeImage_ConvertTo32Bits(dib);
    bytesPerPixel = 4;
  }
  else
  {
    converted = FreeImage_ConvertToRGBF(dib);
    bytesPerPixel = 16;
  }

  bits   = FreeImage_GetBits(converted);
  width  = FreeImage_GetWidth(converted);
  height = FreeImage_GetHeight(converted);

  if((bits == 0) || (width == 0) || (height == 0))
  {
    std::wcerr << L"FreeImage failed for undefined reason, file : " << a_fileName.c_str() << std::endl;
    return INVALID_TEXTURE;
  }

  int size = width * height * bytesPerPixel;
  unsigned char* data = new unsigned char[size];

  // convert to OpenGL layout ...
  //
  if(bitsPerPixel <= 32)
  {
    for(int y=0; y<height; y++)
    {
      int lineOffset1 = y*width;
      int lineOffset2 = y*width;
      if(invertY)
        lineOffset2 = (height-y-1)*width;

      for(int x = 0;x<width; x++)
      { 
        int offset1 = lineOffset1 + x;
        int offset2 = lineOffset2 + x;

        data[4*offset1+0] = bits[4*offset2+2];
        data[4*offset1+1] = bits[4*offset2+1];
        data[4*offset1+2] = bits[4*offset2+0];
        data[4*offset1+3] = bits[4*offset2+3];
      }
    }
  }
  else
  {
    float* fbits = (float*)bits;
    float* fdata = (float*)data;

    for(int i=0;i<width*height;i++)
    {
      fdata[4*i+0] = fbits[3*i+0];
      fdata[4*i+1] = fbits[3*i+1];
      fdata[4*i+2] = fbits[3*i+2];
      fdata[4*i+3] = 0.0f;
    }

  }

  FreeImage_Unload(converted);
  FreeImage_Unload(dib);

  int w = width;
  int h = height;

  if(pConverter!=NULL)
    pConverter->ConvertData(data, w, h);

  int id = pRender->AddTexture(data, w, h, bytesPerPixel); //  bpp can be used as format
  delete [] data;

  return id;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void SaveImageToFile(const std::string& a_fileName, int w, int h, unsigned int* data)
{
  FIBITMAP* dib;

  std::cerr << "inside SaveImageToFile" << std::endl;
  
  //dib = FreeImage_ConvertFromRawBits((BYTE*)data, w, h, w*sizeof(int), 32, FI_RGBA_BLUE_MASK, FI_RGBA_GREEN_MASK, FI_RGBA_RED_MASK, FALSE);

  dib = FreeImage_Allocate(w, h, 32);
  BYTE* bits = FreeImage_GetBits(dib);
  BYTE* data2 = (BYTE*)data;
  for(int i=0;i<w*h;i++)
  {
    bits[4*i+0] = data2[4*i+2];
    bits[4*i+1] = data2[4*i+1];
    bits[4*i+2] = data2[4*i+0];
    bits[4*i+3] = data2[4*i+3];
  }

  if(!FreeImage_Save(FIF_PNG, dib, a_fileName.c_str()) )
    std::cerr << "SaveImageToFile(): FreeImage_Save error on " << a_fileName.c_str() << std::endl;

  FreeImage_Unload(dib);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void SaveHDRImageToFileTIFF(const std::string& a_fileName, int w, int h, float4* data)
{
  FIBITMAP* dib = FreeImage_AllocateT(FIT_RGBAF, w, h);
  
  BYTE* bits = FreeImage_GetBits(dib);
  memcpy(bits, data, sizeof(float4)*w*h);

  if(!FreeImage_Save(FIF_TIFF, dib, a_fileName.c_str()) )
    std::cerr << "SaveImageToFile(): FreeImage_Save error " << std::endl;

  FreeImage_Unload(dib);
}

void FreeImageErrorHandler(FREE_IMAGE_FORMAT fif, const char *message) 
{
  printf("\n***\n");
  printf(message);
  printf("\n***\n");
}

void SaveHDRImageToFileHDR(const std::string& a_fileName, int w, int h, float4* data)
{
  std::vector<float3> tempData(w*h);
  for(int i=0;i<w*h;i++)
    tempData[i] = to_float3(data[i]);

  FIBITMAP* dib = FreeImage_AllocateT(FIT_RGBF, w, h);
  
  BYTE* bits = FreeImage_GetBits(dib);
  memcpy(bits, &tempData[0], sizeof(float3)*w*h);

  FreeImage_SetOutputMessage(FreeImageErrorHandler);

  if(!FreeImage_Save(FIF_HDR, dib, a_fileName.c_str()) )
    std::cerr << "SaveImageToFile(): FreeImage_Save error " << std::endl;

  FreeImage_Unload(dib);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void AlphaFromRedChannel::ConvertData(void* a_data, int w, int h)
{
  unsigned char* data = (unsigned char*)a_data;

  for(int i=0;i<w*h;i++)
    data[i*4+3] = data[i*4+0];
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaTextureImporter::GetPathToFolder(const std::string& pathToFile)
{
  int symbolsCount = 0;
  for(int i=pathToFile.size()-1;i>=0;i--)
  {
    if(pathToFile[i] == '\\' || pathToFile[i] == '/')
      break;
    symbolsCount++;
  }

  return pathToFile.substr(0,pathToFile.size() - symbolsCount);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaTextureImporter::ColladaTextureImporter() : m_chdirResult(0), m_pathWasChanged(false)
{

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaTextureImporter::~ColladaTextureImporter()
{
  ResetCurrentPath();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaTextureImporter::GetAbsolutePath(const std::string& a_path)
{
  if(a_path == "")
    return "";

  std::string abs_path_str = "";
  std::string path = a_path;

  if(path.size() > 8 && path.substr(0,8) == "file:///")
    path = path.substr(8, path.size());

  else if(path.size() > 7 && path.substr(0,7) == "file://")
    path = path.substr(7, path.size());

  for(int i=0;i<path.size();i++)
  {
    if(path[i] == '\\')
      path[i] = '/';
  }

  char buffer[4096];
  GetFullPathNameA(path.c_str(), 4096, buffer, NULL);
  return std::string(buffer);

  //boost::filesystem::path bst_path(path);
  //boost::filesystem::path abs_path = system_complete(bst_path);
  //return abs_path.string();
}

#include <codecvt>

std::wstring utf8_to_wstring(const std::string& str)
{
  std::wstring_convert<std::codecvt_utf8<wchar_t>> myconv;
  return myconv.from_bytes(str);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int  ColladaTextureImporter::AddTextureIfExists(const std::string& a_path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter, bool muteWarning)
{
  WHashMapI& cache = m_cache;
  std::string path = a_path;

  int resId = INVALID_TEXTURE;

  if(path != "")
  {
    std::string abs_path_str = GetAbsolutePath(path);
    std::wstring abs_path2   = utf8_to_wstring(abs_path_str);

    if (cache.find(abs_path2) == cache.end()) // do not load this texture again if we done this once
    {
      bool fileExists = false;
      std::fstream fin;
      fin.open(abs_path2.c_str(), std::ios::in);
      if( fin.is_open() )
        fileExists=true;
      fin.close();

      int id = INVALID_TEXTURE;
      if(fileExists)
        id = LoadTextureToRender(abs_path2, pRender, pConverter);
      else if(!muteWarning)
        std::wcerr << L"texture " + abs_path2 + L" does not exists!" << std::endl;

      cache[abs_path2] = id;
      resId = id;
    }
    else
      resId = cache[abs_path2];
  }

  if(resId != INVALID_TEXTURE && m_ptps != NULL) // save input path
    (*m_ptps)[a_path] = resId;

  return resId;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaTextureImporter::SetCurrentPathToMainFile(const std::string& pathToXML)
{
  char oldPath[256];
  getcwd(oldPath, 256);

  m_pathToXMLFolder = GetPathToFolder(pathToXML);
  m_chdirResult     = chdir(m_pathToXMLFolder.c_str());
  m_pathToXML       = pathToXML;
  m_oldPath         = std::string(oldPath);

  m_pathWasChanged = true;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaTextureImporter::ResetCurrentPath()
{
  if(m_pathWasChanged == false)
    return;

  if(m_chdirResult==0)
  {
    if(chdir(m_oldPath.c_str())!=0)
      std::cerr << "can't chdir back '.exe' dir, crap! perhaps some textures will not be loaded" << std::endl;
    else
      m_pathWasChanged = false;
  }
  //else
    //std::cerr << "can't chdir; perhaps some textures were not loaded" << std::endl;
}


size_t last_write_time(const std::string& a_fileName)
{
  typedef unsigned long long int uint64; 
  HANDLE hFile = CreateFileA(a_fileName.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

  FILETIME creationTimeData, lastAccessTimeData, lastWriteTimeData;

  if(!GetFileTime(hFile, &creationTimeData, &lastAccessTimeData, &lastWriteTimeData))
    return 0;

  CloseHandle(hFile);

  uint64 l = creationTimeData.dwLowDateTime;
  uint64 h = creationTimeData.dwHighDateTime;

  return size_t((h << 32) | l);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
bool ITextureImporter::HeightFileHasChanged(const std::string& a_fileName, const std::string& a_fileName2)
{
  //boost::filesystem::path p1(GetAbsolutePath(a_fileName));
  //boost::filesystem::path p2(GetAbsolutePath(a_fileName2));

  std::time_t t1 = last_write_time(a_fileName);
  std::time_t t2 = last_write_time(a_fileName2);

  //if ( boost::filesystem::exists(p1) && boost::filesystem::exists(p1) )
  //{
    //std::time_t t1 = boost::filesystem::last_write_time(p1);
    //std::time_t t2 = boost::filesystem::last_write_time(p2);

    return (t1 > t2) || (t1 == 0) || (t2 == 0);
  //}

  //return false;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int ColladaTextureImporter::GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex, float bumpAmt, float blurRadius, float blurSigma, bool invHeight)
{
  HashMapI& cache = m_normalMapCache;

  std::string keyPath = pathToHeightTex + ToString(int(invHeight)) + ToString(bumpAmt) + ToString(blurRadius) + ToString(blurSigma);

  if(cache.find(keyPath) != cache.end())
  {
    return cache[keyPath];
  }
  else
  {
    std::cerr << "WARNING, missed normalmap for texture " << pathToHeightTex.c_str() << std::endl;
    int id = this->CalculateNormalMapFromDisplacement(heightTexId, pRender, keyPath, bumpAmt, blurRadius, blurSigma, invHeight);
    cache[keyPath] = id;
    return id;
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int ColladaTextureImporter::CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const string& pathToHeightTex, float bumpAmt, float blurRadius, float blurSigma, bool invHeight)
{
  std::string pathWithoutExt   = pathToHeightTex.substr(0, pathToHeightTex.size()-4);
  std::string oldNormalmapPath = pathWithoutExt + "_normalmap_calculated.png";

  // for a while ... because parameter 'invert height' could chage!!!!!
  //
  bool heightDataHasChanged = true; //!HeightFileHasChanged(oldNormalmapPath,pathToHeightTex);

  int idCachedTex = this->AddTextureIfExists(oldNormalmapPath, pRender, NULL, true);
  if(idCachedTex!=INVALID_TEXTURE && !heightDataHasChanged)
  {
    std::cerr << "normalmap was loaded from normalmap cache" << std::endl;
    return idCachedTex;
  }

  typedef unsigned char uchar;

  uint w,h;
  pRender->GetTextureDesc(heightTexId, &w, &h, NULL);

  const vec4ub* height = (const vec4ub*)pRender->GetTextureDataPtr(heightTexId);
  
  std::vector<vec4ub> normalmapData(w*h);
  //std::vector<float3> normalsPreFinal(w*h);

  HDRImage heightImage(w,h,1,NULL);
  HDRImage normslaImage(w,h,4,NULL);

  std::vector<float>& heightDataf = heightImage.data(); //(w*h);

  // �������E�����
  //
  for(auto i=0;i<heightDataf.size(); i++)
    heightDataf[i] = float(height[i].x);

  //heightImage.gaussBlur(3, 2.0f);

  // ������ �M������
  //
  #pragma omp parallel for
  for (int y = 1; y < h-1; y++)
  {
    int offsetY = y*w;
    int offsetY2 = (h-y)*w;
    int offsetYPlusOne  = (y+1)*w;
    int offsetYMinusOne = (y-1)*w;

    for (uint x = 1; x < w-1; x++)
    {
      float diff[8];

      diff[0] = heightDataf[offsetY + x] - heightDataf[offsetYMinusOne + x - 1];
      diff[1] = heightDataf[offsetY + x] - heightDataf[offsetYMinusOne + x];
      diff[2] = heightDataf[offsetY + x] - heightDataf[offsetYMinusOne + x + 1];
      diff[3] = heightDataf[offsetY + x] - heightDataf[offsetY + x - 1];
      diff[4] = heightDataf[offsetY + x] - heightDataf[offsetY + x + 1];
      diff[5] = heightDataf[offsetY + x] - heightDataf[offsetYPlusOne + x - 1];
      diff[6] = heightDataf[offsetY + x] - heightDataf[offsetYPlusOne + x];
      diff[7] = heightDataf[offsetY + x] - heightDataf[offsetYPlusOne + x + 1];

      if(!invHeight)
      {
        for(int i=0;i<8;i++)
          diff[i] *= -1.0f;
      }

      float scale = 250.0f*clamp(1.0f - bumpAmt, 0.1f, 1.0f);

      float3 v38[8];
      v38[0] = float3(-diff[0], -diff[0], scale);
      v38[1] = float3(0.f, -diff[1], scale);
      v38[2] = float3(diff[2], -diff[2], scale);
      v38[3] = float3(-diff[3], 0.f, scale);
      v38[4] = float3(diff[4], 0.f, scale);
      v38[5] = float3(-diff[5], diff[5], scale);
      v38[6] = float3(0.f, diff[6], scale);
      v38[7] = float3(diff[7], diff[7], scale);

      float3 res(0,0,0);
      for(int i=0;i<8;i++)
        res += v38[i];

      res = res*(1.0f/8.0f);

      res.x *= -1.0f;
      res.y *= -1.0f;
      res.z = abs(res.z); //1.0f;

      res = normalize(res);

      normslaImage.data()[offsetY*4 + x*4 + 0] = res.x;
      normslaImage.data()[offsetY*4 + x*4 + 1] = res.y;
      normslaImage.data()[offsetY*4 + x*4 + 2] = res.z;
      normslaImage.data()[offsetY*4 + x*4 + 3] = 0.0f;
    }
  }

  if(int(blurRadius) > 0 && blurSigma > 0.0f)
    normslaImage.gaussBlur(int(blurRadius), blurSigma);

  for (int y = 1; y < h-1; y++)
  {
    int offsetY = y*w;
    
    for (int x = 1; x < w-1; x++)
    {
      float3 cr, res;

      res.x = normslaImage.data()[offsetY*4 + x*4 + 0];
      res.y = normslaImage.data()[offsetY*4 + x*4 + 1];
      res.z = normslaImage.data()[offsetY*4 + x*4 + 2];

      cr.x = 0.5f*res.x + 0.5f;
      cr.y = 0.5f*res.y + 0.5f;
      cr.z = res.z;

      normalmapData[offsetY + x] = vec4ub( uchar(cr.x*255.0f), uchar(cr.y*255.0f), uchar(cr.z*255.0f), 255);
    }
  }

  // borders
  //

  for(int x=0;x<w;x++)
  {
    normalmapData[0*w+x]     = normalmapData[1*w+x];
    normalmapData[(h-1)*w+x] = normalmapData[(h-2)*w+x];
  }

  for(int y=0;y<h;y++)
  {
    normalmapData[y*w+0]   = normalmapData[y*w+1];
    normalmapData[y*w+w-1] = normalmapData[y*w+w-2];
  }

  int id = pRender->AddTexture(&normalmapData[0], w, h);

  // save image
  //
  // std::string path = GetAbsolutePath(oldNormalmapPath);
  // SaveImageToFile(path.c_str(),w,h, (unsigned int*)&normalmapData[0]);
  
  std::cerr << "normalmap was calculated" << std::endl;

  return id;
}



