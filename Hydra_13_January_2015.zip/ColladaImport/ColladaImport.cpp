#include "ColladaImport.h"
#include <algorithm>

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;

template<>
void NumericParser::ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult, int a_size)
{
  const char* str = in_str;

  pResult->resize(a_size);
  int i=0;
  while(*str != '\0' && i < pResult->size())
  {
    (*pResult)[i] = NextFloat(str);
    i++;
  }
}

template<>
void NumericParser::ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult)
{
  const char* str = in_str;

  while(*str != '\0')
    pResult->push_back(NextFloat(str));
}

template<>
void NumericParser::ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult)
{
  register const char* str = in_str;

  while(*str != '\0')
    pResult->push_back(NextInt(str));
}

template<>
void NumericParser::ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult, int a_size)
{
  const char* str = in_str;

  pResult->resize(a_size);
  int i=0;
  while(*str != '\0' && i < pResult->size())
  {
    (*pResult)[i] = NextInt(str);
    i++;
  }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <>
float STR_CNV::StringTo<float>(const std::string& str)
{
  float res;
  if(sscanf(str.c_str(), "%f",&res) != 1)
    return 0.0f;
  return res;
}

template <>
int STR_CNV::StringTo<int>(const std::string& str)
{
  int res;
  if(sscanf(str.c_str(), "%d",&res) != 1)
    return 0;
  return res;
}

template <>
float2 STR_CNV::StringTo<float2>(const std::string& str)
{
  float2 res;
  if(sscanf(str.c_str(), "%f %f",&res.x, &res.y) != 2)
    return float2(0,0);
  return res;
}

template <>
float3 STR_CNV::StringTo<float3>(const std::string& str)
{
  float3 res;
  if(sscanf(str.c_str(), "%f %f %f", &res.x, &res.y, &res.z) != 3)
    return float3(0,0,0);
  return res;
}

template <>
float4 STR_CNV::StringTo<float4>(const std::string& str)
{
  float4 res;
  if(sscanf(str.c_str(), "%f %f %f %f", &res.x, &res.y, &res.z, &res.w) != 4)
    return float4(0,0,0,0);
  return res;
}

template <>
Matrix4x4f STR_CNV::StringTo<Matrix4x4f>(const std::string& str)
{
  Matrix4x4f r;
  if(sscanf(str.c_str(),"%f %f %f %f \
                         %f %f %f %f \
                         %f %f %f %f \
                         %f %f %f %f",
                         &r.L[0], &r.L[1], &r.L[2], &r.L[3],
                         &r.L[4], &r.L[5], &r.L[6], &r.L[7],
                         &r.L[8], &r.L[9], &r.L[10], &r.L[11],
                         &r.L[12], &r.L[13], &r.L[14], &r.L[15]) != 16)
    RUN_TIME_ERROR("Can not convert string to Matrix4x4f");
  return r;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaParser::ColladaParser()
{
  m_root = NULL;

  m_pHydraMatProfile = NULL;
  m_pExporterSpecific = NULL;

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
ColladaParser::~ColladaParser()
{
  delete m_pHydraMatProfile;  m_pHydraMatProfile = NULL;
  delete m_pExporterSpecific; m_pExporterSpecific = NULL;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::CreateExporterProfiles(TiXmlNode* root)
{
  delete m_pExporterSpecific; m_pExporterSpecific = NULL;

  TiXmlNode* node = GetNode(root, "asset", "contributor", "authoring_tool");
  if(node != NULL)
  {
    std::string tool = node->ToElement()->GetText();
    if(tool.find("Blender") != string::npos || tool.find("blender") != string::npos)
    {
      m_pExporterSpecific = new BlenderExporter;
      return;
    }
    else if(tool.find("OpenCOLLADA") != string::npos || tool.find("openCOLLADA") != string::npos)
    {
      m_pExporterSpecific = new OpenColladaExporter;
      //m_pExporterSpecific = new MaxStandartExporter;
      return;
    }
  }

  m_pExporterSpecific = new MaxStandartExporter;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
bool ColladaParser::LoadXMLFromMem(const std::string& a_xmlData)
{
  m_doc.Parse(a_xmlData.c_str(), NULL, TIXML_ENCODING_UTF8);
  if(m_doc.Error())
    return false;

  m_lastXMLPath = "memory";
  return ParseCurrXML();
}


void testRussianSymbols()
{
  TiXmlDocument doc;

  doc.LoadFile("D:\\temp\\test.xml", TIXML_ENCODING_UTF8);
  if (doc.Error())
  {
    std::cerr << "can't load rus xml" << std::endl;
    return;
  }

  TiXmlHandle docHandle(&doc);
  TiXmlElement* root = docHandle.FirstChild("COLLADA").Element();

  std::string tex1 = GetText(root, "library_materials", "texture1");
  std::string tex2 = GetText(root, "library_materials", "texture2");

  TiXmlNode* pNode = root->FirstChild("library_materials");
  std::string a_prefix = "";

  for (TiXmlNode* p = pNode->FirstChild(); p != NULL; p = pNode->IterateChildren(p))
  {
    TiXmlElement* elem = p->ToElement();
    if (elem != NULL)
    {
      std::string newPrefix = a_prefix + "_" + p->ValueStr();
      const char* pText = elem->GetText();

      std::cerr << pText << std::endl;
    }
  }


}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
bool ColladaParser::LoadXML(const std::string& a_fileName)
{
  //testRussianSymbols();

  m_doc.LoadFile(a_fileName, TIXML_ENCODING_UTF8);
  if(m_doc.Error())
    return false;

  m_lastXMLPath = a_fileName;
  return ParseCurrXML(); // m_doc
}

bool ColladaParser::ParseCurrXML()
{
  TiXmlHandle docHandle(&m_doc);
  TiXmlElement* root = m_root = docHandle.FirstChild( "COLLADA" ).Element();


  TiXmlElement* node = NULL;

  if (root != NULL)
  {
    if (root->Attribute("version") != NULL)
      cout << "COLLADA version: " << root->Attribute("version") << endl;

    CreateExporterProfiles(root);

    if (root->FirstChildElement("asset") != NULL)
      node = root->FirstChildElement("asset")->FirstChildElement("unit");
  }

  m_globalTransform.Identity();

  DEBUG_PRINT("initial matrix: \n", m_globalTransform);

  if(node)
  {
    float scale = StringTo<float>(node->Attribute("meter"));
    Matrix4x4f mScale;
    mScale.SetScale(float3(scale, scale, scale));

    DEBUG_PRINT("scale matrix: \n", mScale);

    m_globalTransform = m_globalTransform*mScale;

    DEBUG_PRINT("transform(1) matrix: \n", m_globalTransform);
  }

  if (root != NULL)
  {
    if (root->FirstChildElement("asset") != NULL)
      node = root->FirstChildElement("asset")->FirstChildElement("up_axis");
  }

  if(node)
  {
    // in RTE like in OpenGL Up axis is y; and z aim to you from the screen.
    //

    Matrix4x4f mRot;

    string upAxis = node->GetText();
    if(upAxis == "Y_UP")
      mRot.Identity(); // ���� ��� ��. X ������; Y �����; Z �� ��� �� ������.
    else if(upAxis == "Z_UP")
    {
      mRot = Matrix4x4f(1,0,0,0,
        0,0,1,0,
        0,-1,0,0,
        0,0,0,1);
    }
    else if(upAxis == "X_UP")
    {
      // �� ��������� ���
      //
      mRot = Matrix4x4f(0,1,0,0,
        -1,0,0,0,
        0,0,1,0,
        0,0,0,1);
    }
    else
      RUN_TIME_ERROR("incorrect UP axis in asset->up_axis node");


    m_globalTransform = m_globalTransform*mRot;
  }

  return true;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::LoadXMLAndGetFirstElement(const std::string& a_profilePath, const std::string& a_str)
{
  if(a_profilePath=="")
    return NULL;

  m_doc.LoadFile(a_profilePath, TIXML_ENCODING_UTF8);

  if(m_doc.Error())
  {
    fprintf(stderr, "Can't load collada profile %s \n", (std::string(m_doc.ErrorDesc()) + " " + a_profilePath).c_str());
    return NULL;
  }

  TiXmlHandle docHandle(&m_doc);
  m_root = docHandle.FirstChild("COLLADA").Element();
  return m_root->FirstChildElement(a_str);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::GetElement(const std::string& a_name)
{
  if(m_root)
    return m_root->FirstChildElement(a_name);
  return NULL;
}

void CreateDefaultHydraProfile(const std::string& a_profilePath)
{
  std::ofstream fout(a_profilePath.c_str(), std::ios_base::out | std::ios_base::trunc);

  if(!fout.is_open())
  {
    std::cerr << "can't open file for writing: " << a_profilePath.c_str() << std::endl;
    return;
  }

  fout << "<?xml version=\"1.0\" encoding=\"utf-8\"?> " << std::endl;
  fout << "<COLLADA profile=\"HydraProfile\"> " << std::endl;
  fout << std::endl;

  fout << "  <library_materials>" << std::endl;
  fout << "  </library_materials>" << std::endl;
  fout << std::endl;

  fout << "  <library_lights>" << std::endl;
  fout << "  </library_lights>" << std::endl;
  fout << std::endl;

  fout << "  <library_cameras>" << std::endl;
  fout << "  </library_cameras>" << std::endl;
  fout << std::endl;

  fout << "  <library_geometry>" << std::endl;
  fout << "  </library_geometry>" << std::endl;
  fout << std::endl;

  fout << "</COLLADA>" << std::endl;

  fout.flush();
  fout.close();
}


HydraScene g_lastScene;
HydraScene* LastImportedScene() {return &g_lastScene;}

std::string parentPath(const std::string& a_path)
{
  size_t posLast = a_path.size() - 1;
  size_t posBreak = 0;

  for(size_t i = posLast; i >= 0; i--)
  {
    if(a_path[i] == '\\' || a_path[i] == '/')
    {
      posBreak = i;
      break;
    }
  }

  return a_path.substr(0, posBreak);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportSceneFromCollada(IGraphicsEngine* pRender, const std::string a_fileName, Camera* camera, const Matrix4x4f& a_mat, const std::string a_profilePath)
{
  g_lastScene.clear();

  g_lastScene.scenefile   = a_fileName;
  g_lastScene.scenefolder = parentPath(a_fileName);

  cerr << "importing   = " + a_fileName << endl;
  cerr << "scenefolder = " + g_lastScene.scenefolder << endl;

  ColladaParser colladaParser;

  colladaParser.LoadXML(a_fileName);
  Matrix4x4f mGlobalTransform = a_mat*colladaParser.GetTransformMatrix();
  g_lastScene.globalTransformMatrix = mGlobalTransform;

  ColladaParser::ObjectDataList data;

  // load collada profile
  //
  ColladaParser profileLoader;

  std::string profilePath = a_profilePath;

  if(profilePath == "")
    profilePath = a_fileName + ".hydra_profile.xml";

  if(!profileLoader.LoadXML(profilePath))
  {
    CreateDefaultHydraProfile(profilePath);
    if(!profileLoader.LoadXML(profilePath))
      RUN_TIME_ERROR("can't load or create default hydra profile, perhaps your scene folder is read only");
  }


  TiXmlElement* materials_lib = profileLoader.GetElement("library_materials");
  TiXmlElement* lights_lib    = profileLoader.GetElement("library_lights");
  TiXmlElement* aliases_mat   = profileLoader.GetElement("material_alias_groups");

  ITextureImporter* pTexImporter  = new ColladaTextureImporter;
  IMaterialImporter* pMatImporter = CreateMaterialImporter(colladaParser.GetRoot());

  //std::cerr << "colladaParser.GetLastParsedXML() = " << colladaParser.GetLastParsedXML().c_str() << std::endl; 
  //std::cerr << "a_fileName = " << a_fileName.c_str() << std::endl;

  pTexImporter->SetCurrentPathToMainFile(a_fileName);
  pTexImporter->SetTexPathStorage(&g_lastScene.texpaths); // all texture paths will be saved here

  // import core
  //

  GeometryStorage geomStorage(colladaParser.m_pExporterSpecific);

  cout << "Importing materials..." << endl;
  colladaParser.ImportMaterials(&data);

  cout << "after colladaParser.ImportMaterials(&data)" << endl;

  ReplaceMaterialsWithProfile(data, materials_lib, EmptyTransform);
  
  cout << "after ReplaceMaterialsWithProfile" << endl;

  DoGlobalFixesOnMaterialParams(data, materials_lib);

  cout << "after DoGlobalFixesOnMaterialParams" << endl;

  ReplaceMaterialsWithAliases(pRender, pTexImporter, data, aliases_mat);

  cout << "after ReplaceMaterialsWithAliases" << endl;

  ImportHydraMaterialsFromCollada(pRender, data, geomStorage, pTexImporter, pMatImporter, g_lastScene.materials);

  InstList instances;
  cout << "Importing geometry..." << endl;
  colladaParser.ImportGeometry(&data, &geomStorage.geom_data, &geomStorage.geom_indices, &instances);
  ImportGeometryFromCollada(pRender, data, geomStorage, mGlobalTransform, instances);

  cout << "Importing lights..." << endl;
  colladaParser.ImportLights(&data);
  ReplaceLightsWithProfile(data, lights_lib);
  ImportLightsFromCollada(pRender, data, mGlobalTransform, pTexImporter, g_lastScene.lights);

  cout << "Importing cameras..." << endl;
  colladaParser.ImportCameras(&data);
  //ReplaceCamerasWithProfile();
  ImportCamerasFromCollada(pRender, data, camera, mGlobalTransform, g_lastScene.cameras, g_lastScene.m_cameras);
  // \\

  pTexImporter->ResetCurrentPath();

  delete pTexImporter; pTexImporter = NULL;
  delete pMatImporter; pMatImporter = NULL;

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaParser::FindTexturePath(const ObjectDataList& list, const std::string& key, const std::string& val, const std::string& second_val) const
{
  for(ObjectDataList::const_iterator p = list.begin(); p!= list.end(); ++p)
  {
    ObjectData::const_iterator p2 = p->second.find(key);
    if(p2 != p->second.end() && p2->second == val)
    {
       ObjectData::const_iterator p3 = p->second.find(second_val);
       if(p3 != p->second.end())
         return p3->second;
       else
         return "";
    }
  }

  return "";
}



HydraMaterial ReadSingleHydraMaterialFromXMLNode(TiXmlElement* matElem, TiXmlElement* aliases_mat, 
                                                 IGraphicsEngine* pRender, ITextureImporter* pTexInporter, std::string& a_outName, int* pOutId, HashMapImportParams* pPapams)
{
  if(matElem == NULL)
  {
    a_outName = "";
    return HydraMaterial();
  }

  std::string name  =  "";
  std::string maxId = "0";

  if(matElem->Attribute("id") != NULL)
    name = matElem->Attribute("id");
  else if(matElem->Attribute("name") != NULL)
    name = matElem->Attribute("name");

  if (matElem->Attribute("maxid") != NULL)
    maxId = matElem->Attribute("maxid");

  a_outName = name;
  if (pOutId != NULL)
    (*pOutId) = atoi(maxId.c_str());

  TiXmlElement* pMaterialModel = matElem->FirstChildElement();

  if(STR_CNV::ToLowerCase(pMaterialModel->ValueStr()) == "hydra")
  {
    // ����� ������ ���....
    //
    ColladaParser::ObjectData params;
    ColladaParser::ObjectDataList temp; 

    params["name"] = name;   // holly shit 
    temp[name]     = params; // holly shit
    
    ColladaParser::ParseHydraMaterial(temp.begin()->second, pMaterialModel);

    if(aliases_mat != NULL)
      ReplaceMaterialsWithAliases(pRender, pTexInporter, temp, aliases_mat);

    return HydraMaterialFromStringMap(temp.begin(), pRender, pTexInporter, pPapams);
  }
  else
  {
    a_outName = "";
    fprintf(stderr, "Warning: Hydra profile has unknown material model %s \n", pMaterialModel->ValueStr().c_str());
    return HydraMaterial();
  }

}


RAYTR::Light SingleHydraLightFromXMLNode(TiXmlElement* lightElem, IGraphicsEngine* pRender, ITextureImporter* pTexImporter, const Matrix4x4f a_globalTransform, std::string& a_outName)
{
  if(lightElem == NULL)
  {
    a_outName = "";
    return RAYTR::Light();
  }

  std::string name =  "";

  if(lightElem->Attribute("id") != NULL)
    name = lightElem->Attribute("id");
  else if(lightElem->Attribute("name") != NULL)
    name = lightElem->Attribute("name");

  a_outName = name;

  ColladaParser::ObjectData params;
  ColladaParser::ObjectDataList temp; // ����� ������ ���....
  temp[name] = params;
  ColladaParser::ParseHydraLight(lightElem, &temp.begin()->second);

  return HydraLightFromStringMap(pRender, temp.begin(), a_globalTransform, pTexImporter);
}

