#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"
#include "Camera.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"
using std::string;

#include "HydraProfiles.h"

#include <sstream>
#include <stdlib.h>
#include <math.h>


struct MaterialTextureImportMaxParams
{

  MaterialTextureImportMaxParams(): uTiling(1.0f), vTiling(1.0f), uOffset(0.0f), vOffset(0.0f) 
  {
    for(int i=0;i<HydraMaterial::TEX_SLOTS_NUMBER;i++)
    {
      texSlotMatrices[i].Identity();
      hasNonIdentityTexMatrix[i] = false;
    }
  } 

  float uTiling;
  float vTiling;
  float uOffset;
  float vOffset;

  Matrix4x4f texSlotMatrices[HydraMaterial::TEX_SLOTS_NUMBER];
  bool       hasNonIdentityTexMatrix[HydraMaterial::TEX_SLOTS_NUMBER];

};

#ifdef __GNUC__

  //#include <unordered_map>

  //typedef std::unordered_map<std::string, std::string> HashMapS;
  //typedef std::unordered_map<std::string, int>         HashMapI;
  //typedef std::unordered_map<std::string, HashMapS>    HashMapOfHashMapS;

  //typedef std::unordered_map<std::string, std::vector<float> > HashMapFV;
  //typedef std::unordered_map<std::string, std::vector<int> >   HashMapIV;

  #include <map>

  typedef std::map<std::string, std::string> HashMapS;
  typedef std::map<std::string, int>         HashMapI;
  typedef std::map<std::wstring, int>        WHashMapI;
  typedef std::map<std::string, HashMapS>    HashMapOfHashMapS;
  typedef std::map<std::string, MaterialTextureImportMaxParams> HashMapImportParams;

  typedef std::map<std::string, std::vector<float> > HashMapFV;
  typedef std::map<std::string, std::vector<int> >   HashMapIV;

  typedef std::map<std::string, HydraMaterial> HydraMaterialMap;
  typedef std::map<std::string, Light>         HydraLightsMap;

#else
  
  #include <hash_map>  

  typedef stdext::hash_map<std::string, std::string> HashMapS;
  typedef stdext::hash_map<std::string, int>         HashMapI;
  typedef stdext::hash_map<std::wstring, int>        WHashMapI;

  typedef stdext::hash_map<std::string, HashMapS>    HashMapOfHashMapS;
  typedef stdext::hash_map<std::string, MaterialTextureImportMaxParams> HashMapImportParams;

  typedef stdext::hash_map<std::string, std::vector<float> > HashMapFV;
  typedef stdext::hash_map<std::string, std::vector<int> >   HashMapIV;

  typedef stdext::hash_map<std::string, HydraMaterial>       HydraMaterialMap;
  typedef stdext::hash_map<std::string, Light>               HydraLightsMap;


  #pragma warning(disable:4305)  // warning C4305: �������������: �������� �� 'double' � 'const float'
  #pragma warning(disable:4503)  // warning C4503: ����� ����������� ����� ������� � ����������� ��������� ������������ ��������, ��� �������

#endif


const bool COLLADA_DEBUG = false;

template<class T>
static void DEBUG_PRINT(const std::string before, const T& x, const std::string after="")
{
  static std::ofstream colladaLog("collada_parsing_log.txt", std::ios::app);

  if(COLLADA_DEBUG)
    colladaLog << before.c_str() << x << " " << after.c_str() << std::endl;
}

struct HydraScene
{
  void clear()
  {
    materials.clear();
    lights.clear();
    cameras.clear();
    texpaths.clear();
    m_cameras.clear();
  }

  HashMapI materials;
  HashMapI lights;
  HashMapI cameras;
  HashMapI texpaths;
  std::vector<std::string> matnames;

  std::vector<Camera> m_cameras;

  Matrix4x4f globalTransformMatrix;

  std::string scenefile;
  std::string scenefolder;
};

void ImportSceneFromCollada(IGraphicsEngine* pRender,
                            const std::string fileName,
                            Camera* camera, const Matrix4x4f& a_mat,
                            const std::string a_profilePath = "");

HydraScene* LastImportedScene();

const char* GetText(TiXmlNode*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*, const char*, const char*);

TiXmlNode* GetNode(TiXmlNode*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*, const char*, const char*);

float      GetFloatFromXMLNode(TiXmlElement* node, const std::string& a_paramName);
float3     GetFloat3FromXMLNode(TiXmlElement* node, const std::string& name);
Matrix4x4f GetFloat4x4FromXMLNode(TiXmlElement* node, const std::string& a_paramName);
Matrix4x4f GetTransformFromNode(TiXmlNode*);

void MakeHydraMaterialMapFromXMLNode(TiXmlElement* materials_lib, IGraphicsEngine* pRender, HydraMaterialMap* pResult, HashMapImportParams* pParams, HashMapI* pMaxIds, const std::string& inColladaFile);
void MakeHydraLightsMapFromXMLNode(TiXmlElement* materials_lib, IGraphicsEngine* pRender, HydraLightsMap* pResult, const std::string& incolladaFile);
void ImportCamFromXMLNode(Camera* pCam, TiXmlElement* camElem);


///////////////////////////////////////////////
///////////////////////////////////////////////

namespace NumericParser
{

//protected:
  typedef long long int uint64_t;

  inline static uint64_t mystrtol(const char *&a_str, uint64_t val = 0 )
  {
    for ( char c; ( c = *a_str ^ '0' ) <= 9; ++ a_str ) val = val * 10 + c;
    return val;
  }

  inline static float mystrtof(const char *&a_str )
  {
    static float const exp_table[] = { 1e38, 1e37, 1e36, 1e35, 1e34, 1e33, 1e32, 1e31, 1e30, 1e29, 1e28, 1e27, 1e26, 1e25, 1e24, 1e23, 1e22, 1e21,
      1e20, 1e19, 1e18, 1e17, 1e16, 1e15, 1e14, 1e13, 1e12, 1e11, 1e10, 1e9, 1e8, 1e7, 1e6, 1e5, 1e4, 1e3, 1e2, 10,
      1, 0.1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10, 1e-11, 1e-12, 1e-13, 1e-14, 1e-15, 1e-16, 1e-17,
      1e-18, 1e-19, 1e-20, 1e-21, 1e-22, 1e-23, 1e-24, 1e-25, 1e-26, 1e-27, 1e-28, 1e-29, 1e-30, 1e-31, 1e-32, 1e-33,
      1e-34, 1e-35, 1e-36, 1e-37, 1e-38};

    static float const *exp_lookup = &exp_table[38];

    // read sign
    //
    float sign = 1.0f;
    if(*a_str == '-')
    {
      sign = -1.0f;
      a_str++;
    }

    // read integer part
    //
    uint64_t val = mystrtol( a_str ); // read integer part
    int neg_exp = 0;
    if ( *a_str == '.' )              // read fractional part
    {
      char const *fracs = ++ a_str;
      val = mystrtol( a_str, val );
      neg_exp = int(a_str - fracs);
    }

    if ( ( *a_str | ('E'^'e') ) == 'e' ) // read exp if number has it
    {
      neg_exp += int( (*(++a_str)) == '-'? mystrtol( ++ a_str ) : - mystrtol( ++ a_str ) );
    }

    if(neg_exp < -38) neg_exp = -38;
    if(neg_exp > 38)  neg_exp = 38;

    return float(val)*exp_lookup[neg_exp]*sign;
  }

//public:

  inline static float NextFloat(const char*& a_str)
  {
    float result = mystrtof(a_str);
    while(*a_str == ' ' || *a_str == '\n' || *a_str == '\t') a_str++;
    return result;
  }

  inline static int NextInt(const char*& a_str)
  {
    int sign = 1;
    if(*a_str == '-')
    {
      sign = -1;
      a_str++;
    }

    int result = int(mystrtol(a_str));
    if(*a_str == '0') a_str++;
    while(*a_str == ' ' || *a_str == '\n' || *a_str == '\t') a_str++;
    return result*sign;
  }

  //////////////////////////////////////////////////////////////////////////////////////////////////////
  ////
  template<class T>
  void ExtractArrayFromString(const char* strValue, vector<T>* pResult, int a_size)
  {
    std::istringstream stream(strValue);
    T data;

    while(!stream.eof())
    {
      stream >> data;
      pResult->push_back(data);
    }
  }

  template<class T>
  void ExtractArrayFromString(const char* strValue, vector<T>* pResult) { ExtractArrayFromString<T>(strValue, pResult, -1); }

  template<> void ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult, int a_size);
  template<> void ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult);

  template<> void ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult);
  template<> void ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult, int a_size);
};


namespace STR_CNV
{

  template <class T> T StringTo(const std::string& str); // { return T(str); }


  template <> float StringTo<float>(const std::string& str);
  template <> int StringTo<int>(const std::string& str);
  template <> float2 StringTo<float2>(const std::string& str);
  template <> float3 StringTo<float3>(const std::string& str);
  template <> float4 StringTo<float4>(const std::string& str);
  template <> Matrix4x4f StringTo<Matrix4x4f>(const std::string& str);



  static std::string ToLowerCase(const std::string& a_str)
  {
    std::string str = a_str;
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
  }

  static void TransformToLowerCase(std::string& key)
  {
    std::transform(key.begin(), key.end(), key.begin(), ::tolower);
  }

};

std::string MatrixToString(const Matrix4x4f& m);


// ����� ������ ����� ��� ������������� ��������� ������������ ����������, ������� ����������, ���������� �.�.�.
// ������ ��� ����� ����� ������� ����� ��� ������� - ���������, ��������� � ���������.
//
#include "ColladaImport.h"

class IHydraMaterialImportProfile
{
public:

  typedef HashMapS ObjectParameters;

  virtual void Transform(ObjectParameters& a_data) = 0;

};

class ColladaMaterialImportProfile : public IHydraMaterialImportProfile
{
public:

  ColladaMaterialImportProfile(TiXmlElement* a_node);

  void Transform(ObjectParameters& a_data);

protected:

  TiXmlElement* m_pProfileNode;

};



struct InstList;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


class ColladaParser
{

public:

   ColladaParser();
   ~ColladaParser();

   typedef HashMapS           ObjectData;
   typedef HashMapOfHashMapS  ObjectDataList;

   bool LoadXML(const std::string& a_fileName);
   bool LoadXMLFromMem(const std::string& a_xmlData);

   void ImportLights(ObjectDataList* pOut_list);
   void ImportMaterials(ObjectDataList* pOut_list);
   void ImportTextures(ObjectDataList* pOut_list);  // no needs in using it directly it will be called from ImportMaterials, but you still can
   void ImportCameras(ObjectDataList* pOut_list);
   void ImportGeometry(ObjectDataList* pOut_list, HashMapFV *geom, HashMapIV *geom_order, InstList *geometryAttribs);

   Matrix4x4f GetTransformMatrix(){return m_globalTransform;}

   const std::string& GetLastParsedXML() const {return m_lastXMLPath;}

   //
   //
   static void ParseXmlNodeRec(ColladaParser::ObjectData& params, TiXmlElement* pNode, const std::string& a_prefix);
   static void ParseHydraMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialHydraNode);
   static void ParseHydraLight(TiXmlNode* node, ObjectData* p);

   static TiXmlElement* FindNodeByName(TiXmlElement* pEffectsLib, const std::string& materialName);
   static TiXmlElement* FindElemByAttribute(TiXmlElement* a_node, const std::string& a_nodeName, const std::string& a_attributeName, const std::string& a_attributeValue);

   static std::string CutOffColladaEffectsShit(const std::string& a_name);

   //
   //
   void ParseStandartMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData);
   void ParseExtraMaterialData(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData);

   TiXmlElement* LoadXMLAndGetFirstElement(const std::string& a_profilePath, const std::string& a_str);

   TiXmlElement* GetElement(const std::string& a_name);
   TiXmlElement* GetRoot() {return m_root;}

   IHydraMaterialImportProfile* m_pHydraMatProfile;


protected:

   bool ParseCurrXML();

   std::string FindTexturePath(const ObjectDataList& list, const std::string& key, const std::string& val, const std::string& second_val) const;
   std::string FindTargetTransform(TiXmlNode* pObjectsTransform, TiXmlNode* nextNode);
   void InstanceLightObjects(TiXmlNode* pNode, ObjectDataList& plist, ObjectDataList& plist2);

   void ProcessGeometryElement(ObjectDataList::iterator p, HashMapFV& geometry, HashMapIV& geometry_order, vector<int>& tmpArr,TiXmlElement* pGeometryElement, string geometryId);

   void CreateExporterProfiles(TiXmlNode* root);

   TiXmlDocument m_doc;
   TiXmlElement* m_root;
   Matrix4x4f m_globalTransform;

   ObjectDataList m_materialsRemembered;
   std::string m_lastXMLPath;
   ObjectData m_defferedErrorMesasages;

public:
   //
   //
   class IExportTool
   {
   public:

     virtual std::string GetGeometryMaterialRef(TiXmlNode* nextTri);
     virtual std::string FindIndicesArrayKey(HashMapIV& a_map, const std::string& a_name);
   };

   class MaxStandartExporter : public IExportTool
   {
      std::string FindIndicesArrayKey(HashMapIV& a_map, const std::string& a_name);
   };

   class OpenColladaExporter : public IExportTool
   {

   };


   class BlenderExporter : public IExportTool
   {
      std::string GetGeometryMaterialRef(TiXmlNode* nextTri);
   };

   IExportTool* m_pExporterSpecific;

};



struct InstList
{
  vector<string>     mesh_ids;
  vector<Matrix4x4f> matrices;
};


class GeometryStorage
{
public:

  GeometryStorage(ColladaParser::IExportTool* a_pExporter) { m_pExporter = a_pExporter;}

  void ImportModelToRender(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& m_transform, HashMapS& a_defferedErrors);

  HashMapFV geom_data;
  HashMapIV geom_indices;
  HashMapI  mat_indices;

protected:

  std::string FindIndicesArrayKey(const std::string& key);

  ColladaParser::IExportTool* m_pExporter;
};



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
class EmptyDataConverter
{
public:
  virtual void ConvertData(void* data, int w, int h) {}
};


class AlphaFromRedChannel : public EmptyDataConverter
{
public:
  AlphaFromRedChannel(){}
  void ConvertData(void* data, int w, int h);

protected:

};


//////////////////////////////////////////////////////////////////////////////////////////////////////
////

class ITextureImporter
{
public:

  ITextureImporter() : m_ptps(NULL) {}
  virtual ~ITextureImporter(){}

  virtual int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false) = 0;
  virtual void SetCurrentPathToMainFile(const std::string& path) = 0;
  virtual void ResetCurrentPath() = 0;

  virtual int  GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex, float bumpAmt, float blurRadius, float blurSigma, bool invHeight) {return INVALID_TEXTURE;}

  virtual WHashMapI& GetCache() { return m_cache; }

  virtual void SetTexPathStorage(HashMapI* a_ptr) { m_ptps = a_ptr; }

protected:

  virtual int  CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex, float bumpAmt) {return INVALID_TEXTURE;}

  virtual std::string GetAbsolutePath(const std::string& path) {return "";}
  virtual bool HeightFileHasChanged(const std::string& heightPath, const std::string& heightPath2);

  WHashMapI m_cache;
  HashMapI  m_bumpCache;
  HashMapI* m_ptps; // pTexPathsStotage
};


class DummyTextureImporter : public ITextureImporter
{
public:

  DummyTextureImporter(){}
  ~DummyTextureImporter(){}

  int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false) {return INVALID_TEXTURE;}
  void SetCurrentPathToMainFile(const std::string& path) {}
  void ResetCurrentPath() {}
  int  GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex, float bumpAmt, float blurRadius, float blurSigma, bool invHeight) {return INVALID_TEXTURE;}

  WHashMapI& GetCache() { return m_cache; }

protected:

  WHashMapI m_cache;

};

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
class ColladaTextureImporter : public ITextureImporter
{
public:
  ColladaTextureImporter();
  ~ColladaTextureImporter();


  int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false);
  void SetCurrentPathToMainFile(const std::string& path);
  void ResetCurrentPath();

  virtual int GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex, float bumpAmt, float blurRadius, float blurSigma, bool invHeight);

protected:

  int  CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex, float bumpAmt, float blurRadius, float blurSigma, bool invHeight);

  ColladaTextureImporter(const ColladaTextureImporter& rhs){}
  ColladaTextureImporter& operator=(const ColladaTextureImporter& rhs) {return* this;}

  std::string GetPathToFolder(const std::string& pathToFile);
  std::string GetAbsolutePath(const std::string& path);

  std::string m_pathToXML;
  std::string m_pathToXMLFolder;
  std::string m_oldPath;
  int m_chdirResult;
  bool m_pathWasChanged;

  HashMapI m_normalMapCache;
};



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
template<typename Iterator>
inline static float3 GetFloat3(Iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<float3>(a_param->second[a_name] );
  else
    return float3(0,0,0);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
template<typename Iterator>
inline static float GetFloat(Iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<float>(a_param->second[a_name] );
  else
    return 0.0f;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
template<typename Iterator>
inline static Matrix4x4f GetMatrix(Iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<Matrix4x4f>(a_param->second[a_name] );
  else
    return Matrix4x4f();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
template<typename Iterator>
static std::string GetString(Iterator a_param, const std::string& a_name)
{
  return a_param->second[a_name];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
template<typename Iterator>
static int GetBRDFType(Iterator a_param, const std::string& a_name, const std::string& a_name2)
{
  std::string brdfType = a_param->second[a_name];

  if(brdfType == "")
    brdfType =  a_param->second[a_name2];

  int BRDF_id;
  if(brdfType == "phong")
    BRDF_id = RAYTR::HydraMaterial::BRDF_PHONG;
  else if (brdfType=="blinn")
    BRDF_id = RAYTR::HydraMaterial::BRDF_BLINN;
  else if (brdfType=="cook-torrance")
    BRDF_id = RAYTR::HydraMaterial::BRDF_COOK_TORRANCE;
  else if (brdfType=="fresnel_dielectric" || brdfType=="fresnel" || brdfType=="dielectric")
    BRDF_id = RAYTR::HydraMaterial::BRDF_FRESNEL_DIELECTRIC;
  else if(brdfType=="fresnel_conductor" || brdfType=="conductor")
    BRDF_id = RAYTR::HydraMaterial::BRDF_FRESNEL_CONDUCTOR;
  else
    BRDF_id = RAYTR::HydraMaterial::BRDF_PHONG;

  return BRDF_id;
}


class IGeometryImporter
{
public:

  virtual void ImportGeometry(IGraphicsEngine* pRender, const Matrix4x4f& a_globalTransform);

};

class ColladaGeometryImporter : public IGeometryImporter
{
public:
  ColladaGeometryImporter(ColladaParser* a_parser) {m_pColladaParser = a_parser;}

protected:

  ColladaParser* m_pColladaParser;


};


class IMaterialImporter
{
public:
  IMaterialImporter(){}
  virtual ~IMaterialImporter(){}

  virtual float3 GetTransparency(ColladaParser::ObjectData& params) {return float3(0,0,0);}

protected:


};

class OpenColladaMaterialImporter : public IMaterialImporter
{
public:

  OpenColladaMaterialImporter(){}
  ~OpenColladaMaterialImporter(){}

  float3 GetTransparency(ColladaParser::ObjectData& params);

protected:

};



IMaterialImporter* CreateMaterialImporter(TiXmlNode* a_xmlRoot);


void ImportLightsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_lights,
                             const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter, HashMapI& a_lightsIds);

void ImportHydraMaterialsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_materials,
                                     GeometryStorage& a_geomStorage, ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter, HashMapI& a_matIds);

void ImportCamerasFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_cameras,
                              Camera* camera, const Matrix4x4f& a_mat, HashMapI& a_camIds, std::vector<Camera>& a_outCameras);


void ImportGeometryFromCollada(IGraphicsEngine* pRender,
                               ColladaParser::ObjectDataList& a_geometry,
                               GeometryStorage& geomStorage, const Matrix4x4f& a_mTransform,
                               InstList& geometryAttribs);

//void ReplaceMaterialsWithProfile(ColladaParser::ObjectDataList& a_materialsList, TiXmlElement* a_mat_lib);
void ReplaceLightsWithProfile(ColladaParser::ObjectDataList& a_lightsList, TiXmlElement* lib);
void ReplaceCamerasWithProfile(ColladaParser::ObjectDataList& a_camList, TiXmlElement* lib);

void ReplaceMaterialsWithAliases(IGraphicsEngine* pRender, ITextureImporter* pTexImporter, ColladaParser::ObjectDataList& a_materials, TiXmlElement* alias_lib);



RAYTR::Light  HydraLightFromStringMap(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter);

void SaveImageToFile(const std::string& a_fileName, int w, int h, unsigned int* data);
void SaveHDRImageToFileTIFF(const std::string& a_fileName, int w, int h, float4* data);
void SaveHDRImageToFileHDR(const std::string& a_fileName, int w, int h, float4* data);

int LoadTextureToRender(const std::string& a_fileName, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL);


void CreateDefaultHydraProfile(const std::string& a_profilePath);


HydraMaterial ReadSingleHydraMaterialFromXMLNode(TiXmlElement* matElem, TiXmlElement* aliases_mat, 
                                                 IGraphicsEngine* pRender, ITextureImporter* pTexInporter, std::string& a_outName, int* pMaxId, HashMapImportParams* pPapams);

RAYTR::Light SingleHydraLightFromXMLNode(TiXmlElement* lightElem, IGraphicsEngine* pRender, ITextureImporter* pTexImporter, 
                                         const Matrix4x4f a_globalTransform, std::string& a_outName);







//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static inline ColladaParser::ObjectData EmptyTransform(const ColladaParser::ObjectData& rhs) { return rhs; }


template<typename Container, typename TransformFunc>
void ReplaceMaterialsWithProfile(Container& a_materialsList, TiXmlElement* materials_lib, TransformFunc TransformObj) 
{
  if(materials_lib == NULL)
    return;

  for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
  {
    TiXmlElement* matElem = nextMat->ToElement();
    std::string name = "";

    if(matElem->Attribute("id") != NULL)
      name = matElem->Attribute("id");
    else if(matElem->Attribute("name") != NULL)
      name = matElem->Attribute("name");

    if(a_materialsList.find(name) == a_materialsList.end())
    {
      fprintf(stderr, "[collada] Warning: model don't have material called %s \n", name.c_str());
      continue;
    }

    ColladaParser::ObjectData params;

    TiXmlElement* pMaterialModel = matElem->FirstChildElement();
    if(STR_CNV::ToLowerCase(pMaterialModel->ValueStr()) == "hydra")
    {
      ColladaParser::ParseHydraMaterial(params, pMaterialModel);
      params["name"] = name; 

      a_materialsList[name] = TransformObj(params);
    }
    else
      fprintf(stderr, "[collada] Warning: Hydra profile has unknown material model %s \n", pMaterialModel->ValueStr().c_str());

  }

}

template<typename Container>
static void DoGlobalFixesOnMaterialParams(Container& a_materialsList, TiXmlElement* materials_lib)
{
  // now make global fixes
  //
  IHydraMaterialImportProfile* pProfileFix = new ColladaMaterialImportProfile(materials_lib);

  for(auto p = a_materialsList.begin(); p!= a_materialsList.end(); ++p)
    pProfileFix->Transform(p->second);

  delete pProfileFix;
}


template<typename PointerType>
RAYTR::HydraMaterial HydraMaterialFromStringMap(PointerType p, IGraphicsEngine* pRender, ITextureImporter* pTexImporter, HashMapImportParams* pStoredImportParams)
{
  RAYTR::HydraMaterial material;
  MaterialTextureImportMaxParams texturesImportParameters;

  std::string name = p->second["name"];
  //std::string name = p->first;

  // ambient
  //
  material.ambient.color            = GetFloat3(p, "ambient_color");
  material.ambient.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"ambient_texture"), pRender);
  material.ambient.light_id         = -1;
  material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");

  if(length(material.ambient.color) > 0.0001f)
  {
    //std::cerr << "ambient != 0; " << name.c_str() << std::endl;
    material.ambient.color = float3(0,0,0);
  }

  if(material.ambient.light_multiplyer == 0.0f)
    material.ambient.light_multiplyer = 1.0f;

  float3 emission = GetFloat3(p, "emission_color");
  if(length(emission) > 0.01f)
  {
    material.flags |= RAYTR::HydraMaterial::THIS_IS_LIGHT;
    material.flags |= RAYTR::HydraMaterial::EMISSIVE_MATERIAL_NOT_SAMPLED_DIRECTLY;
    material.ambient.color = emission;
    material.ambient.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"emission_texture"), pRender);
    material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");

    float disableEmissionPhotonMap = GetFloat(p, "emission_disable_for_photonmap");
    if(disableEmissionPhotonMap > 0.0f)
      material.flags |= HydraMaterial::EMISSION_DISABLE_FOR_PHOTONMAP;

    if(p->second["emission_cast_GI"] != "")
    {
      float cast_GI = GetFloat(p, "emission_cast_GI");
      if (cast_GI < 1e-5f)
        material.flags |= HydraMaterial::EMISSIVE_FORBID_CAST_GI;
    }
   
  }

  // diffuse
  //
  material.diffuse.color       = GetFloat3(p,      "diffuse_color");
  material.diffuse.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"diffuse_texture"), pRender);

  // 3DS Max crap
  //
  {
    float flatNormals = GetFloat(p, "hack_flat_normals");

    if(flatNormals > 0.0f)
      material.flags |= HydraMaterial::IMPORT_FLAT_SHADING;

    // texture 'sampler' - matrix + addressing mode
    //
    if(pStoredImportParams != NULL)
    {
      HashMapImportParams& importParams = (*pStoredImportParams);

      texturesImportParameters.uTiling = GetFloat(p, "diffuse_texture_tiling_u");
      texturesImportParameters.vTiling = GetFloat(p, "diffuse_texture_tiling_v");
      texturesImportParameters.uOffset = GetFloat(p, "diffuse_texture_offset_u");
      texturesImportParameters.vOffset = GetFloat(p, "diffuse_texture_offset_v");

      if(abs(texturesImportParameters.uTiling) < 0.00001f) texturesImportParameters.uTiling = 1.0f; 
      if(abs(texturesImportParameters.vTiling) < 0.00001f) texturesImportParameters.vTiling = 1.0f;

      std::string matricesNames[HydraMaterial::TEX_SLOTS_NUMBER]; 
      unsigned int addressingModes[HydraMaterial::TEX_SLOTS_NUMBER];

      matricesNames[HydraMaterial::TEX_SLOT_EMISSIVE]       = "emission_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_DIFFUSE]        = "diffuse_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_SPECULAR]       = "specular_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_REFLECTIVE]     = "reflectivity_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_SPEC_GLOSINESS] = "specular_glossiness_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_REFL_GLOSINESS] = "reflectivity_glossiness_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_TRANSPARENCY]   = "transparency_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_OPACITY]        = "transparency_opacity_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_DISPLACEMENT]   = "displacement_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_NORMALMAP]      = "displacement_sampler_matrix";

      matricesNames[HydraMaterial::TEX_SLOT_TRANL_COLOR]    = "translucency_color_sampler_matrix";
      matricesNames[HydraMaterial::TEX_SLOT_TRANL_DIFF ]    = "translucency_diff_sampler_matrix";

      for(int i=0;i<HydraMaterial::TEX_SLOTS_NUMBER;i++)
      {
        const std::string& slotName = matricesNames[i];
        const std::string  addressingModeNameU = slotName.substr(0, slotName.size() - 6) + "addressing_mode_u";
        const std::string  addressingModeNameV = slotName.substr(0, slotName.size() - 6) + "addressing_mode_v";
        const std::string  addressingModeNameW = slotName.substr(0, slotName.size() - 6) + "addressing_mode_w";

        addressingModes[i] = 0x00000000;

        if(p->second[slotName] != "")
        {
          texturesImportParameters.hasNonIdentityTexMatrix[i] = true;
          texturesImportParameters.texSlotMatrices[i] = GetMatrix(p, slotName);
          
          std::string addrModeU = GetString(p, addressingModeNameU);
          std::string addrModeV = GetString(p, addressingModeNameV);
          std::string addrModeW = GetString(p, addressingModeNameW);
          
          if(addrModeU == "clamp")
            addressingModes[i] |= HydraMaterial::TEX_COORDU_CLAMP;
          else if(addrModeU == "mirror")
            addressingModes[i] |= HydraMaterial::TEX_COORDU_MIRORRED;
          else
            addressingModes[i] |= HydraMaterial::TEX_COORDU_REPEAT;

          if(addrModeV == "clamp")
            addressingModes[i] |= HydraMaterial::TEX_COORDV_CLAMP;
          else if(addrModeV == "mirror")
            addressingModes[i] |= HydraMaterial::TEX_COORDV_MIRORRED;
          else
            addressingModes[i] |= HydraMaterial::TEX_COORDV_REPEAT;

          if(addrModeW == "clamp")
            addressingModes[i] |= HydraMaterial::TEX_COORDW_CLAMP;
          else if(addrModeW == "mirror")
            addressingModes[i] |= HydraMaterial::TEX_COORDW_MIRORRED;
          else
            addressingModes[i] |= HydraMaterial::TEX_COORDW_REPEAT;
        }
      }

      //
      //
      int slotsAll[12] = {HydraMaterial::TEX_SLOT_EMISSIVE,       HydraMaterial::TEX_SLOT_DIFFUSE,  
                          HydraMaterial::TEX_SLOT_SPECULAR,       HydraMaterial::TEX_SLOT_REFLECTIVE, 
                          HydraMaterial::TEX_SLOT_TRANSPARENCY,   HydraMaterial::TEX_SLOT_DISPLACEMENT, 
                          HydraMaterial::TEX_SLOT_NORMALMAP,      HydraMaterial::TEX_SLOT_SPEC_GLOSINESS, 
                          HydraMaterial::TEX_SLOT_REFL_GLOSINESS, HydraMaterial::TEX_SLOT_OPACITY, 
                          HydraMaterial::TEX_SLOT_TRANL_COLOR,    HydraMaterial::TEX_SLOT_TRANL_DIFF };

      int* refs[12]   = {&material.ambient.color_texMatrixId,        &material.diffuse.color_texMatrixId,
                         &material.specular.color_texMatrixId,       &material.reflection.color_texMatrixId,
                         &material.transparency.color_texMatrixId,   &material.displacement.height_texMatrixId,
                         &material.displacement.normals_texMatrixId, &material.specular.gloss_texMatrixId, 
                         &material.reflection.gloss_texMatrixId,     &material.transparency.opacity_texMatrixId, 
                         &material.translucent.color_texMatrixId,    &material.translucent.diffusion_texMatrixId };

      for(int slotId=0; slotId<12; slotId++)
      {
        int slot = slotsAll[slotId];
        if(texturesImportParameters.hasNonIdentityTexMatrix[slot])
          *(refs[slotId]) = pRender->AddTextureMatrix(texturesImportParameters.texSlotMatrices[slot]) | addressingModes[slot];
      }

      importParams[name] = texturesImportParameters;
    }


  }

  // specular
  //
  material.specular.color = GetFloat3(p, "specular_color");
  float power = GetFloat(p, "specular_cos_power");
  if(power < 1.0) power = HydraMaterial::MaxCosPower();
  else if(power > HydraMaterial::AdmissibleCosPower()) power = HydraMaterial::AdmissibleCosPower();

  material.specular.cosPower   = power;
  material.specular.brdf_id    = GetBRDFType(p, "specular_brfd_type", "specular_brdf_type");
  material.specular.fresnelIOR = GetFloat(p,    "specular_fresnel_IOR");
  material.specular.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"specular_texture"), pRender);
  material.specular.gloss_texId = pTexImporter->AddTextureIfExists(GetString(p,"specular_glossiness_texture"), pRender);

  //std::cerr << "material.specular.fresnelIOR = " << material.specular.fresnelIOR << std::endl;

  if(material.specular.brdf_id == HydraMaterial::BRDF_COOK_TORRANCE)
  {
    float rougness = GetFloat(p, "specular_roughness");
    if(rougness == 0.0f)
      rougness = GetFloat(p, "reflectivity_roughness");
  }

  float specFresnel =  GetFloat(p, "specular_fresnel");
  if(specFresnel > 0.0f)
    material.flags |= HydraMaterial::FRESNEL_SPECULAR_ENABLE;

  // reflection
  //
  material.reflection.color       = GetFloat3(p,   "reflectivity_color");
  material.reflection.brdf_id     = GetBRDFType(p, "reflectivity_brfd_type", "reflectivity_brdf_type");
  material.reflection.fresnelIOR  = GetFloat(p,    "reflectivity_fresnel_IOR");
  material.reflection.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"reflectivity_texture"), pRender);
  material.reflection.gloss_texId = pTexImporter->AddTextureIfExists(GetString(p,"reflectivity_glossiness_texture"), pRender);

  float power2 = GetFloat(p, "reflectivity_cos_power");
  if(power2 < 1.0 || power2 > HydraMaterial::AdmissibleCosPower()) 
    power2 = HydraMaterial::MaxCosPower();
  material.reflection.cosPower = power2;

  float reflFresnel = GetFloat(p, "reflectivity_fresnel");
  if(reflFresnel > 0.0f)
    material.flags |= HydraMaterial::FRESNEL_REFLECTION_ENABLE;

  EmptyDataConverter* pTransparencyConverter = new AlphaFromRedChannel();

  // transparency
  //
  material.transparency.color         = GetFloat3(p, "transparency_color");
  material.transparency.color_texId   = pTexImporter->AddTextureIfExists(GetString(p, "transparency_texture"), pRender, pTransparencyConverter);
  material.transparency.exitColor     = GetFloat3(p, "transparency_exit_color");
  material.transparency.fogColor      = GetFloat3(p, "transparency_fog_color");
  material.transparency.fogMultiplyer = GetFloat(p,  "transparency_fog_multiplyer");
  material.transparency.IOR           = GetFloat(p,  "transparency_IOR");
  material.transparency.IOR_texId     = pTexImporter->AddTextureIfExists(GetString(p,"transparency_IOR_texture"), pRender);
  material.transparency.opacity_texId = pTexImporter->AddTextureIfExists(GetString(p, "transparency_opacity_texture"), pRender);

  if(length(material.transparency.color) > 1e-5f) // ################################ ������ �� ������ !!!
    material.reflection.brdf_id = RAYTR::HydraMaterial::BRDF_FRESNEL_DIELECTRIC;

  if (GetFloat(p, "transparency_thin_surface"))
  {
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;
    //material.transparency.IOR = 1.0f;
  }

  if(GetFloat(p,  "transparency_skip_shadow"))
  {
    //material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;
    material.flags |= HydraMaterial::MATERIAL_SKIP_SHADOW;
    //material.transparency.IOR = 1.0f;
  }

  if (material.transparency.opacity_texId != INVALID_TEXTURE)
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  if (GetFloat(p, "transparency_shadow_matte") > 0.0f)
  {
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;
    material.flags |= HydraMaterial::MATERIAL_SKIP_SHADOW;
    material.flags |= HydraMaterial::TRANSPARENCY_SHADOW_MATTE;

    material.transparency.color    = float3(1, 1, 1);
    material.transparency.fogColor = float3(1, 1, 1);
  }

  float power3 = GetFloat(p, "transparency_cos_power");
  
  if(power3 < 1.0 || power3 > HydraMaterial::AdmissibleCosPower())
    power3 = HydraMaterial::MaxCosPower();
  
  material.transparency.glossiness = power3;

  float castColorShadow = GetFloat(p, "transparency_cast_color_shadows");
  if(castColorShadow > 0.0f)
    material.flags |= HydraMaterial::CAST_COLOR_SHADOWS;

  // displacement
  //
  bool invertHeight = (GetFloat(p, "displacement_invert_height") > 0.0f); // this is a casus :)
  if(invertHeight) // inverse
    material.flags |= HydraMaterial::INVERT_HEIGHT;
  
  bool invertFlagsNormals[4];
  invertFlagsNormals[0] = GetFloat(p, "displacement_invert_normalX") > 0.0f;
  invertFlagsNormals[1] = GetFloat(p, "displacement_invert_normalY") > 0.0f;
  invertFlagsNormals[2] = GetFloat(p, "displacement_invert_normalZ") > 0.0f;
  invertFlagsNormals[3] = GetFloat(p, "displacement_swap_normalXY" ) > 0.0f;

  if(invertFlagsNormals[0])
    material.flags |= HydraMaterial::INVERT_NMAP_X;

  if(invertFlagsNormals[1])
    material.flags |= HydraMaterial::INVERT_NMAP_Y;

  if(invertFlagsNormals[3])
    material.flags |= HydraMaterial::INVERT_SWAP_NMAP_XY;

  std::string pathToHeightTex = GetString(p, "displacement_height_texture");
  std::string pathToNormalTex = GetString(p, "displacement_normals_texture");

  material.displacement.height        = GetFloat(p, "displacement_height");
  material.displacement.height_texId  = pTexImporter->AddTextureIfExists(pathToHeightTex, pRender, NULL, false);
  material.displacement.normals_texId = pTexImporter->AddTextureIfExists(pathToNormalTex, pRender, NULL);

  float bumpBlurRadius = 1.0f;
  float bumpBlurSigma  = 1.5f;

  if(p->second["displacement_bump_radius"] != "")
    bumpBlurRadius = GetFloat(p, "displacement_bump_radius");

  if(p->second["displacement_bump_sigma"] != "")
    bumpBlurSigma = GetFloat(p, "displacement_bump_sigma");

  if(material.displacement.normals_texId == INVALID_TEXTURE && material.displacement.height_texId != INVALID_TEXTURE)
  { 
    float bumpAmt = GetFloat(p, "displacement_bump_amount"); 
    material.displacement.normals_texId = pTexImporter->GetNormalMapFromFisplacement(material.displacement.height_texId, pRender, pathToHeightTex, bumpAmt, bumpBlurRadius, bumpBlurSigma, (material.flags & HydraMaterial::INVERT_HEIGHT));
  }

  delete pTransparencyConverter; pTransparencyConverter = NULL;

  if(GetFloat(p, "displacement_shadows") > 0.0f)
    material.flags |= HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;

  material.flags |= HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;



  material.translucent.color          = GetFloat3(p, "translucency_color");
  material.translucent.diffusionCoeff = GetFloat3(p, "translucency_diff");
  material.translucent.diffRadius     = GetFloat (p, "translucency_radius");

  std::string pathToTranslucentColorTex = GetString(p, "translucency_texture");
  std::string pathToTranslucentDiffTex  = GetString(p, "translucency_texture_diff");

  material.translucent.color_texId     = pTexImporter->AddTextureIfExists(pathToTranslucentColorTex, pRender, NULL, false);
  material.translucent.diffusion_texId = pTexImporter->AddTextureIfExists(pathToTranslucentDiffTex, pRender, NULL, false);

  if (length(material.translucent.color) > 0.001f)
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  return material;
}


