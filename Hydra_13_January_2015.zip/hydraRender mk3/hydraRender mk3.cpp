//**************************************************************************/
// Copyright (c) 1998-2007 Autodesk, Inc.
// All rights reserved.
// 
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION: Appwizard generated plugin
// AUTHOR: ALICE
//***************************************************************************/


#include "hydraRender mk3.h"
#include "3dsmaxport.h"
#include "gamma.h"


//#include "path.h"
//#include "AssetType.h"
#include "IFileResolutionManager.h"
#include <ctime>

extern HINSTANCE hInstance;

BMM_Color_64 colTo64(Color c)
{
  BMM_Color_64 bc;

  // Clamp the colors
  c.ClampMinMax();

  bc.r = (WORD)(c.r * 65535.0);
  bc.g = (WORD)(c.g * 65535.0);
  bc.b = (WORD)(c.b * 65535.0);

  return bc;
}


std::wstring s2ws(const std::string& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0); 
    wchar_t* buf = new wchar_t[len];
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
    std::wstring r(buf);
    delete[] buf;
    return r;
}

std::string ws2s(const std::wstring& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0); 
    char* buf = new char[len];
    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, buf, len, 0, 0); 
    std::string r(buf);
    delete[] buf;
    return r;
}


std::wstring ToWideString(const std::string& rhs)
{
  return s2ws(rhs);
  //std::wstring res; res.resize(rhs.size());
  //std::copy(rhs.begin(), rhs.end(), res.begin());
  //return res;
}

std::string ToNarrowString(const std::wstring& rhs)
{
  return ws2s(rhs);
  //std::string res; res.resize(rhs.size());
  //std::copy(rhs.begin(), rhs.end(), res.begin());
  //return res;
}



hydraRender_mk3::hydraRender_mk3()
{
  rendParams.renderer = this;
  m_pScanlineRender = NULL;

  server_IP = "127.0.0.1";

  plugin_log.OpenLogFile("C:/[Hydra]/pluginFiles/plugin_log.txt");
  m_paramTrace.open("C:/[Hydra]/pluginFiles/paramTrace.txt");

	vsgfFilename = "c:/[hydra]/pluginFiles/scene.vsgf";
	posFilename  = "c:/[hydra]/pluginFiles/pos.dat";
	normFilename = "c:/[hydra]/pluginFiles/norm.dat";
	texFilename  = "c:/[hydra]/pluginFiles/tex.dat";
	vIndFilename = "c:/[hydra]/pluginFiles/vInd.dat";
	mIndFilename = "c:/[hydra]/pluginFiles/mInd.dat";


	last_render = NULL;

  incl.geometry  = true;
  incl.spheres   = true;
  incl.lights    = false;
  incl.materials = false;
  incl.tree      = false;
  bIncludeNormals  =  FALSE;
  bIncludeTextureCoords = TRUE;
  nKeyFrameStep = 5;
  nMeshFrameStep = 5;
	nStaticFrame = GetCOREInterface()->GetTime();
	
	
	start_res = 64;
	//procTexToCheck = 0;

  incl.sceneDumpName  = "c:/[Hydra]/pluginFiles/test.dump";
  incl.colladaProfile = "c:/[Hydra]/pluginFiles/hydra_profile_generated.xml";
  incl.render_type    = _T("Ray_Tracer");

  incl.AccType    = _T("bvh");
  incl.ConstrMode = _T("quality");

  incl.imgObjNum  = 0;
	/*allVerticesNum = 0;
	allIndicesNum = 0;*/
	flat_shading = false;
  mtlEditorWasOpen = FALSE;
  m_geomTemp.reserveMemory(1000000);

	pScene = nullptr;
	pVnode = nullptr;

}

hydraRender_mk3::~hydraRender_mk3()
{
}
#ifdef MAX2014
RefResult hydraRender_mk3::NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID, RefMessage message)
{
	return REF_DONTCARE;
}
#else
RefResult hydraRender_mk3::NotifyRefChanged(const Interval& changeInt, RefTargetHandle hTarget, PartID& partID, RefMessage message, BOOL propagate) 
{
	return REF_DONTCARE;
}
#endif

RefTargetHandle hydraRender_mk3::Clone(RemapDir &remap) 
{
  hydraRender_mk3 *mnew = new hydraRender_mk3();

	//main
	mnew->rendParams.primary = rendParams.primary;
	mnew->rendParams.secondary = rendParams.secondary;
	mnew->rendParams.tertiary = rendParams.tertiary;
	mnew->rendParams.causticsMode = rendParams.causticsMode;
	mnew->rendParams.timeLimitOn = rendParams.timeLimitOn;
	mnew->rendParams.timeLimit = rendParams.timeLimit;
  mnew->rendParams.useHydraGUI = rendParams.useHydraGUI;
  mnew->rendParams.useToneMapping = rendParams.useToneMapping;
	mnew->rendParams.enableDOF = rendParams.enableDOF;
	mnew->rendParams.noRandomLightSel = rendParams.noRandomLightSel;
	mnew->rendParams.enableLog = rendParams.enableLog;
  mnew->rendParams.focalplane = rendParams.focalplane;
  mnew->rendParams.lensradius = rendParams.lensradius;
	mnew->rendParams.debugOn = rendParams.debugOn;
	mnew->rendParams.allSecondary = rendParams.allSecondary;
	mnew->rendParams.allTertiary = rendParams.allTertiary;
	mnew->rendParams.primaryMLFilter = rendParams.primaryMLFilter;
	mnew->rendParams.secondaryMLFilter = rendParams.secondaryMLFilter;
	mnew->rendParams.writeToDisk = rendParams.writeToDisk;

  //path tracing
  mnew->rendParams.seed = rendParams.seed;
  mnew->rendParams.causticRays = rendParams.causticRays;
  mnew->rendParams.minrays = rendParams.minrays;
  mnew->rendParams.maxrays = rendParams.maxrays;
  mnew->rendParams.raybounce = rendParams.raybounce;
  mnew->rendParams.diffbounce = rendParams.diffbounce;
  mnew->rendParams.relative_error = rendParams.relative_error;
	mnew->rendParams.guided = rendParams.guided;

  //SPPM Caustics
  mnew->rendParams.maxphotons_c = rendParams.maxphotons_c;
  mnew->rendParams.caustic_power = rendParams.caustic_power;
  mnew->rendParams.retrace_c = rendParams.retrace_c;
  mnew->rendParams.initial_radius_c = rendParams.initial_radius_c;
  mnew->rendParams.visibility_c = rendParams.visibility_c;
	mnew->rendParams.alpha_c = rendParams.alpha_c;

  //SPPM Diffuse
  mnew->rendParams.maxphotons_d = rendParams.maxphotons_d;
  mnew->rendParams.retrace_d = rendParams.retrace_d;
  mnew->rendParams.initial_radius_d = rendParams.initial_radius_d;
  mnew->rendParams.visibility_d = rendParams.visibility_d;
	mnew->rendParams.alpha_d = rendParams.alpha_d;
	mnew->rendParams.irr_map = rendParams.irr_map;

  //Irradiance cache
  mnew->rendParams.ic_eval = rendParams.ic_eval;
  mnew->rendParams.maxpass = rendParams.maxpass;
  mnew->rendParams.fixed_rays = rendParams.fixed_rays;
  mnew->rendParams.ws_err = rendParams.ws_err;
  mnew->rendParams.ss_err4 = rendParams.ss_err4;
  mnew->rendParams.ss_err2 = rendParams.ss_err2;
  mnew->rendParams.ss_err1 = rendParams.ss_err1;
  mnew->rendParams.ic_relative_error = rendParams.ic_relative_error;

	//Multi-Layer
	mnew->rendParams.filterPrimary = rendParams.filterPrimary;
	mnew->rendParams.r_sigma = rendParams.r_sigma;
	mnew->rendParams.s_sigma = rendParams.s_sigma;
	mnew->rendParams.layerNum = rendParams.layerNum;

  //Tone mapping
  mnew->rendParams.white_point = rendParams.white_point;
  mnew->rendParams.gamma = rendParams.gamma;
  mnew->rendParams.strength = rendParams.strength;
  mnew->rendParams.phi = rendParams.phi;
  mnew->rendParams.bloom = rendParams.bloom;
  mnew->rendParams.icBounce = rendParams.icBounce;

	//Environment
	mnew->rendParams.env_mult = rendParams.env_mult;

  BaseClone(this, mnew, remap);
  return (RefTargetHandle)mnew;
 }

void hydraRender_mk3::ResetParams()
{
  DebugPrint(_T("**** Resetting parameters.\n"));

  rendParams.SetDefaults();
}
/*
int hydraRender_mk3::RenderPresetsPreSave ( ITargetedIO * root, BitArray saveCategories)
{
//	root->AddSaveTarget(
}*/

//Chunk ID's for loading and saving render data

#define MAIN_CHUNK		0x120
#define PATHTRACING_CHUNK		0x130
#define IRRCACHE_CHUNK		0x140
#define MULTILAYER_CHUNK		0x150
#define SPPM_C_CHUNK		0x160
#define SPPM_D_CHUNK		0x170
#define TONEMAP_CHUNK		0x180
#define ENVIRONMENT_CHUNK		0x190

IOResult hydraRender_mk3::Save(ISave *isave)
{
	ULONG nb;

	isave->BeginChunk(MAIN_CHUNK);
	isave->Write(&rendParams.primary,sizeof(int),&nb);
	isave->Write(&rendParams.secondary,sizeof(int),&nb);
	isave->Write(&rendParams.tertiary,sizeof(int),&nb);
	isave->Write(&rendParams.causticsMode,sizeof(int),&nb);
	isave->Write(&rendParams.allSecondary,sizeof(bool),&nb);
	isave->Write(&rendParams.allTertiary,sizeof(bool),&nb);
	isave->Write(&rendParams.timeLimitOn,sizeof(bool),&nb);
	isave->Write(&rendParams.useHydraGUI,sizeof(bool),&nb);
	isave->Write(&rendParams.useToneMapping,sizeof(bool),&nb);
	isave->Write(&rendParams.noRandomLightSel,sizeof(bool),&nb);
	isave->Write(&rendParams.debugOn,sizeof(bool),&nb);
	isave->Write(&rendParams.enableLog,sizeof(bool),&nb);
	isave->Write(&rendParams.enableDOF,sizeof(bool),&nb);
	isave->Write(&rendParams.primaryMLFilter,sizeof(bool),&nb);
	isave->Write(&rendParams.secondaryMLFilter,sizeof(bool),&nb);
	isave->Write(&rendParams.writeToDisk,sizeof(bool),&nb);
	isave->Write(&rendParams.timeLimit,sizeof(long),&nb);
	isave->Write(&rendParams.focalplane,sizeof(float),&nb);
	isave->Write(&rendParams.lensradius,sizeof(float),&nb);	
	isave->EndChunk();

	isave->BeginChunk(PATHTRACING_CHUNK);
	isave->Write(&rendParams.icBounce,sizeof(int),&nb);
	isave->Write(&rendParams.seed,sizeof(int),&nb);
	isave->Write(&rendParams.minrays,sizeof(int),&nb);
	isave->Write(&rendParams.maxrays,sizeof(int),&nb);
	isave->Write(&rendParams.raybounce,sizeof(int),&nb);
	isave->Write(&rendParams.diffbounce,sizeof(int),&nb);
	isave->Write(&rendParams.useRR,sizeof(int),&nb);
	isave->Write(&rendParams.causticRays,sizeof(int),&nb);
	isave->Write(&rendParams.relative_error,sizeof(float),&nb);
	isave->Write(&rendParams.guided, sizeof(bool), &nb);
	isave->EndChunk();

	isave->BeginChunk(IRRCACHE_CHUNK);
	isave->Write(&rendParams.ic_eval,sizeof(int),&nb);
	isave->Write(&rendParams.maxpass,sizeof(int),&nb);
	isave->Write(&rendParams.fixed_rays,sizeof(int),&nb);
	isave->Write(&rendParams.ws_err,sizeof(float),&nb);
	isave->Write(&rendParams.ss_err4,sizeof(float),&nb);
	isave->Write(&rendParams.ss_err2,sizeof(float),&nb);
	isave->Write(&rendParams.ss_err1,sizeof(float),&nb);
	isave->Write(&rendParams.ic_relative_error,sizeof(float),&nb);
	isave->EndChunk();

	isave->BeginChunk(MULTILAYER_CHUNK);
	isave->Write(&rendParams.layerNum,sizeof(int),&nb);
	isave->Write(&rendParams.r_sigma,sizeof(float),&nb);
	isave->Write(&rendParams.s_sigma,sizeof(float),&nb);
	isave->Write(&rendParams.filterPrimary,sizeof(bool),&nb);
	isave->EndChunk();

	isave->BeginChunk(SPPM_C_CHUNK);
	isave->Write(&rendParams.maxphotons_c,sizeof(int),&nb);
	isave->Write(&rendParams.retrace_c,sizeof(int),&nb);
	isave->Write(&rendParams.initial_radius_c,sizeof(float),&nb);
	isave->Write(&rendParams.caustic_power,sizeof(float),&nb);
	isave->Write(&rendParams.visibility_c,sizeof(bool),&nb);
	isave->Write(&rendParams.alpha_c,sizeof(float),&nb);
	isave->EndChunk();

	isave->BeginChunk(SPPM_D_CHUNK);
	isave->Write(&rendParams.maxphotons_d,sizeof(int),&nb);
	isave->Write(&rendParams.retrace_d,sizeof(int),&nb);
	isave->Write(&rendParams.initial_radius_d,sizeof(float),&nb);
	isave->Write(&rendParams.visibility_d,sizeof(bool),&nb);
	isave->Write(&rendParams.alpha_d,sizeof(float),&nb);
	isave->Write(&rendParams.irr_map,sizeof(bool),&nb);
	isave->EndChunk();

	isave->BeginChunk(TONEMAP_CHUNK);
	isave->Write(&rendParams.white_point,sizeof(float),&nb);
	isave->Write(&rendParams.gamma,sizeof(float),&nb);
	isave->Write(&rendParams.strength,sizeof(float),&nb);
	isave->Write(&rendParams.phi,sizeof(float),&nb);
	isave->Write(&rendParams.bloom,sizeof(bool),&nb);
	isave->EndChunk();

	isave->BeginChunk(ENVIRONMENT_CHUNK);
	isave->Write(&rendParams.env_mult,sizeof(float),&nb);
	isave->EndChunk();

	return IO_OK; 
}

IOResult hydraRender_mk3::Load(ILoad *iload)
{
	ULONG nb;
	int id;
	IOResult res;
	while (IO_OK==(res=iload->OpenChunk())) {
		switch(id = iload->CurChunkID())  {
			case MAIN_CHUNK:
				res = iload->Read(&rendParams.primary,sizeof(int),&nb);
				res = iload->Read(&rendParams.secondary,sizeof(int),&nb);
				res = iload->Read(&rendParams.tertiary,sizeof(int),&nb);
				res = iload->Read(&rendParams.causticsMode,sizeof(int),&nb);
				res = iload->Read(&rendParams.allSecondary,sizeof(bool),&nb);
				res = iload->Read(&rendParams.allTertiary,sizeof(bool),&nb);
				res = iload->Read(&rendParams.timeLimitOn,sizeof(bool),&nb);
				res = iload->Read(&rendParams.useHydraGUI,sizeof(bool),&nb);
				res = iload->Read(&rendParams.useToneMapping,sizeof(bool),&nb);
				res = iload->Read(&rendParams.noRandomLightSel,sizeof(bool),&nb);
				res = iload->Read(&rendParams.debugOn,sizeof(bool),&nb);
				res = iload->Read(&rendParams.enableLog,sizeof(bool),&nb);
				res = iload->Read(&rendParams.enableDOF,sizeof(bool),&nb);
				res = iload->Read(&rendParams.primaryMLFilter,sizeof(bool),&nb);
				res = iload->Read(&rendParams.secondaryMLFilter,sizeof(bool),&nb);
				res = iload->Read(&rendParams.writeToDisk,sizeof(bool),&nb);
				res = iload->Read(&rendParams.timeLimit,sizeof(long),&nb);
				res = iload->Read(&rendParams.focalplane,sizeof(float),&nb);
				res = iload->Read(&rendParams.lensradius,sizeof(float),&nb);	
				break;
			case PATHTRACING_CHUNK:
				res = iload->Read(&rendParams.icBounce,sizeof(int),&nb);
				res = iload->Read(&rendParams.seed,sizeof(int),&nb);
				res = iload->Read(&rendParams.minrays,sizeof(int),&nb);
				res = iload->Read(&rendParams.maxrays,sizeof(int),&nb);
				res = iload->Read(&rendParams.raybounce,sizeof(int),&nb);
				res = iload->Read(&rendParams.diffbounce,sizeof(int),&nb);
				res = iload->Read(&rendParams.useRR,sizeof(int),&nb);
				res = iload->Read(&rendParams.causticRays,sizeof(int),&nb);
				res = iload->Read(&rendParams.relative_error,sizeof(float),&nb);
				res = iload->Read(&rendParams.guided, sizeof(bool), &nb);
				break;
			case IRRCACHE_CHUNK:
				res = iload->Read(&rendParams.ic_eval,sizeof(int),&nb);
				res = iload->Read(&rendParams.maxpass,sizeof(int),&nb);
				res = iload->Read(&rendParams.fixed_rays,sizeof(int),&nb);
				res = iload->Read(&rendParams.ws_err,sizeof(float),&nb);
				res = iload->Read(&rendParams.ss_err4,sizeof(float),&nb);
				res = iload->Read(&rendParams.ss_err2,sizeof(float),&nb);
				res = iload->Read(&rendParams.ss_err1,sizeof(float),&nb);
				res = iload->Read(&rendParams.ic_relative_error,sizeof(float),&nb);
				break;
			case MULTILAYER_CHUNK:
				res = iload->Read(&rendParams.layerNum,sizeof(int),&nb);
				res = iload->Read(&rendParams.r_sigma,sizeof(float),&nb);
				res = iload->Read(&rendParams.s_sigma,sizeof(float),&nb);
				res = iload->Read(&rendParams.filterPrimary,sizeof(bool),&nb);
				break;
			case SPPM_C_CHUNK:
				res = iload->Read(&rendParams.maxphotons_c,sizeof(int),&nb);
				res = iload->Read(&rendParams.retrace_c,sizeof(int),&nb);
				res = iload->Read(&rendParams.initial_radius_c,sizeof(float),&nb);
				res = iload->Read(&rendParams.caustic_power,sizeof(float),&nb);
				res = iload->Read(&rendParams.visibility_c,sizeof(bool),&nb);
				res = iload->Read(&rendParams.alpha_c,sizeof(float),&nb);
				break;
			case SPPM_D_CHUNK:
				res = iload->Read(&rendParams.maxphotons_d,sizeof(int),&nb);
				res = iload->Read(&rendParams.retrace_d,sizeof(int),&nb);
				res = iload->Read(&rendParams.initial_radius_d,sizeof(float),&nb);
				res = iload->Read(&rendParams.visibility_d,sizeof(bool),&nb);
				res = iload->Read(&rendParams.alpha_d,sizeof(float),&nb);
				res = iload->Read(&rendParams.irr_map,sizeof(bool),&nb);
				break;
			case TONEMAP_CHUNK:
				res = iload->Read(&rendParams.white_point,sizeof(float),&nb);
				res = iload->Read(&rendParams.gamma,sizeof(float),&nb);
				res = iload->Read(&rendParams.strength,sizeof(float),&nb);
				res = iload->Read(&rendParams.phi,sizeof(float),&nb);
				res = iload->Read(&rendParams.bloom,sizeof(bool),&nb);
				break;
			case ENVIRONMENT_CHUNK:
				res = iload->Read(&rendParams.env_mult,sizeof(float), &nb);
				break;
		}
		iload->CloseChunk();
		if (res!=IO_OK) 
			return res;
	}
	return IO_OK;
}


int hydraRender_mk3::Open(INode *scene, INode *vnode, ViewParams* viewPar, RendParams& rpar,HWND hwnd,DefaultLight* defaultLights,int numDefLights, RendProgressCallback* prog)
{
  int idx;
  plugin_log.Print("Entering HydraRender::Open");


  // Suspend undo, macro recorder, animation, auto backup, and maintain the "Save Required" flag
  //
  SuspendAll uberSuspend(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE); // ��� ���@�� ����E����?

  // Important!! This has to be done here in MAX Release 2!
  // Also enable it again in Renderer::Close()
  GetCOREInterface()->DisableSceneRedraw();

  if (!rpar.inMtlEdit)
    BroadcastNotification(NOTIFY_PRE_RENDER, (void*)(RendParams*)&rpar);	// skk  �E��� �� ���E�E

  // Get options from RenderParams
  // These are the options that are common to all renderers
  rendParams.bVideoColorCheck = rpar.colorCheck;
  rendParams.bForce2Sided     = rpar.force2Side;
  rendParams.bRenderHidden    = rpar.rendHidden;
  rendParams.bSuperBlack      = rpar.superBlack;
  rendParams.bRenderFields    = rpar.fieldRender;
  rendParams.bNetRender       = rpar.isNetRender;
  rendParams.rendType         = rpar.rendType;

	rendParams.inMtlEditor = rpar.inMtlEdit;

  // Default lights
  rendParams.nNumDefLights  = numDefLights;
  rendParams.pDefaultLights = defaultLights;

  // Support Render effects
  rendParams.effect = rpar.effect;

  rendParams.devWidth  = rpar.width;
  rendParams.devHeight = rpar.height;

  rendParams.nMinx     = 0;
  rendParams.nMiny     = 0;
  rendParams.nMaxx     = rendParams.devWidth;
  rendParams.nMaxy     = rendParams.devHeight;

	pScene = scene;
	pVnode = vnode;


	rendParams.gbufReader = NULL;
	rendParams.gbufWriter = NULL;

	m_hdrImageData.clear();

  // Flag we use when reporting errors
  bFirstFrame = TRUE;
  bUvMessageDone = FALSE;

  // Initialize node counter
  nCurNodeID = -1;  //skk - wtf ???

	//Animation
	rendParams.rendTimeType = GetCOREInterface()->GetRendTimeType();
	rendParams.rendStart = GetCOREInterface()->GetRendStart();
	rendParams.rendEnd = GetCOREInterface()->GetRendEnd();
	rendParams.nthFrame = GetCOREInterface()->GetRendNThFrame();
	rendParams.rendSaveFile = GetCOREInterface()->GetRendSaveFile();

	BitmapInfo bi;

	if (rendParams.rendSaveFile)
		bi = GetCOREInterface()->GetRendFileBI();

	plugin_log.PrintValue("Rendered Image path: ",bi.Filename());
  if (!rpar.inMtlEdit)
  {
    mtlEditorWasOpen = GetCOREInterface7()->IsMtlDlgShowing();
		GetCOREInterface7()->CloseMtlDlg();
  }
  else
  {
    if(m_pScanlineRender == NULL)
      m_pScanlineRender = GetCOREInterface()->CreateDefaultScanlineRenderer();
    
    if(m_pScanlineRender != NULL)
      m_pScanlineRender->Open(scene, vnode, viewPar, rpar, hwnd, defaultLights, numDefLights, prog);
  }

  plugin_log.Print("Leaving HydraRender::Open");

  return 1; 	
}


void hydraRender_mk3::Close(HWND hwnd, RendProgressCallback* prog)
{
  plugin_log.Print("Entering HydraRender::Close");
  GetCOREInterface()->EnableSceneRedraw();
  plugin_log.Print("Leaving HydraRender::Close");
	plugin_log.Print("----------------------||\n");
	plugin_log.CloseLog();
  if(m_pScanlineRender != NULL && rendParams.inMtlEditor)
    m_pScanlineRender->Close(hwnd, prog);

	//m_hdrImageData.clear();
	cameras.clear();
	materials.clear();
	lights.clear();
}


void hydraRender_mk3::SetProgTitle(const TCHAR *title) 
{
  if (rendParams.progCallback) 
    rendParams.progCallback->SetTitle(title);
}

float ReadProgressPercent(const char* a_str)
{
  std::string data(a_str);

  size_t pos1 = data.find(":");
  size_t pos2 = data.find("%");

  if(pos1 == std::string::npos || pos2 == std::string::npos)
    return 0.0f;

  float val = atof(data.substr(pos1+1, pos2-pos1-1).c_str());

  return val;
}

std::string MethodName(int a_name)
{
  if(a_name == RENDER_METHOD_PT)
    return "path_tracing";
  else if(a_name == RENDER_METHOD_SPPM)
    return "sppm";
  else if(a_name == RENDER_METHOD_IC)
    return "irradiance_cache";
  else
    return "none";
}

//
//
void hydraRender_mk3::FixPresets(TiXmlElement* root, int renderWidth, int renderHeight)
{
  if(root == NULL)
    return;

  char valueStr[128];
  sprintf(valueStr, "%dx%d", renderWidth, renderHeight);

  std::stringstream outStr;

  // general
  //
  outStr << renderWidth << 'x' << renderHeight << std::endl;
  FixValueXML(root, "resolution", valueStr);
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << int(this->rendParams.noRandomLightSel);
  FixValueXML(root, "norandomlight", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  // path tracing
  //
  outStr << this->rendParams.raybounce;
  FixValueXML(root, "trace_depth", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.diffbounce;   
  FixValueXML(root, "diff_trace_depth", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.maxrays;   
  FixValueXML(root, "maxRaysPerPixel", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.minrays;   
  FixValueXML(root, "minRaysPerPixel", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.relative_error;   
  FixValueXML(root, "pt_error", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.useRR;   
  FixValueXML(root, "ptEnableRoulette", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.causticRays;   
  FixValueXML(root, "ptCaustics", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  if(this->rendParams.seed == 1)
  {
    FixValueXML(root, "ptOneSeed",  "0");
    FixValueXML(root, "ptCoherent", "0");
  }
  else if(this->rendParams.seed == 2)
  {
    FixValueXML(root, "ptOneSeed",  "0");
    FixValueXML(root, "ptCoherent", "1");
  }
  else
  {
    FixValueXML(root, "ptOneSeed",  "1");
    FixValueXML(root, "ptCoherent", "0");
  }

  outStr << this->rendParams.guided;
  FixValueXML(root, "guided_pt", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok
  

  // SPPM (caustic)
  //
  outStr << this->rendParams.initial_radius_c;
  FixValueXML(root, "initialGartherRadiusCaustic", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.visibility_c;
  FixValueXML(root, "pmCausticVisibilityTracing", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.maxphotons_c*1000;
  FixValueXML(root, "maxCausticPhotons", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.caustic_power;
  FixValueXML(root, "causticPower", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.retrace_c;
  FixValueXML(root, "pmCausticFrequency", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << int(this->rendParams.alpha_c);
  FixValueXML(root, "sppmc_alpha", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 


  // SPPM (diffuse)
  //
  outStr << this->rendParams.initial_radius_d;
  FixValueXML(root, "initialGartherRadius", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.visibility_d;
  FixValueXML(root, "pmDiffuseVisibilityTracing", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.maxphotons_d*1000; 
  FixValueXML(root, "maxDiffusePhotons", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.retrace_d;
  FixValueXML(root, "pmDiffuseFrequency", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << int(this->rendParams.irr_map);
  FixValueXML(root, "sppmd_irrad_map", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 
 
  outStr << int(this->rendParams.alpha_d);
  FixValueXML(root, "sppmd_alpha", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  // Irradiance Cache
  //
  
  if(this->rendParams.ic_eval == 0)
    FixValueXML(root, "icEvalAlg", "fixed");
  else
    FixValueXML(root, "icEvalAlg", "progressive");

  //plugin_log.PrintValue("this->fixed_rays ", this->fixed_rays);

  sprintf(valueStr, "%d", this->rendParams.fixed_rays);
  FixValueXML(root, "icFixedRays", valueStr);

  sprintf(valueStr, "%d", this->rendParams.maxpass);
  FixValueXML(root, "icMaxPassesNum", valueStr);

  outStr << this->rendParams.ss_err4;
  FixValueXML(root, "icSSError4", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 
  
  outStr << this->rendParams.ss_err2;
  FixValueXML(root, "icSSError2", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 
  
  outStr << this->rendParams.ss_err1;
  FixValueXML(root, "icSSError1", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.ic_relative_error*0.01f;
  FixValueXML(root, "icError", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.ws_err;
  FixValueXML(root, "icWSError", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.icBounce;
  FixValueXML(root, "icBounce", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  // DOF
  //
  outStr << this->rendParams.enableDOF;
  FixValueXML(root, "enableDOF", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.focalplane;
  FixValueXML(root, "dofFocalPlaneDist", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.lensradius;
  FixValueXML(root, "dofLensRadius", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  // other
  //

  if(gammaMgr.IsEnabled())
    this->rendParams.gamma = gammaMgr.GetDisplayGamma();

  outStr << this->rendParams.gamma;
  FixValueXML(root, "tmGamma", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  float inputGamma = gammaMgr.GetFileInGamma();
  outStr << inputGamma;
  FixValueXML(root, "texInputGamma", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  outStr << this->rendParams.enableLog;
  FixValueXML(root, "outputRedirect", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  // Manual Settings
  //
  outStr << this->rendParams.manualMode;
  FixValueXML(root, "method_manual", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); 

  std::string primaryMethod = MethodName(this->rendParams.primary);

  if(rendParams.primaryMLFilter || rendParams.secondaryMLFilter)
    primaryMethod = "multilayered";

  outStr << primaryMethod.c_str();
  FixValueXML(root, "method_primary", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << MethodName(this->rendParams.secondary);
  FixValueXML(root, "method_secondary", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << MethodName(this->rendParams.tertiary);
  FixValueXML(root, "method_tertiary", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.allSecondary;
  FixValueXML(root, "all_secondary", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  outStr << this->rendParams.allTertiary;
  FixValueXML(root, "all_tertiary", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  if(this->rendParams.causticsMode == 0)
    outStr << "none";
  else if(this->rendParams.causticsMode == 1)
    outStr << "sppm";
  else
    outStr << "path_tracing";

  FixValueXML(root, "method_caustic", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  // <nowindow> 1 </nowindow>
  // 
  outStr << 1;
  FixValueXML(root, "nowindow", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // ok

  // multy-layered
  //
  outStr << int(this->rendParams.s_sigma);
  FixValueXML(root, "mlRadius", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // 

  outStr << int(this->rendParams.r_sigma);
  FixValueXML(root, "mlSigma", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // 

  outStr << int(this->rendParams.primaryMLFilter);
  FixValueXML(root, "mlfilterPrimary", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // 

  outStr << int(1);
  FixValueXML(root, "mlLayerNum", outStr.str());
  outStr.seekp(std::ios_base::beg); outStr.str(""); // 

  // is still needed ?
  //
  std::ofstream fout("C:\\[Hydra]\\filter\\settings.txt");

  fout << 6 << std::endl;
  fout << 1 << std::endl;
  fout << 1 << std::endl;
  fout << 1 << std::endl;
  fout << rendParams.r_sigma << std::endl;
  fout << rendParams.s_sigma << std::endl;
  fout << 2 << std::endl;
  fout << 0 << " " << 0 << " " << 0 << " " << 0 << " " << 0 << " " << 0 << " " << 0 << " " << std::endl;
  fout << rendParams.layerNum << std::endl;

}

void hydraRender_mk3::FixGuiByMethod(HydraRenderParamDlg* pGuiParams, int rendMethod, int rendQuality)
{
  std::string presets = GetMethodPresets(rendMethod, rendQuality);
      
  TiXmlDocument doc;
  doc.Parse(presets.c_str(), 0, TIXML_ENCODING_UTF8);

  TiXmlHandle docHandle(&doc);
  TiXmlElement* root = docHandle.FirstChild("hydra_presets").Element();

  int maxRaysPerPixel = GetIntValueXML(root, "maxRaysPerPixel");
  int minRaysPerPixel = GetIntValueXML(root, "minRaysPerPixel");

  pGuiParams->minrays_spin->SetValue(minRaysPerPixel, FALSE); 
  pGuiParams->minrays_edit->SetText(minRaysPerPixel);

  pGuiParams->maxrays_spin->SetValue(maxRaysPerPixel, FALSE); 
  pGuiParams->maxrays_edit->SetText(maxRaysPerPixel);


}

void hydraRender_mk3::FixGuiForManualSettings(HydraRenderParamDlg* pGuiParams)
{
  int primary   = SendDlgItemMessage(pGuiParams->hMain, IDC_PRIMARY, CB_GETCURSEL, 0, 0);
  int secondary = SendDlgItemMessage(pGuiParams->hMain, IDC_SECONDARY, CB_GETCURSEL, 0, 0);
  int tertiary  = SendDlgItemMessage(pGuiParams->hMain, IDC_TERTIARY, CB_GETCURSEL, 0, 0);
  int caustics  = SendDlgItemMessage(pGuiParams->hMain, IDC_CAUSTICS, CB_GETCURSEL, 0, 0);

  // increase min rays per pixel if sppm used
  //
  if(primary == RENDER_METHOD_SPPM || secondary == RENDER_METHOD_SPPM || caustics == RENDER_METHOD_SPPM)
  {
    int minRaysPerPixel = 1024;
    pGuiParams->minrays_spin->SetValue(minRaysPerPixel, FALSE); 
    pGuiParams->minrays_edit->SetText(minRaysPerPixel);
  }

  // limit max rays per pixel for multy-layered and ic
  //
  if(primary == RENDER_METHOD_IC || rendParams.primaryMLFilter || rendParams.secondaryMLFilter) 
  {
    // int maxRaysPerPixel = 512;
    // pGuiParams->maxrays_spin->SetValue(maxRaysPerPixel, FALSE); 
    // pGuiParams->maxrays_edit->SetText(maxRaysPerPixel);
  }

  if((primary == RENDER_METHOD_PT) && (secondary == RENDER_METHOD_PT) && (caustics =! RENDER_METHOD_SPPM))
  {
    // int minRaysPerPixel = 64;
    // pGuiParams->minrays_spin->SetValue(minRaysPerPixel, FALSE);
    // pGuiParams->minrays_edit->SetText(minRaysPerPixel);
  }

}

void hydraRender_mk3::ToneMap(Bitmap* tobm, int renderHeight, int renderWidth)
{
	plugin_log.Print("Entering ToneMap");
	std::vector<BMM_Color_fl> line(renderWidth);

	PP_FILTERS::ToneMappingFilter filter;
  PP_FILTERS::ToneMappingFilter::Presets hdrPresets;
	PP_FILTERS::Image src, dst;

  hdrPresets.strength   = rendParams.strength;
  hdrPresets.phi        = rendParams.phi;
  hdrPresets.whitePoint = rendParams.white_point;
  filter.SetPresets(hdrPresets);
	//src.CreateStandard(renderWidth, renderHeight);
  src.CreateLocked(&m_hdrImageData[0], renderWidth, renderHeight, renderWidth*3, 3);
  float* srcPtr = src.GetPointer();
	
  if(m_hdrImageData.size() < renderWidth*renderHeight*3)
    return;

	for(int i=0;i<renderWidth*renderHeight;i++)
  {
		srcPtr[3*i+0] = m_hdrImageData[3*i+0];
    srcPtr[3*i+1] = m_hdrImageData[3*i+1];
    srcPtr[3*i+2] = m_hdrImageData[3*i+2];
  }
  
  dst.CreateStandard(renderWidth, renderHeight);
  filter.Apply(&dst, &src);
	
	float* dstPtr = dst.GetPointer();

	for (int y = 0; y < renderHeight; y++) 
  {
    int offset = (renderHeight - y - 1)*renderWidth;

		for(int x = 0; x < renderWidth; x++)
    {
      int index = offset + x;

			float r = dstPtr[index*3 + 0];
			float g = dstPtr[index*3 + 1];
			float b = dstPtr[index*3 + 2];
			float a = 0.0; //image[y*renderWidth + x];

      line[x] = BMM_Color_fl(r,g,b,a);
    }

    tobm->PutPixels(0, y, renderWidth, &line[0]);
  }

	
	tobm->RefreshWindow(NULL);
	if(tobm->GetWindow())
		UpdateWindow(tobm->GetWindow());

	plugin_log.Print("Leaving ToneMap");
}



void hydraRender_mk3::copyBitmap(Bitmap* from, Bitmap* to)
{	
	int renderWidth  = rendParams.nMaxx - rendParams.nMinx;
  int renderHeight = rendParams.nMaxy - rendParams.nMiny;

	std::vector<BMM_Color_fl> line(renderWidth);

	for (int y = rendParams.nMiny; y < rendParams.nMaxy; y++) 
	{
		from->GetPixels(0, y, renderWidth, &line[0]);
		to->PutPixels(0, y, renderWidth, &line[0]);
	}
}

void hydraRender_mk3::displayLastRender()
{	
	last_render->RefreshWindow(NULL);
	if (last_render->GetWindow())
	{
		UpdateWindow(last_render->GetWindow());
		plugin_log.Print("display last render");
	}
}

int hydraRender_mk3::Render(TimeValue t, Bitmap* tobm, FrameRendParams &frp, HWND hwnd, RendProgressCallback* prog, ViewParams* viewPar)
{
	plugin_log.Print("Entering HydraRender::Render");

	if (!tobm)
	{
		plugin_log.Print("tobm == NULL, No output bitmap, not much we can do");
		return 0; // No output bitmap, not much we can do.
	}

	rendParams.progCallback = prog;
	rendParams.devWidth     = tobm->Width();
	rendParams.devHeight    = tobm->Height();
	rendParams.devAspect    = tobm->Aspect();
	rendParams.time         = t;
	rendParams.pFrp         = &frp;

	rendParams.nMinx = 0;
	rendParams.nMiny = 0;
	rendParams.nMaxx = rendParams.devWidth;
	rendParams.nMaxy = rendParams.devHeight;


	/*tobm->Storage()->bi.SetType(BMM_REALPIX_32);*/
	

	/*rendParams.gbufChan.SetSize(NUMGBCHAN);
	rendParams.gbufChan.ClearAll();*/

	rendParams.gbufReader = NULL;
	rendParams.gbufWriter = NULL;
	ULONG origGBufChannels = tobm->ChannelsPresent();
	tobm->CreateChannels(BMM_CHAN_REALPIX);

	GBuffer *gb = tobm->GetGBuffer();
	if (gb) 
	{
		gb->InitBuffer();
		rendParams.gbufWriter = gb->CreateWriter();	
		rendParams.gbufReader = gb->CreateReader();
	}

	ULONG chan = tobm->ChannelsPresent();

	ULONG ctype;
	pGbufRealPix = NULL;
	if (chan & BMM_CHAN_REALPIX) 
	{
		//rendParams.gbufChan.Set(BMM_CHAN_REALPIX);
		pGbufRealPix = (RealPixel*)tobm->GetChannel(BMM_CHAN_REALPIX, ctype);
	}

	/*
	*/

	if(rendParams.inMtlEditor) 
	{
    if(m_pScanlineRender != NULL)
      m_pScanlineRender->Render(t, tobm, frp, hwnd, prog, viewPar);
    else
		  tobm->Fill(BMM_Color_fl(0,0,0,0));
	}
	else
	{
		if (isFileExist("C:\\[Hydra]\\bin\\hydra.exe"))
			DoExport(pScene, pVnode, viewPar, t);
		else
			MessageBoxA(NULL, "Can't find 'C:\\[Hydra]\\bin\\hydra.exe', perhaps forgot copy Hydra folder to 'C:\\' ?", "Critical error", MB_OK);

		if (rendParams.rendTimeType != REND_TIMESINGLE)
		{
			writeXML(t);
		}

		if (!incl.geomObjNum)
		{
			plugin_log.Print("Empty scene.");
			return 0; // No output bitmap, not much we can do.
		}

		if (prog) 
			prog->SetTitle(L"Waiting for hydra.exe to start rendering ...");

		plugin_log.Print("before CreateHydraServerConnection");

		//
		//
		IHydraNetPluginAPI* pConnection = CreateHydraServerConnection();

		if(pConnection == NULL || !pConnection->hasConnection())
		{
			if (prog) 
				prog->SetTitle(L"Can't connect to hydra_server.exe  ...");
			plugin_log.Print("Can't connect to hydra_server.exe");
			Sleep(10);
			return 0;
		}

		int renderWidth  = rendParams.nMaxx - rendParams.nMinx;
		int renderHeight = rendParams.nMaxy - rendParams.nMiny;

		plugin_log.Print("after CreateHydraServerConnection");

		// get predefined presets and update some of them
		//
		if(pConnection->hasConnection())
		{
			if(!this->rendParams.useHydraGUI) // if so, take presets from external gui
			{
				std::string presets = GetMethodPresets(0,0);//(this->renderMethod, this->renderQuality);
      
				TiXmlDocument doc;
				doc.Parse(presets.c_str(), 0, TIXML_ENCODING_UTF8);

				if(doc.Error())
				{
					plugin_log.Print("Error parsing presets xml");
					return 0;
				}

				TiXmlHandle docHandle(&doc);
				TiXmlElement* root = docHandle.FirstChild("hydra_presets").Element();

				if(root != NULL)
				{
					FixPresets(root, renderWidth, renderHeight);

					TiXmlPrinter printer;  // Declare a printer    
					doc.Accept(&printer);  // attach it to the document you want to convert in to a std::string 

					pConnection->updatePresets(printer.CStr());

          std::ofstream outSettings("C:\\[Hydra]\\pluginFiles\\settings.xml");
          outSettings << printer.CStr();
          outSettings.close();
				}

			}
		}
		else
    {
      if(prog) 
			  prog->SetTitle(L"No connection with server (perhaps you forgot to copy [Hydra] folder to C:\ ?)");
	    plugin_log.Print("no connection ... ");
    }

		plugin_log.Print("presets changed");

		
		plugin_log.PrintValue("IsHDR: ", tobm->IsHighDynamicRange());

		//std::vector<BMM_Color_64> line(renderWidth);
		std::vector<BMM_Color_fl> line(renderWidth);
  
		float progressVal = 0.0f;

		std::clock_t start;
		double duration;

		start = std::clock();		

		while(true)
		{
			if(pConnection->haveNewImageFromServer())
			{
				//unsigned int* imageData = (unsigned int*)pConnection->mapImageData();
				float* imageData =  (float*)pConnection->mapImageData(); 

				if(imageData == NULL)
				{
					if(prog) 
						prog->SetTitle(L"Image data not found ...");
					plugin_log.Print("Image data not found");
					Sleep(1000);
					break;
				}

				for (int y = rendParams.nMiny; y < rendParams.nMaxy; y++) 
				{
					// copy one line
					//
					if (rendParams.gbufWriter) rendParams.gbufWriter->StartLine(y);

					int offset = (renderHeight - y - 1)*renderWidth*4;
					for(int x=0;x<renderWidth;x++)
					{
						float r = imageData[offset + x*4 + 0];
						float g = imageData[offset + x*4 + 1];
						float b = imageData[offset + x*4 + 2];
						float a = imageData[offset + x*4 + 3];

						line[x] = BMM_Color_fl(r,g,b,a);

						int gbufIndex = y*rendParams.devWidth + x;

						// GBuffer support
						if (rendParams.gbufWriter) rendParams.gbufWriter->StartPixel(x);
						if (rendParams.gbufWriter) rendParams.gbufWriter->StartNextLayer();

						RealPixel rpix;
						rpix = MakeRealPixel(r, g, b);
						pGbufRealPix[gbufIndex] = rpix;
						

					}

					tobm->PutPixels(0, y, renderWidth, &line[0]);
				}
    
        if(imageData != NULL)
        {
          if(m_hdrImageData.size() != renderWidth*renderHeight*3)
            m_hdrImageData.resize(renderWidth*renderHeight*3);

          for(int i=0;i<renderWidth*renderHeight;i++)
          {
            m_hdrImageData[i*3+0] = imageData[i*4+0];
            m_hdrImageData[i*3+1] = imageData[i*4+1];
            m_hdrImageData[i*3+2] = imageData[i*4+2];
          }

          //memcpy(&m_hdrImageData[0], imageData, renderWidth*renderHeight*4*sizeof(float));
        }

				tobm->RefreshWindow(NULL);
				if (tobm->GetWindow())
					UpdateWindow(tobm->GetWindow());

				pConnection->unmapImageData(); 

				if(pConnection->lastImageWasFinal())
				{ 
					break;
				}	
			}
    
			if(pConnection->haveAnyMessageFromServer())
			{
				char message[64];
				memset(message,0,64);
				pConnection->recieveFromServer(message, 64);
      
				if(std::string(message).substr(0,10) == "exitServer")
				{
					pConnection->sendToServer("exitnow", strlen("exitnow")+1);
					break;
				}

				progressVal = ReadProgressPercent(message);

				if (prog)
					prog->SetTitle(ToWideString(message).c_str());
			}

			// Update progress bar and check for cancel
			//
			if (prog && (prog->Progress(int(progressVal), 100) == RENDPROG_ABORT)) 
			{
				tobm->ShowProgressLine(-1);	// Clear progress line
				pConnection->sendToServer("exitnow", strlen("exitnow")+1);
				//Sleep(2000);
				break;
			}
      else
      {
        //prog->SetCurField(FIELD_FIRST);
        //prog->SetCurField(FIELD_SECOND);
      }
    
			if(rendParams.timeLimitOn)
			{
				duration = ( std::clock() - start ) / (double) CLOCKS_PER_SEC;
				if((long)duration > rendParams.timeLimit)
				{
					pConnection->sendToServer("exitnow", strlen("exitnow")+1);
					break;
				}
			}

			Sleep(10);
		}

		if(rendParams.useToneMapping)
			ToneMap(tobm, renderHeight, renderWidth);

		delete pConnection;

		if (prog)
			prog->SetTitle(L"Done.");

		procTexMD5s.clear();
    materialByAddress.clear();
		material_dict_max_index.clear();
		

		chan = tobm->ChannelsPresent()&(~origGBufChannels);
		if (chan)
			tobm->DeleteChannels(chan);

		if (gb) 
		{
			if (rendParams.gbufReader) 
			{
				gb->DestroyReader(rendParams.gbufReader);
				rendParams.gbufReader = NULL;
			}
			if (rendParams.gbufWriter) 
			{
				gb->DestroyWriter(rendParams.gbufWriter);
				rendParams.gbufWriter = NULL;
			}
		}

		//procTexToCheck = 0;
	
	/*	for(int i = 0; i < 128; i++)
			procTexs[i] = NULL;*/
		
		procTexsV.clear();
		procTexNames.clear();
		last_render = tobm;
	}

  if(mtlEditorWasOpen)
  {
    GetCOREInterface7()->OpenMtlDlg();
    mtlEditorWasOpen = FALSE;
  }

  return 1;
}


HydraRenderParams::HydraRenderParams()
{
  SetDefaults();

  envMap = NULL;
  atmos = NULL;
  rendType = RENDTYPE_NORMAL;
  nMinx = 0;
  nMiny = 0;
  nMaxx = 0;
  nMaxy = 0;
  nNumDefLights = 0;
  scrDUV = Point2(0.0f, 0.0f);
  pDefaultLights = NULL;
  pFrp = NULL;
  bVideoColorCheck = 0;
  bForce2Sided = FALSE;
  bRenderHidden = FALSE;
  bSuperBlack = FALSE;
  bRenderFields = FALSE;
  bNetRender = FALSE;

  renderer = NULL;
  projType = PROJ_PERSPECTIVE;
  devWidth = 0;
  devHeight = 0;
  xscale = 0;
  yscale = 0;
  xc = 0;
  yc = 0;
  antialias = FALSE;
  nearRange = 0;
  farRange = 0;
  devAspect = 0;
  frameDur = 0;
  time = 0;
  wireMode = FALSE;
  inMtlEdit = FALSE;
  fieldRender = FALSE;
  first_field = FALSE;
  field_order = FALSE;
  objMotBlur = FALSE;
  nBlurFrames = 0;


	rendTimeType = REND_TIMESINGLE;
	rendStart = GetCOREInterface()->GetAnimRange().End() / GetTicksPerFrame();
	rendEnd = GetCOREInterface()->GetAnimRange().End() / GetTicksPerFrame();
	nthFrame = 1;
	rendSaveFile = FALSE;
}

void HydraRenderParams::SetDefaults()
{
	//main
	primary = 0;
	secondary = 0;
	tertiary = 0;
	causticsMode = 0;
	timeLimitOn = false;
	timeLimit = 0;
  useHydraGUI   = false;
  useToneMapping   = false;
	enableDOF = false;
	noRandomLightSel = false;
	enableLog = false;
  focalplane = 8;
  lensradius = 0.05;
	debugOn = false;
	allSecondary = false;
	allTertiary = false;
	primaryMLFilter = false;
	secondaryMLFilter = false;
	writeToDisk = false;

	//path tracing
  seed  = 1;
  causticRays = 0;
  minrays = 16;
  maxrays = 1024;
  raybounce = 4;
  diffbounce = 2;
  relative_error = 5;
	guided = false;

  //SPPM Caustics
  maxphotons_c = 1000;
  caustic_power = 1;
  retrace_c = 4;
  initial_radius_c = 4;
  visibility_c     = false;
	alpha_c = 0.66;

  //SPPM Diffuse
  maxphotons_d = 1000;
  retrace_d        = 1;
  initial_radius_d = 10;
  visibility_d = false;
	alpha_d = 0.66;
	irr_map = false;

  //Irradiance cache
  ic_eval = 0;
  maxpass = 16;
  fixed_rays = 1024;
  ws_err = 40;
  ss_err4 = 16;
  ss_err2 = 4;
  ss_err1 = 1;
  ic_relative_error = 10;

	//Multi-Layer
	filterPrimary = false;
	r_sigma = 2.5;
	s_sigma = 5;
	layerNum = 1;

  //Tone mapping
  white_point = 2.5;
  gamma = 2.2;
  strength = 0.25;
  phi = 16;
  bloom = false;
  icBounce = 0;

	//Environment
	env_mult = 1.0f;


	rendTimeType = REND_TIMESINGLE;
	rendStart = GetCOREInterface()->GetAnimRange().End() / GetTicksPerFrame();
	rendEnd = GetCOREInterface()->GetAnimRange().End() / GetTicksPerFrame();
	nthFrame = 1;
	rendSaveFile = FALSE;
}


#define VIEW_DEFAULT_WIDTH ((float)400.0)

void HydraRenderParams::ComputeViewParams(const ViewParams&vp)
{
}


Point3 HydraRenderParams::RayDirection(float sx, float sy)
{
  Point3 p;
  p.x = -(sx-xc)/xscale; 
  p.y = -(sy-yc)/yscale; 
  p.z = -1.0f;
  return Normalize(p);
}


int HydraRenderParams::NumRenderInstances()
{

  return 0;
}

RenderInstance* HydraRenderParams::GetRenderInstance(int i)
{

  return NULL;
}


Point2 MyView::ViewToScreen(Point3 p)
{
  return pRendParams->MapToScreen(p);
}

ClassDesc2* GethydraRender_mk3Desc() 
{ 
  return &hydraRender_mk3Desc; 
}
