#ifndef __IMPORTSTRUCTS_H__
#define __IMPORTSTRUCTS_H__

#include <vector>
#include <string>

struct VNorm
{
  VNorm() : nextOffInPool(-1), avgNorm(0,0,0), smooth(0), init(false), invalid(false) {}
  VNorm(Point3 n, DWORD a_smooth) : nextOffInPool(-1), avgNorm(n), smooth(a_smooth), init(true), invalid(false) {}

  void AddNormal(Point3 n, DWORD s, std::vector<VNorm>& a_pool);
  void Normalize(std::vector<VNorm>& a_pool);
  Point3 GetNormal(DWORD a_smGroup, std::vector<VNorm>& a_pool, bool& a_invalid);

  Point3 avgNorm;
  DWORD smooth;
  bool init;
  bool invalid;
  int nextOffInPool;
};


struct GeometryObj
{
  GeometryObj()
  {
    clear();
  }

  float m[16];
  int n_verts;
  int n_faces;
  std::wstring mesh_id;
  
  std::vector<int> material_id;
  
  std::vector<float> positions;
  std::vector<int> pos_indeces;

  std::vector<int> face_smoothgroups;

  std::vector<VNorm> vnorms;
  std::vector<VNorm> vnormsMemoryPool;
  std::vector<int>   vNormsKeys;

  std::vector<float> normsSpecified; // like in Open Collada plugin
  std::vector<int>   normsSpecIndices;

  std::vector<float> tex_coords;
  std::vector<int>   tex_coords_indices;
  
  float bbox[6];

	template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & m;
    ar & n_verts;
		ar & n_faces;
		ar & mesh_id;
		ar & material_id;
		ar & positions;
		ar & pos_indeces;
    ar & face_smoothgroups;
		ar & tex_coords;
    ar & tex_coords_indices;
    ar & bbox;
  }

  void clear()
  {
    n_verts = 0;
    n_faces = 0;

    material_id.resize(0);
    positions.resize(0);
    pos_indeces.resize(0);
    face_smoothgroups.resize(0);
    tex_coords.resize(0);
    tex_coords_indices.resize(0);
    
    vnorms           = std::vector<VNorm>();
    vnormsMemoryPool = std::vector<VNorm>();
    vNormsKeys       = std::vector<int>();
    normsSpecified   = std::vector<float>();
    normsSpecIndices = std::vector<int>();
  }

  void reserveMemory(int n)
  {
    n_verts = 0;
    n_faces = 0;

    pos_indeces.reserve(3*n);
    positions.reserve(n);
    vnorms.reserve(n);
    material_id.reserve(n/10);
    tex_coords_indices.reserve(3*n);
    tex_coords.reserve(n);
  }


};


struct CameraObj
{
  CameraObj()
  {
    fov = 45;
    nearClipPlane = 0.001f;
    farClipPlane  = 10000.0f;
    zoom = 1.0f;

    dofEnabled = false;
    isOrtho = false;
  }

  float fov;
  float farClipPlane;
  float nearClipPlane;
  float direction[3];
  float zoom;

  float dofFocalDist;
  float dofStrength;
  bool  dofEnabled;

  bool  isOrtho;
  bool  isTargeted;

  float posMatrix[16];
  float targetMatrix[16];
  float worldViewMatrix[16];

	bool isAnimated;
	int frames;
	std::vector <std::string> perFrame;

  std::wstring camName;

};


struct LightObj
{
  enum LDISTRIBTYPES{ LD_UNIFORM = 0, LD_DIFFUSE = 1, LD_SPOT = 2, LD_RAYSET = 3};

  LightObj()
  {
    for(int i=0;i<3;i++)
    {
      position[i]  = 0;
      direction[i] = 0;
      color[i]     = 0;
      colorSecondary[i] = 0;
    }

    intensity = 0;
    lightName        = L"default_name";
    skyPortalEnvMode = L"environment"; 
    skyPortalEnvTex  = L""; 

    for(int k=0;k<4;k++)
    {
      for(int j=0;j<4;j++)
      {
        float val = (k == j) ? 1.0f : 0.0f; 
        m[j*4+k] = val;
        targetMatrix[j*4+k] = val;
      }
    }

    isTargeted   = false;
    on           = true;
    isVisiable   = true;
    causticLight = false;

    directLightStart = 0.0f;
    envTexAmt = 1.0f;
    kc = 1.0f; kl = 0.0f; kq = 0.0f;

    lightDitributionType = LD_UNIFORM;
    useSeparateDiffuseLight = false;

  }

  std::wstring lightName;
  std::wstring lightType;
  std::wstring shadowType;
  std::wstring spotShape;
  std::wstring envTexturePath;
	std::string envTextureSampler;

  std::wstring skyPortalEnvMode; 
  std::wstring skyPortalEnvTex; 
	std::string skyPortalEnvTexSampler;

  ///////////////////////////////////// for skylight only
  // this will influence only on diffuse surfaces
  //
  std::wstring envTexturePathSecondary; 
	std::string envTextureSamplerSecondary;
  float        colorSecondary[3];  
  bool         useSeparateDiffuseLight;
  ///////////////////////////////////// for skylight only

  int lightDitributionType;

  bool useGlobal;
  bool absMapBias;
  bool overshoot;
  bool on;
  bool computeShadow;
  bool isTargeted;
  bool isVisiable;
  bool causticLight;
  bool mrDisablePhotonsD;
  bool mrDisablePhotonsC;

  float position[3];
  float direction[3];
  float color[3];

  float intensity;
  float aspect;
  float hotsize;
  float fallsize;
  float attenStart;
  float attenEnd;
  float TDist;
  float kc,kl,kq;
  float directLightStart;
  float envTexAmt;

  float mapBias;
  float mapRange;
  float mapSize;
  float rayBias;

  float sizeX;
  float sizeY;

  float m[16];
  float targetMatrix[16];
};

struct TextureObj
{
	std::wstring texName;
	std::wstring texClass;
	std::wstring mapName;
	std::wstring texFilter;
	std::wstring mapType;

  std::wstring normalMapPath;
  std::wstring displacementMapPath;
  float displacementAmount;

	bool texInvert;

  bool isBump;
  bool hasNormals;
  bool hasDisplacement;
  bool nmFlipRed;
  bool nmFlipGreen;
  bool nmSwapRedAndGreen;

	float uOffset;
	float vOffset;
	float uTiling;
	float vTiling;
	
  float cporuoffs;
  float cporvoffs;
  float cropuscale;
  float cropvscale;
  
  float angle;
  float angleUVW[3];
	float blur;
	float blurOffset;
	float noiseAmt;
	float noiseSize;
	int noiseLevel;
  int texTilingFlags;
	float noisePhase;
  float texAmount;


  TextureObj()
  {
    texInvert   = false;
    isBump      = false;
    hasNormals  = false;
    hasDisplacement = false;
    nmFlipRed   = false;
    nmFlipGreen = false;
    nmSwapRedAndGreen = false;

    uOffset    = 0.0f;
    vOffset    = 0.0f;
    uTiling    = 1.0f;
    vTiling    = 1.0f;

    cporuoffs  = 0.0f;
    cporvoffs  = 0.0f;
    cropuscale = 1.0f;
    cropvscale = 1.0f;

    angle      = 0;
    blur       = 0;
    blurOffset = 0;
    noiseAmt   = 0;
    noiseSize  = 0;
    noiseLevel = 0;
    noisePhase = 0;
    displacementAmount = 0.0f;
  }

};

struct MaterialObj
{
	bool sub;
  bool isHydraNative;
	bool isVrayMtl;

	int id;
	std::wstring name;
	float ambient_color [3];
	float diffuse_color [3];
	float specular_color[3];
  float filter_color  [3];
  float emission_color[3];
	float shininess;
	float shine_strength;
	float transparency;
	//float wire_size;
	std::wstring shading;
  float opacity;
  float IOR;
	float opacity_falloff;
	float self_illumination;
	bool twosided;
  bool affect_shadows_on;
	/*bool wire;
	bool wire_units; //true - units, false - pixels*/
	bool falloff; //true - out, false - in
	bool facemap;
	bool soften;
	bool no_ic_records;
	std::wstring transparency_type;
	int num_subMat;

	bool lock_specular, hilight_gloss_tex, refr_gloss_tex, reflect_gloss_tex;
  float reflect_color[3];
  float transparency_color[3];
  float fog_color[3];
  float exit_color[3];
	float translucency_color[3];
  bool displacement_on, displacement_invert_height_on, diffuse_mult_on, specular_mult_on, emission_mult_on, transparency_mult_on, reflect_mult_on, transparency_thin_on;
	bool specular_fresnel_on, reflect_fresnel_on, emission_gi, shadow_matte, translucency_mult_on;
	int specular_gloss_or_cos, reflect_gloss_or_cos, transparency_gloss_or_cos;
  float specular_ior, reflect_ior, specular_roughness, reflect_roughness, reflect_cospower, transparency_cospower, specular_cospower, fog_multiplier, displacement_height, diffuse_mult, specular_mult, emission_mult, transparency_mult, reflect_mult;
	float specular_glossiness, reflect_glossiness, transparency_glossiness, bump_amount, bump_radius, bump_sigma, translucency_mult;
  int specular_brdf, reflect_brdf; 
	
	std::vector<TextureObj>   textures;
  std::vector<std::wstring> textureSlotNames;
  std::vector<float>        textureAmount;

  MaterialObj()
  {
    for(int i = 0; i < 3; i++)
      ambient_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      diffuse_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      specular_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      filter_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      reflect_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      transparency_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      fog_color[i] = 0;
  
    for(int i = 0; i < 3; i++)
      exit_color[i] = 0;

		for (int i = 0; i < 3; i++)
			translucency_color[i] = 0;
  
    isHydraNative = false;
	 	isVrayMtl = false;
    displacement_on = false;
    displacement_invert_height_on = false;
    diffuse_mult_on = false;
    specular_mult_on = false;
    emission_mult_on = false;
    transparency_mult_on = false;
    reflect_mult_on = false;
    transparency_thin_on = false;
	 	no_ic_records = false;
	 	lock_specular = true;
	 	hilight_gloss_tex = false;
	 	refr_gloss_tex = false;
	 	reflect_gloss_tex = false;
		translucency_mult_on = false;
  
	 	specular_ior = 0;
	   reflect_ior = 0;
    reflect_roughness = 0;
	 	specular_roughness = 0;
    reflect_cospower = 0;
    transparency_cospower = 0;
	 	specular_cospower = 0;
    fog_multiplier = 0;
    displacement_height = 0;
    diffuse_mult = 0;
    specular_mult = 0;
    emission_mult = 0;
    transparency_mult = 0;
    reflect_mult = 0;
		translucency_mult = 0;
  
    specular_brdf = 0;
    reflect_brdf = 0;
  
    shininess = 0;
    shine_strength = 0;
    transparency = 0;
    std::wstring shading = L"";
    opacity = 0;
    IOR = 0;
    opacity_falloff = 0;
    self_illumination = 0;
    twosided = false;
    falloff = false; 
    facemap = false;
    soften = false;
    sub = false;
    transparency_type = L"";
  
	 	specular_gloss_or_cos = 1;
	 	reflect_gloss_or_cos = 1;
	 	transparency_gloss_or_cos = 1;
	 	specular_glossiness = 1;
	 	reflect_glossiness = 1;
	 	transparency_glossiness = 1;
	 	specular_fresnel_on = false;
	 	reflect_fresnel_on = false;
	 	bump_amount = 0.0f;
  
	 	shadow_matte = false;
	 	emission_gi = true;
	 	bump_radius = 1.0f;
	 	bump_sigma = 1.5f;
  
    id = 0;
    name = L"hydra_material_null";
    num_subMat = 0;
  }
  
  inline int FindTextureSlot(const std::wstring* a_slotNames, int a_size) const
  {
    for(int i=0;i<textureSlotNames.size();i++)
    {
      for(int j=0;j<a_size;j++)
      {
        const std::wstring& a_slotName = a_slotNames[j];
        if(a_slotName == textureSlotNames[i])
          return i;
      }
    }
  
    return -1;
  }

};

struct TransferContents
{
  enum {SCENE, TEXTURE_FILES, VRSCENE_FILE, CONFIG, RENDER_SETTINGS, HEADER};
  int contents;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & contents;
  }

};

struct Header
{
  enum {COLLADA_PROFILE, TEXTURE_FILE};
  int contents;
  std::wstring file_name;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & contents;
    ar & file_name;
  }

};

struct Included
{
  bool geometry;
  bool lights;
  bool materials;
  bool tree;
  bool spheres;

  std::string sceneDumpName;
  std::string colladaProfile;

  std::wstring render_type;

  int geomObjNum;
  int imgObjNum;

  std::wstring AccType;
  std::wstring ConstrMode;

  void IncludeAdd()
  {
    geometry  = true;
    spheres   = true;
    lights    = false;
    materials = false;
    tree      = false;

    sceneDumpName  = "c:/[hydra]/pluginFiles/test.dump";
    colladaProfile = "c:/[hydra]/pluginFiles/hydra_profile_generated.xml";
  }

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & geometry;
    ar & lights;
    ar & materials;
    ar & tree;
    ar & spheres;

    ar & sceneDumpName;

    ar & geomObjNum;
    ar & imgObjNum;  

    ar & AccType;
    ar & ConstrMode;
  }
};


inline static float GetCosPowerFromMaxShiness(float glosiness)
{
  float cMin = 1.0f;
  float cMax = 100000.0f;

  if(glosiness >= 0.99f)
    return 1000000.0f;

  return powf(cMax, glosiness);
}


#endif