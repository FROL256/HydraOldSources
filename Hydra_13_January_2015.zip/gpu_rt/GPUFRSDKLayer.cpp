#include "GPUAbstractLayer.h"

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
  #include "path_tracing.h"
#endif



class FRSDKHWLayer : public IHWLayer
{

public:

  FRSDKHWLayer(int w, int h, int a_flags);
  ~FRSDKHWLayer();

  void Clear(IGraphicsEngine::CLEAR_FLAGS a_flags);

  void SetGeom(InputGeom a_input);
  void SetBVH(InputGeomBVH a_input);

  void SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum); // set All PlainMaterials, including intermediate and auxilary
  void SetAllPODLights(RAYTR::Light* a_materialsAll, PlainLight* a_lights2, size_t a_number); // unlike materials, lights always represented as POD
  void SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data);
  void SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats);
  void SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16]);

  void SetAllFlagsAndVars(const AllRenderVarialbes& a_vars);
  AllRenderVarialbes GetAllFlagsAndVars() const;

  //
  //
  unsigned int AddLightMesh(LightMeshData a_lmesh);

  //
  //
  void GetLDRImageToGL(GLuint ogl_buffer) const;
  void GetLDRImage(uint* data, int width, int height) const;
  void GetHDRImage(float4* data, int width, int height) const;

  void ResetPerfCounters();
 
  void BeginTracingPass();
  void EndTracingPass();
  void InitPathTracing(int seed);

  void BeginBlocksPTPass(BlockList& a_list, BlockList& a_listFinished, int a_minRaysPerPixel, int a_maxRaysPerPixel);
  void EndBlocksPTPass();

  void ResizeScreen(int w, int h, int a_flags);

  void RegisterOutputGLBuffer(GLuint ogl_buffer);
  void UnregisterOutputGLBuffer();

  size_t GetAvaliableMemoryAmount(bool allMem);
  MRaysStat GetRaysStat();

protected:

  std::vector<uint> m_tempImage;
  int m_width;
  int m_height;
};


FRSDKHWLayer::FRSDKHWLayer(int w, int h, int a_flags)
{
  ResizeScreen(w, h, a_flags);
}


FRSDKHWLayer::~FRSDKHWLayer()
{
  
}


void FRSDKHWLayer::ResizeScreen(int width, int height, int a_flags)
{
  m_tempImage.resize(width*height);
  m_width  = width;
  m_height = height;
}

size_t FRSDKHWLayer::GetAvaliableMemoryAmount(bool allMem)
{
  return 1024*1024*1024; // 1 Gb 
}

void FRSDKHWLayer::SetGeom(InputGeom a_input)
{
  if (a_input.vertPos == NULL || a_input.vertNorm == NULL || a_input.vertTexCoord == NULL)
    RUN_TIME_ERROR("FRSDKHWLayer::SetGeom: invalid vertex data null pointer");

  if (a_input.indices == NULL)
    RUN_TIME_ERROR("FRSDKHWLayer::SetGeom: invalid indices null pointer");

  if (a_input.materialIndices == NULL)
    RUN_TIME_ERROR("FRSDKHWLayer::SetGeom: invalid triangle material indices null pointer");

  if (a_input.numIndices % 3 != 0)
    RUN_TIME_ERROR("FRSDKHWLayer::SetGeom: invalid input.numIndices value, must be multiple of 3");

  

}


void FRSDKHWLayer::SetBVH(InputGeomBVH a_input)
{
  if (a_input.nodes == NULL || a_input.primListData == NULL)
    RUN_TIME_ERROR("FRSDKHWLayer::SetBVH: invalid bvh data null pointer");

  if (a_input.numNodes == 0 || a_input.primListSizeInBytes == 0 )
    RUN_TIME_ERROR("FRSDKHWLayer::SetBVH: invalid bvh data size");

 
}

void FRSDKHWLayer::SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum)
{

}

void FRSDKHWLayer::SetAllPODLights(RAYTR::Light* a_lights, PlainLight* a_lights2, size_t a_number)
{
  
}


void FRSDKHWLayer::SetAllFlagsAndVars(const AllRenderVarialbes& a_vars)
{
  this->IHWLayer::SetAllFlagsAndVars(a_vars);

  // your custom setup
}

AllRenderVarialbes FRSDKHWLayer::GetAllFlagsAndVars() const
{
  AllRenderVarialbes state = IHWLayer::GetAllFlagsAndVars();

  // your custom 'get-up' :)

  return state;
}

void FRSDKHWLayer::SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats)
{
  if (a_sizeInFloats % 16 != 0)
    RUN_TIME_ERROR("FRSDKHWLayer::SetAllTextureMatrices: invalid matrices a_sizeInFloats");

 
}

void FRSDKHWLayer::SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data)
{

}

void FRSDKHWLayer::Clear(IGraphicsEngine::CLEAR_FLAGS a_flags)
{
  if (a_flags & IGraphicsEngine::CLEAR_TEXTURES)
  {

  }

  if (a_flags & IGraphicsEngine::CLEAR_LIGHTS)
  {
    // clear lights 
    // clear light meshes
  }

  if (a_flags & IGraphicsEngine::CLEAR_MATERIALS)
  {

  }

  if (a_flags & IGraphicsEngine::CLEAR_GEOMETRY)
  {

  }


}

void FRSDKHWLayer::SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16])
{
  

}


//
//
void FRSDKHWLayer::GetLDRImageToGL(GLuint ogl_buffer) const
{
  glBindBuffer(GL_ARRAY_BUFFER, ogl_buffer);
  glBufferData(GL_ARRAY_BUFFER, m_width*m_height*sizeof(int), &m_tempImage[0], GL_DYNAMIC_COPY);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void FRSDKHWLayer::GetLDRImage(uint* data, int width, int height) const
{
 
}

void FRSDKHWLayer::GetHDRImage(float4* data, int width, int height) const
{
 
}

void FRSDKHWLayer::InitPathTracing(int seed)
{

}

void FRSDKHWLayer::BeginBlocksPTPass(BlockList& a_list, BlockList& a_listFinished, int a_minRaysPerPixel, int a_maxRaysPerPixel) { }
void FRSDKHWLayer::EndBlocksPTPass() {}


MRaysStat FRSDKHWLayer::GetRaysStat()
{
  MRaysStat res;

  return res;
}


unsigned int FRSDKHWLayer::AddLightMesh(LightMeshData a_lmesh)
{
  return 0; // return light mesh index that was just added
}

void FRSDKHWLayer::ResetPerfCounters()
{
  
}

void FRSDKHWLayer::BeginTracingPass()
{
  for (int i = 0; i < m_width*m_height; i++)
  {
    m_tempImage[i] = 0xFFF00FFF;
  }
}

void FRSDKHWLayer::EndTracingPass()
{
  
}


void FRSDKHWLayer::RegisterOutputGLBuffer(GLuint ogl_buffer)
{
  
}

void FRSDKHWLayer::UnregisterOutputGLBuffer()
{

}




IHWLayer* CreateFRSDKImpl(int w, int h, int a_flags) { return new FRSDKHWLayer(w, h, a_flags); }

