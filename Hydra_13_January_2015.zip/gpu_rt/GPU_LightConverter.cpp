// � Copyright 2014 Vladimir Frolov, KIAM RAS
//
#include "GPU_Ray_Tracer.h"

#include <map>
#include <string>

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

class AreaDiffuseLight : public ILight
{
public:

  AreaDiffuseLight(float3 a_pos, float2 a_size, float3 a_norm, const float a_matrix[3][3], float3 a_intensity, int a_texId, int a_texMatrixId, float a_lightSurfaceArea, bool isSkyPortal, bool isDisk, bool isSpot, float a_spotCos1, float a_spotCos2)
  {
    m_plain.data[PLIGHT_POS_X] = a_pos.x;
    m_plain.data[PLIGHT_POS_Y] = a_pos.y;
    m_plain.data[PLIGHT_POS_Z] = a_pos.z;

    m_plain.data[PLIGHT_NORM_X] = a_norm.x;
    m_plain.data[PLIGHT_NORM_Y] = a_norm.y;
    m_plain.data[PLIGHT_NORM_Z] = a_norm.z;

    m_plain.data[PLIGHT_COLOR_X] = a_intensity.x;
    m_plain.data[PLIGHT_COLOR_Y] = a_intensity.y;
    m_plain.data[PLIGHT_COLOR_Z] = a_intensity.z;

    m_plain.data[PLIGHT_COLOR_TEX]        = a_texId;
    m_plain.data[PLIGHT_COLOR_TEX_MATRIX] = a_texMatrixId;

    m_plain.data[PLIGHT_SURFACE_AREA]  = a_lightSurfaceArea;

    m_plain.data[AREA_LIGHT_SIZE_X] = a_size.x;
    m_plain.data[AREA_LIGHT_SIZE_Y] = a_size.y;

    m_plain.data[AREA_LIGHT_MATRIX_E00] = a_matrix[0][0];
    m_plain.data[AREA_LIGHT_MATRIX_E01] = a_matrix[0][1];
    m_plain.data[AREA_LIGHT_MATRIX_E02] = a_matrix[0][2];

    m_plain.data[AREA_LIGHT_MATRIX_E10] = a_matrix[1][0];
    m_plain.data[AREA_LIGHT_MATRIX_E11] = a_matrix[1][1];
    m_plain.data[AREA_LIGHT_MATRIX_E12] = a_matrix[1][2];

    m_plain.data[AREA_LIGHT_MATRIX_E20] = a_matrix[2][0];
    m_plain.data[AREA_LIGHT_MATRIX_E21] = a_matrix[2][1];
    m_plain.data[AREA_LIGHT_MATRIX_E22] = a_matrix[2][2];

    m_plain.data[AREA_LIGHT_SPOT_COS1] = a_spotCos1;
    m_plain.data[AREA_LIGHT_SPOT_COS2] = a_spotCos2;

    ((int*)m_plain.data)[AREA_LIGHT_IS_DISK]    = int(isDisk);
    ((int*)m_plain.data)[AREA_LIGHT_SPOT_DISTR] = int(isSpot);
    ((int*)m_plain.data)[AREA_LIGHT_SKY_PORTAL] = int(isSkyPortal);

    ((int*)m_plain.data)[PLIGHT_TYPE]  = PLAIN_LIGHT_TYPE_AREA;
  }


  ShadowSample Sample(float4 rands, float3 illuminatingPoint)                  const { return areaDiffuseLightSample(const_cast<PlainLight*>(&m_plain), rands, illuminatingPoint); }
  float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const { return areaDiffuseLightEvalPDF(const_cast<PlainLight*>(&m_plain), rayDir, hitDist); }
  float3       GetIntensity(float2 a_texCoord)                                 const { return areaDiffuseLightGetIntensity(const_cast<PlainLight*>(&m_plain), a_texCoord); }


protected:
  

};


class SphereLight : public ILight
{
public:

  SphereLight(float3 a_pos, float a_radius, float3 a_intensity, float a_lightSurfaceArea)
  {
    m_plain.data[PLIGHT_POS_X] = a_pos.x;
    m_plain.data[PLIGHT_POS_Y] = a_pos.y;
    m_plain.data[PLIGHT_POS_Z] = a_pos.z;

    m_plain.data[PLIGHT_COLOR_X] = a_intensity.x;
    m_plain.data[PLIGHT_COLOR_Y] = a_intensity.y;
    m_plain.data[PLIGHT_COLOR_Z] = a_intensity.z;

    m_plain.data[PLIGHT_SURFACE_AREA] = a_lightSurfaceArea;

    m_plain.data[SPHERE_LIGHT_RADIUS] = a_radius;

    ((int*)m_plain.data)[PLIGHT_TYPE] = PLAIN_LIGHT_TYPE_SPHERE;
  }


  ShadowSample Sample(float4 rands, float3 illuminatingPoint)                  const { return sphereLightSample(const_cast<PlainLight*>(&m_plain), rands, illuminatingPoint); }
  float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const { return sphereLightEvalPDF(const_cast<PlainLight*>(&m_plain), illuminatingPoint); }
  float3       GetIntensity(float2 a_texCoord)                                 const { return sphereLightGetIntensity(const_cast<PlainLight*>(&m_plain)); }


protected:


};

class PointLight : public ILight
{
public:

  PointLight(float3 a_pos, float3 a_intensity)
  {
    m_plain.data[PLIGHT_POS_X] = a_pos.x;
    m_plain.data[PLIGHT_POS_Y] = a_pos.y;
    m_plain.data[PLIGHT_POS_Z] = a_pos.z;

    m_plain.data[PLIGHT_COLOR_X] = a_intensity.x;
    m_plain.data[PLIGHT_COLOR_Y] = a_intensity.y;
    m_plain.data[PLIGHT_COLOR_Z] = a_intensity.z;

    m_plain.data[PLIGHT_SURFACE_AREA] = 1.0f;
    ((int*)m_plain.data)[PLIGHT_TYPE] = PLAIN_LIGHT_TYPE_POINT_OMNI;
  }

  ShadowSample Sample(float4 rands, float3 illuminatingPoint)                  const { return pointLightSample(const_cast<PlainLight*>(&m_plain), rands, illuminatingPoint); }
  float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const { return pointLightEvalPDF(const_cast<PlainLight*>(&m_plain), illuminatingPoint); }
  float3       GetIntensity(float2 a_texCoord)                                 const { return pointLightGetIntensity(const_cast<PlainLight*>(&m_plain)); }


protected:

};


class SpotLight : public ILight
{
public:

  SpotLight(float3 a_pos, float3 a_norm, float3 a_intensity, float a_cos1, float a_cos2)
  {
    m_plain.data[PLIGHT_POS_X] = a_pos.x;
    m_plain.data[PLIGHT_POS_Y] = a_pos.y;
    m_plain.data[PLIGHT_POS_Z] = a_pos.z;

    m_plain.data[PLIGHT_NORM_X] = a_norm.x;
    m_plain.data[PLIGHT_NORM_Y] = a_norm.y;
    m_plain.data[PLIGHT_NORM_Z] = a_norm.z;

    m_plain.data[PLIGHT_COLOR_X] = a_intensity.x;
    m_plain.data[PLIGHT_COLOR_Y] = a_intensity.y;
    m_plain.data[PLIGHT_COLOR_Z] = a_intensity.z;

    m_plain.data[POINT_LIGHT_SPOT_COS1] = a_cos1;
    m_plain.data[POINT_LIGHT_SPOT_COS2] = a_cos2;

    m_plain.data[PLIGHT_SURFACE_AREA] = 1.0f;
    ((int*)m_plain.data)[PLIGHT_TYPE] = PLAIN_LIGHT_TYPE_POINT_SPOT;
  }

  ShadowSample Sample(float4 rands, float3 illuminatingPoint)                  const { return spotLightSample(const_cast<PlainLight*>(&m_plain), rands, illuminatingPoint); }
  float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const { return spotLightEvalPDF(const_cast<PlainLight*>(&m_plain), illuminatingPoint); }
  float3       GetIntensity(float2 a_texCoord)                                 const { return spotLightGetIntensity(const_cast<PlainLight*>(&m_plain)); }


protected:

};

class DirectLight : public ILight
{
public:

  DirectLight(float3 a_pos, float3 a_norm, float3 a_intensity, float a_radius1, float a_radius2)
  {
    m_plain.data[PLIGHT_POS_X] = a_pos.x;
    m_plain.data[PLIGHT_POS_Y] = a_pos.y;
    m_plain.data[PLIGHT_POS_Z] = a_pos.z;

    m_plain.data[PLIGHT_NORM_X] = a_norm.x;
    m_plain.data[PLIGHT_NORM_Y] = a_norm.y;
    m_plain.data[PLIGHT_NORM_Z] = a_norm.z;

    m_plain.data[PLIGHT_COLOR_X] = a_intensity.x;
    m_plain.data[PLIGHT_COLOR_Y] = a_intensity.y;
    m_plain.data[PLIGHT_COLOR_Z] = a_intensity.z;

    m_plain.data[DIRECT_LIGHT_RADIUS1] = a_radius1;
    m_plain.data[DIRECT_LIGHT_RADIUS2] = a_radius2;

    m_plain.data[PLIGHT_SURFACE_AREA] = 1.0f;
    ((int*)m_plain.data)[PLIGHT_TYPE] = PLAIN_LIGHT_TYPE_DIRECT;
  }

  ShadowSample Sample(float4 rands, float3 illuminatingPoint)                  const { return spotLightSample(const_cast<PlainLight*>(&m_plain), rands, illuminatingPoint); }
  float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const { return spotLightEvalPDF(const_cast<PlainLight*>(&m_plain), illuminatingPoint); }
  float3       GetIntensity(float2 a_texCoord)                                 const { return spotLightGetIntensity(const_cast<PlainLight*>(&m_plain)); }


protected:

};

void GPU_Ray_Tracer::BuildLightIdTransformTable(const std::vector<RAYTR::Light>& a_legacy)
{
  m_oldLightIdToNewLightId.resize(a_legacy.size());

  int counter = 0;
  for (size_t i = 0; i < a_legacy.size(); i++)
  {
    float3 lightColor = a_legacy[i].color*a_legacy[i].intensity;

    if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_AREA)
    {
      m_oldLightIdToNewLightId[i] = counter;
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_AREA_DISK)
    {
      m_oldLightIdToNewLightId[i] = counter;
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_SPHERICAL)
    {
      m_oldLightIdToNewLightId[i] = counter;
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_POINT)
    {
      m_oldLightIdToNewLightId[i] = counter;
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_SPOT)
    {
      m_oldLightIdToNewLightId[i] = counter;
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_DIRECTIONAL)
    {
      m_oldLightIdToNewLightId[i] = counter;
      counter++;
    }
    else
    {
      m_oldLightIdToNewLightId[i] = 0;
    }
  }

}

void GPU_Ray_Tracer::ConvertAllLegacyLights(const std::vector<RAYTR::Light>& a_legacy, std::vector<ILight*>* a_pLightsModern)
{
  const RAYTR::Light* pSkyLight = NULL; // find sky light

  for (size_t i = 0; i < a_legacy.size(); i++)
  {
    if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_SKY)
    {
      pSkyLight = &a_legacy[i];
      break;
    }
  }

  a_pLightsModern->resize(a_legacy.size());

  for (size_t i = 0; i < a_pLightsModern->size(); i++)
    a_pLightsModern->at(i) = NULL;

  int counter = 0;
  for (size_t i = 0; i < a_pLightsModern->size(); i++)
  {
    float3 lightColor = a_legacy[i].color*a_legacy[i].intensity;

    if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_AREA)
    {
      bool  hasSpotDist = (a_legacy[i].GetDistrbType() == RAYTR::Light::LD_SPOT);
      bool  isSkyPortal  = (a_legacy[i].flags & Light::LIGHT_SKY_PORTAL);

      if (isSkyPortal && pSkyLight!=NULL)
      {
        // if (a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE1); // p->second["general_sky_portal_source"] == "environment"
        // if (a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE2); // p->second["general_sky_portal_source"] == "skylight"
        // if (a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE3); // p->second["general_sky_portal_source"] == "custom"

        if (!(a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE3))
          lightColor = pSkyLight->color*pSkyLight->intensity;
      }

      float cos1 = a_legacy[i].GetSpotLightCutoff(0);
      float cos2 = a_legacy[i].GetSpotLightCutoff(1);

      a_pLightsModern->at(counter) = new AreaDiffuseLight(a_legacy[i].pos, a_legacy[i].GetAreaLightSize(), a_legacy[i].GetNormal(), a_legacy[i].M, lightColor, a_legacy[i].emissiveTexId, a_legacy[i].emissiveTexMatrixId, a_legacy[i].surfaceArea, isSkyPortal, false, hasSpotDist, cos1, cos2);
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_AREA_DISK)
    {
      bool  hasSpotDist = (a_legacy[i].GetDistrbType() == RAYTR::Light::LD_SPOT);
      bool  isSkyPortal = (a_legacy[i].flags & Light::LIGHT_SKY_PORTAL);

      if (isSkyPortal && pSkyLight != NULL)
      {
        // if (a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE1); // p->second["general_sky_portal_source"] == "environment"
        // if (a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE2); // p->second["general_sky_portal_source"] == "skylight"
        // if (a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE3); // p->second["general_sky_portal_source"] == "custom"

        if (!(a_legacy[i].flags & RAYTR::Light::LIGHT_SKY_PORTAL_SOURCE3))
          lightColor = pSkyLight->color*pSkyLight->intensity;
      }

      float cos1 = a_legacy[i].GetSpotLightCutoff(0);
      float cos2 = a_legacy[i].GetSpotLightCutoff(1);

      a_pLightsModern->at(counter) = new AreaDiffuseLight(a_legacy[i].pos, a_legacy[i].GetAreaLightSize(), a_legacy[i].GetNormal(), a_legacy[i].M, lightColor, a_legacy[i].emissiveTexId, a_legacy[i].emissiveTexMatrixId, a_legacy[i].surfaceArea, isSkyPortal, true, hasSpotDist, cos1, cos2);
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_SPHERICAL)
    {
      a_pLightsModern->at(counter) = new SphereLight(a_legacy[i].pos, a_legacy[i].GetSphericalLightRadius(), lightColor, a_legacy[i].surfaceArea);
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_POINT)
    {
      a_pLightsModern->at(counter) = new PointLight(a_legacy[i].pos, lightColor);
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_SPOT)
    {
      float cos1 = a_legacy[i].GetSpotLightCutoff(0);
      float cos2 = a_legacy[i].GetSpotLightCutoff(1);

      a_pLightsModern->at(counter) = new SpotLight(a_legacy[i].pos, a_legacy[i].GetNormal(), lightColor, cos1, cos2);
      counter++;
    }
    else if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_DIRECTIONAL)
    {
      a_pLightsModern->at(counter) = new DirectLight(a_legacy[i].pos, a_legacy[i].GetNormal(), lightColor, a_legacy[i].m_size.x, a_legacy[i].m_size.y);
      counter++;
    }
  
  }




}

void GPU_Ray_Tracer::ConvertAllModernLights(const std::vector<ILight*>& a_pLightsModern, std::vector<PlainLight>* a_pLightsPlain)
{
  a_pLightsPlain->resize(a_pLightsModern.size());

  for (size_t i = 0; i < a_pLightsModern.size(); i++)
  {
    if (a_pLightsModern[i] != NULL)
      a_pLightsPlain->at(i) = a_pLightsModern[i]->ConvertToPlainLight();
  }
}

