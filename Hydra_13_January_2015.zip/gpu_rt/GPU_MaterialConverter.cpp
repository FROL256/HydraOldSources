// � Copyright 2014 Vladimir Frolov, KIAM RAS
//
#include "GPU_Ray_Tracer.h"

#include <map>
#include <string>

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif


class EmissiveMaterial : public IMaterial
{

public:

  EmissiveMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial));  }
  EmissiveMaterial(float3 color, int texId, int texMatrixId, int a_lightId)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[EMISSIVE_COLORX_OFFSET] = color.x;
    m_plain.data[EMISSIVE_COLORY_OFFSET] = color.y;
    m_plain.data[EMISSIVE_COLORZ_OFFSET] = color.z;

    ((int*)(m_plain.data))[EMISSIVE_TEXID_OFFSET]       = texId;
    ((int*)(m_plain.data))[EMISSIVE_TEXMATRIXID_OFFSET] = texMatrixId;
    ((int*)(m_plain.data))[EMISSIVE_LIGHTID_OFFSET]     = a_lightId;

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET] = PLAIN_MAT_CLASS_EMISSIVE;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return lambertSampleAndEvalBRDF(const_cast<PlainMaterial*>(&m_plain), rands.x, rands.y, normal, texCoord); }
  float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord)                         const { return lambertEvalBxDF(const_cast<PlainMaterial*>(&m_plain), l, n); }
  float     EvalPDF(float3 l, float3 v, float3 n, float2 texCoord)                          const { return lambertEvalPDF(const_cast<PlainMaterial*>(&m_plain), l, n); }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const 
  {
    std::vector<PlainMaterial> res(1);
    res[0] = m_plain;
    return res;
  }

protected:

};


class LambertMaterial : public IMaterial
{

public:

  LambertMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial));  }
  LambertMaterial(float3 color, int texId, int texMatrixId)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[LAMBERT_COLORX_OFFSET] = color.x;
    m_plain.data[LAMBERT_COLORY_OFFSET] = color.y;
    m_plain.data[LAMBERT_COLORZ_OFFSET] = color.z;

    ((int*)(m_plain.data))[LAMBERT_TEXID_OFFSET]       = texId;
    ((int*)(m_plain.data))[LAMBERT_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET]      = PLAIN_MAT_CLASS_LAMBERT;
    ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET]     = PLAIN_MATERIAL_HAS_DIFFUSE;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return lambertSampleAndEvalBRDF(const_cast<PlainMaterial*>(&m_plain), rands.x, rands.y, normal, texCoord); }
  float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord)                         const { return lambertEvalBxDF(const_cast<PlainMaterial*>(&m_plain), l, n); }
  float     EvalPDF(float3 l, float3 v, float3 n, float2 texCoord)                          const { return lambertEvalPDF(const_cast<PlainMaterial*>(&m_plain), l, n); }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1);
    res[0] = m_plain;
    return res;
  }

protected:


};


class MirrorMaterial : public IMaterial
{

public:

  MirrorMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial)); }
  MirrorMaterial(float3 color, int texId, int texMatrixId)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[MIRROR_COLORX_OFFSET] = color.x;
    m_plain.data[MIRROR_COLORY_OFFSET] = color.y;
    m_plain.data[MIRROR_COLORZ_OFFSET] = color.z;

    ((int*)(m_plain.data))[MIRROR_TEXID_OFFSET]       = texId;
    ((int*)(m_plain.data))[MIRROR_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET]  = PLAIN_MAT_CLASS_PERFECT_MIRROR;
    ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] = PLAIN_MATERIAL_CAST_CAUSTICS;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return mirrorSampleAndEvalBRDF(const_cast<PlainMaterial*>(&m_plain), rands.x, rands.y, ray_dir, normal, texCoord); }
  float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord)                         const { return mirrorEvalBxDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }
  float     EvalPDF(float3 l, float3 v, float3 n, float2 texCoord)                          const { return mirrorEvalPDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1);
    res[0] = m_plain;
    return res;
  }

protected:


};



class ThinGlassMaterial : public IMaterial
{

public:

  ThinGlassMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial)); }
  ThinGlassMaterial(float3 color, int texId, int texMatrixId)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[THINGLASS_COLORX_OFFSET] = color.x;
    m_plain.data[THINGLASS_COLORY_OFFSET] = color.y;
    m_plain.data[THINGLASS_COLORZ_OFFSET] = color.z;

    ((int*)(m_plain.data))[THINGLASS_TEXID_OFFSET] = texId;
    ((int*)(m_plain.data))[THINGLASS_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET]  = PLAIN_MAT_CLASS_THIN_GLASS;
    ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] = PLAIN_MATERIAL_CAST_CAUSTICS | PLAIN_MATERIAL_HAS_TRANSPARENCY;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return thinglassSampleAndEvalBRDF(const_cast<PlainMaterial*>(&m_plain), rands.x, rands.y, ray_dir, normal, texCoord); }
  float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord)                         const { return thinglassEvalBxDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }
  float     EvalPDF(float3 l, float3 v, float3 n, float2 texCoord)                          const { return thinglassEvalPDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1);
    res[0] = m_plain;
    return res;
  }

protected:


};


class PhongMaterial : public IMaterial
{

public:

  PhongMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial)); }
  PhongMaterial(float3 color, int texId, int texMatrixId, float cosPower, int glossTexId, int glossTexMatrixId)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[PHONG_COLORX_OFFSET] = color.x;
    m_plain.data[PHONG_COLORY_OFFSET] = color.y;
    m_plain.data[PHONG_COLORZ_OFFSET] = color.z;

    m_plain.data[PHONG_COSPOWER_OFFSET]  = cosPower;
    m_plain.data[PHONG_GLOSINESS_OFFSET] = cosPower; // cosPowerToGlosiness

    ((int*)(m_plain.data))[PHONG_TEXID_OFFSET]       = texId;
    ((int*)(m_plain.data))[PHONG_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[PHONG_GLOSINESS_TEXID_OFFSET] = texId;
    ((int*)(m_plain.data))[PHONG_GLOSINESS_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET]  = PLAIN_MAT_CLASS_PHONG_SPECULAR;
    ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] = PLAIN_MATERIAL_CAST_CAUSTICS;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return phongSampleAndEvalBRDF(const_cast<PlainMaterial*>(&m_plain), rands.x, rands.y, ray_dir, normal, texCoord); }
  float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord)                         const { return phongEvalBxDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }
  float     EvalPDF(float3 l, float3 v, float3 n, float2 texCoord)                          const { return phongEvalPDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1);
    res[0] = m_plain;
    return res;
  }

protected:


};


class BlinnTorranceSrappowMaterial : public IMaterial
{

public:

  BlinnTorranceSrappowMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial)); }
  BlinnTorranceSrappowMaterial(float3 color, int texId, int texMatrixId, float cosPower, int glossTexId, int glossTexMatrixId)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[BLINN_COLORX_OFFSET] = color.x;
    m_plain.data[BLINN_COLORY_OFFSET] = color.y;
    m_plain.data[BLINN_COLORZ_OFFSET] = color.z;

    m_plain.data[BLINN_COSPOWER_OFFSET] = cosPower;
    m_plain.data[BLINN_GLOSINESS_OFFSET] = cosPower; // cosPowerToGlosiness

    ((int*)(m_plain.data))[BLINN_TEXID_OFFSET] = texId;
    ((int*)(m_plain.data))[BLINN_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[BLINN_GLOSINESS_TEXID_OFFSET] = texId;
    ((int*)(m_plain.data))[BLINN_GLOSINESS_TEXMATRIXID_OFFSET] = texMatrixId;

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET]  = PLAIN_MAT_CLASS_BLINN_SPECULAR;
    ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] = PLAIN_MATERIAL_CAST_CAUSTICS;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return blinnSampleAndEvalBRDF(const_cast<PlainMaterial*>(&m_plain), rands.x, rands.y, ray_dir, normal, texCoord); }
  float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord)                         const { return blinnEvalBxDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }
  float     EvalPDF(float3 l, float3 v, float3 n, float2 texCoord)                          const { return blinnEvalPDF(const_cast<PlainMaterial*>(&m_plain), l, v, n); }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1);
    res[0] = m_plain;
    return res;
  }

protected:


};




class MixMaterial : public IMaterial // simple mix of n components
{

public:

  MixMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial)); }
  MixMaterial(const std::vector<IMaterial*>& a_components, const std::vector<float>& a_weights) //, const std::vector<int>& a_offsets)
  {
    memset(&m_plain, 0, sizeof(PlainMaterial));
    
    ((int*)(m_plain.data))[MMIX_NUMC_OFFSET] = int(a_components.size());
  
    if (a_components.size() > MMIX_MAX_COMPONENTS)
      RUN_TIME_ERROR("MixMaterial: Too many components in mixture");

    if (a_components.size() != a_weights.size())
      RUN_TIME_ERROR("MixMaterial: Wrong weights array");

    m_components = a_components;
    m_weights    = a_weights;
    m_intervals.resize(m_components.size());

    float wSumm = 0.0f;

    for (int i = 0; i<int(m_weights.size()); i++)
      wSumm += m_weights[i];

    // normalize weights and compute intervals
    //
    float invWSumm = 1.0f / wSumm;
    float wSumm2 = 0.0f;
    for (int i = 0; i<int(m_weights.size()); i++)
    {
      m_weights[i] = m_weights[i] * invWSumm;

      m_intervals[i].x = wSumm2;
      m_intervals[i].y = wSumm2 + m_weights[i];

      wSumm2 += m_weights[i];
    }

    for (int i = 0; i < int(a_components.size()); i++)
    {
      ((int*)(m_plain.data))[MMIX_START + 2*i + 0] = 0; // a_offsets[i];
      m_plain.data          [MMIX_START + 2*i + 1] = m_weights[i];
    }
    
    // move flags up
    //

    ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] = 0;

    for (int i = 0; i<int(a_components.size()); i++)
    {
      if (a_components[i]->HasDiffuse())
        ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] |= PLAIN_MATERIAL_HAS_DIFFUSE;

      if (a_components[i]->HasTransparency())
        ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] |= PLAIN_MATERIAL_HAS_TRANSPARENCY;

      if (a_components[i]->CastCaustic())
        ((int*)(m_plain.data))[PLAIN_MAT_FLAGS_OFFSET] |= PLAIN_MATERIAL_CAST_CAUSTICS;
    }

    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET] = PLAIN_MAT_CLASS_MIX;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const 
  { 
    float ksi = rands.w;
    int   selectedComponent = m_components.size() - 1;

    for (int i = 0; i<int(m_intervals.size()); i++)
    {
      if (m_intervals[i].x <= ksi && ksi < m_intervals[i].y)
        selectedComponent = i;
    }

    return m_components[selectedComponent]->SampleAndEvalBxDF(rands, ray_dir, normal, texCoord);
  }
  
  float3 EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord) const 
  { 
    float3 summBRDF = make_float3(0.0f, 0.0f, 0.0f);
    for (int i = 0; i<int(m_weights.size()); i++)
      summBRDF += m_weights[i] * m_components[i]->EvalBxDF(l, v, n, texCoord);
    return summBRDF;
  }
  
  float EvalPDF(float3 l, float3 v, float3 n, float2 texCoord) const 
  {
    float summPdf = 0.0f;
    for (int i = 0; i<int(m_weights.size()); i++)
      summPdf += m_weights[i] * m_components[i]->EvalPDF(l, v, n, texCoord);
    return summPdf;
  }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1); res.reserve(MMIX_MAX_COMPONENTS + 1);

    for (int i = 0; i < m_components.size(); i++)
    {
      ((int*)(m_plain.data))  [MMIX_START + 2 * i + 0] = res.size(); // component relative offset
      const_cast<float*>(m_plain.intervals)[2 * i + 0] = m_intervals[i].x;
      const_cast<float*>(m_plain.intervals)[2 * i + 1] = m_intervals[i].y;

      std::vector<PlainMaterial> dump = m_components[i]->ConvertToPlainMaterial();
      res.insert(res.end(), dump.begin(), dump.end());
    }

    res[0] = m_plain;
    return res;
  }

protected:

  std::vector<IMaterial*> m_components;
  std::vector<float>      m_weights;
  std::vector<float2>     m_intervals;

};



class BlendMaskMaterial : public IMaterial // simple mix of n components
{

public:

  BlendMaskMaterial() { memset(&m_plain, 0, sizeof(PlainMaterial)); }
  BlendMaskMaterial(IMaterial* a_pMaterial1, IMaterial* a_pMaterial2, float3 alpha_color, int alpha_texID, int alpha_texMatrixID)
  {
    m_pComponent1 = a_pMaterial1;
    m_pComponent2 = a_pMaterial2;

    memset(&m_plain, 0, sizeof(PlainMaterial));

    m_plain.data[BLEND_MASK_COLORX_OFFSET] = alpha_color.x;
    m_plain.data[BLEND_MASK_COLORY_OFFSET] = alpha_color.y;
    m_plain.data[BLEND_MASK_COLORZ_OFFSET] = alpha_color.z;

    ((int*)(m_plain.data))[BLEND_MASK_TEXID_OFFSET]       = alpha_texID;
    ((int*)(m_plain.data))[BLEND_MASK_TEXMATRIXID_OFFSET] = alpha_texMatrixID;   
    ((int*)(m_plain.data))[PLAIN_MAT_TYPE_OFFSET]         = PLAIN_MAT_CLASS_BLEND_MASK;
  }

  float3 Emittance() const { return materialGetEmission(const_cast<PlainMaterial*>(&m_plain)); }
  bool   IsLight()   const { return materialIsLight(const_cast<PlainMaterial*>(&m_plain)); }
  int    LightId()   const { return materialGetLightId(const_cast<PlainMaterial*>(&m_plain)); }

  MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const
  {
    return MatSample();
  }

  float3 EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord) const
  {
    return make_float3(0.0f, 0.0f, 0.0f);
  }

  float EvalPDF(float3 l, float3 v, float3 n, float2 texCoord) const
  {
    return 0.0f;
  }

  std::vector<PlainMaterial> ConvertToPlainMaterial() const
  {
    std::vector<PlainMaterial> res(1); res.reserve(10);

    std::vector<PlainMaterial> dump1 = m_pComponent1->ConvertToPlainMaterial();
    std::vector<PlainMaterial> dump2 = m_pComponent2->ConvertToPlainMaterial();

    ((int*)(m_plain.data))[BLEND_MASK_MATERIAL1_OFFSET] = res.size();
    res.insert(res.end(), dump1.begin(), dump1.end());
    
    ((int*)(m_plain.data))[BLEND_MASK_MATERIAL2_OFFSET] = res.size();
    res.insert(res.end(), dump2.begin(), dump2.end());
    
    res[0] = m_plain;
    return res;
  }

protected:

  IMaterial* m_pComponent1;
  IMaterial* m_pComponent2;

};



void GPU_Ray_Tracer::ConvertAllLegacyMaterials(const std::vector<HydraMaterial>& a_materialsLegacy, std::vector<IMaterial*>* a_pMaterialsModern, std::vector<IMaterial*>* a_pMaterialsModernAux)
{
  for (size_t i = 0; i < a_pMaterialsModern->size(); i++)
    delete a_pMaterialsModern->at(i);

  for (size_t i = 0; i < a_pMaterialsModernAux->size(); i++)
    delete a_pMaterialsModernAux->at(i);

  a_pMaterialsModern->resize(a_materialsLegacy.size());
  a_pMaterialsModernAux->resize(0);


  for (size_t i = 0; i < a_materialsLegacy.size(); i++)
  {
    const HydraMaterial& mat = a_materialsLegacy[i];

    if (length(mat.ambient.color) > 0.001f)
    {
      if (int(m_oldLightIdToNewLightId.size()) < int(mat.ambient.light_id))
        RUN_TIME_ERROR("m_oldLightIdToNewLightId table not initialized");

      int oldLightId = mat.ambient.light_id;
      int newLightId = (oldLightId >= 0) ? m_oldLightIdToNewLightId[oldLightId] : oldLightId;

      a_pMaterialsModern->at(i) = new EmissiveMaterial(mat.ambient.color, mat.ambient.color_texId, mat.ambient.color_texMatrixId, newLightId);
    }
    else if (length(mat.reflection.color) > 0.001f && length(mat.diffuse.color) > 0.001f && length(mat.transparency.color) > 0.001f) // simple mix
    {
      IMaterial* pPhong = NULL;

      if (mat.reflection.cosPower >= HydraMaterial::MaxCosPower() && mat.reflection.gloss_texId == INVALID_TEXTURE)
        pPhong = new MirrorMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId);
      else
        pPhong = new PhongMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId,
                                   mat.reflection.cosPower, mat.reflection.gloss_texId, mat.reflection.gloss_texMatrixId);

      IMaterial* pGlass = new ThinGlassMaterial(mat.transparency.color, mat.transparency.color_texId, mat.transparency.color_texMatrixId);
      IMaterial* pLambert = new LambertMaterial(mat.diffuse.color, mat.diffuse.color_texId, mat.diffuse.color_texMatrixId);

      float summ = maxcomp(mat.reflection.color) + maxcomp(mat.diffuse.color) + maxcomp(mat.transparency.color);

      float phongWeight   = maxcomp(mat.reflection.color)   / summ;
      float lambertWeight = maxcomp(mat.diffuse.color)      / summ;
      float glassWeight   = maxcomp(mat.transparency.color) / summ;

      std::vector<IMaterial*> components;
      std::vector<float>      weights;

      components.push_back(pPhong);
      components.push_back(pLambert);
      components.push_back(pGlass);

      weights.push_back(phongWeight);
      weights.push_back(lambertWeight);
      weights.push_back(glassWeight);

      a_pMaterialsModern->at(i) = new MixMaterial(components, weights);

      a_pMaterialsModernAux->push_back(pPhong);   // store pointer to futher free memory
      a_pMaterialsModernAux->push_back(pLambert);
      a_pMaterialsModernAux->push_back(pGlass);

    }
    else if(false) //(length(mat.reflection.color) > 0.001f && length(mat.diffuse.color) > 0.001f) // simple mix
    {
      IMaterial* pPhong = NULL;

      if (mat.reflection.cosPower >= HydraMaterial::MaxCosPower() && mat.reflection.gloss_texId == INVALID_TEXTURE)
        pPhong = new MirrorMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId);
      else
        pPhong = new PhongMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId,
                                   mat.reflection.cosPower, mat.reflection.gloss_texId, mat.reflection.gloss_texMatrixId);

      //pPhong = new ThinGlassMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId);

      IMaterial* pLambert = new LambertMaterial(mat.diffuse.color, mat.diffuse.color_texId, mat.diffuse.color_texMatrixId);

      float phongWeight   = maxcomp(mat.reflection.color) / (maxcomp(mat.reflection.color) + maxcomp(mat.diffuse.color));
      float lambertWeight = maxcomp(mat.diffuse.color)    / (maxcomp(mat.reflection.color) + maxcomp(mat.diffuse.color));

      std::vector<IMaterial*> components;
      std::vector<float>      weights;

      components.push_back(pPhong);
      components.push_back(pLambert);

      weights.push_back(phongWeight);
      weights.push_back(lambertWeight);

      a_pMaterialsModern->at(i) = new MixMaterial(components, weights);

      a_pMaterialsModernAux->push_back(pPhong);   // store pointer to futher free memory
      a_pMaterialsModernAux->push_back(pLambert);
    }
    else if (length(mat.reflection.color) > 0.001f && length(mat.diffuse.color) > 0.001f) // simple blend
    {
      IMaterial* pPhong = NULL;

      if (mat.reflection.cosPower >= HydraMaterial::MaxCosPower() && mat.reflection.gloss_texId == INVALID_TEXTURE)
        pPhong = new MirrorMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId);
      else
        pPhong = new PhongMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId,
                                   mat.reflection.cosPower, mat.reflection.gloss_texId, mat.reflection.gloss_texMatrixId);

      IMaterial* pLambert = new LambertMaterial(mat.diffuse.color, mat.diffuse.color_texId, mat.diffuse.color_texMatrixId);

      a_pMaterialsModern->at(i) = new BlendMaskMaterial(pPhong, pLambert, mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId);
      //a_pMaterialsModern->at(i) = new BlendMaskMaterial(pLambert, pPhong, mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId);

      a_pMaterialsModernAux->push_back(pPhong);   // store pointer to futher free memory
      a_pMaterialsModernAux->push_back(pLambert);

    }
    else if (length(mat.reflection.color) > 0.001f)
    {
      a_pMaterialsModern->at(i) = new PhongMaterial(mat.reflection.color, mat.reflection.color_texId, mat.reflection.color_texMatrixId, 
                                                    mat.reflection.cosPower, mat.reflection.gloss_texId, mat.reflection.gloss_texMatrixId);
    }
    else
    {
      a_pMaterialsModern->at(i) = new LambertMaterial(mat.diffuse.color, mat.diffuse.color_texId, mat.diffuse.color_texMatrixId);
    }


  }

}


void PrepareRootMaterialTextureIndicesForPrefetch(PlainMaterial* a_pRoot, IMaterial* a_pRootAbstract)
{
  for (int i = 0; i < MIX_MAX_TEXTURE_SLOTS; i++)
  {
    a_pRoot->allTextureIndices [i] = INVALID_TEXTURE;
    a_pRoot->allTextureMatrices[i] = 0;
  }

  // recursiveStackBasedTravel of all material graph
  //
  int tos = 0;
  int stack[MIX_TREE_MAX_DEEP];

  //PlainMaterial* node = a_pRoot;
  IMaterial*     node = a_pRootAbstract;

  while (true)
  {

    if (false) //(isSimpleBRDF(node))
    {
      // lambert ->
      // phong   ->
      // ...
      //
    }
    else
    {
      // mix           ->
      // blend         ->
      // fresnel blend ->
    }

    break;
  }


}

void GPU_Ray_Tracer::ConvertAllModernMaterials(const std::vector<IMaterial*>& a_materialsModern, std::vector<PlainMaterial>* a_pMaterialsPlain, std::vector<int>* a_pMatIndicesOffsets)
{
  a_pMaterialsPlain->resize(0);
  a_pMaterialsPlain->reserve(a_materialsModern.size() * 5);

  a_pMatIndicesOffsets->resize(a_materialsModern.size());

  for (size_t i = 0; i < a_materialsModern.size(); i++)
  {
    std::vector<PlainMaterial> dump = a_materialsModern[i]->ConvertToPlainMaterial();

    PrepareRootMaterialTextureIndicesForPrefetch(&dump[0], a_materialsModern[i]);

    a_pMatIndicesOffsets->at(i)     = a_pMaterialsPlain->size();
    a_pMaterialsPlain->insert(a_pMaterialsPlain->end(), dump.begin(), dump.end());
  }


}

