// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include "Common_Graphics_Engine.h"
#include "Fonts.h"

#include "../bvh_builder/BVHBuilderRef_vfrolov.h"
#include "../vsgl3/glHelper.h"

using namespace MGML_MATH;

float LightComputeSurfaceArea(const RAYTR::Light& light);

Common_Graphics_Engine::Common_Graphics_Engine(int w, int h, int a_flags): IGraphicsEngine(w,h), m_updateProgressCall(NULL)
{
  m_initFlags = a_flags;
  if(!(a_flags & GPU_RT_NOWINDOW)) { CHECK_GL_ERRORS; }
  width = w;
  height = h;

  //screen_buffer = new uint [width*height];

  for(int i=0;i<MAX_VERTEX_ATTRIBUTES;i++) 
    m_vertAttr[i] = NULL;

  m_currInputLayout = 0;
  m_pBVHBuilder = NULL;

  m_lightsWasAddedAsGeometry = 0;

  m_dataVerifyed            = false;
  m_dirtyHydraMaterials     = true;
  m_dirtyLights             = true;
  m_accelStructuresDirty    = true;
  m_debugOutput             = true;
  m_voxelizeOnLoad          = false;

  m_ivars["g_debugLayerDraw"] = 0;

  if(!(a_flags & GPU_RT_NOWINDOW))
  {
    gl_ver = GetCurrGLVersion(); CHECK_GL_ERRORS;
    if(gl_ver <= 3.1)
      glBuildFont();

    CHECK_GL_ERRORS;
  }

  //std::cerr << "precomputing SH data" << std::endl;
  // precompute hemisphere data - 32*32, 64*64, 128*128, 256*256 
  //
  Timer timer(true);
  int numSamplesPerSector = 32; 
  for(int i=0;i<HEMISPHERE_SEQUENCE_NUM;i++)
  {
    CreateSphericalDistribution(m_sphereUniformArray[i], numSamplesPerSector);         // cosine 
    CreateSphericalDistribution(m_sphereUniformArray2[i], numSamplesPerSector, false); // uniform
    //CreateCubeMapDistribution(m_cubeUniformArray[i], numSamplesPerSector/2); // sqr(numSamplesPerSector) == samples per cube face
    numSamplesPerSector *= 2;
  }
  PrecomputeSHCoeffs(m_shCoeffsArray);  

  //std::cerr << "SH coeffs calculations time = " << timer.getElapsed() << std::endl;

  ReserveMemoryFor(INPUT_PRIMITIVE_TRIANGLES, 1000000); // reserve
  m_geomMD5   = "";
  m_lightsMD5 = "";

  m_texMatrices.resize(1);
  m_texMatrices[0] = Matrix4x4f();

  m_projParams = float4(MGML_MATH::PI/2.0f, 3.0f/4.0f, 0.01f, 1000.0f);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Common_Graphics_Engine::~Common_Graphics_Engine()
{
  //delete m_pKdTreeBuilder; m_pKdTreeBuilder = NULL;
  //delete [] screen_buffer; screen_buffer = NULL;
  delete m_pBVHBuilder; m_pBVHBuilder = NULL;

  for(int i=0;i<MAX_VERTEX_ATTRIBUTES;i++) 
    { delete [] m_vertAttr[i]; m_vertAttr[i] = NULL; }

}

void Common_Graphics_Engine::SetProgressBarCallback(RTE_PROGRESSBAR_CALLBACK a_callback) { m_updateProgressCall = a_callback; }
void Common_Graphics_Engine::SetUpdateImageCallback(RTE_UPDATEIMAGE_CALLBACK a_callback) { m_updateImageCall = a_callback; }

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::DrawLights()
{
  if(m_lightsWasAddedAsGeometry || gl_ver > 3.1)
    return;

  glDisable(GL_LIGHTING);
  glDisable(GL_TEXTURE_2D);

  glPushMatrix();

  for(int i=0;i<m_lights.size();i++)
  {
    const RAYTR::Light* pLight = &m_lights[i];

    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA || pLight->GetLightType() == Light::LIGHT_TYPE_SPOT)
    {
      // draw normal
      glColor3f(0,0,1);
      glBegin(GL_LINES);
        glVertex3fv(pLight->pos.M);
        glVertex3fv((pLight->pos + pLight->GetNormal()).M);
      glEnd();
    }

    //glColor3f(0,1,0);
    //DebugDrawPoints();
    
    glColor3fv(pLight->color.M);
    glPushMatrix();
    glTranslatef(pLight->pos.x, pLight->pos.y, pLight->pos.z);
    
    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA)
    { 
      Matrix4x4f mRot;
      pLight->GetMatrixRotation(mRot.L);
     
      glPushMatrix();
      glMultMatrixf(mRot.L);

      vec2f size = pLight->GetAreaLightSize();

      glBegin(GL_TRIANGLE_STRIP);
        glVertex3f(-size.x, 0, -size.y);
        glVertex3f(-size.x, 0, size.y);
        glVertex3f(size.x, 0, -size.y);
        glVertex3f(size.x, 0, size.y);
      glEnd();
      glPopMatrix();
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPHERICAL)
    {
      glutSolidSphere(pLight->GetSphericalLightRadius(),20,20);
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_POINT)
    {
      glutSolidSphere(0.05f,10,10);
    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPOT)
    {
      //Matrix4x4f mRot;
      //for(int i=0;i<3;i++)
        //for(int j=0;j<3;j++)
          //mRot.M[i][j] = pLight->GetAreaLightRotationMatrix()[i*3+j];

      //glMultMatrixf(mRot.L);
      //glRotatef(-90,1,0,0);
      glutWireCone(0.4f,0.8f, 20,20);
    }

    //glutSolidSphere(pLight->radius,20,20);
    glPopMatrix();
  }

  glPopMatrix();
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_LIGHTING);

}


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::Clear(int a_flags)
{
  if(a_flags & CLEAR_MATERIALS)
  {
    m_triangleMaterialId.clear();
    m_texMatrices.resize(1);
    m_texMatrices[0] = Matrix4x4f();
  }

  if(a_flags & CLEAR_GEOMETRY)
  {
    m_spheres.clear();
    m_index.clear();
    m_triangleMaterialId.clear();
    m_vertPos.clear();
    m_vertNorm.clear();
    m_vertTexCoord.clear();
    m_vertTangent.clear();
  }

  if(a_flags & CLEAR_LIGHTS)
    m_lights.resize(0);

  if(a_flags & CLEAR_TEXTURES) //#UNCHECKED
  {
    for(int i=0;i<m_images.size();i++)
      m_images[i].FreeData();
    m_images.resize(0);
  }
}



/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddMaterial(const RAYTR::HydraMaterial& mat)
{
  if (mat.ambient.color_texId != INVALID_TEXTURE && mat.ambient.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for ambient.color");

  if (mat.diffuse.color_texId != INVALID_TEXTURE && mat.diffuse.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for diffuse.color");

  if (mat.specular.color_texId != INVALID_TEXTURE && mat.specular.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for specular.color");

  if (mat.reflection.color_texId != INVALID_TEXTURE && mat.reflection.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for reflection.color");

  if (mat.transparency.color_texId != INVALID_TEXTURE && mat.transparency.color_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for refraction.color");

  if (mat.displacement.normals_texId != INVALID_TEXTURE && mat.displacement.normals_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for mat.displacement.normals_texId");

  if (mat.displacement.height_texId != INVALID_TEXTURE && mat.displacement.height_texId >= m_images.size()) 
    RUN_TIME_ERROR("AddMaterial, invalid texture id for mat.displacement.height_texId");

  m_hydraMaterials.push_back(mat);
  m_dirtyHydraMaterials = true;
  return (unsigned int)m_hydraMaterials.size()-1;
}


/////////////////////////////////////////////////////////////////////////////////////
////
vec2ui Common_Graphics_Engine::AddTriangles(const Vertex4f* v, int N_vertices,
                                            const unsigned int* indices,int N_indices, int a_flags)
{ 
  Matrix4x4f identityMatrix;
  vec2ui res(m_vertPos.size(), m_index.size());

  this->DeclareVertexInputLayout(VERTEX_POSITION | VERTEX_NORMAL | VERTEX_UV | VERTEX_MATERIAL_ID);
  this->SetVertexPositionPointer((const float*)&v[0].pos, sizeof(Vertex4f));
  this->SetVertexNormalPointer((const float*)&v[0].norm, sizeof(Vertex4f));
  this->SetVertexUVPointer((const float*)&v[0].t, sizeof(Vertex4f));
  this->SetVertexMaterialIdPointer((const int*)&v[0].material_id, sizeof(Vertex4f));
  this->AddTriangles(identityMatrix, indices, N_indices, N_vertices, a_flags);

  return res;
}

/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddSpheres(const Sphere4f* s, int N_spheres)
{
  int oldSize = m_spheres.size();
  for(int i=0;i<N_spheres;i++)
    m_spheres.push_back(s[i]);
  return oldSize;
}

void MakeLightPhysicallyCorrect(RAYTR::Light& light)
{
  if(light.GetLightType() != RAYTR::Light::LIGHT_TYPE_DIRECTIONAL && 
     light.GetLightType() != RAYTR::Light::LIGHT_TYPE_SPOT && 
     light.GetLightType() != RAYTR::Light::LIGHT_TYPE_SKY)
  {
    light.kc = 0.0; 
    light.kl = 0.0; 
    light.kq = 1.0;
  }

  if (light.GetLightType() != RAYTR::Light::LIGHT_TYPE_SKY && light.GetLightType() != RAYTR::Light::LIGHT_TYPE_MESH && !(light.flags & RAYTR::Light::LIGHT_SKY_PORTAL))
    light.intensity = light.intensity*MGML_MATH::PI;
  
  light.surfaceArea = 1.0f;
  light.emittance   = light.intensity;
  light.surfaceArea = LightComputeSurfaceArea(light);


}


/////////////////////////////////////////////////////////////////////////////////////
////
uint Common_Graphics_Engine::AddLight(const RAYTR::Light& a_light)
{
  RAYTR::Light light = a_light;

  MakeLightPhysicallyCorrect(light);

  m_lights.push_back(light);
  m_dirtyLights = true;

  return m_lights.size()-1;
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetLight(const RAYTR::Light& a_light,int index)
{
  if(index >= m_lights.size())
    RUN_TIME_ERROR("SetLight: no light with this index: " + ToString(index));

  RAYTR::Light light = a_light;

  MakeLightPhysicallyCorrect(light);

  m_dirtyLights   = true;
  m_lights[index] = light;
}

/////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::GetLightNumber() const { return m_lights.size(); }

/////////////////////////////////////////////////////////////////////////////////////
////
const RAYTR::Light& Common_Graphics_Engine::GetLight(int index) const
{
  if(index >= m_lights.size())
    RUN_TIME_ERROR("No lights with this index: " + ToString(index));

  return m_lights[index];
}


RAYTR::HydraMaterial Common_Graphics_Engine::GetHydraMaterial(int a_id)
{
  if(a_id >= m_hydraMaterials.size())
    RUN_TIME_ERROR("No hydra material with this index: " + ToString(a_id));

  return m_hydraMaterials[a_id];
}

void Common_Graphics_Engine::SetHydraMaterial(const RAYTR::HydraMaterial& rhs, int a_id)
{
  if(a_id >= m_hydraMaterials.size())
    RUN_TIME_ERROR("No hydra material with this index: " + ToString(a_id));

  m_dirtyHydraMaterials  = true;
  m_hydraMaterials[a_id] = rhs;
}

void Common_Graphics_Engine::SetWindowResolution(int a_width, int a_height)
{

}

/////////////////////////////////////////////////////////////////////////////////////
////
unsigned int Common_Graphics_Engine::AddTexture(const void* memory, uint w, uint h, uint a_bytesPerPixel)
{
  if(w == 0 || w > 65536)
    RUN_TIME_ERROR("AddTexture, incorrect width");

  if(h == 0 || h > 32768)
    RUN_TIME_ERROR("AddTexture, incorrect height");

  if(a_bytesPerPixel == 0 || a_bytesPerPixel > 16)
    RUN_TIME_ERROR("AddTexture, incorrect bpp");

  if(m_images.size() == 0)
    m_images.reserve(100);

  m_images.push_back(ImageStorage());
  m_images[m_images.size()-1].SetData((const unsigned char*)memory, w, h, a_bytesPerPixel);

  return m_images.size()-1;
}

void Common_Graphics_Engine::SetAuxCamProjParams(const float params[4])
{
  m_projParams.x = MGML_MATH::DEG_TO_RAD(params[0]);
  m_projParams.y = params[1];
  m_projParams.z = params[2];
  m_projParams.w = params[3];
}


int Common_Graphics_Engine::WriteTriangle(int index, void* pAddressToWrite, char* pAddressStart)
{
  ObjectListTriangle t;

  int A_offs = this->m_index[3 * index + 0];
  int B_offs = this->m_index[3 * index + 1];
  int C_offs = this->m_index[3 * index + 2];

  int matId = this->GetTriangleMaterialId(index);

  if (matId >= this->m_hydraMaterials.size())
  {
    RUN_TIME_ERROR("Invalid m_data->GetTriangleMaterialId(index)");
    matId = 0;
  }
  else
  {
    const HydraMaterial& material = this->m_hydraMaterials[matId];

    if (!(material.flags & HydraMaterial::TRANSPARENCY_THIN_SURFACE) && 
        !(material.flags & HydraMaterial::MATERIAL_SKIP_SHADOW) && 
        length(material.transparency.color) < 0.001f)
      matId = 0xFFFFFFFF; // write spetial geom transparency flag. If no transparency happen, put 0xFFFFFFFF

    if (material.flags & HydraMaterial::THIS_IS_LIGHT)
    {
      int lightid = material.ambient.light_id;

      if (lightid >= 0)
      {
        int lightMeshId = this->m_lights[lightid].lightMeshIndex;

        if (lightMeshId < 255) // WTF ? --> aah ok
          matId = (matId & ALPHA_MATERIAL_MASK) | ((lightMeshId << ALPHA_LIGHTMESH_SHIFT) & ALPHA_LIGHTMESH_MASK);
      }
    }
  }

#if TRIANGLE_LAYOUT == VERTEX_TRIANGLE_LAYOUT

  t.v1 = this->GetVertexPos(A_offs);
  t.v2 = this->GetVertexPos(B_offs);
  t.v3 = this->GetVertexPos(C_offs);

  int* pFlags = (int*)(&t.v1.w);      // put matId and flag for alpha test, aka flags;
  *pFlags = matId;

  int* pMaterialId = (int*)(&t.v2.w); // put common matId, aka matIndex
  *pMaterialId = this->GetTriangleMaterialId(index);

  int* pTriIndex =  (int*)(&t.v3.w);  // put tri index here, aka selfIndex
  (*pTriIndex) = 3*index;

#elif TRIANGLE_LAYOUT == INDEX_TRIANGLE_LAYOUT

  t.v[0] = this->m_index[3 * index + 0];
  t.v[1] = this->m_index[3 * index + 1];
  t.v[2] = this->m_index[3 * index + 2];

#elif TRIANGLE_LAYOUT == MATRIX_TRIANGLE_LAYOUT

  float3 A = to_float3(this->GetVertexPos(A_offs));
  float3 B = to_float3(this->GetVertexPos(B_offs));
  float3 C = to_float3(this->GetVertexPos(C_offs));
  float3 N = normalize(cross(A - C, B - C));

  MGML::Matrix4x4f m1;

  m1.M[0][0] = A.x - C.x;
  m1.M[1][0] = A.y - C.y;
  m1.M[2][0] = A.z - C.z;

  m1.M[0][1] = B.x - C.x;
  m1.M[1][1] = B.y - C.y;
  m1.M[2][1] = B.z - C.z;

  m1.M[0][2] = N.x - C.x;
  m1.M[1][2] = N.y - C.y;
  m1.M[2][2] = N.z - C.z;

  m1.M[0][3] = C.x;
  m1.M[1][3] = C.y;
  m1.M[2][3] = C.z;

  m1 = MGML::SafeInverse(m1);

  for (int i = 0; i<3; i++)
  {
    t.m.row[i].x = m1.M[i][0];
    t.m.row[i].y = m1.M[i][1];
    t.m.row[i].z = m1.M[i][2];
    t.m.row[i].w = m1.M[i][3];
  }

  // swap rows
  //
  float4 temp[3];
  temp[0] = t.m.row[0];
  temp[1] = t.m.row[1];
  temp[2] = t.m.row[2];

  t.m.row[0] = temp[2];
  t.m.row[1] = temp[0];
  t.m.row[2] = temp[1];

#else
  RUN_TIME_ERROR("uups");
#endif


  ObjectListTriangle* result = (ObjectListTriangle*)pAddressToWrite;
  (*result) = t;
  
  return sizeof(ObjectListTriangle);
}




size_t Common_Graphics_Engine::PutPrimitivesToFinalBuffer(const std::vector<BvhLeafInfo>& a_beginEndArray,
                                                          const std::vector<int>&         a_indexArray,
                                                          std::vector<BVHNode>&           a_inBVH,
                                                          std::vector<char>&              outMemory,
                                                          RAYTR::InputData*               pInput)
{

  outMemory.resize(sizeof(ObjectListTriangle)*a_indexArray.size() + sizeof(ObjectList)*a_beginEndArray.size() + 2*sizeof(ObjectList));

  size_t oldSize = 0;

  // first put all triangles just as blob
  //
  for (size_t triId = 0; triId < a_indexArray.size(); triId++)
  {
    WriteTriangle(a_indexArray[triId], &outMemory[0] + oldSize, &outMemory[0]);
    oldSize += sizeof(ObjectListTriangle);
  }
  
  // then put all objectList structures
  //
  for (size_t leafId = 0; leafId < a_beginEndArray.size(); leafId++)
  {
    BvhLeafInfo leafData = a_beginEndArray[leafId];
    BVHNode* currNode = &a_inBVH[leafData.leafOffset];

    int size = sizeof(ObjectList);

    if (oldSize + size >= outMemory.size())
      outMemory.resize(outMemory.size() + outMemory.size() / 2);

    char* dataPointer = &outMemory[0] + oldSize;

    ((ObjectList*)dataPointer)->m_offset        = (leafData.begin*sizeof(ObjectListTriangle)) / sizeof(float4);
    ((ObjectList*)dataPointer)->m_triangleCount = (leafData.end - leafData.begin);

    dataPointer += sizeof(ObjectList);

    currNode->SetLeaf(1);
    currNode->SetObjectListOffset(oldSize / sizeof(float4));

    oldSize += size;
  }
  
  // write tail for the case if sizeof(ObjectList) != sizeof(float4)
  //
  if (a_beginEndArray.size() % 2 != 0)
  {
    char* dataPointer = &outMemory[0] + oldSize;
    ((ObjectList*)dataPointer)->m_offset = 0;
    ((ObjectList*)dataPointer)->m_triangleCount = 0;
    dataPointer += sizeof(ObjectList);
  }

  outMemory.resize(oldSize);

  return oldSize;
}





/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::BuildAccelerationStructures(const std::string& a_geomMD5, const std::string& a_lightsMD5)
{ 
  BVHUserInput input(this);
  input.progressBar = m_updateProgressCall;

  AccelStructSettings  presets;
  presets.flags = AccelStructSettings::INPUT_TRIANGLES | AccelStructSettings::CONSTRUCT_QUALITY;
  presets.maxDeep = 64;
  presets.maxPrimInLeaf = 32;
  presets.recomendedPrimInLeaf = 4;


  delete m_pBVHBuilder;
  m_pBVHBuilder = new BVHBuilderRef_vfrolov;

  m_pBVHBuilder->Build(&input, presets, &m_bvhGlobal);

  m_bBox.vmin = m_bvhGlobal.boxMin;
  m_bBox.vmax = m_bvhGlobal.boxMax;

  PutPrimitivesToFinalBuffer(m_bvhGlobal.leafesInfo, m_bvhGlobal.indices, m_bvhGlobal.nodes, m_bvhObjListData, &input);

  m_accelStructuresDirty = false;

  //if(m_voxelizeOnLoad)
  // VoxelizeAllGeometry();
}



/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::DebugDrawAccelStruct()
{

  //vec3f farPos = g_debugRay.pos + g_debugRay.dir*1000.0f;
  //glColor3f(0,0,1);
  //glBegin(GL_LINES);
  //glVertex3fv(g_debugRay.pos.M);
  //glVertex3fv(farPos.M);
  //glEnd();

} 


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::VerifyData()
{
  return; 
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::VerifyAllData()
{
  if(m_hydraMaterials.size() == 0)
    std::cerr << "[Engine]: WARNING - materials (hydra) were not set" << std::endl;

  if(m_lights.size() == 0)
    std::cerr << "[Engine] WARNING: lights (hydra) were not set" << std::endl;

  if(m_images.size() == 0)
    std::cerr << "[Engine] WARNING: textures were not set" << std::endl;

  m_dataVerifyed = true;
}


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::CalcTangentSpace()
{
  int vertexCount   = m_vertPos.size();
  int triangleCount = m_index.size()/3; 

  float4 *tan1 = new float4[vertexCount * 2];
  float4 *tan2 = tan1 + vertexCount;
  ZeroMemory(tan1, vertexCount * sizeof(float4) * 2);

  for (long a = 0; a < triangleCount; a++)
  {
    long i1 = m_index[3*a+0];
    long i2 = m_index[3*a+1];
    long i3 = m_index[3*a+2];

    const float4& v1 = m_vertPos[i1];
    const float4& v2 = m_vertPos[i2];
    const float4& v3 = m_vertPos[i3];

    const float2& w1 = m_vertTexCoord[i1];
    const float2& w2 = m_vertTexCoord[i2];
    const float2& w3 = m_vertTexCoord[i3];

    float x1 = v2.x - v1.x;
    float x2 = v3.x - v1.x;
    float y1 = v2.y - v1.y;
    float y2 = v3.y - v1.y;
    float z1 = v2.z - v1.z;
    float z2 = v3.z - v1.z;

    float s1 = w2.x - w1.x;
    float s2 = w3.x - w1.x;
    float t1 = w2.y - w1.y;
    float t2 = w3.y - w1.y;

    float r = 1.0f / (s1 * t2 - s2 * t1);
    float4 sdir((t2 * x1 - t1 * x2) * r, (t2 * y1 - t1 * y2) * r, (t2 * z1 - t1 * z2) * r, 1);
    float4 tdir((s1 * x2 - s2 * x1) * r, (s1 * y2 - s2 * y1) * r, (s1 * z2 - s2 * z1) * r, 1);

    tan1[i1] += sdir;
    tan1[i2] += sdir;
    tan1[i3] += sdir;

    tan2[i1] += tdir;
    tan2[i2] += tdir;
    tan2[i3] += tdir;
  }

  m_vertTangent.resize(vertexCount);

  for (long a = 0; a < vertexCount; a++)
  {
    const float4& n = m_vertNorm[a];
    const float4& t = tan1[a];

    // Gram-Schmidt orthogonalization
    m_vertTangent[a] = normalize(t - n * dot(n, t));

    // Calculate handedness
    m_vertTangent[a].w = (dot(cross(n, t), tan2[a]) < 0.0f) ? -1.0f : 1.0f;
  }

  delete [] tan1;
}






/////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::BVHUserInput::GetNumTriangles() const throw (std::runtime_error)
{
  ASSERT(m_data->m_index.size()%3 == 0);
  return m_data->m_index.size()/3;
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::BVHUserInput::GetTriangle(int index, float A[3], float B[3], float C[3]) const throw (std::runtime_error)
{
  int iA = m_data->m_index[3*index+0];
  int iB = m_data->m_index[3*index+1];
  int iC = m_data->m_index[3*index+2];

  float4 aPos = m_data->GetVertexPos(iA);
  float4 bPos = m_data->GetVertexPos(iB);
  float4 cPos = m_data->GetVertexPos(iC);

  for(int i=0;i<3;i++)
  {
    A[i] = aPos.M[i];
    B[i] = bPos.M[i];
    C[i] = cPos.M[i];
  }
}

/////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::BVHUserInput::GetNumSpheres() const throw (std::runtime_error)
{
  return m_data->m_spheres.size();
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::BVHUserInput::GetSphere(int index, float sph_pos[3], float* sph_r) const throw (std::runtime_error)
{ 
  float4 spPos = m_data->GetSpherePos(index);
  sph_pos[0] = spPos.M[0];
  sph_pos[1] = spPos.M[1];
  sph_pos[2] = spPos.M[2];

  *sph_r = m_data->GetSphereRadius(index);
}



/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVariable(const std::string& a_name, int a_val)
{
  m_ivars[a_name] = a_val;
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVariable(const std::string& a_name, float a_val)
{
  m_fvars[a_name] = a_val;
}





float LightComputeSurfaceArea(const RAYTR::Light& light)
{
  float surfaceArea = 1.0f;

  switch (light.GetLightType())
  {
  case RAYTR::Light::LIGHT_TYPE_AREA:
  {
    float3 vert[4];

    float2 size = light.GetAreaLightSize();
    vert[0].set(-size.x, 0, -size.y);
    vert[1].set(-size.x, 0, size.y);
    vert[2].set(size.x, 0, size.y);
    vert[3].set(size.x, 0, -size.y);

    Matrix4x4f mTransform, mRotation, mTranslate;
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        mRotation.M[i][j] = light.GetMatrixElem(i, j);
    mTranslate.SetTranslate(light.pos);
    mTransform = mTranslate*mRotation;

    for (int i = 0; i < 4; i++)
      vert[i] = mTransform*vert[i];

    float sizeX = length(vert[1] - vert[0]);
    float sizeY = length(vert[1] - vert[2]);

    surfaceArea = sizeX*sizeY;
  }
    break;

  case RAYTR::Light::LIGHT_TYPE_AREA_DISK:
  {
    float R = light.GetSphericalLightRadius();
    Matrix4x4f mTransform;
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        mTransform.M[i][j] = light.GetMatrixElem(i, j);

    R = length(mTransform*float3(0, R, 0));
    surfaceArea = MGML_MATH::PI*R*R;
  }
    break;


  case RAYTR::Light::LIGHT_TYPE_SPHERICAL:
  {
    float R = light.GetSphericalLightRadius();
    surfaceArea = 4.0f*3.1415926535f*R*R;
  }
    break;

  default:
    surfaceArea = 1.0f;
    break;
  }

  return surfaceArea;
}



