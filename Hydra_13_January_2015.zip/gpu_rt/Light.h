#define LIGHT_GUARDIAN

#ifndef MGML_GPU_GUARDIAN
  #include "../CSL/MGML_GPU.h"
#endif

namespace RAYTR
{

  struct Light
  {
    enum {LIGHT_TYPE_POINT, LIGHT_TYPE_SPOT, LIGHT_TYPE_DIRECTIONAL, LIGHT_TYPE_SKY,
          LIGHT_TYPE_AREA, LIGHT_TYPE_AREA_DISK, LIGHT_TYPE_SPHERICAL, LIGHT_TYPE_MESH};

    enum CUST_DIST{LD_UNIFORM = 0, LD_DIFFUSE = 1, LD_SPOT = 2, LD_RAYSET = 3, LD_DEFAULT = 0xFFFFFFFF};

    enum FLAGS{ LIGHT_ACTIVE                 = 1, 
                LIGHT_COMPUTE_AREA_SHADING   = 2, 
                LIGHT_AS_GEOMETRY            = 4,
                LIGHT_ENV_USE_SIMPLE_COLOR   = 8,
                LIGHT_MESH_FLAT              = 16,
                LIGHT_DIRECT_SIMULATE_SUN    = 32,
                LIGHT_DISABLE_FOR_PHOTONMAP  = 64,
                LIGHT_DIRECT_HAS_CIRCLE_SIZE = 128,
                LIGHT_CAUSTIC_NO_DIRECT      = 256,
                LIGHT_SKY_PORTAL             = 512,
                LIGHT_SKY_PORTAL_SOURCE2     = 1024,   // skylight
                LIGHT_SKY_PORTAL_SOURCE3     = 2048,
                LIGHT_SKY_PORTAL_SOURCE4     = 4096,
                LIGHT_MR_DISABLE_PHOTONS_GI  = 8192,
                LIGHT_MR_DISABLE_PHOTONS_CI  = 8192*2}; 

    #ifndef __CUDACC__
    Light()
    {
      intensity = 1.0f;
      color = make_float3(1,1,1);
      kc = 0.0f;
      kl = 0.0f;
      kq = 1.0f;
      flags = LIGHT_ACTIVE | LIGHT_COMPUTE_AREA_SHADING | LIGHT_AS_GEOMETRY;
 
      surfaceArea = 1.0f;
      m_spotCutoffAngleCos[0] = cos(3.141592654f/6.0f);
      m_spotCutoffAngleCos[1] = cos(3.141592654f/2.0f);

      m_type              = RAYTR::Light::LIGHT_TYPE_POINT;
      m_customDistribType = LD_DEFAULT;

      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          M[i][j] = 0;

      M[0][0] = M[1][1] = M[2][2] = 1.0f;

      emissiveTexId = INVALID_TEXTURE;
      emissiveTexMatrixId = 0;

      sphTexMatrices[0] = 0;
      sphTexMatrices[1] = 0;
    }
    ~Light(){}
    #endif


    void SetLighType(int a_type) {m_type = a_type;}
    
    inline universal_call int GetLightType() const { return m_type; }
    
    inline universal_call bool hasSize() const { return ((m_type == LIGHT_TYPE_AREA) || (m_type == LIGHT_TYPE_AREA_DISK) || (m_type == LIGHT_TYPE_SPHERICAL)) && (flags & LIGHT_AS_GEOMETRY); }

    
    inline universal_call bool IsSampledDirectly() const { return Active() && 
                                                                  (m_type != Light::LIGHT_TYPE_SKY) && 
                                                                  (m_type != Light::LIGHT_TYPE_MESH || (flags & LIGHT_MESH_FLAT)) &&
                                                                  !(flags & LIGHT_CAUSTIC_NO_DIRECT); }

    inline universal_call float pdfArea() const
    {
      return 1.0f/fmaxf(surfaceArea, 1e-20f);
    }

    void SetMatrixRotation(const float* a_m)
    {
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          M[i][j] = a_m[i*4+j];
    }

    void GetMatrixRotation(float* a_m) const
    {
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          a_m[i*4+j] = M[i][j];
    }

    void SetAreaLightSize(float sz_x, float sz_y)
    {
      m_size.x = sz_x;
      m_size.y = sz_y;
    }

    void SetSphericalLightRadius(float a_r) { m_size.x = a_r; }

    void SetSunAngleCos(float a_cos)
    {
      m_size.y = a_cos;
      flags |= LIGHT_DIRECT_SIMULATE_SUN;
    }

    float GetSunAngleCos() { return m_size.y; }

    void SetActive(bool a_active)
    {
      if(a_active)
        flags = flags | LIGHT_ACTIVE;
      else
        flags = flags & (~LIGHT_ACTIVE); // flags.LIGHT_ACTIVE = false;
    }

    inline universal_call float GetSphericalLightRadius() const  { return m_size.x; }
    inline universal_call float2 GetAreaLightSize() const { return m_size; }
    inline universal_call float3 GetNormal() const { return m_norm; }
    inline universal_call const float* GetAreaLightRotationMatrix() const { return L; }
    inline universal_call bool  Active() const  { return (flags & LIGHT_ACTIVE); }
    inline universal_call float GetSpotLightCutoff(int i) const { return m_spotCutoffAngleCos[i]; }
    inline universal_call float GetMatrixElem(int i, int j) const { return M[i][j]; }
    inline universal_call void  SetPrimitiveId(int a_id){ m_spotCutoffAngleCos[1] = *( (float*)(&a_id) ); }
    inline universal_call int   GetDistrbType() const { return m_customDistribType; }
    
#ifdef __CUDACC__
    inline __device__ int  GetPrimitiveId() const {return as_int(m_spotCutoffAngleCos[1]);} 
#endif

    inline universal_call void  SetAORayLength(float a_length){ m_spotCutoffAngleCos[1] = a_length; }
    inline universal_call float GetAORayLength() const {return m_spotCutoffAngleCos[1];}    

    float3 pos;
    float3 color;
    float  intensity;
    float  kc, kl, kq;

    float  surfaceArea;
    float  emittance;

  //protected:
    
    int m_type;

    float3 m_norm; // for directional lights
    float2 m_size; // for area lights

    enum {SPOT_REGIONS = 2}; // number of conuces for spot lights (SPOT and SPOT_AREA)
    float m_spotCutoffAngleCos[SPOT_REGIONS];
    int   m_customDistribType;
    float m_dummy; 

    union
    {
      float M[3][3];
      float L[9];

      int texCudeIndices[6];
      int sphTexIndex[2];

      struct // for mesh lights
      {
        int matId;
        int lightMeshIndex;
      };
    };

    int sphTexMatrices[2];


    int    flags;

    // for mesh lights onstructed from emissive material and flat lights with emissive textures
    //    
    int    emissiveTexId;
    int    emissiveTexMatrixId;
  };


}




