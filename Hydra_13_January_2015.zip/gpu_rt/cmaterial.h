#ifndef RTCMATERIAL
#define RTCMATERIAL

#include "globals.h"


#define MIX_MATERIAL_DATA_SIZE 32
#define MIX_MAX_TEXTURE_SLOTS 32
#define MIX_TREE_MAX_DEEP 4

enum PLAIN_MAT_TYPES { 
  PLAIN_MAT_CLASS_MIX            = 0, 
  PLAIN_MAT_CLASS_EMISSIVE       = 1,
  PLAIN_MAT_CLASS_LAMBERT        = 2,
  PLAIN_MAT_CLASS_PHONG_SPECULAR = 3,
  PLAIN_MAT_CLASS_BLINN_SPECULAR = 4, // Micro Facet Torrance Sparrow model with Blinn distribution
  PLAIN_MAT_CLASS_PERFECT_MIRROR = 5,
  PLAIN_MAT_CLASS_THIN_GLASS     = 6,
  PLAIN_MAT_CLASS_GLASS          = 7,
  PLAIN_MAT_CLASS_BLEND_MASK     = 8,


};

enum PLAIN_MAT_FLAGS{
  PLAIN_MATERIAL_IS_LIGHT         = 1,
  PLAIN_MATERIAL_CAST_CAUSTICS    = 2,
  PLAIN_MATERIAL_HAS_DIFFUSE      = 4,
  PLAIN_MATERIAL_HAS_TRANSPARENCY = 8,
};


struct PlainMaterialT
{
  float data[MIX_MATERIAL_DATA_SIZE];
  float intervals[MIX_MATERIAL_DATA_SIZE];
  int   allTextureIndices[MIX_MAX_TEXTURE_SLOTS];   // used only by root material to prefetch texture data
  int   allTextureMatrices[MIX_MAX_TEXTURE_SLOTS];  // used only by root material to prefetch texture data
};

typedef struct PlainMaterialT PlainMaterial;


#define PLAIN_MAT_TYPE_OFFSET        0
#define PLAIN_MAT_FLAGS_OFFSET       1
#define PLAIN_MAT_COMPONENTS_OFFSET  2

ID_CALL int  materialGetType         (__global PlainMaterial* a_pMat) { return as_int(a_pMat->data[PLAIN_MAT_TYPE_OFFSET]); }
ID_CALL int  materialGetFlags        (__global PlainMaterial* a_pMat) { return as_int(a_pMat->data[PLAIN_MAT_FLAGS_OFFSET]); }
ID_CALL int  materialGetNumComponents(__global PlainMaterial* a_pMat) { return as_int(a_pMat->data[PLAIN_MAT_FLAGS_OFFSET]); }

ID_CALL bool materialCastCaustics(__global PlainMaterial* a_pMat)    { return (as_int(a_pMat->data[PLAIN_MAT_FLAGS_OFFSET]) & PLAIN_MATERIAL_CAST_CAUSTICS); }
ID_CALL bool materialHasDiffuse(__global PlainMaterial* a_pMat)      { return (as_int(a_pMat->data[PLAIN_MAT_FLAGS_OFFSET]) & PLAIN_MATERIAL_HAS_DIFFUSE); }
ID_CALL bool materialHasTransparency(__global PlainMaterial* a_pMat) { return (as_int(a_pMat->data[PLAIN_MAT_FLAGS_OFFSET]) & PLAIN_MATERIAL_HAS_TRANSPARENCY); }

// emissive component, always present in material to speed-up code
//
#define EMISSIVE_COLORX_OFFSET       4
#define EMISSIVE_COLORY_OFFSET       5
#define EMISSIVE_COLORZ_OFFSET       6

#define EMISSIVE_TEXID_OFFSET        7
#define EMISSIVE_TEXMATRIXID_OFFSET  8
#define EMISSIVE_LIGHTID_OFFSET      9

IDH_CALL float3 materialGetEmission(__global PlainMaterial* a_pMat) { return make_float3(a_pMat->data[EMISSIVE_COLORX_OFFSET], a_pMat->data[EMISSIVE_COLORY_OFFSET], a_pMat->data[EMISSIVE_COLORZ_OFFSET]); }
ID_CALL  int2   materialGetEmissionTex(__global PlainMaterial* a_pMat)
{
  int2 res;
  res.x = as_int(a_pMat->data[EMISSIVE_TEXID_OFFSET]);
  res.y = as_int(a_pMat->data[EMISSIVE_TEXMATRIXID_OFFSET]);
  return res;
}

IDH_CALL int materialIsLight(__global PlainMaterial* a_pMat) { return length(materialGetEmission(a_pMat)) > 1e-4f ? 1 : 0; }
ID_CALL  int materialGetLightId(__global PlainMaterial* a_pMat) { return as_int(a_pMat->data[EMISSIVE_LIGHTID_OFFSET]); }

//////////////////////////////////////////////////////////////// all other components may overlay their offsets

// lambert material
//
#define LAMBERT_COLORX_OFFSET       10
#define LAMBERT_COLORY_OFFSET       11
#define LAMBERT_COLORZ_OFFSET       12

#define LAMBERT_TEXID_OFFSET        13
#define LAMBERT_TEXMATRIXID_OFFSET  14

IDH_CALL float3 lambertGetDiffuseColor(__global PlainMaterial* a_pMat) { return make_float3(a_pMat->data[LAMBERT_COLORX_OFFSET], a_pMat->data[LAMBERT_COLORY_OFFSET], a_pMat->data[LAMBERT_COLORZ_OFFSET]); }
ID_CALL  int2   lambertGetDiffuseTex(__global PlainMaterial* a_pMat) 
{
  int2 res;
  res.x = as_int(a_pMat->data[LAMBERT_TEXID_OFFSET]);
  res.y = as_int(a_pMat->data[LAMBERT_TEXMATRIXID_OFFSET]);
  return res;
}


IDH_CALL float  lambertEvalPDF (__global PlainMaterial* a_pMat, float3 l, float3 n) { return fmax(dot(l, n), 0.0f)*INV_PI; }
IDH_CALL float3 lambertEvalBxDF(__global PlainMaterial* a_pMat, float3 l, float3 n) { return lambertGetDiffuseColor(a_pMat)*fmax(dot(l, n), 0.0f)*INV_PI; }

IDH_CALL MatSample lambertSampleAndEvalBRDF(__global PlainMaterial* a_pMat, float a_r1, float a_r2, float3 a_normal, float2 a_texCoord)
{
  float3 kd       = lambertGetDiffuseColor(a_pMat);
  float3 newDir   = MapSampleToCosineDistribution(a_r1, a_r2, a_normal, a_normal, 1.0f);
  float  cosTheta = fmax(dot(newDir, a_normal), 0.0f);

  MatSample res;
  res.direction    = newDir;
  res.pdf          = cosTheta*INV_PI;
  res.color        = kd*cosTheta*INV_PI;
  res.pureSpecular = false;
  return res;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// perfect mirror material
//
#define MIRROR_COLORX_OFFSET       10
#define MIRROR_COLORY_OFFSET       11
#define MIRROR_COLORZ_OFFSET       12

#define MIRROR_TEXID_OFFSET        13
#define MIRROR_TEXMATRIXID_OFFSET  14

IDH_CALL float3 mirrorGetColor(__global PlainMaterial* a_pMat) { return make_float3(a_pMat->data[MIRROR_COLORX_OFFSET], a_pMat->data[MIRROR_COLORY_OFFSET], a_pMat->data[MIRROR_COLORZ_OFFSET]); }
ID_CALL  int2   mirrorGetTex(__global PlainMaterial* a_pMat)
{
  int2 res;
  res.x = as_int(a_pMat->data[MIRROR_TEXID_OFFSET]);
  res.y = as_int(a_pMat->data[MIRROR_TEXMATRIXID_OFFSET]);
  return res;
}


IDH_CALL float mirrorEvalPDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{
  return 0.0f; // because we don't want to sample thsi material with shadow rays 
}

IDH_CALL float3 mirrorEvalBxDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{
  return make_float3(0,0,0);  // because we don't want to sample thsi material with shadow rays 
}

ID_CALL MatSample mirrorSampleAndEvalBRDF(__global PlainMaterial* a_pMat, float a_r1, float a_r2, float3 ray_dir, float3 a_normal, float2 a_texCoord)
{
  MatSample res;
  res.direction    = reflect(ray_dir, a_normal);
  res.pdf          = 1.0f;
  res.color        = mirrorGetColor(a_pMat);
  res.pureSpecular = true;
  return res;

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// thin glass surface
//
#define THINGLASS_COLORX_OFFSET       10
#define THINGLASS_COLORY_OFFSET       11
#define THINGLASS_COLORZ_OFFSET       12

#define THINGLASS_TEXID_OFFSET        13
#define THINGLASS_TEXMATRIXID_OFFSET  14

IDH_CALL float3 thinglassGetColor(__global PlainMaterial* a_pMat) { return make_float3(a_pMat->data[THINGLASS_COLORX_OFFSET], a_pMat->data[THINGLASS_COLORY_OFFSET], a_pMat->data[THINGLASS_COLORZ_OFFSET]); }
ID_CALL  int2   thinglassGetTex(__global PlainMaterial* a_pMat)
{
  int2 res;
  res.x = as_int(a_pMat->data[THINGLASS_TEXID_OFFSET]);
  res.y = as_int(a_pMat->data[THINGLASS_TEXMATRIXID_OFFSET]);
  return res;
}


IDH_CALL float thinglassEvalPDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{
  return 0.0f;  // because we don't want to sample thsi material with shadow rays 
}

IDH_CALL float3 thinglassEvalBxDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{
  return make_float3(0, 0, 0);  // because we don't want to sample thsi material with shadow rays 
}

ID_CALL MatSample thinglassSampleAndEvalBRDF(__global PlainMaterial* a_pMat, float a_r1, float a_r2, float3 ray_dir, float3 a_normal, float2 a_texCoord)
{
  MatSample res;
  res.direction    = ray_dir;
  res.pdf          = 1.0f;
  res.color        = thinglassGetColor(a_pMat);
  res.pureSpecular = true;
  return res;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// 'fixed' phong material
//
#define PHONG_COLORX_OFFSET       10
#define PHONG_COLORY_OFFSET       11
#define PHONG_COLORZ_OFFSET       12

#define PHONG_TEXID_OFFSET        13
#define PHONG_TEXMATRIXID_OFFSET  14

#define PHONG_COSPOWER_OFFSET     15
#define PHONG_GLOSINESS_OFFSET    16

#define PHONG_GLOSINESS_TEXID_OFFSET        17
#define PHONG_GLOSINESS_TEXMATRIXID_OFFSET  18


IDH_CALL float3 phongGetColor(__global PlainMaterial* a_pMat) { return make_float3(a_pMat->data[PHONG_COLORX_OFFSET], a_pMat->data[PHONG_COLORY_OFFSET], a_pMat->data[PHONG_COLORZ_OFFSET]); }
ID_CALL  int2   phongGetTex(__global PlainMaterial* a_pMat)
{
  int2 res;
  res.x = as_int(a_pMat->data[PHONG_TEXID_OFFSET]);
  res.y = as_int(a_pMat->data[PHONG_TEXMATRIXID_OFFSET]);
  return res;
}


IDH_CALL float  phongEvalPDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{ 
  float3 r       = reflect((-1.0)*v, n);
  float cosTheta = clamp(dot(l, r), 0.0f, M_PI*0.499995f);
  float cosPower = a_pMat->data[PHONG_COSPOWER_OFFSET];
  return pow(cosTheta, cosPower) * (cosPower + 1.0f) * (0.5f * INV_PI); 
}

IDH_CALL float3 phongEvalBxDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{ 
  float3 color    = phongGetColor(a_pMat);
  float  cosPower = a_pMat->data[PHONG_COSPOWER_OFFSET];

  float3 r        = reflect((-1.0)*v, n);
  float  cosTheta = clamp(dot(l, r), 0.0f, M_PI*0.499995f);

  return color*(cosPower + 2.0f)*0.5f*INV_PI*pow(cosTheta, cosPower);

}

ID_CALL MatSample phongSampleAndEvalBRDF(__global PlainMaterial* a_pMat, float a_r1, float a_r2, float3 ray_dir, float3 a_normal, float2 a_texCoord)
{
  float3 color    = phongGetColor(a_pMat);
  float  cosPower = a_pMat->data[PHONG_COSPOWER_OFFSET];
 
  float3 r       = reflect(ray_dir, a_normal);
  float3 newDir  = MapSampleToModifiedCosineDistribution(a_r1, a_r2, r, a_normal, cosPower);
  
  float cosTheta = clamp(dot(newDir, r), 0.0, M_PI*0.499995);

  MatSample res;
  res.direction = newDir;
  res.pdf       = pow(cosTheta, cosPower) * (cosPower + 1.0f) * (0.5f * INV_PI);
  res.color     = color*((cosPower + 2.0f) * INV_TWOPI * pow(cosTheta, cosPower));
  res.pureSpecular = false;
  return res;

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// microfacet mode, blinn distribution and torrance-sparrow brdf in analogue to pbrt
//
#define BLINN_COLORX_OFFSET       10
#define BLINN_COLORY_OFFSET       11
#define BLINN_COLORZ_OFFSET       12

#define BLINN_TEXID_OFFSET        13
#define BLINN_TEXMATRIXID_OFFSET  14

#define BLINN_COSPOWER_OFFSET     15
#define BLINN_GLOSINESS_OFFSET    16

#define BLINN_GLOSINESS_TEXID_OFFSET        17
#define BLINN_GLOSINESS_TEXMATRIXID_OFFSET  18


IDH_CALL float3 blinnGetColor(__global PlainMaterial* a_pMat) { return make_float3(a_pMat->data[BLINN_COLORX_OFFSET], a_pMat->data[BLINN_COLORY_OFFSET], a_pMat->data[BLINN_COLORZ_OFFSET]); }
ID_CALL  int2   blinnGetTex(__global PlainMaterial* a_pMat)
{
  int2 res;
  res.x = as_int(a_pMat->data[BLINN_TEXID_OFFSET]);
  res.y = as_int(a_pMat->data[BLINN_TEXMATRIXID_OFFSET]);
  return res;
}


IDH_CALL float3 SphericalDirection(float sintheta, float costheta, float phi) { return make_float3(sintheta * cos(phi), sintheta * sin(phi), costheta); }
IDH_CALL bool SameHemisphere(float3 w, float3 wp) { return w.z * wp.z > 0.f; }

IDH_CALL float FrCond(float cosi, float eta, float k)
{
  float tmp    = (eta*eta + k*k) * cosi*cosi;
  float Rparl2 = (tmp - (2.f * eta * cosi) + 1.0f) / (tmp + (2.f * eta * cosi) + 1.0f);
  float tmp_f  = eta*eta + k*k;
  float Rperp2 = (tmp_f - (2.f * eta * cosi) + cosi*cosi) / (tmp_f + (2.f * eta * cosi) + cosi*cosi);
  return (Rparl2 + Rperp2) / 2.f;
}


IDH_CALL float TorranceSparrowG1(float3 wo, float3 wi, float3 wh) // in PBRT coord system
{
  float NdotWh  = fabs(wh.z);
  float NdotWo  = fabs(wo.z);
  float NdotWi  = fabs(wi.z);
  float WOdotWh = fabs(dot(wo, wh));

  return fmin(1.f, fmin((2.f * NdotWh * NdotWo / WOdotWh), (2.f * NdotWh * NdotWi / WOdotWh)));
}

IDH_CALL float TorranceSparrowG2(float3 wo, float3 wi, float3 wh, float3 n) // in normal word coord system
{
  float NdotWh  = fabs(dot(wh, n));
  float NdotWo  = fabs(dot(wo, n));
  float NdotWi  = fabs(dot(wi, n));
  float WOdotWh = fabs(dot(wo, wh));

  return fmin(1.f, fmin((2.f * NdotWh * NdotWo / WOdotWh), (2.f * NdotWh * NdotWi / WOdotWh)));
}

IDH_CALL float TorranceSparrowGF1(float3 wo, float3 wi) // in PBRT coord system
{
  float cosThetaO = fabs(wo.z); // inline float AbsCosTheta(const Vector &w) { return fabsf(w.z); }
  float cosThetaI = fabs(wi.z); // inline float AbsCosTheta(const Vector &w) { return fabsf(w.z); }

  if (cosThetaI == 0.0f || cosThetaO == 0.0f) 
    return 0.0f;

  float3 wh = wi + wo;
  if (wh.x == 0.0f && wh.y == 0.0f && wh.z == 0.0f) 
    return 0.0f;
  
  wh = normalize(wh);
  
  float cosThetaH = dot(wi, wh);
  float F = FrCond(cosThetaH, 5.0f, 1.25f); // fresnel->Evaluate(cosThetaH);

  return fmin(TorranceSparrowG1(wo, wi, wh) * F / (4.f * cosThetaI * cosThetaO), 4.0f);
}

IDH_CALL float TorranceSparrowGF2(float3 wo, float3 wi, float3 n)  // in normal word coord system
{
  float cosThetaO = fabs(dot(wo,n)); // inline float AbsCosTheta(const Vector &w) { return fabsf(w.z); }
  float cosThetaI = fabs(dot(wi,n)); // inline float AbsCosTheta(const Vector &w) { return fabsf(w.z); }

  if (cosThetaI == 0.f || cosThetaO == 0.0f)
    return 0.0f;

  float3 wh = wi + wo;
  if (wh.x == 0.0f && wh.y == 0.0f && wh.z == 0.0f)
    return 0.0f;

  wh = normalize(wh);

  float cosThetaH = dot(wi, wh);
  float F = FrCond(cosThetaH, 5.0f, 1.25f); // fresnel->Evaluate(cosThetaH);

  return TorranceSparrowG2(wo, wi, wh, n) * F / (4.f * cosThetaI * cosThetaO);
}


IDH_CALL float  blinnEvalPDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{
  float  exponent = a_pMat->data[BLINN_COSPOWER_OFFSET];

  float3 wh = normalize(l + v);
  float costheta = clamp(dot(l, wh), 0.0f, M_PI*0.499995f);

  float blinn_pdf = ((exponent + 1.0f) * pow(costheta, exponent)) / (2.f * M_PI * 4.f * dot(l, wh));

  if (dot(l, wh) <= 0.f)
    blinn_pdf = 1.0f;                                                                                            /////////////// WRONG ????!!!!

  return blinn_pdf;
}

IDH_CALL float3 blinnEvalBxDF(__global PlainMaterial* a_pMat, float3 l, float3 v, float3 n)
{
  float3 color = phongGetColor(a_pMat);
  float  exponent = a_pMat->data[BLINN_COSPOWER_OFFSET];

  float3 wh = normalize(l + v);

  float costheta = clamp(dot(l, wh), 0.0f, M_PI*0.499995f);
  float D = ((exponent + 2.0f) * INV_TWOPI * pow(costheta, exponent));

  if (dot(l, wh) <= 0.f)
    D = 0.0f;

  return color*D*TorranceSparrowGF2(l,v,n);

}

ID_CALL MatSample blinnSampleAndEvalBRDF(__global PlainMaterial* a_pMat, float a_r1, float a_r2, float3 ray_dir, float3 a_normal, float2 a_texCoord)
{
  float3 color = phongGetColor(a_pMat);
  float  cosPower = a_pMat->data[BLINN_COSPOWER_OFFSET];

  ///////////////////////////////////////////////////////////////////////////// to PBRT coordinate system
  //
  float3 nx, ny = a_normal, nz;
  CoordinateSystem(ny, &nx, &nz);
  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  float3 wo = make_float3(-dot(ray_dir, nx), -dot(ray_dir, ny), -dot(ray_dir, nz));
  //
  /////////////////////////////////////////////////////////////////////////////

  // Compute sampled half-angle vector $\wh$ for Blinn distribution
  //
  float exponent = cosPower;
  float u1       = a_r1;
  float u2       = a_r2;

  float costheta = pow(u1, 1.f / (exponent + 1.0f));
  float sintheta = sqrt(fmax(0.f, 1.f - costheta*costheta));
  float phi = u2 * 2.f * M_PI;
  float3 wh = SphericalDirection(sintheta, costheta, phi);
  
  if (!SameHemisphere(wo, wh)) 
    wh = wh*(-1.0f);

  float3 wi = (2.0f * dot(wo, wh) * wh) - wo; // Compute incident direction by reflecting about $\wh$

  float blinn_pdf = ((exponent + 1.0f) * pow(costheta, exponent)) / (2.f * M_PI * 4.f * dot(wo, wh));
  float D         = ((exponent + 2.0f) * INV_TWOPI * pow(costheta, exponent));

  if (dot(wo, wh) <= 0.f)
  {
    blinn_pdf = 1.0f; // ����� ����������� pdf-� ��� materialMix, �� ��� ����� ������ pdf ������ ���� ����� ���� !!!
    D         = 0.0f;
  }

  MatSample res;
  res.direction    = wi.x*nx + wi.y*ny + wi.z*nz; // back to normal coordinate system
  res.pdf          = blinn_pdf;
  res.color        = color * D * TorranceSparrowGF1(wo, wi);
  res.pureSpecular = false;
  return res;

}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define MMIX_NUMC_OFFSET    10
#define MMIX_DUMMY_OFFSET   11

#define MMIX_START          12
#define MMIX_MAX_COMPONENTS ((MIX_MATERIAL_DATA_SIZE - MMIX_START)/2)

typedef struct BRDFSelectorT
{
  int   localOffs;
  float w;

} BRDFSelector;


ID_CALL BRDFSelector mixSelectBRDF(__global PlainMaterial* a_pMat, float a_r3)
{
  int numComponents = as_int(a_pMat->data[MMIX_NUMC_OFFSET]);
  int selectedComponent = 0;

  for (int i = 0; i < numComponents; i++)
  {
    if (a_pMat->intervals[2 * i + 0] <= a_r3 && a_r3 < a_pMat->intervals[2 * i + 1])
      selectedComponent = i;
  }

  BRDFSelector res;
  res.localOffs = as_int(a_pMat->data[MMIX_START + 2 * selectedComponent + 0]);
  res.w         = fmax  (a_pMat->data[MMIX_START + 2 * selectedComponent + 1], 0.001f);
  return res;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#define BLEND_MASK_COLORX_OFFSET       10
#define BLEND_MASK_COLORY_OFFSET       11
#define BLEND_MASK_COLORZ_OFFSET       12

#define BLEND_MASK_TEXID_OFFSET        13
#define BLEND_MASK_TEXMATRIXID_OFFSET  14
//#define BLEND_MASK_IS_CBLEND_OFFSET    15 // if we blend via using not only luminance of mask 

#define BLEND_MASK_MATERIAL1_OFFSET    16 // alpha = luminance(BLEND_MASK_COLOR);
#define BLEND_MASK_MATERIAL2_OFFSET    17 // res = BLEND_MASK_MATERIAL1*alpha + BLEND_MASK_MATERIAL2_OFFSET*(1.0f-alpha)

IDH_CALL float mylocalluminance(float3 v) { return dot(make_float3(0.35f, 0.51f, 0.14f), v); }

ID_CALL float blendMaskAlpha(__global PlainMaterial* pMat, float2 hitTexCoord)
{
  return mylocalluminance(make_float3(pMat->data[BLEND_MASK_COLORX_OFFSET], pMat->data[BLEND_MASK_COLORY_OFFSET], pMat->data[BLEND_MASK_COLORZ_OFFSET])); // !!!!!!! <<<----- add texture fetch here !!!!
}

ID_CALL BRDFSelector blendSelectBRDF(__global PlainMaterial* pMat, float a_r3, float2 hitTexCoord)
{
  float alpha = blendMaskAlpha(pMat, hitTexCoord);
  
  BRDFSelector mat1, mat2;

  mat1.localOffs = as_int(pMat->data[BLEND_MASK_MATERIAL1_OFFSET]);
  mat1.w = fmax(alpha, 0.001f);

  mat2.localOffs = as_int(pMat->data[BLEND_MASK_MATERIAL2_OFFSET]);
  mat2.w = fmax(1.0f - alpha, 0.001f);

  if (a_r3 <= alpha)
    return mat1;
  else
    return mat2;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ID_CALL bool materialIsLeafBRDF(__global PlainMaterial* a_pMat)
{
  int type = materialGetType(a_pMat);
  return (type != PLAIN_MAT_CLASS_MIX) && (type != PLAIN_MAT_CLASS_BLEND_MASK);
}


ID_CALL BRDFSelector materialRandomWalkBRDF(__global PlainMaterial* a_pMat, float4 a_rands, float2 hitTexCoord)
{
  BRDFSelector res, sel;

  res.localOffs = 0;
  res.w = 1.0f;

  sel.localOffs = 0;
  sel.w = 1.0f;

  __global PlainMaterial* node = a_pMat;

  for (int i = 0; i < MIX_TREE_MAX_DEEP; i++)
  {
    float rndVal = a_rands.x;

    rndVal = (i == 1) ? a_rands.y : rndVal;
    rndVal = (i == 2) ? a_rands.z : rndVal;
    rndVal = (i == 3) ? a_rands.w : rndVal;

    //////////////////////////////////////////////////////////////////////////
    int type = materialGetType(node);

    if (type == PLAIN_MAT_CLASS_MIX)
      sel = mixSelectBRDF(node, rndVal);
    else if (type == PLAIN_MAT_CLASS_BLEND_MASK)
      sel = blendSelectBRDF(node, rndVal, hitTexCoord);
    //////////////////////////////////////////////////////////////////////////

    res.w         = res.w*sel.w;
    res.localOffs = sel.localOffs;

    node = node + sel.localOffs;

    if (materialIsLeafBRDF(node))
      break;
  }

  return res;
}


ID_CALL MatSample materialLeafSampleAndEvalBRDF(__global PlainMaterial* pMat, float4 rands, float3 ray_dir, float3 hitNorm, float2 hitTexCoord)
{
  switch (materialGetType(pMat))
  {
  case PLAIN_MAT_CLASS_PHONG_SPECULAR: return phongSampleAndEvalBRDF(pMat, rands.x, rands.y, ray_dir, hitNorm, hitTexCoord);
  case PLAIN_MAT_CLASS_BLINN_SPECULAR: return blinnSampleAndEvalBRDF(pMat, rands.x, rands.y, ray_dir, hitNorm, hitTexCoord);
  case PLAIN_MAT_CLASS_PERFECT_MIRROR: return mirrorSampleAndEvalBRDF(pMat, rands.x, rands.y, ray_dir, hitNorm, hitTexCoord);
  case PLAIN_MAT_CLASS_THIN_GLASS    : return thinglassSampleAndEvalBRDF(pMat, rands.x, rands.y, ray_dir, hitNorm, hitTexCoord);
  case PLAIN_MAT_CLASS_LAMBERT       : return lambertSampleAndEvalBRDF(pMat, rands.x, rands.y, hitNorm, hitTexCoord);
  default                            : return lambertSampleAndEvalBRDF(pMat, rands.x, rands.y, hitNorm, hitTexCoord);
  };

}


ID_CALL float3 materialLeafEvalBxDF(__global PlainMaterial* pMat, float3 l, float3 v, float3 n, float2 hitTexCoord)
{
  switch (materialGetType(pMat))
  {
  case PLAIN_MAT_CLASS_PHONG_SPECULAR: return phongEvalBxDF    (pMat, l,v,n);
  case PLAIN_MAT_CLASS_BLINN_SPECULAR: return blinnEvalBxDF    (pMat, l, v, n);
  case PLAIN_MAT_CLASS_PERFECT_MIRROR: return mirrorEvalBxDF   (pMat, l, v, n);
  case PLAIN_MAT_CLASS_THIN_GLASS:     return thinglassEvalBxDF(pMat, l, v, n);
  case PLAIN_MAT_CLASS_LAMBERT:        return lambertEvalBxDF  (pMat, l, n);
  default:                             return lambertEvalBxDF  (pMat, l, n);
  };

}


ID_CALL float materialLeafEvalPDF(__global PlainMaterial* pMat, float3 l, float3 v, float3 n, float2 hitTexCoord)
{
  switch (materialGetType(pMat))
  {
  case PLAIN_MAT_CLASS_PHONG_SPECULAR: return phongEvalPDF    (pMat, l, v, n);
  case PLAIN_MAT_CLASS_BLINN_SPECULAR: return blinnEvalPDF    (pMat, l, v, n);
  case PLAIN_MAT_CLASS_PERFECT_MIRROR: return mirrorEvalPDF   (pMat, l, v, n);
  case PLAIN_MAT_CLASS_THIN_GLASS:     return thinglassEvalPDF(pMat, l, v, n);
  case PLAIN_MAT_CLASS_LAMBERT:        return lambertEvalPDF    (pMat, l, n);
  default:                             return lambertEvalPDF    (pMat, l, n);
  };

}




ID_CALL float3 materialEvalBxDF(__global PlainMaterial* pMat, float3 l, float3 v, float3 n, float2 hitTexCoord, bool disableCaustics)
{
  float3 val = make_float3(0.0f, 0.0f, 0.0f);

  if (materialGetType(pMat) == PLAIN_MAT_CLASS_MIX)
  {
    int numComponents = as_int(pMat->data[MMIX_NUMC_OFFSET]);

    for (int i = 0; i < numComponents; i++)
    {
      BRDFSelector res;

      res.localOffs = as_int(pMat->data[MMIX_START + 2 * i + 0]);
      res.w         =        pMat->data[MMIX_START + 2 * i + 1];

      __global PlainMaterial* pComponent = pMat + res.localOffs;

      if (!(disableCaustics && materialCastCaustics(pComponent)))
        val += materialLeafEvalBxDF(pComponent, l, v, n, hitTexCoord);
    }

  }
  else if (materialGetType(pMat) == PLAIN_MAT_CLASS_BLEND_MASK)
  {
    BRDFSelector mat1, mat2;

    float alpha    = blendMaskAlpha(pMat, hitTexCoord);

    mat1.localOffs = as_int(pMat->data[BLEND_MASK_MATERIAL1_OFFSET]);
    mat1.w         = alpha;

    mat2.localOffs = as_int(pMat->data[BLEND_MASK_MATERIAL2_OFFSET]);
    mat2.w         = (1.0f - alpha);

    __global PlainMaterial* pComponent1 = pMat + mat1.localOffs;
    __global PlainMaterial* pComponent2 = pMat + mat2.localOffs;

    if (!(disableCaustics && materialCastCaustics(pComponent1)))
      val += mat1.w*materialLeafEvalBxDF(pComponent1, l, v, n, hitTexCoord);

    if (!(disableCaustics && materialCastCaustics(pComponent2)))
      val += mat2.w*materialLeafEvalBxDF(pComponent2, l, v, n, hitTexCoord);
  }
  else
    val = materialLeafEvalBxDF(pMat, l, v, n, hitTexCoord);


  return val;
}


ID_CALL float materialEvalPDF(__global PlainMaterial* pMat, float3 l, float3 v, float3 n, float2 hitTexCoord, bool disableCaustics)
{
  float val = 0.0f;

  if (materialGetType(pMat) == PLAIN_MAT_CLASS_MIX)
  {
    int numComponents = as_int(pMat->data[MMIX_NUMC_OFFSET]);

    for (int i = 0; i < numComponents; i++)
    {
      BRDFSelector res;

      res.localOffs = as_int(pMat->data[MMIX_START + 2 * i + 0]);
      res.w         =        pMat->data[MMIX_START + 2 * i + 1];

      __global PlainMaterial* pComponent = pMat + res.localOffs;

      if (!(disableCaustics && materialCastCaustics(pComponent)))
        val += res.w*materialLeafEvalPDF(pComponent, l, v, n, hitTexCoord);
    }

  }
  else if (materialGetType(pMat) == PLAIN_MAT_CLASS_BLEND_MASK)
  {
    BRDFSelector mat1, mat2;

    float alpha = blendMaskAlpha(pMat, hitTexCoord);

    mat1.localOffs = as_int(pMat->data[BLEND_MASK_MATERIAL1_OFFSET]);
    mat1.w = alpha;

    mat2.localOffs = as_int(pMat->data[BLEND_MASK_MATERIAL2_OFFSET]);
    mat2.w = (1.0f - alpha);

    __global PlainMaterial* pComponent1 = pMat + mat1.localOffs;
    __global PlainMaterial* pComponent2 = pMat + mat2.localOffs;

    if (!(disableCaustics && materialCastCaustics(pComponent1)))
      val += mat1.w*materialLeafEvalPDF(pComponent1, l, v, n, hitTexCoord);

    if (!(disableCaustics && materialCastCaustics(pComponent2)))
      val += mat2.w*materialLeafEvalPDF(pComponent2, l, v, n, hitTexCoord);
  }
  else
    val = materialLeafEvalPDF(pMat, l, v, n, hitTexCoord);

  return val;

}



#endif
