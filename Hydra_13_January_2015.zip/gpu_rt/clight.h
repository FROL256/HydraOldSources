#ifndef RTCLIGHT
#define RTCLIGHT

#include "globals.h"


enum PLAIN_LIGHT_TYPES {
  PLAIN_LIGHT_TYPE_POINT_OMNI   = 0,
  PLAIN_LIGHT_TYPE_POINT_SPOT   = 1,
  PLAIN_LIGHT_TYPE_DIRECT       = 2,
  PLAIN_LIGHT_TYPE_SKY_DOME     = 3,
  PLAIN_LIGHT_TYPE_AREA         = 4,
  PLAIN_LIGHT_TYPE_SPHERE       = 5,
  PLAIN_LIGHT_TYPE_MESH         = 6,

};

enum PLAIN_LIGHT_FLAGS{
  DUMMY_FLAG = 1,
};


#define LIGHT_DATA_SIZE 32

struct PlainLightT
{
  float data[LIGHT_DATA_SIZE];
};

typedef struct PlainLightT PlainLight;


typedef struct ShadowSampleT
{

  float3 pos;
  float3 color;
  float  pdf;
  float  maxDist;
  bool   isPoint;

} ShadowSample;


#define PLIGHT_TYPE  0
#define PLIGHT_FLAGS 1

#define PLIGHT_POS_X 2
#define PLIGHT_POS_Y 3
#define PLIGHT_POS_Z 4

#define PLIGHT_NORM_X 5
#define PLIGHT_NORM_Y 6
#define PLIGHT_NORM_Z 7

#define PLIGHT_COLOR_X 8
#define PLIGHT_COLOR_Y 9
#define PLIGHT_COLOR_Z 10

#define PLIGHT_COLOR_TEX        11
#define PLIGHT_COLOR_TEX_MATRIX 12

#define PLIGHT_SURFACE_AREA     13


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define AREA_LIGHT_SIZE_X       14
#define AREA_LIGHT_SIZE_Y       15

#define AREA_LIGHT_MATRIX_E00   16
#define AREA_LIGHT_MATRIX_E01   17
#define AREA_LIGHT_MATRIX_E02   18
#define AREA_LIGHT_MATRIX_E10   19
#define AREA_LIGHT_MATRIX_E11   20
#define AREA_LIGHT_MATRIX_E12   21
#define AREA_LIGHT_MATRIX_E20   22
#define AREA_LIGHT_MATRIX_E21   23
#define AREA_LIGHT_MATRIX_E22   24

#define AREA_LIGHT_IS_DISK      25
#define AREA_LIGHT_SPOT_DISTR   26

#define AREA_LIGHT_SPOT_COS1    27
#define AREA_LIGHT_SPOT_COS2    28

#define AREA_LIGHT_SKY_PORTAL   29

ID_CALL float areaDiffuseLightEvalPDF(__global const PlainLight* pLight, float3 rayDir, float hitDist)
{

  float3 lightNorm = make_float3(pLight->data[PLIGHT_NORM_X], pLight->data[PLIGHT_NORM_Y], pLight->data[PLIGHT_NORM_Z]);
  float pdfA       = 1.0f / pLight->data[PLIGHT_SURFACE_AREA];
  float cosVal     = fmax(dot(rayDir, -1.0f*lightNorm), 0.0f);

  return PdfAtoW(pdfA, hitDist, cosVal);
}

ID_CALL float3 areaDiffuseLightGetIntensity(__global const PlainLight* pLight, float2 a_texCoord)
{
  return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}


IDH_CALL float mylocalclamp(float u, float a, float b) { float r = fmax(a, u); return fmin(r, b); }

IDH_CALL float mylocalsmoothstep(float edge0, float edge1, float x)
{
  float t = mylocalclamp((x - edge0) / (edge1 - edge0), 0.0f, 1.0f);
  return t * t * (3.0f - 2.0f * t);
}

ID_CALL float areaSpotLightAttenuation(__global const PlainLight* pLight, float3 in_shadowRayDir)
{
  float cos1 = pLight->data[AREA_LIGHT_SPOT_COS1];
  float cos2 = pLight->data[AREA_LIGHT_SPOT_COS2];
  float3 norm = make_float3(pLight->data[PLIGHT_NORM_X], pLight->data[PLIGHT_NORM_Y], pLight->data[PLIGHT_NORM_Z]);
  float cos_theta = fmax(dot(in_shadowRayDir, norm), 0.0f);
  return mylocalsmoothstep(cos2, cos1, cos_theta);
}


ID_CALL ShadowSample areaDiffuseLightSample(__global const PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  float offsetX = rands.x * 2.0f - 1.0f;
  float offsetY = rands.y * 2.0f - 1.0f;

  float3 samplePos;

  samplePos.x = offsetX*pLight->data[AREA_LIGHT_SIZE_X];
  samplePos.y = 0.0f;
  samplePos.z = offsetY*pLight->data[AREA_LIGHT_SIZE_Y];
  

  if (as_int(pLight->data[AREA_LIGHT_IS_DISK]) != 0)
  {
    float2 xz = MapSamplesToDisc(make_float2(offsetX, offsetY))*pLight->data[AREA_LIGHT_SIZE_X]; // disk radius
    samplePos.x = xz.x;
    samplePos.y = 0;
    samplePos.z = xz.y;
  }

  __global const float* pMatrix = pLight->data + AREA_LIGHT_MATRIX_E00;
  samplePos = matrix3x3f_mult_float3(pMatrix, samplePos);                                                                     // transform with rotation matrix

  samplePos = samplePos + make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);    // translate to world light position

  float3 rayDir = normalize(samplePos - illuminatingPoint);
  float hitDist = length(samplePos - illuminatingPoint);
 
  float3 color = areaDiffuseLightGetIntensity(pLight, make_float2(rands.x, rands.y));

  if (as_int(pLight->data[AREA_LIGHT_SPOT_DISTR]) != 0)
    color *= areaSpotLightAttenuation(pLight, (-1.0f)*rayDir);

  ShadowSample res;

  res.isPoint   = false;
  res.pos       = samplePos;
  res.color     = color;
  res.pdf       = areaDiffuseLightEvalPDF(pLight, rayDir, hitDist);
  res.maxDist   = hitDist;

  return res;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#define SPHERE_LIGHT_RADIUS 14


ID_CALL float sphereLightEvalPDF(__global const PlainLight* pLight, float3 illuminatingPoint)
{
  float  lradius = pLight->data[SPHERE_LIGHT_RADIUS];
  float3 lcenter = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);

  if (DistanceSquared(illuminatingPoint, lcenter) - lradius*lradius < 1.0e-4f)
    return 1.0f / pLight->data[PLIGHT_SURFACE_AREA];

  float sinThetaMax2 = lradius*lradius / DistanceSquared(illuminatingPoint, lcenter);
  float cosThetaMax = sqrt(fmax(0.0f, 1.0f - sinThetaMax2));

  return UniformConePdf(cosThetaMax);
}

ID_CALL float3 sphereLightGetIntensity(__global const PlainLight* pLight)
{
  return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}

ID_CALL ShadowSample sphereLightSample(__global const PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{

  float3 samplePos; 

  float3 lcenter = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);
  float  lradius = pLight->data[SPHERE_LIGHT_RADIUS];

  if (DistanceSquared(illuminatingPoint, lcenter) - lradius*lradius < 1.0e-4f)
    samplePos = lcenter;
  else
  {
    float3 wc, wcX, wcY;
    wc = normalize(lcenter - illuminatingPoint);
    CoordinateSystem(wc, &wcX, &wcY);

    float sinThetaMax2 = lradius*lradius / DistanceSquared(illuminatingPoint, lcenter);
    float cosThetaMax = sqrt(fmax(0.0f, 1.0f - sinThetaMax2));

    float3 rdir = UniformSampleCone(rands.x, rands.y, cosThetaMax, wcX, wcY, wc);
    float3 rpos = illuminatingPoint + rdir*(1.0e-3f);

    float2 hitMinMax = RaySphereIntersect(rpos, rdir, lcenter, lradius);

    float thit = 0.0f;
    if (hitMinMax.x < 0.0f)
      thit = dot(lcenter - illuminatingPoint, normalize(rdir));
    else
      thit = hitMinMax.x;

    samplePos = rpos + thit*rdir;
  }

  float hitDist = length(samplePos - illuminatingPoint);

  ShadowSample res;

  res.isPoint = false;
  res.pos     = samplePos;
  res.color   = sphereLightGetIntensity(pLight);
  res.pdf     = sphereLightEvalPDF(pLight, illuminatingPoint);
  res.maxDist = hitDist;

  return res;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


ID_CALL float pointLightEvalPDF(__global const PlainLight* pLight, float3 illuminatingPoint)
{
  float3 samplePos = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);
  float  hitDist   = length(samplePos - illuminatingPoint);
  return PdfAtoW(1.0f, hitDist, 1.0f);
}

ID_CALL float3 pointLightGetIntensity(__global const PlainLight* pLight)
{
  return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}

ID_CALL ShadowSample pointLightSample(__global const PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  float3 samplePos = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);

  float hitDist = length(samplePos - illuminatingPoint);

  ShadowSample res;

  res.isPoint = true;
  res.pos     = samplePos;
  res.color   = pointLightGetIntensity(pLight);
  res.pdf     = PdfAtoW(1.0f, hitDist, 1.0f);
  res.maxDist = hitDist*1.01f;

  return res;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define POINT_LIGHT_SPOT_COS1    14
#define POINT_LIGHT_SPOT_COS2    15

ID_CALL float pointSpotLightAttenuation(__global const PlainLight* pLight, float3 in_shadowRayDir)
{
  float  cos1 = pLight->data[POINT_LIGHT_SPOT_COS1];
  float  cos2 = pLight->data[POINT_LIGHT_SPOT_COS2];
  float3 norm = make_float3(pLight->data[PLIGHT_NORM_X], pLight->data[PLIGHT_NORM_Y], pLight->data[PLIGHT_NORM_Z]);
  float  cos_theta = fmax(dot(in_shadowRayDir, norm), 0.0f);
  return mylocalsmoothstep(cos2, cos1, cos_theta);
}

ID_CALL float spotLightEvalPDF(__global const PlainLight* pLight, float3 illuminatingPoint)
{
  float3 samplePos = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);
  float  hitDist = length(samplePos - illuminatingPoint);
  return PdfAtoW(1.0f, hitDist, 1.0f);
}

ID_CALL float3 spotLightGetIntensity(__global const PlainLight* pLight)
{
  return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}

ID_CALL ShadowSample spotLightSample(__global const PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  float3 samplePos = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);

  float hitDist = length(samplePos - illuminatingPoint);
  float3 rayDir = normalize(samplePos - illuminatingPoint);

  float3 color = spotLightGetIntensity(pLight)*pointSpotLightAttenuation(pLight, (-1.0f)*rayDir);

  ShadowSample res;

  res.isPoint = true;
  res.pos     = samplePos;
  res.color   = color;
  res.pdf     = PdfAtoW(1.0f, hitDist, 1.0f);
  res.maxDist = hitDist*1.01f;

  return res;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define DIRECT_LIGHT_RADIUS1 14
#define DIRECT_LIGHT_RADIUS2 15

ID_CALL float directLightEvalPDF(__global const PlainLight* pLight, float3 illuminatingPoint)
{
  return 1.0f;
}

ID_CALL float3 directLightGetIntensity(__global const PlainLight* pLight)
{
  return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}


ID_CALL float directLightAttenuation(__global const PlainLight* pLight, float3 illuminatingPoint)
{
  float  radius1 = pLight->data[DIRECT_LIGHT_RADIUS1];
  float  radius2 = pLight->data[DIRECT_LIGHT_RADIUS2];

  float3 lpos = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);
  float3 norm = make_float3(pLight->data[PLIGHT_NORM_X], pLight->data[PLIGHT_NORM_Y], pLight->data[PLIGHT_NORM_Z]);

  float cos_alpha = dot(normalize(illuminatingPoint - lpos), norm);

  if (cos_alpha > 0.0f)
  {
    float sin_alpha = sqrt(1.0f - cos_alpha*cos_alpha);
    float d = length(illuminatingPoint - lpos)*sin_alpha;
    float maxd = fmax(radius2, radius1);
    float mind = fmin(radius2, radius1);
    return mylocalsmoothstep(maxd, mind, d);
  }
  else
    return 0.0f;
}

ID_CALL ShadowSample directLightSample(__global const PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  float3 lpos = make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);
  float3 norm = make_float3(pLight->data[PLIGHT_NORM_X], pLight->data[PLIGHT_NORM_Y], pLight->data[PLIGHT_NORM_Z]);

  float3 AC    = illuminatingPoint - lpos;
  float  CBLen = dot(normalize(AC), norm)*length(AC);

  float3 samplePos = illuminatingPoint - norm*CBLen;
  float hitDist    = CBLen; // length(samplePos - illuminatingPoint);

  float3 color = directLightGetIntensity(pLight)*directLightAttenuation(pLight, illuminatingPoint);

  ShadowSample res;

  res.isPoint = true;
  res.pos     = samplePos;
  res.color   = color;
  res.pdf     = 1.0f;
  res.maxDist = hitDist*1.01f;

  return res;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ID_CALL ShadowSample lightSample(__global const PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  int lightType = as_int(pLight->data[PLIGHT_TYPE]);

  switch (lightType)
  {
  case PLAIN_LIGHT_TYPE_DIRECT:       return directLightSample(pLight, rands, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_POINT_SPOT:   return spotLightSample(pLight, rands, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_POINT_OMNI:   return pointLightSample(pLight, rands, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_SPHERE:       return sphereLightSample(pLight, rands, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_AREA:         
  default:                            
                                      return areaDiffuseLightSample(pLight, rands, illuminatingPoint);
  }
}


ID_CALL float lightEvalPDF(__global const PlainLight* pLight, float3 illuminatingPoint, float3 rayDir, float hitDist)
{
  int lightType = as_int(pLight->data[PLIGHT_TYPE]);

  switch (lightType)
  {
  case PLAIN_LIGHT_TYPE_DIRECT:       return directLightEvalPDF(pLight, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_POINT_SPOT:   return spotLightEvalPDF(pLight, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_POINT_OMNI:   return pointLightEvalPDF(pLight, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_SPHERE:       return sphereLightEvalPDF(pLight, illuminatingPoint);
  case PLAIN_LIGHT_TYPE_AREA:        
  default:                            
                                      return areaDiffuseLightEvalPDF(pLight, rayDir, hitDist);
  }

}

ID_CALL float3 lightGetIntensity(__global const PlainLight* pLight, float2 a_texCoord)
{
  int lightType = as_int(pLight->data[PLIGHT_TYPE]);

  if (lightType == PLAIN_LIGHT_TYPE_AREA)
    return areaDiffuseLightGetIntensity(pLight, a_texCoord);
  else
    return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}





#endif

