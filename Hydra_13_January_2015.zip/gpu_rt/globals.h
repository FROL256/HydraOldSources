#ifndef RTGLOBALS
#define RTGLOBALS

#define BLOCK_SIZE_X 16
#define BLOCK_SIZE_Y 16
#define WARP_SIZE 32

#define Z_ORDER_BLOCK_SIZE 16
#define CMP_RESULTS_BLOCK_SIZE 256


#define HRT_RAY_MISS 0xFFFFFFFE
#define HRT_RAY_HIT 0xFFFFFFFF

#define DELTA_RAY 1e-5f
#define MIS_PURE_SPECULAR_PDF 1e10f

#define HEMISPHERE_SEQUENCE_NUM 4
#define RC_CUBE_SIZE 4

#define GMAXVARS 32

#define INVALID_TEXTURE  0x80000000
#define HDR_TEXT_TYPE    0x40000000

#define TEX_TYPE_MASK    0xff000000
#define TEX_ID_MASK      0x007fffff

// they are related because data are storen in one int32 variable triAlphaTest
//
#define ALPHA_MATERIAL_MASK   0x00FFFFFF
#define ALPHA_LIGHTMESH_MASK  0xFF000000
#define ALPHA_LIGHTMESH_SHIFT 24

#define TEXMATRIX_ID_MASK     0x00FFFFFF // for texture slots - 'color_texMatrixId' and e.t.c
#define TEXSAMPLER_TYPE_MASK  0xFF000000 // for texture slots - 'color_texMatrixId' and e.t.c

#define INFINITY (1e38f)

#define M_PI          3.14159265358979323846f
#define INV_PI        0.31830988618379067154f
#define INV_TWOPI     0.15915494309189533577f
#define INV_FOURPI    0.07957747154594766788f

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef __CUDACC__ 

  #include "float4.cuh"              // CUDA

  #define ushort unsigned short
  #define uint   unsigned int

  #define __global
  #define __constant const
  #define __private

  #define __kernel __global__
 
  #define GLOBAL_ID_X blockDim.x * blockIdx.x + threadIdx.x
  #define GLOBAL_ID_Y blockDim.y * blockIdx.y + threadIdx.y

  #define LOCAL_ID_X threadIdx.x
  #define LOCAL_ID_Y threadIdx.y

  //#define SYNCTHREADS        __syncthreads()
  #define SYNCTHREADS_LOCAL  __syncthreads()
  #define SYNCTHREADS_GLOBAL __syncthreads()

  #define ID_CALL inline __device__

  typedef int image1d_t;
  typedef int image2d_t;

  #define __read_only const

  #define _PACKED
  
  #define __local __shared__

  ID_CALL int   as_int(float x) { return __float_as_int(x); }
  ID_CALL float as_float(int x) { return __int_as_float(x); }

  ID_CALL int atomic_inc(int* pData)   { return atomicAdd(pData, 1); }
  ID_CALL uint atomic_inc(uint* pData) { return atomicAdd(pData, 1); }

#else
  
  #ifdef OCL_COMPILER                // OpenCL
   
   #define __device__
   #define IDH_CALL inline
   #define ID_CALL  inline

   inline ushort2 make_ushort2(ushort x, ushort y) { ushort2 res; res.x = x; res.y = y; return res; }

   #define GLOBAL_ID_X get_global_id(0)
   #define GLOBAL_ID_Y get_global_id(1)

   #define LOCAL_ID_X  get_local_id(0)
   #define LOCAL_ID_Y  get_local_id(1)

   #define _PACKED __attribute__ ((packed))

   //#define SYNCTHREADS        barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE)
   #define SYNCTHREADS_LOCAL  barrier(CLK_LOCAL_MEM_FENCE)
   #define SYNCTHREADS_GLOBAL barrier(CLK_GLOBAL_MEM_FENCE)

   IDH_CALL float maxcomp(float3 v) { return fmax(v.x, fmax(v.y, v.z)); }

   #define NULL 0

  #else                              // Common C++
    
    #ifndef MGML_GPU_GUARDIAN
      #include "../CSL/MGML_GPU.h"
    #endif

    using RAYTR::float2;
    using RAYTR::float3;
    using RAYTR::float4;

    using RAYTR::uint2;
    using RAYTR::uint4;

    #define IDH_CALL static inline
    #define ID_CALL  static inline

    #define __global
    #define __constant const

    #define __private


    #define COMMON_CPLUS_PLUS_CODE 1

    ID_CALL int   __float_as_int(float x) { return *( (int*)&x ); }
    ID_CALL float __int_as_float(int x) { return *( (float*)&x ); }
   
    ID_CALL int   as_int(float x) { return __float_as_int(x); }
    ID_CALL float as_float(int x) { return __int_as_float(x); }

    #define _PACKED

#endif

#endif




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct MatSampleT
{
  float3 color;
  float3 direction;
  float  pdf;
  bool   pureSpecular;
} MatSample;


enum FLAG_BITS{HRT_COMPUTE_SHADOWS                 = 1,
               HRT_DISABLE_SHADING                 = 2, // need this flag for photon trace and bidirectional path tracing
               HRT_DIFFUSE_REFLECTION              = 4,
               HRT_USE_RANDOM_RAYS                 = 8,
               HRT_SAVE_SURFACE_DATA               = 16,
               HRT_FINAL_GARTHER                   = 32,
               HRT_COMPUTE_IRRADIANCE_CACHE        = 64,
               HRT_USE_MIS                         = 128,
               HRT_IRRDAIANCE_CACHE_FIND_SECONDARY = 256,
               HRT_DUMMY_THIS_FLAG_IS_FREE         = 512,
               HRT_DISABLE_BUMP                    = 1024,
               HRT_ENV_MAP_CUBEMAP_ACTIVE          = 2048,
               HRT_ENV_MAP_SPHEREMAP_ACTIVE        = 4096,
               HRT_STORE_RAY_SAMPLES               = 8192,
               HRT_DUMMY1                          = 16384,
               HRT_RC_HARMONICS                    = 32768,
               HRT_IC_ESTIMATE_SS_IRRAD            = 65536,
               HRT_DIFFUSE_PHOTON_TRACING          = 65536*2,
               HRT_CAUSTIC_PHOTON_TRACING          = 65536*4,
               HRT_STUPID_PT_MODE                  = 65536*8,
               HRT_NO_RANDOM_LIGHTS_SELECT         = 65536*16,
               HRT_MARK_SURFACES_FG                = 65536*32, // 
               HRT_LDIRECT_PHOTON_TRACING          = 65536*64, // tracing photons to form spetial photonmap to speed-up direct light sampling
               HRT_DEBUG_DRAW_LIGHT_PHOTONS        = 65536*128,
               HRT_PHOTONS_STORE_MULTIPLY_COLORS   = 65536*256,
               HRT_GARTHER_CAUSTICS                = 65536*512,
               HRT_TRANSFORM_IC_TO_PHMAP           = 65536*1024,
               HRT_ENABLE_PT_CAUSTICS              = 65536*2048,
               HRT_USE_BOTH_PHOTON_MAPS            = 65536 * 4096,
               HRT_ENABLE_QMC_ONE_SEED             = 65536*8192, // !!!!!!!! DONT MOVE THIS FLAG !!!! See random generator implementation
               HRT_ENABLE_COHERENT_PT              = 65536*16384,
              };

enum SURFACE_MARKERS {SURF_FRONT = 0x80000000, 
                      SURF_BACK  = 0x40000000}; // we can use other 30 bits for index or sms like that


enum VARIABLE_NAMES { // int vars
                      //
                      HRT_ENABLE_DOF               = 0,
                      HRT_DEBUG_DRAW_LAYER         = 1,
                      HRT_FIRST_BOUNCE_STORE_CACHE = 2,
                      HRT_ENABLE_MRAYS_COUNTERS    = 3,
                      HRT_DEBUG_OUTPUT             = 4,
                      HRT_MEASURE_RAYS_TYPE        = 5,
                      HRT_DEBUG_SH_ENVIRONMENT     = 6,
                      HRT_IC_HARMONIC_MEAN         = 7,
                      HRT_TEXCACHE_MAX_MEMORY      = 8,
                      HRT_TRACE_DEPTH              = 9,
                      HRT_PHOTONS_STORE_BOUNCE     = 10,
                      HRT_PHOTONS_GARTHER_BOUNCE   = 11,
                      HRT_RAYS_APPENDBUFFER_SIZE   = 12,
                      HRT_DIFFUSE_TRACE_DEPTH      = 13,
                      HRT_DISPLAY_IC_INTERMEDIATE  = 14,
                      HRT_PT_FILTER_TYPE           = 15,
                      HRT_RAY_REORDER_TYPE         = 16,
                      HRT_RAY_REORDER_PATTERN      = 17,
                      HRT_VAR_ENABLE_RR            = 18,
                      HRT_RENDER_LAYER             = 19,
                      HRT_RENDER_LAYER_DEPTH       = 20,
                      HRT_IC_ENABLED               = 21,
                      HRT_IMAP_ENABLED             = 22,
                      HRT_SPHEREMAP_TEXID0         = 23,
                      HRT_SPHEREMAP_TEXID1         = 24,
                      HRT_USE_GAMMA_FOR_ENV        = 25,
                      HRT_IC_BOUNCE                = 26,
                      HRT_SPHEREMAP_TEXMATRIXID0   = 27,
                      HRT_SPHEREMAP_TEXMATRIXID1   = 28,
                      HRT_ENABLE_PATH_REGENERATE   = 29,
};

enum VARIABLE_FLOAT_NAMES{ // float vars
                           //
                           HRT_DOF_LENS_RADIUS                     = 0,
                           HRT_DOF_FOCAL_PLANE_DIST                = 1,
                           HRT_IC_WS_ERROR_TRESHOLD                = 2,
                           HRT_TRACE_PROCEEDINGS_TRESHOLD          = 3, 
                           HRT_DUMMY_TEMP_IS_FREE                  = 4,
                           HRT_CAUSTIC_POWER_MULT                  = 5,
                           HRT_IMAGE_GAMMA                         = 6,
                           HRT_TEXINPUT_GAMMA                      = 7,
                           HRT_ENV_COLOR_X                         = 8,
                           HRT_ENV_COLOR_Y                         = 9,
                           HRT_ENV_COLOR_Z                         = 10,
                           HRT_ENV_COLOR2_X                        = 11,
                           HRT_ENV_COLOR2_Y                        = 12,
                           HRT_ENV_COLOR2_Z                        = 13,
                           HRT_CAM_FOV                             = 14,
                           HRT_PATH_TRACE_ERROR                    = 15,     
};


enum RENDER_LAYER {
  LAYER_COLOR = 0,
  LAYER_POSITIONS = 1,
  LAYER_NORMALS = 2,
  LAYER_TEXCOORD = 3,
  LAYER_TEXCOLOR_AND_MATERIAL = 4,   // material mask
  LAYER_INCOMING_PRIMARY = 5,   // incoming primary
  LAYER_INCOMING_RADIANCE = 6,   // incoming secondary
  LAYER_COLOR_PRIMARY_AND_REST = 7,   // primary + refractions and other bounces
  LAYER_COLOR_THE_REST = 8
}; // refractions, and other bounces

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

IDH_CALL uint ZIndex(ushort x, ushort y, __constant ushort* a_mortonTable256)
{
  return	(a_mortonTable256[y >> 8]   << 17) |
          (a_mortonTable256[x >> 8]   << 16) |
          (a_mortonTable256[y & 0xFF] << 1 ) |
          (a_mortonTable256[x & 0xFF]      );
}

IDH_CALL ushort ExtractXFromZIndex(uint zIndex)
{
  uint result = 0;
  for (int i = 0; i<16; i++)
    result |= ((1 << 2 * i) & zIndex) >> i;
  return (ushort)result;
}


IDH_CALL ushort ExtractYFromZIndex(uint zIndex)
{
  uint result = 0;
  for (int i = 0; i<16; i++)
    result |= ((1 << (2 * i + 1)) & zIndex) >> i;
  return (ushort)(result >> 1);
}

IDH_CALL int blocks(int elems, int threadsPerBlock)
{
  if (elems % threadsPerBlock == 0 && elems >= threadsPerBlock)
    return elems / threadsPerBlock;
  else
    return (elems / threadsPerBlock) + 1;
}

IDH_CALL uint Index2D(uint x, uint y, int pitch) { return y*pitch + x; }

IDH_CALL uint IndexZBlock2D(int x, int y, int pitch, __constant ushort* a_mortonTable) // window_size[0]
{
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint zIndex = ZIndex(zOrderX, zOrderY, a_mortonTable);

  uint wBlocks = pitch / Z_ORDER_BLOCK_SIZE;
  uint blockX = x / Z_ORDER_BLOCK_SIZE;
  uint blockY = y / Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
}


//#ifndef OCL_COMPILER

IDH_CALL float3 to_float3(float4 f4)
{
  float3 res;
  res.x = f4.x;
  res.y = f4.y;
  res.z = f4.z;
  return res;
}

IDH_CALL float4 to_float4(float3 v, float w) 
{
  float4 res;
  res.x = v.x;
  res.y = v.y;
  res.z = v.z;
  res.w = w;
  return res;
}

//#endif



#ifndef __CUDACC__

IDH_CALL float2 make_float2(float a, float b)
{
  float2 res;
  res.x = a;
  res.y = b;
  return res;
}

IDH_CALL float3 make_float3(float a, float b, float c) 
{ 
  float3 res;
  res.x = a;
  res.y = b;
  res.z = c;
  return res;
}

IDH_CALL float4 make_float4(float a, float b, float c, float d) 
{ 
  float4 res;
  res.x = a;
  res.y = b;
  res.z = c;
  res.w = d;
  return res;
}

#endif

IDH_CALL float3 reflect(float3 dir, float3 normal) { return normalize((normal * dot(dir, normal) * (-2.0f)) + dir); }


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///// a simple tone mapping
IDH_CALL float3 ToneMapping(float3 color)  { return make_float3(fmin(color.x, 1.0f), fmin(color.y, 1.0f), fmin(color.z, 1.0f)); }
IDH_CALL float4 ToneMapping4(float4 color) { return make_float4(fmin(color.x, 1.0f), fmin(color.y, 1.0f), fmin(color.z, 1.0f), fmin(color.w, 1.0f)); }

/////////////////////////////////////////////////////////////////////////////////////////////////////////
////
IDH_CALL uint RealColorToUint32_f3(float3 real_color)
{
  float  r = real_color.x*255.0f;
  float  g = real_color.y*255.0f;
  float  b = real_color.z*255.0f;
  unsigned char red = (unsigned char)r, green = (unsigned char)g, blue = (unsigned char)b;
  return red | (green << 8) | (blue << 16) | 0xFF000000;
}


IDH_CALL uint RealColorToUint32(float4 real_color)
{
  float  r = real_color.x*255.0f;
  float  g = real_color.y*255.0f;
  float  b = real_color.z*255.0f;
  float  a = real_color.w*255.0f;

  unsigned char red   = (unsigned char)r;
  unsigned char green = (unsigned char)g;
  unsigned char blue  = (unsigned char)b;
  unsigned char alpha = (unsigned char)a;

  return red | (green << 8) | (blue << 16) | (alpha << 24);
}

IDH_CALL float3 SafeInverse(float3 d)
{
  float ooeps = exp2(-80.0f); // Avoid div by zero.

  float3 res;
  res.x = 1.0f / (fabs(d.x) > ooeps ? d.x : copysign(ooeps, d.x));
  res.y = 1.0f / (fabs(d.x) > ooeps ? d.y : copysign(ooeps, d.y));
  res.z = 1.0f / (fabs(d.x) > ooeps ? d.z : copysign(ooeps, d.z));
  return res;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct float4x3
{
  float4 row[3];
};

struct float4x4
{
  float4 row[4];
};

struct float3x3
{
  float3 row[3];
};



IDH_CALL float3 mul4x3x3(struct float4x3 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
  return res;
}

IDH_CALL float4 mul4x4x4(struct float4x4 m, float4 v)
{
  float4 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w*v.w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w*v.w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w*v.w;
  res.w = m.row[3].x*v.x + m.row[3].y*v.y + m.row[3].z*v.z + m.row[3].w*v.w;
  return res;
}

IDH_CALL float3 mul(struct float4x4 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
  return res;
}

IDH_CALL float3 mul3x4(struct float4x3 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
  return res;
}

IDH_CALL float3 mul3x3(struct float4x3 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
  return res;
}

IDH_CALL struct float3x3 make_float3x3(float3 a, float3 b, float3 c)
{
  struct float3x3 m;
  m.row[0] = a;
  m.row[1] = b;
  m.row[2] = c;
  return m;
}

IDH_CALL struct float3x3 make_float3x3_by_columns(float3 a, float3 b, float3 c)
{
  struct float3x3 m;
  m.row[0].x = a.x;
  m.row[1].x = a.y;
  m.row[2].x = a.z;

  m.row[0].y = b.x;
  m.row[1].y = b.y;
  m.row[2].y = b.z;

  m.row[0].z = c.x;
  m.row[1].z = c.y;
  m.row[2].z = c.z;
  return m;
}

IDH_CALL float3 mul3x3x3(struct float3x3 m, const float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
  return res;
}

IDH_CALL struct float3x3 mul3x3x3x3(struct float3x3 m1, struct float3x3 m2)
{
  float3 column1 = mul3x3x3(m1, make_float3(m2.row[0].x, m2.row[1].x, m2.row[2].x));
  float3 column2 = mul3x3x3(m1, make_float3(m2.row[0].y, m2.row[1].y, m2.row[2].y));
  float3 column3 = mul3x3x3(m1, make_float3(m2.row[0].z, m2.row[1].z, m2.row[2].z));

  return make_float3x3_by_columns(column1, column2, column3);
}

IDH_CALL struct float3x3 inverse(struct float3x3 a)
{
  float det = a.row[0].x * (a.row[1].y * a.row[2].z - a.row[1].z * a.row[2].y) -
              a.row[0].y * (a.row[1].x * a.row[2].z - a.row[1].z * a.row[2].x) +
              a.row[0].z * (a.row[1].x * a.row[2].y - a.row[1].y * a.row[2].x);

  struct float3x3 b;
  b.row[0].x = (a.row[1].y * a.row[2].z - a.row[1].z * a.row[2].y);
  b.row[0].y = -(a.row[0].y * a.row[2].z - a.row[0].z * a.row[2].y);
  b.row[0].z = (a.row[0].y * a.row[1].z - a.row[0].z * a.row[1].y);
  b.row[1].x = -(a.row[1].x * a.row[2].z - a.row[1].z * a.row[2].x);
  b.row[1].y = (a.row[0].x * a.row[2].z - a.row[0].z * a.row[2].x);
  b.row[1].z = -(a.row[0].x * a.row[1].z - a.row[0].z * a.row[1].x);
  b.row[2].x = (a.row[1].x * a.row[2].y - a.row[1].y * a.row[2].x);
  b.row[2].y = -(a.row[0].x * a.row[2].y - a.row[0].y * a.row[2].x);
  b.row[2].z = (a.row[0].x * a.row[1].y - a.row[0].y * a.row[1].x);

  float s = 1.0f / det;
  b.row[0] *= s;
  b.row[1] *= s;
  b.row[2] *= s;

  return b;
}


IDH_CALL struct float4x4 inverse4x4(struct float4x4 m1)
{
  float tmp[12]; // temp array for pairs
  struct float4x4 m;

  // calculate pairs for first 8 elements (cofactors)
  //
  tmp[0] = m1.row[2].z * m1.row[3].w;
  tmp[1] = m1.row[2].w * m1.row[3].z;
  tmp[2] = m1.row[2].y * m1.row[3].w;
  tmp[3] = m1.row[2].w * m1.row[3].y;
  tmp[4] = m1.row[2].y * m1.row[3].z;
  tmp[5] = m1.row[2].z * m1.row[3].y;
  tmp[6] = m1.row[2].x * m1.row[3].w;
  tmp[7] = m1.row[2].w * m1.row[3].x;
  tmp[8] = m1.row[2].x * m1.row[3].z;
  tmp[9] = m1.row[2].z * m1.row[3].x;
  tmp[10] = m1.row[2].x * m1.row[3].y;
  tmp[11] = m1.row[2].y * m1.row[3].x;

  // calculate first 8 m1.rowents (cofactors)
  //
  m.row[0].x = tmp[0] * m1.row[1].y + tmp[3] * m1.row[1].z + tmp[4] * m1.row[1].w;
  m.row[0].x -= tmp[1] * m1.row[1].y + tmp[2] * m1.row[1].z + tmp[5] * m1.row[1].w;
  m.row[1].x = tmp[1] * m1.row[1].x + tmp[6] * m1.row[1].z + tmp[9] * m1.row[1].w;
  m.row[1].x -= tmp[0] * m1.row[1].x + tmp[7] * m1.row[1].z + tmp[8] * m1.row[1].w;
  m.row[2].x = tmp[2] * m1.row[1].x + tmp[7] * m1.row[1].y + tmp[10] * m1.row[1].w;
  m.row[2].x -= tmp[3] * m1.row[1].x + tmp[6] * m1.row[1].y + tmp[11] * m1.row[1].w;
  m.row[3].x = tmp[5] * m1.row[1].x + tmp[8] * m1.row[1].y + tmp[11] * m1.row[1].z;
  m.row[3].x -= tmp[4] * m1.row[1].x + tmp[9] * m1.row[1].y + tmp[10] * m1.row[1].z;
  m.row[0].y = tmp[1] * m1.row[0].y + tmp[2] * m1.row[0].z + tmp[5] * m1.row[0].w;
  m.row[0].y -= tmp[0] * m1.row[0].y + tmp[3] * m1.row[0].z + tmp[4] * m1.row[0].w;
  m.row[1].y = tmp[0] * m1.row[0].x + tmp[7] * m1.row[0].z + tmp[8] * m1.row[0].w;
  m.row[1].y -= tmp[1] * m1.row[0].x + tmp[6] * m1.row[0].z + tmp[9] * m1.row[0].w;
  m.row[2].y = tmp[3] * m1.row[0].x + tmp[6] * m1.row[0].y + tmp[11] * m1.row[0].w;
  m.row[2].y -= tmp[2] * m1.row[0].x + tmp[7] * m1.row[0].y + tmp[10] * m1.row[0].w;
  m.row[3].y = tmp[4] * m1.row[0].x + tmp[9] * m1.row[0].y + tmp[10] * m1.row[0].z;
  m.row[3].y -= tmp[5] * m1.row[0].x + tmp[8] * m1.row[0].y + tmp[11] * m1.row[0].z;

  // calculate pairs for second 8 m1.rowents (cofactors)
  //
  tmp[0] = m1.row[0].z * m1.row[1].w;
  tmp[1] = m1.row[0].w * m1.row[1].z;
  tmp[2] = m1.row[0].y * m1.row[1].w;
  tmp[3] = m1.row[0].w * m1.row[1].y;
  tmp[4] = m1.row[0].y * m1.row[1].z;
  tmp[5] = m1.row[0].z * m1.row[1].y;
  tmp[6] = m1.row[0].x * m1.row[1].w;
  tmp[7] = m1.row[0].w * m1.row[1].x;
  tmp[8] = m1.row[0].x * m1.row[1].z;
  tmp[9] = m1.row[0].z * m1.row[1].x;
  tmp[10] = m1.row[0].x * m1.row[1].y;
  tmp[11] = m1.row[0].y * m1.row[1].x;

  // calculate second 8 m1 (cofactors)
  //
  m.row[0].z = tmp[0] * m1.row[3].y + tmp[3] * m1.row[3].z + tmp[4] * m1.row[3].w;
  m.row[0].z -= tmp[1] * m1.row[3].y + tmp[2] * m1.row[3].z + tmp[5] * m1.row[3].w;
  m.row[1].z = tmp[1] * m1.row[3].x + tmp[6] * m1.row[3].z + tmp[9] * m1.row[3].w;
  m.row[1].z -= tmp[0] * m1.row[3].x + tmp[7] * m1.row[3].z + tmp[8] * m1.row[3].w;
  m.row[2].z = tmp[2] * m1.row[3].x + tmp[7] * m1.row[3].y + tmp[10] * m1.row[3].w;
  m.row[2].z -= tmp[3] * m1.row[3].x + tmp[6] * m1.row[3].y + tmp[11] * m1.row[3].w;
  m.row[3].z = tmp[5] * m1.row[3].x + tmp[8] * m1.row[3].y + tmp[11] * m1.row[3].z;
  m.row[3].z -= tmp[4] * m1.row[3].x + tmp[9] * m1.row[3].y + tmp[10] * m1.row[3].z;
  m.row[0].w = tmp[2] * m1.row[2].z + tmp[5] * m1.row[2].w + tmp[1] * m1.row[2].y;
  m.row[0].w -= tmp[4] * m1.row[2].w + tmp[0] * m1.row[2].y + tmp[3] * m1.row[2].z;
  m.row[1].w = tmp[8] * m1.row[2].w + tmp[0] * m1.row[2].x + tmp[7] * m1.row[2].z;
  m.row[1].w -= tmp[6] * m1.row[2].z + tmp[9] * m1.row[2].w + tmp[1] * m1.row[2].x;
  m.row[2].w = tmp[6] * m1.row[2].y + tmp[11] * m1.row[2].w + tmp[3] * m1.row[2].x;
  m.row[2].w -= tmp[10] * m1.row[2].w + tmp[2] * m1.row[2].x + tmp[7] * m1.row[2].y;
  m.row[3].w = tmp[10] * m1.row[2].z + tmp[4] * m1.row[2].x + tmp[9] * m1.row[2].y;
  m.row[3].w -= tmp[8] * m1.row[2].y + tmp[11] * m1.row[2].z + tmp[5] * m1.row[2].x;

  // calculate matrix inverse
  //
  float k = 1.0f / (m1.row[0].x * m.row[0].x + m1.row[0].y * m.row[1].x + m1.row[0].z * m.row[2].x + m1.row[0].w * m.row[3].x);

  for (int i = 0; i<4; i++)
  {
    m.row[i].x *= k;
    m.row[i].y *= k;
    m.row[i].z *= k;
    m.row[i].w *= k;
  }

  return m;
}

// Look At matrix creation
// return the inverse view matrix
//

IDH_CALL struct float4x4 lookAt(float3 eye, float3 center, float3 up)
{
  float3 x, y, z; // basis; will make a rotation matrix

  z.x = eye.x - center.x;
  z.y = eye.y - center.y;
  z.z = eye.z - center.z;
  z = normalize(z);

  y.x = up.x;
  y.y = up.y;
  y.z = up.z;

  x = cross(y, z); // X vector = Y cross Z
  y = cross(z, x); // Recompute Y = Z cross X

  // cross product gives area of parallelogram, which is < 1.0 for
  // non-perpendicular unit-length vectors; so normalize x, y here
  x = normalize(x);
  y = normalize(y);

  struct float4x4 M;
  M.row[0].x = x.x; M.row[1].x = x.y; M.row[2].x = x.z; M.row[3].x = -x.x * eye.x - x.y * eye.y - x.z*eye.z;
  M.row[0].y = y.x; M.row[1].y = y.y; M.row[2].y = y.z; M.row[3].y = -y.x * eye.x - y.y * eye.y - y.z*eye.z;
  M.row[0].z = z.x; M.row[1].z = z.y; M.row[2].z = z.z; M.row[3].z = -z.x * eye.x - z.y * eye.y - z.z*eye.z;
  M.row[0].w = 0.0; M.row[1].w = 0.0; M.row[2].w = 0.0; M.row[3].w = 1.0;
  return M;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

IDH_CALL float3 EyeRayDir(float x, float y, float w, float h, struct float4x4 a_mViewProjInv) // g_mViewProjInv
{
  float4 pos = make_float4( 2.0f * (x + 0.5f) / w - 1.0f, 
                           -2.0f * (y + 0.5f) / h + 1.0f, 
                            0.0f, 
                            1.0f );

  pos = mul4x4x4(a_mViewProjInv, pos);
  pos /= pos.w;

  pos.y *= (-1.0f);

  return normalize(to_float3(pos));
}


IDH_CALL void matrix4x4f_mult_ray3(struct float4x4 a_mWorldViewInv, __private float3* ray_pos, __private float3* ray_dir) // g_mWorldViewInv
{
  float3 pos  = mul(a_mWorldViewInv, (*ray_pos));
  float3 pos2 = mul(a_mWorldViewInv, ((*ray_pos) + 100.0f*(*ray_dir)));

  float3 diff = pos2 - pos;

  (*ray_pos)  = pos;
  (*ray_dir)  = normalize(diff);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
////
IDH_CALL float3 matrix3x3f_mult_float3(__global const float* M, float3 v)
{
  float3 res;
  res.x = M[0 * 3 + 0] * v.x + M[0 * 3 + 1] * v.y + M[0 * 3 + 2] * v.z;
  res.y = M[1 * 3 + 0] * v.x + M[1 * 3 + 1] * v.y + M[1 * 3 + 2] * v.z;
  res.z = M[2 * 3 + 0] * v.x + M[2 * 3 + 1] * v.y + M[2 * 3 + 2] * v.z;
  return res;
}


IDH_CALL float DistanceSquared(float3 a, float3 b)
{
  float3 diff = b - a;
  return dot(diff, diff);
}

IDH_CALL float UniformConePdf(float cosThetaMax) { return 1.0f / (2.0f * M_PI * (1.0f - cosThetaMax)); }

IDH_CALL float3 UniformSampleSphere(float u1, float u2)
{
  float z = 1.0f - 2.0f * u1;
  float r = sqrt(fmax(0.0, 1.0f - z*z));
  float phi = 2.0f * M_PI * u2;
  float x = r * cos(phi);
  float y = r * sin(phi);
  return make_float3(x, y, z);
}

IDH_CALL float lerp2(float t, float a, float b)
{
  return (1.0f - t) * a + t * b;
}

IDH_CALL float3 UniformSampleCone(float u1, float u2, float costhetamax, float3 x, float3 y, float3 z)
{
  float costheta = lerp2(u1, costhetamax, 1.0f);
  float sintheta = sqrt(1.0f - costheta*costheta);
  float phi = u2 * 2.0f * M_PI;
  return cos(phi) * sintheta * x + sin(phi) * sintheta * y + costheta * z;
}

IDH_CALL float2 RaySphereIntersect(float3 rayPos, float3 rayDir, float3 sphPos, float radius)
{
  float3 k = rayPos - sphPos;
  float  b = dot(k, rayDir);
  float  c = dot(k, k) - radius*radius;
  float  d = b * b - c;

  float2 res;

  if (d >= 0.0f)
  {
    float sqrtd = sqrt(d);
    float t1 = -b - sqrtd;
    float t2 = -b + sqrtd;

    res.x = fmin(t1, t2);
    res.y = fmax(t1, t2);
  }
  else
  {
    res.x = -1e28f;
    res.y = -1e28f;
  }

  return res;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ��������� ����� �����:
// ������ 16 ���� - ���� ���������� ObjectList
// ������� ���� ������������, ����� �����. ������ ����������� ��������� �� float4 (��� uint4)
//

struct ObjectListTriangle
{
  float4 v1;
  float4 v2;
  float4 v3;
};

struct ObjectListSphere
{
  float3 pos;
  float r;
};

enum HIT_PRIMITIVE_TYPES { HIT_TRIANGLE = 0, HIT_SPHERE = 1, HIT_BOX = 2, HIT_NONE = 3 };

struct ObjectList
{

#ifndef OCL_COMPILER
#ifndef __CUDACC__

  ObjectList() { m_triangleCount = m_offset = dummy1 = dummy2 = 0; }

  inline ObjectListTriangle* GetTriangles() const { return  (ObjectListTriangle*)(((char*)this) + sizeof(ObjectList)); }
  inline const ObjectListSphere* GetSpheres() const { return  (const ObjectListSphere*)((char*)this + sizeof(ObjectList) + m_triangleCount*sizeof(ObjectListTriangle)); }

#endif
#endif

  int m_offset;
  int m_triangleCount;
  int dummy1;
  int dummy2;
};

IDH_CALL int GetNumTriangles(struct ObjectList ol)  { return ol.m_triangleCount; }
IDH_CALL int GetOffset(struct ObjectList ol)        { return ol.m_offset; }
IDH_CALL int GetNumPrimitives(struct ObjectList ol) { return GetNumTriangles(ol); }


struct Lite_HitT
{
  float t;
  unsigned int  object_id; // we can use 2 bits of object_id to store object_type
};

typedef struct Lite_HitT Lite_Hit;


IDH_CALL unsigned int GetObjectId(Lite_Hit lh)    { return (lh.object_id & 0x3FFFFFFF); }
IDH_CALL unsigned int GetObjectType(Lite_Hit lh)  { return (lh.object_id & 0xC0000000) >> 30; }

IDH_CALL unsigned int MakeObjectId(unsigned int a_id, unsigned int a_objType)   { return (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000); }

IDH_CALL Lite_Hit Make_Lite_Hit(float t, unsigned int a_id, unsigned int a_objType)
{
  Lite_Hit hit;
  hit.t = t;
  hit.object_id = (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000);
  return hit;
}


IDH_CALL int IS_LEAF(int a_leftOffsetAndLeaf) { return a_leftOffsetAndLeaf & 0x80000000; }
IDH_CALL int EXTRACT_OFFSET(int a_leftOffsetAndLeaf) { return a_leftOffsetAndLeaf & 0x7fffffff; }
IDH_CALL int PACK_LEAF_AND_OFFSET(int a_leftOffset, int leaf) { return (a_leftOffset & 0x7fffffff) | (leaf & 0x80000000); }


// a know about bit fields, but in CUDA they didn't work
//
struct BVHNodeT
{

#ifndef __CUDACC__
#ifndef OCL_COMPILER

  BVHNodeT() { m_leftOffsetAndLeaf = 0xffffffff; }

  inline void SetLeaf(unsigned int a_Leaf) { m_leftOffsetAndLeaf = (m_leftOffsetAndLeaf & 0x7fffffff) | ((a_Leaf) << 31); }
  inline unsigned int Leaf() const  { return (m_leftOffsetAndLeaf & 0x80000000) >> 31; }
  inline void SetLeftOffset(unsigned int in_offset) { m_leftOffsetAndLeaf = (m_leftOffsetAndLeaf & 0x80000000) | (in_offset & 0x7fffffff); }

  inline void SetObjectListOffset(unsigned int in_offset)
  {
    if (Leaf())
      SetLeftOffset(in_offset);
  }

  inline unsigned int GetLeftOffset()       const { return m_leftOffsetAndLeaf & 0x7fffffff; }
  inline unsigned int GetRightOffset()      const { return GetLeftOffset() + 1; }
  inline unsigned int GetObjectListOffset() const { return GetLeftOffset(); }

#endif
#endif

  float3 m_boxMin;
  unsigned int m_leftOffsetAndLeaf;

  float3 m_boxMax;
  unsigned int m_escapeIndex;

};

typedef struct BVHNodeT BVHNode;


struct _PACKED RayFlagsT
{
  unsigned char  diffuseBounceNum;
  unsigned char  bounceNum;
  unsigned short otherFlags;
};

typedef struct RayFlagsT RayFlags;

enum {
  RAY_GRAMMAR_SPECULAR             = 1,
  RAY_GRAMMAR_DIFFUSE_REFLECTION   = 2,
  RAY_GRAMMAR_REFLECTION           = 4,
  RAY_GRAMMAR_REFRACTION           = 8,
  RAY_GRAMMAR_CAUSTIC              = 16,
  RAY_GRAMMAR_OUT_OF_SCENE         = 32,
  RAY_GRAMMAR_PHOTON_STORED        = 64,
  RAY_IS_INSIDE_TRANSPARENT_OBJECT = 128,
  RAY_NOT_ALL_BOUNCES_ARE_MIRROR   = 256,
  RAY_GRAMMAR_MAY_CAUSE_CAUSTIC    = 512,
  RAY_GRAMMAR_FORCE_CAUSTIC_PHOTON = 1024,
  RAY_HIT_SURFACE_FROM_OTHER_SIDE  = 2048,
  RAY_IS_DEAD                      = 4096,  // set when ray had account environment or dien on the surface
  RAY_REGENERATE_IMMEDIATELY       = 8192,  // set when ray must be regenerated in next kernel call when path regeneration is enabled
  RAY_DEAD_BLOCK                   = 16384, // set when ray must be regenerated in next kernel call when path regeneration is enabled
};

IDH_CALL uint unpackRayFlags(uint a_flags)                       { return ((a_flags & 0xFFFF0000) >> 16); } 
IDH_CALL uint packRayFlags(uint a_oldData, uint a_flags)         { return (a_oldData & 0x0000FFFF) | (a_flags << 16); } 

IDH_CALL uint unpackBounceNum(uint a_flags)     { return ((a_flags & 0x0000FF00) >> 8); }          
IDH_CALL uint unpackBounceNumDiff(uint a_flags) { return (a_flags & 0x000000FF); }                 

IDH_CALL uint packBounceNum    (uint a_oldData, uint a_bounceNum)  { return (a_oldData & 0xFFFF00FF) | (a_bounceNum << 8); } 
IDH_CALL uint packBounceNumDiff(uint a_oldData, uint a_bounceNum)  { return (a_oldData & 0xFFFFFF00) | (a_bounceNum); } 

IDH_CALL bool rayIsActiveS(RayFlags a_flags) { return (a_flags.otherFlags & (RAY_GRAMMAR_OUT_OF_SCENE | RAY_IS_DEAD)) == 0; }
IDH_CALL bool rayIsActiveU(uint     a_flags) { return ( ((a_flags & 0xFFFF0000) >> 16) & (RAY_GRAMMAR_OUT_OF_SCENE | RAY_IS_DEAD)) == 0; }

typedef struct MisDataT
{
  float matSamplePdf;
  float lightPickProb;
  int   prevMaterialOffset;
  int   isSpecular;

} MisData;



IDH_CALL uint encodeNormal(float3 n)
{
  short x = (short)(n.x*32767.0f);
  short y = (short)(n.y*32767.0f);

  ushort sign = (n.z >= 0) ? 0 : 1;

  int sx = ((int)(x & 0xfffe) | sign);
  int sy = ((int)(y & 0xfffe) << 16);

  return (sx | sy);
}

IDH_CALL float3 decodeNormal(uint a_data)
{
  const float divInv = 1.0f / 32767.0f;

  short a_enc_x, a_enc_y;

  a_enc_x = (short)(a_data & 0x0000FFFF);
  a_enc_y = (short)((int)(a_data & 0xFFFF0000) >> 16);

  float sign = (a_enc_x & 0x0001) ? -1.0f : 1.0f;

  float x = (short)(a_enc_x & 0xfffe)*divInv;
  float y = (short)(a_enc_y & 0xfffe)*divInv;
  float z = sign*sqrt(fmax(1.0f - x*x - y*y, 0.0f));

  return make_float3(x, y, z);
}

struct _PACKED HitPosNormT
{
  float  pos_x;
  float  pos_y;
  float  pos_z;
  uint   norm_xy;

#ifdef __CUDACC__

  __device__ float3 GetNormal() const { return decodeNormal(norm_xy); }
  __device__ void SetNormal(float3 a_norm) { norm_xy = encodeNormal(normalize(a_norm)); }

#endif

};

typedef struct HitPosNormT HitPosNorm;

ID_CALL HitPosNorm make_HitPosNorm(float4 a_data)
{
  HitPosNorm res;
  res.pos_x   = a_data.x;
  res.pos_y   = a_data.y;
  res.pos_z   = a_data.z;
  res.norm_xy = (uint)(as_int(a_data.w));
  return res;
}

IDH_CALL float3 GetPos(HitPosNorm a_data) { return make_float3(a_data.pos_x, a_data.pos_y, a_data.pos_z); }
IDH_CALL void   SetPos(__private HitPosNorm* a_pData, float3 a_pos) { a_pData->pos_x = a_pos.x; a_pData->pos_y = a_pos.y; a_pData->pos_z = a_pos.z; }

struct _PACKED HitTexCoordT
{
  float  tex_u;
  float  tex_v;
};

typedef struct HitTexCoordT HitTexCoord;


struct _PACKED HitMatRefT
{
  int m_data;
};

typedef struct HitMatRefT HitMatRef;

IDH_CALL int GetHitType(HitMatRef a_hitMat)    { return (a_hitMat.m_data & 0xF0000000) >> 28; }
IDH_CALL int GetMaterialId(HitMatRef a_hitMat) { return a_hitMat.m_data & 0x0FFFFFFF; }

IDH_CALL void SetHitType(__private HitMatRef* a_pHitMat, int a_id)
{
  int mask = a_id << 28;
  int m_data2 = a_pHitMat->m_data & 0x0FFFFFFF;
  a_pHitMat->m_data = m_data2 | mask;
}


IDH_CALL void SetMaterialId(__private HitMatRef* a_pHitMat, int a_mat_id)
{
  int mask = a_mat_id & 0x0FFFFFFF;
  int m_data2 = a_pHitMat->m_data & 0xF0000000;
  a_pHitMat->m_data = m_data2 | mask;
}


struct _PACKED Hit_Part4T
{
  uint tangentCompressed;
  uint bitangentCompressed;
};

typedef struct Hit_Part4T Hit_Part4;









IDH_CALL void CoordinateSystem(float3 v1, __private float3* v2, __private float3* v3)
{
  float invLen = 1.0f;

  if (fabs(v1.x) > fabs(v1.y))
  {
    invLen = 1.0f / sqrt(v1.x*v1.x + v1.z*v1.z);
    (*v2) = make_float3(-v1.z * invLen, 0.0f, v1.x * invLen);
  }
  else
  {
    invLen = 1.0f / sqrt(v1.y*v1.y + v1.z*v1.z);
    (*v2) = make_float3(0.0f, v1.z * invLen, -v1.y * invLen);
  }

  (*v3) = cross(v1, (*v2));
}


IDH_CALL float3 MapSampleToCosineDistribution(float r1, float r2, float3 direction, float3 hit_norm, float power)
{
  if(power >= 1e6f)
    return direction;

  float sin_phi = sin(2.0f*r1*3.141592654f);
  float cos_phi = cos(2.0f*r1*3.141592654f);

  //sincos(2.0f*r1*3.141592654f, &sin_phi, &cos_phi);

  float cos_theta = pow(1.0f - r2, 1.0f / (power + 1.0f));
  float sin_theta = sqrt(1.0f - cos_theta*cos_theta);

  float3 deviation;
  deviation.x = sin_theta*cos_phi;
  deviation.y = sin_theta*sin_phi;
  deviation.z = cos_theta;

  float3 ny = direction, nx, nz;
  CoordinateSystem(ny, &nx, &nz);

  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  float3 res = nx*deviation.x + ny*deviation.y + nz*deviation.z;

  float invSign = dot(direction, hit_norm) > 0.0f ? 1.0f : -1.0f;

  if (invSign*dot(res, hit_norm) < 0.0f) // reflected ray is below surface #CHECK_THIS
  {
    res = (-1.0f)*nx*deviation.x + ny*deviation.y - nz*deviation.z;
    //belowSurface = true;
  }

  return res;
}


// Using the modified Phong reflectance model for physically based rendering
//
IDH_CALL float3 MapSampleToModifiedCosineDistribution(float r1, float r2, float3 direction, float3 hit_norm, float power)
{
  if (power >= 1e6f)
    return direction;

  // float sin_phi, cos_phi;
  // sincosf(2 * r1*3.141592654f, &sin_phi, &cos_phi);
  float sin_phi = sin(2.0f*r1*3.141592654f);
  float cos_phi = cos(2.0f*r1*3.141592654f);

  float sin_theta = sqrt(1.0f - pow(r2, 2.0f / (power + 1.0f)));

  float3 deviation;
  deviation.x = sin_theta*cos_phi;
  deviation.y = sin_theta*sin_phi;
  deviation.z = pow(r2, 1.0f / (power + 1.0f));

  float3 ny = direction, nx, nz;
  CoordinateSystem(ny, &nx, &nz);

  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  float3 res = nx*deviation.x + ny*deviation.y + nz*deviation.z;

  float invSign = dot(direction, hit_norm) > 0.0f ? 1.0f : -1.0f;

  if (invSign*dot(res, hit_norm) < 0.0f) // reflected ray is below surface #CHECK_THIS
  {
    res = (-1.0f)*nx*deviation.x + ny*deviation.y - nz*deviation.z;
    //belowSurface = true;
  }

  return res;
}

IDH_CALL float2 MapSamplesToDisc(float2 xy)
{
  float x = xy.x;
  float y = xy.y;

  float r = 0;
  float phi = 0;

  float2 res = xy;

  if (x>y && x>-y)
  {
    r = x;
    phi = 0.25f*3.141592654f*(y / x);
  }

  if (x < y && x > -y)
  {
    r = y;
    phi = 0.25f*3.141592654f*(2.0f - x / y);
  }

  if (x < y && x < -y)
  {
    r = -x;
    phi = 0.25f*3.141592654f*(4.0f + y / x);
  }

  if (x >y && x<-y)
  {
    r = -y;
    phi = 0.25f*3.141592654f*(6 - x / y);
  }

  //float sin_phi, cos_phi;
  //sincosf(phi, &sin_phi, &cos_phi);
  float sin_phi = sin(phi);
  float cos_phi = cos(phi);

  res.x = r*sin_phi;
  res.y = r*cos_phi;

  return res;
}


IDH_CALL float3 MapSamplesToCone(float cosCutoff, float2 sample, float3 direction)
{
  float cosTheta = (1 - sample.x) + sample.x * cosCutoff;
  float sinTheta = sqrt(1.0f - cosTheta * cosTheta);

  //float sinPhi, cosPhi;
  //sincosf(2.0f * M_PI * sample.y, &sinPhi, &cosPhi);
  float sinPhi = sin(2.0f * M_PI * sample.y);
  float cosPhi = cos(2.0f * M_PI * sample.y);

  float3 deviation = make_float3(cosPhi * sinTheta, sinPhi * sinTheta, cosTheta);

  // transform to different basis
  //
  float3 ny = direction;
  float3 nx = normalize(cross(ny, make_float3(1.04, 2.93f, -0.6234f)));
  float3 nz = normalize(cross(nx, ny));
  //swap(ny, nz);
  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  return nx*deviation.x + ny*deviation.y + nz*deviation.z;
}



struct ZBlockT
{

#ifndef OCL_COMPILER  
#ifndef __CUDACC__

  ZBlockT() { index = 0; diff = 100; counter = 0; }
  
  ZBlockT(int a_index, float a_diff)
  {
    index   = a_index;
    index2  = 0;
    diff    = a_diff;
    counter = 0;
  }

#endif

  inline __host__ __device__ static int GetSize() { return Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE; }
  inline __host__ __device__ int GetOffset() const { return index*GetSize(); }
  inline __host__ __device__ bool operator<(const ZBlockT& rhs) const { return (diff < rhs.diff); }
#endif

  int index;   // just block offset if global screen buffer
  int index2;  // index in other buffer + avg trace depth
  int counter; // how many times this block was traced?
  float diff;  // error in some units. stop criterion if fact
};

typedef struct ZBlockT ZBlock;

//IDH_CALL uint unpackAvgTraceDepth(uint a_flags)                       { return ((a_flags  & 0xFF000000) >> 24); }
//IDH_CALL uint packAvgTraceDepth(uint a_oldData, uint a_flags)         { return (a_oldData & 0x00FFFFFF) | (a_flags << 24); }

//IDH_CALL uint unpackIndex2(uint a_flags)                       { return (a_flags   & 0x00FFFFFF); }
//IDH_CALL uint packIndex2(uint a_oldData, uint a_flags)         { return (a_oldData & 0xFF000000) | a_flags; }


static bool BlockFinished(ZBlock block, int a_minRaysPerPixel, int a_maxRaysPerPixel, float* a_outDiff) // for use on the cpu side ... for current
{
  int samplesPerPixel = block.counter; // was *2 due to odd and even staff

  if(a_outDiff!=NULL)
    *a_outDiff = block.diff;

  float acceptedBadPixels = sqrt((float)(CMP_RESULTS_BLOCK_SIZE));
  int minRaysPerPixel     = a_minRaysPerPixel;

  bool summErrorOk = (block.diff <= acceptedBadPixels);
  bool maxErrorOk = false;

  return ((summErrorOk || maxErrorOk) && samplesPerPixel >= minRaysPerPixel) || (samplesPerPixel >= a_maxRaysPerPixel);
}

IDH_CALL uint ThreadSwizzle1D(uint pixelId, uint zBlockIndex)
{
  uint indexInsideZBlock = pixelId%CMP_RESULTS_BLOCK_SIZE;
  return zBlockIndex*CMP_RESULTS_BLOCK_SIZE + indexInsideZBlock;
}


IDH_CALL float PdfAtoW(const float aPdfA, const float aDist, const float aCosThere)
{
  return (aPdfA*aDist*aDist) / fmax(aCosThere, 1e-12f);
}

struct MRaysStat
{
  int   traceTimePerCent;
  float raysPerSec;
  float samplesPerSec;

  float reorderTimeMs;

  float traversalTimeMs;
  float shadowTimeMs;
  float bounceTimeMS;

  float sampleTimeMS;
};

IDH_CALL float probabilityAbsorbRR(uint a_flags)
{
  uint rayBounceNum  = unpackBounceNum(a_flags);
  uint diffBounceNum = unpackBounceNumDiff(a_flags);
  uint otherFlags    = unpackRayFlags(a_flags);

  float pabsorb = 0.0f;

  if (diffBounceNum >= 5)
    pabsorb = 0.50f;
  else if (diffBounceNum >= 3)
    pabsorb = 0.25f;

  return fmin(pabsorb, 0.65f);
}


IDH_CALL float MonteCarloStdErr(float3 avgColor, float3 sqrColor, int nSamples)
{
  float fnSamples = ((float)(nSamples));
  float nSampleInv = 1.0f / fnSamples;

  float3 colorSumm = avgColor*fnSamples;
  float3 sqrSumm   = sqrColor*fnSamples;

  float3 variance = (sqrSumm - (colorSumm*colorSumm)*nSampleInv) * (1.0f/(fnSamples - 1.0f));

  variance.x = fmax(variance.x, 0.0f);
  variance.y = fmax(variance.y, 0.0f);
  variance.z = fmax(variance.z, 0.0f);

  float3 stdError = make_float3(sqrt(variance.x*nSampleInv), sqrt(variance.y*nSampleInv), sqrt(variance.z*nSampleInv));

  // transform to relative error
  //
  float kLowestValue = 0.01f;

  stdError.x = stdError.x / (fmax(avgColor.x, kLowestValue));
  stdError.y = stdError.y / (fmax(avgColor.y, kLowestValue));
  stdError.z = stdError.z / (fmax(avgColor.z, kLowestValue));

  return fmax(fmax(stdError.x, stdError.y), stdError.z);
}



// CPU and CUDA only code 
//

#ifndef OCL_COMPILER 

IDH_CALL float clamp(float u, float a, float b) { float r = fmax(a, u); return fmin(r, b); }
IDH_CALL float3 clamp3(float3 x, float a, float b) { return make_float3(fmin(fmax(x.x, a), b), fmin(fmax(x.y, a), b), fmin(fmax(x.z, a), b)); }

static unsigned short MortonTable256Host[] =
{
  0x0000, 0x0001, 0x0004, 0x0005, 0x0010, 0x0011, 0x0014, 0x0015,
  0x0040, 0x0041, 0x0044, 0x0045, 0x0050, 0x0051, 0x0054, 0x0055,
  0x0100, 0x0101, 0x0104, 0x0105, 0x0110, 0x0111, 0x0114, 0x0115,
  0x0140, 0x0141, 0x0144, 0x0145, 0x0150, 0x0151, 0x0154, 0x0155,
  0x0400, 0x0401, 0x0404, 0x0405, 0x0410, 0x0411, 0x0414, 0x0415,
  0x0440, 0x0441, 0x0444, 0x0445, 0x0450, 0x0451, 0x0454, 0x0455,
  0x0500, 0x0501, 0x0504, 0x0505, 0x0510, 0x0511, 0x0514, 0x0515,
  0x0540, 0x0541, 0x0544, 0x0545, 0x0550, 0x0551, 0x0554, 0x0555,
  0x1000, 0x1001, 0x1004, 0x1005, 0x1010, 0x1011, 0x1014, 0x1015,
  0x1040, 0x1041, 0x1044, 0x1045, 0x1050, 0x1051, 0x1054, 0x1055,
  0x1100, 0x1101, 0x1104, 0x1105, 0x1110, 0x1111, 0x1114, 0x1115,
  0x1140, 0x1141, 0x1144, 0x1145, 0x1150, 0x1151, 0x1154, 0x1155,
  0x1400, 0x1401, 0x1404, 0x1405, 0x1410, 0x1411, 0x1414, 0x1415,
  0x1440, 0x1441, 0x1444, 0x1445, 0x1450, 0x1451, 0x1454, 0x1455,
  0x1500, 0x1501, 0x1504, 0x1505, 0x1510, 0x1511, 0x1514, 0x1515,
  0x1540, 0x1541, 0x1544, 0x1545, 0x1550, 0x1551, 0x1554, 0x1555,
  0x4000, 0x4001, 0x4004, 0x4005, 0x4010, 0x4011, 0x4014, 0x4015,
  0x4040, 0x4041, 0x4044, 0x4045, 0x4050, 0x4051, 0x4054, 0x4055,
  0x4100, 0x4101, 0x4104, 0x4105, 0x4110, 0x4111, 0x4114, 0x4115,
  0x4140, 0x4141, 0x4144, 0x4145, 0x4150, 0x4151, 0x4154, 0x4155,
  0x4400, 0x4401, 0x4404, 0x4405, 0x4410, 0x4411, 0x4414, 0x4415,
  0x4440, 0x4441, 0x4444, 0x4445, 0x4450, 0x4451, 0x4454, 0x4455,
  0x4500, 0x4501, 0x4504, 0x4505, 0x4510, 0x4511, 0x4514, 0x4515,
  0x4540, 0x4541, 0x4544, 0x4545, 0x4550, 0x4551, 0x4554, 0x4555,
  0x5000, 0x5001, 0x5004, 0x5005, 0x5010, 0x5011, 0x5014, 0x5015,
  0x5040, 0x5041, 0x5044, 0x5045, 0x5050, 0x5051, 0x5054, 0x5055,
  0x5100, 0x5101, 0x5104, 0x5105, 0x5110, 0x5111, 0x5114, 0x5115,
  0x5140, 0x5141, 0x5144, 0x5145, 0x5150, 0x5151, 0x5154, 0x5155,
  0x5400, 0x5401, 0x5404, 0x5405, 0x5410, 0x5411, 0x5414, 0x5415,
  0x5440, 0x5441, 0x5444, 0x5445, 0x5450, 0x5451, 0x5454, 0x5455,
  0x5500, 0x5501, 0x5504, 0x5505, 0x5510, 0x5511, 0x5514, 0x5515,
  0x5540, 0x5541, 0x5544, 0x5545, 0x5550, 0x5551, 0x5554, 0x5555
};

static inline uint ZIndexHost(ushort x, ushort y)
{
  return	MortonTable256Host[y >> 8] << 17  |
          MortonTable256Host[x >> 8] << 16  |
          MortonTable256Host[y & 0xFF] << 1 |
          MortonTable256Host[x & 0xFF];
}

static inline uint HostIndexZBlock2D(int x, int y, int pitch)
{
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint zIndex = ZIndexHost(zOrderX, zOrderY);

  uint wBlocks = pitch / Z_ORDER_BLOCK_SIZE;
  uint blockX = x / Z_ORDER_BLOCK_SIZE;
  uint blockY = y / Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
}


static void ImageZBlockMemToRowPitch(const float4* inData, float4* outData, int w, int h)
{
  #pragma omp parallel for
  for (int y = 0; y<h; y++)
  {
    for (int x = 0; x<w; x++)
    {
      int indexSrc = HostIndexZBlock2D(x, y, w);
      int indexDst = Index2D(x, y, w);
      outData[indexDst] = inData[indexSrc];
    }
  }


}



#endif



#ifdef __CUDACC__ 
  #undef ushort
  #undef uint
#endif



#endif

