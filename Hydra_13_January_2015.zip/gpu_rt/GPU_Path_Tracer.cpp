#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "IrradianceCache.h"

#include "RadianceGrid.h"

using MGML_MATH::EPSILON_E5;

void GPU_Path_Tracer::CheckBlockListF(GPU_Path_Tracer::BlockList* pList, const char* file, int line)
{
  GPU_Path_Tracer::BlockList::iterator p;
  int counter = 0;
  for(p=pList->begin(); p!= pList->end(); ++p)
  {
    if(p->index == 0)
      counter++;
  }

  if(counter > 1)
  {
    std::string c = ToString(counter);
    RunTimeError(file,line,"there are " + c + " blocks with index == 0");
  }

}

#define CHECK_LIST(plist) CheckBlockListF((plist),__FILE__,__LINE__)

/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::GPU_Path_Tracer(int w, int h, int flags, int a_devId) : Base(w, h, flags, a_devId)
{
  m_pathTracingState = STATE_BEGIN;
  SetRaysPerPixel(1);
  m_avgRaysPerPixel = 0;

  m_startScreenBlockListSize = 0;
  m_debugICacheFileOutput = false;
  m_voxelRadianceCacheEnabled = false;
  m_photonMapsPrepared = false;
  m_irradMapConstructed = false;
  
  CUDAHWLayer* pImpl = dynamic_cast<CUDAHWLayer*>(m_pHWLayer);

  if (pImpl != NULL)
  {
    for (int i = 0; i < HEMISPHERE_SEQUENCE_NUM; i++)
    {
      hlmInitHemisphereRaysTexture(0, i, &m_sphereUniformArray[i][0], m_sphereUniformArray[i].size());
      hlmInitHemisphereRaysTexture(1, i, &m_sphereUniformArray2[i][0], m_sphereUniformArray2[i].size());
      hlmInitSHCoefficient(&m_shCoeffsArray[0], m_shResPhi, m_shResTheta, m_sphLayersNum);
    }

    m_pRC = NULL;
    m_pPhotonMap            = hlmCreatePhotonMap(1000000, false, false);
    m_pCausticPhotonMap     = hlmCreatePhotonMap(1000000, true, false);
    m_pLightDirectPhotonMap = hlmCreatePhotonMap(1000000, false, true);
    m_pIrradianceMap        = hlmCreateIrradianceMap();
  }
  else
  {
    m_pRC                   = NULL;
    m_pPhotonMap            = NULL;
    m_pCausticPhotonMap     = NULL;
    m_pLightDirectPhotonMap = NULL;
    m_pIrradianceMap        = NULL;
  }

  size_t BLOCK_NUMBER = (w*h) / (ZBlock::GetSize());
  m_zBlocksCoordByIndex.resize(BLOCK_NUMBER);
  m_zblocksPosTmp.resize(BLOCK_NUMBER);

  if(!(flags & GPU_RT_NOWINDOW))
  {
    //m_display2DLines.InitFromString(RTE_GetShaderSource("simple_vs_2d"), RTE_GetShaderSource("color_ps"));
    m_display2DLines.InitFromString(RTE_GetShaderSource("dummy_vs_2d"), RTE_GetShaderSource("gs_quad_lines"), RTE_GetShaderSource("color_ps"));

    // resize OpenGL vertex buffer
    //
    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_blocksPos);                                CHECK_GL_ERRORS;                                    
    glBufferData(GL_ARRAY_BUFFER, BLOCK_NUMBER*sizeof(float2), NULL, GL_DYNAMIC_DRAW); CHECK_GL_ERRORS;

    // init vao for blocks
    //
    GLuint location = glGetAttribLocation(m_display2DLines.program, "vertex"); CHECK_GL_ERRORS;
    glBindVertexArray(m_glRes.m_vaoBlocks);                                    CHECK_GL_ERRORS;
    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_blocksPos);                        CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(location);                                       CHECK_GL_ERRORS;
    glVertexAttribPointer(location, 3, GL_FLOAT, GL_FALSE, 0, 0);              CHECK_GL_ERRORS;

    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);  

		CalcOrtoMatix(0, width, 0, height,-1,1, &m_ortoMat);
  }
}

void GPU_Path_Tracer::SetWindowResolution(int a_width, int a_height)
{
  GPU_Ray_Tracer::SetWindowResolution(a_width, a_height);
  
  if(!m_windowWasResized)
    return;

  SetRaysPerPixel(1);

  size_t BLOCK_NUMBER = (width*height) / (ZBlock::GetSize());
  m_zBlocksCoordByIndex.resize(BLOCK_NUMBER);
  m_zblocksPosTmp.resize(BLOCK_NUMBER);

  if (!(m_initFlags & GPU_RT_NOWINDOW))
  {
    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_blocksPos);                                CHECK_GL_ERRORS;
    glBufferData(GL_ARRAY_BUFFER, BLOCK_NUMBER*sizeof(float2), NULL, GL_DYNAMIC_DRAW); CHECK_GL_ERRORS;
    glBindBuffer(GL_ARRAY_BUFFER, 0);
  }
  CalcOrtoMatix(0, width, 0, height,-1,1, &m_ortoMat);

  size_t memFree = m_pHWLayer->GetAvaliableMemoryAmount();
  std::cout << "[gpurt]: video mem free = " << int(double(memFree)/(1024.0*1024.0)) << " MB" << std::endl;


  m_windowWasResized = false;
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::~GPU_Path_Tracer()
{
  hlmDeletePhotonMap(m_pCausticPhotonMap); m_pCausticPhotonMap = NULL;
  hlmDeletePhotonMap(m_pPhotonMap); m_pPhotonMap = NULL;
  hlmDeletePhotonMap(m_pLightDirectPhotonMap); m_pLightDirectPhotonMap = NULL;
  hlmDeleteIrradianceMap(m_pIrradianceMap); m_pIrradianceMap = NULL;
  delete m_pRC; m_pRC = NULL;

  BlockList::Free();
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::SetRenderingParams(const RenderingParams& a_params)
{
  m_params = a_params;
  int iEnableDOF = int(a_params.enableDOF);

  AllRenderVarialbes state = m_pHWLayer->GetAllFlagsAndVars();

  state.SetVariableF(HRT_PATH_TRACE_ERROR, a_params.qualityTreshold);
  state.SetVariableI(HRT_ENABLE_DOF, iEnableDOF);
  state.SetVariableF(HRT_DOF_LENS_RADIUS, a_params.dofLensRadius);
  state.SetVariableF(HRT_DOF_FOCAL_PLANE_DIST, a_params.dofFocalPlaneDist);

  m_pHWLayer->SetAllFlagsAndVars(state);

  m_rtOnlyVarDrawRaysStatInfo = m_params.drawRaysStatInfo;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::MakeScreenBlockList(BlockList* pList)
{ 
  pList->clear();
  m_screenFinished.clear();

  int BLOCK_NUMBER = (width*height) / (ZBlock::GetSize());
  
  BlockList::Free();
  BlockList::Allocate(2*BLOCK_NUMBER+10);

  for(int i=0;i<BLOCK_NUMBER;i++)
  {
    int x = (i*Z_ORDER_BLOCK_SIZE)%width; 
    int y = (i*ZBlock::GetSize() - x*Z_ORDER_BLOCK_SIZE)/width;
    m_zBlocksCoordByIndex[i] = float2(x,y); //  ��E�E ��� �������G�

    pList->push_front(ZBlock(i,10000));
  }

  m_avgRaysPerPixel = 0; // zero when start

  float acceptedBadPixels = sqrtf(float(CMP_RESULTS_BLOCK_SIZE));

  m_blockErrorMaxRed = acceptedBadPixels*2.0f;
  m_blockErrorMinGreen = acceptedBadPixels;

  // this variable need for the last pass of path tracing because i have some errors with
  // small size of kernel. so i need some hack. just reset this variable to 1 or 2
  m_lastPass = START_LAST_PASS;
  m_megaBlockPathTraceInProcess = false;
  forceEnd = false;
  m_avgError = 100.0f;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////

float GPU_Path_Tracer::EtimateTotalRenderingProgress() const
{
  int BLOCK_NUMBER = (width*height) / (ZBlock::GetSize());

  int remainBlocks = 0;
  int totalSPPDone = 0;

  for (auto p = m_screenBlockList.begin(); p != m_screenBlockList.end(); ++p)
  {
    totalSPPDone += p->counter;
    remainBlocks++;
  }

  //for (auto p = m_screenFinished.begin(); p != m_screenFinished.end(); ++p)
    //totalSPPDone += m_params.maxRaysPerPixel;

  totalSPPDone += (BLOCK_NUMBER - remainBlocks)*m_params.maxRaysPerPixel;

  float totalSppmf = float(BLOCK_NUMBER)*float(m_params.maxRaysPerPixel);

  return (float(totalSPPDone) / totalSppmf);
}

void GPU_Path_Tracer::ResetPathTracing(int a_seed) { m_pathTracingState = STATE_BEGIN; m_lastSeed = a_seed; }
bool GPU_Path_Tracer::PathTracingFinished() const  { return m_screenBlockList.empty();}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::BeginPathTracingPass(RenderSettings a_renderState)
{
  m_pHWLayer->ResetPerfCounters();

  m_lastRenderState = a_renderState;

  GPU_Ray_Tracer::UpdateComplete();

  switch (m_pathTracingState)
  {
  case STATE_BEGIN:
  {
    m_currPTPassNumber = 0;

    MakeScreenBlockList(&m_screenBlockList);
    SetRaysPerPixel(m_params.initialSPP);

    AllRenderVarialbes state = m_pHWLayer->GetAllFlagsAndVars();

    state.SetFlags(HRT_USE_RANDOM_RAYS, 1);
    state.SetFlags(HRT_COMPUTE_SHADOWS, a_renderState.GetShadow());
    state.SetFlags(HRT_DIFFUSE_REFLECTION, a_renderState.GetIndirrectIllumination());
    state.SetFlags(HRT_COMPUTE_IRRADIANCE_CACHE | HRT_IRRDAIANCE_CACHE_FIND_SECONDARY, 0);
    state.SetFlags(HRT_FINAL_GARTHER, a_renderState.GetEnableFG());
    state.SetFlags(HRT_GARTHER_CAUSTICS, a_renderState.GetEnableCG());

    if (a_renderState.GetEnableFG() && a_renderState.GetEnableCG())
      state.SetFlags(HRT_USE_BOTH_PHOTON_MAPS, 1);
    else
      state.SetFlags(HRT_USE_BOTH_PHOTON_MAPS, 0);

    state.SetFlags(HRT_ENABLE_PT_CAUSTICS, a_renderState.ptCaustics);
    state.SetFlags(HRT_ENABLE_COHERENT_PT, m_params.coherent);
    state.SetFlags(HRT_DISABLE_SHADING, 0);
    state.SetFlags(HRT_USE_MIS, m_params.useMIS);
    state.SetFlags(HRT_NO_RANDOM_LIGHTS_SELECT, m_params.noRandomLightSelect);

    state.SetVariableF(HRT_IC_WS_ERROR_TRESHOLD, m_icPresets.icWSErrorTreshold); //a_renderState.icWSErrorTreshold
    state.SetVariableF(HRT_TRACE_PROCEEDINGS_TRESHOLD, a_renderState.GetTraceProceedingsTreshold());
    state.SetVariableF(HRT_CAUSTIC_POWER_MULT, a_renderState.causticPower);
    state.SetVariableF(HRT_CAM_FOV, m_projParams.x);

    state.SetVariableI(HRT_ENABLE_MRAYS_COUNTERS, int(a_renderState.GetEnableRaysCounter()));
    state.SetVariableI(HRT_TRACE_DEPTH, a_renderState.GetTraceDepth());
    state.SetVariableI(HRT_PHOTONS_GARTHER_BOUNCE, a_renderState.GetGartherBounce());
    state.SetVariableI(HRT_PHOTONS_STORE_BOUNCE, a_renderState.GetStoreBounce());
    state.SetVariableI(HRT_DIFFUSE_TRACE_DEPTH, a_renderState.GetDiffuseTraceDepth());
    state.SetVariableI(HRT_IC_BOUNCE, a_renderState.icBounce);

    if (a_renderState.GetEnableFG() || m_irradMapConstructed)
      state.SetVariableI(HRT_DIFFUSE_TRACE_DEPTH, a_renderState.GetGartherBounce());

    state.SetVariableI(HRT_DEBUG_OUTPUT, m_debugOutput);

    state.SetVariableF(HRT_IMAGE_GAMMA, a_renderState.GetGamma());
    state.SetVariableF(HRT_TEXINPUT_GAMMA, a_renderState.GetGammaTex());

    state.SetVariableI(HRT_PT_FILTER_TYPE, m_params.filterType);
    state.SetVariableI(HRT_VAR_ENABLE_RR, m_params.enableRR);

    state.SetVariableI(HRT_RENDER_LAYER, a_renderState.GetRenderLayer());
    state.SetVariableI(HRT_RENDER_LAYER_DEPTH, a_renderState.GetRenderLayerDepth());

    state.SetVariableI(HRT_ENABLE_PATH_REGENERATE, a_renderState.enablePathRegenerate);

    if (a_renderState.GetRenderLayer() == LAYER_POSITIONS ||
        a_renderState.GetRenderLayer() == LAYER_NORMALS   ||
        a_renderState.GetRenderLayer() == LAYER_TEXCOORD  ||
        a_renderState.GetRenderLayer() == LAYER_TEXCOLOR_AND_MATERIAL ||
        a_renderState.GetRenderLayer() == LAYER_INCOMING_PRIMARY)
    {
      state.SetVariableI(HRT_TRACE_DEPTH, 1 + a_renderState.GetRenderLayerDepth());
      state.SetFlags(HRT_DIFFUSE_REFLECTION, 0); // disable diffuse reflections

      if (a_renderState.GetRenderLayer() != LAYER_INCOMING_PRIMARY)
        state.SetFlags(HRT_DISABLE_SHADING, 1);
    }
    else if (a_renderState.GetRenderLayer() == LAYER_INCOMING_RADIANCE)
    {
      state.SetFlags(HRT_DIFFUSE_REFLECTION, 1); // enable diffuse reflections
    }
    else if (a_renderState.GetRenderLayer() == LAYER_COLOR_THE_REST || a_renderState.GetRenderLayer() == LAYER_COLOR_PRIMARY_AND_REST)
    {

    }

    m_startScreenBlockListSize = (int)m_screenBlockList.size();

    state.SetFlags(HRT_ENABLE_QMC_ONE_SEED, 0);
    
    m_pHWLayer->SetAllFlagsAndVars(state);

    m_pHWLayer->InitPathTracing(m_lastSeed);
   
    m_currGartherRadius = m_initialGatherRadiusDiffuse;
    m_currCausticGartherRadius = m_initialGatherRadiusCaustic;
    m_lastValidGatherRadius = m_initialGatherRadiusDiffuse;

    m_pathTracingState = STATE_TRACING;
    //break;
  }
  case STATE_TRACING:
  {
    m_currPTPassNumber++;

    if (m_screenBlockList.empty())
    {
      m_pathTracingState = STATE_FINISHED;
    }
    else
    {
      if (m_params.coherent)     // set swizzle pattern inside ZBlock
      {
        hrtNextSwizzlePattern();
        hrtFillXYBuffer();
      }

      bool diffusePhotonsPass = (m_phMapPresets.diffuseRetracePass == 1) || ((m_currPTPassNumber % m_phMapPresets.diffuseRetracePass) == 0);
      bool causticPhotonsPass = (m_phMapPresets.causticRetracePass == 1) || ((m_currPTPassNumber % m_phMapPresets.causticRetracePass) == 0);
      bool dlPhotonsPass      = (m_lastRenderState.guidedPathTracing   ) && ((m_currPTPassNumber % 16) == 0);

      bool retracePhotonsForThisLayer = ( a_renderState.GetRenderLayer() == LAYER_INCOMING_RADIANCE ||
                                          a_renderState.GetRenderLayer() == LAYER_COLOR             ||
                                          a_renderState.GetRenderLayer() == LAYER_INCOMING_PRIMARY  ||
                                          a_renderState.GetRenderLayer() == LAYER_COLOR_PRIMARY_AND_REST); 

      if (a_renderState.GetRenderLayer() == LAYER_COLOR_THE_REST)
      {
        diffusePhotonsPass = true;
        causticPhotonsPass = false;
        retracePhotonsForThisLayer = true;
        m_pCausticPhotonMap->Clear();
      }
      else if (a_renderState.GetRenderLayer() == LAYER_INCOMING_RADIANCE)
      {
        causticPhotonsPass = false;
        m_pCausticPhotonMap->Clear();
      }

      if (m_photonMapsPrepared && a_renderState.GetEnableCG() && m_phMapPresets.progressiveCausticMap && causticPhotonsPass && retracePhotonsForThisLayer && m_currPTPassNumber > 1)
        CausticPhotonPass();

      if (m_photonMapsPrepared && a_renderState.GetEnableFG() && m_phMapPresets.progressivePhotonMap && diffusePhotonsPass && retracePhotonsForThisLayer && m_currPTPassNumber > 1)
        DiffusePhotonPass();

      if (dlPhotonsPass)
        DirectPhotonPass(m_pLightDirectPhotonMap);
      
      m_pHWLayer->BeginBlocksPTPass(m_screenBlockList, m_screenFinished, m_params.minRaysPerPixel, m_params.maxRaysPerPixel);

      m_currRaysPerPixel = m_pHWLayer->GetRaysPerPixel();
     
      if (m_screenBlockList.empty())
      {
        m_avgRaysPerPixel /= float(width*height);
        m_pathTracingState = STATE_FINISHED;
      }

    }

    break;
  }
  case STATE_FINISHED:
  {
   

    break;
  }
  }

}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::CopyResultToGLBuffer()
{
  m_pHWLayer->GetLDRImageToGL(m_glRes.m_screenBuffer);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::EndPathTracingPass()
{ 
  m_pHWLayer->EndBlocksPTPass();

  GPU_Ray_Tracer::EndDrawScene();
  
  DegudDrawActiveBlocksAndStatisticsData();

  return m_screenBlockList.empty() || forceEnd;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DumpBufferToFile(const char* a_buffName, const char* a_fileName)
{
 
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::GetZBlockedImage(float4* a_colorSumm, float4* a_colorSummSquare, ZBlock* a_zblocks)
{
  m_pHWLayer->GetHDRImageZCurve(a_colorSumm, a_colorSummSquare, width, height);

  // fill zblocks image
  //
  int BLOCK_NUMBER = (width*height) / (ZBlock::GetSize());
  memset(a_zblocks, 0, BLOCK_NUMBER*sizeof(a_zblocks));

  for (auto p = m_screenBlockList.begin(); p != m_screenBlockList.end(); ++p)
  {
    a_zblocks[p->index] = (*p);
    a_zblocks[p->index].index2 = 0;         // mark as not finished
  }

  for (auto p = m_screenFinished.begin(); p != m_screenFinished.end(); ++p)
  {
    a_zblocks[p->index] = (*p);
    a_zblocks[p->index].index2 = 0xFFFFFFFF; // mark as finished
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DegudDrawActiveBlocksAndStatisticsData()
{
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);

  int counter=0;
  if(m_params.drawBlocks)
  {
    float size = Z_ORDER_BLOCK_SIZE;

    std::vector<float3>& resultData = m_zblocksPosTmp;

    for(BlockList::iterator p=m_screenBlockList.begin();p!=m_screenBlockList.end();++p)
    {
      float2 coord = m_zBlocksCoordByIndex[p->index];
      float  err   = p->diff;

      if(p->counter <= m_params.minRaysPerPixel)
        err = 1000.0f;

      if(p->counter != 0)
      {
        resultData[counter] = float3(coord.x, coord.y, err);
        counter++;
      }
    }

    glNamedBufferDataEXT(m_glRes.m_blocksPos, counter*sizeof(float3), &resultData[0], GL_DYNAMIC_DRAW); CHECK_GL_ERRORS;

    glUseProgram(m_display2DLines.program);  CHECK_GL_ERRORS; 

    setUniform(m_display2DLines.program, "size",      float2(size, size)); 
    setUniform(m_display2DLines.program, "useColorCoding", 1); 
    setUniform(m_display2DLines.program, "errBounds", float2(m_blockErrorMinGreen, m_blockErrorMaxRed)); 
    setUniform(m_display2DLines.program, "projectionMatrix", m_ortoMat); 
    setUniform(m_display2DLines.program, "color", float4(1,0,0,1)); 

    glBindVertexArray(m_glRes.m_vaoBlocks); CHECK_GL_ERRORS; 
    glDrawArrays(GL_POINTS, 0, counter);    CHECK_GL_ERRORS; 

    glBindVertexArray(0); CHECK_GL_ERRORS; 
    glUseProgram(0);      CHECK_GL_ERRORS; 
  }
  
  if(m_params.drawRaysStatInfo && gl_ver <= 3.1)
  {
    // legacy
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glLoadMatrixf(m_ortoMat.L);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glPushAttrib(GL_CURRENT_RASTER_POSITION);
    glColor3f(1,1,0);

    float startY = height - 20;
  
    glRasterPos2f(10, startY-200);
    glPrint("RAYS_PER_PIXEL: %d", m_currRaysPerPixel);

    glRasterPos2f(10, startY-220);
    glPrint("ACTIVE_TILES  : %d", counter);
    glPopAttrib();
  }
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::MarkVisibleSurfaces(IPhotonMap* a_photonMap)
{
  if(m_phMapPresets.disableVisibilityTracing)
  {
    hrtClearPrimitiveIndicesFromFGFlags(SURF_FRONT | SURF_BACK);
    return;
  }
  else
    hrtClearPrimitiveIndicesFromFGFlags(0); 

  RenderSettings oldSettings = m_lastRenderState;
  RenderSettings newSettings = m_lastRenderState;

  hrtPushAllVars();
  hrtPushAllFlags();
  if(a_photonMap->IsCausticMap())
    hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 0);
 
  hrtSetFlags(HRT_MARK_SURFACES_FG, 1);

  newSettings.SetEnableFG(false);
  newSettings.SetEnableCG(false);
  newSettings.guidedPathTracing = false;

  if(!a_photonMap->IsCausticMap())
  {
    newSettings.SetDiffuseTraceDepth(1);
    newSettings.SetIndirrectIllumination(true);
  }

  size_t totalPixels = width*height;
  size_t megaBlock   = hrtGetMegaBlockSize();
  size_t timesScreen = totalPixels / megaBlock;

  int passNumber     = 4 * int(timesScreen);

  if(a_photonMap->IsCausticMap())
    passNumber = 4;

  RenderingParams oldPathTracerParams = m_params;
  RenderingParams newPathTracerParams = m_params;

  newPathTracerParams.minRaysPerPixel = 4;
  newPathTracerParams.maxRaysPerPixel = 16;

  for(int i=0;i<passNumber;i++)
  {
    this->SetRenderingParams(newPathTracerParams);
    this->BeginPathTracingPass(newSettings);
    this->EndPathTracingPass();
    
    if(i%4 == 0)
      m_updateProgressCall("Tracing Importance Particles ", float(i)/float(passNumber));

    if(i%4 && !(m_initFlags & GPU_RT_NOWINDOW))
      glutSwapBuffers();
  }

  this->SetRenderingParams(oldPathTracerParams);

  hrtPopAllVars();
  hrtPopAllFlags();
  m_lastRenderState = oldSettings;

  std::cerr << std::endl;
}


void GPU_Path_Tracer::PhotonTracing(IPhotonMap* a_photonMap, float a_gartherRadius)
{
  float vpTracingTime = 0;
  float photonsTraceTime = 0;
  float buildingOctreeTime = 0;

  BuildOctreeTimings octreeTimings;
  
  if(m_lights.size() > 0)
  {
    Timer mytimer(true);

    if(m_debugOutput)
    {
      hrtThreadSynchronize();
      vpTracingTime = mytimer.getElapsed(); mytimer.start();
      hrtThreadSynchronize();
    }

    mytimer.start();

    a_photonMap->TracePhotons();

    if(m_debugOutput)
    {
      hrtThreadSynchronize();
      photonsTraceTime = mytimer.getElapsed(); mytimer.start();
      hrtThreadSynchronize();
    }

    a_photonMap->BuildOctree(a_gartherRadius, &octreeTimings);

    if(m_debugOutput)
    {
      hrtThreadSynchronize();
      buildingOctreeTime = mytimer.getElapsed();
      hrtThreadSynchronize();
    }
  }
  
  //std::cerr << "m_lights.size() = " << m_lights.size() << std::endl;

  if(m_debugOutput)
  {
    std::cout << std::endl;
    std::cout << "TracePhotons time = " << photonsTraceTime << std::endl;
    std::cout << "buildOctree  time = " << buildingOctreeTime << std::endl;
    
    std::cout << std::endl;
    std::cout << "photon sort  time = " << octreeTimings.photonSortingTime << std::endl;
    std::cout << "append refs  time = " << octreeTimings.appendRefsTime << std::endl;
    std::cout << "refs   sort  time = " << octreeTimings.sortRefs << std::endl;
    std::cout << "append nodes time = " << octreeTimings.appendNodesTime << std::endl;
    std::cout << "nodes  sort  time = " << octreeTimings.sortNodes << std::endl;
    std::cout << "alloc/free   time = " << octreeTimings.allocFreeTime << std::endl;
    std::cout << "cpFromSymbol time = " << octreeTimings.memcpyFromSymbolTime << std::endl;
    std::cout << "other overh  time = " << octreeTimings.otherOverhead << std::endl;
    std::cout << "total        time = " << octreeTimings.photonSortingTime + octreeTimings.sortRefs + octreeTimings.appendRefsTime + \
    octreeTimings.allocFreeTime + octreeTimings.memcpyFromSymbolTime + octreeTimings.otherOverhead << std::endl;
  }
}

float GPU_Path_Tracer::sizeInPixelsToScenePerCentSize(float a_sizeInPx, float avgPixelSize)
{
  float3 diff   = m_bBox.vmax - m_bBox.vmin;
  float  maxSize = ::fmaxf(diff.x, ::fmaxf(diff.y, diff.z));
  float  avgPixelSizeInPerCent = avgPixelSize/maxSize;
  return a_sizeInPx*avgPixelSizeInPerCent;
}

void GPU_Path_Tracer::PreparePhotonMaps(RenderSettings a_renderState)
{
  if (m_pPhotonMap == NULL)
    return;

  float avgPixelSize = hrtEstimateAvgPixelSize();
  float maxRadius    = sizeInPixelsToScenePerCentSize(50.0f, avgPixelSize);

  m_photonMapsPrepared = false;

  m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  m_pCausticPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pCausticPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  m_pLightDirectPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pLightDirectPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  if(a_renderState.GetEnableFG())
    MarkVisibleSurfaces(m_pPhotonMap);
  else if (a_renderState.GetEnableCG())
    MarkVisibleSurfaces(m_pCausticPhotonMap);
  else if(a_renderState.guidedPathTracing)
    MarkVisibleSurfaces(m_pLightDirectPhotonMap);

  if(a_renderState.GetEnableFG() && a_renderState.GetEnableCG())
    hrtSetFlags(HRT_USE_BOTH_PHOTON_MAPS, 1);
  else
    hrtSetFlags(HRT_USE_BOTH_PHOTON_MAPS, 0);

  if(a_renderState.GetEnableFG() && m_phMapPresets.progressivePhotonMap)  // init diffuse photon map
  {
    m_currGartherRadius = sizeInPixelsToScenePerCentSize(m_lastRenderState.GetGartherRadius(), avgPixelSize);
    if(m_currGartherRadius > maxRadius)
      m_currGartherRadius = maxRadius;

    m_photonPassNumber = 1;
    DiffusePhotonPass();
    hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true);

    m_initialGatherRadiusDiffuse = m_currGartherRadius;
    m_lastValidGatherRadius      = m_currGartherRadius;
  }

  if(a_renderState.GetEnableCG() && m_phMapPresets.progressiveCausticMap) // init caustic photon map
  {
    m_currCausticGartherRadius = sizeInPixelsToScenePerCentSize(m_lastRenderState.GetGartherRadiusCaustic(), avgPixelSize);
    if(m_currCausticGartherRadius > maxRadius*0.5f)
      m_currCausticGartherRadius = maxRadius*0.5f;

    m_photonCausticPassNumber = 1;
    CausticPhotonPass();
    hrtPhotonMapSetActiveMap("caustic", m_pCausticPhotonMap, true);
    m_initialGatherRadiusCaustic = m_currCausticGartherRadius;
  }

  if(a_renderState.guidedPathTracing)
  {
    m_currGartherRadiusLD = sizeInPixelsToScenePerCentSize(m_lastRenderState.GetGartherRadius()*1.5f, avgPixelSize);
    if(m_currGartherRadiusLD > maxRadius)
      m_currGartherRadiusLD = maxRadius;

    DirectPhotonPass(m_pLightDirectPhotonMap);
    hrtPhotonMapSetActiveMap("lightsdirect", m_pLightDirectPhotonMap, true);
  }

  ResetPathTracing(m_lastSeed);

  m_photonMapsPrepared = true;
  m_photonCausticNextPassNumber = 1;
  m_photonCausticPassNumber2 = 1;
  m_photonDiffuseNextPassNumber = 1;
  m_photonDiffusePassNumber2 = 1;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DiffusePhotonTracing()
{
  MarkVisibleSurfaces(m_pPhotonMap);

  float avgPixelSize = hrtEstimateAvgPixelSize();
  float maxRadius    = sizeInPixelsToScenePerCentSize(50.0f, avgPixelSize);

  hrtPushAllVars();
  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, m_lastRenderState.GetDiffuseTraceDepth());

  m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);
  
  m_currGartherRadius = sizeInPixelsToScenePerCentSize(m_lastRenderState.GetGartherRadius(), avgPixelSize);
  if(m_currGartherRadius > maxRadius)
    m_currGartherRadius = maxRadius;

  if(m_pPhotonMap->HasPhotonEmitters())
  {
    m_photonPassNumber = 1;
    DiffusePhotonPass();
    hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true);
  }

  hrtPopAllVars();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::CausticPhotonTracing()
{
  MarkVisibleSurfaces(m_pCausticPhotonMap);

  m_pCausticPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pCausticPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  if(m_pCausticPhotonMap->HasPhotonEmitters())
  {
    m_pCausticPhotonMap->Clear();
    PhotonTracing(m_pCausticPhotonMap, m_lastRenderState.GetGartherRadiusCaustic());
    hrtPhotonMapSetActiveMap("caustic", m_pCausticPhotonMap, true);
  }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// a simple but important note for ppm
// sqr(r[i+1])/sqr(r[i]) = (i+alpha)/(i+1);    
// r[i+1] = r[i]*sqrt( (i+alpha)/(i+1)); 
// alpha seems to be = 2/3; Must be in [0,1
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

void GPU_Path_Tracer::DiffusePhotonPass()
{
  if (m_pPhotonMap == NULL)
    return;

  if (!m_pPhotonMap->HasPhotonEmitters())
    return;

  if(m_debugOutput)
    std::cerr << "r[i] = " << m_currGartherRadius <<std::endl;

  if(m_photonPassNumber > 2 && m_photonPassNumber%2 == 0)
  {
    float alpha = m_phMapPresets.alphaD;
    if(alpha < 3.0f/4.0f)
      alpha = 3.0f/4.0f;

    float i = float(m_photonPassNumber)/2.0f;
    m_currGartherRadius = m_currGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
    //std::cerr << "garther radius = " << m_currGartherRadius << std::endl;
  }

  m_photonPassNumber++;

  hrtPushAllFlags();
  hrtPushAllVars();

  hrtSetFlags(HRT_DIFFUSE_PHOTON_TRACING, 1);
  hrtSetFlags(HRT_CAUSTIC_PHOTON_TRACING, 0);

  hrtSetVariableI(HRT_RENDER_LAYER, LAYER_COLOR);

  hrtSetVariableI(HRT_TRACE_DEPTH, 10);
  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 3);
  
  hrtSetFlags(HRT_DIFFUSE_REFLECTION, 1);
  hrtSetFlags(HRT_DISABLE_SHADING, 1);
    

  m_pPhotonMap->Clear();
  PhotonTracing(m_pPhotonMap, m_currGartherRadius);

  // shitty bug
  //
  if(m_pPhotonMap->GetCurrPhotons() != 0)
    m_lastValidGatherRadius = m_currGartherRadius;
  else
  {
    int counter = 0;
    while(m_pPhotonMap->GetCurrPhotons() == 0 && counter < 2)
    {
      m_pPhotonMap->Clear();
      PhotonTracing(m_pPhotonMap, m_lastValidGatherRadius);
      counter++;
    }
  }

  hrtPopAllVars();
  hrtPopAllFlags();

  std::cerr << "retrace photons ... " << std::endl;
}

void GPU_Path_Tracer::DirectPhotonPass(IPhotonMap* a_pPhotonMap)
{
  if (a_pPhotonMap == NULL)
    return;

  if (!a_pPhotonMap->HasPhotonEmitters())
    return;

  hrtPushAllFlags();
  hrtPushAllVars();

  hrtSetFlags(HRT_DIFFUSE_PHOTON_TRACING, 1);
  hrtSetFlags(HRT_LDIRECT_PHOTON_TRACING, 1);
  hrtSetFlags(HRT_CAUSTIC_PHOTON_TRACING, 0);

  hrtSetVariableI(HRT_RENDER_LAYER, LAYER_COLOR);

  hrtSetVariableI(HRT_TRACE_DEPTH, 1);
  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 1);
  
  hrtSetFlags(HRT_DIFFUSE_REFLECTION, 1);
  hrtSetFlags(HRT_DISABLE_SHADING, 1);    
    
  a_pPhotonMap->Clear();
  PhotonTracing(a_pPhotonMap, m_currGartherRadiusLD);

  a_pPhotonMap->BuildLightsTable();

  //a_pPhotonMap->FreePhotonsMemory(); // we don't need actual photons data after we build lights table

  hrtPopAllVars();
  hrtPopAllFlags();

  // hrtPhotonMapSetActiveMap("lightsdirect", a_pPhotonMap, true);
}


void GPU_Path_Tracer::CausticPhotonPass()
{
  if (m_pCausticPhotonMap == NULL)
    return;

  if (!m_pCausticPhotonMap->HasPhotonEmitters())
    return;

  //std::cerr << "caustic pass = " << m_photonCausticPassNumber-1 << std::endl;

  if(m_photonCausticPassNumber > 2 && m_photonCausticPassNumber%2 == 0)
  {
    float alpha = m_phMapPresets.alphaC;
    if(alpha < 3.0f/4.0f)
      alpha = 3.0f/4.0f;

    float i = float(m_photonCausticPassNumber)/2.0f;
    m_currCausticGartherRadius = m_currCausticGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
  }

  hrtPushAllFlags();
  hrtPushAllVars();
  
  hrtSetFlags(HRT_DIFFUSE_PHOTON_TRACING, 0);
  hrtSetFlags(HRT_CAUSTIC_PHOTON_TRACING, 1);
  
  hrtSetVariableI(HRT_RENDER_LAYER, LAYER_COLOR);

  hrtSetVariableI(HRT_TRACE_DEPTH, 10);
  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 0);
  hrtSetFlags(HRT_DISABLE_SHADING, 1);

  hrtSetVariableI(HRT_PHOTONS_STORE_BOUNCE, 0); // for "causticlight"

  m_photonCausticPassNumber++;

  m_pCausticPhotonMap->Clear();
  PhotonTracing(m_pCausticPhotonMap, m_currCausticGartherRadius);

  if(m_debugOutput)
    std::cerr << "r[i] = " << m_currCausticGartherRadius <<std::endl;

  hrtPopAllVars();
  hrtPopAllFlags();

  std::cerr << "retrace caustic photons ... " << std::endl;
}

void GPU_Path_Tracer::TestICToPhotonmap()
{
  if (m_pPhotonMap == NULL)
    return;

   hrtPushAllFlags();
   hrtSetFlags(HRT_TRANSFORM_IC_TO_PHMAP, 1);
   std::cerr << "TestICToPhotonmap start" << std::endl;

   //m_pPhotonMap->SetPhotonsBox(m_octreeAABB.vmin - float3(0.1,0.1,0.1), m_octreeAABB.vmax + float3(0.1,0.1,0.1)); //!!!!!!!!!!!!!!!!!! WILL NOT WORK!!!!!
   m_pPhotonMap->ResizeCurrPhotons( hlmIrradianceCacheGetSize() );

   hlmIrradianceCacheConvertToPhotonMap(m_pPhotonMap);

   float buildingOctreeTime = 0.0f;
   float radius = m_icAverageValidityRadius/2.0f;
   radius = radius/(m_octreeAABB.vmax.x - m_octreeAABB.vmin.x); // set in percentage(!)

   std::cerr << "avg validity radius = " << m_icAverageValidityRadius << std::endl;
 
   hrtThreadSynchronize();
   hrtFreePerRayData();

   Timer mytimer(true);

   m_pPhotonMap->BuildOctree(radius);

   hrtAllocPerRayData(hrtGetMegaBlockSize());  

   if(m_debugOutput)
   {
     hrtThreadSynchronize();
     buildingOctreeTime = mytimer.getElapsed();
   }

   std::cerr << "ICToPhotonmap: " << buildingOctreeTime << std::endl;
   hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true);

   std::cerr << "TestICToPhotonmap end" << std::endl;
   hrtPopAllFlags();
}


static float4 DownSampler(float4 data[8])
{
  float4 res;
  res.x = res.y = res.z = res.w = 0.f;

  for (int i = 0; i < 8; i++)
    res += data[i];

  return res / 8;
}

void GPU_Path_Tracer::DebugCall(const std::string& a_name, const std::string& a_params)
{
  Base::DebugCall(a_name, a_params);
  
  if(a_name == "TracePhotonsTest") //Shift + p
  {
    DiffusePhotonTracing(); 
  }
  else if(a_name == "ClearDiffusePhotons")
  {
    m_pPhotonMap->Clear();
  }
  else if(a_name == "TraceCausticPhotonsTest") //Shift + o
  {
    CausticPhotonTracing();
  }
  else if(a_name == "ClearCausticPhotons") 
  {
    m_pCausticPhotonMap->Clear();
  }
  else if(a_name == "icToPhMap") // Shift + k
  {
    TestICToPhotonmap();
  }
  else if(a_name == "voxelizeDebug") //Shift + v
  {
    BuildIrradianceMap(16);
  }


}

void GPU_Path_Tracer::BuildIrradianceMap(int a_passNum)
{
  if(!m_photonMapsPrepared)
    MarkVisibleSurfaces(m_pPhotonMap);

  float avgPixelSize = hrtEstimateAvgPixelSize();
  float gatherRadius = sizeInPixelsToScenePerCentSize(m_lastRenderState.GetGartherRadius(), avgPixelSize);


  hrtPushAllVars();
  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, m_lastRenderState.GetDiffuseTraceDepth());

  m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  const int numPass = a_passNum;
  for(int i=0;i<numPass;i++)
  {
    m_pPhotonMap->Clear();
    PhotonTracing(m_pPhotonMap, gatherRadius);

    if(i==0)
      m_pPhotonMap->RememberCurrentBoundingBox();

    m_pIrradianceMap->Update(m_pPhotonMap);

    m_updateProgressCall("Building Irradiance Map ", float(i)/float(numPass));
  }

  hrtSetActiveIrradianceMap(m_pIrradianceMap);
  hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true); // this is needed for correct calls inside engine

  hrtPopAllVars();

  hrtSetVariableI(HRT_IMAP_ENABLED, 1);
  
  ResetPathTracing(m_lastSeed);

  m_irradMapConstructed = true;
}

void GPU_Path_Tracer::FreeIrradianceMap()
{
  m_irradMapConstructed = false;
  m_pIrradianceMap->Clear();
  hrtSetVariableI(HRT_IMAP_ENABLED, 0);
}


void GPU_Path_Tracer::SetPhotonMapPresets(const PhotonMapPresets& a_presets)
{
  m_phMapPresets = a_presets;

  if (m_pPhotonMap == NULL || m_pCausticPhotonMap == NULL)
    return;

  if(m_pPhotonMap->GetMaxPhotons() != m_phMapPresets.maxDiffusePhotons)
  {
    hlmDeletePhotonMap(m_pPhotonMap);
    m_pPhotonMap = hlmCreatePhotonMap(m_phMapPresets.maxDiffusePhotons, false, false);
  }

  if(m_pCausticPhotonMap->GetMaxPhotons() != m_phMapPresets.maxCausticPhotons)
  {
    hlmDeletePhotonMap(m_pCausticPhotonMap);
    m_pCausticPhotonMap = hlmCreatePhotonMap(m_phMapPresets.maxCausticPhotons, true, false);
  }
}


void GPU_Path_Tracer::SaveMultyLayeredSubSamples(const char* a_fileName, const char* a_fileName2)
{
  if(m_lastRenderState.GetRenderLayer() == LAYER_NORMALS)
  {
    std::cerr << std::endl;
    std::cerr << "save norlams&depths " << std::endl;
    hrtSaveBoundarySubSamples(a_fileName, a_fileName2); // one row is exactrly one sub sample
    std::cerr << std::endl;
  }

}

