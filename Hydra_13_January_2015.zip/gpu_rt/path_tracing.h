#pragma once
#define PATH_TRACING_GUARDIAN

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif


namespace RAYTR
{

  static unsigned int __device__ __host__ SpreadBits(int x, int offset)
  {

  #ifndef __CUDACC__
    if ((x < 0) || (x > 1023)) RUN_TIME_ERROR("SpreadBits, out of range for x");
    if ((offset < 0) || (offset > 2)) RUN_TIME_ERROR("SpreadBits, out of range for offset");
  #endif

    x = (x | (x << 10)) & 0x000F801F;
    x = (x | (x <<  4)) & 0x00E181C3;
    x = (x | (x <<  2)) & 0x03248649;
    x = (x | (x <<  2)) & 0x09249249;

    return uint(x) << offset;
  }

  static unsigned int __device__ __host__ GetMortonNumber(int x, int y, int z)
  {
    return SpreadBits(x, 0) | SpreadBits(y, 1) | SpreadBits(z, 2);
  }

};

#ifdef __CUDACC__

#include "random_mc.h"
#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

struct RandomGenerator // : public Singleton
{
  void Resize(int a_numThreads) {Init(a_numThreads, 0);}

  void Init(int a_numThreads, int a_seed)
  {
    checkCudaErrors(cudaFree(m_data1));
    checkCudaErrors(cudaFree(m_data2));

    if(USE_SIMPLE_RANDOM)
      m_data1 = NULL;
    else
      checkCudaErrors(cudaMalloc((void**) &m_data1, a_numThreads*sizeof(int4)));
    
    checkCudaErrors(cudaMalloc((void**) &m_data2, a_numThreads*sizeof(int)));

    // save pointers in constant memory; Warning, this is thread unsafe
    //
    checkCudaErrors(cudaMemcpyToSymbol(cm_rndData1, &m_data1, sizeof(int4*)));
    checkCudaErrors(cudaMemcpyToSymbol(cm_rndData2, &m_data2, sizeof(int*)));

    InitRandomGenerator_kernel<<< a_numThreads/512, 512>>>(m_data1, m_data2, a_seed);
    getLastCudaError("Kernel execution failed"); 
  }

  void Dispose()
  {
    checkCudaErrors(cudaFree(m_data1)); m_data1 = NULL;
    checkCudaErrors(cudaFree(m_data2)); m_data2 = NULL;
  }

  RandomGenerator() 
  {
    m_data1 = 0; 
    m_data2 = 0;
  }

  void Destroy()
  {
    checkCudaErrors(cudaFree(m_data1)); m_data1 = NULL;
    checkCudaErrors(cudaFree(m_data2)); m_data2 = NULL;
  }


  int4* m_data1;
  int*  m_data2;
};



struct Hardware_Monte_Carlo_Tracer
{
  Hardware_Monte_Carlo_Tracer();

  //float4* m_pathTraceColor;
  //float4* m_pathTraceColor2;
  
  ZBlock* m_blocks;
  int m_zBlocksNumber;

  int  m_numRandNumbers;
  int m_raysPerPixel;
  int m_stepNumber;

  RandomGenerator m_randomGenerator;
};



#endif

extern "C" int hmctInit(int w, int h);
extern "C" int hmctDelete();
extern "C" int hmctSetZBlocks(ZBlock* cpu_buffer, int a_N);
extern "C" int hmctMegaBlockPathTraceSM(int a_NBlocks);

extern "C" int hmctCompareAndStoreResult(ZBlock* out_cpu_zblocks, int a_NBlocks, bool copyToCPU);
extern "C" int hmctSetRaysPerPixel(int a_rays);


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////
extern "C" int hlmInit();
extern "C" int hlmDelete();

extern "C" int hlmInitHemisphereRaysTexture(int hemisphereId, int index, float4* cpu_dir, int nRays);
extern "C" int hlmInitSHCoefficient(float* coeffs, int w, int h, int layers);


// Irradiance Cache
//
extern "C" int hlmIrradianceCahceGetFullScreenPositions(IrradianceCachePoint_Part1* cpu_data1, IrradianceCachePoint_Part2* cpu_data2, int size);

extern "C" int hlmIrradianceCahceAssign(const IrradianceCachePoint_Part1* cpu_data1,
                                               const IrradianceCachePoint_Part2* cpu_data2,
                                               const IrradianceCachePoint_Part3* cpu_data3, int a_size);

extern "C" int hlmIrradianceCahceComputeIrradiance(int index, const IrradianceCachePoint_Part1* cpu_data1, const IrradianceCachePoint_Part2* cpu_data2, IrradianceCachePoint_Part3* cpu_data3, float* cpuErrors, int a_size);

extern "C" int hlmIrradianceCahceSetOctree(const OctreeNode* octree, int a_nodesNum, const int* pointsIndices, int indicesNum, const float3& center, float boxSize);
extern "C" int hlmIrradianceCahceSetRecordsData(const IrradianceCachePoint_Part1* data1, const IrradianceCachePoint_Part2* data2, const IrradianceCachePoint_Part3* data3, int n_points);

extern "C" int hlmIrradianceCacheFindMoreCandidates(IrradianceCachePoint_Part1* cpu_data1, IrradianceCachePoint_Part2* cpu_data2, int a_MaxSize, int* a_pRecordedPoints);
extern "C" int hlmIrradianceCacheFindIrradianceGapsScreenSpace(IrradianceCachePoint_Part1* cpu_data1, IrradianceCachePoint_Part2* cpu_data2, int a_MaxSize, float a_treshold, int* a_pRecordedPoints);


extern "C" int hlmIrradianceCacheConvertToPhotonMap(IPhotonMap* a_phMap);
extern "C" int hlmIrradianceCacheGetSize();

// Radiance Cache
//
extern "C" int hlmRadianceCacheCreate();
extern "C" int hlmRadianceCacheDestroy(int a_objectId);
extern "C" int hlmRadianceCacheClear(int a_objectId);

extern "C" int hlmRadianceCacheComputeHarmonics(int a_objectId,int index, float4* in_pos, int a_size); // return last size of rc buffer
extern "C" int hlmRadianceCacheComputeCubeMaps(int a_objectId, int index, float4* in_pos, int a_size); // return last size of rc buffer
extern "C" int hlmRadianceCacheSetBVH(int a_objectId, const BVHNode* a_treeData, int a_nodesNum);


