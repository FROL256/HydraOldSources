#pragma once
#include <gl/glew.h>

#include "IGraphicsEngine.h"
#include "Ray_Tracer.h"
#include "GPU_Ray_Tracer.h"
#include "IrradianceCache.h"
#include "RadianceCache.h"
#include "PhotonMap.h"

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
  #include "path_tracing.h"
#endif

class DLL_API GPU_Path_Tracer: public GPU_Ray_Tracer // ,public Singleton
{
  typedef GPU_Ray_Tracer Base;

public:
  
  GPU_Path_Tracer(int w, int h, int flags = 0, int a_devId = 0);
  ~GPU_Path_Tracer();

  struct DLL_API RenderingParams
  { 
    enum FILERS{PT_FILTER_TYPE_NONE = 0, PT_FILTER_TYPE_BILINEAR = 1 };

    RenderingParams()
    {
      qualityTreshold  = 1.0f; // control path tracing error
      //icErrorThreshold = 0.1f; // control ic error

      minRaysPerPixel = 8;
      maxRaysPerPixel = 1000;
      initialSPP = 1;
      useHDRQualityEstimation = true;
      drawBlocks = false;
      qmcOneSeed = false;

      enableDOF = false;
      dofLensRadius = 1.0f;
      dofFocalPlaneDist = 10.0f;

      coherent = false;
      enableRR = true;
      useMIS   = true;
      noRandomLightSelect = false;

      loaylEstimateFunctionTresholdInRays = 200;
    }

    float qualityTreshold;
    //float icErrorThreshold;
    int   minRaysPerPixel;
    int   maxRaysPerPixel;
    short initialSPP;
    bool  useHDRQualityEstimation;
    bool  drawBlocks;
    bool  drawRaysStatInfo;
    bool  enableDOF;
    bool  qmcOneSeed;
    bool  coherent;
    bool  enableRR;
    bool  useMIS;
    bool  noRandomLightSelect;
    float dofLensRadius;
    float dofFocalPlaneDist;

    int   filterType;
    float loaylEstimateFunctionTresholdInRays;
  };

  struct DLL_API PhotonMapPresets
  {
    PhotonMapPresets(): progressivePhotonMap(true), maxDiffusePhotons(1000000), maxCausticPhotons(1000000), disableVisibilityTracing(false), alphaC(0.66667f), alphaD(0.66667f) {}
    
    int  maxDiffusePhotons;
    int  maxCausticPhotons;
    
    bool progressivePhotonMap;
    bool progressiveCausticMap;
    bool disableVisibilityTracing;

    int  diffuseRetracePass;
    int  causticRetracePass;

    float alphaC;
    float alphaD;
  };

  void SetPhotonMapPresets(const PhotonMapPresets& a_presets);

  void SetRenderingParams(const RenderingParams& a_params);
  void SetICPresets(const RAYTR::ICPresets& a_presets);

  void BeginPathTracingPass(RenderSettings a_renderState);			
  bool EndPathTracingPass(); 

  bool PathTracingFinished() const; // return true if path tracing has finished
  void ResetPathTracing(int a_seed);
  
  void DumpBufferToFile(const char* a_buffName, const char* a_fileName);

  void SetRaysPerPixel(int a_num) 
  { 
    m_currRaysPerPixel = a_num;  
    m_pHWLayer->SetRaysPerPixel(a_num);
  }

  void ComputeIrradianceCache();
  void FreeIrradianceCache();

  void ComputeRadianceCache(int a_type);
  void FreeRadianceCache();

  void PreparePhotonMaps(RenderSettings a_renderState);
  
  void BuildIrradianceMap(int a_passNum);
  void FreeIrradianceMap();

  void DebugCall(const std::string& a_name, const std::string& a_params);

  enum PATH_TRACING_STATES {STATE_BEGIN, STATE_TRACING, STATE_FINISHED};
  int GetPathTracingState() const {return m_pathTracingState;}

  void SetWindowResolution(int a_width, int a_height);

  void DiffusePhotonTracing();
  void CausticPhotonTracing();

  void SaveMultyLayeredSubSamples(const char* a_fileName, const char* a_fileName2);

  void GetZBlockedImage(float4* a_colorSumm, float4* a_colorSummSquare, ZBlock* a_zblocks);

protected:

  GPU_Path_Tracer(const GPU_Path_Tracer& rhs);
  GPU_Path_Tracer& operator=(const GPU_Path_Tracer& rhs);

  typedef MGML_MEMORY::FastList<ZBlock> BlockList; 
  //typedef std::list<ZBlock> BlockList; 
  
  void MakeScreenBlockList(BlockList*);
  void CheckBlockListF(GPU_Path_Tracer::BlockList* pList, const char* file, int line);
  
  void InsertPointsInOctree(const RAYTR::IrradianceCacheDataSet& a_dataSet, IrradCacheOctreeAPI* pOctree);

  void CopyResultToGLBuffer(); 

  void DegudDrawActiveBlocksAndStatisticsData();
  void DrawICRecords();
  void FreeICRecordsGLBuffer();

  // photon mapping
  //
  void DrawPhotons(const char* a_phMapName);
  void FreeGLPhotonsData(const char* a_phMapName);

  void MarkVisibleSurfaces(IPhotonMap* a_photonMap);
  void PhotonTracing(IPhotonMap* a_photonMap, float a_gartherRadius);

  void TestICToPhotonmap();
  
  void CausticPhotonPass();
  void DiffusePhotonPass();
  void DirectPhotonPass(IPhotonMap* a_pPhotonMap);

  float sizeInPixelsToScenePerCentSize(float a_sizeInPx, float avgPixelSize);

  // data
  //
  enum {START_LAST_PASS=32};
  int m_pathTracingState;

  BlockList m_screenBlockList;
  BlockList m_screenFinished;
  float m_avgError;
  float EtimateTotalRenderingProgress() const;

  //int m_blocksArraySize;
  int m_lastPass;
  bool m_megaBlockPathTraceInProcess;
  bool forceEnd;
  std::vector<float2> m_zBlocksCoordByIndex;
  std::vector<float3> m_zblocksPosTmp;
  float m_blockErrorMaxRed;   // for blocks color encoding
  float m_blockErrorMinGreen;  // for blocks color encoding

  RenderingParams m_params;
  ICPresets       m_icPresets;
  int m_currRaysPerPixel;

  bool m_debugICacheFileOutput;
  bool m_voxelRadianceCacheEnabled;

  AABB3f m_octreeAABB;
  float m_icAverageValidityRadius;
  RadianceCache* m_pRC;
  IPhotonMap* m_pPhotonMap;
  IPhotonMap* m_pCausticPhotonMap;
  IPhotonMap* m_pLightDirectPhotonMap;
  IIrradianceMap* m_pIrradianceMap;
  PhotonMapPresets m_phMapPresets;

  bool m_irradMapConstructed;

  float m_currCausticGartherRadius;
  float m_currGartherRadius;     
  float m_currGartherRadiusLD;     // LD means Lights Direct, this is for smart lights sampling

  float m_initialGatherRadiusDiffuse;
  float m_initialGatherRadiusCaustic;
  float m_lastValidGatherRadius;

  int   m_photonCausticPassNumber;
  int   m_photonCausticNextPassNumber;
  int   m_photonCausticPassNumber2;
  int   m_photonDiffuseNextPassNumber;
  int   m_photonDiffusePassNumber2;
  int   m_photonPassNumber;
  int   m_currPTPassNumber; 
  bool  m_photonMapsPrepared;
  int   m_lastSeed;
 
  ShaderProgram   m_display2DLines;
  Matrix4x4f      m_ortoMat;

  std::vector<ZBlock> blockesInQueue;
};

