#include "GPUAbstractLayer.h"

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
  #include "path_tracing.h"
#endif


void IHWLayer::SetAllFlagsAndVars(const AllRenderVarialbes& a_vars)
{
  m_vars = a_vars;
}

AllRenderVarialbes IHWLayer::GetAllFlagsAndVars() const
{
  return m_vars;
}


void IHWLayer::PushState()
{
  m_varsStack.push(m_vars);
}

void IHWLayer::PopState()
{
  m_vars = m_varsStack.top();
  m_varsStack.pop();
  m_flagsStack.pop();
}



void AllRenderVarialbes::SetVariableI(int a_name, int a_val)
{
  if (a_name<GMAXVARS)
    m_varsI[a_name] = a_val;
}

void AllRenderVarialbes::SetVariableF(int a_name, float a_val)
{
  if (a_name<GMAXVARS)
    m_varsF[a_name] = a_val;
}

void AllRenderVarialbes::SetFlags(unsigned int bits, unsigned int a_value)
{
  if (a_value == 0)
    m_flags = m_flags & (~bits);
  else
    m_flags |= bits;
}

bool AllRenderVarialbes::shadePassEnable()
{
  if ((m_flags & HRT_MARK_SURFACES_FG) || (m_flags & HRT_IRRDAIANCE_CACHE_FIND_SECONDARY) || (m_flags & HRT_DISABLE_SHADING) || (m_flags & HRT_STUPID_PT_MODE))
    return false;

  if (m_varsI[HRT_RENDER_LAYER] == LAYER_POSITIONS || m_varsI[HRT_RENDER_LAYER] == LAYER_NORMALS || m_varsI[HRT_RENDER_LAYER] == LAYER_TEXCOORD || m_varsI[HRT_RENDER_LAYER] == LAYER_TEXCOLOR_AND_MATERIAL)
    return false;

  if ((m_flags & HRT_DIFFUSE_PHOTON_TRACING) || (m_flags & HRT_CAUSTIC_PHOTON_TRACING) || (m_flags & HRT_LDIRECT_PHOTON_TRACING))
    return false;

  return true;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

CUDAHWLayer::CUDAHWLayer(int w, int h, int a_flags)
{
  hrtInit(w, h, a_flags);
  hmctInit(w, h);
  hlmInit();

  m_currRaysPerPixel = 1;
  m_width = w; 
  m_height = h;
  m_blocksArray.resize((w*h) / (ZBlock::GetSize()));
}


CUDAHWLayer::~CUDAHWLayer()
{
  hlmDelete();
  hmctDelete();
  hrtDelete();
}


void CUDAHWLayer::ResizeScreen(int width, int height, int a_flags)
{
  hrtPTFreePerRayData();
  hrtFreeScreenBuffersData();
  hrtFreePerRayData();

  int MEGA_BLOCK_SIZE = width*height / 2;
  if (MEGA_BLOCK_SIZE > 1280 * 1024)
    MEGA_BLOCK_SIZE = width*height / 4;

  hrtAllocScreenBuffersData(width, height);
  hrtAllocPerRayData(MEGA_BLOCK_SIZE);
  hrtPTAllocPerRayData(MEGA_BLOCK_SIZE);

  m_currRaysPerPixel = 1;
  m_width            = width;
  m_height           = height;
}

size_t CUDAHWLayer::GetAvaliableMemoryAmount(bool allMem)
{
  return hrtGetAvaliableMemoryAmount(allMem);
}

void CUDAHWLayer::SetGeom(InputGeom a_input)
{
  if(a_input.vertPos == NULL || a_input.vertNorm == NULL || a_input.vertTexCoord == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid vertex data null pointer");

  if (a_input.indices == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid indices null pointer");

  if (a_input.materialIndices == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid triangle material indices null pointer");

  if (a_input.numIndices % 3 != 0)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid input.numIndices value, must be multiple of 3");

  hrtSetCommonVertexAttributes(a_input.vertPos, a_input.vertNorm, a_input.vertTexCoord, NULL, int(a_input.vertNum));
  //hrtSetTangentAtrributes(a_input.vertTangent, int(a_input.vertNum));
  hrtSetIndices32(a_input.indices, int(a_input.numIndices));
  
}


void CUDAHWLayer::SetBVH(InputGeomBVH a_input)
{
  if (a_input.nodes == NULL || a_input.primListData == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetBVH: invalid bvh data null pointer");

  if (a_input.numNodes == NULL || a_input.primListSizeInBytes == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetBVH: invalid bvh data size");

  hrtSetWorldBVH(a_input.nodes, uint(a_input.numNodes));
  hrtSetWorldObjectListData(a_input.primListData, uint(a_input.primListSizeInBytes), uint(a_input.triNumInList));
  hrtSetCurrAccelStructType(ACCEL_STRUCT_BVH);
}

void CUDAHWLayer::SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum)
{

}

void CUDAHWLayer::SetAllPODLights(RAYTR::Light* a_lights, PlainLight* a_lights2, size_t a_number)
{
  //fprintf(stderr, "[cpp ]: sizeof(Light) = %d\n", sizeof(RAYTR::Light));
  hrtSetLights(a_lights, int(a_number));
}


void CUDAHWLayer::SetAllFlagsAndVars(const AllRenderVarialbes& a_vars)
{
  this->IHWLayer::SetAllFlagsAndVars(a_vars);

  hrtSetAllFlags(a_vars.m_flags);
  
  for (int i = 0; i < GMAXVARS; i++)
  {
    hrtSetVariableI(i, a_vars.m_varsI[i]);
    hrtSetVariableF(i, a_vars.m_varsF[i]);
  }

}

AllRenderVarialbes CUDAHWLayer::GetAllFlagsAndVars() const
{
  AllRenderVarialbes state = IHWLayer::GetAllFlagsAndVars();

  state.m_flags = hrtGetFlags();

  for (int i = 0; i < GMAXVARS; i++)
  {
    state.m_varsI[i] = hrtGetVariableI(i);
    state.m_varsF[i] = hrtGetVariableF(i);
  }

  return state;
}

void CUDAHWLayer::SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats)
{
  if (a_sizeInFloats%16 != 0)
    RUN_TIME_ERROR("CUDAHWLayer::SetAllTextureMatrices: invalid matrices a_sizeInFloats");

  hrtSetTextureMatrices(a_data, a_sizeInFloats/16);
}

void CUDAHWLayer::SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data)
{
  switch (usage)
  {
  case MEGATEX_SHADING:
    hrtAddMegaTexture4ub("shadingTexture", a_data.outOfCore, a_data.data, a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
    break;

  case MEGATEX_SHADING_HDR:
    hrtAddMegaTexture4f("shadingTextureHDR", a_data.outOfCore, (const float*)a_data.data, a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
    break;

  case MEGATEX_NORMAL:
    hrtAddMegaTexture4ub("normalmapTexture", a_data.outOfCore, a_data.data, a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
    break;
  
  case MEGATEX_OPACITY:
  {
    std::vector<unsigned char> tempData(a_data.w*a_data.h);

    for (int i = 0; i < tempData.size(); i++)
    {
      unsigned char r = a_data.data[4*i + 0];
      unsigned char g = a_data.data[4*i + 1];
      unsigned char b = a_data.data[4*i + 2];
      unsigned char a = a_data.data[4*i + 3];

      int avg = (int(r) + int(g) + int(b)) / 3; // or alpha ??? WARNING: this is different for different textures

      tempData[i] = (unsigned char)(avg);
    }

    hrtAddMegaTexture1ub("opacityTexture", a_data.outOfCore, (const char*)&tempData[0], a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
  }
  break;

  default:
    RUN_TIME_ERROR("CUDAHWLayer::SetMegaTexture: invalid usage");
    break;
  };
 
}

void CUDAHWLayer::Clear(IGraphicsEngine::CLEAR_FLAGS a_flags)
{
  if (a_flags & IGraphicsEngine::CLEAR_TEXTURES)
    hrtClearMegaTextures();

  if (a_flags & IGraphicsEngine::CLEAR_LIGHTS)
  {
    // clear lights 
    // clear light meshes
  }

  if (a_flags & IGraphicsEngine::CLEAR_MATERIALS)
  {

  }

  if (a_flags & IGraphicsEngine::CLEAR_GEOMETRY)
  {

  }


}

void CUDAHWLayer::SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16])
{
  sga_cudaMemcpyToSymbol("g_mViewProjInv", mProjInverse, 16 * sizeof(float));
  sga_cudaMemcpyToSymbol("g_mWorldViewInv", mWorldViewInverse, 16 * sizeof(float));

  hrtSetCamMatrices(mProjInverse, mWorldViewInverse);

}


//
//
void CUDAHWLayer::GetLDRImageToGL(GLuint ogl_buffer) const
{
  hrtEndTrace(ogl_buffer, NULL);
}

void CUDAHWLayer::GetLDRImage(uint* data, int width, int height) const
{
  hrtGetBuffer("LDRColorBuffer", data, width*height*sizeof(uint), 0);
}

void CUDAHWLayer::GetHDRImage(float4* data, int width, int height) const
{
  hrtGetBuffer("HDRColorBuffer", data, width*height*sizeof(float4), 0);
}


void CUDAHWLayer::InitPathTracing(int seed)
{
  hrtInitRandom(seed);
  hrtFillXYBufferAndClearAccumBuffers();
}

void CUDAHWLayer::BeginBlocksPTPass(BlockList& a_list, BlockList& a_listFinished, int a_minRaysPerPixel, int a_maxRaysPerPixel)
{
  int NTimes = blocks(m_width*m_height, hrtGetMegaBlockSize());

  for (int i = 0; i < NTimes; i++)
    DoMegaBlock(a_list, a_listFinished, a_minRaysPerPixel, a_maxRaysPerPixel);
}

void CUDAHWLayer::DoMegaBlock(BlockList& a_blockList, BlockList& a_listFinished, int a_minRaysPerPixel, int a_maxRaysPerPixel)
{
  if (a_blockList.empty())
    return;

  const int zblocksInParallelNumber = hrtGetMegaBlockSize() / (ZBlock::GetSize()*m_currRaysPerPixel);

  // fetch first zblocksInParallelNumber ZBlocks from list and make array of it
  //
  int counter = 0;
  while (!a_blockList.empty() && counter < zblocksInParallelNumber)
  {
    m_blocksArray[counter] = *(a_blockList.begin());
    a_blockList.pop_front();
    counter++;
  }

  bool unprocessedTilesExists = (a_blockList.size() != 0);

  hmctSetZBlocks(&m_blocksArray[0], counter);

  for (int i = 0; i<2; i++) // trace 2 times to reduce CPU overhead
  {
    hmctMegaBlockPathTraceSM(counter); ASSERT(counter*ZBlock::GetSize() <= hrtGetMegaBlockSize());
    hmctCompareAndStoreResult(&m_blocksArray[0], counter, bool(i == 1));  // compare old blocks colors with new, recompute and store the new result 
  }

  // extract unprocessed block to separate array
  //
  std::vector<ZBlock> blockesInQueue; blockesInQueue.reserve((m_width*m_height) / 256 + 16);
  while (!a_blockList.empty())
  {
    blockesInQueue.push_back(*(a_blockList.begin()));
    a_blockList.pop_front();
  }

  //if (m_params.initialSPP > 1)  // blocks sorting by index, top down scanline render
  if(false)
  {
    // extract all other blocks to the same queue
    //
    while (!a_blockList.empty())
    {
      blockesInQueue.push_back(*(a_blockList.begin()));
      a_blockList.pop_front();
    }

    struct CompareBlocks { bool operator()(const ZBlock& a, const ZBlock& b) { return a.index < b.index; } };

    std::sort(blockesInQueue.begin(), blockesInQueue.end(), CompareBlocks());
  }
  else // sort block with their iter number
  {
    // extract all other blocks to the same queue
    //
    while (!a_blockList.empty())
    {
      blockesInQueue.push_back(*(a_blockList.begin()));
      a_blockList.pop_front();
    }

    for (auto p = blockesInQueue.begin(); p != blockesInQueue.end(); ++p)
      if (p->counter < a_minRaysPerPixel)
        p->diff *= 100;

    //struct CompareBlocks { bool operator()(const ZBlock& a, const ZBlock& b) {return a.diff < b.diff;} };

    struct CompareBlocks { bool operator()(const ZBlock& a, const ZBlock& b) { return a.counter > b.counter; } };

    std::sort(blockesInQueue.begin(), blockesInQueue.end(), CompareBlocks());
  }

  // now see the block quality metric and if it is too small, discard this block from the list
  // 
  for (int i = 0; i<counter; i++)
  {
    float error = 0;

    if (!BlockFinished(m_blocksArray[i], a_minRaysPerPixel, a_maxRaysPerPixel, &error))
      a_blockList.push_front(m_blocksArray[i]);
    else
      a_listFinished.push_front(m_blocksArray[i]);
  }

  // push unprocessed blocks back to make them first in queue
  //
  for (int i = 0; i<blockesInQueue.size(); i++)
    a_blockList.push_front(blockesInQueue[i]);

  if (a_blockList.size() == 0)
    return;

  const int NBLOCKS = hrtGetMegaBlockSize() / ZBlock::GetSize();
  if (a_blockList.size()*m_currRaysPerPixel * 2 <= NBLOCKS && !unprocessedTilesExists)
    SetRaysPerPixel(m_currRaysPerPixel * 2);
}

void CUDAHWLayer::SetRaysPerPixel(int a_num)
{
  m_currRaysPerPixel = a_num;
  hmctSetRaysPerPixel(m_currRaysPerPixel);
  
  if (a_num > 1)
  {
    m_vars.SetFlags(HRT_ENABLE_COHERENT_PT, 0);
    hrtSetFlags(HRT_ENABLE_COHERENT_PT, 0);
  }
}

void CUDAHWLayer::EndBlocksPTPass() 
{

}

MRaysStat CUDAHWLayer::GetRaysStat() 
{ 
  return hrtGetRaysStat(); 
}

unsigned int CUDAHWLayer::AddLightMesh(LightMeshData a_lmesh)
{
  return hrtAddLightMesh(a_lmesh.positions, a_lmesh.texCoords, a_lmesh.texCoords, int(a_lmesh.size));
}

void CUDAHWLayer::ResetPerfCounters()
{
  hrtResetCounters();
}

void CUDAHWLayer::BeginTracingPass()
{
  hrtBeginTrace(0);
}

void CUDAHWLayer::EndTracingPass()
{
 
}


void CUDAHWLayer::RegisterOutputGLBuffer(GLuint ogl_buffer)
{
  hrtRegisterPBO(ogl_buffer);
}

void CUDAHWLayer::UnregisterOutputGLBuffer()
{
  hrtUnregisterPBO();
}




IHWLayer* CreateCudaImpl(int w, int h, int a_flags) { return new CUDAHWLayer(w, h, a_flags); }

