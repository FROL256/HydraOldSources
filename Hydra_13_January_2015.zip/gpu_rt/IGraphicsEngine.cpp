#include "IGraphicsEngine.h"

IGraphicsEngine::IGraphicsEngine(int w,int h){}
IGraphicsEngine::~IGraphicsEngine(){}

IGraphicsEngine::RenderSettings::RenderSettings()
{
  m_traceDepth  = 4;
  m_diffTraceDepth = 2;
  m_AA  = 0;
  m_traceProoceedThreshold = 1e-8f;

  m_shadows = 1;
  m_enableRaysCount = true;
  m_fgBounce = 1;
  m_enableFinalGarthering = false;
  ptCaustics = false;

  m_renderLayer = LAYER_COLOR;
  icBounce = 0;
  guidedPathTracing = 0;
}

IGraphicsEngine::RenderSettings::~RenderSettings(){}

void IGraphicsEngine::RenderSettings::SetDiffuseTraceDepth(int d) {m_diffTraceDepth = d;}
int  IGraphicsEngine::RenderSettings::GetDiffuseTraceDepth() const {return m_diffTraceDepth;}

bool IGraphicsEngine::RenderSettings::GetEnableRaysCounter() const {return m_enableRaysCount;}
void IGraphicsEngine::RenderSettings::SetEnableRaysCounter(bool a_val) {m_enableRaysCount = a_val;}

void IGraphicsEngine::RenderSettings::SetTraceDepth(int a_depth)
{
  m_traceDepth = a_depth;
}

int  IGraphicsEngine::RenderSettings::GetTraceDepth() const  { return m_traceDepth; }
void IGraphicsEngine::RenderSettings::SetShadow(bool a_shadow) { m_shadows = a_shadow; }

bool IGraphicsEngine::RenderSettings::GetShadow() const {return (bool)m_shadows;}

void IGraphicsEngine::RenderSettings::SetAA(int a_AA)
{
  if(a_AA > 127)
    throw std::runtime_error("RendertState: too big AA multi sample value, 256 rays per pixel max");

  m_AA = a_AA;
}

int  IGraphicsEngine::RenderSettings::GetAA() const { return m_AA; }

void  IGraphicsEngine::RenderSettings::SetTraceProceedingsTreshold(float a_treshold)
{
  if(a_treshold > 0.1f || a_treshold < 1e-30f)
    RUN_TIME_ERROR("IGraphicsEngine::SetTraceProceedingsTreshold : incorrect 'TraceProceedings' treshold value, restricted by interval [1e-5,0.1]");

  m_traceProoceedThreshold = a_treshold;
}

float IGraphicsEngine::RenderSettings::GetTraceProceedingsTreshold() const { return m_traceProoceedThreshold; }



void IGraphicsEngine::RenderSettings::SetIndirrectIllumination(bool a_val) { m_giEnabled = a_val; }
bool IGraphicsEngine::RenderSettings::GetIndirrectIllumination() const {return m_giEnabled; }


bool IGraphicsEngine::RenderSettings::GetEnableFG() const  { return m_enableFinalGarthering; }
void IGraphicsEngine::RenderSettings::SetEnableFG(bool a_value) { m_enableFinalGarthering = a_value; }

bool IGraphicsEngine::RenderSettings::GetEnableCG() const  { return m_enableCausticGarthering; }
void IGraphicsEngine::RenderSettings::SetEnableCG(bool a_value) { m_enableCausticGarthering = a_value; }

void  IGraphicsEngine::RenderSettings::SetGartherRadius(float a_val) { m_gartherRadius = a_val;}
float IGraphicsEngine::RenderSettings::GetGartherRadius() const { return m_gartherRadius; }

void  IGraphicsEngine::RenderSettings::SetGartherRadiusCaustic(float a_val) { m_gartherRadiusCaustic = a_val;}
float IGraphicsEngine::RenderSettings::GetGartherRadiusCaustic() const { return m_gartherRadiusCaustic; }

int IGraphicsEngine::RenderSettings::GetGartherBounce() const { return m_fgBounce; }
void IGraphicsEngine::RenderSettings::SetGartherBounce(int a_val) { m_fgBounce = a_val; }

int   IGraphicsEngine::RenderSettings::GetStoreBounce() const { return m_storeBounce; }
void  IGraphicsEngine::RenderSettings::SetStoreBounce(int a_val) { m_storeBounce = a_val; }

void  IGraphicsEngine::RenderSettings::SetGamma(float a_gamma, float a_gammaTex) 
{
  if(a_gammaTex <= 0.0f)
    m_gammaTex = a_gamma;
  else
    m_gammaTex = a_gammaTex;
  m_gamma = a_gamma;
}

float IGraphicsEngine::RenderSettings::GetGamma() const { return m_gamma; }
float IGraphicsEngine::RenderSettings::GetGammaTex() const { return m_gammaTex; }

void IGraphicsEngine::RenderSettings::SetRenderLayer(RENDER_LAYER a_layer) 
{
  if(a_layer < 0 || a_layer > 255)
    RUN_TIME_ERROR("IGraphicsEngine::SetRenderLayer, invalid argument");

  m_renderLayer = a_layer;
}

RENDER_LAYER IGraphicsEngine::RenderSettings::GetRenderLayer() const { return m_renderLayer; }


void IGraphicsEngine::RenderSettings::SetRenderLayerDepth(int a_depth) 
{
   if(a_depth < 0 || a_depth > 255)
    RUN_TIME_ERROR("IGraphicsEngine::SetRenderLayerDepth, invalid argument");

  m_renderLayerDepth = a_depth;
}

int  IGraphicsEngine::RenderSettings::GetRenderLayerDepth() const { return m_renderLayerDepth; }
