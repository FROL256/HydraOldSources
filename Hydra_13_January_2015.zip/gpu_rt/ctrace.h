#ifndef RTCTRACE
#define RTCTRACE

#include "globals.h"
#include "cfetch.h"


IDH_CALL bool RayBoxIntersectionLite(float3 ray_pos, float3 ray_dir, float3 boxMin, float3 boxMax, __private float* tmin, __private float* tmax)
{
  float lo = ray_dir.x*(boxMin.x - ray_pos.x);
  float hi = ray_dir.x*(boxMax.x - ray_pos.x);

  (*tmin) = fmin(lo, hi);
  (*tmax) = fmax(lo, hi);

  float lo1 = ray_dir.y*(boxMin.y - ray_pos.y);
  float hi1 = ray_dir.y*(boxMax.y - ray_pos.y);

  (*tmin) = fmax((*tmin), fmin(lo1, hi1));
  (*tmax) = fmin((*tmax), fmax(lo1, hi1));

  float lo2 = ray_dir.z*(boxMin.z - ray_pos.z);
  float hi2 = ray_dir.z*(boxMax.z - ray_pos.z);

  (*tmin) = fmax((*tmin), fmin(lo2, hi2));
  (*tmax) = fmin((*tmax), fmax(lo2, hi2));

  return ((*tmin) <= (*tmax));
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef COMMON_CPLUS_PLUS_CODE

ID_CALL void IntersectAllPrimitivesInLeaf(float3 ray_pos, float3 ray_dir, unsigned int leaf_offset, float t_min, __private Lite_Hit* pResult, __private int* triAlphaTest, __global float4* a_objListTex)
{
  int2 objectListInfo = getObjectList(leaf_offset, a_objListTex);

  const int NUM_FETCHES_TRI = 3; // sizeof(struct ObjectListTriangle) / sizeof(float4);

  int triAddressStart = objectListInfo.x; 
  int triAddressEnd   = triAddressStart + objectListInfo.y*NUM_FETCHES_TRI;
  float tTriangle     = pResult->t + fabs(pResult->t)*1e-6f;

  
  #pragma unroll 1
  for (int triAddress = triAddressStart; triAddress < triAddressEnd; triAddress += NUM_FETCHES_TRI)
  {

  #ifdef __CUDACC__
    float4 data1 = tex1Dfetch(primLists_tex, triAddress + 0);
    float4 data2 = tex1Dfetch(primLists_tex, triAddress + 1);
    float4 data3 = tex1Dfetch(primLists_tex, triAddress + 2);
  #else
    float4 data1 = a_objListTex[triAddress + 0]; //= read_1Dimagef(a_objListTex, samplerReadElement, triAddress + 0);
    float4 data2 = a_objListTex[triAddress + 1]; //= read_1Dimagef(a_objListTex, samplerReadElement, triAddress + 1);
    float4 data3 = a_objListTex[triAddress + 2]; //= read_1Dimagef(a_objListTex, samplerReadElement, triAddress + 2);
  #endif

    float3 A_pos = to_float3(data1);
    float3 B_pos = to_float3(data2);
    float3 C_pos = to_float3(data3);

    int tempTriAlphaTest = (ALPHA_MATERIAL_MASK & as_int(data1.w));

    float3 edge1 = B_pos - A_pos;
    float3 edge2 = C_pos - A_pos;
    float3 pvec  = cross(ray_dir, edge2);
    float3 tvec  = ray_pos - A_pos;
    float3 qvec  = cross(tvec, edge1);
    float invDet = 1.0f / dot(edge1, pvec);

    float v = dot(tvec, pvec)*invDet;
    float u = dot(qvec, ray_dir)*invDet;
    float t = dot(edge2, qvec)*invDet;

    if (v > 0.f && u > 0.f && u + v < 1.0f && t > t_min && t < tTriangle)
    {
      tTriangle  = t + fabs(t)*1e-6f; //tTriangle = t;
      pResult->t = t;
      pResult->object_id = MakeObjectId(triAddress, HIT_TRIANGLE);
      (*triAlphaTest)    = tempTriAlphaTest;
    }

  }

}


#define STACK_SIZE 80

ID_CALL unsigned int BVHTraversal(float3 ray_pos, float3 ray_dir, float t_rayMin, __private Lite_Hit* pHit, 
                                  __global float4* bvhTex, 
                                  __global float4* objListTex)
{
  int  local_stack[STACK_SIZE]; local_stack[0] = 0xFFFFFFFF;
  int* stack = local_stack + 1;

  int top = 0;
  int leftNodeOffset = 1;
  int triAlphaTest = 0xFFFFFFFF;

  bool searchingForLeaf = true;
  float3 invDir = SafeInverse(ray_dir);

  while (top >= 0)
  {
    
    while (searchingForLeaf)
    {
      float t_minLeft = 0.0f;
      float t_maxLeft = 0.0f;

      BVHNode leftNode         = GetBVHNode(leftNodeOffset, bvhTex);
      bool traverseChild0      = RayBoxIntersectionLite(ray_pos, invDir, leftNode.m_boxMin, leftNode.m_boxMax, &t_minLeft, &t_maxLeft);
      traverseChild0           = traverseChild0 && (t_maxLeft >= t_rayMin) && (t_minLeft <= pHit->t); // t_rayMax is hit.t

      float t_minRight = 0.0f;
      float t_maxRight = 0.0f;

      BVHNode rightNode        = GetBVHNode(leftNodeOffset + 1, bvhTex);
      bool traverseChild1      = RayBoxIntersectionLite(ray_pos, invDir, rightNode.m_boxMin, rightNode.m_boxMax, &t_minRight, &t_maxRight);
      traverseChild1           = traverseChild1 && (t_maxRight >= t_rayMin) && (t_minRight <= pHit->t); // t_rayMax is hit.t

      // traversal decision
      //
      leftNodeOffset = traverseChild0 ? leftNode.m_leftOffsetAndLeaf : rightNode.m_leftOffsetAndLeaf;

      if (traverseChild0 && traverseChild1)
      {
        leftNodeOffset = (t_minLeft <= t_minRight) ? leftNode.m_leftOffsetAndLeaf  : rightNode.m_leftOffsetAndLeaf;
        stack[top]     = (t_minLeft <= t_minRight) ? rightNode.m_leftOffsetAndLeaf : leftNode.m_leftOffsetAndLeaf;
        top++;
      }

      if (!traverseChild0 && !traverseChild1) // both miss, stack.pop()
      {
        top--;
        leftNodeOffset = stack[top];
      }

      searchingForLeaf = !IS_LEAF(leftNodeOffset) && (top >= 0);
      leftNodeOffset   = EXTRACT_OFFSET(leftNodeOffset);
    }
    

    if (leftNodeOffset != 0x7fffffff)
    {
      IntersectAllPrimitivesInLeaf(ray_pos, ray_dir, leftNodeOffset, t_rayMin, pHit, &triAlphaTest, objListTex);
      if (triAlphaTest == 0xFFFFFFFF && GetObjectType(*pHit) != HIT_NONE)
        top = 0;
    }
    
    top--;
    leftNodeOffset = stack[top];

    searchingForLeaf = !IS_LEAF(leftNodeOffset);
    leftNodeOffset = EXTRACT_OFFSET(leftNodeOffset);
  }
  

  return triAlphaTest;
}

#endif // not COMMON_CPLUS_PLUS_CODE

/// other utils functions
//

IDH_CALL float2 triBaricentrics(float3 ray_pos, float3 ray_dir, float3 A_pos, float3 B_pos, float3 C_pos)
{
  float3 edge1   = B_pos - A_pos;
  float3 edge2   = C_pos - A_pos;
  float3 pvec    = cross(ray_dir, edge2);
  float  det     = dot(edge1, pvec);

  float  inv_det = 1.0f / det;
  float3 tvec    = ray_pos - A_pos;
  float  v       = dot(tvec, pvec)*inv_det;

  float3 qvec    = cross(tvec, edge1);
  float  u       = dot(ray_dir, qvec)*inv_det;

  return make_float2(u, v);
}


#endif // file guardian
