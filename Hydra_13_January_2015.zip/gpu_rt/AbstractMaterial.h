#define ABSTRACT_MATERIAL_GUARDIAN

#ifndef __CUDACC__
  #ifndef MGML_GUARDIAN
    #include "../CSL/MGML.h"
  #endif
#endif

#ifndef RTGLOBALS
  #include "../gpu_rt/globals.h"
#endif

#ifndef RTCMATERIAL
  #include "../gpu_rt/cmaterial.h"
#endif

#ifndef RTCLIGHT
  #include "../gpu_rt/clight.h"
#endif


namespace RAYTR
{

  class IMaterial
  {
  public:

    IMaterial(){}
    virtual ~IMaterial() {}

    // classic 6 functions for PT 
    //
    virtual float3 Emittance()  const = 0;
    virtual bool   IsLight()    const = 0;
    virtual int    LightId()    const = 0;

    virtual MatSample SampleAndEvalBxDF(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const = 0;
    virtual float3    EvalBxDF(float3 l, float3 v, float3 n, float2 texCoord) const = 0;
    virtual float     EvalPDF (float3 l, float3 v, float3 n, float2 texCoord) const = 0;

    // these are much harder to understand. They all needed for combination of PT and SPPM/VM and for disabling caustics
    //
    virtual bool   CastCaustic()     const { return materialCastCaustics   (const_cast<PlainMaterial*>(&m_plain)); }
    virtual bool   HasDiffuse()      const { return materialHasDiffuse     (const_cast<PlainMaterial*>(&m_plain)); }
    virtual bool   HasTransparency() const { return materialHasTransparency(const_cast<PlainMaterial*>(&m_plain)); }

    virtual float3 Diffuse()      const { return make_float3(0, 0, 0); }
    virtual float3 Transparency() const { return make_float3(0, 0, 0); } // and this one is for transparent shadow trace

    virtual MatSample SampleAndEvalBxDFCaustic(float4 rands, float3 ray_dir, float3 normal, float2 texCoord) const { return MatSample();  }


    virtual std::vector<PlainMaterial> ConvertToPlainMaterial() const = 0;

  protected:

    PlainMaterial m_plain;

  };


  class ILight
  {
  public:

    ILight(){}
    virtual ~ILight(){}

    virtual ShadowSample Sample(float4 rands, float3 illuminatingPoint) const = 0;
    virtual float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const = 0;
    virtual float3       GetIntensity(float2 a_texCoord) const = 0;

    virtual PlainLight ConvertToPlainLight() const  { return m_plain; }

  protected:

    PlainLight m_plain;

  };



}

