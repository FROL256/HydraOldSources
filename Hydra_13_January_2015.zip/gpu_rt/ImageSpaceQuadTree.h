#pragma once

#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "IrradianceCache.h"

#include <vector>




class ImageSpaceQuadTree
{
public:

  ImageSpaceQuadTree();
  
  void SetThresholds(float a_scale, float a_thresholds[4]) { m_scale = a_scale; for(int i=0;i<4;i++ ) m_threshold[i] = a_thresholds[i]; }
  void SetConfig(int a_startBlockSize = 8, int a_minBlockSize = 1) { m_startBlockSize = a_startBlockSize; m_minBlockSize = a_minBlockSize; }

  void BuildFromImage(int a_width, int a_heigt, const std::vector<float3>& a_image, std::vector<bool>* a_pRecordSet);


  void BreadthFirstNextLevel(int a_width, int a_heigt, const std::vector<float3>& a_image, std::vector<bool>* a_pRecordSet);

protected:

  struct Edge
  {
    Edge(int a_x1, int a_y1, int a_x2, int a_y2) : x1(a_x1), x2(a_x2), y1(a_y1), y2(a_y2) {}

    int x1,y1;
    int x2,y2;
  };

  typedef Edge Region; // the same data structure for different thing
  
  enum NODE_TYPE_STATE {TYPE_S = 0, // Square 
                        TYPE_R = 1, //  Romb
                        TYPE_F = 0xFFFFFFFF};

  void ProcessRegion(int startX, int startY, int endX, int endY);
  void SubdivideQuadS(int startX, int startY, int endX, int endY);
  void SubdivideQuadR(int startX, int startY, int endX, int endY);

  float Difference(int x1, int y1, int x2, int y2);
  float MaxDifferenceLine(int x1, int y1, int x2, int y2);

  void InsertRecord(int x, int y);
  int  ThresholdIndex(int a_size);

  float m_scale;
  float m_threshold[4];
  int   m_startBlockSize;
  int   m_minBlockSize;

  const std::vector<float3>* m_pImage;
  std::vector<bool>*         m_pSet;

  int m_width;
  int m_height;

  std::vector<Region>        m_currQueue;
  std::vector<Region>        m_nextQueue;
  int                        m_currBlockSize;
};

