#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <windows.h>

#ifdef CERF_DLL_EXPORTS
  #define DLL_API __declspec(dllexport)
#else
  #define DLL_API __declspec(dllimport)
#endif

// Build Our Bitmap Font
void DLL_API glBuildFont();
void DLL_API glKillFont();
void DLL_API glPrint(const char *fmt, ...);