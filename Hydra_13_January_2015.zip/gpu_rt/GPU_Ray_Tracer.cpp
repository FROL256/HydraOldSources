// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include <GL/glew.h>

#include "../MegaTexture/MegaTexture/MegaTextureManager.h"

#include "GPU_Ray_Tracer.h"
#include "Fonts.h"

#include <map>
#include <string>

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

using std::map;
using std::string;

#include <sstream>

bool USE_PBO = true; 
bool USE_TBO = false;

#include "path_tracing.h"

///////////////////////////////////////////////////////////////////////////////////
////
GPU_Ray_Tracer::GPU_Ray_Tracer(int w, int h, int flags, int a_devId) : Ray_Tracer(w, h, flags)
{
  if(!(flags & GPU_RT_NOWINDOW))
  {
    CHECK_GL_ERRORS; 
    m_glRes.Init();
  }

  if (flags & GPU_RT_HW_LAYER_FRSDK)
    m_pHWLayer = CreateFRSDKImpl(width, height, flags);
  else if (flags & GPU_RT_HW_LAYER_OCL)
    m_pHWLayer = CreateOclImpl(width, height, flags, a_devId);
  else
    m_pHWLayer = CreateCudaImpl(width, height, flags);

  std::cerr << "[gpurt]:mem free  = " << int(double(m_pHWLayer->GetAvaliableMemoryAmount(true))/(1024.0*1024.0)) << " MB" << std::endl;

  m_rtOnlyVarDrawRaysStatInfo = false;

  // don't delete this comment please!
  //PrintMaterialParametersOffsets("hmat_offsets.h");


  m_drawLights = false;
  if(!(flags & GPU_RT_NOWINDOW))
  {
    m_pFullScreenQuad = new FullScreenQuad();

    // init OpenGL3/4 resources
    //
    if(USE_PBO)
      m_displayRTProg.InitFromString(RTE_GetShaderSource("quad_vs"), RTE_GetShaderSource("quad_ps"));
    else if(USE_TBO)
      m_displayRTProg.InitFromString(RTE_GetShaderSource("quad_vs"), RTE_GetShaderSource("quad_ps_tbo"));

    m_displayPointsProg.InitFromString(RTE_GetShaderSource("simple_vs"), RTE_GetShaderSource("color_ps"));
    m_displayPhotonsProg.InitFromString(RTE_GetShaderSource("photons_vs"), RTE_GetShaderSource("color_ps"));

    GLuint location = glGetAttribLocation(m_displayPointsProg.program, "vertex");

    glBindVertexArray(m_glRes.m_vaoPoints);                         CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_pointsPos);             CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(location);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(location, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;


    GLuint loc1 = glGetAttribLocation(m_displayPhotonsProg.program, "vertex");
    GLuint loc2 = glGetAttribLocation(m_displayPhotonsProg.program, "vcolor");

    // diffuse photons
    //
    glBindVertexArray(m_glRes.m_vaoPhotons);                    CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsPos);        CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(loc1);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(loc1, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsCol);        CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(loc2);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(loc2, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

    // caustic photons
    //
    glBindVertexArray(m_glRes.m_vaoPhotonsCaustic);             CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsCausticPos); CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(loc1);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(loc1, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsCausticCol); CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(loc2);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(loc2, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;


    // dl photons
    //
    glBindVertexArray(m_glRes.m_vaoPhotonsDL);                  CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsDLPos);      CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(loc1);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(loc1, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsDLCol);      CHECK_GL_ERRORS;     
    glEnableVertexAttribArray(loc2);                            CHECK_GL_ERRORS;
    glVertexAttribPointer(loc2, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

    glBindBuffer(GL_ARRAY_BUFFER, 0);  
    glBindVertexArray(0);

    InitPBO(&m_glRes.m_screenBuffer);
  }
  else
    m_pFullScreenQuad = NULL;


  AllRenderVarialbes state = m_pHWLayer->GetAllFlagsAndVars();
  
  state.SetVariableI(HRT_MEASURE_RAYS_TYPE, 0);
  
  m_pHWLayer->SetAllFlagsAndVars(state);

}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::SetWindowResolution(int a_width, int a_height)
{
  m_windowWasResized = false;

  if(width == a_width && height == a_height)
    return;

  int widthClamped  = a_width;
  int heightClamped = a_height;

  if(widthClamped % 16 != 0 || heightClamped%16 != 0)
  {
    widthClamped  = 16*(a_width/16);  // + (16 - a_width%16);
    heightClamped = 16*(a_height/16); // + (16 - a_height%16);
  }

  if(width == widthClamped && height == heightClamped)
    return;

  width  = widthClamped;
  height = heightClamped;

  m_pHWLayer->ResizeScreen(width, height, 0);

  if(!(m_initFlags & GPU_RT_NOWINDOW))
  {
    m_pHWLayer->UnregisterOutputGLBuffer();

    if(USE_PBO)
    {
      glBindTexture (GL_TEXTURE_2D, m_screenTexture);                                              CHECK_GL_ERRORS;
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);  CHECK_GL_ERRORS;

      glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_glRes.m_screenBuffer);                              CHECK_GL_ERRORS;
      glBufferData(GL_PIXEL_UNPACK_BUFFER, width*height*sizeof(int), NULL, GL_DYNAMIC_COPY);     CHECK_GL_ERRORS;
      glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
    }
    else if(USE_TBO)
    {
      glBindBuffer(GL_TEXTURE_BUFFER, m_glRes.m_screenBuffer);                          CHECK_GL_ERRORS;
      glBufferData(GL_TEXTURE_BUFFER, width*height*sizeof(int), NULL, GL_STATIC_DRAW);  CHECK_GL_ERRORS;

      glBindTexture(GL_TEXTURE_BUFFER, m_screenTexture);                                CHECK_GL_ERRORS;
      glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA8, m_glRes.m_screenBuffer);                 CHECK_GL_ERRORS;

      glBindTexture(GL_TEXTURE_BUFFER, 0);
      glBindBuffer(GL_TEXTURE_BUFFER, 0);
    }

    m_pHWLayer->RegisterOutputGLBuffer(m_glRes.m_screenBuffer);
  }

  m_windowWasResized = true;

}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::InitPBO(GLuint* a_pBuffer)
{
  GLuint& pixelBuffer = *a_pBuffer;

  if(glBindBuffer == NULL)
  {
    GLenum err=glewInit();
    if(err!=GLEW_OK)
    {
      fprintf(stderr, "glewInitError: %s\n", glewGetErrorString(err));
      RUN_TIME_ERROR("glewInit() failed");
    }
  }

  if(USE_PBO)
  {
    glGenTextures(1,&m_screenTexture);  CHECK_GL_ERRORS;
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);  CHECK_GL_ERRORS;
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);  CHECK_GL_ERRORS;

    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);        CHECK_GL_ERRORS;
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);        CHECK_GL_ERRORS;
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);  CHECK_GL_ERRORS;
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);  CHECK_GL_ERRORS;
    // \\ end init texture

    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, pixelBuffer);                                       CHECK_GL_ERRORS;
    glBufferData(GL_PIXEL_UNPACK_BUFFER, width * height*sizeof(int), NULL, GL_DYNAMIC_COPY); CHECK_GL_ERRORS;
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
  }
  else if(USE_TBO)
  {
    std::vector<uint> testData(width*height);
    for(int i=0;i<width*height;i++)
      testData[i] = 0xFFFFFFFF;

    // tbo
    //
    glBindBuffer(GL_TEXTURE_BUFFER, pixelBuffer);                                             CHECK_GL_ERRORS;
    glBufferData(GL_TEXTURE_BUFFER, width*height*sizeof(int), &testData[0], GL_STATIC_DRAW);  CHECK_GL_ERRORS;
    glBindBuffer(GL_TEXTURE_BUFFER, 0);

    glGenTextures(1, &m_screenTexture);                                               CHECK_GL_ERRORS;
    glBindTexture(GL_TEXTURE_BUFFER, m_screenTexture);                                CHECK_GL_ERRORS;
    glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA8, pixelBuffer);                            CHECK_GL_ERRORS;
    glBindTexture(GL_TEXTURE_BUFFER, 0);	                                            CHECK_GL_ERRORS;

  }

  m_pHWLayer->RegisterOutputGLBuffer(pixelBuffer);
}

///////////////////////////////////////////////////////////////////////////////////
////
GPU_Ray_Tracer::~GPU_Ray_Tracer()
{
  delete m_pFullScreenQuad; m_pFullScreenQuad = NULL;

  if((USE_PBO || USE_TBO) && !(m_initFlags & GPU_RT_NOWINDOW))
    glDeleteTextures(1, &m_screenTexture);
  
  delete m_pHWLayer; m_pHWLayer = NULL;
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::BeginDrawScene(RenderSettings a_renderState)
{
  if (m_lights.size() == 0)
    RUN_TIME_ERROR("BeginDrawScene(): No lights were addeed to the scene!");

  m_pHWLayer->ResetPerfCounters();

  m_rtOnlyVarDrawRaysStatInfo = a_renderState.GetEnableRaysCounter();
  m_lastRenderState           = a_renderState;

	UpdateComplete();

  AllRenderVarialbes state = m_pHWLayer->GetAllFlagsAndVars();
  
  state.SetFlags(HRT_USE_RANDOM_RAYS, 0);
  state.SetFlags(HRT_COMPUTE_SHADOWS, a_renderState.GetShadow());
  state.SetFlags(HRT_DIFFUSE_REFLECTION, a_renderState.GetIndirrectIllumination());
  state.SetFlags(HRT_COMPUTE_IRRADIANCE_CACHE | HRT_IRRDAIANCE_CACHE_FIND_SECONDARY, 0);
  state.SetFlags(HRT_FINAL_GARTHER, a_renderState.GetEnableFG());
  state.SetFlags(HRT_GARTHER_CAUSTICS, a_renderState.GetEnableCG());
  state.SetFlags(HRT_ENABLE_PT_CAUSTICS, a_renderState.ptCaustics);

  state.SetVariableI(HRT_TRACE_DEPTH, a_renderState.GetTraceDepth());
  state.SetVariableI(HRT_DIFFUSE_TRACE_DEPTH, a_renderState.GetDiffuseTraceDepth());
  state.SetVariableF(HRT_IMAGE_GAMMA, a_renderState.GetGamma());
  state.SetVariableF(HRT_TEXINPUT_GAMMA, a_renderState.GetGammaTex());
  state.SetVariableF(HRT_TRACE_PROCEEDINGS_TRESHOLD, a_renderState.GetTraceProceedingsTreshold());
  state.SetVariableF(HRT_CAUSTIC_POWER_MULT, a_renderState.causticPower);
  state.SetVariableF(HRT_CAM_FOV, m_projParams.x);

  state.SetVariableI(HRT_DEBUG_DRAW_LAYER, m_ivars["g_debugLayerDraw"]);
  state.SetVariableI(HRT_ENABLE_MRAYS_COUNTERS, int(a_renderState.GetEnableRaysCounter()));
  state.SetVariableI(HRT_PHOTONS_GARTHER_BOUNCE, a_renderState.GetGartherBounce());
  state.SetVariableI(HRT_PHOTONS_STORE_BOUNCE, a_renderState.GetStoreBounce());
  state.SetVariableI(HRT_DEBUG_OUTPUT, m_debugOutput);

  m_pHWLayer->SetAllFlagsAndVars(state);

  m_pHWLayer->BeginTracingPass(); // may do some code in parallel between begin/end pass

  m_pHWLayer->EndTracingPass();
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::CopyResultToGLBuffer()
{
  m_pHWLayer->GetLDRImageToGL(m_glRes.m_screenBuffer);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::EndDrawScene()
{
  if(m_initFlags & GPU_RT_NOWINDOW)
    return;

  glViewport(0,0,width,height);

  glDisable(GL_DEPTH_TEST);  CHECK_GL_ERRORS;  
  glDisable(GL_CULL_FACE);   CHECK_GL_ERRORS;  

  this->CopyResultToGLBuffer();

  if(USE_PBO)
  {
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);               CHECK_GL_ERRORS;  
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_glRes.m_screenBuffer); CHECK_GL_ERRORS;  
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, (GLvoid*)0); CHECK_GL_ERRORS;    // copy color from PBO to texture
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);                      CHECK_GL_ERRORS;  
  }

  glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

  int2 im_size(width, height);

  glUseProgram(m_displayRTProg.program);  CHECK_GL_ERRORS; 
  setUniform(m_displayRTProg.program, "im_size", im_size); // glProgramUniformEXT (?)
  
  if(USE_PBO)
    bindTexture(m_displayRTProg.program, 0, "screenBufferTex", m_screenTexture);
  else if(USE_TBO)
    bindTextureBuffer(m_displayRTProg.program, 0, "tboSampler", m_screenTexture);

  m_pFullScreenQuad->Draw();

  glUseProgram(0);
  glBindTexture(GL_TEXTURE_BUFFER, 0);

  glClear(GL_DEPTH_BUFFER_BIT);  

  if(m_ivars["drawIrradianceCachePixelPoints"] == 1)
    DrawICRecords();
  else
    FreeICRecordsBuffer();

  if(m_ivars["drawPhotons"] == 1)
    DrawPhotons("diffuse");
  else
    FreeGLPhotonsData("diffuse");

  if(m_ivars["drawPhotonsCaustic"] == 1)
    DrawPhotons("caustic");
  else
    FreeGLPhotonsData("caustic");

  if(m_ivars["pmdlDraw"] == 1)
    DrawPhotons("directlight");
  else
    FreeGLPhotonsData("directlight");

  // draw text
  //
  if(m_rtOnlyVarDrawRaysStatInfo && gl_ver <= 3.1)
  {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,width,0,height, -1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glClear(GL_DEPTH_BUFFER_BIT);

    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glColor3f(1,1,0);
    glPushAttrib(GL_CURRENT_RASTER_POSITION);

    MRaysStat raysStat = m_pHWLayer->GetRaysStat();
    
    int mrays    = (int)(raysStat.raysPerSec*1e-6f + 0.5f);
    float startY = height - 40;

    glRasterPos2f(10, startY-0);
    glPrint("M(Rays)/sec   : %d", mrays);
    
    glRasterPos2f(10, startY-20);
    glPrint("M(Samples)/sec: %f", raysStat.samplesPerSec*1e-6f);

    glRasterPos2f(10, startY-40);
    glPrint("Shadow    (ms): %2.2f", raysStat.shadowTimeMs);

    glRasterPos2f(10, startY-60);
    glPrint("Traversal ( %%): %d", raysStat.traceTimePerCent);

    glRasterPos2f(10, startY-80);
    glPrint("Traversal (ms): %2.2f", raysStat.traversalTimeMs);

    glRasterPos2f(10, startY-100);
    glPrint("FullBounce(ms): %2.2f", raysStat.bounceTimeMS);

    glRasterPos2f(10, startY-120);
    glPrint("SampleTime(ms): %2.2f", raysStat.sampleTimeMS);

    glRasterPos2f(10, startY-140);
    glPrint("ReordTime (ms): %2.2f", raysStat.reorderTimeMs);

    glPopAttrib();
    glEnable(GL_TEXTURE_2D);
  }

  // just draw lights with OpenGL 
  //
  if(m_drawLights && gl_ver <= 3.1) // TODO: if nothing to do, port drawing point and directional lights to GL ? for what reason ??
  {
    glClearDepth(1.0f);									
    glDepthFunc(GL_LEQUAL);
    glClear(GL_DEPTH_BUFFER_BIT);

    Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
    Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);
    float z_near  = 0.1f;
    float z_far   = 1e5f;

    glMatrixMode(GL_PROJECTION);
    glLoadMatrixf(m_projectionMatrixData);

    glMatrixMode(GL_MODELVIEW);
    glLoadMatrixf(m_worldViewMatrixData);

    Base::DrawLights();
  }

}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::GetLDRImage(uint* data) const
{
  m_pHWLayer->GetLDRImage(data, width, height);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::GetHDRImage(float4* data) const
{
  m_pHWLayer->GetHDRImage(data, width, height);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::UpdateComplete()
{  
  if(m_dirtyLights && m_lights.size() > 0)
  {
    BuildLightIdTransformTable(m_lights);
    UpdateLightsOnHWLayer(m_lights);
    m_dirtyLights = false;
  }
	
  if(m_dirtyHydraMaterials && m_hydraMaterials.size() > 0)
  {
    UpdateMaterialsOnHWLayer(m_hydraMaterials);

    CUDAHWLayer* pImpl = dynamic_cast<CUDAHWLayer*>(m_pHWLayer);

    if (pImpl != NULL)
      hrtSetHydraMaterials(&m_hydraMaterials[0], int(m_hydraMaterials.size()));

    m_dirtyHydraMaterials = false;
  }

  Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
  Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);

  Matrix4x4f mProjInverse      = SafeInverse(mProj).GetTranspose();
  Matrix4x4f mWorldViewInverse = SafeInverse(mWorldView).GetTranspose();

  m_pHWLayer->SetCamMatrices((float*)&mProjInverse, (float*)&mWorldViewInverse);
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::LoadStaticDataToGPU()
{
  if(!m_dataVerifyed)
    VerifyAllData();

  if(m_index.size() > 0)
  {
    InputGeom geom;

    geom.vertPos      = &m_vertPos[0];
    geom.vertNorm     = &m_vertNorm[0];
    geom.vertTexCoord = &m_vertTexCoord[0];
    geom.vertTangent  = NULL;
    geom.vertNum      = m_vertPos.size();

    geom.indices         = &m_index[0];
    geom.materialIndices = &m_triangleMaterialId[0];
    geom.numIndices      = m_index.size();

    m_pHWLayer->SetGeom(geom);
  }

  if(m_spheres.size() > 0)
    hrtSetSpheres(&m_spheres[0], int(m_spheres.size()));

  BuildLightIdTransformTable(m_lights);

  CreateMegaTextures();

  if(m_lights.size() > 0)
    UpdateLightsOnHWLayer(m_lights);
  else
    std::cerr << "[gpurt] warning: lights were not set" <<std::endl;

  // free memory
  //
  m_images = std::vector<ImageStorage>();

  m_vertNorm     = std::vector<float4>();
  m_vertTangent  = std::vector<float4>();
  m_vertTexCoord = std::vector<float2>();

  // free this later
  //
  //m_index  = std::vector<uint>();
  //m_vertPos = std::vector<float4>();
  //m_spheres = std::vector<Sphere4f>();
  //m_triangleMaterialId = std::vector<int>();
}

struct BVHInfo
{
  uint bvhNodes;
  uint primListArraySize;
  uint primListIndexSize;
  uint dummy;

};

bool GPU_Ray_Tracer::LoadBVHCache(const std::string& a_path, const std::string& a_geomMD5, const std::string& a_lightsMD5)
{
  std::string hashInfoFile  = a_path + "bvhhash.txt";
  std::string cacheDataFile = a_path + "bvhcache.bin";

  std::ifstream hashFile(hashInfoFile.c_str());
  if(!hashFile.is_open())
    return false;

  char temp[1024];

  hashFile >> temp;
  if(std::string(temp) != a_geomMD5)
    return false;

  hashFile >> temp;
  if(std::string(temp) != a_lightsMD5)
    return false;

  hashFile.close();

  
  std::ifstream cacheData(cacheDataFile.c_str(), std::ios::binary);
  if(!cacheData.is_open())
    return false;

  BVHInfo info;
  cacheData.read((char*)&info, sizeof(info));
  cacheData.read((char*)&m_bBox, sizeof(MGML::AABB3f));

  BVHNodeT* nodes     = new BVHNodeT[info.bvhNodes];
  char*     plistData = new char   [info.primListArraySize];

  cacheData.read((char*)nodes, info.bvhNodes*sizeof(BVHNodeT));
  cacheData.read((char*)plistData, info.primListArraySize);

  InputGeomBVH bvhInput;

  bvhInput.nodes               = nodes;
  bvhInput.numNodes            = info.bvhNodes;
  bvhInput.primListData        = plistData;
  bvhInput.primListSizeInBytes = info.primListArraySize;
  bvhInput.triNumInList        = info.primListIndexSize;

  m_pHWLayer->SetBVH(bvhInput);

  delete [] nodes;
  delete [] plistData;

  std::cout << "[BVHCache] : LoadBVHCache from " << cacheDataFile.c_str() << std::endl;

  return true;
}

void GPU_Ray_Tracer::UpdateBVHCache(const std::string& a_path, const std::string& a_geomMD5, const std::string& a_lightsMD5)
{
  std::string hashInfoFile  = a_path + "bvhhash.txt";
  std::string cacheDataFile = a_path + "bvhcache.bin";

  std::ofstream hashFile(hashInfoFile.c_str(), std::ios::trunc);
  if(!hashFile.is_open())
  {
    std::cerr << "[BVHCacheUpdate]: can't open " << hashInfoFile.c_str() << std::endl;
    return;
  }

  hashFile << a_geomMD5   << std::endl;
  hashFile << a_lightsMD5 << std::endl;

  hashFile.close();

  std::ofstream cacheData(cacheDataFile.c_str(), std::ios::binary | std::ios::trunc);
  if(!cacheData.is_open())
  {
    std::cerr << "[BVHCacheUpdate]: can't open " << cacheDataFile.c_str() << std::endl;
    return;
  }

  BVHInfo info;
  info.bvhNodes          = m_bvhGlobal.nodes.size();    // m_pBVHBuilder->GetBVHArraySize();
  info.primListArraySize = m_bvhObjListData.size();     // m_pBVHBuilder->GetPrimitiveListsArraySize();
  info.primListIndexSize = m_bvhGlobal.indices.size();  // total tri num in tri list
  info.dummy             = 0xFAFAFAFA;

  m_bBox.vmin = m_bvhGlobal.boxMin;
  m_bBox.vmax = m_bvhGlobal.boxMax;

  cacheData.write((const char*)&info, sizeof(info));
  cacheData.write((const char*)&m_bBox, sizeof(MGML::AABB3f));

  cacheData.write((const char*)&m_bvhGlobal.nodes[0], info.bvhNodes*sizeof(BVHNode));
  cacheData.write((const char*)&m_bvhObjListData[0],  info.primListArraySize);

  cacheData.close();

  std::cerr << "[BVHCacheUpdate]: updated at " << cacheDataFile.c_str() << std::endl;
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::BuildAccelerationStructures(const std::string& a_geomMD5, const std::string& a_lightsMD5)
{
  LoadStaticDataToGPU();

  bool loadedFromCache = LoadBVHCache("C:\\[Hydra]\\pluginFiles\\", a_geomMD5, a_lightsMD5);

  if(!loadedFromCache)
  //if(true)
  {
    Base::BuildAccelerationStructures("", "");

    m_triangleMaterialId = std::vector<uint>();   // free unnecesary data

    InputGeomBVH bvhInput;

    bvhInput.nodes               = &m_bvhGlobal.nodes[0];
    bvhInput.numNodes            = m_bvhGlobal.nodes.size();
    
    bvhInput.primListData        = &m_bvhObjListData[0];       // m_pBVHBuilder->GetPrimitiveListsArray();
    bvhInput.primListSizeInBytes = m_bvhObjListData.size();    // m_pBVHBuilder->GetPrimitiveListsArraySize();
    bvhInput.triNumInList        = m_bvhGlobal.indices.size();

    m_pHWLayer->SetBVH(bvhInput);

    UpdateBVHCache("C:\\[Hydra]\\pluginFiles\\", a_geomMD5, a_lightsMD5);
  }
  else
    m_triangleMaterialId = std::vector<uint>(); // free unnecesary data

  delete m_pBVHBuilder;
  m_pBVHBuilder = NULL;

  // free memory used by bvh builder
  //
  m_bvhGlobal.freeMem();
  m_bvhObjListData = std::vector<char>();

  //
  //
  std::cerr << "[gpurt]: mem free = " << int(double(m_pHWLayer->GetAvaliableMemoryAmount(true)) / (1024.0*1024.0)) << " MB" << std::endl;

  // calc regular AABB
  //
  float3 boxSize   = m_bBox.vmax - m_bBox.vmin;
  float maxBoxSize = ::fmaxf(boxSize.x, ::fmaxf(boxSize.y, boxSize.z));

  m_regularBBox.vmin = m_bBox.center() - float3(maxBoxSize,maxBoxSize,maxBoxSize);
  m_regularBBox.vmax = m_bBox.center() + float3(maxBoxSize,maxBoxSize,maxBoxSize);
 
  CUDAHWLayer* pImpl = dynamic_cast<CUDAHWLayer*>(m_pHWLayer);

  if (pImpl != NULL)
  {
    hrtSetRegularBBox(m_regularBBox.vmin, m_regularBBox.vmax);
    sga_cudaMemcpyToSymbol("g_sceneBoundingSphereDiameter", (void*)&maxBoxSize, sizeof(float));
  }

  // free geometry and other data
  //
  m_index    = std::vector<uint>();
  m_vertPos  = std::vector<float4>();
  m_spheres  = std::vector<Sphere4f>();
 

  std::cerr << "[gpurt]: loading megatextures to GPU ..." << std::endl;
  LoadDefferedMegaTexturesToGPU();

  m_pHWLayer->SetAllTextureMatrices((float*)&m_texMatrices[0], m_texMatrices.size()*16);

  std::cerr << "[gpurt]: mem free = " << int(double(m_pHWLayer->GetAvaliableMemoryAmount(true)) / (1024.0*1024.0)) << " MB" << std::endl;
}


uint GPU_Ray_Tracer::AddLight(const RAYTR::Light& a_light)
{
  RAYTR::Light light = a_light;
  
  AABB3f box;

  if(a_light.m_type == RAYTR::Light::LIGHT_TYPE_MESH)
  {
    std::vector<float4>  positions; // tri positions
    std::vector<float2>  texcoords; // vert texture coordinates
    std::vector<float2>  intervals; // probability intervals
    std::vector<float>   areas;

    positions.reserve(1000);
    texcoords.reserve(1000);

    int matId = a_light.matId;
    std::vector<int>& indexList = m_lightMeshIdListByMatId[matId];

    for(size_t i=0;i<indexList.size();i++)
    {
      int index  = indexList[i];
      int A_offs = this->m_index[3*index+0];
      int B_offs = this->m_index[3*index+1];
      int C_offs = this->m_index[3*index+2];

      positions.push_back(GetVertexPos(A_offs));
      positions.push_back(GetVertexPos(B_offs));
      positions.push_back(GetVertexPos(C_offs));

      texcoords.push_back(GetVertexTexCoord(A_offs));
      texcoords.push_back(GetVertexTexCoord(B_offs));
      texcoords.push_back(GetVertexTexCoord(C_offs));
    }

    if ((positions.size() / 3) % 2 == 0)
    {/*
      size_t last = positions.size() - 1;
      float4 A = positions[last - 2];
      float4 B = positions[last - 1];
      float4 C = positions[last - 0];

      float2 tA = texcoords[last - 2];
      float2 tB = texcoords[last - 1];
      float2 tC = texcoords[last - 0];

      positions.push_back(A);
      positions.push_back(B);
      positions.push_back(C);

      texcoords.push_back(tA);
      texcoords.push_back(tB);
      texcoords.push_back(tC);
      */

      /*
      positions.pop_back();
      positions.pop_back();
      positions.pop_back();

      texcoords.pop_back();
      texcoords.pop_back();
      texcoords.pop_back();
      */
    }

    intervals.resize(positions.size()/3);
    areas.resize(positions.size()/3);

    bool planeLight = true;
    float3 normal0 = normalize(cross(to_float3(positions[1]) - to_float3(positions[0]), 
                                     to_float3(positions[2]) - to_float3(positions[0])));
    double areaSumm = 0.0f;
    for(int i=0;i<areas.size();i++)
    {
      float3 A = to_float3(positions[i*3+0]);
      float3 B = to_float3(positions[i*3+1]);
      float3 C = to_float3(positions[i*3+2]);

      box.include(A);
      box.include(B);
      box.include(C);
    
      float3 normal = normalize(cross(B-A, C-A));
      if(dot(normal, normal0) < 0.99f)
        planeLight = false;

      areas[i] = float(areaSumm);
      areaSumm += double( 0.5f*length(cross(B-A,C-A)) );
    }
   
    float invSumm = 1.0f/float(areaSumm);
    for(int i=0;i<areas.size();i++)
      areas[i] *= invSumm;

    for(int i=0;i<intervals.size()-1;i++)
    {
      intervals[i].x = areas[i];
      intervals[i].y = areas[i+1];
    }

    int last = intervals.size()-1;
    intervals[last].x = areas[last];
    intervals[last].y = 1.0f;
    
    LightMeshData lmesh;

    lmesh.positions = &positions[0];
    lmesh.texCoords = &texcoords[0];
    lmesh.intervals = &intervals[0];
    lmesh.size = intervals.size();

    light.lightMeshIndex = m_pHWLayer->AddLightMesh(lmesh);
    light.pos = box.center();
    light.surfaceArea = areaSumm;
  }

  return Base::AddLight(light);
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::PrintStatInfo(std::ostream& out)
{
  std::cout << "path tracing statistics: " << std::endl;
  std::cout << "avg rays per pixel = " << m_avgRaysPerPixel << std::endl;
}


//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::RT_Core* GPU_Ray_Tracer::GetRTCore()
{
	return &m_core;
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::PrintMaterialParametersOffsets(const string& a_fileName)
{
  static const HydraMaterial gtm_offsets;
  static const float* gtm_pStart = (const float*)&gtm_offsets;
  
  #undef HMAT_AMBIENT_COLOR_X_OFFSET
  #undef HMAT_AMBIENT_COLOR_Y_OFFSET
  #undef HMAT_AMBIENT_COLOR_Z_OFFSET
  #undef HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET
  #undef HMAT_AMBIENT_LIGHT_ID_OFFSET
  #undef HMAT_DIFFUSE_COLOR_X_OFFSET
  #undef HMAT_DIFFUSE_COLOR_Y_OFFSET
  #undef HMAT_DIFFUSE_COLOR_Z_OFFSET
  #undef HMAT_SPECULAR_COLOR_X_OFFSET
  #undef HMAT_SPECULAR_COLOR_Y_OFFSET
  #undef HMAT_SPECULAR_COLOR_Z_OFFSET
  #undef HMAT_SPECULAR_POWER_OFFSET
  #undef HMAT_SPECULAR_BRDF_ID_OFFSET
  #undef HMAT_SPECULAR_GLOSINESS_OFFSET
  #undef HMAT_SPECULAR_FRESNEL_IOR_OFFSET
  #undef HMAT_REFLECTION_COLOR_X_OFFSET
  #undef HMAT_REFLECTION_COLOR_Y_OFFSET
  #undef HMAT_REFLECTION_COLOR_Z_OFFSET
  #undef HMAT_REFLECTION_POWER_OFFSET
  #undef HMAT_REFLECTION_BRDF_ID_OFFSET
  #undef HMAT_REFLECTION_GLOSINESS_OFFSET
  #undef HMAT_REFLECTION_FRESNEL_IOR_OFFSET
  #undef HMAT_REFRACTION_COLOR_X_OFFSET
  #undef HMAT_REFRACTION_COLOR_Y_OFFSET
  #undef HMAT_REFRACTION_COLOR_Z_OFFSET
  #undef HMAT_REFRACTION_FOG_COLOR_X_OFFSET
  #undef HMAT_REFRACTION_FOG_COLOR_Y_OFFSET
  #undef HMAT_REFRACTION_FOG_COLOR_Z_OFFSET
  #undef HMAT_REFRACTION_FOG_MULT_OFFSET
  #undef HMAT_REFRACTION_EXIT_COLOR_X_OFFSET
  #undef HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET
  #undef HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET
  #undef HMAT_REFRACTION_GLOSSINESS_OFFSET
  #undef HMAT_REFRACTION_IOR_OFFSET
  #undef HMAT_DISPLACEMENT_HEIGHT_OFFSET
  #undef HMAT_FLAGS_OFFSET
  #undef HMAT_AMBIENT_COLOR_TEX_ID_OFFSET
  #undef HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET
  #undef HMAT_SPECULAR_COLOR_TEX_ID_OFFSET
  #undef HMAT_REFLECTION_COLOR_TEX_ID_OFFSET
  #undef HMAT_REFRACTION_COLOR_TEX_ID_OFFSET
  #undef HMAT_REFRACTION_IOR_TEX_ID_OFFSET
  #undef HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET
  #undef HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET
  #undef HMAT_EMISSION_TEX_MAXTRIX_ID
  #undef HMAT_DIFFUSE_TEX_MAXTRIX_ID
  #undef HMAT_SPECULAR_TEX_MAXTRIX_ID
  #undef HMAT_REFLECTION_TEX_MAXTRIX_ID
  #undef HMAT_TRANSPARENCY_TEX_MAXTRIX_ID
  #undef HMAT_DISPLACEMENT_TEX_MAXTRIX_ID
  #undef HMAT_NORMALMAP_TEX_MAXTRIX_ID

  #undef HMAT_SPECULAR_GLOSS_TEX_ID_OFFSET
  #undef HMAT_REFLECTION_GLOSS_TEX_ID_OFFSET
  #undef HMAT_SPECULAR_GLOSS_TEX_MATRIX_ID_OFFSET
  #undef HMAT_REFLECTION_GLOSS_TEX_MATRIX_ID_OFFSET

  #undef HMAT_TRANSPARENCY_OPACITY_TEX_ID
  #undef HMAT_TRANSPARENCY_OPACITY_TEX_MATRIX_ID

  ////////////////////////////////////////////////
  #undef HMAT_TRANSLUCENT_COLOR
  #undef HMAT_TRANSLUCENT_DIFFUSION

  #undef HMAT_TRANSLUCENT_COLOR_TEX_ID
  #undef HMAT_TRANSLUCENT_COLOR_TEX_MATRIX_ID

  #undef HMAT_TRANSLUCENT_DIFFUSION_TEX_ID
  #undef HMAT_TRANSLUCENT_DIFFUSION_TEX_MATRIX_ID

  #undef HMAT_TRANSLUCENT_DIFF_RADIUS

  const int HMAT_AMBIENT_COLOR_X_OFFSET = &gtm_offsets.ambient.color.x - gtm_pStart;
  const int HMAT_AMBIENT_COLOR_Y_OFFSET = &gtm_offsets.ambient.color.y - gtm_pStart;
  const int HMAT_AMBIENT_COLOR_Z_OFFSET = &gtm_offsets.ambient.color.z - gtm_pStart;
  const int HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET = &gtm_offsets.ambient.light_multiplyer - gtm_pStart;
  const int HMAT_AMBIENT_LIGHT_ID_OFFSET = &gtm_offsets.ambient.light_id - (const int*)gtm_pStart;

  const int HMAT_DIFFUSE_COLOR_X_OFFSET  = &gtm_offsets.diffuse.color.x - gtm_pStart;
  const int HMAT_DIFFUSE_COLOR_Y_OFFSET  = &gtm_offsets.diffuse.color.y - gtm_pStart;
  const int HMAT_DIFFUSE_COLOR_Z_OFFSET  = &gtm_offsets.diffuse.color.z - gtm_pStart;

  const int HMAT_SPECULAR_COLOR_X_OFFSET     = &gtm_offsets.specular.color.x - gtm_pStart;
  const int HMAT_SPECULAR_COLOR_Y_OFFSET     = &gtm_offsets.specular.color.y - gtm_pStart;
  const int HMAT_SPECULAR_COLOR_Z_OFFSET     = &gtm_offsets.specular.color.z - gtm_pStart;
  const int HMAT_SPECULAR_POWER_OFFSET       = &gtm_offsets.specular.cosPower- gtm_pStart;

  const int HMAT_SPECULAR_FRESNEL_IOR_OFFSET = &gtm_offsets.specular.fresnelIOR - gtm_pStart;
  const int HMAT_SPECULAR_BRDF_ID_OFFSET     = &gtm_offsets.specular.brdf_id - (const int*)gtm_pStart;
  const int HMAT_SPECULAR_GLOSINESS_OFFSET   = &gtm_offsets.reflection.glosiness - gtm_pStart;

  const int HMAT_REFLECTION_COLOR_X_OFFSET     = &gtm_offsets.reflection.color.x - gtm_pStart;
  const int HMAT_REFLECTION_COLOR_Y_OFFSET     = &gtm_offsets.reflection.color.y - gtm_pStart;
  const int HMAT_REFLECTION_COLOR_Z_OFFSET     = &gtm_offsets.reflection.color.z - gtm_pStart;
  const int HMAT_REFLECTION_POWER_OFFSET       = &gtm_offsets.reflection.cosPower- gtm_pStart;
  const int HMAT_REFLECTION_BRDF_ID_OFFSET     = &gtm_offsets.reflection.brdf_id - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_GLOSINESS_OFFSET   = &gtm_offsets.reflection.glosiness - gtm_pStart;
  const int HMAT_REFLECTION_FRESNEL_IOR_OFFSET = &gtm_offsets.reflection.fresnelIOR - gtm_pStart;


  const int HMAT_REFRACTION_COLOR_X_OFFSET      = &gtm_offsets.transparency.color.x - gtm_pStart;
  const int HMAT_REFRACTION_COLOR_Y_OFFSET      = &gtm_offsets.transparency.color.y - gtm_pStart;
  const int HMAT_REFRACTION_COLOR_Z_OFFSET      = &gtm_offsets.transparency.color.z - gtm_pStart;
  const int HMAT_REFRACTION_FOG_COLOR_X_OFFSET  = &gtm_offsets.transparency.fogColor.x - gtm_pStart;
  const int HMAT_REFRACTION_FOG_COLOR_Y_OFFSET  = &gtm_offsets.transparency.fogColor.y - gtm_pStart;
  const int HMAT_REFRACTION_FOG_COLOR_Z_OFFSET  = &gtm_offsets.transparency.fogColor.z - gtm_pStart;
  const int HMAT_REFRACTION_FOG_MULT_OFFSET     = &gtm_offsets.transparency.fogMultiplyer - gtm_pStart;
  const int HMAT_REFRACTION_EXIT_COLOR_X_OFFSET = &gtm_offsets.transparency.exitColor.x - gtm_pStart;
  const int HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET = &gtm_offsets.transparency.exitColor.y - gtm_pStart;
  const int HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET = &gtm_offsets.transparency.exitColor.z - gtm_pStart;
  const int HMAT_REFRACTION_GLOSSINESS_OFFSET   = &gtm_offsets.transparency.glossiness - gtm_pStart;
  const int HMAT_REFRACTION_IOR_OFFSET          = &gtm_offsets.transparency.IOR - gtm_pStart;

  const int HMAT_DISPLACEMENT_HEIGHT_OFFSET    = &gtm_offsets.displacement.height - gtm_pStart;

  const int HMAT_FLAGS_OFFSET                  = &gtm_offsets.flags - (const int*)gtm_pStart;


  const int HMAT_AMBIENT_COLOR_TEX_ID_OFFSET    = &gtm_offsets.ambient.color_texId  - (const int*)gtm_pStart;
  const int HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET    = &gtm_offsets.diffuse.color_texId  - (const int*)gtm_pStart;
  const int HMAT_SPECULAR_COLOR_TEX_ID_OFFSET   = &gtm_offsets.specular.color_texId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_COLOR_TEX_ID_OFFSET = &gtm_offsets.reflection.color_texId - (const int*)gtm_pStart;

  const int HMAT_REFRACTION_COLOR_TEX_ID_OFFSET = &gtm_offsets.transparency.color_texId - (const int*)gtm_pStart;
  const int HMAT_REFRACTION_IOR_TEX_ID_OFFSET   = &gtm_offsets.transparency.IOR_texId - (const int*)gtm_pStart;

  const int HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET = &gtm_offsets.displacement.normals_texId - (const int*)gtm_pStart;
  const int HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET  = &gtm_offsets.displacement.height_texId - (const int*)gtm_pStart;

  const int HMAT_SPECULAR_GLOSS_TEX_ID_OFFSET       = &gtm_offsets.specular.gloss_texId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_GLOSS_TEX_ID_OFFSET     = &gtm_offsets.reflection.gloss_texId - (const int*)gtm_pStart;

  const int HMAT_EMISSION_TEX_MAXTRIX_ID     =  &gtm_offsets.ambient.color_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_DIFFUSE_TEX_MAXTRIX_ID      =  &gtm_offsets.diffuse.color_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_SPECULAR_TEX_MAXTRIX_ID     =  &gtm_offsets.specular.color_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_TEX_MAXTRIX_ID   =  &gtm_offsets.reflection.color_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_TRANSPARENCY_TEX_MAXTRIX_ID =  &gtm_offsets.transparency.color_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_DISPLACEMENT_TEX_MAXTRIX_ID =  &gtm_offsets.displacement.height_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_NORMALMAP_TEX_MAXTRIX_ID    =  &gtm_offsets.displacement.normals_texMatrixId - (const int*)gtm_pStart;

  const int HMAT_SPECULAR_GLOSS_TEX_MATRIX_ID_OFFSET  = &gtm_offsets.specular.gloss_texMatrixId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_GLOSS_TEX_MATRIX_ID_OFFSET= &gtm_offsets.reflection.gloss_texMatrixId - (const int*)gtm_pStart;

  const int HMAT_TRANSPARENCY_OPACITY_TEX_ID = &gtm_offsets.transparency.opacity_texId - (const int*)gtm_pStart;
  const int HMAT_TRANSPARENCY_OPACITY_TEX_MATRIX_ID = &gtm_offsets.transparency.opacity_texMatrixId - (const int*)gtm_pStart;

  ///////////////////////////////////////////////////
  const int HMAT_TRANSLUCENT_COLOR     = &gtm_offsets.translucent.color.x - gtm_pStart;
  const int HMAT_TRANSLUCENT_DIFFUSION = &gtm_offsets.translucent.diffusionCoeff.x - gtm_pStart;

  const int HMAT_TRANSLUCENT_COLOR_TEX_ID = &gtm_offsets.translucent.color_texId - (const int*)gtm_pStart;
  const int HMAT_TRANSLUCENT_COLOR_TEX_MATRIX_ID = &gtm_offsets.translucent.color_texMatrixId - (const int*)gtm_pStart;

  const int HMAT_TRANSLUCENT_DIFFUSION_TEX_ID = &gtm_offsets.translucent.diffusion_texId - (const int*)gtm_pStart;
  const int HMAT_TRANSLUCENT_DIFFUSION_TEX_MATRIX_ID = &gtm_offsets.translucent.diffusion_texMatrixId - (const int*)gtm_pStart;

  const int HMAT_TRANSLUCENT_DIFF_RADIUS = &gtm_offsets.translucent.diffRadius - gtm_pStart;

  std::ofstream out(a_fileName.c_str());

  out << "#define " << "HMAT_AMBIENT_COLOR_X_OFFSET" << " " << HMAT_AMBIENT_COLOR_X_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_COLOR_Y_OFFSET" << " " << HMAT_AMBIENT_COLOR_Y_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_COLOR_Z_OFFSET" << " " << HMAT_AMBIENT_COLOR_Z_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET" << " " << HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_LIGHT_ID_OFFSET" << " " << HMAT_AMBIENT_LIGHT_ID_OFFSET << std::endl; 
  
  out << "#define " << "HMAT_DIFFUSE_COLOR_X_OFFSET" << " " << HMAT_DIFFUSE_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_Y_OFFSET" << " " << HMAT_DIFFUSE_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_Z_OFFSET" << " " << HMAT_DIFFUSE_COLOR_Z_OFFSET << std::endl;

  out << "#define " << "HMAT_SPECULAR_COLOR_X_OFFSET" << " " << HMAT_SPECULAR_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_Y_OFFSET" << " " << HMAT_SPECULAR_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_Z_OFFSET" << " " << HMAT_SPECULAR_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_POWER_OFFSET" << " " << HMAT_SPECULAR_POWER_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_BRDF_ID_OFFSET" << " " << HMAT_SPECULAR_BRDF_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_SPECULAR_GLOSINESS_OFFSET" << " " << HMAT_SPECULAR_GLOSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_FRESNEL_IOR_OFFSET" << " " << HMAT_SPECULAR_FRESNEL_IOR_OFFSET << std::endl;

  out << "#define " << "HMAT_REFLECTION_COLOR_X_OFFSET" << " " << HMAT_REFLECTION_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_Y_OFFSET" << " " << HMAT_REFLECTION_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_Z_OFFSET" << " " << HMAT_REFLECTION_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_POWER_OFFSET" << " " << HMAT_REFLECTION_POWER_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_BRDF_ID_OFFSET" << " " << HMAT_REFLECTION_BRDF_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_REFLECTION_GLOSINESS_OFFSET" << " " << HMAT_REFLECTION_GLOSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_FRESNEL_IOR_OFFSET" << " " << HMAT_REFLECTION_FRESNEL_IOR_OFFSET << std::endl;

  out << "#define " << "HMAT_REFRACTION_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_MULT_OFFSET" << " " << HMAT_REFRACTION_FOG_MULT_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_GLOSSINESS_OFFSET" << " " << HMAT_REFRACTION_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_IOR_OFFSET" << " " << HMAT_REFRACTION_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_HEIGHT_OFFSET" << " " << HMAT_DISPLACEMENT_HEIGHT_OFFSET << std::endl;
  
  out << "#define " << "HMAT_FLAGS_OFFSET" << " " << HMAT_FLAGS_OFFSET << std::endl;

  out << "#define " << "HMAT_AMBIENT_COLOR_TEX_ID_OFFSET"  << " " << HMAT_AMBIENT_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET"  << " " << HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_COLOR_TEX_ID_OFFSET << std::endl;
  
 
  out << "#define " << "HMAT_REFLECTION_COLOR_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_COLOR_TEX_ID_OFFSET << std::endl;
 
 
  out << "#define " << "HMAT_REFRACTION_COLOR_TEX_ID_OFFSET" << " " << HMAT_REFRACTION_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_IOR_TEX_ID_OFFSET"   << " " << HMAT_REFRACTION_IOR_TEX_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET"  << " " << HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET" << " " << HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_SPECULAR_GLOSS_TEX_ID_OFFSET"   << " " << HMAT_SPECULAR_GLOSS_TEX_ID_OFFSET   << std::endl;
  out << "#define " << "HMAT_REFLECTION_GLOSS_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_GLOSS_TEX_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_EMISSION_TEX_MAXTRIX_ID"     << " " << HMAT_EMISSION_TEX_MAXTRIX_ID     << std::endl;
  out << "#define " << "HMAT_DIFFUSE_TEX_MAXTRIX_ID"      << " " << HMAT_DIFFUSE_TEX_MAXTRIX_ID      << std::endl;
  out << "#define " << "HMAT_SPECULAR_TEX_MAXTRIX_ID"     << " " << HMAT_SPECULAR_TEX_MAXTRIX_ID     << std::endl;
  out << "#define " << "HMAT_REFLECTION_TEX_MAXTRIX_ID"   << " " << HMAT_REFLECTION_TEX_MAXTRIX_ID   << std::endl;
  out << "#define " << "HMAT_TRANSPARENCY_TEX_MAXTRIX_ID" << " " << HMAT_TRANSPARENCY_TEX_MAXTRIX_ID << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_TEX_MAXTRIX_ID" << " " << HMAT_DISPLACEMENT_TEX_MAXTRIX_ID << std::endl;
  out << "#define " << "HMAT_NORMALMAP_TEX_MAXTRIX_ID"    << " " << HMAT_NORMALMAP_TEX_MAXTRIX_ID    << std::endl;

  out << "#define " << "HMAT_SPECULAR_GLOSS_TEX_MATRIX_ID_OFFSET"   << " " << HMAT_SPECULAR_GLOSS_TEX_MATRIX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_GLOSS_TEX_MATRIX_ID_OFFSET" << " " << HMAT_REFLECTION_GLOSS_TEX_MATRIX_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_TRANSPARENCY_OPACITY_TEX_ID" << " " << HMAT_TRANSPARENCY_OPACITY_TEX_ID << std::endl;
  out << "#define " << "HMAT_TRANSPARENCY_OPACITY_TEX_MATRIX_ID" << " " << HMAT_TRANSPARENCY_OPACITY_TEX_MATRIX_ID << std::endl;

  ///////////////////////////////////////////////////
  out << "#define " << "HMAT_TRANSLUCENT_COLOR" << " " << HMAT_TRANSLUCENT_COLOR << std::endl;
  out << "#define " << "HMAT_TRANSLUCENT_DIFFUSION" << " " << HMAT_TRANSLUCENT_DIFFUSION << std::endl;

  out << "#define " << "HMAT_TRANSLUCENT_COLOR_TEX_ID" << " " << HMAT_TRANSLUCENT_COLOR_TEX_ID << std::endl;
  out << "#define " << "HMAT_TRANSLUCENT_COLOR_TEX_MATRIX_ID" << " " << HMAT_TRANSLUCENT_COLOR_TEX_MATRIX_ID << std::endl;

  out << "#define " << "HMAT_TRANSLUCENT_DIFFUSION_TEX_ID" << " " << HMAT_TRANSLUCENT_DIFFUSION_TEX_ID << std::endl;
  out << "#define " << "HMAT_TRANSLUCENT_DIFFUSION_TEX_MATRIX_ID" << " " << HMAT_TRANSLUCENT_DIFFUSION_TEX_MATRIX_ID << std::endl;


  out << "#define " << "HMAT_TRANSLUCENT_DIFF_RADIUS" << " " << HMAT_TRANSLUCENT_DIFF_RADIUS << std::endl;

  out.close();

}

void GPU_Ray_Tracer::UpdateMaterialsOnHWLayer(const std::vector<HydraMaterial>& a_hydraMaterials)
{
  std::vector<IMaterial*>     modernMaterials;
  std::vector<IMaterial*>     modernMaterialsAux;
  std::vector<PlainMaterial>  plainMaterials;
  std::vector<int>            plainMatOffsets;

  ConvertAllLegacyMaterials(a_hydraMaterials, &modernMaterials, &modernMaterialsAux); // legacy to modern
  ConvertAllModernMaterials(modernMaterials, &plainMaterials, &plainMatOffsets);      // modern to plain representation

  if (plainMaterials.size() == 0)
    return;

  m_pHWLayer->SetAllPODMaterials(&plainMaterials[0], plainMaterials.size(), &plainMatOffsets[0], plainMatOffsets.size());

  // free mem if not pure CPU implementation used
  //
  for (int i = 0; i < modernMaterials.size(); i++)
    delete modernMaterials[i];

  for (int i = 0; i < modernMaterialsAux.size(); i++)
    delete modernMaterialsAux[i];
}

void GPU_Ray_Tracer::UpdateLightsOnHWLayer(const std::vector<RAYTR::Light>& a_lights)
{
  std::vector<ILight*>     modernLights;
  std::vector<PlainLight>  plainLights;

  ConvertAllLegacyLights(a_lights, &modernLights);
  ConvertAllModernLights(modernLights, &plainLights);

  if (plainLights.size() == 0)
    return;

  m_pHWLayer->SetAllPODLights((RAYTR::Light*)&a_lights[0], &plainLights[0], a_lights.size());

  // free mem if not pure CPU implementation used
  //
  for (int i = 0; i < modernLights.size(); i++)
    delete modernLights[i];

}



///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::Pack1ChannelTexTo4ThChannel(int texIdTo, int texIdFrom)
{
  if(texIdTo==INVALID_TEXTURE || texIdFrom == INVALID_TEXTURE || texIdTo == texIdFrom)
    return;

  int w1 = m_images[texIdTo].width();
  int h1 = m_images[texIdTo].height();

  int w2 = m_images[texIdFrom].width();
  int h2 = m_images[texIdFrom].height();

  if(w1!=w2 || h1!=h2)
    RUN_TIME_ERROR("input 'paired' textures have different resolution. Check relosution of normalmap/displacement, specular/power, refl/power and e.t.c.");

  vec4ub* data1 = (vec4ub*)(m_images[texIdTo].GetData());
  vec4ub* data2 = (vec4ub*)(m_images[texIdFrom].GetData());

  for(int y=0;y<h1;y++)
  {
    int offsetY = y*w1;
    for(int x=0;x<w1;x++)
      data1[offsetY+x].w = data2[offsetY+x].x;
  }

}

void GPU_Ray_Tracer::CollectEnvTexIds(std::vector<int*>& shadingTextureIds, int a_bpp)
{

  for(int i=0;i<m_lights.size();i++)
  {
    bool validCubeTextures = true;
    for(int j=0;j<6;j++)
      validCubeTextures = validCubeTextures && (m_lights[i].texCudeIndices[j] != INVALID_TEXTURE);

    if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY && validCubeTextures)
    {
      for(int j=0;j<6;j++)
      {
        if(m_lights[i].texCudeIndices[j] != INVALID_TEXTURE)
          if(m_images[m_lights[i].texCudeIndices[j]].bpp() == a_bpp)
            shadingTextureIds.push_back(&m_lights[i].texCudeIndices[j]);
      }
    }
    else if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY)
    {
      int index0 = m_lights[i].sphTexIndex[0];
      int index1 = m_lights[i].sphTexIndex[1];
      
      if(index0 != INVALID_TEXTURE)
        if(m_images[index0].bpp() == a_bpp)
          shadingTextureIds.push_back(&m_lights[i].sphTexIndex[0]);

      if(index1 != INVALID_TEXTURE)
        if(m_images[index1].bpp() == a_bpp)
          shadingTextureIds.push_back(&m_lights[i].sphTexIndex[1]);
    }
    else if((m_lights[i].flags & Light::LIGHT_SKY_PORTAL) && (m_lights[i].flags & Light::LIGHT_SKY_PORTAL_SOURCE3))
    {
      if(m_lights[i].emissiveTexId != INVALID_TEXTURE)
        if(m_images[m_lights[i].emissiveTexId].bpp() == a_bpp)
          shadingTextureIds.push_back(&m_lights[i].emissiveTexId);
    }
  }
}


void GPU_Ray_Tracer::CollectTexIds(std::vector<int*>& shadingTextureIds, std::vector<int*>& opacityTextureIds, std::vector<int*>& displacementTextureIds)
{
  for(int i=0;i<m_hydraMaterials.size();i++)
  {
    HydraMaterial& mat = m_hydraMaterials[i];

    if(mat.ambient.color_texId != INVALID_TEXTURE)
      if(m_images[mat.ambient.color_texId].bpp() == 4)
        shadingTextureIds.push_back(&mat.ambient.color_texId); 

    if(mat.diffuse.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.diffuse.color_texId);

    if(mat.specular.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.specular.color_texId);

    if(mat.specular.gloss_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.specular.gloss_texId);

    if(mat.reflection.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.reflection.color_texId);

    if(mat.reflection.gloss_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.reflection.gloss_texId);

    if(mat.transparency.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.transparency.color_texId);

    if(mat.translucent.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.translucent.color_texId);

    if(mat.transparency.opacity_texId != INVALID_TEXTURE)
      opacityTextureIds.push_back(&mat.transparency.opacity_texId);

    if(mat.displacement.normals_texId != INVALID_TEXTURE)
      displacementTextureIds.push_back(&mat.displacement.normals_texId);

    // pack displacement to normalmap channel
    if(mat.displacement.height_texId != INVALID_TEXTURE && mat.displacement.normals_texId != INVALID_TEXTURE)
      Pack1ChannelTexTo4ThChannel(mat.displacement.normals_texId, mat.displacement.height_texId);
  }

  CollectEnvTexIds(shadingTextureIds, 4);
}

void GPU_Ray_Tracer::CollectTexIdsHDR(std::vector<int*>& shadingTextureIds)
{
  for(int i=0;i<m_hydraMaterials.size();i++)
  {
    HydraMaterial& mat = m_hydraMaterials[i];

    if(mat.ambient.color_texId != INVALID_TEXTURE)
      if(m_images[mat.ambient.color_texId].bpp() == 16)
        shadingTextureIds.push_back(&mat.ambient.color_texId); 
  }

  CollectEnvTexIds(shadingTextureIds, 16);
}

GPU_Ray_Tracer::MegaTexStorageProxy* GPU_Ray_Tracer::CreateNewMegatexStotageProxy(const std::string& name, std::vector<int*>& idArray, int a_bpp)
{
  if(a_bpp == 4)
    return CreateNewMegatexStotageProxyT<char>(name, idArray);
  else
    return CreateNewMegatexStotageProxyT<float>(name, idArray);
}

MEGATEX_USAGE UsageFromString(const std::string& a_usage)
{
  if (a_usage == "shadingTexture")
    return MEGATEX_SHADING;

  if (a_usage == "shadingTextureHDR")
    return MEGATEX_SHADING_HDR;

  if (a_usage == "opacityTexture")
    return MEGATEX_OPACITY;

  if (a_usage == "normalmapTexture")
    return MEGATEX_NORMAL;

  return MEGATEX_SHADING;
}

void GPU_Ray_Tracer::ResizeTextures()
{
  std::vector<ImageStorage*> imageRefs(m_images.size());
 
  for (size_t i = 0; i < m_images.size(); i++)
    imageRefs[i] = &m_images[i];


  struct CompareByImageSize
  {
    bool operator()(ImageStorage* a, ImageStorage* b)
    {
      size_t aSize = a->width()*a->height()*a->bpp();
      size_t bSize = b->width()*b->height()*b->bpp();
      return (aSize > bSize);
    }
  };

  while (true)
  {
    size_t totalSize = 0;
    size_t sizeAvaliable = m_pHWLayer->GetAvaliableMemoryAmount()/2; // because the rest of memory is for geometry

    for (size_t i = 0; i < imageRefs.size(); i++)
    {
      ImageStorage* a = imageRefs[i];
      totalSize += a->width()*a->height()*a->bpp();
    }

    if (totalSize < sizeAvaliable)
      break;

    std::sort(imageRefs.begin(), imageRefs.end(), CompareByImageSize());

    std::cerr << "[MegaTex]: image of size " << imageRefs[0]->width() << "x" << imageRefs[0]->height() << " was resized" << std::endl;

    imageRefs[0]->resizeToHalfSize();
    
  };

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//// so we have 3 megatextures, they are: shadingTexture, transparencyTexture, displacementTexture
//
void GPU_Ray_Tracer::CreateMegaTextures()
{
  std::cerr << "[MegaTex]: assembling mega-textures, total tex num = " << m_images.size() << std::endl;

  ResizeTextures();


  std::vector<int*> shadingTextureHDRIds;
  std::vector<int*> shadingTextureIds;
  std::vector<int*> opacityTextureIds;
  std::vector<int*> displacementTextureIds;

  CollectTexIds(shadingTextureIds, opacityTextureIds, displacementTextureIds);
  CollectTexIdsHDR(shadingTextureHDRIds);

  std::map< std::string, std::vector<int*>* >    megaTexIndicesData;

  megaTexIndicesData["shadingTextureHDR"]      = &shadingTextureHDRIds;
  megaTexIndicesData["shadingTexture"]         = &shadingTextureIds;
  megaTexIndicesData["opacityTexture"]         = &opacityTextureIds;
  megaTexIndicesData["normalmapTexture"]       = &displacementTextureIds;

  m_pHWLayer->Clear(IGraphicsEngine::CLEAR_TEXTURES);

  int   totalBytes = 0;
  float unusedBytes = 0;

  for(auto p = megaTexIndicesData.begin(); p!= megaTexIndicesData.end(); ++p)
  {
    const std::string& name     = p->first;
    std::vector<int*>& idArray  = *(p->second);

    if(name == "shadingTextureHDR")
      m_defferedMegaTexHash[name] = CreateNewMegatexStotageProxy(name, idArray, 16);
    else
      m_defferedMegaTexHash[name] = CreateNewMegatexStotageProxy(name, idArray, 4);
    
   
    totalBytes  += m_defferedMegaTexHash[name]->totalBytes;
    unusedBytes += m_defferedMegaTexHash[name]->unusedBytes;  
  }

  // update materials and lights because we alter textures ids in material struct fields
  //
  if (m_hydraMaterials.size() != 0)
  {
    UpdateMaterialsOnHWLayer(m_hydraMaterials);

    CUDAHWLayer* pImpl = dynamic_cast<CUDAHWLayer*>(m_pHWLayer);
    if (pImpl != NULL)
      hrtSetHydraMaterials(&m_hydraMaterials[0], int(m_hydraMaterials.size()));
  }

  // set correct tex indices anv variables for environment
  //
  for(int i=0;i<m_lights.size();i++)
  {
    if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY)
    {
      float3 color = m_lights[i].color*m_lights[i].intensity;

      AllRenderVarialbes state = m_pHWLayer->GetAllFlagsAndVars();

      state.SetVariableI(HRT_MEASURE_RAYS_TYPE, 0);

      state.SetVariableI(HRT_SPHEREMAP_TEXID0, m_lights[i].sphTexIndex[0]);
      state.SetVariableI(HRT_SPHEREMAP_TEXID1, m_lights[i].sphTexIndex[1]);

      state.SetVariableI(HRT_SPHEREMAP_TEXMATRIXID0, m_lights[i].sphTexMatrices[0]);
      state.SetVariableI(HRT_SPHEREMAP_TEXMATRIXID1, m_lights[i].sphTexMatrices[1]);

      state.SetVariableI(HRT_USE_GAMMA_FOR_ENV, 0);
      state.SetFlags(HRT_ENV_MAP_SPHEREMAP_ACTIVE, 1);

      state.SetVariableF(HRT_ENV_COLOR_X, color.x);
      state.SetVariableF(HRT_ENV_COLOR_Y, color.y);
      state.SetVariableF(HRT_ENV_COLOR_Z, color.z);

      state.SetVariableF(HRT_ENV_COLOR2_X, m_lights[i].L[6]);
      state.SetVariableF(HRT_ENV_COLOR2_Y, m_lights[i].L[7]);
      state.SetVariableF(HRT_ENV_COLOR2_Z, m_lights[i].L[8]);

      m_pHWLayer->SetAllFlagsAndVars(state);
    }
    else if (m_lights[i].GetLightType() == Light::LIGHT_TYPE_MESH) // alter tex id's also in lights
    {
      int eMatId = m_lights[i].matId;
      m_lights[i].emissiveTexId       = m_hydraMaterials[eMatId].ambient.color_texId; 
      m_lights[i].emissiveTexMatrixId = m_hydraMaterials[eMatId].ambient.color_texMatrixId; 
    }
  }
  /////////////////////////////////////////////////////////

  for(int i=0;i<m_images.size();i++)
    m_images[i].FreeData();

  if(totalBytes > 0)
  {
    std::cerr << "[MegaTex]: total memory  " << float(totalBytes)/(1024.0f*1024.0f)  << " MBytes" << std::endl;
    std::cerr << "[MegaTex]: unused memory " << 100.0f*unusedBytes/float(totalBytes) << "\%" << std::endl;
  }

}


void GPU_Ray_Tracer::LoadDefferedMegaTexturesToGPU()
{
  typedef std::map<std::string, MegaTexStorageProxy*>::iterator MegaTexIterator; 
  
  MegaTexIterator p;

  std::vector<MegaTexIterator> megaTexIerators; megaTexIerators.reserve(10);

  megaTexIerators.push_back(m_defferedMegaTexHash.find("opacityTexture"));
  megaTexIerators.push_back(m_defferedMegaTexHash.find("shadingTexture"));
  megaTexIerators.push_back(m_defferedMegaTexHash.find("normalmapTexture"));

  for(p = m_defferedMegaTexHash.begin(); p!= m_defferedMegaTexHash.end(); ++p)
  {
    if(p->second == NULL) continue;
    
    bool alreadyhasThisTex = false;
    for(int i=0;i<megaTexIerators.size();i++)
    {
      if(p == megaTexIerators[i])
      {
        alreadyhasThisTex = true;
        break;
      }
    }
    if(alreadyhasThisTex) continue;

    megaTexIerators.push_back(p);
  }

  for(int i=0;i<megaTexIerators.size();i++)
  {
    p = megaTexIerators[i];
    if(p->second == NULL) 
      continue;

    const std::string& name = p->first;
   
    int width  = p->second->width();
    int height = p->second->height();
    const char* megaTexData = (const char*)(p->second->GetData());

    const std::vector<float>& lookUpTable = p->second->GetLut();
    
    size_t bytesLeft = m_pHWLayer->GetAvaliableMemoryAmount();
    bool outOfCore = (p->first == "shadingTexture" && width*height*4 > bytesLeft) || (p->first == "normalmapTexture" && width*height*4 > bytesLeft);

    if(outOfCore)
      std::cerr << "texture " << p->first.c_str() << " was placed io pinned memory" << std::endl;

    MEGATEX_USAGE texUsage = UsageFromString(name);

    MegaTexData texInput;

    texInput.w               = width;
    texInput.h               = height;
    texInput.data            = (const char*)megaTexData;
    texInput.outOfCore       = outOfCore;
    texInput.lookUpTable     = (float4*)(&lookUpTable[0]);
    texInput.lookUpTableSize = lookUpTable.size()/4;

    m_pHWLayer->SetMegaTexture(texUsage, texInput);

    delete p->second; p->second = NULL;
  }


}



void GPU_Ray_Tracer::SetVariable(const std::string& a_name, int a_val)
{
  Base::SetVariable(a_name, a_val);

  AllRenderVarialbes state = m_pHWLayer->GetAllFlagsAndVars();

  if(a_name == "debugViewSH")
  {
    state.SetVariableI(HRT_DEBUG_SH_ENVIRONMENT, a_val);
  }
  else if(a_name == "g_saveRaySamples")
  {
    state.SetFlags(HRT_STORE_RAY_SAMPLES, a_val);
  }
  else if(a_name == "g_debugLayerDraw")
  {
    state.SetVariableI(HRT_DEBUG_DRAW_LAYER, a_val);
  }
  else if(a_name == "g_ptStupid")
  {
    state.SetFlags(HRT_STUPID_PT_MODE, a_val);
  }
  else if(a_name == "rtMeasureRaysType")
  {
    state.SetVariableI(HRT_MEASURE_RAYS_TYPE, a_val);
  }
  else if(a_name == "rtReorderType")
  {
    state.SetVariableI(HRT_RAY_REORDER_TYPE, a_val);
  }
  else if(a_name == "rtReorderPattern")
  {
    state.SetVariableI(HRT_RAY_REORDER_PATTERN, a_val);
  }

  m_pHWLayer->SetAllFlagsAndVars(state);

}


void GPU_Ray_Tracer::SetVariable(const std::string& a_name, float a_val)
{
  Base::SetVariable(a_name, a_val);
}

void GPU_Ray_Tracer::Clear(int a_flags)
{
  m_pHWLayer->Clear(IGraphicsEngine::CLEAR_FLAGS(a_flags));
  Base::Clear(a_flags);
}


extern "C" void CreateRandomRotationMatrix(float outM[16])
{
  Matrix4x4f rotX, rotY, rotZ; 

  rotX.SetRotationX( rnd(0, MGML_MATH::PI) );
  rotY.SetRotationY( rnd(0, MGML_MATH::PI) );
  rotX.SetRotationZ( rnd(0, MGML_MATH::PI) );
  
  Matrix4x4f res = rotX*rotY*rotZ;
  memcpy(outM, &res, 16*sizeof(float));
}



