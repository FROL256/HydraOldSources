#include <windows.h>

#include <iostream>
#include <sstream>
#include <fstream>

#include <string>
#include <vector>

#include "server_utils.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"
using std::string;

// for max plugin interop

enum PROGRAM_IDS{
  HYDRA_SERVER_ID        = 1,
  HYDRA_PLUGIN_ID        = 2,
  HYDRA_SERVER_FINISH_ID = 3,
};

struct SharedBufferDataInfo
{
  int width;
  int height;
  int read;
  int written;
};

// max plugin crap
//
HANDLE g_sharedMemoryHandle      = NULL;
HANDLE g_sharedOutputImageHandle = NULL;
HANDLE g_sharedMessages          = NULL;

SharedBufferDataInfo* g_pInfo = NULL;
char* g_messages = NULL;
char* g_guiXML = NULL;

void ConnectToMaxPlugin()
{
  g_sharedMemoryHandle = OpenFileMappingA(FILE_MAP_READ, false, "HydraGuiShmem");
  g_guiXML = (char*)MapViewOfFile(g_sharedMemoryHandle, FILE_MAP_READ, 0, 0, 0);

  g_sharedOutputImageHandle = OpenFileMappingA(FILE_MAP_WRITE, false, "HydraLDRImage"); // in fact this is an HDR image, just left old name of resource
  g_pInfo = (SharedBufferDataInfo*)MapViewOfFile(g_sharedOutputImageHandle, FILE_MAP_WRITE, 0, 0, 0);

  g_sharedMessages = OpenFileMappingA(FILE_MAP_WRITE | FILE_MAP_READ, false, "HydraMessageShmem");
  g_messages = (char*)MapViewOfFile(g_sharedMessages, FILE_MAP_WRITE, 0, 0, 0);

  // find xml header, crap code
  //
  if (g_guiXML != NULL)
  {
    bool headerFound = false;

    for (int start = 0; start < 256; start++)
    {
      char header[8]; //
      memcpy(header, g_guiXML + start, 5); header[5] = '\0';
      if (std::string(header) == "<?xml")
      {
        g_guiXML    = g_guiXML + start;
        headerFound = true;
        break;
      }
    }

    if (!headerFound)
      std::cerr << "xml header not found in shared buffer" << std::endl;
  }


}

void DisconnectMaxPlugin()
{
  CloseHandle(g_sharedMemoryHandle);
  g_sharedMemoryHandle = NULL;

  CloseHandle(g_sharedOutputImageHandle);
  g_sharedOutputImageHandle = NULL;

  CloseHandle(g_sharedMessages);
  g_sharedMessages = NULL;
}


void UpdateImageFromZImage(void* a_data, int WinWidth, int WinHeight, bool a_lastImage)
{
  SharedBufferDataInfo* pInfo = g_pInfo; 

  if (pInfo != NULL && pInfo->read != 0)
  {
    char* pOutData = ((char*)(g_pInfo)) + sizeof(SharedBufferDataInfo);
    
    if (a_data != NULL)
      ImageZBlockMemToRowPitch((const float4*)a_data, (float4*)pOutData, WinWidth, WinHeight);
      //memcpy(pOutData, a_data, WinWidth*WinHeight*4*sizeof(float));   
    
    pInfo->width  = WinWidth;
    pInfo->height = WinHeight;
    pInfo->read   = 0;

    if (a_lastImage)
      pInfo->written = HYDRA_SERVER_FINISH_ID;
    else
      pInfo->written = HYDRA_SERVER_ID;
  }

}


struct PluginInput
{

  PluginInput()
  {
    imageWidth      = 1024;
    imageHeight     = 1024;
    minRaysPerPixel = 16;
    maxRaysPerPixel = 1024;
    relativeError   = 0.05f;
    exitNow         = false;
  }

  void ReadFromSharedXML();

  int   imageWidth;
  int   imageHeight;
  int   minRaysPerPixel;
  int   maxRaysPerPixel;
  float relativeError;
  bool  exitNow;
};

void PluginInput::ReadFromSharedXML()
{
  TiXmlDocument doc;
  doc.Parse(g_guiXML, 0, TIXML_ENCODING_UTF8);

  TiXmlHandle docHandle(&doc);
  TiXmlNode* node;

  TiXmlNode* presetsNode = docHandle.FirstChild("hydra_presets").Node();
  if (presetsNode == NULL)
  {
    std::cerr << "presetsNode == NULL" << std::endl;
    return;
  }

  node = presetsNode->FirstChild("resolution");
  if (node != NULL)
  {
    std::string res_text = node->ToElement()->GetText();
    size_t xPos = res_text.find('x');
    std::string widthStr = res_text.substr(0, xPos);
    std::string heightStr = res_text.substr(xPos + 1, res_text.size());

    imageWidth = atoi(widthStr.c_str());
    imageHeight = atoi(heightStr.c_str());
  }

  node = presetsNode->FirstChild("maxRaysPerPixel");
  if (node)
    maxRaysPerPixel = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("minRaysPerPixel");
  if (node)
    minRaysPerPixel = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("pt_error");
  if (node)
    relativeError = atof(node->ToElement()->GetText()) / 100.0f;

  node = presetsNode->FirstChild("exitnow");
  if (node)
    exitNow = bool(atoi(node->ToElement()->GetText()));
}

void SendToPlugin(const char* a_message)
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)g_messages;

  char* messageData = g_messages + sizeof(SharedBufferDataInfo);
  if (a_message == NULL || g_messages == NULL)
    return;

  memset(messageData, 0, 1024);
  strcpy(messageData, a_message);

  pInfo->width = strlen(a_message) + 1;
  pInfo->height = 1;
  pInfo->read = 0;
  pInfo->written = HYDRA_SERVER_ID;
}

void UpdateProgress(const char* a_message, float a_progress)
{
  static char message[1024];

  memset(message, 0, 1024);
  sprintf(message, "%s: %.0f%% \r", a_message, a_progress*100.0f);

  fprintf(stderr, "%s", message);
  SendToPlugin(message);
}


// \\ for max plugin interop

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//// communication between hydra_server.exe and hydra.exe
//
HANDLE g_hServerControll = NULL;
int*   g_pServerControlData = NULL;

void OpenHydraServerToRenderShmem()
{
  g_hServerControll = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, 64*sizeof(int), "HydraServerControl");
  g_pServerControlData = (int*)MapViewOfFile(g_hServerControll, FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, 0);
  memset(g_pServerControlData, 0, 64 * sizeof(int));
}

void CloseHydraServerToRenderShmem()
{
  CloseHandle(g_hServerControll);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


struct ZBlockT
{
  ZBlockT()            : index(0), index2(2), counter(0), diff(0.0f) {}
  ZBlockT(int a_index) : index(a_index), index2(2), counter(0), diff(0.0f) {}

  int index;   // just block offset if global screen buffer
  int index2;  // index in other buffer + avg trace depth
  int counter; // how many times this block was traced?
  float diff;  // error in some units. stop criterion if fact
};

const int ZBLOCKSIZE = 256;

struct ImageZ
{
  void init(int w, int h);
  void clear();

  bool loadFromFile(const std::string& a_fileName);
  void unionWith(const ImageZ& a_otyherImage);

  float estimateProgress(float relError, int minRaysPerPixel, int maxRaysPerPixel);
  bool isFinished(float relError, int minRaysPerPixel, int maxRaysPerPixel);

  std::vector<float>   color;
  std::vector<float>   colorSquare;
  std::vector<ZBlockT> zblocks;

  int width;
  int height;
};


void ImageZ::init(int w, int h)
{
  width  = w;
  height = h;

  color.resize(w*h*4);
  colorSquare.resize(w*h*4);
  zblocks.resize((w*h) / ZBLOCKSIZE);
}


void ImageZ::clear()
{
  for (size_t i = 0; i < color.size(); i+=4)
  {
    color[i+0] = 0.0f;
    color[i+1] = 0.0f;
    color[i+2] = 0.0f;
    color[i+3] = 0.0f;

    colorSquare[i + 0] = 0.0f;
    colorSquare[i + 1] = 0.0f;
    colorSquare[i + 2] = 0.0f;
    colorSquare[i + 3] = 0.0f;
  }

  for (size_t i = 0; i < zblocks.size(); i++)
    zblocks[i] = ZBlockT(i);

}

bool ImageZ::loadFromFile(const std::string& a_fileName)
{
  HANDLE hFile = NULL;
  int iter = 0;

  for (int iter = 0; iter < 20; iter++)
  {
    hFile = CreateFileA(a_fileName.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);   // no sharing allowed !
    
    if (hFile != NULL && hFile != INVALID_HANDLE_VALUE)
      break;
    
    Sleep(100);
  }

  if (hFile == NULL || hFile == INVALID_HANDLE_VALUE)
    return false;

  DWORD dwBytesRead = 0;

  int wh[2] = { 0, 0 };

  ReadFile(hFile, wh,              sizeof(int) * 2, &dwBytesRead, NULL);

  init(wh[0], wh[1]);

  ReadFile(hFile, &color[0],       sizeof(float) * color.size(), &dwBytesRead, NULL);
  ReadFile(hFile, &colorSquare[0], sizeof(float) * colorSquare.size(), &dwBytesRead, NULL);
  ReadFile(hFile, &zblocks[0],     sizeof(ZBlockT) * zblocks.size(), &dwBytesRead, NULL);

  CloseHandle(hFile);

  return true;
}

void ImageZ::unionWith(const ImageZ& a_otherImage)
{
  for (size_t z = 0; z < zblocks.size(); z++)
  {
    ZBlockT block1 = zblocks[z];
    ZBlockT block2 = a_otherImage.zblocks[z];

    float w1 = float(block1.counter) / float(block1.counter + block2.counter);
    float w2 = float(block2.counter) / float(block1.counter + block2.counter);

    size_t start = block1.index*ZBLOCKSIZE;
    size_t end   = block1.index*ZBLOCKSIZE + ZBLOCKSIZE;

    for (size_t x = start; x < end; x++)
    {
      color[x*4+0] = color[x*4+0]*w1 + a_otherImage.color[x*4+0]*w2; 
      color[x*4+1] = color[x*4+1]*w1 + a_otherImage.color[x*4+1]*w2;
      color[x*4+2] = color[x*4+2]*w1 + a_otherImage.color[x*4+2]*w2;
      color[x*4+3] = color[x*4+3]*w1 + a_otherImage.color[x*4+3]*w2;

      colorSquare[x * 4 + 0] = colorSquare[x * 4 + 0] * w1 + a_otherImage.colorSquare[x * 4 + 0] * w2;
      colorSquare[x * 4 + 1] = colorSquare[x * 4 + 1] * w1 + a_otherImage.colorSquare[x * 4 + 1] * w2;
      colorSquare[x * 4 + 2] = colorSquare[x * 4 + 2] * w1 + a_otherImage.colorSquare[x * 4 + 2] * w2;
      colorSquare[x * 4 + 3] = colorSquare[x * 4 + 3] * w1 + a_otherImage.colorSquare[x * 4 + 3] * w2;
    }

    zblocks[z].counter = block1.counter + block2.counter;
    zblocks[z].index2  = block1.index2 | block2.index2;    /// resulting block finished if one of them is finished
  }

}


float BlockError(int offset, float* a_color, float* a_color2, int nSamples, float a_pathTraceError)
{
  float error = 0.0f;

  size_t start = offset;
  size_t end = offset + ZBLOCKSIZE;

  for (size_t x = start; x < end; x++)
  {
    float3 color, colorSquare;

    color.x = a_color[x * 4 + 0];
    color.y = a_color[x * 4 + 1];
    color.z = a_color[x * 4 + 2];

    colorSquare.x = a_color2[x * 4 + 0];
    colorSquare.y = a_color2[x * 4 + 1];
    colorSquare.z = a_color2[x * 4 + 2];

    float pixelError = MonteCarloStdErr(color, colorSquare, nSamples);

    if (pixelError >= a_pathTraceError)
      error += (pixelError / a_pathTraceError); // how many times we are fucked up ?
  }

  return error;
}

static bool BlockFinished(ZBlockT block, int a_minRaysPerPixel, int a_maxRaysPerPixel) // for use on the cpu side ... for current
{
  int samplesPerPixel     = block.counter;
  float acceptedBadPixels = sqrtf((float)(256));
  bool summErrorOk        = (block.diff <= acceptedBadPixels);

  return ((summErrorOk && samplesPerPixel >= a_minRaysPerPixel) || (samplesPerPixel >= a_maxRaysPerPixel)) || (block.index2 == 0xFFFFFFFF);
}

float ImageZ::estimateProgress(float relError, int minRaysPerPixel, int maxRaysPerPixel)
{
  int BLOCK_NUMBER = (width*height) / (256);
  float totalSppmf = float(BLOCK_NUMBER)*float(maxRaysPerPixel);
  int totalSPPDone = 0;

  for (size_t z = 0; z < zblocks.size(); z++)
  {
    ZBlockT& block = zblocks[z];
    block.diff = BlockError(block.index*ZBLOCKSIZE, &color[0], &colorSquare[0], block.counter, relError);

    if (BlockFinished(block, minRaysPerPixel, maxRaysPerPixel))
      totalSPPDone += maxRaysPerPixel;
    else
      totalSPPDone += block.counter;
  }

  return (float(totalSPPDone) / totalSppmf);
}

bool ImageZ::isFinished(float relError, int a_minRaysPerPixel, int a_maxRaysPerPixel)
{
  for (size_t z = 0; z < zblocks.size(); z++)
  {
    ZBlockT& block = zblocks[z];
    if (!BlockFinished(block, a_minRaysPerPixel, a_maxRaysPerPixel))
      return false;
  }

  return true;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


struct HydraInstance
{
  int deviceId;
  int seed;
  float updateTimeInSec;

  std::string exePath;
  std::string imgPath;

  STARTUPINFOA        startupInfo;
  PROCESS_INFORMATION processInfo;
  bool                processStarted;
};

std::string toString(int val)
{
  std::stringstream out;
  out << val;
  return out.str();
}

std::string toString(float val)
{
  std::stringstream out;
  out << val;
  return out.str();
}

int main(int argc, char** argv)
{
  ConnectToMaxPlugin();
  OpenHydraServerToRenderShmem();

  if (g_pInfo == NULL)
  {
    std::cout << "can't connect to Max shared memory" << std::endl;
    return 0;
  }

  PluginInput input;
  input.ReadFromSharedXML();

  std::vector<HydraInstance> renderNodes(2);

  renderNodes[0].deviceId = 0;
  renderNodes[0].seed     = rand();
  renderNodes[0].exePath  = "C:/[Hydra]/bin/hydra.exe";
  renderNodes[0].imgPath  = "C:/[Hydra]/rendered_images/test_render.zdata";
  renderNodes[0].updateTimeInSec = 2.0f;

  if (renderNodes.size() > 1)
  {
    renderNodes[1].deviceId = 2;
    renderNodes[1].seed = rand();
    renderNodes[1].exePath = "C:/[Hydra]/bin/hydra.exe";
    renderNodes[1].imgPath = "C:/[Hydra]/rendered_images/test_render2.zdata";
    renderNodes[1].updateTimeInSec = 3.0f;
  }

  // clear all img data files
  //
  for (auto p = renderNodes.begin(); p != renderNodes.end(); ++p)
  {
    const std::string& fname = p->imgPath;
    DeleteFileA(fname.c_str());
  }


  // run all reder insrtances
  //
  for (auto p = renderNodes.begin(); p != renderNodes.end(); ++p)
  {
    ZeroMemory(&p->startupInfo, sizeof(STARTUPINFOA));
    ZeroMemory(&p->processInfo, sizeof(PROCESS_INFORMATION));
  
    p->startupInfo.cb          = sizeof(STARTUPINFO);
    p->startupInfo.dwFlags     = STARTF_USESHOWWINDOW;
    p->startupInfo.wShowWindow = SW_SHOWMINNOACTIVE;

    std::string argstr = "C:/[Hydra]/bin/hydra.exe C:/[Hydra]/pluginFiles/scene.vsgf C:/[Hydra]/pluginFiles/hydra_profile_generated.xml C:/[Hydra]/pluginFiles/settings.xml -cl_enable 1 -multidevicemode 1";
  
    argstr += " -out "            + p->imgPath;
    argstr += " -cl_device_id "   + toString(p->deviceId);
    argstr += " -seed "           + toString(p->seed);
    argstr += " -diskupdatetime " + toString(p->updateTimeInSec);

    p->processStarted = CreateProcessA("C:\\[Hydra]\\bin\\hydra.exe", (char*)argstr.c_str(), NULL, NULL, FALSE, NULL, NULL, NULL, &p->startupInfo, &p->processInfo);
  }

  // main 'render' loop
  //
  ImageZ mainImage;
  ImageZ tempImage;

  mainImage.init(input.imageWidth, input.imageHeight);

  while (!input.exitNow) // or all processes are finished or the fastest one finished ... perhaps thic cond is for local scheme only
  {
    Sleep(1500);

    mainImage.clear();
    bool unionFailed = false;

    for (auto p = renderNodes.begin(); p != renderNodes.end(); ++p)
    {
      if (tempImage.loadFromFile(p->imgPath))
      {
        mainImage.unionWith(tempImage);
        //std::cout << "image load succeded!" << std::endl;
      }
      else
      {
        //std::cout << "image load failed!" << std::endl;
        unionFailed = true;
        break;
      }
    }

    if (!unionFailed)
    {
      UpdateImageFromZImage(&mainImage.color[0], input.imageWidth, input.imageHeight, false);
      float progress = mainImage.estimateProgress(input.relativeError, input.minRaysPerPixel, input.maxRaysPerPixel);
      UpdateProgress("Rendering (multi-device)", progress);
    }

    if (!unionFailed && mainImage.isFinished(input.relativeError, input.minRaysPerPixel, input.maxRaysPerPixel))
      break;

    input.ReadFromSharedXML();
  }

  for (int i = 0; i < 64; i++)
    g_pServerControlData[i] = 0xFFFFFFFF;  // send exit messages to all processes 

  SendToPlugin("exitServer");              // send exit message to plugin
 
  Sleep(1000);

  // terminate them if they are still hangs
  //
  for (auto p = renderNodes.begin(); p != renderNodes.end(); ++p)
  {
    DWORD exitCode;
    GetExitCodeProcess(p->processInfo.hProcess, &exitCode);

    if (exitCode == STILL_ACTIVE)
      TerminateProcess(p->processInfo.hProcess, 0);
  }

  CloseHydraServerToRenderShmem();
  DisconnectMaxPlugin();

  return 0;
}

