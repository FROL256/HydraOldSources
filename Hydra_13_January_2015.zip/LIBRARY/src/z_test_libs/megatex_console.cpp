#include "Tester.cpp"

/*
#include <fstream>
#include "MegaTextureManager.h"
#include <time.h>

typedef std::vector<std::pair<int, int>> SizeArray;

#define SIZES 9
int possibleSizes[SIZES]={20,50,128,256,300,400,512,600,1024};

int main()
{
  int t = (int) time(0);
  printf("%d\n",t);
  srand(t);

  std::vector<const float *> images;
  SizeArray inputSizes;

  for (int i=0; i<100; i++)
  {
    float color = (128 + rand() % 127) / 255.0f;
    int width=possibleSizes[rand()%SIZES];
    int height=possibleSizes[rand()%SIZES];
    inputSizes.push_back(std::pair<int,int>(width,height));
    float * ptr = new float [4 * width * height];

    for (int j = 0; j < 4 * width * height; j++ )
      ptr[j] = color;

    images.push_back(ptr);
  } 

  float* mega;
  int w, h;

  MegaTextureManager<float,4> megaTexCompiler;

  megaTexCompiler.CalculateOffsets(inputSizes, &w, &h);

  mega = new float [4*w*h];
  bool res = megaTexCompiler.BuildImage(images, inputSizes, mega, w, h);

  long bytes = megaTexCompiler.GetUsedBytes();
  int blacks = megaTexCompiler.GetBlackAreasPercent();

  printf("BYTES USED: %d\n", bytes);
  printf("BLACK: %d%\n", blacks);

  if (!res)
    printf("failed\n");

  std::ofstream fout;
  fout.open("c://out.bin", std::ios::out | std::ios::binary);
  if(!fout.is_open())
    return -1;

  fout.write((char*)mega, 4*w*h*sizeof(float));


  delete [] mega;
  for (int i = 0 ; i < (int) images.size(); i++)
    delete images[i];
}
*/

