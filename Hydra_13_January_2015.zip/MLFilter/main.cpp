#include "MLFilterAPI.h"
#include "../CSL/HDRImage.h"

#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>

#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

typedef unsigned char uint8;

//static inline float fmaxf(float a, float b) { return a < b ? a : b; }

ILuint LoadImageFromImagef4(const std::string& a_fileName, bool a_tmAndGamma)
{
  int wh[2];

  std::ifstream fin(a_fileName.c_str(), std::ios::binary);

  if(!fin.is_open())
  {
    std::cerr << "LoadImageFromImagef4: can't open file " << a_fileName.c_str() << std::endl;
    return 0xFFFFFFFF;
  }

  fin.read((char*)wh, sizeof(int)*2);
  float* data = new float[wh[0]*wh[1]*4]; 
  fin.read((char*)data, wh[0]*wh[1]*4*sizeof(float));
  fin.close();

  if(a_tmAndGamma)
  {
    float gamma = 2.0f;

    for(int i = 0; i < wh[0]*wh[1]*4; i+=4)
    {
      float r = data[i+0];
      float g = data[i+1];
      float b = data[i+2];
      float a = data[i+3];

      r = powf(r, 1.0f/gamma);
      g = powf(g, 1.0f/gamma);
      b = powf(b, 1.0f/gamma);
      a = a;

      //float maxColInv = 1.0f/fmaxf(r, fmaxf(g, b));
      //r = (maxColInv < 1.0f) ? r*maxColInv : r;
      //g = (maxColInv < 1.0f) ? g*maxColInv : g;
      //b = (maxColInv < 1.0f) ? b*maxColInv : b;

      data[i+0] = r;
      data[i+1] = g;
      data[i+2] = b;
      data[i+3] = a;
    }

  }

  ILuint imageName = ilGenImage();
  ilBindImage(imageName);

  ilTexImage(wh[0],wh[1],1,4,IL_RGBA,IL_FLOAT,data);

  delete [] data;
  return imageName;
}


void SummAllImageLaiers()
{
  HDRImage primary, secondary, tex, normals, rest, lum, sec2;

  primary.loadFromImage4f("C:\\[Hydra]\\filter\\input_bin\\layer_0_5_primary_diffuse.imagef4");
  secondary.loadFromImage4f("C:\\[Hydra]\\filter\\input_bin\\layer_0_6_secondary_diffuse.imagef4");
  rest.loadFromImage4f("C:\\[Hydra]\\filter\\input_bin\\layer_0_7_color_the_rest.imagef4");
  tex.loadFromImage4f("C:\\[Hydra]\\filter\\input_bin\\layer_0_3_texcolor.imagef4");
  normals.loadFromImage4f("C:\\[Hydra]\\filter\\input_bin\\layer_0_2_normals.imagef4");

  IMLFilter* pFilterImpl = CreateFilter("default");

  lum  = primary;
  sec2 = secondary;

  
  MLSettings presets;
  presets.filterPrimary = true;
  presets.filterSize = 5;
  presets.sigma = 2.0f;

  MLAllData data;
  data.w         = normals.width();
  data.h         = normals.height();
  data.primary   = &primary.data()[0];
  data.secondary = &secondary.data()[0];
  data.normals   = &normals.data()[0];
  data.txcolor   = &tex.data()[0];
  data.out_res   = &lum.data()[0];

  pFilterImpl->SetPresets(presets);
  pFilterImpl->SetAllInputData(data);

  pFilterImpl->FilterIrradiance();
  
  lum.add(rest);
  lum.saveToPNG("D:\\temp\\MultiLayeredBug\\01_result.png", 2.2f);

  normals.saveToPNG("D:\\temp\\MultiLayeredBug\\02_normals.png", 2.2f);
  normals.gaussBlur(2, 1.5f);
  normals.saveToPNG("D:\\temp\\MultiLayeredBug\\02_normals_blurred.png", 2.2f);

  DeleteFilter(pFilterImpl); pFilterImpl = NULL;

}

int main(int argc, char** argv)
{
  /*
  std::vector<float> testG;

  int ksize = 5;
  createGaussKernelWeights(ksize, testG);
  
  float summ = 0.0f;
  for(int i = 0; i < ksize; ++i)
  {
    for(int j = 0; j < ksize; ++j)
    {
      std::cerr << testG[i*ksize+j] << " ";
      summ += testG[i*ksize+j];
    }
    std::cerr << std::endl;
  }
  std::cerr << std::endl;

  std::cerr << "summ = " << summ << std::endl;

  return 0;
  */

  ilInit();
  iluInit();

  SummAllImageLaiers();
  return 0;

  bool useToneMapping = false;
  bool toPNG = false;

  /*
  if(argc < 3)
  {
    fprintf(stderr,"Error, input or output file was not set\n");
    return 0;
  }

  char* inFileName  = argv[1];
  char* outFileName = argv[2];

  bool useToneMapping = false;
  if(argc > 3)
  {
    std::string arg3 = argv[3];
    if(arg3 == "-tm")
      useToneMapping = true;
  }

  if(argc > 4)
  {
    std::string arg3 = argv[3];
    if(arg3 == "-png")
      toPNG = true;
  }*/

  //char* inFileName  = "C:\\[Hydra]\\temp\\geom.image4f";
  char* inFileName  = "C:\\[Hydra]\\filter\\output.imagef4";
  //char* inFileName  = "image_layers\\layer_0_3_texcolor.imagef4";
  char* outFileName = "image_layers\\out.hdr";

  ilInit();
  iluInit();

  ILenum Error;
  ILuint imageName = LoadImageFromImagef4(inFileName, useToneMapping);
  
  ilEnable(IL_FILE_OVERWRITE);
  
  if(toPNG)
    ilSave(IL_PNG, outFileName);
  else
    ilSave(IL_HDR, outFileName);

  while ((Error = ilGetError()) != IL_NO_ERROR)
    fprintf(stderr,"SaveImageToFile; \n OpenIL error, can save image: %d: %s\n", Error, iluErrorString(Error));

  ilDeleteImages(1, &imageName); 
  ilDisable(IL_FILE_OVERWRITE);

  return 0;
}
