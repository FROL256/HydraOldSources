#pragma once

#include "MLFilterAPI.h"
#include "../CSL/HDRImage.h"
#include "LiteMath.h"

#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

class SimpleMLFilter : public IMLFilter
{
public:

  SimpleMLFilter(){}
  ~SimpleMLFilter(){}

  void SetAllInputData(MLAllData a_data);

  void FilterIrradiance();

protected:

  struct AllData
  {
    const float4* normals;
    const float4* txcolor;

    const float4* primary;
    const float4* secondary;

    float4*       out_res;

    int           w,h;

  } m_allData;


  float m_depthMin;
  float m_depthMax;
  void calcDepthImageParams();

  float tex2DDepth(int x, int y);

  struct int2
  {
    int2() : x(0), y(0) {}
    int2(int a, int b) : x(a), y(b) {} 
    int x, y;
  };

  //bool  pixelsSame(float4 data1, float4 data2);
  float pixelSimilarity(float4 data1, float4 data2);


  struct GaussResult
  {
    GaussResult() : isBoundary(false), isStrongBoundary(false), matchTimes(0), pixelColor(0,0,0) {}

    float3 pixelColor;
    int    matchTimes;
    bool   isBoundary;
    bool   isStrongBoundary;
  };


  GaussResult gaussFilterColor(int bSize, int x, int y, const float4* colors, float4 sampleData);

  float3 gaussFilterCombine(int bSize, int x, int y);
  float3 gaussFilterCombineSS(int bSize, int x, int y, int ssOffset);


  std::vector<float> m_gaussKernel;

  struct SubSamplesArray
  {
    void LoadFromFiles(const std::string& fname1, const std::string& fname2, const std::string& fname3);
    
    #ifndef ML_PRODUCTION
    void TestSaveImages2(int w, int h);
    #endif

    HDRImage m_ssnd;
    HDRImage m_sstc;
    std::vector<int2> pixelsCoord;
  };

  SubSamplesArray m_subSamples;
  std::vector<int> m_subSamplesOffset;

  void buildLookUpTable(std::vector<int>& a_lut, const SubSamplesArray& a_subSamples);

};



void createGaussKernelWeights(int size, std::vector<float>& gKernel);


float3 tex2D(const float4* data, int x, int y, int w, int h);
float  tex2D(const float* data, int x, int y, int w, int h);
float3 sample2D(const float4* data, float x, float y, int w, int h);

