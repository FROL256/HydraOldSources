#pragma once

#include <string>

class ISerializer
{
public:
	virtual bool Init(std::string& filename) = 0;
	virtual bool SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight) = 0;
	virtual bool Close() = 0;
};