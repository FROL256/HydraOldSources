#include "parser.h"
#include "..\tinyxml\tinyxml.h"

bool Parser::parseFile( const char * filename )
{
	TiXmlDocument doc(filename);
	bool loadOkay = doc.LoadFile();
	if (!loadOkay)
		return false;

	TiXmlNode* node;
	TiXmlElement* elem;
	TiXmlNode* typeNode = doc.FirstChild("type");
	if (!typeNode)
		return false;

	elem = typeNode->ToElement();
	if (!elem)
		return false;
	m_type = atoi(elem->GetText());

	TiXmlNode* outNode = doc.FirstChild("output");
	if (!outNode)
		return false;

	elem = outNode->ToElement();
	if (!elem)
		return false;

	m_output = elem->Attribute("path");
	elem->Attribute("width", &m_width);
	elem->Attribute("height", &m_height);

	node=NULL;
	while (node = doc.IterateChildren("light", node))
	{
		//TiXmlNode* srcPathNode = node->FirstChild("photopath");
		//if (!srcPathNode)
		//	return false;
		elem=node->ToElement();
		if (!elem)
			return false;

		m_input.push_back(elem->Attribute("photopath"));

		//TiXmlNode* coeffsNode = node->FirstChild("coeffs");
		//if (!coeffsNode)
		//	return false;

		//elem=coeffsNode->ToElement();
		//if (!elem)
		//	return false;

		double r,g,b;
		elem->Attribute("R",&r);
		elem->Attribute("G",&g);
		elem->Attribute("B",&b);

		m_coeffs.push_back((float)r);
		m_coeffs.push_back((float)g);
		m_coeffs.push_back((float)b);
	}

	return true;
}

int Parser::getType()
{
   return m_type;
}

int Parser::getImageWidth()
{
	return m_width;
}

int Parser::getImageHeight()
{
	return m_height;
}

void Parser::getOutputFile( std::string& output )
{
   output=m_output;
}

void Parser::getInputFiles( std::vector<std::string>& input )
{
   input=m_input;
}

void Parser::getLightCoeffs( std::vector<float>& coeffs )
{
	coeffs=m_coeffs;
}