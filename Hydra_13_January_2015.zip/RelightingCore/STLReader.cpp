#include "STLReader.h"

bool STLReader::Init(std::string& filename)
{
	fin.clear();
	fin.open(filename.c_str(), std::ios::in | std::ios::binary);
    if(!fin.is_open())
      return false;
	return true;
}

bool STLReader::Close()
{
	fin.close();
	return true;
}

bool STLReader::SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight)
{
	fin.read((char*)in_fpImage, 4*in_iWidth*in_iHeight*sizeof(float));
	return true;
}


