#include "HDRImage.h"


HDRImage::HDRImage(int w, int h, int channels, const float* data) : m_channels(channels), m_width(w), m_height(h)
{
  m_data.resize(w*h*channels);

  if(data!=NULL)
    memcpy(&m_data[0], data, w*h*channels*sizeof(float));
  else
    memset(&m_data[0], 0, w*h*channels*sizeof(float));
}

void HDRImage::loadFromImage4f(const std::string& a_fileName)
{
  unsigned int wh[2];

  std::ifstream fin(a_fileName.c_str(), std::ios::binary);

  if(!fin.is_open())
  {
    std::cerr << "LoadImageFromImagef4: can't open file " << a_fileName.c_str() << std::endl;
    return;
  }

  fin.read((char*)wh, sizeof(int)*2);
  
  m_width  = wh[0];
  m_height = wh[1];

  m_data.resize(m_width*m_height*4);

  fin.read((char*)&m_data[0], wh[0]*wh[1]*4*sizeof(float));
  fin.close();

  m_channels = 4;
}

void HDRImage::blend(const HDRImage& a_image, float c1, float c2)
{
  if(m_width != a_image.width() || m_height != a_image.height())
  {
    std::cerr << "HDRImage::blend, IMAGES OF DIFFERENT SIZE!!!" << std::endl;
    return;
  }

  const std::vector<float>& data = a_image.data();

  for(size_t i=0;i<m_data.size();i++)
    m_data[i] = m_data[i]*c1 + data[i]*c2;
}

void HDRImage::mul(const HDRImage& a_image, float c1)
{
  if(m_width != a_image.width() || m_height != a_image.height())
  {
    std::cerr << "HDRImage::mul, IMAGES OF DIFFERENT SIZE!!!" << std::endl;
    return;
  }

  const std::vector<float>& data = a_image.data();

  for(size_t i=0;i<m_data.size();i++)
    m_data[i] = m_data[i]*data[i]*c1;

}


void HDRImage::mul(float c1)
{
  for(size_t i=0;i<m_data.size();i++)
    m_data[i] = m_data[i]*c1;
}

void HDRImage::gaussBlur(int radius, float sigma)
{
  std::vector<float> gKernel;
  createGaussKernelWeights1D(2*radius+1, gKernel, sigma);

  //std::cerr << "gKernel = ";
  //for(auto i=0;i<gKernel.size();i++)
  //  std::cerr << gKernel[i] << " ";
  //std::cerr << std::endl;

  std::vector<float> tempData(m_width*m_height*m_channels);

  float tempColor[4];

  int h = m_height;
  int w = m_width;

  // blur rows
  //
  for (int y = 0; y < h; y++)
  {
    int offsetY = y*w*m_channels;

    for (int x = radius; x < w-radius; x++)
    {
      for(int k=0;k<m_channels;k++)
        tempColor[k] = 0.0f;

      float summW = 0.0f;
      for(int p=x-radius;p<x+radius;p++)
      {
        float weight = gKernel[p+radius-x];
        for(int k=0;k<m_channels;k++)
          tempColor[k] += m_data[offsetY + p*m_channels + k]*weight;
        summW += weight;
      }

      for(int k=0;k<m_channels;k++)
        tempData[offsetY + x*m_channels + k] = tempColor[k]/(summW+1e-5f);
    }
  }
  

  // blur cols
  //
  for (int x = 0; x < w; x++)
  {
    //int offsetY = y*w*m_channels;
    for (int y = radius; y < h-radius; y++)
    {
      for(int k=0;k<m_channels;k++)
        tempColor[k] = 0.0f;

      float summW = 0.0f;
      for(int p=y-radius;p<y+radius;p++)
      {
        float weight = gKernel[p+radius-y];
        for(int k=0;k<m_channels;k++)
          tempColor[k] += tempData[p*w*m_channels + x*m_channels + k]*weight;
        summW += weight;
      }

      for(int k=0;k<m_channels;k++)
        m_data[y*w*m_channels + x*m_channels + k] = tempColor[k]/(summW+1e-5f);
    }
  }

}


#ifndef ML_PRODUCTION

#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

void HDRImage::saveToHDR(const std::string& a_fileName, float a_gamma)
{
  std::vector<float> tempData = m_data;

  if(a_gamma != 1.0f)
  {
    for(int i = 0; i < m_width*m_height*m_channels; i++)
    {
      float val = tempData[i+0];
      tempData[i] = powf(val, 1.0f/a_gamma);
    }
  }

  ILuint imageName = ilGenImage();
  ilBindImage(imageName);

  if(m_channels == 4)
    ilTexImage(m_width,m_height,1,4,IL_RGBA,IL_FLOAT, &tempData[0]);
  else
    ilTexImage(m_width,m_height,1,1,IL_LUMINANCE,IL_FLOAT, &tempData[0]);
  
  ilEnable(IL_FILE_OVERWRITE);
  
  ilSave(IL_HDR, a_fileName.c_str());
  ilDisable(IL_FILE_OVERWRITE);
  ilDeleteImages(1, &imageName); 
}

void HDRImage::saveToPNG(const std::string& a_fileName, float a_gamma)
{
  if(m_channels != 4)
    return;

  std::vector<unsigned int>  tempData2(m_data.size());

  for(int i = 0; i < m_width*m_height*4; i+=4)
  {
    float r = m_data[i+0];
    float g = m_data[i+1];
    float b = m_data[i+2];
    float a = m_data[i+3];

    r = powf(r, 1.0f/a_gamma);
    g = powf(g, 1.0f/a_gamma);
    b = powf(b, 1.0f/a_gamma);
    a = a;

    r = (r < 1.0f) ? r : 1.0f;
    g = (g < 1.0f) ? g : 1.0f;
    b = (b < 1.0f) ? b : 1.0f;
    a = (a < 1.0f) ? a : 1.0f;

    if(r < 0) r = 0;
    if(g < 0) g = 0;
    if(b < 0) b = 0;
    if(a < 0) a = 0;

    unsigned int iR = int(r*255.0f);
    unsigned int iG = int(g*255.0f);
    unsigned int iB = int(b*255.0f);
    unsigned int iA = 255; //int(a*255.0f);

    unsigned resColor = (iR << 0) | (iG << 8) | (iB << 16) | (iA << 24);
    tempData2[i/4] = resColor; 
  }

  ILuint imageName = ilGenImage();
  ilBindImage(imageName);

  ilTexImage(m_width,m_height,1,4,IL_RGBA,IL_UNSIGNED_BYTE, &tempData2[0]);
  ilEnable(IL_FILE_OVERWRITE);
  
  ilSave(IL_PNG, a_fileName.c_str());
  ilDisable(IL_FILE_OVERWRITE);
  ilDeleteImages(1, &imageName); 
}

#endif


void createGaussKernelWeights(int size, std::vector<float>& gKernel, float a_sigma)
{
  gKernel.resize(size*size);

  // set standard deviation to 1.0
  float sigma = a_sigma;
  float s = 2.0 * sigma * sigma;

  // sum is for normalization
  float sum = 0.0;

  int halfSize = size/2;

  // generate 5x5 kernel
  //
  for (int x = -halfSize; x <= halfSize; x++)
  {
    for(int y = -halfSize; y <= halfSize; y++)
    {
      float r = sqrtf(x*x + y*y);
      int index = (y + halfSize)*size + x + halfSize;
      gKernel[index] = (exp(-(r*r)/s))/(3.141592654f * s);
      sum += gKernel[index];
    }
  }

  // normalize the Kernel
  for(int i = 0; i < size; ++i)
    for(int j = 0; j < size; ++j)
      gKernel[i*size+j] /= sum;

 /* std::ofstream gaussFile("D:\\temp\\MultiLayeredBug\\gauss.txt");
  gaussFile.precision(2);
  for(int i = 0; i < size; ++i)
  {
    for(int j = 0; j < size; ++j)
      gaussFile << gKernel[i*size+j] << " ";
    gaussFile << std::endl;
  }
  gaussFile << std::endl;
  */

}


void createGaussKernelWeights1D(int size, std::vector<float>& gKernel, float a_sigma)
{
  gKernel.resize(size);

  // set standard deviation to 1.0
  //
  float sigma = a_sigma;
  float s = 2.0 * sigma * sigma; 

  // sum is for normalization
  float sum = 0.0;
  int halfSize = size/2;

  // generate 5x5 kernel
  //
  for (int x = -halfSize; x <= halfSize; x++)
  {
    float r = sqrtf(x*x);
    int index = x + halfSize;
    gKernel[index] = (exp(-(r)/s))/(3.141592654f * s);
    sum += gKernel[index];
  }

  // normalize the Kernel
  for(int i = 0; i < size; ++i)
    gKernel[i] /= sum;
      
}

