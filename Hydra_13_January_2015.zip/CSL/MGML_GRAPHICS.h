#define MGML_GRAPHICS_GUARDIAN

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif

#ifndef MGML_GUARDIAN
	#include "MGML.h"
#endif


namespace MGML_GRAPHICS
{

typedef MGML_MATH::VECTOR<3,unsigned char> RGB256;

template<int n>
inline universal_call RGB256 REAL_COLOR_TO_RGB256(const MGML_MATH::VECTOR<n,float>& real_color)
{
 //typedef st_assert<(n >= 3)> n_must_be_gt_3;

 float  r = real_color.x*255;
 float  g = real_color.y*255;
 float  b = real_color.z*255;

 ASSERT(r < 256 && r >= 0);
 ASSERT(g < 256 && g >= 0);
 ASSERT(b < 256 && b >= 0);

 RGB256 res;
 res.set(r,g,b);

 return res;
}

template<int n>
inline universal_call MGML_MATH::VECTOR<n,float> RGB256_TO_REAL_COLOR(const RGB256& clr)
{
	MGML_MATH::VECTOR<n,float> res;
	res.x = clr.x;
	res.y = clr.y;
	res.z = clr.z;

	res *= (1.0f/255.0f);

	return res;
}

inline universal_call UINT RGB256_TO_UINT32(const RGB256& clr)
{
	unsigned int result = 0;
	unsigned int red   = clr.x;
	unsigned int green = clr.y;
	unsigned int blue  = clr.z;

	result = red | (green << 8) | (blue << 16);

	return result;
}


inline universal_call MGML_MATH::VECTOR<4,float> UINT32_TO_REAL_COLOR(unsigned int clr)
{
	unsigned char red_b	  = (clr & 0x000000FF);
	unsigned char green_b = (clr & 0x0000FF00) >> 8;
	unsigned char blue_b  = (clr & 0x00FF0000) >> 16;

	float red	= (float)red_b;
	float green = (float)green_b;
	float blue	= (float)blue_b;

	float inv_255 = 1.0f/255.0f;

	MGML_MATH::VECTOR<4,float> res;
	res.set(inv_255*red,inv_255*green,inv_255*blue,1);

	return res;
}

template<int n>
inline universal_call unsigned int REAL_COLOR_TO_UNT32(const MGML_MATH::VECTOR<n,float>& real_color)
{
	float  r = real_color.M[0]*255.0f;
	float  g = real_color.M[1]*255.0f;
	float  b = real_color.M[2]*255.0f;

	//ASSERT(r < 256.0f && r >= 0.0f);
	//ASSERT(g < 256.0f && g >= 0.0f);
	//ASSERT(b < 256.0f && b >= 0.0f);

	unsigned char red = (unsigned char)r, green = (unsigned char)g, blue = (unsigned char)b;
	return red | (green << 8) | (blue << 16);
}


//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////      VERTEX        /////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
template <int n_,class T>
struct VERTEX
{
	MGML_MATH::VECTOR<n_,T> pos;
	MGML_MATH::VECTOR<n_,T> norm;
	MGML_MATH::VECTOR<2,T>  t;

	unsigned int material_id;

#ifndef __CUDACC__
	VERTEX()
	{

	}
#endif

	universal_call VERTEX& operator*=(const MGML_MATH::MATRIX<n_,n_,T>& m)
	{
		pos  = pos*m;
		norm = norm*m;
		norm.Normalize();
		return *this;
	}

	friend universal_call VERTEX operator*(const MGML_MATH::MATRIX<n_,n_,T>& m,const VERTEX& v)
	{
		VERTEX res;
		res.pos  = m*v.pos;
		res.norm = m*v.norm;
		res.norm.Normalize();
		return res;
	}

	inline bool HasSameMaterialAndTextures(const VERTEX& rhs) const
	{
		return material_id == rhs.material_id;
	}

};


};

