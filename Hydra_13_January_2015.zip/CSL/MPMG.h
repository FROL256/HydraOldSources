#define MPMG_GUARDIAN

#ifndef MGML_GLOBALS
	#include "MGML_GLOBALS.h"
#endif

namespace MPMG_INTIMATE
{
 struct Stop
 { static universal_call void exec(){}
   
   template<class Env>
   static universal_call void exec(Env& env){}

   template<class Lhs,class Rhs>
   static universal_call void exec(Lhs& lhs,Rhs& rhs){}
 };


};

// �������������������� 
namespace MPMG
{
static const int DEFAULT  = ~(~0u >> 1); // ���������� ����� int 
static const int endValue = ~(~0u >> 1);


template<bool>
struct STATIC_ASSERT;

template<>
struct STATIC_ASSERT<true> {};


template <typename A, typename B>
struct TypesEqual
{
  enum { RET = false };
};

template<typename A>
struct TypesEqual<A, A>
{
  enum { RET = true };
};

//============================================================== IF
template<bool condition,class Then,class Else>
struct IF
{typedef Then RET;
};

template<class Then,class Else>
struct IF<false,Then,Else>
{ typedef Else RET;
};
//============================================================== IF


//============================================================== SWITCH
struct NilCase {};

template<int tag_,class Type_,class Next_ = NilCase>
struct CASE
{
	enum {tag = tag_};
	typedef Type_ Type;
	typedef Next_ Next;
};

template<int tag,class Case>
class SWITCH
{
	typedef typename Case::Next NextCase;
	enum {
		caseTag = Case::tag,
		found = (caseTag == tag || caseTag == (int)DEFAULT)
	};
public:
	typedef typename IF<found,
		typename Case::Type,
		typename SWITCH<tag,NextCase>::RET
	>::RET RET;
};

template<int tag>
class SWITCH<tag,NilCase>
{
public:
	typedef NilCase RET;
};
//============================================================== SWITCH


};




namespace _MGML_VEC
{
template<class T>
struct ZeroIter
{
   inline static universal_call void exec(T* c,const T* a,const T* b){}
   inline static universal_call void exec(T* c,const T* a,const T b){}
   inline static universal_call void exec(T* c,const T* b){}
   inline static universal_call void exec(T* c,const T b){}
};

};

namespace MGML_MATH
{


//=================================================================================== ��������� ������������
template <int n,class T> 
struct DotMult
{
   inline static universal_call T exec(const T* a,const T* b)
   {
	   return (*a)*(*b) + DotMult<n-1,T>::exec(a+1,b+1);
   }
};

template<class T>
struct DotMult<0,T>
{
   inline static universal_call T exec(const T* a,const T* b)
   {
	   return 0;
   }
};
// \\=================================================================================== ��������� ������������

//=================================================================================== ����������� ��������
template <int n,class T> 
struct MovVec
{
   inline static universal_call void exec(T* a,const T* b)
   {
     *a = *b;
	   MovVec<n-1,T>::exec(a+1,b+1);
   }
};

template<class T>
struct MovVec<0,T>:public _MGML_VEC::ZeroIter<T> { };
// \\ ===================================================================================����������� ��������

//=================================================================================== ����� ��������
template <int n,class T> 
struct AddVec
{
   inline static universal_call void exec(T* c,const T* a,const T* b)
   {
    *c = *a + *b;
	  AddVec<n-1,T>::exec(c+1,a+1,b+1);
   }

   inline static universal_call void exec(T* c,const T* a,const T b)
   {
    *c = *a + b;
	  AddVec<n-1,T>::exec(c+1,a+1,b);
   }

   inline static universal_call void exec(T* c,const T* b)
   {
    *c += *b;
	  AddVec<n-1,T>::exec(c+1,b+1);
   }

   inline static universal_call void exec(T* c,const T b)
   {
    *c += b;
	  AddVec<n-1,T>::exec(c+1,b);
   }
};

template<class T>
struct AddVec<0,T>: public _MGML_VEC::ZeroIter<T> { };
// \\=================================================================================== ����� ��������

//=================================================================================== �������� ��������
template <int n,class T> 
struct SubVec
{
   inline static universal_call void exec(T* c,const T* a,const T* b)
   {
    *c = *a - *b;
     SubVec<n-1,T>::exec(c+1,a+1,b+1);
   }

   inline static universal_call void exec(T* c,const T* a,const T b)
   {
    *c = *a - b;
	  SubVec<n-1,T>::exec(c+1,a+1,b);
   }

   inline static universal_call void exec(T* c,const T* b)
   {
    *c -= *b;
	  SubVec<n-1,T>::exec(c+1,b+1);
   }

   inline static universal_call void exec(T* c,const T b)
   {
    *c -= b;
	  SubVec<n-1,T>::exec(c+1,b);
   }
};

template<class T>
struct SubVec<0,T>: public _MGML_VEC::ZeroIter<T> { };
// \\=================================================================================== �������� ��������

//=================================================================================== �������������� ��������� ��������
template <int n,class T> 
struct MulVec
{
   inline static universal_call void exec(T* c,const T* a,const T* b)
   {
    *c = (*a)*(*b);
     MulVec<n-1,T>::exec(c+1,a+1,b+1);
   }

   inline static universal_call void exec(T* c,const T* a,const T b)
   {
    *c = (*a)*b;
	  MulVec<n-1,T>::exec(c+1,a+1,b);
   }

   inline static universal_call void exec(T* c,const T* b)
   {
    *c *= *b;
	  MulVec<n-1,T>::exec(c+1,b+1);
   }

   inline static universal_call void exec(T* c,const T b)
   {
    *c *= b;
	  MulVec<n-1,T>::exec(c+1,b);
   }
};

template<class T>
struct MulVec<0,T>: public _MGML_VEC::ZeroIter<T> { };
// \\=================================================================================== �������������� ��������� ��������



//=================================================================================== �������������� ������� ��������
template <int n,class T> 
struct DivVec
{
   inline static universal_call void exec(T* c,const T* a,const T* b)
   {
    *c = (*a)/(*b);
     DivVec<n-1,T>::exec(c+1,a+1,b+1);
   }

   inline static universal_call void exec(T* c,const T* a,const T b)
   {
    *c = (*a)/b;
	  DivVec<n-1,T>::exec(c+1,a+1,b);
   }

   inline static universal_call void exec(T* c,const T* b)
   {
    *c /= *b;
	  DivVec<n-1,T>::exec(c+1,b+1);
   }

   inline static universal_call void exec(T* c,const T b)
   {
    *c /= b;
	  DivVec<n-1,T>::exec(c+1,b);
   }
};

template<class T>
struct DivVec<0,T>: public _MGML_VEC::ZeroIter<T> { };
// \\=================================================================================== �������������� ������� ��������

};

