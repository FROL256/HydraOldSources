#pragma once

#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

struct HDRImage
{
public:

  HDRImage() : m_channels(4), m_width(0), m_height(0) {}

  HDRImage(int w, int h, int channels, const float* data);

  inline int width()  const { return m_width;}
  inline int height() const { return m_height;}
  inline int channels() const { return m_channels;}

  const std::vector<float>& data() const { return m_data; }
  std::vector<float>& data() { return m_data; }

  void loadFromImage4f(const std::string& a_fileName);
  
#ifndef ML_PRODUCTION
  void saveToHDR(const std::string& a_fileName, float a_gamma);
  void saveToPNG(const std::string& a_fileName, float a_gamma);
#endif

  void blend(const HDRImage& a_image, float c1, float c2);
  void add(const HDRImage& a_image) { blend(a_image, 1.0f, 1.0f); }
  void mul(const HDRImage& a_image, float c1);
  void mul(float c1);

  void gaussBlur(int radius, float sigma);

private:

  int m_width;
  int m_height;
  int m_channels;
  std::vector<float> m_data;

};

void createGaussKernelWeights(int size, std::vector<float>& gKernel, float a_sigma);
void createGaussKernelWeights1D(int size, std::vector<float>& gKernel, float a_sigma);

