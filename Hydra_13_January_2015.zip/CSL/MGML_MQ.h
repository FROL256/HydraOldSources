// � Copyright 2008 �������� ������
#define MGML_MQ_GUARDIAN

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif

namespace MGML_MATH
{



// ������ ��� � ������. �����, ����� �������� ������� �� ����.
// ��� ��������� ��������� �������
// do_matrix_noise<n*m,T>::exec(L);
template<int n,class T>
struct do_matrix_noise
{
 static universal_call void exec(T* L) {}
};


template<int n>
struct do_matrix_noise<n,float>
{
 inline static float rnd(float s, float e)
 {
   float t = (float)rand()/32767.0f;
   return s + t*(e-s);
 }

 static universal_call void exec(float* L)
 {
#ifndef __CUDACC__
	 for(int i=0;i<n;i++)
		 L[i] += rnd(0.00001f,0.00002f);
#else
	 ASSERT(false);
#endif
 }

};


template<int n>
struct do_matrix_noise<n,double>
{
 inline static float rnd(float s, float e)
 {
   float t = (float)rand()/32767.0f;
   return s + t*(e-s);
 }

 static universal_call void exec(double* L)
 {
#ifndef __CUDACC__
	 for(int i=0;i<n;i++)
		 L[i] += rnd(0.0000001,0.0000002);
#else
	 ASSERT(false);
#endif
 }

};



template<class T>
class MATRIX4X4
{
private:

	typedef const T CT;
  enum {m=4, n=4};

public:

  union
  {
    T L[16];
    T M[4][4];
    struct
    {
      T  M00,M01,M02,M03;
      T  M10,M11,M12,M13;
      T  M20,M21,M22,M23;
      T  M30,M31,M32,M33;
    };
  };

	inline universal_call MATRIX4X4() { for(int i=0;i<16;i++) this->L[i] = 0; this->M00 = 1; this->M11 = 1; this->M22 = 1; this->M33= 1; }
	inline universal_call MATRIX4X4(const T* p) { for(int i=0;i<n*m;i++) this->L[i]=p[i]; }

	inline universal_call MATRIX4X4(CT a00,CT a01,CT a02,CT a03,
				                          CT a10,CT a11,CT a12,CT a13,
				                          CT a20,CT a21,CT a22,CT a23,
				                          CT a30,CT a31,CT a32,CT a33)
  {
    M00 = a00; M01 = a01; M02 = a02; M03 = a03;
    M10 = a10; M11 = a11; M12 = a12; M13 = a13;
    M20 = a20; M21 = a21; M22 = a22; M23 = a23;
    M30 = a30; M31 = a31; M32 = a32; M33 = a33;
  }

  inline universal_call void setScale(CT a,CT b,CT c) { M00 = a; M11 = b; M22 = c; }
  inline universal_call void swapRows(int r1,int r2);
  inline universal_call void add_row(int which,int to,int j,T k) { for(register int i=j;i<n;i++) this->M[to][i] += this->M[which][i]*k; }

  inline universal_call void Zero() { for(register int i=0;i<n*m;i++) this->L[i] = 0;}
  inline universal_call void Identity() {Zero();for(register int i=0;i<n;i++) this->M[i][i] =1; }

	inline universal_call void SetRow(const int r,const VECTOR<n,T>& v) { for(int i=0;i<n;i++) this->M[r][i] = v.M[i]; }
	inline universal_call void SetCol(const int r,const VECTOR<m,T>& v) { for(int i=0;i<m;i++) this->M[i][r] = v.M[i]; }

	inline universal_call VECTOR<4,T> GetRow(const int r)       const { return VECTOR<4,T>(M[r][0], M[r][1], M[r][2], M[r][3]); }
	inline universal_call const VECTOR<m,T> GetCol(const int r) const { return VECTOR<4,T>(M[0][r], M[1][r], M[2][r], M[3][r]); }

	inline universal_call void SetScale(const VECTOR<3,T>& vec) { for(int i=0;i<3;i++) this->M[i][i] = vec.M[i]; }
  inline universal_call void SetScale(const VECTOR<4,T>& vec) { for(int i=0;i<4;i++) this->M[i][i] = vec.M[i]; }

  inline universal_call void SetTranslate(const VECTOR<3,T>& v) { this->M03 = v.x; this->M13 = v.y; this->M23 = v.z; this->M33 = 1; }
  inline universal_call void SetTranslate(const VECTOR<4,T>& v) { this->M03 = v.x; this->M13 = v.y; this->M23 = v.z; this->M33 = v.w; }

	inline universal_call void Transpose()
  {
    for(int j=1;j<n;j++)
    {
      for(int i=0;i<j;i++)
      {
        T tmp = this->M[i][j];
        this->M[i][j] = this->M[j][i];
        this->M[j][i] = tmp;
      }
    }
  }

  inline universal_call T det();
	inline universal_call void Inverse();

	inline universal_call MATRIX4X4<T> GetTranspose() const { MATRIX4X4<T> temp(*this); temp.Transpose(); return temp; }
	inline universal_call MATRIX4X4<T> GetInverse() const { MATRIX4X4<T> temp(*this); temp.Inverse(); return temp; }

  inline universal_call void SetRotation(T theta, const VECTOR<3,T>& a_v)
  {
    Identity();

    VECTOR<3,T> v = normalize(a_v);

    float cos_t = cos(theta);
    float sin_t = sin(theta);

    this->M[0][0] = (1.0f-cos_t)*v.x*v.x + cos_t;
    this->M[0][1] = (1.0f-cos_t)*v.x*v.y - sin_t*v.z;
    this->M[0][2] = (1.0f-cos_t)*v.x*v.z + sin_t*v.y;

    this->M[1][0] = (1.0f-cos_t)*v.y*v.x + sin_t*v.z;
    this->M[1][1] = (1.0f-cos_t)*v.y*v.y + cos_t;
    this->M[1][2] = (1.0f-cos_t)*v.y*v.z - sin_t*v.x;

    this->M[2][0] = (1.0f-cos_t)*v.x*v.z - sin_t*v.y;
    this->M[2][1] = (1.0f-cos_t)*v.z*v.y + sin_t*v.x;
    this->M[2][2] = (1.0f-cos_t)*v.z*v.z + cos_t;
  }

	inline universal_call void SetRotationX(T ang);
	inline universal_call void SetRotationY(T ang);
	inline universal_call void SetRotationZ(T ang);

	inline universal_call void SetRotationXYZ(T ang_x,T ang_y,T ang_z);
	inline universal_call void SetRotationXYZ(const VECTOR<3,T>& v) { SetRotationXYZ(v.x, v.y, v.z); }
	inline universal_call void SetRotationXYZ(const T* p)			{ SetRotationXYZ(p[0],p[1],p[2]); }

	inline universal_call void SetRotationYXZ(T x_ang,T y_ang,T z_ang);
	inline universal_call void SetRotationYXZ(const VECTOR<3,T>& v) { SetRotationYXZ(v.x, v.y, v.z);}
	inline universal_call void SetRotationYXZ(const T* p)			{ SetRotationYXZ(p[0],p[1],p[2]);}

  inline universal_call MATRIX4X4<T> operator*(const MATRIX4X4<T>& m2) const
  {
    MATRIX4X4<T> ret; ret.Zero();
    for(register int i=0; i < 4; i++)
      for(register int j=0; j < 4; j++)
        for(register int c=0; c < 4; c++)
          ret.M[i][j]+=this->M[i][c]*m2.M[c][j];
    return ret;
  }

  inline universal_call MATRIX4X4<T>& operator+=(const MATRIX4X4<T>& rhs)
  {
    for(int i=0;i<16;i++)
      this->L[i] += rhs.L[i];
    return *this;
  }

#ifndef __CUDACC__
  void print(std::ostream& out) const;
#endif

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class T> std::ostream& operator<<(std::ostream& out, const MATRIX4X4<T>& mat) { mat.print(out); return out; }

template<class T> std::istream& operator>>(std::istream& in, MATRIX4X4<T>& mat)
{
  for(int i=0;i<4;i++)
    for(int j=0;j<4;j++)
      in >> mat.M[i][j];
  return in;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class T> class QUATERNION: public VECTOR<4,T>
{
  // ��� ������� ����� ���������� ��� �����������.
  T dot(const VECTOR<4,T>& v1) {return 0;}

public:

  inline universal_call QUATERNION(const T a,const T b,const T c,const T d): MGML_MATH::VECTOR<4,T>(a,b,c,d){}
  inline universal_call QUATERNION(): MGML_MATH::VECTOR<4,T>(){}

  inline universal_call void set(const VECTOR<3,T>& axis,T theta);
  inline universal_call void set(const VECTOR<3,T>& from,const VECTOR<3,T>& to);
  inline universal_call void set(const MATRIX4X4<T>& m);
  inline universal_call const MATRIX4X4<T> toMatrix() const;

  inline universal_call QUATERNION<T>& operator=(const VECTOR<4,T>& q);
  inline universal_call QUATERNION<T>& operator*=(const QUATERNION<T>& qr);
  inline universal_call QUATERNION<T>  operator*(const QUATERNION<T>& qr) const;

  friend universal_call const VECTOR<3,T> operator*(const VECTOR<3,T>& vec,const QUATERNION<T>& q)
  {
    ASSERT(false);
    return 0;
  }

};



static MATRIX4X4<float> MatrixFromString(const std::string in_str)
{
  MATRIX4X4<float> r;

  sscanf(in_str.c_str(),"%f %f %f %f \
                         %f %f %f %f \
                         %f %f %f %f \
                         %f %f %f %f",
                         &r.L[0], &r.L[1], &r.L[2], &r.L[3],
                         &r.L[4], &r.L[5], &r.L[6], &r.L[7],
                         &r.L[8], &r.L[9], &r.L[10], &r.L[11],
                         &r.L[12], &r.L[13], &r.L[14], &r.L[15]);

  return r;
}


};




///////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////  MATRIX   ////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

// =================================================================================
//
// =================================================================================
template<class T>
universal_call void MGML_MATH::MATRIX4X4<T>::print(std::ostream& out) const
{
 for(int i=0;i<n;i++)
 {
	 for(int j=0;j<m;j++)
		 out << this->M[i][j] << " ";
	 out << std::endl;
 }
}

// =================================================================================
//
// =================================================================================
template<class T>
inline universal_call void MGML_MATH::MATRIX4X4<T>::SetRotationX(T ang)
{
 Identity();
 T sinx = sin(ang);
 T cosx = cos(ang);
 this->M11=cosx; this->M12=sinx;
 this->M21=-sinx;this->M22=cosx;
}
// =================================================================================
//
// =================================================================================
template<class T>
inline universal_call void MGML_MATH::MATRIX4X4<T>::SetRotationY(T ang)
{
 Identity();
 T siny = sin(ang);
 T cosy = cos(ang);
 this->M00=cosy;this->M02=-siny;
 this->M20=siny;this->M22=cosy;
}
// =================================================================================
//
// =================================================================================
template<class T>
inline universal_call void MGML_MATH::MATRIX4X4<T>::SetRotationZ(T ang)
{
 Identity();
 T sinz = sin(ang);
 T cosz = cos(ang);
 this->M00=cosz; this->M01=sinz;
 this->M10=-sinz;this->M11=cosz;
}
// =================================================================================
//
// =================================================================================
template<class T>
inline universal_call void MGML_MATH::MATRIX4X4<T>::SetRotationXYZ(T x_ang,T y_ang,T z_ang)
{
	MATRIX4X4<T> mx,my,mz;
	mx.SetRotationX(x_ang);
	my.SetRotationY(y_ang);
	mz.SetRotationZ(z_ang);
	*this = mx*my*mz;
}

// =================================================================================
//
// =================================================================================
template<class T>
inline universal_call void MGML_MATH::MATRIX4X4<T>::SetRotationYXZ(T x_ang,T y_ang,T z_ang)
{
	MATRIX4X4<T> mx,my,mz;
	mx.SetRotationX(x_ang);
	my.SetRotationY(y_ang);
	mz.SetRotationZ(z_ang);
	*this = my*mx*mz;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////  SquareMatrix   //////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
// =================================================================================
//
// =================================================================================
template<class T>
inline universal_call void MGML_MATH::MATRIX4X4<T>::swapRows(int r1,int r2)
{
	// optimization needed
	for(int i=0;i<m;i++)
	{
		T tmp = this->M[r1][i];
		this->M[r1][i] = this->M[r2][i];
		this->M[r2][i] = tmp;
		//MGML_MATH::SWAP(this->M[r1][i],this->M[r2][i]);
	}

}
// =================================================================================
//
// =================================================================================
template<class T>
universal_call T MGML_MATH::MATRIX4X4<T>::det()
{
 // ������ ��� ������ ������ � ������� �� �������� �������� � �������
 // ��� ��� ������ �������� �� �����, ����� �������� �������� �� ��������
 {for(register int i=0;i<n-1;i++)
  {

	 if(this->M[i][i]*this->M[i][i] < EPSILON_E10M)
	 {
		 bool flag = false;
		 for(register int j=i;j<n;j++)
		  if(this->M[i][j]*this->M[i][i] > EPSILON_E10M)
		   { this->swapRows(i,j); flag = true; break;}
		 if(!flag)
		 {
			#ifndef __CUDACC__
				throw std::runtime_error("Attempt to get determinant of singular matrix");
			#else
				return 0;
			#endif
		 }
	 }
	 // ������� ���� � �������
	 for(register int j=i+1;j<n;j++)
	 {
      T w = -this->M[j][i]/this->M[i][i];
	  add_row(i,j,i,w);
	 }

  }}

 T _det = 1;
 for(register int i=0;i<n;i++) _det *= this->M[i][i];
 return _det;
}

// =================================================================================
//
// =================================================================================
template<class T>
universal_call void MGML_MATH::MATRIX4X4<T>::Inverse()
{
  T tmp[12]; // temp array for pairs
  MATRIX4X4<T> m;
  MATRIX4X4<T>& m1 = (*this);

  // calculate pairs for first 8 elements (cofactors)
  //
  tmp[0]  = m1.M[2][2] * m1.M[3][3];
  tmp[1]  = m1.M[2][3] * m1.M[3][2];
  tmp[2]  = m1.M[2][1] * m1.M[3][3];
  tmp[3]  = m1.M[2][3] * m1.M[3][1];
  tmp[4]  = m1.M[2][1] * m1.M[3][2];
  tmp[5]  = m1.M[2][2] * m1.M[3][1];
  tmp[6]  = m1.M[2][0] * m1.M[3][3];
  tmp[7]  = m1.M[2][3] * m1.M[3][0];
  tmp[8]  = m1.M[2][0] * m1.M[3][2];
  tmp[9]  = m1.M[2][2] * m1.M[3][0];
  tmp[10] = m1.M[2][0] * m1.M[3][1];
  tmp[11] = m1.M[2][1] * m1.M[3][0];

  // calculate first 8 m1.Ments (cofactors)
  //
  m.M[0][0]  = tmp[0] * m1.M[1][1] + tmp[3] * m1.M[1][2] + tmp[4]  * m1.M[1][3];
  m.M[0][0] -= tmp[1] * m1.M[1][1] + tmp[2] * m1.M[1][2] + tmp[5]  * m1.M[1][3];
  m.M[1][0]  = tmp[1] * m1.M[1][0] + tmp[6] * m1.M[1][2] + tmp[9]  * m1.M[1][3];
  m.M[1][0] -= tmp[0] * m1.M[1][0] + tmp[7] * m1.M[1][2] + tmp[8]  * m1.M[1][3];
  m.M[2][0]  = tmp[2] * m1.M[1][0] + tmp[7] * m1.M[1][1] + tmp[10] * m1.M[1][3];
  m.M[2][0] -= tmp[3] * m1.M[1][0] + tmp[6] * m1.M[1][1] + tmp[11] * m1.M[1][3];
  m.M[3][0]  = tmp[5] * m1.M[1][0] + tmp[8] * m1.M[1][1] + tmp[11] * m1.M[1][2];
  m.M[3][0] -= tmp[4] * m1.M[1][0] + tmp[9] * m1.M[1][1] + tmp[10] * m1.M[1][2];
  m.M[0][1]  = tmp[1] * m1.M[0][1] + tmp[2] * m1.M[0][2] + tmp[5]  * m1.M[0][3];
  m.M[0][1] -= tmp[0] * m1.M[0][1] + tmp[3] * m1.M[0][2] + tmp[4]  * m1.M[0][3];
  m.M[1][1]  = tmp[0] * m1.M[0][0] + tmp[7] * m1.M[0][2] + tmp[8]  * m1.M[0][3];
  m.M[1][1] -= tmp[1] * m1.M[0][0] + tmp[6] * m1.M[0][2] + tmp[9]  * m1.M[0][3];
  m.M[2][1]  = tmp[3] * m1.M[0][0] + tmp[6] * m1.M[0][1] + tmp[11] * m1.M[0][3];
  m.M[2][1] -= tmp[2] * m1.M[0][0] + tmp[7] * m1.M[0][1] + tmp[10] * m1.M[0][3];
  m.M[3][1]  = tmp[4] * m1.M[0][0] + tmp[9] * m1.M[0][1] + tmp[10] * m1.M[0][2];
  m.M[3][1] -= tmp[5] * m1.M[0][0] + tmp[8] * m1.M[0][1] + tmp[11] * m1.M[0][2];

  // calculate pairs for second 8 m1.Ments (cofactors)
  //
  tmp[0]  = m1.M[0][2] * m1.M[1][3];
  tmp[1]  = m1.M[0][3] * m1.M[1][2];
  tmp[2]  = m1.M[0][1] * m1.M[1][3];
  tmp[3]  = m1.M[0][3] * m1.M[1][1];
  tmp[4]  = m1.M[0][1] * m1.M[1][2];
  tmp[5]  = m1.M[0][2] * m1.M[1][1];
  tmp[6]  = m1.M[0][0] * m1.M[1][3];
  tmp[7]  = m1.M[0][3] * m1.M[1][0];
  tmp[8]  = m1.M[0][0] * m1.M[1][2];
  tmp[9]  = m1.M[0][2] * m1.M[1][0];
  tmp[10] = m1.M[0][0] * m1.M[1][1];
  tmp[11] = m1.M[0][1] * m1.M[1][0];

  // calculate second 8 m1.Ments (cofactors)
  //
  m.M[0][2]  = tmp[0]  * m1.M[3][1] + tmp[3]  * m1.M[3][2] + tmp[4]  * m1.M[3][3];
  m.M[0][2] -= tmp[1]  * m1.M[3][1] + tmp[2]  * m1.M[3][2] + tmp[5]  * m1.M[3][3];
  m.M[1][2]  = tmp[1]  * m1.M[3][0] + tmp[6]  * m1.M[3][2] + tmp[9]  * m1.M[3][3];
  m.M[1][2] -= tmp[0]  * m1.M[3][0] + tmp[7]  * m1.M[3][2] + tmp[8]  * m1.M[3][3];
  m.M[2][2]  = tmp[2]  * m1.M[3][0] + tmp[7]  * m1.M[3][1] + tmp[10] * m1.M[3][3];
  m.M[2][2] -= tmp[3]  * m1.M[3][0] + tmp[6]  * m1.M[3][1] + tmp[11] * m1.M[3][3];
  m.M[3][2]  = tmp[5]  * m1.M[3][0] + tmp[8]  * m1.M[3][1] + tmp[11] * m1.M[3][2];
  m.M[3][2] -= tmp[4]  * m1.M[3][0] + tmp[9]  * m1.M[3][1] + tmp[10] * m1.M[3][2];
  m.M[0][3]  = tmp[2]  * m1.M[2][2] + tmp[5]  * m1.M[2][3] + tmp[1]  * m1.M[2][1];
  m.M[0][3] -= tmp[4]  * m1.M[2][3] + tmp[0]  * m1.M[2][1] + tmp[3]  * m1.M[2][2];
  m.M[1][3]  = tmp[8]  * m1.M[2][3] + tmp[0]  * m1.M[2][0] + tmp[7]  * m1.M[2][2];
  m.M[1][3] -= tmp[6]  * m1.M[2][2] + tmp[9]  * m1.M[2][3] + tmp[1]  * m1.M[2][0];
  m.M[2][3]  = tmp[6]  * m1.M[2][1] + tmp[11] * m1.M[2][3] + tmp[3]  * m1.M[2][0];
  m.M[2][3] -= tmp[10] * m1.M[2][3] + tmp[2]  * m1.M[2][0] + tmp[7]  * m1.M[2][1];
  m.M[3][3]  = tmp[10] * m1.M[2][2] + tmp[4]  * m1.M[2][0] + tmp[9]  * m1.M[2][1];
  m.M[3][3] -= tmp[8]  * m1.M[2][1] + tmp[11] * m1.M[2][2] + tmp[5]  * m1.M[2][0];

  // calculate matrix inverse
  //
  float k = 1.0f / (m1.M[0][0] * m.M[0][0] + m1.M[0][1] * m.M[1][0] + m1.M[0][2] * m.M[2][0] + m1.M[0][3] * m.M[3][0]);

  for(int i=0;i<16;i++)
    m.L[i] *= k;

  (*this) = m;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////     QUATERNION   //////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
//=======================================================
// �������� =
//=======================================================
template<class T>
inline universal_call MGML_MATH::QUATERNION<T>& MGML_MATH::QUATERNION<T>::operator=(const VECTOR<4,T>& q)
{
	this->x=q.M[0];
	this->y=q.M[1];
	this->z=q.M[2];
	this->w=q.M[3];
	return *this;
}
//=======================================================
// ������������� ������� �� �������, �� ���� ��������
// ���� ��������� � ���� ��������
//=======================================================
template<class T>
inline universal_call void MGML_MATH::QUATERNION<T>::set(const VECTOR<3,T>& axis,T theta)
{
  T sqnorm = axis.lenSquare();

   if (sqnorm <= EPSILON_E5M)
   {
     // axis too small.
     this->x = this->y = this->z = 0.0;
	 this->w = 1;
   }
   else
   {
     theta /= 2;
     T sin_theta = (T)(sin(theta));

     if(fabs(sqnorm-1) > EPSILON_E5M)
        sin_theta /= (T)(sqrt(sqnorm));

     this->x = sin_theta * axis.M[0]; // SIMD
     this->y = sin_theta * axis.M[1];
     this->z = sin_theta * axis.M[2];
     this->w = (T)(cos(theta));
  }
}
// =================================================================================
//
// =================================================================================
template <class T>
inline universal_call void MGML_MATH::QUATERNION<T>::set(const MATRIX4X4<T>& m)
{
  T tr, s;
  const int nxt[3] = { 1, 2, 0 };
  tr = m.M[0][0] + m.M[1][1] + m.M[2][2];

  if ( tr > 0 )
  {
    s = (T)(sqrt( tr + m.M[3][3] ));
    this->M[3] = (T) ( s * 0.5 );
    s = (T)(0.5) / s;

    this->M[0] = (T)( ( m.M[1][2] - m.M[2][1] ) * s ); // SIMD
    this->M[1] = (T)( ( m.M[2][0] - m.M[0][2] ) * s );
    this->M[2] = (T)( ( m.M[0][1] - m.M[1][0] ) * s );
  }
  else
  {
    register int i = 0,j,k;
    if ( m.M[1][1] > m.M[0][0] )
              i = 1;

    if ( m.M[2][2] > m.M[i][i] )
              i = 2;

     j = nxt[i];
     k = nxt[j];

     s = (T)(sqrt( ( m.M[i][j] - ( m.M[j][j] + m.M[k][k] )) + 1));

     this->M[i] = (T)( s * 0.5 );
     s = (T)(0.5 / s);

     this->M[3] = (T)( ( m.M[j][k] - m.M[k][j] ) * s ); // SIMD
     this->M[j] = (T)( ( m.M[i][j] + m.M[j][i] ) * s );
     this->M[k] = (T)( ( m.M[i][k] + m.M[k][i] ) * s );
  }
}
// =================================================================================
//
// =================================================================================

