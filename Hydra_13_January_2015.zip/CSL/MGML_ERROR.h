# pragma once

#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <windows.h>

#include <stdexcept>

namespace MGML_ERROR
{

 template<class T>
 void DumpBuffer(const T* buff, int size, const std::string& fileName)
 {
   std::ofstream out(fileName.c_str(), std::ios::binary);
   out.write(buff, size*sizeof(T));
   out.close();
 }

 template<class T>
 int CompareBuffer(const T* buff, int size, const std::string& fileName)
 {
   T* tempBuff = new T[size];
   std::ifstream in(fileName.c_str(), std::ios::binary);
   in.read(tempBuff,size*sizeof(T));

   for(int i=0;i<size;i++)
   {
     if (tempBuff[i] != buff[i])
     {
       delete [] tempBuff;
       return i;
     }
   }
   in.close();

   delete [] tempBuff;
   return size;
 }


 static void ALERT(const std::string& err_msg)
 {

#ifdef UNICODE
	 MessageBox(NULL,(LPCWSTR)err_msg.c_str(),(LPCWSTR)"ALERT!",MB_ICONERROR);
#else
	 MessageBox(NULL,(LPCSTR)err_msg.c_str(),(LPCSTR)"ALERT!",MB_ICONERROR);
#endif
 }

 static void ALERT(const std::string& err_msg1,const std::string& err_msg2)
 {

#ifdef UNICODE
	 MessageBox(NULL,(LPCWSTR)err_msg2.c_str(),(LPCWSTR)err_msg1.c_str(),MB_ICONERROR);
#else
	 MessageBox(NULL,(LPCSTR)err_msg2.c_str(),(LPCSTR)err_msg1.c_str(),MB_ICONERROR);
#endif
 }

 static std::string ToString(int i)
 {
  std::stringstream out;
  out << i;
	return out.str();
 }

 static std::string ToString(float i)
 {
  std::stringstream out;
  out << i;
	return out.str();
 }

 static std::string ToString(unsigned int i)
 {
   std::stringstream out;
   out << i;
   return out.str();
 }



 static std::string NotEnoughMemory(bool videoMem = false)
 {
  int choice = (rand()*GetTickCount())%100;
  if(videoMem)
  {
      if(choice > 50)
        return std::string("Required more minerals!");
      else
        return std::string("Required more vespren gas!");
  }
  else
  {
    if(choice > 66)
      return std::string("Additional supply deports required!");
    else if(choice > 33)
      return std::string("You must construct additional pylons!");
    else
      return std::string("Spawn more overlords!");
  }
 }

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////


 static void RunTimeError(const char* file, int line, std::string msg)
 {
   throw std::runtime_error(std::string("Run time error at ") + file + std::string(", line ") + ToString(line) + ": " + msg);
 }


};


#undef  RUN_TIME_ERROR
#define RUN_TIME_ERROR(e) (MGML_ERROR::RunTimeError(__FILE__,__LINE__,(e)))

#undef  RUN_TIME_ERROR_AT
#define RUN_TIME_ERROR_AT(e, file, line) (MGML_ERROR::RunTimeError((file),(line),(e)))



#undef  ASSERT
#ifdef  NDEBUG
#define ASSERT(_expression) ((void)0)
#else
#define ASSERT(_expression) if(!(_expression)) RUN_TIME_ERROR_AT("Assertion Failed", __FILE__, __LINE__)
#endif

#define VERIFY(cond) if(!(cond)) RUN_TIME_ERROR("Verification failed");
#define SAFE_CALL(call) try { (call); } catch(...) { std::cerr << "Error at: " << __FILE__ << ", line: " << __LINE__ << std::endl; throw;  }

