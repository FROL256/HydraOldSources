#define MGML_GUARDIAN

#ifndef __CUDACC__

  #define WIN32_LEAN_AND_MEAN
//	#include <d3d9.h>
	#include <string>
	#include <vector>
	#include <list>
	#include <map>
	#include <fstream>
	#include <algorithm>
	#include <windows.h>

  #include <gl/glew.h>
	#include <gl/freeglut.h>

#else

typedef unsigned int UINT;
typedef unsigned char BYTE;

#define _RDTSC(ts) \
		__asm rdtsc \
		__asm mov DWORD PTR [ts], eax \
		__asm mov DWORD PTR [ts+4], edx

#endif

typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  BYTE;

//typedef unsigned short uint16;
//typedef unsigned int uint32;
//typedef unsigned long long int uint64;

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif


#ifndef MGML_MATH_INTERSECTIONS_GUARDIAN
	#include "MGML_MATH_INTERSECTIONS.h"
#endif

#ifndef MGML_GRAPHICS
	#include "MGML_GRAPHICS.h"
#endif


#ifndef __CUDACC__

  #include "MGML_ERROR.h"
  #include "MGML_MEMORY.h"
  #include <map>

#endif

#include "HDRImage.h"

namespace MGML
{

	typedef MGML_MATH::VECTOR<2,float> vec2f;
	typedef MGML_MATH::VECTOR<3,float> vec3f;
	typedef MGML_MATH::VECTOR<4,float> vec4f;

	typedef MGML_MATH::VECTOR<2,double> vec2d;
	typedef MGML_MATH::VECTOR<3,double> vec3d;
	typedef MGML_MATH::VECTOR<4,double> vec4d;

	typedef MGML_MATH::VECTOR<2,int> vec2i;
	typedef MGML_MATH::VECTOR<3,int> vec3i;
	typedef MGML_MATH::VECTOR<4,int> vec4i;

	typedef MGML_MATH::VECTOR<2,UINT> vec2ui;
	typedef MGML_MATH::VECTOR<3,UINT> vec3ui;
	typedef MGML_MATH::VECTOR<4,UINT> vec4ui;

	typedef MGML_MATH::VECTOR<2,unsigned char> vec2ub;
	typedef MGML_MATH::VECTOR<3,unsigned char> vec3ub;
	typedef MGML_MATH::VECTOR<4,unsigned char> vec4ub;

	typedef MGML_MATH::MATRIX4X4<float>  Matrix4x4f;

	
  typedef MGML_MATH::SPHERE<3,float>	  Sphere3f;
	typedef MGML_MATH::SPHERE<4,float>	  Sphere4f;

  typedef MGML_MATH::PACKED_SPHERE3<float>  PackedSphere3f;
	typedef MGML_MATH::PACKED_SPHERE3<double> PackedSphere3d;

	typedef MGML_MATH::AABB<4,float>	    AABB4f;
	typedef MGML_MATH::AABB<3,float>	    AABB3f;


	typedef MGML_GRAPHICS::VERTEX<3,float>  Vertex3f;
	typedef MGML_GRAPHICS::VERTEX<4,float>  Vertex4f;

	inline universal_call vec3f to_vec3f(const vec4f& rhs) { return vec3f(rhs.M[0],rhs.M[1],rhs.M[2]); }

  static Matrix4x4f SafeInverse(const Matrix4x4f& m1)
  {
    float tmp[12]; // temp array for pairs
    Matrix4x4f m;

    // calculate pairs for first 8 elements (cofactors)
    //
    tmp[0]  = m1.M[2][2] * m1.M[3][3];
    tmp[1]  = m1.M[2][3] * m1.M[3][2];
    tmp[2]  = m1.M[2][1] * m1.M[3][3];
    tmp[3]  = m1.M[2][3] * m1.M[3][1];
    tmp[4]  = m1.M[2][1] * m1.M[3][2];
    tmp[5]  = m1.M[2][2] * m1.M[3][1];
    tmp[6]  = m1.M[2][0] * m1.M[3][3];
    tmp[7]  = m1.M[2][3] * m1.M[3][0];
    tmp[8]  = m1.M[2][0] * m1.M[3][2];
    tmp[9]  = m1.M[2][2] * m1.M[3][0];
    tmp[10] = m1.M[2][0] * m1.M[3][1];
    tmp[11] = m1.M[2][1] * m1.M[3][0];

    // calculate first 8 m1.Ments (cofactors)
    //
    m.M[0][0]  = tmp[0] * m1.M[1][1] + tmp[3] * m1.M[1][2] + tmp[4]  * m1.M[1][3];
    m.M[0][0] -= tmp[1] * m1.M[1][1] + tmp[2] * m1.M[1][2] + tmp[5]  * m1.M[1][3];
    m.M[1][0]  = tmp[1] * m1.M[1][0] + tmp[6] * m1.M[1][2] + tmp[9]  * m1.M[1][3];
    m.M[1][0] -= tmp[0] * m1.M[1][0] + tmp[7] * m1.M[1][2] + tmp[8]  * m1.M[1][3];
    m.M[2][0]  = tmp[2] * m1.M[1][0] + tmp[7] * m1.M[1][1] + tmp[10] * m1.M[1][3];
    m.M[2][0] -= tmp[3] * m1.M[1][0] + tmp[6] * m1.M[1][1] + tmp[11] * m1.M[1][3];
    m.M[3][0]  = tmp[5] * m1.M[1][0] + tmp[8] * m1.M[1][1] + tmp[11] * m1.M[1][2];
    m.M[3][0] -= tmp[4] * m1.M[1][0] + tmp[9] * m1.M[1][1] + tmp[10] * m1.M[1][2];
    m.M[0][1]  = tmp[1] * m1.M[0][1] + tmp[2] * m1.M[0][2] + tmp[5]  * m1.M[0][3];
    m.M[0][1] -= tmp[0] * m1.M[0][1] + tmp[3] * m1.M[0][2] + tmp[4]  * m1.M[0][3];
    m.M[1][1]  = tmp[0] * m1.M[0][0] + tmp[7] * m1.M[0][2] + tmp[8]  * m1.M[0][3];
    m.M[1][1] -= tmp[1] * m1.M[0][0] + tmp[6] * m1.M[0][2] + tmp[9]  * m1.M[0][3];
    m.M[2][1]  = tmp[3] * m1.M[0][0] + tmp[6] * m1.M[0][1] + tmp[11] * m1.M[0][3];
    m.M[2][1] -= tmp[2] * m1.M[0][0] + tmp[7] * m1.M[0][1] + tmp[10] * m1.M[0][3];
    m.M[3][1]  = tmp[4] * m1.M[0][0] + tmp[9] * m1.M[0][1] + tmp[10] * m1.M[0][2];
    m.M[3][1] -= tmp[5] * m1.M[0][0] + tmp[8] * m1.M[0][1] + tmp[11] * m1.M[0][2];

    // calculate pairs for second 8 m1.Ments (cofactors)
    //
    tmp[0]  = m1.M[0][2] * m1.M[1][3];
    tmp[1]  = m1.M[0][3] * m1.M[1][2];
    tmp[2]  = m1.M[0][1] * m1.M[1][3];
    tmp[3]  = m1.M[0][3] * m1.M[1][1];
    tmp[4]  = m1.M[0][1] * m1.M[1][2];
    tmp[5]  = m1.M[0][2] * m1.M[1][1];
    tmp[6]  = m1.M[0][0] * m1.M[1][3];
    tmp[7]  = m1.M[0][3] * m1.M[1][0];
    tmp[8]  = m1.M[0][0] * m1.M[1][2];
    tmp[9]  = m1.M[0][2] * m1.M[1][0];
    tmp[10] = m1.M[0][0] * m1.M[1][1];
    tmp[11] = m1.M[0][1] * m1.M[1][0];

    // calculate second 8 m1.Ments (cofactors)
    //
    m.M[0][2]  = tmp[0]  * m1.M[3][1] + tmp[3]  * m1.M[3][2] + tmp[4]  * m1.M[3][3];
    m.M[0][2] -= tmp[1]  * m1.M[3][1] + tmp[2]  * m1.M[3][2] + tmp[5]  * m1.M[3][3];
    m.M[1][2]  = tmp[1]  * m1.M[3][0] + tmp[6]  * m1.M[3][2] + tmp[9]  * m1.M[3][3];
    m.M[1][2] -= tmp[0]  * m1.M[3][0] + tmp[7]  * m1.M[3][2] + tmp[8]  * m1.M[3][3];
    m.M[2][2]  = tmp[2]  * m1.M[3][0] + tmp[7]  * m1.M[3][1] + tmp[10] * m1.M[3][3];
    m.M[2][2] -= tmp[3]  * m1.M[3][0] + tmp[6]  * m1.M[3][1] + tmp[11] * m1.M[3][3];
    m.M[3][2]  = tmp[5]  * m1.M[3][0] + tmp[8]  * m1.M[3][1] + tmp[11] * m1.M[3][2];
    m.M[3][2] -= tmp[4]  * m1.M[3][0] + tmp[9]  * m1.M[3][1] + tmp[10] * m1.M[3][2];
    m.M[0][3]  = tmp[2]  * m1.M[2][2] + tmp[5]  * m1.M[2][3] + tmp[1]  * m1.M[2][1];
    m.M[0][3] -= tmp[4]  * m1.M[2][3] + tmp[0]  * m1.M[2][1] + tmp[3]  * m1.M[2][2];
    m.M[1][3]  = tmp[8]  * m1.M[2][3] + tmp[0]  * m1.M[2][0] + tmp[7]  * m1.M[2][2];
    m.M[1][3] -= tmp[6]  * m1.M[2][2] + tmp[9]  * m1.M[2][3] + tmp[1]  * m1.M[2][0];
    m.M[2][3]  = tmp[6]  * m1.M[2][1] + tmp[11] * m1.M[2][3] + tmp[3]  * m1.M[2][0];
    m.M[2][3] -= tmp[10] * m1.M[2][3] + tmp[2]  * m1.M[2][0] + tmp[7]  * m1.M[2][1];
    m.M[3][3]  = tmp[10] * m1.M[2][2] + tmp[4]  * m1.M[2][0] + tmp[9]  * m1.M[2][1];
    m.M[3][3] -= tmp[8]  * m1.M[2][1] + tmp[11] * m1.M[2][2] + tmp[5]  * m1.M[2][0];

    // calculate matrix inverse
    //
    float k = 1.0f / (m1.M[0][0] * m.M[0][0] + m1.M[0][1] * m.M[1][0] + m1.M[0][2] * m.M[2][0] + m1.M[0][3] * m.M[3][0]);

    for(int i=0;i<16;i++)
      m.L[i] *= k;

    return m;
  }

  static void CalcOrtoMatix(float left, float right, float bottom, float top, float nearPlane, float farPlane, Matrix4x4f* a_pResult)
  {
    Matrix4x4f res;

    res.M[0][0] = 2.0f/(right-left);
    res.M[1][1] = 2.0f/(top-bottom);
    res.M[2][2] = 2.0f/(farPlane-nearPlane);

    res.M[0][3] = -(right + left) / (right - left);
    res.M[1][3] = -(top + bottom) / (top - bottom);
    res.M[2][3] = -(farPlane + nearPlane) / (farPlane - nearPlane);

		res.Transpose();

    (*a_pResult) = res;
  }

  class Float16Compressor
  {
    typedef int int32_t;
    typedef unsigned int uint32_t;
    typedef unsigned short uint16_t;

    union Bits
    {
      float f;
      int32_t si;
      uint32_t ui;
    };

    static int const shift = 13;
    static int const shiftSign = 16;

    static int32_t const infN = 0x7F800000; // flt32 infinity
    static int32_t const maxN = 0x477FE000; // max flt16 normal as a flt32
    static int32_t const minN = 0x38800000; // min flt16 normal as a flt32
    static int32_t const signN = 0x80000000; // flt32 sign bit

    static int32_t const infC = infN >> shift;
    static int32_t const nanN = (infC + 1) << shift; // minimum flt16 nan as a flt32
    static int32_t const maxC = maxN >> shift;
    static int32_t const minC = minN >> shift;
    static int32_t const signC = signN >> shiftSign; // flt16 sign bit

    static int32_t const mulN = 0x52000000; // (1 << 23) / minN
    static int32_t const mulC = 0x33800000; // minN / (1 << (23 - shift))

    static int32_t const subC = 0x003FF; // max flt32 subnormal down shifted
    static int32_t const norC = 0x00400; // min flt32 normal down shifted

    static int32_t const maxD = infC - maxC - 1;
    static int32_t const minD = minC - subC - 1;

  public:

    static uint16_t compress(float value)
    {
      Bits v, s;
      v.f = value;
      uint32_t sign = v.si & signN;
      v.si ^= sign;
      sign >>= shiftSign; // logical shift
      s.si = mulN;
      s.si = int32_t(s.f * v.f); // correct subnormals
      v.si ^= (s.si ^ v.si) & -(minN > v.si);
      v.si ^= (infN ^ v.si) & -((infN > v.si) & (v.si > maxN));
      v.si ^= (nanN ^ v.si) & -((nanN > v.si) & (v.si > infN));
      v.ui >>= shift; // logical shift
      v.si ^= ((v.si - maxD) ^ v.si) & -(v.si > maxC);
      v.si ^= ((v.si - minD) ^ v.si) & -(v.si > subC);
      return v.ui | sign;
    }

    static float decompress(uint16_t value)
    {
      Bits v;
      v.ui = value;
      int32_t sign = v.si & signC;
      v.si ^= sign;
      sign <<= shiftSign;
      v.si ^= ((v.si + minD) ^ v.si) & -(v.si > subC);
      v.si ^= ((v.si + maxD) ^ v.si) & -(v.si > maxC);
      Bits s;
      s.si = mulC;
      s.f *= v.si;
      int32_t mask = -(norC > v.si);
      v.si <<= shift;
      v.si ^= (s.si ^ v.si) & mask;
      v.si |= sign;
      return v.f;
    }
  };


};
