#include "../HydraAppLib/main.h"

using namespace std;

extern int WinWidth;
extern int WinHeight;
extern Input input;  

bool IsXmlPath(const char* a_str)
{
  std::string myPath(a_str);
  return (myPath.find(".xml") != std::string::npos);
}

int main(int argc, char** argv)
{

#ifdef WIN32

  HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(h, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);

  wchar_t NPath[512];
  GetCurrentDirectoryW(512, NPath);

  std::wcout << L"[main]: path    = " << NPath << std::endl; 

#endif

  // hydra.exe scene.vsgf sceneProfile.xml settings.xml 
  //
  if(argc > 1)
  {
    input.inColladaFile      = argv[1];

    if(argc>2)
      input.inColladaProfile = argv[2];

    if (argc > 3)
    {
      if (IsXmlPath(argv[3]))
        input.ReadXMLFromFile(argv[3]);
      else
        input.ReadXMLFromSharedMemory("HydraGuiShmem", "HydraLDRImage", "HydraMessageShmem"); // argv[3] and other ...
    }
    else
      input.ReadXMLFromSharedMemory("HydraGuiShmem", "HydraLDRImage", "HydraMessageShmem");


    for (int i = 0; i < argc; i++)
      std::cout << "[main]: agrv[" << i << "] = " << argv[i] << std::endl;
    
    // parse other cmd params
    //
    HashMapS cmdParams;

    for (int i = 0; i < argc; )
    {
      if (argv[i][0] == '-' && i+1 < argc)
      {
        const char* paramName = argv[i];
        const char* paramVal  = argv[i+1];
        cmdParams[paramName]  = paramVal;
        i += 2;
      }
      else
        i++;
    }

    //for (auto p = cmdParams.begin(); p != cmdParams.end(); ++p)
     // std::cout << p->first.c_str() << " " << p->second.c_str() << std::endl;

    input.inColladaFile      = argv[1];
    input.inColladaProfile   = argv[2];
    input.inOutImageFileName = cmdParams["-out"];
    input.inTempFolder       = cmdParams["-temp"];
    input.inOpenCLMode       = cmdParams["-cl_enable"];
    input.inDeviceId         = cmdParams["-cl_device_id"];
    input.inListDevicesNow   = cmdParams["-cl_list_devices"];
    input.inSeed             = cmdParams["-seed"];
    input.inMultiDevMode     = cmdParams["-multidevicemode"];
    input.inDiskUpdateTime   = cmdParams["-diskupdatetime"];
  }
  else
  {
    input.ReadXMLFromSharedMemory("HydraGuiShmem", "HydraLDRImage", "HydraMessageShmem");
  }


  WinWidth  = input.ext_width;
  WinHeight = input.ext_height;

  if(input.noWindow)
  {
    Init();
    atexit(ShutDown);
    while(!input.exit_status)
      Display();
    ShutDown();
    return 0;
  }
  else
  {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
    glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
    
    glutInitContextVersion(3,1); // if 3.1 => compatability mode
    glutInitWindowSize(WinWidth, WinHeight);
    glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)-WinWidth)/2, (glutGet(GLUT_SCREEN_HEIGHT)-WinHeight)/2);
    glutCreateWindow("NO FATE");

    glutDisplayFunc(Display);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(KeyboardSpecial);
    glutReshapeFunc(Reshape);
    glutMouseFunc(Mouse);
    glutMotionFunc(MouseMotion);
    glutIdleFunc(Idle);

    Init();
    atexit(ShutDown);

    glutMainLoop();
  }

  ShutDown();
  return 0;
}
