import os

compareProgPath = "\"z_image_compare_prog\\mse.exe\""
hydraPath       = "C:/[Hydra]/bin/hydra.exe"

results = open("zresults.txt", "w")

for root, dirs, files in os.walk(".", topdown=False):
  
  for name in dirs:
  
    folder      = os.path.join(root, name)
    testBatFile = os.path.join(folder, "z_test.bat")
	
    if os.path.isfile(testBatFile):
	  
	  imageRef = os.path.abspath(os.path.join(folder, "z_ref.png"))
	  imageOut = os.path.abspath(os.path.join(folder, "z_out.png"))
	  imageDif = os.path.abspath(os.path.join(folder, "z_mse.txt"))
	  
	  scenePath = os.path.abspath(os.path.join(folder, "scene.vsgf"))
	  xml1Path  = os.path.abspath(os.path.join(folder, "hydra_profile_generated.xml"))
	  xml2Path  = os.path.abspath(os.path.join(folder, "settings.xml"))
	  
	  cmd1 = hydraPath + " " + scenePath + " " + xml1Path + " " + xml2Path + " -out " + imageOut 
	  cmd2 = compareProgPath + " " + imageRef + " " + imageOut + " " + imageDif
	  
	  print cmd1
	  os.system(cmd1);
	  
	  print cmd2
	  os.system(cmd2);
	  
	  myfile = open(imageDif, "r")
	  mse    = float(myfile.read())
	 
	  print(folder + " " + str(mse))
	  
	  #if mse < 10.0:
	  #  results.write("test  " + folder + "\t\tPASSED!\tmse = " + str(mse) +  " \n" )
	  #else:
	  #  results.write("test  " + folder + "\t\tFAILED!\tmse = " + str(mse) +  " \n" )
	
	  if mse < 30.0:
	    results.write('test  {:40s} {:8s} {:7.2f} \n'.format(folder, "PASSED!", mse) )
	  else:
	    results.write('test  {:40s} {:8s} {:7.2f} \n'.format(folder, "FAILED!", mse) )
