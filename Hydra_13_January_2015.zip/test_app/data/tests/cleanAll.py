import os

if os.path.isfile("zresults.txt") : os.remove("zresults.txt")

for root, dirs, files in os.walk(".", topdown=False):
  
  for name in dirs:
  
    folder      = os.path.abspath(os.path.join(root, name))
    testBatFile = os.path.abspath(os.path.join(folder, "z_test.bat"))
	
    if os.path.isfile(testBatFile):
	  
	  imageOut  = os.path.abspath(os.path.join(folder, "z_out.png"))
	  imageOut2 = os.path.abspath(os.path.join(folder, "z_out.hdr"))
	  imageDif  = os.path.abspath(os.path.join(folder, "z_mse.txt"))
          crap      = os.path.abspath(os.path.join(folder, "hmat_offsets.h"))
	  
	  if os.path.isfile(imageOut) : os.remove(imageOut)
	  if os.path.isfile(imageOut2): os.remove(imageOut2)
	  if os.path.isfile(imageDif) : os.remove(imageDif)
          if os.path.isfile(crap)     : os.remove(crap)
	  
print "images were cleaned, all tests are ready to go!"