#include "AccelerationStructure.h"

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <algorithm>

#ifdef _OPENMP
  #include <omp.h>
  #include <WinBase.h>
#endif

using namespace RAYTR;

using MGML_MATH::MIN;
using MGML_MATH::MAX;


////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VTriangle::SizeInBytes() const
{
  return sizeof(ObjectListTriangle);
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VTriangle::GetPrimType() const
{
  return HIT_TRIANGLE;
}

////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::VSphere::VSphere(int a_id,  AccelerationStructure* t)
{
  ConstructSphere(a_id,t);
}

////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::VSphere::ConstructSphere(int a_id,  AccelerationStructure* t)
{
  m_primitiveIndex = a_id;
  thisAccelStruct = t;

  Sphere sph;
  thisAccelStruct->m_pInputData->GetSphere(a_id,sph.pos.M,&sph.r);

  m_box.vmin = to_float3(sph.pos) - float3(sph.r,sph.r,sph.r);
  m_box.vmax = to_float3(sph.pos) + float3(sph.r,sph.r,sph.r);
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VSphere::SizeInBytes() const
{
  return sizeof(ObjectListSphere);
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VSphere::GetPrimType() const
{
  return HIT_SPHERE;
}



////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::VTriangle::VTriangle(int i, AccelerationStructure* t)
{
  ConstructTriangle(i,t);
}

void AccelerationStructure::VTriangle::ConstructTriangle(int i, AccelerationStructure* t)
{
  m_primitiveIndex = i/3;
  thisAccelStruct = t;

  float A[3], B[3], C[3];
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, A, B, C);

  for (int axis=0;axis<3;axis++)
  {
    m_box.vmax[axis] = MGML_MATH::MAX(A[axis], B[axis], C[axis]);
    m_box.vmin[axis] = MGML_MATH::MIN(A[axis], B[axis], C[axis]);
  }
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::VTriangle::IntersectWithAABB(const AABB3f& b) const
{
  bool overlap = MGML_MATH::Intersect<AABB3f,AABB3f>::exec(m_box, b);

  if (!overlap)
    return false;

  Triangle t;
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, t.A.M, t.B.M, t.C.M);

	return MGML_MATH::Intersect<AABB3f,Triangle>::exec(b,t);
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::VTriangle::Valid() const
{
  Triangle t;
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, t.A.M, t.B.M, t.C.M);

  float d1 = length(t.A);
  float d2 = length(t.B);
  float d3 = length(t.C);

  if(d1 > 1e35f || d2 > 1e35f || d3 > 1e35f)
    return false;

  d1 = length(t.A-t.B);
  d2 = length(t.B-t.C);
  d3 = length(t.C-t.B);

  if(d1 > 1e36f || d2 > 1e36f || d3 > 1e36f)
    return false;

  if(d1 <= 1e-36f || d2 <= 1e-36f || d3 <= 1e-36f)
    return false;

  return true;
}

bool AccelerationStructure::VSphere::Valid() const
{
  return true;
}

////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::VTriangle::GetVertexPositions(Triangle* t) const
{
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, t->A.M, t->B.M, t->C.M);
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::VSphere::IntersectWithAABB(const AABB3f& b) const
{
  bool overlap = MGML_MATH::Intersect<AABB3f,AABB3f>::exec(m_box, b);

  if (!overlap)
    return false;

  AABB4f box(to_float4(b.vmin,1), to_float4(b.vmax,1));

	Sphere sph;
  thisAccelStruct->m_pInputData->GetSphere(m_primitiveIndex, sph.pos.M, &sph.r);
	return MGML_MATH::Intersect<AABB4f,Sphere>::exec(box, sph);
}


////////////////////////////////////////////////////////////////////////////
////
vec2i AccelerationStructure::VTriangle::IntersectAxisAlignedPlane(float splitPos, int axis) const
{
  vec2i res(0,0);

  float3 verts[3];
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, verts[0].M, verts[1].M, verts[2].M);

  float3 edges[3][2] = {  {verts[0], verts[1]},
                          {verts[0], verts[2]},
                          {verts[1], verts[2]} };

  for (int i=0;i<3;i++)
  {
    float v0p = edges[i][0][axis];
    float v1p = edges[i][1][axis];

    if ((v0p <= splitPos && v1p >= splitPos) || (v0p >= splitPos && v1p <= splitPos))
    {
      res.x++;
      res.y++;
      return res;
    }
  }

  if (verts[0][axis] <= splitPos)
    res.x++;
  else
    res.y++;

  return res;
}

////////////////////////////////////////////////////////////////////////////
////
vec2i AccelerationStructure::VSphere::IntersectAxisAlignedPlane(float coord, int axis) const
{
  vec2i res(0,0);

  Sphere sph;
  thisAccelStruct->m_pInputData->GetSphere(m_primitiveIndex, sph.pos.M, &sph.r);

  if ( abs(sph.pos[axis] - coord) <= sph.r)
  {
    res.x++;
    res.y++;
  }

  return res;
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::AccelerationStructure()
{
  //m_spheres = NULL;
 // m_vert = 0;
 // m_index = 0;
  m_vtrianglesMemory = NULL;
  m_vspheresMemory = NULL;
  m_pInputData = NULL;
}

////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::~AccelerationStructure()
{
  delete [] m_vtrianglesMemory;
  delete [] m_vspheresMemory;
}


////////////////////////////////////////////////////////////////////////////
////
const AABB4f AccelerationStructure::GetBoundingBox() const
{
  return AABB4f(to_float4(m_bBox.vmin, 0), to_float4(m_bBox.vmax, 1));;
}



////////////////////////////////////////////////////////////////////////////
////
AABB3f AccelerationStructure::CalcBindingBox(const PrimitiveList& plist)
{
  // find center
  AABB3f bBox;
  size_t counter = 0;
  PrimitiveList::const_iterator p;

  for(p=plist.begin();p!=plist.end();++p)
    bBox.include(p->Box());

  for(int i=0;i<3;i++)
  {
    bBox.vmin[i] -= MGML_MATH::EPSILON_E5*(bBox.vmax[i]-bBox.vmin[i]);
    bBox.vmax[i] += MGML_MATH::EPSILON_E5*(bBox.vmax[i]-bBox.vmin[i]);
  }

  return bBox;
}

int AccelerationStructure::PushListInIndexListBuffer(const PrimitiveList& plist, int leafOffs)
{
  int threadId = 0;
  size_t currLeafId = 0;

#ifdef _OPENMP
  threadId = omp_get_thread_num();
#endif

  // avoid dynamic memory allocation each time
  std::vector<int>& tempArray = m_memData[threadId].tempIntArray;

  tempArray.resize(0);
  for (size_t i = 0; i < plist.size(); i++)
    tempArray.push_back(plist[i].GetPrimIndex());
  
  std::sort(tempArray.begin(), tempArray.end());

  #pragma omp critical
  {
    int begin = int(m_pIndexArray->size());
    int end   = int(m_pIndexArray->size() + plist.size());

    for (size_t i = 0; i < tempArray.size(); i++)
      m_pIndexArray->push_back(tempArray[i]);

    currLeafId = m_pBeginEndArray->size();
    m_pBeginEndArray->push_back(BvhLeafInfo(begin, end, leafOffs));
  }

  return currLeafId; 
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::StatInfo::StatInfo()
{
  m_pAccelStruct = 0;
  Clear();
}

////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::StatInfo::Clear()
{
  emptyNodes = 0;
  totalNodes = 0;
  leafes = 0;
  avgPrimInLeaf = 0;

	notEmptyLeafesNum = 0;
	maxDeep = 0;
  maxPrimsInLeaf = 0;
  primitiveListMemorySize = 0;
  dublicates = 0;
  totalPrims = 0;
  avgDeep = 0;
}



////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::StatInfo::Print(std::ostream& out, int totalPrimsNum)
{

  if(m_pAccelStruct != NULL)
    out << typeid(*m_pAccelStruct).name() <<" statistics: " << std::endl;

  out << "Nodes:                     " << totalNodes << std::endl;
	out << "Leafes:                    " << leafes << std::endl;
	out << "Empty(leafes):             " << emptyNodes << std::endl;

  int oldPrecision = out.precision(4);
	out << "Avg_Prim (not empty l-fs): " << avgPrimInLeaf << std::endl;
  out << "Max primitives in leaf:    " << maxPrimsInLeaf << std::endl;
  out.precision(oldPrecision);
  out << "ObjList size:              " << primitiveListMemorySize << " bytes" << std::endl;

	//out << "Object List data size:  " << m_objListDataTop << std::endl;
	//out << "object list data top: " << m_objListDataSize << std::endl;

  out << "Avg deep:                  " << avgDeep <<std::endl;
	out << "Max deep:                  " << maxDeep << std::endl;
  out << "Relative SAH:              " << relativeSAH << std::endl;

  out.precision(3);
  out << "Duplicates:                " << 100*(float)dublicates/(float)totalPrimsNum << "%" << std::endl;
  //out << "Memory taken by objList:   " << float(m_pAccelStruct->m_objListData.size())/(1024.0f*1024.0f) << " MBytes" << std::endl;

  out.precision(oldPrecision);


}


////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::FreeList(PrimitiveList& l)
{
  PrimitiveList empty;
  l.swap(empty);

  delete [] m_vspheresMemory;
  delete [] m_vtrianglesMemory;
  m_vspheresMemory = 0;
  m_vtrianglesMemory = 0;
}


////////////////////////////////////////////////////////////////////////////
////
float  AccelerationStructure::EstimateCost(const AABB& a_Box, float split_pos, int split_axis, size_t lsumm, size_t rsumm) const
{
  AABB left_box  = a_Box, right_box = a_Box;

  left_box.vmax[split_axis]  = split_pos;
  right_box.vmin[split_axis] = split_pos;

  float left_cost  = (float)lsumm;
  float right_cost = (float)rsumm;

  float summ_cost = (float)EMPTY_NODE_COST_TRAVERSE + (SurfaceArea(left_box)*left_cost + SurfaceArea(right_box)*right_cost);

  return summ_cost;
}



////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::FoundAlreadySplitedAAReferences(const AABB3f& a_box, PrimitiveList& prims, float min_split, int min_axis)
{
  // Now, solve a problem of fucking axis aligned triangles.
  // This problem arise when we have axis aligned triangles and we have
  // a split position on such triangle. And this is shit.
  // This need to be checked because actually triangles that are not axis aligned but overlap the plane
  // may be processed incorrectly
  //

  for(uint i=0;i<prims.size();i++)
  {
    if(prims[i].AxisAligned(min_axis, min_split))
    {
      if(prims[i].ExistSplitOnThatPlane(min_axis, min_split))
        return true;

      prims[i].MemorizeExistSplit(min_axis, min_split);
    }
  }

  return false;
}



////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::SplitReference(const PrimitiveRef& a_ref, PrimitiveRef* a_pLeft, PrimitiveRef* a_pRight, float splitPos, int splitAxis)
{
  *a_pLeft = a_ref;
  *a_pRight = a_ref;

  AABB3f& leftBox  = a_pLeft->Box();
  AABB3f& rightBox = a_pRight->Box();
  const AABB3f& nodeBox  = a_ref.Box();

  leftBox = rightBox = AABB3f();

  if (a_ref->GetPrimType() == HIT_TRIANGLE && !a_ref.AxisAligned(splitAxis, splitPos))
  {
    float3 verts[3];
    m_pInputData->GetTriangle(a_ref->GetPrimIndex(), verts[0].M, verts[1].M, verts[2].M);

    // !!!!!!!! THIS IS VERY IMPORTANT TO USE (0,2,1), i mean try ALL(0, 1 and 2) vertices as v0.
    // for example  {verts[0], verts[1]}, {verts[0], verts[2]}, verts[1], verts[2] will not work!!!
    //
    float3 edges[3][2] = {  {verts[0], verts[1]},
                            {verts[2], verts[0]},
                            {verts[1], verts[2]} };

    // grow both boxes with vertices and edge-plane intersections
    //
    for (int i=0;i<3;i++)
    {
      float v0p = edges[i][0][splitAxis];
      float v1p = edges[i][1][splitAxis];

      // Insert vertex to the boxes it belongs to.
      //
      if(v0p <= splitPos)
        leftBox.include(edges[i][0]);

      if(v0p >= splitPos)
        rightBox.include(edges[i][0]);

      // Edge intersects the plane => insert intersection to both boxes.
      //
      if ((v0p < splitPos && v1p > splitPos) || (v0p > splitPos && v1p < splitPos))
      {
        float3 t = lerp(edges[i][0], edges[i][1], ::clamp((splitPos - v0p) / (v1p - v0p), 0.0f, 1.0f));

        leftBox.include(t);
        rightBox.include(t);
      }
    }

  }

  leftBox.vmax[splitAxis] = splitPos;
  rightBox.vmin[splitAxis] = splitPos;

  // Intersect with original bounds.
  //
  leftBox.intersect(nodeBox);
  rightBox.intersect(nodeBox);
}



uint AccelerationStructure::GetContructionMode()
{
  uint mode = 0;

  if(m_settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    mode = KD_TREE_CONSTRUCT_QUALITY;
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_FAST)
    mode = KD_TREE_CONSTRUCT_FAST;
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_VERY_FAST)
    mode = KD_TREE_CONSTRUCT_VERY_FAST;
  else
  {
    mode = KD_TREE_CONSTRUCT_QUALITY;
    std::cerr << "KdTreeBuilder: construction quality was not specified, using 'CONSTRUCT_QUALITY' mode";
  }

  return mode;
}


////////////////////////////////////////////////////////////////////////////
////
float AccelerationStructure::SurfaceAreaOfTriangle(const PrimitiveRef& prim)
{
  const VTriangle* pTriangle = dynamic_cast<const VTriangle*>(prim.GetRealPrimitivePointer());

  if(pTriangle==NULL)
    RUN_TIME_ERROR("SurfaceAreaOfTriangle should be called only for triangles");

  Triangle tri;
  pTriangle->GetVertexPositions(&tri);

  return length(cross3(tri.C - tri.A, tri.B - tri.A));
}

float AccelerationStructure::SubdivMetric(PrimitiveRef triRef)
{
  float triSA = SurfaceAreaOfTriangle(triRef);
  float boxSA = SurfaceArea(triRef.Box());
  return boxSA*boxSA/fmaxf(triSA, 1e-5f);
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::PrimitiveList AccelerationStructure::SubdividePrimitive(PrimitiveRef triRef, double memExpansion)
{
  std::vector<PrimitiveRef> subdivs;

  float triSA = SurfaceAreaOfTriangle(triRef);
  float boxSA = SurfaceArea(triRef.Box());
  float relation = triSA/boxSA;

  int maxSubdivs; //= (int)(clamp(1.0f/relation,2.0f,128.0f));

  if(relation <= ((1.0f/4096.f)))
    maxSubdivs = 80;
  else if(relation <= ((1.0f/1024.f)))
    maxSubdivs = 64;
  else if (relation <= ((1.0f/256.f)))
    maxSubdivs = 48;
  else if (relation <= ((1.0f/64.f)))
    maxSubdivs = 32;
  else if (relation <= ((1.0f/32.f)))
    maxSubdivs = 24;
  else if (relation <= ((1.0f/16.f)))
    maxSubdivs = 16;
  else if (relation <= ((1.0f/8.f)))
    maxSubdivs = 8;
  else if (relation <= ((1.0f/4.f)))
    maxSubdivs = 4;
  else
    maxSubdivs = 2;

  if(memExpansion > 1.5)
    maxSubdivs *= 2; // fix ... a bit

  subdivs.reserve(maxSubdivs);

  std::queue<PrimitiveRef> queue;
  queue.push(triRef);

  while(!queue.empty())
  {
    PrimitiveRef prim = queue.front(); queue.pop();
    PrimitiveRef a, b;

    float3 boxSize = prim.Box().vmax - prim.Box().vmin;
    float splitPos = 0;
    int splitAxis = 0;
    float maxSize = -1;
    for(int i=0;i<3;i++)
    {
      if(maxSize < boxSize[i])
      {
        splitPos = prim.Box().center()[i];
        splitAxis = i;
        maxSize = boxSize[i];
      }
    }

    SplitReference(prim, &a, &b, splitPos, splitAxis);

    if(HaveToBeToSplited(a) && (queue.size() + subdivs.size() <= maxSubdivs) )
      queue.push(a);
    else
      subdivs.push_back(a);

    if(HaveToBeToSplited(b) && (queue.size() + subdivs.size() <= maxSubdivs))
      queue.push(b);
    else
      subdivs.push_back(b);
  }

  return subdivs;
}



////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::EarlySplitClipping(PrimitiveList& a_plist, const AABB3f& boundingBoxOfScene, float avgPrimSurfaceArea)
{
  std::cerr << "early split clipping...\n";
  int lastId = 0;

  m_sceneBBoxSA = SurfaceArea(boundingBoxOfScene);

  m_primsCountBeforeEarlySplitClipping = a_plist.size();

  float scale = 0.25f;

  // calc subdiv threshold for early split clipping
  //
  if(m_settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    m_minPrimSA_OK = scale*0.000005f*SurfaceArea(boundingBoxOfScene);
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    m_minPrimSA_OK = scale*0.0000075f*SurfaceArea(boundingBoxOfScene);
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_FAST)
    m_minPrimSA_OK = scale*0.00001f*SurfaceArea(boundingBoxOfScene);
  else
    m_minPrimSA_OK = SurfaceArea(boundingBoxOfScene); // no split clipping

  float minprimSAByAvg = avgPrimSurfaceArea*0.05f;

  m_minPrimSA_OK = fminf(m_minPrimSA_OK, minprimSAByAvg);

  unsigned int numTriangles = m_pInputData->GetNumTriangles();

  // sort primitives accorting to their needs to be splitted
  //
  struct CompareGreater
  {
    bool operator()(const PrimitiveRef& a, const PrimitiveRef& b) {return (a->m_aux > b->m_aux);}
  };
  for(size_t i=0;i<a_plist.size();i++)
    a_plist[i]->m_aux = SubdivMetric(a_plist[i]);

  std::sort(a_plist.begin(), a_plist.end(), CompareGreater());
  // \\ sort

  double memExpansion = double(MemoryExpansionFactor(m_settings, a_plist.size()));

  size_t totalSubdivs = 0;
  size_t maxSubdivs = size_t(double(memExpansion)*double(numTriangles));

  PrimitiveList plist;
  plist.reserve(size_t(double(a_plist.size())*memExpansion + 1000.0));

  for(size_t i=0;i<a_plist.size();i++)
  {
    PrimitiveRef triRef = a_plist[i];

    size_t theRest = (a_plist.size() - i);

    if(HaveToBeToSplited(triRef) && (totalSubdivs + theRest) < maxSubdivs)
    {
      std::vector<PrimitiveRef> subdivPrims = SubdividePrimitive(triRef, memExpansion);

      for(int i=0;i<subdivPrims.size();i++)
        plist.push_back(subdivPrims[i]);

      totalSubdivs      += (subdivPrims.size()-1);
      m_stat.dublicates += (subdivPrims.size()-1);
      lastId = plist.size();
    }
    else
    {
      totalSubdivs += 1;
      plist.push_back(triRef);
    }
  }

  if(totalSubdivs >= maxSubdivs)
    std::cerr << "Memory was exhausted when " << 100.0f*(float)lastId/plist.size() << " % prims processed" << std::endl;
  else
    std::cerr << "Early split clipping memory usage: " << 100.0f*totalSubdivs / maxSubdivs << " %" << std::endl;

  a_plist = plist;
}


