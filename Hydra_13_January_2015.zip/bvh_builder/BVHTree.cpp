#include "BVHTree.h"

#include <queue>

#ifdef _OPENMP
  #include <omp.h>
  #include <WinBase.h>
#endif

//#include <thrust/sort.h>


using MGML_MATH::MIN;
using MGML_MATH::MAX;

using namespace RAYTR;

////////////////////////////////////////////////////////////////////////////
////
BVHTree::BVHTree()
{
  EMPTY_NODE_COST_TRAVERSE = 0;
  SAH_OVERSPLIT_TRESHOLD = 1.0f;

  m_debugOutBVH = false;
  m_degugNodeIndex = 0;

  m_glListId = 257;
  m_glListCreated = false;

  m_pRoot = NULL;
}

////////////////////////////////////////////////////////////////////////////
////
BVHTree::~BVHTree()
{

}


////////////////////////////////////////////////////////////////////////////
////
void BVHTree::Build(RAYTR::BvhOutData* a_pOutData)
{
  if(a_pOutData == NULL)
    return;

  this->m_pRoot    = &a_pOutData->nodes;

  m_pBeginEndArray = &a_pOutData->leafesInfo;
  m_pIndexArray    = &a_pOutData->indices;

  std::vector<BVHNode>& m_root = *(this->m_pRoot);

  //
  //
  m_progressBar = 0;

  std::cerr << "adding primitives to input bvh...\n";

  m_buildTimer.start();

  int primitivesNumber = GetTotalPrims();

  delete [] m_vspheresMemory;
  delete [] m_vtrianglesMemory;
  m_vspheresMemory   = new VSphere[m_pInputData->GetNumSpheres()];
  m_vtrianglesMemory = new VTriangle [m_pInputData->GetNumTriangles()];


  PrimitiveList& plist = m_allPrimsSorted;
  plist.reserve(GetTotalPrims());

  AABB3f boundingBoxOfScene;

  float avgSurfaceArea = 0.0f;
  float maxSurfaceArea = 0.0f;

  unsigned int numTriangles = m_pInputData->GetNumTriangles();
  for(unsigned int i=0;i<numTriangles;i++)
  {
    m_vtrianglesMemory[i].ConstructTriangle(3*i, this);

    if(m_vtrianglesMemory[i].Valid())
    {
      PrimitiveRef triRef(m_vtrianglesMemory+i);
      boundingBoxOfScene.include(triRef.Box());

      float boxSA = SurfaceArea(triRef.Box());
      avgSurfaceArea += boxSA;
      maxSurfaceArea = fmaxf(maxSurfaceArea, boxSA);
      
      plist.push_back(triRef);
    }
  }

  avgSurfaceArea *= (1.0f/float(numTriangles));
  m_stat.Clear();

  size_t oldPrimListSize = plist.size();
  std::cerr << "[bvh] input prims: " << plist.size() << std::endl;

  if(!(m_settings.flags & AccelStructSettings::DISABLE_EARLY_SPLIT_CLIPPING))
    EarlySplitClipping(plist, boundingBoxOfScene, avgSurfaceArea); // m_vtrianglesMemory => plist

  unsigned int numSpheres = m_pInputData->GetNumSpheres();
  for(unsigned int i=0;i<numSpheres;i++)
  {
    m_vspheresMemory[i].ConstructSphere(i, this);
    PrimitiveRef sphRef(m_vspheresMemory+i);
    plist.push_back(sphRef);
    boundingBoxOfScene.include(sphRef.Box());
  }

  std::cerr << "[bvh] total prims: " << plist.size() << std::endl;

  if(plist.size() == 0)
    RUN_TIME_ERROR("BVH builder: 0 input prims, empty scene");


  int growFactor = 1;
  if(m_settings.recomendedPrimInLeaf < 4)
    growFactor *= 2;

  m_root.reserve(plist.size()*growFactor + 10000);
  size_t approxSizeOfObjectList = plist.size() * 4 * (sizeof(ObjectListTriangle));

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  m_pBeginEndArray->reserve(m_root.capacity());
  m_pBeginEndArray->resize(0);

  m_pIndexArray->reserve(plist.size()*4);
  m_pIndexArray->resize(0);
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  std::cerr << "[bvh] building bvh...\n";

  // third - set global binding box
  m_bBox = boundingBoxOfScene;

  //fourth - start kd-tree building
  m_root.push_back(BVHNodeT());
  m_root.resize( m_root.capacity() );
  m_nodeTop = 1; // will be used by fast NewNodePair implementation

  for(int i=0;i<BVHMAXTHREADS;i++)
    m_memData[i].FreeData(); // aux storage for building tree

  std::sort(plist.begin(), plist.end(), MyBoxLessMax<0>());

  PrimitiveListSlice allPrims(plist.begin(), plist.end());
  
  bool useopenMP = false;
  #ifdef _OPENMP
  useopenMP = true;
  #endif

  if(allPrims.size() <= 100000 || !useopenMP)
  {
    Subdivide(&m_root[0], boundingBoxOfScene, m_settings.maxDeep, allPrims, 0.0f, 1.0f);
  }
  else
  {
    std::vector<SubdivContext> nodesQueue;
    nodesQueue.reserve(BVHMAXTHREADS*2);
    nodesQueue.resize(0);
    nodesQueue.push_back(SubdivContext(&m_root[0], boundingBoxOfScene, m_settings.maxDeep, allPrims));

    SubdivideInParallel(&nodesQueue);
  }

  m_root.resize(m_nodeTop);

  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  for(int i=0;i<BVHMAXTHREADS;i++)
    m_memData[i].FreeData(); // aux storage for building tree

  FreeList(plist);
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  size_t oldIndexSize = m_pIndexArray->size();
  float compressTime  = 0.0f;

  if(1)
  {
    m_pInputData->progressBar("BVHBuilder, compress indices", 0);

    Timer myTimer(true);

    std::vector<BvhLeafInfo> tempLeafes;
    std::vector<int>         tempIndices;

    tempLeafes.reserve(m_pBeginEndArray->capacity());
    tempIndices.reserve(m_pIndexArray->capacity());

    compressLZ77(*m_pBeginEndArray, *m_pIndexArray, tempLeafes, tempIndices);

    (*m_pBeginEndArray) = tempLeafes;
    (*m_pIndexArray)    = tempIndices;

    compressTime = myTimer.getElapsed();
  }

  if (0)
  {
    std::ofstream fout("bvh_indices.txt");
    for (int node = 0; node < m_pBeginEndArray->size(); node++)
    {
      BvhLeafInfo leaf = (*m_pBeginEndArray)[node];

      fout << "(" << leaf.begin << " " << leaf.end << ") : ";
      for (int j = leaf.begin; j < leaf.end; j++)
        fout << (*m_pIndexArray)[j] << " ";

      fout << std::endl;
    }
  }


  float bvhMem     = double(m_root.size()*sizeof(BVHNode)) / (1024.0*1024.0);
  float objListMem = double(m_pIndexArray->size()*sizeof(float4)*3 +  // tri data arrray
                           sizeof(int)*m_pIndexArray->size()       +  // aux tri index by address array 
                           sizeof(ObjectList)*m_pBeginEndArray->size()) / (1024.0*1024.0);

  float obListMemIndexed = double(oldPrimListSize*sizeof(float4)*3 + m_pIndexArray->size()*sizeof(int) + sizeof(ObjectList)*m_pBeginEndArray->size()) / (1024.0*1024.0); 

  int oldPrecision = std::cerr.precision(4);
  std::cerr << std::endl;
  std::cerr << "[bvh] memory taken by BVH nodes : " << bvhMem << "\tMBytes" << std::endl;
  std::cerr << "[bvh] memory taken by prim list : " << objListMem << "\tMBytes" << std::endl;
  std::cerr << "[bvh] memory taken by total     : " << bvhMem + objListMem << "\tMBytes" << std::endl;
  
  std::cerr << "[bvh] memory taken indexed list : " << obListMemIndexed << "\tMBytes" << std::endl;
  std::cerr << "[bvh] memory taken indexed total: " << bvhMem + obListMemIndexed << "\tMBytes" << std::endl;
  std::cerr << "[bvh] memory taken list  win    : " << objListMem/obListMemIndexed << "\t times" << std::endl;
  std::cerr << "[bvh] memory taken total win    : " << (bvhMem + objListMem) / (bvhMem + obListMemIndexed) << "\t times" << std::endl;

  std::cerr << "[bvh] tri indices num = " << m_pIndexArray->size() << std::endl;
  std::cerr << "[bvh] tri indices compress rate = " << float(oldIndexSize)/float(m_pIndexArray->size()) << std::endl;
  std::cerr << "[bvh] tri indices compress time = " << compressTime << "s " << std::endl;

  //std::cerr << "[bvh] mem taken leafes begEnd   : " << double(m_pBeginEndArray->size()*sizeof(float4)) / (1024.0*1024.0) << "\tMBytes" << std::endl;
  std::cerr << "[bvh] bBoxSize = ( " << float3(m_bBox.vmax - m_bBox.vmin) << ") " << std::endl;
  std::cerr.precision(oldPrecision);

  a_pOutData->boxMin = m_bBox.vmin;
  a_pOutData->boxMax = m_bBox.vmax;
}






////////////////////////////////////////////////////////////////////////////
////
void BVHTree::InsertListInLeaf(BVHNode* curr_node, PrimitiveListSlice& plist)
{
  int threadId = 0;

#ifdef _OPENMP
  threadId = omp_get_thread_num();
#endif

  // avoid dynamic memory allocation each time
  PrimitiveList& plist2 = m_memData[threadId].auxThreadPrimList;
  plist2.resize(0);

  // remove duplicates
  //
  for(int i=0;i<plist.size();i++)
  {
    bool foudDuplicate = false;

    for(int j=i+1;j<plist.size();j++)
    {
      if(plist[i].GetRealPrimitivePointer()==plist[j].GetRealPrimitivePointer()) // the same prim
      {
        foudDuplicate = true;
        break;
      }
    }

    if (!foudDuplicate)
      plist2.push_back(plist[i]);
  }

  int bvhLeafOffset = int(curr_node - GetRoot());

  int offset2 = PushListInIndexListBuffer(plist2, bvhLeafOffset);
  curr_node->SetLeaf(1);
  curr_node->SetObjectListOffset(offset2); // not strictly nessesary, because it should be overrided further outside of the BVH Builder

  //int offset = PushListInObjectListBuffer(plist2);
  //curr_node->SetObjectListOffset(offset/sizeof(float4));

}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::SortPrimitives(PrimitiveListSlice currList, int dim)
{

  switch(dim)
  {
  case 0:
    std::sort(currList.begin(), currList.end(), MyBoxLessMax<0>());
    break;
  case 1:
    std::sort(currList.begin(), currList.end(), MyBoxLessMax<1>());
    break;
  case 2:
    std::sort(currList.begin(), currList.end(), MyBoxLessMax<2>());
    break;
  }

  /*
  int threadId = 0;

#ifdef _OPENMP
  threadId = omp_get_thread_num();
#endif

  std::vector<float>& keys = m_memData[threadId].keys;
  keys.resize(currList.size());

  for(int i=0;i<keys.size();i++)
  {
    PrimitiveRef p1 = currList[i];
    keys[i] = p1.Box().vmax[dim];
  }

  thrust::sort_by_key(keys.begin(), keys.end(), currList.begin());
  */

}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::CalcBounds(PrimitiveListSlice currList, std::vector<AABB3f>& rightBounds, SplitData& res, int dim)
{
  // Sweep right to left and determine bounds.
  //
  AABB3f rightBounds1;
  for (uint i = currList.size() - 1; i > 0; i--)
  {
    rightBounds1.include(currList[i].Box());
    rightBounds[i-1] = rightBounds1;
  }

  // Sweep left to right and select lowest SAH.
  //
  AABB3f leftBounds;
  for (uint i = 1; i < currList.size(); i++)
  {
    leftBounds.include(currList[i-1].Box());

    const AABB3f& leftBox  = leftBounds;
    const AABB3f& rightBox = rightBounds[i-1];

    float primsOnLeftSide  = float(i);
    float primsOnRightSide = float(currList.size() - i);

    float sah = EMPTY_NODE_COST_TRAVERSE + SurfaceArea(leftBox)*primsOnLeftSide + SurfaceArea(rightBox) * primsOnRightSide;

    // calc left and right nodes intersection penalty
    //
    //leftBox.intersect(rightBox);
    //sah += 0.1f*SurfaceArea(leftBox)*(primsOnLeftSide + primsOnRightSide);

    if (sah < res.sah)
    {
      res.sah = sah;
      res.axis = dim;
      res.primsOnLeftSide = i;
      res.primsOnRightSide = currList.size() - i;
      res.leftBounds  = leftBox;
      res.rightBounds = rightBox;
    }
  }
}


////////////////////////////////////////////////////////////////////////////
////
BVHTree::SplitData BVHTree::FindObjectSplit(PrimitiveListSlice a_plist, const AABB3f& a_box)
{
  BVHTree::SplitData res;
  res.sah = SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size();
  res.subdivideNext = false;
  res.axis = -1;

  int threadId = 0;

#ifdef _OPENMP
  threadId = omp_get_thread_num();
#endif

  // avoid dynamic memory allocation each time
  //
  std::vector<AABB3f>& rightBounds = m_memData[threadId].rightBounds_FindObjectSplit; rightBounds.resize(a_plist.size());
  PrimitiveList&       currList    = m_memData[threadId].auxThreadPrimList; currList.resize(a_plist.size());

  int axisOrder[3];

  if(a_plist.axis() == 1)
  {
    axisOrder[0] = 1;
    axisOrder[1] = 2;
    axisOrder[2] = 0;
  }
  else if(a_plist.axis() == 2)
  {
    axisOrder[0] = 2;
    axisOrder[1] = 0;
    axisOrder[2] = 1;
  }
  else
  {
    axisOrder[0] = 0;
    axisOrder[1] = 1;
    axisOrder[2] = 2;
  }

  BVHTree::SplitData splitPerAxis[3] = {res,res,res};

  for (int axisNum=0;axisNum<3;axisNum++)
  {
    int dim = axisOrder[axisNum];

    // copy data to appropriate memory location
    //
    std::copy(a_plist.begin(), a_plist.end(), currList.begin());

    if(axisNum!=0)
      SortPrimitives(PrimitiveListSlice(currList.begin(), currList.end()), dim);

    CalcBounds(PrimitiveListSlice(currList.begin(), currList.end()), rightBounds, res, dim);
    splitPerAxis[dim] = res;
  } 

  
  res.subdivideNext = (res.axis != -1) && (res.sah < SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size());
  res.pos = res.leftBounds.vmax[res.axis];

  if(res.subdivideNext)
  {
    if(res.axis == axisOrder[2])
      std::copy(currList.begin(), currList.end(), a_plist.begin());
    else
    {
      SortPrimitives(a_plist, res.axis);
      res = splitPerAxis[res.axis];
    }
  }

  res.subdivideNext = (res.axis != -1) && (res.sah < SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size());
  res.pos = res.leftBounds.vmax[res.axis];

  return res;
}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::Subdivide(BVHNode* a_currNode, const AABB3f& a_box, int a_currDeep, PrimitiveListSlice& plist, float a_progressStart, float a_progressEnd)
{
  SetBoundingBoxData(a_currNode, a_box);

  if(a_currDeep == 0 || (int)plist.size() <= m_settings.recomendedPrimInLeaf)
  {
    InsertListInLeaf(a_currNode, plist);
    return;
  }

  int threadId = 0;
  bool parallelBuild = false;

#ifdef _OPENMP
  threadId = omp_get_thread_num();
  parallelBuild = true;
#endif

  if(!parallelBuild && m_buildTimer.getElapsed() >= 1.0f && (a_progressStart != a_progressEnd))
  {
    if(m_pInputData->progressBar != NULL)
      m_pInputData->progressBar("BVHBuilder, progress ", a_progressStart);
    m_buildTimer.start();
  }
  m_threadProgress[threadId] = a_progressStart;

  if(parallelBuild && m_buildTimer.getElapsed() >= 0.2f)
  {
    float remainTotal = 0.0f;
    for(int i=0;i<BVHMAXTHREADS;i++)
      remainTotal += 1.0f - m_threadProgress[i];

    float progressTotal = 1.0f - (remainTotal/float(BVHMAXTHREADS));
    #pragma omp critical
    {
      //fprintf(stderr, "BVHBuilder, progress: %.0f%% \r", progressTotal*100.0f);
      if(m_pInputData->progressBar != NULL)
        m_pInputData->progressBar("BVHBuilder, progress ", progressTotal);
      m_buildTimer.start();
    }
  }

  SplitData split = FindObjectSplit(plist, a_box);

  if(!split.subdivideNext)
  {
    InsertListInLeaf(a_currNode, plist);
    return;
  }

  // split primitives and construct subtrees
  //
  BVHNode *leftNode = NULL, *rightNode = NULL;
  NewNodePair(a_currNode, &leftNode, &rightNode);

  PrimitiveList::iterator middle = plist.begin() + split.primsOnLeftSide;
  PrimitiveListSlice leftList(plist.begin(), middle, split.axis);
  PrimitiveListSlice rightList(middle, plist.end(),  split.axis);

  float progressMid = MGML_MATH::lerp(a_progressStart, a_progressEnd, (float)leftList.size() / (float)(leftList.size() + rightList.size()));

  Subdivide(leftNode,  split.leftBounds,  a_currDeep-1, leftList,  a_progressStart, progressMid);
  Subdivide(rightNode, split.rightBounds, a_currDeep-1, rightList, progressMid, a_progressEnd);
}


////////////////////////////////////////////////////////////////////////////
////
void BVHTree::SubdivideInParallel(std::vector<SubdivContext>* a_pResult)
{
  if(a_pResult == NULL)
    RUN_TIME_ERROR("SubdivideBreadthFirst, a_pResult == NULL");


  struct CompareByArraySize
  {
    inline bool operator()(const SubdivContext& p1, const SubdivContext& p2) const { return (p1.plist.size() > p2.plist.size()); }
  };

  // breadth-first build
  //
  while(a_pResult->size() < BVHMAXTHREADS)
  {
    std::vector<SubdivContext> currNodes = *a_pResult;
    a_pResult->resize(0);
 
    std::sort(currNodes.begin(), currNodes.end(), CompareByArraySize());

    //for(int nodeIt = 0; nodeIt < currNodes.size(); nodeIt++)
    //  std::cerr << currNodes[nodeIt].plist.size() << std::endl;
    //std::cerr << std::endl;

    int halfLast = (currNodes.size()/2) + 1;

    if(currNodes.size() <= 4)
      halfLast = currNodes.size();

    #pragma omp parallel for
    for(int nodeIt = 0; nodeIt < halfLast; nodeIt++)
    {
      SubdivContext& ctx        = currNodes[nodeIt];
      BVHNode* a_currNode       = ctx.parentNode;
      const AABB3f& a_box       = ctx.parentBox;
      int a_currDeep            = ctx.depth;
      PrimitiveListSlice& plist = ctx.plist;

      // common bvh split code
      //
      SetBoundingBoxData(a_currNode, a_box);

      int a_prevSplitAxis = plist.axis();

      if(a_currDeep == 0 || (int)plist.size() <= m_settings.recomendedPrimInLeaf)
      {
        InsertListInLeaf(a_currNode, plist);
        continue;
      }

      SplitData split = FindObjectSplit(plist, a_box);

      if(!split.subdivideNext)
      {
        InsertListInLeaf(a_currNode, plist);
        continue;
      }

      // split primitives and construct subtrees
      //
      BVHNode *leftNode = NULL, *rightNode = NULL;
      NewNodePair(a_currNode, &leftNode, &rightNode);

      PrimitiveList::iterator middle = plist.begin() + split.primsOnLeftSide;
      PrimitiveListSlice leftList(plist.begin(), middle, split.axis);
      PrimitiveListSlice rightList(middle, plist.end(),  split.axis);

      SubdivContext leftContext(leftNode,  split.leftBounds,  a_currDeep-1, leftList);     
      SubdivContext rightContext(rightNode,  split.rightBounds,  a_currDeep-1, rightList);
    
      #pragma omp critical
      {
        a_pResult->push_back(leftContext);
        a_pResult->push_back(rightContext);
      }
    }

    for(int i=halfLast; i < currNodes.size();i++)
      a_pResult->push_back(currNodes[i]);
  }

  for(int i=0;i<BVHMAXTHREADS;i++)
    m_memData[i].FreeData(); // aux storage for building tree

  m_buildTimer.start();

  // depth-first build
  //
  #pragma omp parallel for num_threads(BVHMAXTHREADS)
  for(int nodeIt = 0; nodeIt < a_pResult->size(); nodeIt++)
  {
    SubdivContext& ctx = (*a_pResult)[nodeIt];
    Subdivide(ctx.parentNode, ctx.parentBox, ctx.depth, ctx.plist, 0.0f, 1.0f);
  }


}


////////////////////////////////////////////////////////////////////////////
////
void BVHTree::NewNodePair(BVHNode* curr_node, BVHNode** left, BVHNode** right)
{
  unsigned int oldSize = 0;

  oldSize = InterlockedExchangeAdd((volatile LONG*)&m_nodeTop, 2);

  if(oldSize + 2 > m_pRoot->size())
  {
    #pragma omp critical
    {
      if(oldSize + 2 > m_pRoot->size())
        m_pRoot->resize(2 * oldSize);
    }
  }

  m_pRoot->at(oldSize + 0) = BVHNode();
  m_pRoot->at(oldSize + 1) = BVHNode();

  curr_node->SetLeaf(0);
  curr_node->SetLeftOffset(oldSize);

  int offs1 = curr_node->GetLeftOffset();
  int offs2 = curr_node->GetRightOffset();

  *left  = GetRoot() + curr_node->GetLeftOffset();
  *right = GetRoot() + curr_node->GetRightOffset();

  (*left)->SetLeaf(1);
  (*right)->SetLeaf(1);
}


////////////////////////////////////////////////////////////////////////////
////
float BVHTree::MemoryExpansionFactor(AccelStructSettings settings, size_t a_primListSize) const
{
  return CalcBVHMemoryExpansionFactor(settings, a_primListSize);
}


