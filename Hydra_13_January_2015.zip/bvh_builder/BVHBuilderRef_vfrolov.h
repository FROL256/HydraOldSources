#pragma once
#include "IBVHBuilder.h"
#include "BVHTree.h"

class BVHBuilderRef_vfrolov : public IBVHBuilder
{
public:

  BVHBuilderRef_vfrolov();
  ~BVHBuilderRef_vfrolov();

  void Build(const RAYTR::InputData* pInData, RAYTR::AccelStructSettings settings, RAYTR::BvhOutData* pOutData);

  const BVHNode* GetBVH() const;
  int GetBVHArraySize() const;

  RAYTR::AccelStructStatistics GetStatistics() const;
  void GetBoundingBox(float vmin[3], float vmax[3]) const;

  const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const;

  float MemoryExpansionFactor(RAYTR::AccelStructSettings settings, size_t a_primitives) const;

protected:
  // closed copy constructor and operator=()
  //
  BVHBuilderRef_vfrolov(const BVHBuilderRef_vfrolov& arg){}
  BVHBuilderRef_vfrolov& operator=(const BVHBuilderRef_vfrolov& arg) {return *this;}

  RAYTR::BVHTree* m_pMyBVH;
};

