#include "BVHBuilderRef_vfrolov.h"
#include "BVHTree.h"

////////////////////////////////////////////////////////////////////////////
////
BVHBuilderRef_vfrolov::BVHBuilderRef_vfrolov()
{
  m_pMyBVH = new RAYTR::BVHTree;
}

////////////////////////////////////////////////////////////////////////////
////
BVHBuilderRef_vfrolov::~BVHBuilderRef_vfrolov()
{
  delete m_pMyBVH;
}

////////////////////////////////////////////////////////////////////////////
////
void BVHBuilderRef_vfrolov::Build(const RAYTR::InputData* pInData, RAYTR::AccelStructSettings settings, RAYTR::BvhOutData* pOutData)
{
  m_pMyBVH->SetSettings(settings);
  m_pMyBVH->SetInputData(pInData);
  m_pMyBVH->Build(pOutData);
}

////////////////////////////////////////////////////////////////////////////
////
const BVHNode* BVHBuilderRef_vfrolov::GetBVH() const
{
  return m_pMyBVH->GetRoot();
}

////////////////////////////////////////////////////////////////////////////
////
int  BVHBuilderRef_vfrolov::GetBVHArraySize() const
{
  return m_pMyBVH->GetNumNodes();
}

////////////////////////////////////////////////////////////////////////////
////
RAYTR::AccelStructStatistics BVHBuilderRef_vfrolov::GetStatistics() const
{
  return m_pMyBVH->GetStatistics();
}

////////////////////////////////////////////////////////////////////////////
////
void BVHBuilderRef_vfrolov::GetBoundingBox(float a_vmin[3], float a_vmax[3]) const
{
  AABB4f box = m_pMyBVH->GetBoundingBox();

  for(int i=0;i<3;i++)
  {
    a_vmin[i] = box.vmin[i];
    a_vmax[i] = box.vmax[i];
  }
}

////////////////////////////////////////////////////////////////////////////
////
const void* BVHBuilderRef_vfrolov::GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const
{
  if(a_dataStructureName == "vfrolov_BVHTree")
  {
    return m_pMyBVH;
  }

  return NULL;
}

float BVHBuilderRef_vfrolov::MemoryExpansionFactor(RAYTR::AccelStructSettings settings, size_t a_primListSize) const
{
  return RAYTR::CalcBVHMemoryExpansionFactor(settings, a_primListSize);
}


