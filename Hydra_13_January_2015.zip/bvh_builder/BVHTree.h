#pragma once

#include "IBVHBuilder.h"

#ifndef ACCEL_STRUCT_GUARDIAN
  #include "../bvh_builder/AccelerationStructure.h"
#endif


namespace RAYTR
{
  ////////////////////////////////////////////////////////////////////////////
  ////
  static void SetBoundingBoxData(BVHNode* a_currNode, const AABB3f& a_box)
  {
    a_currNode->m_boxMin.x = a_box.vmin.x;
    a_currNode->m_boxMin.y = a_box.vmin.y;
    a_currNode->m_boxMin.z = a_box.vmin.z;
    a_currNode->m_boxMax.x = a_box.vmax.x;
    a_currNode->m_boxMax.y = a_box.vmax.y;
    a_currNode->m_boxMax.z = a_box.vmax.z;
  }

  ////////////////////////////////////////////////////////////////////////////
  ////
  static const AABB3f GetBoundingBoxData(const BVHNode* a_currNode)
  {
    return AABB3f(float3(a_currNode->m_boxMin.x, a_currNode->m_boxMin.y, a_currNode->m_boxMin.z),
                  float3(a_currNode->m_boxMax.x, a_currNode->m_boxMax.y, a_currNode->m_boxMax.z));
  }


class BVHTree : public AccelerationStructure
{
public:
  BVHTree();
  ~BVHTree();

  const BVHNode* GetRoot() const { std::vector<BVHNode>& tempRef = (*m_pRoot); return &tempRef[0]; }
  BVHNode*       GetRoot()       { std::vector<BVHNode>& tempRef = (*m_pRoot); return &tempRef[0]; }

  int GetNumNodes() const {return m_pRoot->size();}

  const BVHNode* GetNode(int offset) const { return GetRoot() + offset; }

  void Build(RAYTR::BvhOutData* pOutData);
  void Draw() const;

  void SetDebugNodeIndex(int a_val) { m_degugNodeIndex = a_val; }

  float MemoryExpansionFactor(AccelStructSettings settings, size_t a_primitivesNum) const;

protected:

  BVHTree(const BVHTree& rhs) {}
  BVHTree& operator=(const BVHTree& rhs) { return *this; }

  void Subdivide(BVHNode* a_Node, const AABB3f& a_Box, int a_Depth, PrimitiveListSlice& plist, float a_progressStart, float a_progressEnd);

  struct SubdivContext
  {
    SubdivContext() : parentNode(NULL), depth(0) {}

    SubdivContext(BVHNode* a_node, const AABB3f& a_bounds, int a_depth, const PrimitiveListSlice& a_plist) : 
                  parentNode(a_node), parentBox(a_bounds), depth(a_depth), plist(a_plist) {}

    BVHNode* parentNode;
    AABB3f   parentBox;
    int      depth;
    PrimitiveListSlice plist;
  };

  void SubdivideInParallel(std::vector<SubdivContext>* a_pResult);


  void InsertListInLeaf(BVHNode* curr_node, PrimitiveListSlice& plist);
  SplitData FindObjectSplit(PrimitiveListSlice plists, const AABB3f& a_box);

  void MakeBVHMoreCacheFriendly();
  void DepthFirstTestTraversal(const BVHNode* a_root, const BVHNode* node, std::vector<int>& a_outIndices);

  void NewNodePair(BVHNode* curr_node, BVHNode** left, BVHNode** right);


  void DebugCollectStatistics();
  void DebugCollectStatistics(const BVHNode* a_node, int a_deep);
  void DrawNode(const BVHNode* a_node) const;
  float GetExactSahRec(int a_nodeOffset);
  void DebugLeafDrawGeometry(const BVHNode* node) const;

  PrimitiveList m_allPrimsSorted;

  void SortPrimitives(PrimitiveListSlice a_slice, int dim);
  void CalcBounds(PrimitiveListSlice currList, std::vector<AABB3f>& rightBounds, SplitData& res, int dim);


  std::vector<BVHNode>* m_pRoot;
  unsigned int m_nodeTop;

  int m_degugNodeIndex;

  bool m_debugOutBVH;

  int m_glListId;
  mutable bool m_glListCreated;

  

};


void compressLZ77(const std::vector<BvhLeafInfo>& leafesInfo, const std::vector<int>& indices,
  std::vector<BvhLeafInfo>& out_leafesInfo, std::vector<int>& out_indices);

}


