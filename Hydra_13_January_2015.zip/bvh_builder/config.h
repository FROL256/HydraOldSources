#pragma once
#define CONFIG_GUARDIAN

#define INDEX_TRIANGLE_LAYOUT  1
#define VERTEX_TRIANGLE_LAYOUT 2
#define MATRIX_TRIANGLE_LAYOUT 3

#define TRIANGLE_LAYOUT VERTEX_TRIANGLE_LAYOUT
#define BLOCK_SIZE      256

#define SUPPORT_SPHERES 1
#define SUPPORT_ALPHA_TEST 1


typedef void (*RTE_PROGRESSBAR_CALLBACK)(const char* message, float a_progress);

