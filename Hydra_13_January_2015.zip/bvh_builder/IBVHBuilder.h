#pragma once

#include <iostream>

#ifndef ACCEL_STRUCT_GUARDIAN
  #include "../bvh_builder/AccelerationStructure.h"
#endif


#pragma warning(disable:4290) // warning about unsupported exeption specifications, like 'throw (std::runtime_error)' by msvc compiler


class IBVHBuilder
{
public:

  IBVHBuilder(){}
  virtual ~IBVHBuilder(){}

  virtual void Build(const RAYTR::InputData* pInData, RAYTR::AccelStructSettings settings, RAYTR::BvhOutData* pOutData) = 0;
  virtual RAYTR::AccelStructStatistics GetStatistics() const = 0;


  virtual const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const {return NULL;}  // NEVER use this function. For Developers only.
  virtual float MemoryExpansionFactor(RAYTR::AccelStructSettings settings) const { return 4; }  // for BVH 4 by default

private:
  IBVHBuilder(const IBVHBuilder& arg){}
  IBVHBuilder& operator=(const IBVHBuilder& arg) {return *this;}
};



