#include <gl/glew.h>

#include "scenes.h"

//#include <il/il.h>
//#include <il/ilu.h>
//#pragma comment(lib, "devil.lib")
//#pragma comment(lib, "ilu.lib")

#include <FreeImage.h>
#pragma comment(lib, "FreeImage.lib")


#pragma warning(disable:4305)

using MGML_MATH::rnd;

extern Camera* cam;

unsigned char* LoadTextureHeight(const std::string& a_fileName, int* pW, int* pH)
{
  unsigned char* texData = LoadTexture("data/rocks_height.dds", pW, pH);

  int size = (*pW) * (*pH) * 4;
  unsigned char* data = new unsigned char[size];

  for(int i=0;i<(*pW) * (*pH);i++)
  {
    data[i*4+0] = texData[i*4+3];
    data[i*4+1] = texData[i*4+3];
    data[i*4+2] = texData[i*4+3];
    data[i*4+3] = texData[i*4+3];
  }

  delete [] texData;
  return data;
}




void MakeTestScene_ParallaxMappingDemo2(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  int chessTexId = LoadTextureToRender("data/texture1.bmp", pRender); //pRender->AddTexture(texture.getConstBuffer(), texture.width(), texture.height(), IGraphicsEngine::RGBA8);

  //ilInit();
  //iluInit();

  // rocks
  //
  int w=0,h=0;
  unsigned char* texData = LoadTexture("data/rock_height.dds", &w, &h);
  int displTextureId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rock_diffuse.dds", &w, &h);
  int diffuseTextureId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rock_bump.dds", &w, &h);
  int normalsTexId = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;


  // rock wall
  //
  texData = LoadTexture("data/rockwall_diffuse.dds", &w, &h);
  int diffuseTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rockwall_height.dds", &w, &h);
  int displTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/rockwall_bump.dds", &w, &h);
  int normalsTexture2Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  // four figures
  //
  texData = LoadTexture("data/relief_wood.jpg", &w, &h);
  int diffuseTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/relief_height.png", &w, &h);
  int displTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  texData = LoadTexture("data/relief_bump.png", &w, &h);
  int normalsTexture3Id = pRender->AddTexture(texData, w, h, IGraphicsEngine::RGBA8);
  delete [] texData;

  HydraMaterial materials[8];

  //
  //
  materials[0].ambient.color = float3(0.1,0.1,0.1);
  materials[0].diffuse.color = float3(0.20f,0.20f,0.20f);
  materials[0].diffuse.color_texId = diffuseTexture2Id;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.cosPower   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.45f,0.45f,0.45f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].displacement.height = 0.04f;
  materials[0].displacement.normals_texId = normalsTexture2Id;
  materials[0].displacement.height_texId  = displTexture2Id;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;// | HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;
  int FLOOR_MATERIAL = 0;

  //
  //
  materials[1].ambient.color    = float3(0.1,0.1,0.1);
  materials[1].ambient.color_texId = diffuseTexture3Id;

  materials[1].diffuse.color    = float3(0.25f,0.25f,0.25f);
  materials[1].diffuse.color_texId = diffuseTexture3Id;

  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.cosPower   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].reflection.color = float3(0.25f,0.25f,0.25f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].displacement.height = 0.1f;
  materials[1].displacement.normals_texId = normalsTexture3Id;
  materials[1].displacement.height_texId  = displTexture3Id;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;
  int DISPLACED_MATERIAL = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.cosPower   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].transparency.color = float3(0.0,0.65f,0.0f);
  materials[2].transparency.fogColor      = float3(0,1,0);
  materials[2].transparency.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].transparency.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].transparency.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS;
  int GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0.1,0.1,0.1);
  materials[3].ambient.color_texId = diffuseTexture2Id;
  materials[3].diffuse.color    = float3(0.35f,0.35f,0.35f);
  materials[3].diffuse.color_texId = diffuseTexture2Id;
  materials[3].specular.color   = float3(0.3f,0.3f,0.3f);
  materials[3].specular.cosPower   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].displacement.normals_texId = normalsTexture2Id;
  //materials[3].displacement.height_texId  = 0;//displTextureId;
  //materials[3].displacement.height = 0.00f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS;
  int DISPLACED_MATERIAL3 = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.0f, 0.45f, 0.0f);
  int DIFFUSE_GREEN = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  for(int i=0;i<8;i++)
    pRender->AddMaterial(materials[i]);
    

/*
  HydraMaterial materials[8];

  //
  //
  materials[0].ambient.color = float3(0,0,0);
  materials[0].diffuse.color = float3(0.85f,0.85f,0.85f);
  //materials[0].diffuse.color_texId = chessTexId;
  materials[0].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[0].specular.cosPower   = 60.0f;
  materials[0].specular.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[0].reflection.color = float3(0.0f,0.0f,0.0f);
  materials[0].reflection.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[0].flags = HydraMaterial::DEFAULT_FLAGS;
  int FLOOR_MATERIAL = 0;

  //
  //
  materials[1].ambient.color    = float3(0,0,0);
  materials[1].diffuse.color    = float3(0.15f,0.15f,0.15f);
  materials[1].specular.color   = float3(0.25f,0.25f,0.25f);
  materials[1].specular.cosPower   = 60.0f;
  materials[1].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[1].reflection.color = float3(0.25f,0.25f,0.25f);
  materials[1].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[1].refraction.color = float3(0.65f,0.65f,0.65f);
  materials[1].refraction.fogColor      = float3(1,1,1);
  materials[1].refraction.fogMultiplyer = 0.25f; // 
  materials[1].refraction.exitColor     = float3(1,0,0); // interest effect
  materials[1].refraction.IOR           = 2.2f;
  materials[1].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int PURE_WHITE_GLASS = 1;


  //
  //
  materials[2].ambient.color    = float3(0,0,0);
  materials[2].diffuse.color    = float3(0.0f,0.15f,0.0f);
  materials[2].specular.color   = float3(0.0,0.25f,0.0f);
  materials[2].specular.cosPower   = 60.0f;
  materials[2].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[2].reflection.color = float3(0.0,0.25f,0.0f);
  materials[2].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[2].refraction.color = float3(0.0,0.65f,0.0f);
  materials[2].refraction.fogColor      = float3(0,1,0);
  materials[2].refraction.fogMultiplyer = 1.0f;           // a bit dark glass
  materials[2].refraction.exitColor     = float3(0.65f,0.65f,0);  // interest effect
  materials[2].refraction.IOR           = 1.2f;
  materials[2].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int DARK_GREEN_GLASS = 2;

  //
  //
  materials[3].ambient.color    = float3(0,0,0);
  materials[3].diffuse.color    = float3(0.15f,0.0f,0.0f);
  materials[3].specular.color   = float3(0.25f,0.0,0.0f);
  materials[3].specular.cosPower   = 60.0f;
  materials[3].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  materials[3].reflection.color = float3(0.25f,0.0,0.0);
  materials[3].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  materials[3].refraction.color         = float3(0.65f,0.0,0.0);
  materials[3].refraction.fogColor      = float3(1,1,1);
  materials[3].refraction.fogMultiplyer = 0.0f;           // pure transparent glass
  materials[3].refraction.exitColor     = float3(0.65f,0,0);  // common practice
  materials[3].refraction.IOR           = 1.8f;
  materials[3].flags = HydraMaterial::DEFAULT_FLAGS | HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;
  int LITE_RED_GLASS = 3;


  materials[4].ambient.color = float3(0,0,0);
  materials[4].diffuse.color = float3(0.45f, 0.45f, 0.45f);
  int DIFFUSE_WHITE = 4;

  materials[5].ambient.color = float3(0,0,0);
  materials[5].diffuse.color = float3(0.45f, 0.0f, 0.0f);
  int DIFFUSE_RED = 5;

  materials[6].ambient.color = float3(0,0,0);
  materials[6].diffuse.color = float3(0.45f, 0.45f, 0.0f);
  int DIFFUSE_YELLOW = 6;

  materials[7].ambient.color = float3(0,0,0);
  materials[7].diffuse.color = float3(0.0f, 0.0f, 0.45f);
  int DIFFUSE_BLUE = 7;

  for(int i=0;i<8;i++)
    pRender->AddMaterial(materials[i]);
  */



/*
  HydraMaterial h_materials[5];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);
  h_materials[1].diffuse.color = float3(0.5,0.5,0.5);
  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.0,0.5);

  for(int i=0;i<5;i++)
    pRender->AddMaterial(h_materials[i]);
    */


  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(1,3.99,1);
  flatLight2.kc = 1;
  flatLight2.kl = 0.001;
  flatLight2.kq = 0.00001;
  flatLight2.intensity = 2.0f;
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);

  pRender->AddLight(flatLight2);


  //RAYTR::Light pointLight;
  //pointLight.SetPointLight();
  //pointLight.pos.set(-2,4,-4);
  //pointLight.kc = 1;
  //pointLight.kl = 0.001;
  //pointLight.kq = 0.00001;

  //pointLight.intensity = 2.0f;
  //pRender->AddLight(pointLight);
}


void MakeTestScene_GlossySphereInCornellBox(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);


  HydraMaterial h_materials[5];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);

  h_materials[1].diffuse.color  = float3(0.1, 0.1, 0.1);
  h_materials[1].specular.color = float3(0.5,0.5,0.5);
  h_materials[1].specular.cosPower = 60;
  h_materials[1].reflection.color = h_materials[1].specular.color;
  h_materials[1].reflection.cosPower = 500;

  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.5,0.0);

  for(int i=0;i<5;i++)
    pRender->AddMaterial(h_materials[i]);
  

  // triangles
  Vertex4f vert[4];
  uint sideIndices[6];

  float size = 4;

  // floor
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-size,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-size,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = 1;
  vert[1].material_id = 1;
  vert[2].material_id = 1;
  vert[3].material_id = 1;


  float wrap = 4.0f;
  //float wrap = 1.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);
  sideIndices[0]=0;sideIndices[1]=1;sideIndices[2]=2;
  sideIndices[3]=2;sideIndices[4]=3;sideIndices[5]=0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // top
  vert[0].pos.set(-size,size,-size,1); vert[0].norm.set(0,-1,0,1);
  vert[1].pos.set(-size,size,size,1);  vert[1].norm.set(0,-1,0,1);
  vert[2].pos.set(size, size,size,1);   vert[2].norm.set(0,-1,0,1);
  vert[3].pos.set(size, size,-size,1);  vert[3].norm.set(0,-1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // left wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(1,0,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(1,0,0,1);
  vert[2].pos.set(-size,size,size,1);   vert[2].norm.set(1,0,0,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(1,0,0,1);

  vert[0].material_id = 2;
  vert[1].material_id = 2;
  vert[2].material_id = 2;
  vert[3].material_id = 2;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // right wall
  vert[0].pos.set(size,-size,-size,1); vert[0].norm.set(-1,0,0,1);
  vert[1].pos.set(size,-size,size,1);  vert[1].norm.set(-1,0,0,1);
  vert[2].pos.set(size,size,size,1);   vert[2].norm.set(-1,0,0,1);
  vert[3].pos.set(size,size,-size,1);  vert[3].norm.set(-1,0,0,1);

  vert[0].material_id = 4;
  vert[1].material_id = 4;
  vert[2].material_id = 4;
  vert[3].material_id = 4;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // back wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,0,1,1);
  vert[1].pos.set(size,-size,-size,1);  vert[1].norm.set(0,0,1,1);
  vert[2].pos.set(size,size,-size,1);   vert[2].norm.set(0,0,1,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(0,0,1,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);


  Sphere4f sphere;
  sphere.pos.set(0,-2,0,1);
  sphere.setRadius(2.0f);
  sphere.material_id = 1;
  pRender->AddSpheres(&sphere, 1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);

  pRender->AddLight(flatLight2);
}





void MakeTestScene_GlassSphereInCornellBox(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);


  HydraMaterial h_materials[6];

  h_materials[0].diffuse.color = float3(0.5,0.5,0.5);

  h_materials[1].diffuse.color  = float3(0.1, 0.1, 0.1);
  h_materials[1].specular.color = float3(0.5,0.5,0.5);
  h_materials[1].specular.cosPower = 60;
  h_materials[1].reflection.color = h_materials[1].specular.color;
  h_materials[1].reflection.cosPower = 500;

  h_materials[2].diffuse.color = float3(0.5,0.0,0.0);
  h_materials[3].diffuse.color = float3(0.0,0.5,0.0);
  h_materials[4].diffuse.color = float3(0.0,0.5,0.0);

  h_materials[5].ambient.color    = float3(0,0,0);
  h_materials[5].diffuse.color    = float3(0.15f,0.15f,0.15f);
  h_materials[5].specular.color   = float3(0.25f,0.25f,0.25f);
  h_materials[5].specular.cosPower   = 60.0f;
  h_materials[5].specular.brdf_id = HydraMaterial::BRDF_PHONG;
  h_materials[5].reflection.color = float3(0.45f,0.45f,0.45f);
  h_materials[5].reflection.brdf_id = HydraMaterial::BRDF_PHONG;

  h_materials[5].transparency.color = float3(0.65f,0.65f,0.65f);
  h_materials[5].transparency.fogColor      = float3(1,1,1);
  h_materials[5].transparency.fogMultiplyer = 0.25f; // 
  h_materials[5].transparency.exitColor     = float3(1,0,0); // interest effect
  h_materials[5].transparency.IOR           = 2.2f;
  h_materials[5].flags = HydraMaterial::DEFAULT_FLAGS;
  int THIN_PURE_WHITE_GLASS = 5;

  for(int i=0;i<6;i++)
    pRender->AddMaterial(h_materials[i]);


  // triangles
  Vertex4f vert[4];
  uint sideIndices[6];

  float size = 4;

  // floor
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-size,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-size,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = 1;
  vert[1].material_id = 1;
  vert[2].material_id = 1;
  vert[3].material_id = 1;


  float wrap = 4.0f;
  //float wrap = 1.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);
  sideIndices[0]=0;sideIndices[1]=1;sideIndices[2]=2;
  sideIndices[3]=2;sideIndices[4]=3;sideIndices[5]=0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // top
  vert[0].pos.set(-size,size,-size,1); vert[0].norm.set(0,-1,0,1);
  vert[1].pos.set(-size,size,size,1);  vert[1].norm.set(0,-1,0,1);
  vert[2].pos.set(size, size,size,1);   vert[2].norm.set(0,-1,0,1);
  vert[3].pos.set(size, size,-size,1);  vert[3].norm.set(0,-1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // left wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(1,0,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(1,0,0,1);
  vert[2].pos.set(-size,size,size,1);   vert[2].norm.set(1,0,0,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(1,0,0,1);

  vert[0].material_id = 2;
  vert[1].material_id = 2;
  vert[2].material_id = 2;
  vert[3].material_id = 2;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // right wall
  vert[0].pos.set(size,-size,-size,1); vert[0].norm.set(-1,0,0,1);
  vert[1].pos.set(size,-size,size,1);  vert[1].norm.set(-1,0,0,1);
  vert[2].pos.set(size,size,size,1);   vert[2].norm.set(-1,0,0,1);
  vert[3].pos.set(size,size,-size,1);  vert[3].norm.set(-1,0,0,1);

  vert[0].material_id = 4;
  vert[1].material_id = 4;
  vert[2].material_id = 4;
  vert[3].material_id = 4;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // back wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,0,1,1);
  vert[1].pos.set(size,-size,-size,1);  vert[1].norm.set(0,0,1,1);
  vert[2].pos.set(size,size,-size,1);   vert[2].norm.set(0,0,1,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(0,0,1,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);


  Sphere4f sphere;
  sphere.pos.set(0,-2,0,1);
  sphere.setRadius(2.0f);
  sphere.material_id = THIN_PURE_WHITE_GLASS;
  pRender->AddSpheres(&sphere, 1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);

  pRender->AddLight(flatLight2);
}



