#include <gl/glew.h>

#include "scenes.h"
#include "../obj_loader2/load_model/glm.h"
#include "ObjImport.h"
#include "../ColladaImport/ColladaImport.h"

#include <map>

#pragma warning(disable:4305)

using MGML_MATH::rnd;


void AddMeshFromOBJ(const std::string& a_fileName, IGraphicsEngine* pRender, const Matrix4x4f& a_mat)
{
  char* tmpFileName = const_cast<char*>(a_fileName.c_str());

  GLMmodel* pmodel1 = glmReadOBJ(tmpFileName);
  glmUnitize(pmodel1);

  //glmFacetNormals(pmodel1);        
  //glmVertexNormals(pmodel1, 90.0);
  
  AddMeshFromOBJ(pmodel1, pRender, a_mat);
  glmDelete(pmodel1);
}

void AddMeshFromOBJ(GLMmodel* pmodel1, IGraphicsEngine* pRender, const Matrix4x4f& a_mat, int a_externMatId)
{
  int indicesNum = pmodel1->numtriangles*3;

  Vertex4f* vert = new Vertex4f [pmodel1->numtriangles*3];
  unsigned int* indices = new unsigned int [pmodel1->numtriangles*3];

  int currVertex = 0;
  int currIndex = 0;

  std::map<std::string, int> myTextures;

  GLMgroup* pNext = pmodel1->groups;
  

  while(pNext!= NULL)
  {
    int currMaterialId = 0;
    
    std::map<int,int> materialIndices;

    if(pmodel1->materials!=NULL)
    {
      for(int matId_obj=0; matId_obj < pmodel1->nummaterials; matId_obj++)
      {
        RAYTR::HydraMaterial hmat;
        GLMmaterial& objMat = pmodel1->materials[matId_obj];

        //float3 summ = 0.1f*float3(objMat.ambient) + float3(objMat.diffuse) + float3(objMat.specular);
        //float3 sumInv(1.0f/summ.x, 1.0f/summ.y, 1.0f/summ.z);
        //float3 sumInv(1.0f, 1.0f, 1.0f);
       
        hmat.ambient.color  = 0.1*float3(objMat.ambient);
        hmat.diffuse.color  = float3(objMat.diffuse);
        hmat.diffuse.radiance = 2.0f;
        //hmat.specular.color = 0.1*float3(objMat.specular);
        //hmat.specular.brdf_id = RAYTR::Material::BRDF_PHONG;
        //hmat.reflection = hmat.specular;
        //hmat.specular.power = objMat.shininess;

        int currTextureId = INVALID_TEXTURE; // TODO this is not strictly correct
        {
          GLMtexture* pTexture = &pmodel1->textures[objMat.IDTextura];
          if(pTexture==NULL || objMat.IDTextura >= pmodel1->numtextures)
            ; // TODO this is not striclty correct
          else
          { 
            const char* path = pmodel1->textures[objMat.IDTextura].path;
            if(myTextures.find(path) == myTextures.end())
            {
              currTextureId = LoadTextureToRender(path, pRender);
              myTextures[path] = currTextureId;
            }
            else
              currTextureId = myTextures[path];
          }
          hmat.diffuse.color_texId = currTextureId;
        }

        materialIndices[matId_obj] = pRender->AddMaterial(hmat);
      }
    }

    for(int i=0;i<pNext->numtriangles;i++)
    {
      indices[currIndex+0] = currIndex+0;
      indices[currIndex+1] = currIndex+1;
      indices[currIndex+2] = currIndex+2;
      currIndex+=3;

      float* pos1 = pmodel1->vertices + 3*pmodel1->triangles[i].vindices[0];
      float* pos2 = pmodel1->vertices + 3*pmodel1->triangles[i].vindices[1];
      float* pos3 = pmodel1->vertices + 3*pmodel1->triangles[i].vindices[2];

      float* norm1 = pmodel1->normals + 3*pmodel1->triangles[i].nindices[0];
      float* norm2 = pmodel1->normals + 3*pmodel1->triangles[i].nindices[1];
      float* norm3 = pmodel1->normals + 3*pmodel1->triangles[i].nindices[2];

      float* tex1 = pmodel1->texcoords + 2*pmodel1->triangles[i].tindices[0];
      float* tex2 = pmodel1->texcoords + 2*pmodel1->triangles[i].tindices[1];
      float* tex3 = pmodel1->texcoords + 2*pmodel1->triangles[i].tindices[2];

      vert[currVertex+0].pos = a_mat*float4(pos1[0],pos1[1],pos1[2],1);
      vert[currVertex+1].pos = a_mat*float4(pos2[0],pos2[1],pos2[2],1);
      vert[currVertex+2].pos = a_mat*float4(pos3[0],pos3[1],pos3[2],1);

      if(pmodel1->normals != NULL)
      {
        vert[currVertex+0].norm = normalize(a_mat*float4(norm1[0],norm1[1],norm1[2],0));
        vert[currVertex+1].norm = normalize(a_mat*float4(norm2[0],norm2[1],norm2[2],0));
        vert[currVertex+2].norm = normalize(a_mat*float4(norm3[0],norm3[1],norm3[2],0));
      }

      if(pmodel1->texcoords != NULL)
      {
        vert[currVertex+0].t = float2(tex1[0],tex1[1]);
        vert[currVertex+1].t = float2(tex2[0],tex2[1]);
        vert[currVertex+2].t = float2(tex3[0],tex3[1]);
      }
      else
      {
        for(int i=0;i<3;i++)
           vert[currVertex+i].t = float2(0,0); 
      }

      int currMaterialId = materialIndices[pmodel1->triangles[i].m_matIndex];

      if(a_externMatId >= 0)
        currMaterialId = a_externMatId;

      vert[currVertex+0].material_id = currMaterialId;
      vert[currVertex+1].material_id = currMaterialId;
      vert[currVertex+2].material_id = currMaterialId;

      currVertex+=3;
    }

    pNext = pNext->next;
  }

  pRender->AddTriangles(vert, indicesNum, indices, indicesNum);

  delete [] vert;
  delete [] indices;
}