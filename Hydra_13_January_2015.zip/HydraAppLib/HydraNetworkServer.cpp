#include "HydraNetwork.h"
#include "Input.h"

struct ServerShmemView : public IHydraNetServerAPI
{
  ServerShmemView(const char* a_data, unsigned int a_size);
  ~ServerShmemView();

  void sendToPlugin(const char* a_data, unsigned int a_size);

  bool haveAnyMessageFromPlugin();
  unsigned int recieveFromPlugin(char* a_data, unsigned int a_maxSize);

  int getImageType() const;

  bool  imageWasRead();
  void* mapImageData();
  void  unmapImageData();

  void* mapImageDataHDR();
  void  unmapImageDataHDR();

protected:

};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern Input input;  


ServerShmemView::ServerShmemView(const char* a_data, unsigned int a_size)
{

}


ServerShmemView::~ServerShmemView()
{

}


void ServerShmemView::sendToPlugin(const char* a_message, unsigned int a_size)
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.messages;

  char* messageData = input.messages + sizeof(SharedBufferDataInfo);
  memset(messageData, 0, 1024);
  memcpy(messageData, a_message, a_size);

  pInfo->width   = strlen(a_message)+1;
  pInfo->height  = 1;
  pInfo->read    = 0;
  pInfo->written = HYDRA_SERVER_ID;
}

bool ServerShmemView::haveAnyMessageFromPlugin()
{
  return false;
}

unsigned int ServerShmemView::recieveFromPlugin(char* a_data, unsigned int a_maxSize)
{
  return 0;
}

bool  ServerShmemView::imageWasRead()
{
  return false;
}

void* ServerShmemView::mapImageData()
{
  return NULL;
}

void  ServerShmemView::unmapImageData()
{

}


void* ServerShmemView::mapImageDataHDR()
{
  return NULL;
}

void  ServerShmemView::unmapImageDataHDR()
{

}


int ServerShmemView::getImageType() const
{
  return SEND_IMAGE_LDR;
}


bool RenderWasCanceledByUser()
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.messages;

  char* messageData = input.messages + sizeof(SharedBufferDataInfo);

  if(!strcmp(messageData, "CancelRender") && pInfo->written == HYDRA_PLUGIN_ID)
    return true;

  return false;
}


void SendToPlugin(const char* a_message)
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.messages;

  char* messageData = input.messages + sizeof(SharedBufferDataInfo);
  if(a_message == NULL || input.messages == NULL)
    return;

  memset(messageData, 0, 1024);
  strcpy(messageData, a_message);

  pInfo->width   = strlen(a_message)+1;
  pInfo->height  = 1;
  pInfo->read    = 0;
  pInfo->written = HYDRA_SERVER_ID;
}




struct HydraShmemWin32ImageUnion : public IHydraImageUnionStorageObject
{
  HydraShmemWin32ImageUnion(int a_width, int a_height, const std::string& a_resourceName);
  ~HydraShmemWin32ImageUnion();

  void InitDeviceList(const std::vector<int>& a_devList);

  void ClearImage();
  void AddImageFromDevice(const float* a_inColorSumm, const float* a_inColorSummSquare, const ZBlockT* a_zBlocks);
  void GetFinalPitchLinearImage(float* a_outImage, int a_width, int a_height);

  float* GetTempColorPointer();
  float* GetTempColorSquarePointer();

  bool IsWaitingForDevice(int a_deviceId) const;
  bool IsReady() const;                            // does not wait for any device (!)
  bool IsLocked();

  bool IsRenderFinished() const;

  void Lock(int a_deviceId);
  void Unlock();

protected:

  struct UnionInfo
  {
    unsigned int sizeInBytes;
    unsigned int flags;
    unsigned int lock;
    unsigned int dummy2;
  };

  int m_width, m_height;
  std::vector<ZBlockT> m_imageBlocks;

  volatile void*      m_allData;
  volatile UnionInfo* m_pInfo;
  
  volatile float4*    m_image;
  volatile float4*    m_imageSquare;

  volatile float4*    m_temp1;
  volatile float4*    m_temp2;

};


HydraShmemWin32ImageUnion::HydraShmemWin32ImageUnion(int a_width, int a_height, const std::string& a_resourceName)
{

}

HydraShmemWin32ImageUnion::~HydraShmemWin32ImageUnion()
{

}

void HydraShmemWin32ImageUnion::InitDeviceList(const std::vector<int>& a_devList)
{

}



void HydraShmemWin32ImageUnion::ClearImage()
{

}

void HydraShmemWin32ImageUnion::AddImageFromDevice(const float* a_inColorSumm, const float* a_inColorSummSquare, const ZBlockT* a_zBlocks)
{

}

void HydraShmemWin32ImageUnion::GetFinalPitchLinearImage(float* a_outImage, int a_width, int a_height)
{

}

float* HydraShmemWin32ImageUnion::GetTempColorPointer() { return (float*)m_temp1; }
float* HydraShmemWin32ImageUnion::GetTempColorSquarePointer() { return (float*)m_temp2; }

bool HydraShmemWin32ImageUnion::IsWaitingForDevice(int a_deviceId) const
{
  return false;
}

bool HydraShmemWin32ImageUnion::IsReady() const
{
  return false;
}

bool HydraShmemWin32ImageUnion::IsLocked()
{
  return true;
}

bool HydraShmemWin32ImageUnion::IsRenderFinished() const
{
  return false;
}

void HydraShmemWin32ImageUnion::Lock(int a_deviceId)
{

}

void HydraShmemWin32ImageUnion::Unlock()
{

}


