#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "Cube.h"
#include "Prism.h"
#include "Camera.h"

#include "../ColladaImport/ColladaImport.h"




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void SetVSync(bool sync);
void glTablePrintf (int row, int col, const char *fmt, ...);
void CreateSHImages(int resX, int resY, int numLayers);


unsigned char* LoadTexture(const std::string& a_fileName, int* pW, int* pH);



void DrawDebugTreeData3();
void DrawDebugSphereBox();
void DrawDebugSpheres(std::string fileName);
void DrawDebugBoxes(std::string fileName);
void DrawDebugPoints(std::string fileName);
void DrawDebugSpheres2(std::string fileName, int maxFiles);
void DebugDrawRays(std::string fileNamePos, std::string fileNameDir, std::string fileNameColor);
void DrawDebugBoxesLayered(std::string fileName, int maxFiles);

