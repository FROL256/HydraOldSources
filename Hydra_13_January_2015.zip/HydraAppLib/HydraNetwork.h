#pragma once

enum SENDED_IMAGE_TYPE {
  SEND_IMAGE_LDR        = 0,
  SEND_IMAGE_HDR_FLOAT4 = 1,
  SEND_IMAGE_HDR_UINT16 = 2,
};

struct IHydraNetServerAPI
{
  virtual void sendToPlugin(const char* a_data, unsigned int a_size) = 0;
  
  virtual bool haveAnyMessageFromPlugin() = 0;
  virtual unsigned int recieveFromPlugin(char* a_data, unsigned int a_maxSize) = 0;
  
  virtual int   getImageType() const = 0;
  virtual bool  imageWasRead()   = 0;

  virtual void* mapImageData()   = 0;
  virtual void  unmapImageData() = 0;

  virtual void* mapImageDataHDR()   = 0;
  virtual void  unmapImageDataHDR() = 0;
};


struct IHydraNetPluginAPI
{
  IHydraNetPluginAPI(){}
  virtual ~IHydraNetPluginAPI(){}

  virtual void sendToServer(const char* a_data, unsigned int a_size) = 0;
  virtual void waitForAnyServerReply() = 0;

  virtual void updatePresets(const char* a_presetsXML) = 0;

  virtual bool  haveNewImageFromServer() = 0;
  virtual bool  lastImageWasFinal() const = 0;
  virtual int   getImageType() const = 0;

  virtual void* mapImageData()   = 0;
  virtual void  unmapImageData() = 0;

  virtual void* mapImageDataHDR()   = 0;
  virtual void  unmapImageDataHDR() = 0;

  virtual bool  hasConnection() const = 0;

  virtual bool haveAnyMessageFromServer() = 0;
  virtual unsigned int recieveFromServer(char* a_data, unsigned int a_maxSize) = 0;
};



enum PROGRAM_IDS{
      HYDRA_SERVER_ID = 1,
      HYDRA_PLUGIN_ID = 2, 
      HYDRA_SERVER_FINISH_ID = 3,
      };

struct SharedBufferDataInfo
{
  int width;
  int height;
  int read;
  int written;
};


void SendToPlugin(const char* a_message);
bool RenderWasCanceledByUser();


#include <vector>

struct IHydraImageUnionStorageObject
{
  IHydraImageUnionStorageObject(){}
  virtual ~IHydraImageUnionStorageObject() {}

  struct ZBlockT
  {
    int index;   // just block offset if global screen buffer
    int index2;  // index in other buffer + avg trace depth
    int counter; // how many times this block was traced?
    float diff;  // error in some units. stop criterion if fact
  };

  virtual void InitDeviceList(const std::vector<int>& a_devList) = 0;

  virtual void ClearImage() = 0;
  virtual void AddImageFromDevice(const float* a_inColorSumm, const float* a_inColorSummSquare, const ZBlockT* a_zBlocks) = 0;
  virtual void GetFinalPitchLinearImage(float* a_outImage, int a_width, int a_height) = 0;

  virtual float* GetTempColorPointer() = 0;
  virtual float* GetTempColorSquarePointer() = 0;

  virtual bool IsWaitingForDevice(int a_deviceId) const = 0;
  virtual bool IsReady() const = 0;                            // does not wait for any device (!)
  virtual bool IsLocked() = 0;

  virtual bool IsRenderFinished() const = 0;

  virtual void Lock(int a_deviceId) = 0;
  virtual void Unlock() = 0;
};

