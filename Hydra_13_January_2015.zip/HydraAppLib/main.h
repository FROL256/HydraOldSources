#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gl/glew.h>
#include <gl/freeglut.h> 

#ifndef MGML_GUARDIAN
#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"
#include "../gpu_rt/HydraExport.h"

#include "../ColladaImport/Camera.h"
#include "../ColladaImport/ColladaImport.h"

#include "Input.h"
#include "Cube.h"
#include "Prism.h"
#include "scenes.h"
#include "ReLight.h"

#include <sstream>

#include "../HDRCore/PostProcessEngine/image.h"
#include "../HDRCore/PostProcessEngine/filters/tonemappingfilter.h"
#include "../HDRCore/PostProcessEngine/filters/blurfilter.h"
#include "../HDRCore/PostProcessEngine/filters/boxfilter.h"

#include "../MLFilter/MLFilterAPI.h"

struct IHydraUserControl
{
  IHydraUserControl(){}
  virtual ~IHydraUserControl(){}

  virtual void SetScene(const HydraScene* a_data)         = 0;
  virtual void ReloadProfile(const std::string& a_path)   = 0;
  virtual void GenerateProfile(const std::string& a_path) = 0;

  virtual void LoadSceneFromNativeHydraFormat(const std::string& a_vsgfFile, const std::string& a_hydraProfilePath) = 0;

  virtual HydraScene* GetScene() = 0;
  virtual Camera& GetCamera(int index) = 0;
  virtual void SetCamera(int index, const Camera& a_cam) = 0;

  virtual HashMapImportParams* GetImportParamsHash() = 0;

  virtual ITextureImporter* GetTexImporter() = 0;
};

struct HydraControlCommon : public IHydraUserControl
{
  HydraControlCommon(IGraphicsEngine* a_pRender);
  ~HydraControlCommon();

  void SetScene(const HydraScene* a_data);
  void ReloadProfile(const std::string& a_path);
  void GenerateProfile(const std::string& a_path);
  void OutSamplerInfo(std::ostream& fout, int a_samplerSlot);

  void AddNewDataFromProfile(const std::string& a_path, std::vector<std::string> a_matNames);
  void LoadSceneFromNativeHydraFormat(const std::string& a_vsgfFile, const std::string& a_hydraProfilePath);

  HydraScene* GetScene() {return m_scene;}
  Camera& GetCamera(int index);
  void SetCamera(int index, const Camera& a_cam);

  HashMapImportParams* GetImportParamsHash() { return &m_importTextureMaxParams; }
 
  ITextureImporter* GetTexImporter() { return m_texImporter; }

  IGraphicsEngine*  m_pRender;
  HydraScene*       m_scene;
  ITextureImporter* m_texImporter;

  HashMapImportParams m_importTextureMaxParams;
};

enum PASS_STATES{ 
  STATE_PATH_TRACING       = 0,
  STATE_BUILD_IC           = 1,
  STATE_POST_PROCESS       = 2,
  STATE_COPY_IMAGE         = 3,
  STATE_PREPARE_PHOTON_MAP = 4,
  STATE_PREPARE_IRRAD_MAP  = 5,
  STATE_INITIAL            = 0xFFFFFFFE,
  STATE_FINAL              = 0xFFFFFFFF,
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
struct HydraRenderPassState
{
  HydraRenderPassState() : clearNow(false), 
                           layer(LAYER_COLOR), 
                           passCounter(0), 
                           layerdDepth(0),
                           state(STATE_INITIAL) {}

  int state;

  // for multiLayered
  //
  bool clearNow;
  int  passCounter;
  RENDER_LAYER layer;
  int  layerdDepth;
};


struct IHydraStateMachine
{
  virtual HydraRenderPassState NextState(const HydraRenderPassState& a_state, bool ptFinished) = 0;
};


struct EmptyStateMachineSM : IHydraStateMachine
{
  HydraRenderPassState NextState(const HydraRenderPassState& a_state, bool ptFinished);
};


struct SimplePathTracerSM : IHydraStateMachine
{
  HydraRenderPassState NextState(const HydraRenderPassState& a_state, bool ptFinished);
};

struct IrradianceCahePlusPathTracerSM : IHydraStateMachine
{
  HydraRenderPassState NextState(const HydraRenderPassState& a_state, bool ptFinished);
};


struct MultyLayeredSM : IHydraStateMachine
{
  HydraRenderPassState NextState(const HydraRenderPassState& a_state, bool ptFinished);
};



void DoMLFilter(IMLFilter* a_pMLFilter, const std::string& a_path, const std::string& a_outputImage4fFileName, bool a_filterPrimary);
void SaveImageFromRender(IGraphicsEngine* pRender, float path_tracing_time, bool takeImageOutside, int WinWidth, int WinHeight);
void SaveImageTM(const std::string& a_filename, float4* hdrImageData, int WinWidth, int WinHeight);
void SaveImageFromOutputFile(const char* a_inImage, const char* a_path, float path_tracing_time, int WinWidth, int WinHeight);

std::string GetSystemDate();



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



std::string ImageLayerName(const HydraRenderPassState& a_state);
void SaveFloat4ImageDump(int w, int h, const float4* a_dump, const std::string& a_fname);
void UpdateProgress(const char* a_message, float a_progress);
void UpdateImage(IGraphicsEngine* pRender, uint* a_data = NULL, bool a_lastImage = false);
void WaitForImageBufferIsFree();
void LoadImage4f(const char* fileName, int w, int h, float4* a_data);
void SimpleToneMapping(uint* otherLDRImage, float4* hdrImageData, int a_WinWidth, int a_WinHeight);
float scaleWithMatrix(float a_val, const Matrix4x4f& a_externTransform);

void Init();
void ShutDown();
void Display();
void Reshape(int Width, int Height);


void Mouse(int button, int state, int x, int y);
void MouseMotion(int x, int y);
void Keyboard(unsigned char key,int x,int y);
void KeyboardSpecial(int key, int x, int y);
void Idle();



