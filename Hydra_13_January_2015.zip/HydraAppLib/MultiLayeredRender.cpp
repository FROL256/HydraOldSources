#include "main.h"

extern int WinWidth;
extern int WinHeight;
extern Input input;
extern bool takeImageOutside;
extern uint* otherLDRImage;
extern IGraphicsEngine* pRender;
extern Camera* cam;
extern IMLFilter* pMLFilter;

std::string ImageLayerName(const HydraRenderPassState& a_state)
{
  std::stringstream str;
  str << "layer_" << a_state.layerdDepth << "_";
  const std::string& prefix = str.str();

  switch(a_state.layer)
  {
    case LAYER_POSITIONS:              return prefix + "1_positions";
    case LAYER_NORMALS:                return prefix + "2_normals";
    case LAYER_TEXCOLOR_AND_MATERIAL:  return prefix + "3_texcolor";
    case LAYER_TEXCOORD:               return prefix + "4_texcoord";
    case LAYER_INCOMING_PRIMARY:       return prefix + "5_primary_diffuse";
    case LAYER_INCOMING_RADIANCE:      return prefix + "6_secondary_diffuse";
    case LAYER_COLOR_THE_REST:         return prefix + "7_color_the_rest";
    case LAYER_COLOR_PRIMARY_AND_REST: return prefix + "8_color_the_rest_and_primary";
    case LAYER_COLOR:                  return prefix + "0_color_summ";
    default:                           return prefix + "0_unknown";
  }

}


void SaveFloat4ImageDump(int w, int h, const float4* a_dump, const std::string& a_fname)
{
  int wh[2] = {w,h};

  std::ofstream fout(a_fname.c_str(), std::ios::binary);

  fout.write((const char*)wh, sizeof(int)*2);
  fout.write((const char*)a_dump, sizeof(float4)*w*h);
  fout.flush();
  fout.close();
}


HydraRenderPassState EmptyStateMachineSM::NextState(const HydraRenderPassState& a_state, bool ptFinished)
{
  return a_state;
}

HydraRenderPassState SimplePathTracerSM::NextState(const HydraRenderPassState& a_state, bool ptFinished)
{
  HydraRenderPassState newState(a_state);

  switch(a_state.state)
  {
  case STATE_INITIAL:
    newState.state = STATE_PATH_TRACING;
    input.pathTracingEnabled = true;
    break;

  case STATE_PATH_TRACING:
    if(ptFinished)
      newState.state = STATE_FINAL;
    break;

  case STATE_FINAL:
    input.exit_status = true;
    break;

  default:
    break;
  }

  return newState;
}

int g_oldRetracePass = 1;
bool g_oldPtEnabled = false;

HydraRenderPassState IrradianceCahePlusPathTracerSM::NextState(const HydraRenderPassState& a_state, bool ptFinished)
{
  HydraRenderPassState newState(a_state);

  switch(a_state.state)
  {
  case STATE_INITIAL:
    {
      if(input.enablePhotonsGartheringDiffuse) // if FG enabled, prepare photon maps first
      {
        g_oldPtEnabled   = input.pathTracingEnabled;
        g_oldRetracePass = input.pmDiffuseRetrace;

        newState.state = STATE_PREPARE_PHOTON_MAP;
        newState.clearNow = true;

        input.pathTracingEnabled   = true;
        input.progressivePhotonMap = true;
        input.pmDiffuseRetrace = 1;
        //std::cerr << "next state = STATE_PREPARE_PHOTON_MAP" << std::endl;
      }
      else
      {
        newState.state = STATE_BUILD_IC;
        
        input.pathTracingEnabled     = g_oldPtEnabled;
        input.computeIrradianceCache = true;
        input.progressivePhotonMap   = false;
        input.pmDiffuseRetrace       = g_oldRetracePass;
        //std::cerr << "next state = STATE_BUILD_IC" << std::endl;
      }
    }
    break;

  case STATE_PREPARE_PHOTON_MAP:
    newState.state    = STATE_BUILD_IC;
    newState.clearNow = true;

    input.progressivePhotonMap   = false;
    input.pathTracingEnabled     = false;
    input.computeIrradianceCache = true;
    break;

  case STATE_BUILD_IC:
    newState.state = STATE_PATH_TRACING;
    input.pathTracingEnabled = true;
    newState.clearNow        = true;
    input.enablePhotonsGartheringDiffuse = false; // disable photon maps for final render with IC
    input.progressivePhotonMap           = false; // disable photon maps for final render with IC
    break;

  case STATE_PATH_TRACING:
    if(ptFinished)
      newState.state = STATE_FINAL;
    break;

  case STATE_FINAL:
    input.exit_status = true;
    break;

  default:
    break;
  }

  return newState;
}

int g_oldRaysMaxSPP = 0;
extern Timer g_totalTimer;

HydraRenderPassState MultyLayeredSM::NextState(const HydraRenderPassState& a_state, bool ptFinished)
{
  HydraRenderPassState newState(a_state);

  //GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
  //if(pathTracer == NULL)
    //return a_state;

  switch(a_state.state)
  {
  case STATE_INITIAL:
    newState.state = STATE_PATH_TRACING;
    newState.layer = LAYER_NORMALS;
    newState.passCounter = 0;
    input.pathTracingEnabled = true;
    g_oldRaysMaxSPP = input.pt_params.maxRaysPerPixel;
    input.pt_params.initialSPP = 16;
    input.pt_params.maxRaysPerPixel = 64;
    break;

  case STATE_PATH_TRACING:
    {
      newState.passCounter++;
      newState.clearNow = false;

      switch(newState.layer)
      {

      case LAYER_POSITIONS:
        if(ptFinished)
        {
          newState.clearNow = true;
          newState.layer = LAYER_NORMALS;
        }
        break;

      case LAYER_NORMALS:
        if(ptFinished)
        {
          newState.clearNow = true;
          newState.layer = LAYER_TEXCOLOR_AND_MATERIAL;
        }
        break;

      case LAYER_TEXCOLOR_AND_MATERIAL:
        if(ptFinished)
        {
          newState.clearNow = true;
          //newState.layer = IGraphicsEngine::LAYER_TEXCOORD;

          if(input.mlFilterPrimary)
            newState.layer = LAYER_INCOMING_PRIMARY;
          else
          {
            newState.layer = LAYER_COLOR_PRIMARY_AND_REST;
            input.pt_params.maxRaysPerPixel *= 2; // temporary fix for get better quality ...
          }

          input.pt_params.initialSPP = 1;
          input.pt_params.maxRaysPerPixel = g_oldRaysMaxSPP;
        }
        break;

      case LAYER_TEXCOORD:
        if(ptFinished)
        {
          newState.clearNow = true;
          newState.layer = LAYER_INCOMING_PRIMARY;
          input.pt_params.initialSPP = 1;
          input.pt_params.maxRaysPerPixel = g_oldRaysMaxSPP;
        }
        break;


      case LAYER_INCOMING_PRIMARY:
        if(ptFinished)
        {
          newState.clearNow = true;
          newState.layer = LAYER_INCOMING_RADIANCE;
        }
        break;

      case LAYER_COLOR_PRIMARY_AND_REST:
        if(ptFinished)
        {
          newState.clearNow = true;
          newState.layer = LAYER_INCOMING_RADIANCE;
        }
        break;

      case LAYER_INCOMING_RADIANCE:
        
        if(ptFinished)
        {
          newState.layerdDepth = a_state.layerdDepth + 1;

          if(input.mlFilterPrimary)
          {

            if(newState.layerdDepth == input.mlLayersNum) 
            {
              newState.clearNow = true;
              newState.layer    = LAYER_COLOR_THE_REST;
              newState.layerdDepth--; // this is for correct "the rest" rendering

              input.pt_params.maxRaysPerPixel *= 2; // temporary fix for get better quality ...
            }
            else
            {
              newState.clearNow    = true;
              newState.layer       = LAYER_POSITIONS;
            }
          }
          else
          {
            newState.clearNow = false;
            newState.state = STATE_POST_PROCESS;
          }

          //pathTracer->ResetPathTracing();
        }
        break;

      case LAYER_COLOR_THE_REST:

         if(ptFinished)
         {
           newState.clearNow = false;
           newState.state = STATE_POST_PROCESS;
         }

       break;
      }


    }
    break;

  case STATE_POST_PROCESS:
    {
      /*std::stringstream cmd;

      cmd << "C:\\[Hydra]\\filter\\filtering.exe \"" << cam->pos << "\"";

      std::ofstream camFile("C:\\[Hydra]\\filter\\camera.txt");
      camFile << cam->pos << std::endl;

      // call Alexei Filter and get result back
      //
      UpdateProgress("Filter final image", 0.0f);
      std::cerr << "cmd = " << cmd.str().c_str() << std::endl;
      
      Sleep(10);
      system(cmd.str().c_str());
      Sleep(10);
      */

      UpdateProgress("Filter final image ... ", 0.0f);
      DoMLFilter(pMLFilter, "C:\\[Hydra]\\filter\\input_bin\\", "C:\\[Hydra]\\filter\\output.imagef4", input.mlFilterPrimary);
      SaveImageFromOutputFile("C:\\[Hydra]\\filter\\output.imagef4", "C:\\[Hydra]\\rendered_images\\", g_totalTimer.getElapsed(), WinWidth, WinHeight);

      takeImageOutside  = true;
      newState.state    = STATE_COPY_IMAGE;
      newState.clearNow = false;
      input.exit_status = false;

    }
    break;


  case STATE_COPY_IMAGE:
    {
      float4* hdrImageData = (float4*)malloc(WinWidth*WinHeight*sizeof(float4));
      
      if(hdrImageData!=NULL)
      {
        LoadImage4f("C:\\[Hydra]\\filter\\output.imagef4", WinWidth, WinHeight, hdrImageData);
        WaitForImageBufferIsFree();
        UpdateImage(pRender, (uint*)hdrImageData, true);
      }

      free(hdrImageData); hdrImageData = NULL;

      newState.state    = STATE_FINAL;
      newState.clearNow = false;
      input.exit_status = true;
    }
    break;

  case STATE_FINAL:
    input.exit_status = true;
    break;

  default:
    break;
  }

  return newState;
}


void LoadImage4f(const char* fileName, int w, int h, float4* a_data)
{
  std::ifstream fin(fileName, std::ios::binary);

  int wh[2];
  fin.read((char*)wh, 2*sizeof(int));

  if(wh[0]!= w || wh[1]!=h)
    return;

  fin.read((char*)a_data, w*h*sizeof(float4));
}


/*
inline float4 ToneMapping4(float4 color)
{
  //float maxColInv = 1.0f/fmaxf(color.x, fmaxf(color.y, color.z));
  //return (maxColInv < 1.0f) ? color*maxColInv : color;
  
  return make_float4(::fminf(color.x, 1.0f), ::fminf(color.y, 1.0f), ::fminf(color.z, 1.0f), color.w);
}


inline unsigned int RealColorToUint32(const float4& real_color)
{
  float  r = real_color.x*255.0f;
  float  g = real_color.y*255.0f;
  float  b = real_color.z*255.0f;
  unsigned char red = (unsigned char)r, green = (unsigned char)g, blue = (unsigned char)b;
  return red | (green << 8) | (blue << 16) | 0xFF000000;
}
*/

void SimpleToneMapping(uint* otherLDRImage, float4* hdrImageData, int a_WinWidth, int a_WinHeight)
{
  const int size = a_WinWidth*a_WinHeight;

  #pragma omp parallel for
  for(int i=0;i<size;i++)
  {
    float4 color = hdrImageData[i];

    color.x = pow(color.x, 1.0f/input.hdrGamma);
    color.y = pow(color.y, 1.0f/input.hdrGamma);
    color.z = pow(color.z, 1.0f/input.hdrGamma);

    otherLDRImage[i] = RealColorToUint32(ToneMapping4(color));
  }
}




void DoMLFilter(IMLFilter* a_pMLFilter, const std::string& a_path, const std::string& a_outputImage4fFileName, bool a_filterPrimary)
{
  std::ofstream outputImage(a_outputImage4fFileName.c_str(), std::ios::binary);

  if(!outputImage.is_open() || a_pMLFilter == NULL)
  {
    std::cerr << "DoMLFilter failed due to can't open output image file or null pointer 'a_pMLFilter' !" << std::endl;
    return;
  }

  std::string primaryImageFile   = a_path + "layer_0_5_primary_diffuse.imagef4";
  std::string secondaryImageFile = a_path + "layer_0_6_secondary_diffuse.imagef4";

  std::string rest1ImageFile      = a_path + "layer_0_7_color_the_rest.imagef4";
  std::string rest2ImageFile      = a_path + "layer_0_8_color_the_rest_and_primary.imagef4";

  std::string texcImageFile      = a_path + "layer_0_3_texcolor.imagef4";
  std::string normalsImageFile   = a_path + "layer_0_2_normals.imagef4";
 
  HDRImage primary, secondary, tex, normals, rest, lum, sec2;

  tex.loadFromImage4f(texcImageFile);
  normals.loadFromImage4f(normalsImageFile);
  secondary.loadFromImage4f(secondaryImageFile);
  lum = secondary;

  MLSettings settings;

  //std::cerr << "filterSize = " << input.mlRadius << std::endl;

  settings.filterPrimary = a_filterPrimary;
  settings.filterSize    = input.mlRadius;
  settings.sigma         = input.mlSigma;

  a_pMLFilter->SetPresets(settings);

  MLAllData data;
  data.w         = normals.width();
  data.h         = normals.height();
  data.primary   = NULL; 
  data.secondary = &secondary.data()[0];
  data.normals   = &normals.data()[0];
  data.txcolor   = &tex.data()[0];
  data.out_res   = &lum.data()[0];

  a_pMLFilter->SetAllInputData(data);

  if(a_filterPrimary)
  {
    primary.loadFromImage4f(primaryImageFile);
    rest.loadFromImage4f(rest1ImageFile);
    data.primary = &primary.data()[0];
    a_pMLFilter->SetAllInputData(data);
    a_pMLFilter->FilterIrradiance();
    lum.add(rest);
  }
  else
  {
    rest.loadFromImage4f(rest2ImageFile);
    a_pMLFilter->FilterIrradiance();
    lum.add(rest);
  }

  int wh[2] = {WinWidth, WinHeight};

  outputImage.write((const char*)wh, sizeof(int)*2);
  outputImage.write((const char*)&lum.data()[0], sizeof(float4)*WinWidth*WinHeight);
  outputImage.close();
}

