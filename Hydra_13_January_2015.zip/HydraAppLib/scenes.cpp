#include <gl/glew.h>

#include "scenes.h"

#pragma warning(disable:4305)

using MGML_MATH::rnd;

extern Camera* cam;


#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"
using std::string;


