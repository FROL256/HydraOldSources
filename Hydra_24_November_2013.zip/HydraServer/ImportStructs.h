#ifndef __IMPORTSTRUCTS_H__
#define __IMPORTSTRUCTS_H__

struct GeometryObj
{
  GeometryObj()
  {
    n_verts = 0;
    n_faces = 0;
  }

  float m[16];
  int n_verts;
  int n_faces;
  std::wstring mesh_id;
  
  std::vector<int> material_id;
  
  std::vector<float> positions;
  std::vector<int> pos_indeces;

  std::vector<int> face_smoothgroups;

  std::vector<float> tex_coords;
  std::vector<int>   tex_coords_indices;
  
  float bbox[6];

	template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & m;
    ar & n_verts;
		ar & n_faces;
		ar & mesh_id;
		ar & material_id;
		ar & positions;
		ar & pos_indeces;
    ar & face_smoothgroups;
		ar & tex_coords;
    ar & tex_coords_indices;
    ar & bbox;
  }

  void reserveMemory(int n)
  {
    n_verts = 0;
    n_faces = 0;

    pos_indeces.reserve(3*n);
    positions.reserve(n);
    material_id.reserve(n/10);
    tex_coords_indices.reserve(3*n);
    tex_coords.reserve(n);
  }


};


struct CameraObj
{
  CameraObj()
  {
    fov = 45;
    nearClipPlane = 0.001f;
    farClipPlane  = 10000.0f;

    dofEnabled = false;
    isOrtho = false;
  }

  float fov;
  float farClipPlane;
  float nearClipPlane;

  float dofFocalDist;
  float dofStrength;
  bool  dofEnabled;

  bool  isOrtho;

  float posMatrix[16];
  float targetMatrix[16];
  float worldViewMatrix[16];

  std::wstring camName;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & fov;
    ar & farClipPlane;
    ar & nearClipPlane;

    ar & dofFocalDist;
    ar & dofStrength;
    ar & dofEnabled;

    ar & isOrtho;

    ar & posMatrix;
    ar & targetMatrix;
    ar & worldViewMatrix;

    ar & camName;
  }


};


struct LightObj
{
  LightObj()
  {
    for(int i=0;i<3;i++)
    {
      position[i]  = 0;
      direction[i] = 0;
      color[i]     = 0;
    }

    intensity = 0;
    lightName = L"default_name";

    for(int k=0;k<4;k++)
    {
      for(int j=0;j<4;j++)
      {
        float val = (k == j) ? 1.0f : 0.0f; 
        m[j*4+k] = val;
        targetMatrix[j*4+k] = val;
      }
    }

    isTargeted = false;
    on = true;

    directLightStart = 0.0f;
    kc = 1.0f; kl = 0.0f; kq = 0.0f;
  }

  std::wstring lightName;
  std::wstring lightType;
  std::wstring shadowType;
  std::wstring spotShape;
  std::wstring envTexturePath;

  bool useGlobal;
  bool absMapBias;
  bool overshoot;
  bool on;
  bool computeShadow;
  bool isTargeted;

  float position[3];
  float direction[3];
  float color[3];

  float intensity;
  float aspect;
  float hotsize;
  float fallsize;
  float attenStart;
  float attenEnd;
  float TDist;
  float kc,kl,kq;
  float directLightStart;

  float mapBias;
  float mapRange;
  float mapSize;
  float rayBias;


  float m[16];
  float targetMatrix[16];

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & lightName;
    ar & lightType;
    ar & shadowType;
    ar & spotShape;
    ar & envTexturePath;
    ar & useGlobal;
    ar & absMapBias;
    ar & overshoot;
    ar & on;
    ar & computeShadow;
    ar & isTargeted;
    ar & position;
    ar & direction;
    ar & color;
    ar & intensity;
    ar & aspect;
    ar & hotsize;
    ar & fallsize;
    ar & attenStart;
    ar & attenEnd;
    ar & TDist;
    ar & kc;
    ar & kl;
    ar & kq;
    ar & directLightStart;
    ar & mapBias;
    ar & mapRange;
    ar & mapSize;
    ar & rayBias;
    ar & m;
    ar & targetMatrix;
  }


};

struct TextureObj
{
	std::wstring texName;
	std::wstring texClass;
	std::wstring texAmount;
	std::wstring mapName;
	std::wstring texFilter;
	std::wstring mapType;

	bool texInvert;

	float uOffset;
	float vOffset;
	float uTiling;
	float vTiling;
	float angle;
	float blur;
	float blurOffset;
	float noiseAmt;
	float noiseSize;
	int noiseLevel;
	float noisePhase;

	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & texName;
		  ar & texClass;
		  ar & texAmount;
		  ar & mapName;
		  ar & texFilter;
		  ar & mapType;

		  ar & texInvert;

		  ar & uOffset;
		  ar & vOffset;
		  ar & uTiling;
		  ar & vTiling;
		  ar & angle;
		  ar & blur;
		  ar & blurOffset;
		  ar & noiseAmt;
		  ar & noiseSize;
		  ar & noiseLevel;
		  ar & noisePhase;
    }

    TextureObj()
    {
      texInvert = false;

      uOffset = 0;
      vOffset = 0;
      uTiling = 0;
      vTiling = 0;
      angle = 0;
      blur = 0;
      blurOffset = 0;
      noiseAmt = 0;
      noiseSize = 0;
      noiseLevel = 0;
      noisePhase = 0;
    }
};

struct MaterialObj
{
	bool sub;

	int id;
	std::wstring name;
	float ambient_color[3];
	float diffuse_color[3];
	float specular_color[3];
  float filter_color[3];
	float shininess;
	float shine_strength;
	float transparency;
	//float wire_size;
	std::wstring shading;
  float opacity;
  float IOR;
	float opacity_falloff;
	float self_illumination;
	bool twosided;
	/*bool wire;
	bool wire_units; //true - units, false - pixels*/
	bool falloff; //true - out, false - in
	bool facemap;
	bool soften;
	std::wstring transparency_type;
	int num_subMat;

	std::vector<TextureObj> textures;


	template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & sub;

		  ar & id;
		  ar & name;
		  ar & ambient_color;
		  ar & diffuse_color;
		  ar & specular_color;
      ar & filter_color;
		  ar & shininess;
		  ar & shine_strength;
		  ar & transparency;
		 // ar & wire_size;
		  ar & shading;
		  ar & opacity_falloff;
		  ar & self_illumination;
		  ar & twosided;
		 /* ar & wire;
		  ar & wire_units; */
		  ar & falloff; 
		  ar & facemap;
		  ar & soften;
		  ar & transparency_type;
		  ar & num_subMat;

		  ar & textures;
    }

    MaterialObj()
    {
      for(int i = 0; i < 3; i++)
        ambient_color[i] = 0;

      for(int i = 0; i < 3; i++)
        diffuse_color[i] = 0;

      for(int i = 0; i < 3; i++)
        specular_color[i] = 0;

      for(int i = 0; i < 3; i++)
        filter_color[i] = 0;

      shininess = 0;
      shine_strength = 0;
      transparency = 0;
      std::wstring shading = L"";
      opacity = 0;
      IOR = 0;
      opacity_falloff = 0;
      self_illumination = 0;
      twosided = false;
      falloff = false; 
      facemap = false;
      soften = false;
      sub = false;
      transparency_type = L"";

      id = 0;
      name = L"hydra_material_null";
      num_subMat = 0;
    }

};

struct TransferContents
{
  enum {SCENE, TEXTURE_FILES, VRSCENE_FILE, CONFIG, RENDER_SETTINGS, HEADER};
  int contents;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & contents;
  }

};

struct Header
{
  enum {COLLADA_PROFILE, TEXTURE_FILE};
  int contents;
  std::wstring file_name;

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & contents;
    ar & file_name;
  }

};

struct Included
{
  bool geometry;
  bool lights;
  bool materials;
  bool tree;
  bool spheres;

  std::string sceneDumpName;
  std::string colladaProfile;

  std::wstring render_type;

  int geomObjNum;
  int imgObjNum;

  std::wstring AccType;
  std::wstring ConstrMode;

  void IncludeAdd()
  {
    geometry  = true;
    lights    = true;
    materials = true;
    tree      = false;
    spheres   = true;

    sceneDumpName  = "c:/[hydra]/pluginFiles/test.dump";
    colladaProfile = "c:/[hydra]/pluginFiles/hydra_profile.xml";
  }

  template <class Archive>
  void serialize(Archive& ar, unsigned int version)
  {
    ar & geometry;
    ar & lights;
    ar & materials;
    ar & tree;
    ar & spheres;

    ar & sceneDumpName;

    ar & geomObjNum;
    ar & imgObjNum;  

    ar & AccType;
    ar & ConstrMode;
  }
};

struct SphereObj
{
  float m[16];
  float center[4];
  float radius;
  std::wstring mesh_id;
  int material_id;
  float bbox[6];
  template <class Archive>
    void serialize(Archive& ar, unsigned int version)
    {
      ar & m;
      ar & center;
		  ar & radius;
		  ar & mesh_id;
		  ar & material_id;
      ar & bbox;
    }
};


#endif