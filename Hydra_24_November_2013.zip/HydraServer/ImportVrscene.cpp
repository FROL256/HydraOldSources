#include "ImportVrscene.h"

namespace vrscene
{
  bool vrsceneImport::getValue(std::string const& section_type, std::string const& section_name, std::string const& entry, std::string & result)
  {
    vrsceneData::const_iterator vrs;

    for(vrs = vrscene.begin(); vrs != vrscene.end(); ++vrs)
    {
      if(vrs->first == section_type && vrs->second.first == section_name)
        break;
    }
    if (vrs == vrscene.end())
      return false;

    Entries::const_iterator it = find_if(vrs->second.second.begin(), vrs->second.second.end(), first_is(entry));
    if (it == vrs->second.second.end())
      return false;

    result = it->second;
    return true;
  }

  void vrsceneImport::parseFile()
  {
    std::ifstream fileStream;

    fileStream.open(fileName.c_str());
    if(!fileStream)
    {
      std::cout << "Can't open file :" << fileName << std::endl;
      return;
    }

    std::vector <std::string> lns;

    std::string s;
    while(!fileStream.eof())
    {
      std::getline(fileStream, s);
      boost::algorithm::trim(s);
      lns.push_back(s+='\n');
    }

    fileStream.close();

    lns.erase(remove_if(lns.begin(), lns.end(), is_comment()), lns.end());
    std::string text = std::accumulate(lns.begin(), lns.end(), std::string());

    vrscene_parser parser(vrscene);

    parse_info<> info = parse(text.c_str(), parser, nothing_p);
    if (!info.hit)
    {
      std::cout << "Parse error\n";
      return;
    }
  }


  void vrsceneImport::importVrsceneInfo()
  {

  }
}