#include "../HydraAppLib/main.h"

#ifndef MAXPL_H
  #include "maxPluginServer.h"
#endif

bool g_importFromFile = true;


using namespace MGML;
using namespace MGML_MATH;
using namespace std;

int WinWidth  = 640;
int WinHeight = 480;
float gl_ver  = 3.0;

IGraphicsEngine* pRender = NULL;
IReLightProxy*   pReLightApp = NULL;
IHydraUserControl* pUserControl = NULL;
Input input;  

Camera* cam;

volatile bool pathTracingFinished = true;
int ticksOld = 0;
int ticksNew = 0;
bool stopCountTime = false;
bool firstPass = 0;

float flyRadius = 8.0f;

void ConcoleProgressBar(const char* a_message, float a_progress)
{
  fprintf(stderr, "%s: %.0f%% \r", a_message, a_progress*100.0f);
}


void Init()
{
	try
	{

  //  if(0)
  //  {

  //    Matrix4x4f lightTransform(1, 4.17022e-008, -1.31002e-008, -1.98226e-006, 
  //      -4.37114e-008, 0.954035, -0.299697, -45.3489, 
  //      0, 0.299697, 0.954035, 152.843, 
  //      0, 0, 0, 1 );

  //    float3 oldPos(-0.00132704, -0.00132704, -0.00132704);
  //    float3 lpos = lightTransform*oldPos;

  //    std::cerr << "lighgt pos = " << lpos << std::endl;
  //  }

    gl_ver = GetCurrGLVersion();

    if(gl_ver <= 3.1)
      glBuildFont(); // my custom function

    //------------------------------------------------------------------
    CHECK_GL_ERRORS;
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glViewport(0, 0, WinWidth, WinHeight);

    glClear(GL_COLOR_BUFFER_BIT);
    if(gl_ver <= 3.1)
    {
      glDisable(GL_LIGHTING);
      glDisable(GL_TEXTURE_2D);
      glColor3f(1,1,1);
      glTablePrintf (1, 3, "Init Renderer ... ");
    }
    glutSwapBuffers();
    CHECK_GL_ERRORS;
    //------------------------------------------------------------------

    glewExperimental = GL_TRUE;
    GLenum err=glewInit();
    if(err!=GLEW_OK)
    {
      fprintf(stderr, "glewInitError: %s\n", glewGetErrorString(err));
      RUN_TIME_ERROR("glewInit() failed");
    }

    // flush OpenGL errors
    int tmp = 0;
    while(glGetError()!= GL_NO_ERROR && tmp < 100) tmp++;

    input.reset();
    SetVSync(0);
    CHECK_GL_ERRORS;

    int flags = 0;
    if(input.rayBufferFullSize)
      flags = GPU_RT_MEMORY_FULL_SIZE_MODE;

    if(input.ext_renderer == "OpenGL 1")
      pRender = new OpenGL_Render(WinWidth,WinHeight);
    else   if(input.ext_renderer == "Exporter")
      pRender = new HydraExporter(WinWidth, WinHeight);
    else
      pRender = new GPU_Path_Tracer(WinWidth, WinHeight, flags);


    pReLightApp  = new TestReLightPoxy(pRender);
    pUserControl = new HydraControlCommon(pRender);
    pUserControl->SetScene(LastImportedScene()); // object ids of scene that was imported from collada

    cam = new Camera();

    //cam->SetPerspectiveProjection(45.0f, float(WinWidth)/float(WinHeight), 0.1f, 10000.0f);    
    cam->SetPerspectiveProjection(input.camApect/2.0f, float(WinWidth)/float(WinHeight), 0.01f, 10000.0f);
    
    //std::cout << "sizeof(HydraMaterial): " << sizeof(HydraMaterial) << std::endl;

    Matrix4x4f mr,mt,ms, ms2;
    float k = 0.1f/0.025400;
    ms.SetScale(float3(k,k,k));
 
    flyRadius = 4;

    //------------------------------------------------------------------
    if(gl_ver <= 3.1)
    {
      glClear(GL_COLOR_BUFFER_BIT);
      glTablePrintf (1, 3, "Init Renderer ... ");
      glTablePrintf (2, 3, "Loading Scene ... ");
      glutSwapBuffers();
    }
    //------------------------------------------------------------------

    //std::cerr << " input.inColladaFile =  " << input.inColladaFile.c_str() << std::endl;

    if(g_importFromFile)
      LoadSceneDump("C:/[Hydra]/pluginFiles/test.dump", "C:/[Hydra]/pluginFiles/hydra.CONF", pRender, pUserControl, &input);
    else
      ServerFileMain(pRender, pUserControl, &input); 

    pRender->SetProgressBarCallback(ConcoleProgressBar);

    if(input.reloadHydraProfile)
    {
      pUserControl->ReloadProfile(input.inColladaProfile);
      input.reloadHydraProfile = false;
    }

    std::cerr << "light num = " << pRender->GetLightNumber() << std::endl;

    if(pRender->GetLightNumber() == 0) // no lights in scene? Add one!
    {
      RAYTR::Light addedLight;
      addedLight.SetLighType(RAYTR::Light::LIGHT_TYPE_SKY);
      addedLight.pos.set(0,10000,0);
      addedLight.kc = 1;
      addedLight.kl = 0.0;
      addedLight.kq = 0.0;
      addedLight.intensity = 0.5f;
      addedLight.color.set(1.0f, 0.95f, 0.95f);
      addedLight.SetAORayLength(10000.0f);
      addedLight.sphTexIndex = INVALID_TEXTURE;
      pRender->AddLight(addedLight);
    }

    bool hydraProfileExists = false;
    //if(input.inColladaFile != "")
    //{
    //  std::ifstream testFin(input.inColladaProfile.c_str());
    //  hydraProfileExists = testFin.is_open();
    //  testFin.close();
    //  ImportSceneFromCollada(pRender, input.inColladaFile, cam, ms, input.inColladaProfile);
    //}

    Ray_Tracer* pRayTracer = dynamic_cast<Ray_Tracer*>(pRender);
    if(pRayTracer != 0 && !input.animateLight)
      pRayTracer->AddLightsAsGeometry();  // try to add lights as geometry if needed

    pUserControl->SetScene(LastImportedScene()); // object ids of scene that was imported from collada
    if(input.generateHydraProfiles)
    {
      pUserControl->GenerateProfile(std::string(LastImportedScene()->scenefolder) + "/hydra_profile_generated.xml");           
      //if(!hydraProfileExists)
      //{
      //  ifstream source((std::string(LastImportedScene()->scenefolder) + "/hydra_profile_generated.xml").c_str());
      //  ofstream dest((std::string(LastImportedScene()->scenefolder) + "/hydra_profile.xml").c_str());
      //  dest << source.rdbuf();
      //  source.close();
      //  dest.close();
      //  std::cerr << "copy 'hydra_profile_generated' to 'hydra_profile'" << std::endl;
      //}
    }
    //------------------------------------------------------------------
    if(gl_ver <= 3.1)
    {
      glClear(GL_COLOR_BUFFER_BIT);
      glTablePrintf (1, 3, "Init Renderer ... ");
      glTablePrintf (2, 3, "Loading Scene ... ");
      glTablePrintf (3, 3, "Building BVH ... ");
      glutSwapBuffers();
    }
    //------------------------------------------------------------------

    //pRender->DebugCall("SetVoxelizeOnLoad", ToString(int(input.voxelizeOnLoad)));

		cout << "constructing acceleration structures (may take a very long time), please wait...\n";
    Timer treeBuildTimer;
    treeBuildTimer.start();
    float timeStart = treeBuildTimer.getElapsed();

    pRender->BuildAccelerationStructures(input.accelStructConstructionMode);
    
    float totalConstructionTime = treeBuildTimer.getElapsed() - timeStart;
    cout << "construction time: " << totalConstructionTime << "s" << endl;

    HydraExporter* pExporter = dynamic_cast<HydraExporter*>(pRender);
    if(pExporter != NULL)
      pExporter->ExportSceneGeometry(input.exportFilePath, LastImportedScene()->materials);

	}
	catch(std::bad_alloc e)
	{
    cerr << std::endl;
		string err_msg = NotEnoughMemory();
		ALERT(err_msg);
		cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
		exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
	catch(...)
	{
    cerr << std::endl;
		cout << "Unexpected Exception!" << endl;
		exit(-1);
	}
}


//////////////////////////////////////////////////////////////////////////
////
void ShutDown()
{
  try
	{
    cerr << "destroying resources..." << std::endl;
    cerr.flush();

    delete cam; cam = NULL;
    delete pUserControl; pUserControl = NULL;
    delete pReLightApp; pReLightApp = NULL;
		delete pRender; pRender = NULL;

    cerr << "resources were destroyed" << std::endl;
    cerr.flush();
	}
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
}


void Display()
{
  static int FramesCount = 0;
	static float FPS = 60; // ������� ������ � �������

	static float t_process = 1;
	static float omega = 0.5;
  static float path_tracing_time = 0.0f;
  static float lastImageSavedTime = 0.0;
  static bool imageSaved = false;
  static PP_FILTERS::Image src, dst;

  static Timer timer; 

	try
	{
    input.ReadXMLFromSharedMemory();

		if(input.exit_status) 
      exit(0);

    if(t_process > 1000)
      t_process = 1.0f;

    if(!input.pathTracingEnabled)
    { 
      t_process += (omega/FPS);

      int numLights = pRender->GetLightNumber();
      if(numLights > 0)
      { 
        RAYTR::Light light = pRender->GetLight(0);
        light.pos.x = flyRadius*sin(t_process);
        light.pos.z = flyRadius*cos(t_process);
        if(input.animateLight)
          pRender->SetLight(light, 0);
      }
    
      cam->Move(input.cam_mov);
      cam->SetRotation(input.cam_rot);
    }

    // save and restore camera
    //
    if(input.saveCamera != 0)
    {
      stringstream tmpstream; tmpstream << "cam" << input.saveCamera << ".txt";
      cam->Save(tmpstream.str());
      input.saveCamera = 0;
    }
    else if(input.restoreCamera != 0)
    {
      stringstream tmpstream; tmpstream << "cam" << input.restoreCamera << ".txt";
      cam->Load(tmpstream.str());
      cam->SetPerspectiveProjection(input.camApect/2.0f, float(WinWidth)/float(WinHeight), 0.01f, 10000.0f);    
      input.cam_rot = cam->GetRotation();
      input.restoreCamera = 0;
    }

    if(input.reloadHydraProfile)
    {
      pUserControl->ReloadProfile(input.inColladaProfile);
      input.reloadHydraProfile = false;
    }
    
    cam->SetPerspectiveProjection(input.camApect/2.0f, float(WinWidth)/float(WinHeight), 0.01f, 10000.0f);

    //
    //
    pRender->SetWorldViewMatrix((cam->GetWorldMatrix()*cam->GetViewMatrix()).L);
    pRender->SetProjectionMatrix(cam->GetProjectionMatrix().L);

    pRender->SetVariable("drawIrradianceCachePixelPoints", int(input.drawIrradianceCachePixelPoints));
    pRender->SetVariable("drawPhotons", int(input.drawPhotons));
    pRender->SetVariable("drawPhotonsCaustic", int(input.drawPhotonsCaustic));
    pRender->SetVariable("debugViewSH", int(input.debugViewSHReconstructed));
    pRender->SetVariable("g_debugLayerDraw", input.debugLayerDraw);
    pRender->SetVariable("g_saveRaySamples", int(input.useFiltering));
    pRender->SetVariable("g_ptStupid", int(input.ptStupidMode));
    pRender->SetVariable("g_enableSROctree", int(input.enableSROctreeForPhotonMapping));
    pRender->SetVariable("rtMeasureRaysType", input.rtMeasureRaysType);
    pRender->SetVariable("rtReorderType", input.rtReorderType);
    pRender->SetVariable("rtReorderPattern", input.rtReorderPattern);

    IGraphicsEngine::RenderSettings settings;

    settings.SetTraceDepth(input.trace_depth);
    settings.SetDiffuseTraceDepth(input.diffuse_trace_depth);
    settings.SetShadow(input.shadows);
    settings.SetAA(input.AA);
    settings.SetIndirrectIllumination(input.indirrectIllum);
    settings.SetEnableRaysCounter(input.drawRayStatInfo);
 
    settings.SetEnableFG(input.enablePhotonsGartheringDiffuse);
    settings.SetEnableCG(input.enablePhotonsGartheringCaustic);
    settings.SetGartherBounce(input.skipGartherBounce);
    settings.SetStoreBounce(input.skipFirstPhotonBounce);
    settings.SetGartherRadius(input.gartherRadiusDiffuse);
    settings.SetGartherRadiusCaustic(input.gartherRadiusCaustic);
    settings.SetGamma(input.hdrGamma);
    settings.enableRecursiveTracing = input.recursiveTracer;
    settings.causticPower = input.causticPower;
    settings.ptCaustics   = input.ptCaustics && !input.enablePhotonsGartheringCaustic;

    if(input.irradianceCacheCalculated)
      settings.SetIndirrectIllumination(false); // disable brute force tracing in that case

    pRender->DebugCall("SetDebugOputputValue", ToString(int(input.enableDebugOutput)));

    // voxels
    //
    if(input.voxelizeNow == true)
    {
      pRender->DebugCall("voxelizeDebug","");
      input.voxelizeNow = false;
    }

    // simple test for octree paper
    // 
    if(input.transformICToPhMap == true)
    {
      pRender->DebugCall("icToPhMap","");
      input.transformICToPhMap = false;
    }

    // RC
    //
    if(input.computeRadianceCache && !input.radianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->ComputeRadianceCache(input.rcType);
        input.radianceCacheCalculated = true;
      }
    }
    else if(!input.computeRadianceCache && input.radianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->FreeRadianceCache();
        input.radianceCacheCalculated = false;
      }
    }

    // IC
    //
    if(!input.computeIrradianceCache && input.irradianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
        pathTracer->FreeIrradianceCache();

      input.irradianceCacheCalculated = false;
    }
    else if(input.computeIrradianceCache && !input.relightEnabled && !input.irradianceCacheCalculated)
    {
       GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
       if(pathTracer!=0)
       {
         GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;
         pathTracerParams.drawBlocks       = false;
         pathTracerParams.drawRaysStatInfo = false;
         pathTracer->SetRenderingParams(pathTracerParams);

         RAYTR::ICPresets icPresets;

         //std::cerr << "input.icWSErrorTreshold = " << input.icWSErrorTreshold << std::endl;
         icPresets.icWSErrorTreshold       = input.icWSErrorTreshold;
         icPresets.drawICRecords           = input.drawIrradianceCachePixelPoints;
         icPresets.icError                 = input.icError;
         icPresets.icFixedRays             = input.icFixedRays;
         icPresets.icMaxPasses             = input.icMaxPasses;
         icPresets.icProgressiveEvaluation = input.icProgressiveEvaluation;
         
         pathTracer->SetICPresets(icPresets);
         pathTracer->ComputeIrradianceCache();
       }

       input.irradianceCacheCalculated = true;
    }

    // Photon maps Debug
    //
    if((input.tracePhotonsDebug || input.tracePhotonsCausticsDebug) && !input.photonTracingFinishedDebug)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=NULL)
      {
        GPU_Path_Tracer::PhotonMapPresets presets;
        
        presets.maxDiffusePhotons     = input.maxDiffusePhotons;
        presets.maxCausticPhotons     = input.maxCausticPhotons;
        presets.progressivePhotonMap  = input.progressivePhotonMap;
        presets.progressiveCausticMap = input.progressiveCausticMap;
        presets.diffuseRetracePass    = input.pmDiffuseRetrace;
        presets.causticRetracePass    = input.pmCausticRetrace;
        presets.disableVisibilityTracing = input.disablePhotonVisibilityTracing;

        pathTracer->SetPhotonMapPresets(presets);
      }

      if(input.tracePhotonsDebug)
        pRender->DebugCall("TracePhotonsTest","");
      else
        pRender->DebugCall("TraceCausticPhotonsTest","");

      input.photonTracingFinishedDebug = false;
      input.tracePhotonsDebug = false;
      input.tracePhotonsCausticsDebug = false;
    }
    
    // PT
    //
    if(input.pathTracingEnabled)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);

      if(firstPass)
      {
        timer.start();
        firstPass = false;

        // photon maps initialisation 
        //
        if(pathTracer!=NULL && (input.progressivePhotonMap || input.progressiveCausticMap))
        {
          GPU_Path_Tracer::PhotonMapPresets presets;

          presets.maxDiffusePhotons        = input.maxDiffusePhotons;
          presets.maxCausticPhotons        = input.maxCausticPhotons;
          presets.progressivePhotonMap     = input.progressivePhotonMap;
          presets.progressiveCausticMap    = input.progressiveCausticMap;
          presets.diffuseRetracePass       = input.pmDiffuseRetrace;
          presets.causticRetracePass       = input.pmCausticRetrace;
          presets.disableVisibilityTracing = input.disablePhotonVisibilityTracing;

          pathTracer->SetRenderingParams(input.pt_params);
          pathTracer->SetPhotonMapPresets(presets);
          pathTracer->PreparePhotonMaps(settings);
        }
      }

      
      if (pathTracer!=NULL)
      {
        GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;
        
        if(input.inputXML == NULL)
        {
          pathTracerParams.drawBlocks       = input.drawBlocks;
          pathTracerParams.drawRaysStatInfo = input.drawRayStatInfo;
        }

        pathTracer->SetRenderingParams(pathTracerParams);


        pathTracer->BeginPathTracingPass(settings);
        pathTracingFinished = pathTracer->EndPathTracingPass();

        if(!stopCountTime)
        {
          float timeElaspedPerFrame = timer.getElapsed();
          path_tracing_time  += timeElaspedPerFrame;
          lastImageSavedTime += timeElaspedPerFrame;
        }


        static std::string oldImageName = "";

        if(pathTracingFinished && !stopCountTime || 
           (input.saveImageNow || input.toneMapNow) || // && oldImageName != input.savedImageName
           (input.savePTImagesSequence && lastImageSavedTime > 1000))
        {
          bool saveImages = true; //input.saveImageNow;

          if(!input.saveImageNow && !pathTracingFinished)
            stopCountTime = true;

          std::cerr << endl;
          pathTracer->PrintStatInfo(std::cerr);
          
          
          if(!imageSaved || oldImageName != input.savedImageName)
          {
            bool saveOnlyToneMapped = imageSaved && (oldImageName != input.savedImageName);

            std::cerr << "saving image" << std::endl;

            uint* imageData = new uint [WinWidth*WinHeight];
            pRender->GetLDRImage(imageData);

            if(saveImages)
            {
              std::stringstream fileName; fileName.precision(6);
              fileName << input.savedImageName << "_" << path_tracing_time << ".png";
              SaveImageToFile(fileName.str(), WinWidth, WinHeight, imageData);
              std::cerr << "image saved" << std::endl;
            }

            delete [] imageData;

            float4* hdrImageData = new float4[WinWidth*WinHeight];
            pRender->GetHDRImage(hdrImageData);

            if(!saveOnlyToneMapped && saveImages)
            {
              std::stringstream fileName2;  fileName2.precision(6);
              fileName2 << input.savedImageName << "_" << path_tracing_time << "_hdr.tiff";
              SaveHDRImageToFile(fileName2.str(), WinWidth, WinHeight, hdrImageData);
              std::cerr << "hdr image saved" << std::endl;
            }
          
            PP_FILTERS::ToneMappingFilter filter;
            PP_FILTERS::ToneMappingFilter::Presets hdrPresets;

            hdrPresets.strength   = input.hdrStrength;
            hdrPresets.phi        = input.hdrPhi;
            hdrPresets.whitePoint = input.hdrWitePoint;
            filter.SetPresets(hdrPresets);
            
            src.CreateStandard(WinWidth, WinHeight);
            float* srcPtr = src.GetPointer();
            float power   = 1.0/input.hdrGamma;
            for(int i=0;i<WinWidth*WinHeight;i++)
            {
              srcPtr[3*i+0] = powf(hdrImageData[i].x, power);
              srcPtr[3*i+1] = powf(hdrImageData[i].y, power);
              srcPtr[3*i+2] = powf(hdrImageData[i].z, power);
            }
            delete [] hdrImageData;

            dst.CreateCopy(&src);
            filter.Apply(&dst, &src);

            if(saveImages)
            {
              std::stringstream fileName3;  fileName3.precision(6);
              fileName3 << input.savedImageName << "_" << path_tracing_time << "_tm.png";
              dst.Save(fileName3.str());
              std::cerr << "tone mapped image saved" << std::endl;
            }

            if(!input.saveImageNow)
            {
              input.saveImageNow = false;
              imageSaved = true;
              stopCountTime = true;
            }
            else
              input.saveImageNow = false;

            if(input.savePTImagesSequence)
            {
              imageSaved    = false;
              stopCountTime = false;
              lastImageSavedTime = 0;
            }

            input.toneMapNow = false;

            oldImageName = input.savedImageName;
          }
          
        }
      }
    }
    else if (input.relightEnabled)
    {
        pReLightApp->DoRendering("out_relight_data");
        input.relightEnabled = false;
        exit(0);
    }
    else
    {
      pathTracingFinished = false;
      firstPass = true;
      FPS = 60;
      path_tracing_time = 0.0f;
      stopCountTime = false;

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if (pathTracer!=0)
        pathTracer->ResetPathTracing();
      imageSaved = false;

      pRender->BeginDrawScene(settings); 

      OpenGL_Render* pCGE = dynamic_cast<OpenGL_Render*>(pRender);
      if(pCGE!=0)
      {
        pCGE->SetDebugDrawIndex(input.m_debugIndex);
        
        //DrawDebugBoxes("boxes0.txt");
        //DrawDebugBoxesLayered("boxes", 6);
        //DrawDebugSpheres("rc_spheres.txt");
        //DrawDebugPoints("points2.txt");
        //DrawDebugSphereBox();
        //DrawDebugTreeData3();
        //DrawDebugSpheres2("spheres", 20);
        //DebugDrawRays("debugRaysPos.txt", "debugRaysDir.txt", "debugRaysColor.txt");
      }

	    pRender->EndDrawScene();
    }

    if(input.saveImageWithReadPixels)
    {
      unsigned int* data = new unsigned int[WinWidth*WinHeight];
      glReadPixels(0,0,WinWidth,WinHeight,GL_RGBA, GL_UNSIGNED_BYTE, data);

      SaveImageToFile("ic_records.png", WinWidth,WinHeight, data);

      delete [] data;
      input.saveImageWithReadPixels = false;
    }

    if(input.showToneMappedImage && input.pathTracingEnabled && dst.GetPointer() != NULL)
      glDrawPixels(WinWidth, WinHeight, GL_RGB, GL_FLOAT, dst.GetPointer());

		glutSwapBuffers();
		input.reset();
	}
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
	
	// -----------------------  �������� �������� FPS. -----------------------
  FramesCount++;
	if(FramesCount > 1)
	{
    FPS = float(FramesCount)/(timer.getElapsed());
		FramesCount=0;
    timer.start();

    char Title[64];

    if(!input.pathTracingEnabled)
      sprintf(Title, "FPS=%.1f", FPS);
    else if (!pathTracingFinished)
      sprintf(Title, "path tracing: %.2f sec", path_tracing_time);
    else
      sprintf(Title, "path tracing: %.2f sec, finished!", path_tracing_time);

    glutSetWindowTitle(Title);

	}
 
	//\\ -----------------------  �������� �������� FPS. -----------------------
}

void Reshape(int Width, int Height) 
{
  int widthClamped  = Width; //Width + (16 - Width%16);
  int heightClamped = Height; //Height + (16 - Height%16);

  if(cam == NULL || pRender == NULL)
    return;

  cam->SetPerspectiveProjection(cam->GetFOV(), float(widthClamped)/float(heightClamped), cam->GetNearClipPlane(), cam->GetFarClipPlane());
  pRender->SetWindowResolution(widthClamped, heightClamped);

  WinWidth  = widthClamped;
  WinHeight = heightClamped;
  input.ext_width  = widthClamped;
  input.ext_height = heightClamped;
}


void Mouse(int button, int state, int x, int y) { input.Mouse(button,state,x,y); }
void MouseMotion(int x, int y) { input.MouseMotion(x,y); }
void Keyboard(unsigned char key,int x,int y){ input.Keyboard(key,x,y); glutPostRedisplay();}   //�����
void KeyboardSpecial(int key, int x, int y) { input.KeyboardSpecial(key,x,y); glutPostRedisplay();  }   // ���� �����
void Mouse(int button, int state, int x, int y); //��������� ������� ����
void Idle() { glutPostRedisplay(); } 

int main(int argc, char** argv)
{
  HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(h, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
  
  if(argc > 1)
  {
    input.inColladaFile = argv[1];
    
    if(argc>2)
      input.inColladaProfile = argv[2];

    if(argc>3)
      input.ReadXMLFromFile(argv[3]);

    for(int i=0;i<argc;i++)
      std::cout << "agrv[" << i << "] = " << argv[i] << std::endl;
  }
  
  input.ReadXMLFromSharedMemory();

  WinWidth  = input.ext_width;
  WinHeight = input.ext_height;

  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
  glutInitContextVersion(3,1); // if 3.1 => compatability mode
	glutInitWindowSize(WinWidth, WinHeight);
	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)-WinWidth)/2, (glutGet(GLUT_SCREEN_HEIGHT)-WinHeight)/2);
	glutCreateWindow("NO FATE");
	
	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(KeyboardSpecial);
	glutReshapeFunc(Reshape);
	glutMouseFunc(Mouse);
	glutMotionFunc(MouseMotion);
	glutIdleFunc(Idle);

	Init();
  atexit(ShutDown);
			
	glutMainLoop();
}
