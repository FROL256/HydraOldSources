#include "maxPluginServer.h"
#include "ImportVrscene.h"

#include <boost/archive/binary_iarchive.hpp>

#include <il/il.h>
#include <il/ilu.h>

#pragma comment(lib, "devil.lib")
#pragma comment(lib, "ilu.lib")

#define HEADER_COLLADA 100
#define HEADER_TEXTURE 101
#define SCENE_FILE 200
#define CONFIG_FILE 201
#define READ_COLLADA 202
#define READ_TEXTURE 203
#define READ_NEXT 204

#include "../ColladaImport/ColladaImport.h"

extern Input input;

void MakeHydraMaterialMapFromXMLNode(TiXmlElement* materials_lib, IGraphicsEngine* pRender, HydraMaterialMap* pResult, IHydraUserControl* pControl)
{
  if(materials_lib == NULL)
    return;

  ITextureImporter* pTexImporter  = new ColladaTextureImporter;
  
  //std::cerr << " input.inColladaFile =  " << input.inColladaFile.c_str() << std::endl;

  pTexImporter->SetCurrentPathToMainFile(input.inColladaFile);
  pTexImporter->SetTexPathStorage(&(LastImportedScene()->texpaths)); // all texture paths will be saved here
  
  ColladaParser::ObjectDataList allData;

  for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
  {
    TiXmlElement* matElem = nextMat->ToElement();
    std::string name =  "";

    if(matElem->Attribute("id") != NULL)
      name = matElem->Attribute("id");
    else if(matElem->Attribute("name") != NULL)
      name = matElem->Attribute("name");

    ColladaParser::ObjectData params;

    TiXmlElement* pMaterialModel = matElem->FirstChildElement();
    if(STR_CNV::ToLowerCase(pMaterialModel->ValueStr()) == "hydra")
    {
      ColladaParser::ParseHydraMaterial(params, pMaterialModel);
      params["name"] = name; // IMPORTANT!!!
      allData[name] = params;
    }
    else
      fprintf(stderr, "Warning: Hydra profile has unknown material model %s \n", pMaterialModel->ValueStr().c_str());

  }

  // now make global fixes
  //
  IHydraMaterialImportProfile* pProfileFix = new ColladaMaterialImportProfile(materials_lib);

  ColladaParser::ObjectDataList::iterator p;

  for(p = allData.begin(); p!= allData.end(); ++p)
    pProfileFix->Transform(p->second);

  delete pProfileFix;

  // and now transform all this shit to HydraMaterial
  //
  HydraMaterialMap& a_map = (*pResult);

  for(p = allData.begin(); p!= allData.end(); ++p)
    a_map[p->first] = HydraMaterialFromStringMap(p, pRender, pTexImporter, pControl->GetImportParamsHash());


  pTexImporter->ResetCurrentPath();
  delete pTexImporter;
}

//
//
void MakeHydraLightsMapFromXMLNode(TiXmlElement* lib, IGraphicsEngine* pRender, HydraLightsMap* pResult)
{
  if(lib == NULL)
    return;

  ITextureImporter* pTexImporter  = new ColladaTextureImporter;
  pTexImporter->SetCurrentPathToMainFile(input.inColladaFile);

  ColladaParser::ObjectDataList lightsData;

  for(TiXmlNode* nextLight = lib->FirstChild("light"); nextLight!=0; nextLight = lib->IterateChildren("light", nextLight))
  {
    TiXmlElement* lightElem = nextLight->ToElement();
    std::string name =  "";

    if(lightElem->Attribute("id") != NULL)
      name = lightElem->Attribute("id");
    else if(lightElem->Attribute("name") != NULL)
      name = lightElem->Attribute("name");

    ColladaParser::ObjectData params;
    ColladaParser::ParseHydraLight(nextLight, &params);    

    lightsData[name] = params;
  }
   
  // and now transform all this shit to HydraMaterial
  //
  HydraLightsMap& a_map = (*pResult);

  ColladaParser::ObjectDataList::iterator p;
  for(p = lightsData.begin(); p!= lightsData.end(); ++p)
    a_map[p->first] = HydraLightFromStringMap(pRender, p, Matrix4x4f(), pTexImporter);

  pTexImporter->ResetCurrentPath();
  delete pTexImporter;

}







float3 ComputeSmGroupNormal(const std::vector<int>& faceIndeces, int faceNum, const std::vector<int> &face_smoothgroups, float *face_normals)
{
  float3 v(0,0,0);
  int counter = 0;

  float3 faceNorm;
  faceNorm.x = face_normals[faceNum*3 + 0];
  faceNorm.y = face_normals[faceNum*3 + 1];
  faceNorm.z = face_normals[faceNum*3 + 2];

  v = faceNorm;

  for(int i = 0; i < faceIndeces.size(); i++)
  {
    float3 norm;
    norm.x = face_normals[faceIndeces[i]*3 + 0];
    norm.y = face_normals[faceIndeces[i]*3 + 1];
    norm.z = face_normals[faceIndeces[i]*3 + 2];

    if(face_smoothgroups[faceNum] == face_smoothgroups[faceIndeces[i]] && dot(v,norm) > 0.173648f ) // if angle is less than 80 degrees 
    {
      v.x += norm.x;
      v.y += norm.y;
      v.z += norm.z;
      counter++;
    }

  }
  v = v/counter;
  return normalize(v);
}

void ComputeVertexFaceIndices(const GeometryObj &mesh, std::map<int, std::vector < int > > &vertexFaceIndeces)
{

  if(mesh.n_faces*3 > mesh.pos_indeces.size())
  {
    std::cerr << "ComputeVertexFaceIndices, mesh.n_faces is out of range!" << std::endl;
    std::cerr << "mesh.n_faces*3          = " << mesh.n_faces*3 << std::endl;
    std::cerr << "mesh.pos_indeces.size() = " << mesh.pos_indeces.size() << std::endl;
  }

  for (int i = 0; i < mesh.n_faces; i++) 
  {
    int index1 = mesh.pos_indeces[i*3+0];
    int index2 = mesh.pos_indeces[i*3+1];
    int index3 = mesh.pos_indeces[i*3+2];

    vertexFaceIndeces[index1].push_back(i);
    vertexFaceIndeces[index2].push_back(i);
    vertexFaceIndeces[index3].push_back(i);
  }
}


void ComputeBBox(const std::vector<GeometryObj> &geometry, const std::vector<SphereObj> &spheres, Matrix4x4f* res)
{
  Matrix4x4f &m = *res;

  float4 p_min = float4(geometry[0].bbox[0],geometry[0].bbox[1],geometry[0].bbox[2],1);
  float4 p_max = float4(geometry[0].bbox[3],geometry[0].bbox[4],geometry[0].bbox[5],1);

  struct s_bbox
  {
    float bbox[6];
  };

  vector<s_bbox> bboxes;

  for(vector<GeometryObj>::const_iterator geom = geometry.begin(); geom != geometry.end(); ++geom)
  {
    if(geom->positions.size()!=0)
    {
      s_bbox box;
      box.bbox[0] = geom->bbox[0];
      box.bbox[1] = geom->bbox[1];
      box.bbox[2] = geom->bbox[2];
      box.bbox[3] = geom->bbox[3];
      box.bbox[4] = geom->bbox[4];
      box.bbox[5] = geom->bbox[5];

      bboxes.push_back(box);
    }
  }
  for(vector<SphereObj>::const_iterator sph = spheres.begin(); sph != spheres.end(); ++sph)
  {
    s_bbox box;
    box.bbox[0] = sph->bbox[0];
    box.bbox[1] = sph->bbox[1];
    box.bbox[2] = sph->bbox[2];
    box.bbox[3] = sph->bbox[3];
    box.bbox[4] = sph->bbox[4];
    box.bbox[5] = sph->bbox[5];

    bboxes.push_back(box);
  }

  for(vector<s_bbox>::const_iterator bb = bboxes.begin(); bb != bboxes.end(); ++bb)
	{
    if ( bb->bbox[0] < p_min.x ) p_min.x = bb->bbox[0];
    if ( bb->bbox[1] < p_min.y ) p_min.y = bb->bbox[1];
    if ( bb->bbox[2] < p_min.z ) p_min.z = bb->bbox[2];

    if ( bb->bbox[3] > p_max.x ) p_max.x = bb->bbox[3];
    if ( bb->bbox[4] > p_max.y ) p_max.y = bb->bbox[4];
    if ( bb->bbox[5] > p_max.z ) p_max.z = bb->bbox[5];
  }

  float sizeX = p_max.x - p_min.x;
  float sizeY = p_max.y - p_min.y;
  float sizeZ = p_max.z - p_min.z;

  AABB4f box(p_min, p_max);
  float4 center = box.center(); center.w = 1.0f;

  Matrix4x4f mTranslate, mRotate, mScale;

  mTranslate.SetTranslate(-1.0f*center);

  float maxSize = sizeX;

  if(sizeY > maxSize) maxSize = sizeY;
  if(sizeZ > maxSize) maxSize = sizeZ;


  mScale.SetScale(float3((1.0f/maxSize)*3, (1.0f/maxSize)*3, (1.0f/maxSize)*3));
  //mScale.SetScale(float3(1,1,1));
   

  mRotate = Matrix4x4f( 1,0,0,0,
                        0,0,1,0,
                        0,-1,0,0,
                        0,0,0,1);

  

  m = mRotate*mScale*mTranslate;
}



int LoadDump(std::string name)
{
	std::ifstream is;
	is.open(name.c_str());
	if (!is)
		return 1;
	boost::archive::binary_iarchive ar( is );

	std::vector<GeometryObj> geometry;
	std::vector<MaterialObj> materials;
	std::vector<LightObj> lights;
	/*SceneTree* tree;*/

	ar & geometry;
	ar & materials;
	ar & lights;
	//ar & tree;

	return 0;
}


void LoadGeometry(IGraphicsEngine* pRender, const std::vector<GeometryObj> &geometry, Matrix4x4f& m_externTransform,
                  const std::vector<SphereObj> &spheres, std::map<int, int> &materialIDs, int mat_size, IHydraUserControl* pUserControl)
{ 
  Matrix4x4f mScale;
  mScale.SetScale(float3(10,10,10));

  ComputeBBox(geometry, spheres, &m_externTransform);

  m_externTransform = mScale*m_externTransform;

  LoadSpheres(pRender, spheres, m_externTransform);

  int geom_obj = 0;

  //std::ofstream outPosFile("out_objects.txt");

	for(vector<GeometryObj>::const_iterator geom = geometry.begin(); geom != geometry.end(); ++geom)
	{
    if(geom->positions.size()!=0)
    {
      std::map <int, std::vector <int> > vertexFaceIndeces;
      float *face_normals;
      face_normals = new float[geom->n_faces*3];

      ComputeVertexFaceIndices(geometry[geom_obj], vertexFaceIndeces);

 		  int N_vertices = geom->n_faces*3;
		  int N_indices = geom->n_faces*3;

		  Vertex4f* v = new Vertex4f[N_vertices];
		  uint* indices = new uint[N_indices];

		  Matrix4x4f mTransform;

		  mTransform = Matrix4x4f(geom->m[0],  geom->m[1], geom->m[2],  geom->m[3],
					                    geom->m[4],  geom->m[5], geom->m[6],  geom->m[7],
					                    geom->m[8],  geom->m[9], geom->m[10], geom->m[11],
					                    geom->m[12], geom->m[13],geom->m[14], geom->m[15]);

      mTransform.Transpose();

      // this is needed to find object positions
      //
      if(0)
      {
        AABB3f box(float3(geom->bbox), float3(geom->bbox+3));
        float3 objPos = box.center();
        float3 objPosTransformed = m_externTransform*objPos;
        //outPosFile << ToNarrowString(geom->mesh_id).c_str() << " : " << objPosTransformed << std::endl;
      }


		  for(int i=0; i<geom->n_faces; i++)
		  {
			  int index1 = geom->pos_indeces[i*3+0];
			  int index2 = geom->pos_indeces[i*3+1];
			  int index3 = geom->pos_indeces[i*3+2];

        float4 v1Pos = float4(geom->positions[index1*3], geom->positions[index1*3+1], geom->positions[index1*3+2], 1);
        float4 v2Pos = float4(geom->positions[index2*3], geom->positions[index2*3+1], geom->positions[index2*3+2], 1);
        float4 v3Pos = float4(geom->positions[index3*3], geom->positions[index3*3+1], geom->positions[index3*3+2], 1);

        float4 v1PosTransformed = m_externTransform*v1Pos;
        float4 v2PosTransformed = m_externTransform*v2Pos; 
        float4 v3PosTransformed = m_externTransform*v3Pos; 


			  v[i*3+0].pos = v1PosTransformed;
			  v[i*3+1].pos = v2PosTransformed;
			  v[i*3+2].pos = v3PosTransformed;
       

			  indices[i*3+0] = i*3+0;
			  indices[i*3+1] = i*3+1;
			  indices[i*3+2] = i*3+2;

        int matID = geom->material_id[i];

        v[i*3+0].material_id = materialIDs[matID];
        v[i*3+1].material_id = materialIDs[matID];
        v[i*3+2].material_id = materialIDs[matID];

        
        MaterialTextureImportMaxParams texMults; // piece of max import shit
        {
          HydraScene* pScene = pUserControl->GetScene(); // it is important to remember materials in global scene inf
          const std::string& mname = pScene->matnames[matID];

          HashMapImportParams* pMaxImportParams = pUserControl->GetImportParamsHash();
          if(pMaxImportParams != NULL && !pMaxImportParams->empty())
          {
            HashMapImportParams::iterator p = pMaxImportParams->find(mname);
            if(p != pMaxImportParams->end())
              texMults = p->second;
          }
        }

        const HydraMaterial& mat = pRender->GetHydraMaterial(v[i*3+0].material_id);

        if(geom->tex_coords.size()!=0)
        {
          int tindex1 = geom->tex_coords_indices[i*3+0];
          int tindex2 = geom->tex_coords_indices[i*3+1];
          int tindex3 = geom->tex_coords_indices[i*3+2];

          if(mat.flags & HydraMaterial::IMPORT_FLIPXY_TEXCOORD)
          {
            v[i*3+0].t = float2(geom->tex_coords[tindex1*2+1], geom->tex_coords[tindex1*2+0]);
            v[i*3+1].t = float2(geom->tex_coords[tindex2*2+1], geom->tex_coords[tindex2*2+0]);
            v[i*3+2].t = float2(geom->tex_coords[tindex3*2+1], geom->tex_coords[tindex3*2+0]);
          }
          else
          {
            v[i*3+0].t = float2(geom->tex_coords[tindex1*2+0], geom->tex_coords[tindex1*2+1]);
            v[i*3+1].t = float2(geom->tex_coords[tindex2*2+0], geom->tex_coords[tindex2*2+1]);
            v[i*3+2].t = float2(geom->tex_coords[tindex3*2+0], geom->tex_coords[tindex3*2+1]);
          }

          v[i*3+0].t.x = texMults.uOffset + v[i*3+0].t.x*texMults.uTiling;
          v[i*3+0].t.y = texMults.vOffset + v[i*3+0].t.y*texMults.vTiling;

          v[i*3+1].t.x = texMults.uOffset + v[i*3+1].t.x*texMults.uTiling;
          v[i*3+1].t.y = texMults.vOffset + v[i*3+1].t.y*texMults.vTiling;

          v[i*3+2].t.x = texMults.uOffset + v[i*3+2].t.x*texMults.uTiling;
          v[i*3+2].t.y = texMults.vOffset + v[i*3+2].t.y*texMults.vTiling;
          
        }

     
        float4 norm = normalize(cross(v2PosTransformed-v1PosTransformed, v3PosTransformed-v1PosTransformed));
        face_normals[i*3 + 0] = norm.x;
        face_normals[i*3 + 1] = norm.y;
        face_normals[i*3 + 2] = norm.z;
		  }


      // recompute normals based on smoothing groups
      //
      for(int i=0; i<geom->n_faces; i++)
      {
        int index1 = geom->pos_indeces[i*3+0];
        int index2 = geom->pos_indeces[i*3+1];
        int index3 = geom->pos_indeces[i*3+2];

        int matID = geom->material_id[i];
        const HydraMaterial& mat = pRender->GetHydraMaterial(matID);
        if(mat.flags & HydraMaterial::IMPORT_FLAT_SHADING)
        {
          float4 normFlat(face_normals[i*3+0], face_normals[i*3+1], face_normals[i*3+2], 0);
          v[i*3+0].norm = normFlat;
          v[i*3+1].norm = normFlat;
          v[i*3+2].norm = normFlat;
        }
        else
        {
          const std::vector <int>& vn1 = vertexFaceIndeces[index1];
          float3 norm = ComputeSmGroupNormal(vn1, i, geom->face_smoothgroups, face_normals);
          float4 norm4(norm.x, norm.y, norm.z, 1);
          v[i*3+0].norm = norm4;

          const std::vector <int>& vn2 = vertexFaceIndeces[index2];
          norm = ComputeSmGroupNormal(vn2, i, geom->face_smoothgroups, face_normals);
          norm4 = float4(norm.x, norm.y, norm.z, 1);
          v[i*3+1].norm = norm4;

          const std::vector <int>& vn3 = vertexFaceIndeces[index3];
          norm = ComputeSmGroupNormal(vn3, i, geom->face_smoothgroups, face_normals);
          norm4 = float4(norm.x, norm.y, norm.z, 1);
          v[i*3+2].norm = norm4;
        }
      }


 		  pRender->AddTriangles(v, N_vertices, indices, N_indices);

      delete [] v;
      delete [] indices;
      delete [] face_normals;

      geom_obj++;
    }
	}
	
}


void LoadLights(IGraphicsEngine* pRender, const std::vector<LightObj> &a_lights, const Matrix4x4f& m_externTransform, const std::string& a_profilePath, IHydraUserControl* pUserControl)
{
	/*for (vector<LightObj>::const_iterator li = lights.begin(); li != lights.end(); ++li)
	{
		RAYTR::Light light;

		light.intensity = 1.0f;
		light.color = float3(1,1,1);
		light.pos = float3(0,0,0);	

		light.intensity = li->intensity;

		light.color = float3(li->color[0], li->color[1], li->color[2]);

		pRender->AddLight(light);
	}*/


  do // load profileMap
  {
    ColladaParser profileLoader;

    if(a_profilePath == "" || !profileLoader.LoadXML(a_profilePath))
    {
      std::cerr << "PluginServer: LoadLights, can't load material profile" << std::endl;
      break;
    }

    HydraLightsMap lightsMap;

    TiXmlElement* lights_lib = profileLoader.GetElement("library_lights");
    MakeHydraLightsMapFromXMLNode(lights_lib, pRender, &lightsMap);

    //
    //
    int lightNum = int(a_lights.size());
    //std::cerr << "a_lights.size() = " << lightNum << std::endl;

    for(int i=0; i<lightNum; i++)
    {
      std::string key = ToNarrowString( a_lights[i].lightName );
      //std::cerr << "key = " << key << std::endl;

      RAYTR::Light localLight;

      HydraLightsMap::iterator p = lightsMap.find(key);

      RAYTR::Light& light = (p == lightsMap.end()) ? localLight : p->second;

      Matrix4x4f matrixLight(a_lights[i].m); matrixLight.Transpose();
      Matrix4x4f matrixLightTarget(a_lights[i].targetMatrix); matrixLightTarget.Transpose();

      float3 newPos    = m_externTransform*(matrixLight*float3(0,0,0));
      float3 targetPos = m_externTransform*(matrixLightTarget*float3(0,0,0));

      light.pos = newPos;
      if(a_lights[i].isTargeted)
        light.m_norm = normalize(targetPos - newPos);
      else // thats wrong!
      {
        float3 dir(a_lights[i].direction);
        std::swap(dir.y, dir.z);             // this is because of different 3ds max coordinate system
        light.m_norm = normalize(dir);
      }

      if(a_lights[i].lightType == L"DIR")
      {
        float3 tmpVec  = float3(0, a_lights[i].hotsize,0);
        float3 tmpVec2 = float3(0, a_lights[i].fallsize,0);
        
        float decaySize1 = 0.725f*length(m_externTransform*tmpVec);
        float decaySize2 = 0.725f*length(m_externTransform*tmpVec2);

        light.m_size.x = decaySize1;
        light.m_size.y = decaySize2;
        light.flags |= RAYTR::Light::LIGHT_DIRECT_HAS_CIRCLE_SIZE;
      }

      if(a_lights[i].lightType == L"SKY")
      {
        ITextureImporter* pTexImporter =  pUserControl->GetTexImporter();
        if(pTexImporter!=NULL)
        {
          std::string texPath = ToNarrowString(a_lights[i].envTexturePath);

          light.texCudeIndices[0] = INVALID_TEXTURE;
          light.texCudeIndices[1] = INVALID_TEXTURE;
          light.texCudeIndices[2] = INVALID_TEXTURE;
          light.texCudeIndices[3] = INVALID_TEXTURE;
          light.texCudeIndices[4] = INVALID_TEXTURE;
          light.texCudeIndices[5] = INVALID_TEXTURE;

          light.sphTexIndex = pTexImporter->AddTextureIfExists(texPath, pRender);
        }
      }

      if(p == lightsMap.end())
      {
        light.intensity = a_lights[i].intensity;
        light.color = float3(a_lights[i].color);

        if(a_lights[i].on)
           light.SetActive(true);
        else
           light.SetActive(false);

        if(a_lights[i].lightType == L"OMNI")
          light.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
        else if(a_lights[i].lightType == L"DIR")
          light.SetLighType(RAYTR::Light::LIGHT_TYPE_DIRECTIONAL);
        else if(a_lights[i].lightType == L"SPOT")
          light.SetLighType(RAYTR::Light::LIGHT_TYPE_SPOT);
        else if(a_lights[i].lightType == L"SKY")
        {
          light.SetLighType(RAYTR::Light::LIGHT_TYPE_SKY);
          light.m_norm = float3(0,-1,0);
        }
        else if(a_lights[i].lightType == L"AREA")
        {
          light.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
        }
        else if(a_lights[i].lightType == L"SPHERE")
        {
          light.SetLighType(RAYTR::Light::LIGHT_TYPE_SPHERICAL);
        }

        light.m_spotCutoffAngleCos[0] = cos(0.5f*MGML_MATH::DEG_TO_RAD(a_lights[i].hotsize));
        light.m_spotCutoffAngleCos[1] = cos(0.5f*MGML_MATH::DEG_TO_RAD(a_lights[i].fallsize)); 

        light.kc = a_lights[i].kc;
        light.kl = a_lights[i].kl;
        light.kq = a_lights[i].kq;

        lightsMap[key] = light;
      }

    }


    for(HydraLightsMap::iterator p = lightsMap.begin(); p!= lightsMap.end(); ++p)
    {
      std::string lightName = p->first;
      int lightId = pRender->AddLight(p->second);

      //std::cerr << "lightId   = " << lightId << std::endl;
      
      //std::cerr << "pos       = " << p->second.pos << std::endl;
      //std::cerr << "dir       = " << p->second.m_norm << std::endl;
      
      //std::cerr << "color     = " << p->second.color << std::endl;
      //std::cerr << "intensity = " << p->second.intensity << std::endl;
      
      //std::cerr << "cos1      = " << p->second.m_spotCutoffAngleCos[0] << std::endl;
      //std::cerr << "cos2      = " << p->second.m_spotCutoffAngleCos[1] << std::endl;

      //std::cerr << "kc        = " << p->second.kc << std::endl;
      //std::cerr << "kl        = " << p->second.kl << std::endl;
      //std::cerr << "kq        = " << p->second.kq << std::endl;

      HydraScene* pScene = pUserControl->GetScene(); // it is important to remember lights in global scene info
      HashMapI& lights   = pScene->lights;
      lights[lightName]  = lightId; 
    }


  } while(false);


}


int LoadMaterials(IGraphicsEngine* pRender, const std::vector<MaterialObj> &materials, std::map<int, int> &materialIDs, const std::string& a_profilePath, IHydraUserControl* pUserControl)
{
	int mat_size = materials.size();
	int i =0;

  HydraMaterialMap profileMap;

  do // load profileMap
  {
    ColladaParser profileLoader;

    if(a_profilePath == "" || !profileLoader.LoadXML(a_profilePath))
    {
      std::cerr << "PluginServer: LoadMaterials, can't load material profile" << std::endl;
      break;
    }

    TiXmlElement* materials_lib = profileLoader.GetElement("library_materials");
    MakeHydraMaterialMapFromXMLNode(materials_lib, pRender, &profileMap, pUserControl);
  
  } while(false);
  

  pUserControl->GetScene()->matnames.resize(mat_size); 

	for (vector<MaterialObj>::const_iterator mat = materials.begin(); mat != materials.end(); ++mat)
	{
    HydraMaterial material;

		if(mat->shading==L"PHONG")
			material.specular.brdf_id = HydraMaterial::BRDF_PHONG;
		else if (mat->shading==L"BLINN")
			material.specular.brdf_id = HydraMaterial::BRDF_BLINN;
		else
			material.specular.brdf_id = HydraMaterial::BRDF_PHONG;

		material.ambient.color    = float3(0.0f,0.0f, 0.0f); //0.05f*float3(mat->ambient_color);
		material.diffuse.color    = float3(mat->diffuse_color);
    material.diffuse.radiance = 1.0;
    material.specular.color   = 0.25f*float3(mat->specular_color);
    material.specular.power   = 100*mat->shininess;

    material.reflection.color = 0.5*material.specular.color;
    material.reflection.power = material.reflection.power;

    //material.refraction.color = mat->transparency*material.reflection.color;
    //material.refraction.fogColor  = material.refraction.color;
    //material.refraction.exitColor = material.refraction.color;

    //rt_materials[i].specular.fresnelIOR = mat->IOR;
    //material.specular.glossiness = mat->shininess;
    //material.specular.power = mat->shine_strength;
  
    std::string matName = ToNarrowString(mat->name);
    HydraMaterialMap::iterator f = profileMap.find(matName);
    if(f != profileMap.end())
      material = f->second;

    int materialId = pRender->AddMaterial(material);
    
    HydraScene* pScene   = pUserControl->GetScene(); // it is important to remember materials in global scene info
    HashMapI& materials  = pScene->materials;
    materials[matName]   = materialId; 
    materialIDs[mat->id] = materialId;

    pScene->matnames[materialId] = matName;
	}

  if(mat_size == 0 || materialIDs.size() == 0)
    RUN_TIME_ERROR("EMPTY MATERIAL DUMP!");



  return mat_size;

}

void LoadSpheres(IGraphicsEngine* pRender, const std::vector<SphereObj> &spheres, const Matrix4x4f &m)
{
  for (vector<SphereObj>::const_iterator sph = spheres.begin(); sph != spheres.end(); ++sph)
  {
    Sphere4f sphere;
    sphere.pos = float4(sph->center[0], sph->center[1], sph->center[2], sph->center[3]);
    sphere.setRadius(sph->radius);
    sphere.material_id = sph->material_id;

    sphere.pos = m*sphere.pos;

    sphere.setRadius(sphere.r*m.GetCol(0)[0]);

    pRender->AddSpheres(&sphere,1);
    
  }
}


int ServerFileMain(IGraphicsEngine* pRender, IHydraUserControl* pUserControl, Input* input)
{
  //boost::array<char, 1024> buf;
  //size_t file_size = 0;
  const unsigned int buff_size = 16384;
  int res = CONFIG_FILE;

  try
  {
    unsigned short tcp_port = 1234;

    std::cout <<"listen on port " << tcp_port << std::endl;

    boost::asio::io_service io_service;
    boost::asio::ip::tcp::acceptor acceptor(io_service, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), tcp_port));
    while(1)
    {
      if(res == SCENE_FILE)
        break;
      boost::system::error_code error;
      boost::asio::ip::tcp::socket socket(io_service);

      acceptor.accept(socket);      
      std::cout << "get client connection." << std::endl;

      std::ofstream f("C:/[Hydra]/pluginFiles/serv_test.dump",std::ios_base::binary); 

      unsigned int count = 0; 

      while(1) 
      { 
        boost::array<char, buff_size> buf; 
        boost::system::error_code error;

        size_t len = socket.read_some(boost::asio::buffer(buf), error);

        count += len;
        
        if (error == boost::asio::error::eof ) 
        { 
          std::cout << "Read a total of " << count << " bytes " << std::endl;

          f.write(buf.data(),len); 

          size_t file_size = f.tellp();
          std::cout << "File size " << file_size << std::endl;
          f.close();   
          break; 
        }
        else if (error) 
        {
          throw boost::system::system_error(error); 
        }
        else 
        {
          f.write(buf.data(),len);
        }
      }

      if(res == CONFIG_FILE)
        res = ReadDump("C:/[Hydra]/pluginFiles/serv_test.dump", pRender, READ_NEXT, input, pUserControl);
      else if(res == HEADER_COLLADA)
        res = ReadDump("C:/[Hydra]/pluginFiles/serv_test.dump", pRender, READ_COLLADA, input, pUserControl);
      else if(res == HEADER_TEXTURE)
        res = ReadDump("C:/[Hydra]/pluginFiles/serv_test.dump", pRender, READ_TEXTURE, input, pUserControl);
    }
  }
  catch (std::exception& e)
  {
    std::cerr << "Error : " << e.what() << std::endl;
  }
  catch (boost::system::error_code& e)
  {
    std::cerr << "Error : " << e.message() << std::endl;
  }
  return 0;
}


int ReadDump(std::string name, IGraphicsEngine* pRender, int headerRecvd, Input* input, IHydraUserControl* pUserControl)
{
  static std::wstring next_file_name = L"";

  if(headerRecvd == READ_NEXT)
  {  
    TransferContents transfer;
    
    int mat_size = 0;

    std::ifstream ifs(name.c_str(), std::ios_base::binary);
    if (!ifs)
    {
      std::cout << "failed to open " << name << std::endl;
      return 0;
    }
    else
    {
      std::cout << "successfully opened " << name << std::endl;
    }

    boost::archive::binary_iarchive ar( ifs );

    static Included incl;

    ar & transfer;

    switch (transfer.contents)
    {
      case transfer.CONFIG:
      {
        ar & incl;

        std::cout << "settings read" << std::endl;
        ifs.close();

        return CONFIG_FILE;
      }
      case transfer.SCENE:
      {
        std::vector<GeometryObj> geometry;
        std::vector<SphereObj> spheres;
        std::vector<MaterialObj> materials;
        std::vector<LightObj> lights;
        std::map<int, int> materialIDs;

        if(incl.materials)
        {
          ar & materials;
          std::cout << "materials read" << std::endl;
          
          std::string profilePath = input->inColladaProfile; 
          mat_size = LoadMaterials(pRender, materials, materialIDs, profilePath, pUserControl);
        }

        //
        //
        Matrix4x4f m_externTransform; // global transform applied to scene
                                      // will be written by LoadGeometry

        if(incl.geometry)
        {
          for(int i = 0; i < incl.geomObjNum; i++)
          {
            GeometryObj geom;
            ar & geom;
            geometry.push_back(geom);
          }       

          std::cout << "geometry read" << std::endl;

          if(incl.spheres)
          {
            ar & spheres;

            std::cout << "spheres read" << std::endl;
          }

          LoadGeometry(pRender, geometry, m_externTransform, spheres, materialIDs, mat_size, pUserControl);
        }

        if(incl.lights)
        {
          ar & lights;
          std::cout << "lights read" << std::endl;
        }

        std::string profilePath = input->inColladaProfile; 
        LoadLights(pRender, lights, m_externTransform, profilePath, pUserControl);

        ifs.close();

        std::cout << "SCENE LOADING COMPLETE" << std::endl;

        return SCENE_FILE;
      }
      case transfer.HEADER:
      {
          Header head;
          ar & head;

          std::cout << "header read" << std::endl;
          ifs.close();

          if(head.contents == head.COLLADA_PROFILE)
          {
            next_file_name = head.file_name;
            std::cout << std::endl <<"********************************" << std::endl << std::endl;
            return HEADER_COLLADA;
          }
          if(head.contents == head.TEXTURE_FILE)
          {
            next_file_name = head.file_name;
            std::cout << std::endl <<"********************************" << std::endl << std::endl;
            return HEADER_TEXTURE;
          }


          size_t found = head.file_name.find(L".hhh");
          if (found != std::string::npos)
            head.file_name.erase(found, 4);

          next_file_name = head.file_name;
      }
    }//switch
  }//if
  else if(headerRecvd == READ_COLLADA)
  {
    std::cout << "Collada profile received" << std::endl;
    std::cout << std::endl <<"********************************" << std::endl << std::endl;
    std::string temp = ToNarrowString(next_file_name);

    std::cerr << "temp = " << temp.c_str() << std::endl;
    std::cerr << "name = " << name.c_str() << std::endl;

    std::rename(name.c_str(), temp.c_str());
    return CONFIG_FILE;
  }
  else if(headerRecvd == READ_TEXTURE)
  {
    std::cout << "Texture file received" << std::endl;
   
    size_t found = next_file_name.find(L".hhh");
    if (found != std::string::npos)
      next_file_name.erase(found, 4);

    std::string temp = ToNarrowString(next_file_name);

    std::cout << temp << std::endl;  
    std::cout << std::endl <<"********************************" << std::endl << std::endl;

    std::rename(name.c_str(), temp.c_str());
    return CONFIG_FILE;
  }

  return 0;
  //TODO: Debugging vrscene import. Remove this later.
  /*vrscene::vrsceneImport import("C:/[Derp]/pluginFiles/box_vraymtl.vrscene");
  import.parseFile();

  std::string res;
  if (import.getValue("TexFresnel", "brdf0_fresnel", "fresnel_ior", res))
    std::cout << "TexFresnel brdf0_fresnel : fresnel_ior = " << res;
  else
    std::cout << "Can't find requested parameter";
  std::cout << std::endl;*/

}


int LoadSceneDump(std::string sceneDumpName, std::string configName, IGraphicsEngine* pRender, IHydraUserControl* pUserControl, Input* input)
{
  int mat_size = 0;

  std::ifstream ifs_conf(configName.c_str(), std::ios_base::binary);
  if (!ifs_conf)
  {
    std::cout << "failed to open " << configName << std::endl;
    return 0;
  }
  else
  {
    std::cout << "successfully opened " << configName << std::endl;
  }

  boost::archive::binary_iarchive ar_conf( ifs_conf );

  TransferContents transfer;

  Included incl;

  ar_conf & transfer;

  ar_conf & incl;

  ifs_conf.close();

  std::ifstream ifs(sceneDumpName.c_str(), std::ios_base::binary);
  if (!ifs)
  {
    std::cout << "failed to open " << sceneDumpName << std::endl;
    return 0;
  }
  else
  {
    std::cout << "successfully opened " << sceneDumpName << std::endl;
  }

  boost::archive::binary_iarchive ar( ifs );

  ar & transfer;

  std::vector<GeometryObj> geometry;
  std::vector<SphereObj>   spheres;
  std::vector<MaterialObj> materials;
  std::vector<LightObj>    lights;
  std::map<int, int>       materialIDs;
  
  if(incl.materials)
  {
    ar & materials;

    std::cout << "materials read" << std::endl;
    std::string profilePath = input->inColladaProfile;
    mat_size = LoadMaterials(pRender, materials, materialIDs, profilePath, pUserControl);
  }

  Matrix4x4f m_externTransform; // will be written by LoadGeometry

  if(incl.geometry)
  {
    for(int i = 0; i < incl.geomObjNum; i++)
    {
      GeometryObj geom;
      ar & geom;
      geometry.push_back(geom);
    }       

    std::cout << "geometry read" << std::endl;

    if(incl.spheres)
    {
      ar & spheres;

      std::cout << "spheres read" << std::endl;
    }

    LoadGeometry(pRender, geometry, m_externTransform, spheres, materialIDs, mat_size, pUserControl);
  }

  if(incl.lights)
  {
    ar & lights;
    std::cout << "lights read" << std::endl;
  }

  std::string profilePath = input->inColladaProfile; 
  LoadLights(pRender, lights, m_externTransform, profilePath, pUserControl);

  ifs.close();

  std::cout << "SCENE LOADING COMPLETE" << std::endl;

  return 1;
}

std::wstring ToWideString(const std::string& rhs)

{

  std::wstring res; res.resize(rhs.size());

  std::copy(rhs.begin(), rhs.end(), res.begin());

  return res;

}

 

std::string ToNarrowString(const std::wstring& rhs)

{

  std::string res; res.resize(rhs.size());

  std::copy(rhs.begin(), rhs.end(), res.begin());

  return res;

}