// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#define MGML_MATH_GUARDIAN

#include <math.h>

#ifndef __CUDACC__
	#ifndef MGML_ERROR_GUARDIAN
		#include "MGML_ERROR.h"
	#endif
#endif

#ifndef MGML_GLOBALS
	#include "MGML_GLOBALS.h"
#endif


#ifndef MGML_VECTOR_GUARDIAN
	#include "MGML_VECTOR.h"
#endif

#ifndef MGML_MQ_GUARDIAN
	#include "MGML_MQ.h"
#endif



namespace MGML_MATH
{
 static const float PI = ((float)3.141592654f);
 // defines for small numbers
 static const float EPSILON_E3 = (float)(1E-3);
 static const float EPSILON_E4 = (float)(1E-4);
 static const float EPSILON_E5 = (float)(1E-5);
 static const float EPSILON_E6 = (float)(1E-6);
 static const float EPSILON_E7 = (float)(1E-7);
 static const float EPSILON_E8 = (float)(1E-8);
 static const float EPSILON_E9 = (float)(1E-9);
 static const float EPSILON_E10 = (float)(1E-10);
 static const float EPSILON_E11 = (float)(1E-11);
 static const float EPSILON_E12 = (float)(1E-12);
 static const float MAX_FLOAT_VALUE = 1e38f;

 template<int n,class T>	   class VECTOR;
 template<int n,int m,class T> class MATRIX;
 template<int n,class T>       class LINE;
 template<int n,class T>       class RAY;
 template<int n,class T>       class SEGMENT;
 template<int n,class T>       class PLANE;
 template<int n,class T>       class SPHERE;
 template<int n,class T>       class AABB;
 template<int n,class T>       class BOX;
 template<int n,class T>       class TRIANGLE;



 // � STL ��� �-� ������-�� �� ��������
 template <class T>
 inline universal_call void SWAP(T& a,T& b)
 {
		T temp = a;
		a=b;b=temp;
 }

 template <class T> universal_call T MIN(T a, T b){ return a < b ? a : b; }
 template <class T> universal_call T MAX(T a, T b){ return a > b ? a : b; }

  template <class T> inline universal_call T MIN(T a,T b,T c)
  {
    if(a <= b && a <= c)
      return a;
    else if(b <= a && b <= c)
      return b;
    else
      return c;
  }

 template <class T> inline universal_call T MAX(T a,T b,T c)
 {
   if(a >= b && a >= c)
     return a;
   else if(b >= a && b >= c)
     return b;
   else
     return c;
 }


 template <class T>
 inline universal_call const T DEG_TO_RAD(const T ang)
  { return ((float)ang)*PI/180.0f; }

 template <class T>
 inline universal_call const T RAD_TO_DEG(const T rads)
 { return rads*180.0f/PI; }


 template <class T>
 inline universal_call T SIGN(T num)
 {
	 if(num>0)
		 return 1;
	 else if(num < 0)
		 return -1;
	 else
		 return 0;
 }

 template <int n,class T>
 inline universal_call const VECTOR<n,T> SPHERICAL_TO_ORTHOGONAL(const T r,const T phi,const T theta)
 {
   VECTOR<n,T> res;
   res.x = r*sin(theta)*cos(phi);
   res.y = r*sin(theta)*sin(phi);
   res.z = r*cos(theta);
   return res;
 }

 template <int n,class T>
 inline universal_call const VECTOR<n,T> SPHERICAL_TO_ORTHOGONAL(const VECTOR<n,T>& v)
 { return SPHERICAL_TO_ORTHOGONAL<n,T>(v.x,v.y,v.z); }

 // ���������� ������ (r,phi,theta)
 template <int n,class T>
 inline universal_call const VECTOR<n,T> ORTHOGONAL_TO_SPHERICAL(const VECTOR<n,T>& v)
 { return ORTHOGONAL_TO_SPHERICAL<n,T>(v.x,v.y,v.z); }

 template <int n,class T>
 inline universal_call const VECTOR<n,T> ORTHOGONAL_TO_SPHERICAL(const T x,const T y,const T z)
 {
   VECTOR<n,T> res;
   res.M[0] = sqrt(x*x + y*y + z*z);
   res.M[2] = acos(z/res.M[0]);
   res.M[1] = PI + atan2(y,x);
   return res;
 }

 inline float rnd_simple(float s, float e)
 {
   float t = (float)rand()/32767.0f;
   return s + t*(e-s);
 }

 inline float rnd(float s, float e) { return rnd_simple(s,e); }


 template<int n,class T>
 inline universal_call VECTOR<n,T> reflect(const VECTOR<n,T>& dir,const VECTOR<n,T>& normal)
 {
	VECTOR<n,T> temp =  normal * dot(dir,normal) * (-2);
	VECTOR<n,T> rVec = temp + dir;
	rVec.Normalize();
	return rVec;
  // return 2*normal + ray.dir;
 }


template<int n,class T>
inline universal_call bool refract(RAY<n,T>* inout_ray, VECTOR<n,T> normal, T eta)
{
  eta = 1.0f/eta; // ��� ���-�� ���� ���, ����� ������������ ���������, eta = material.n/1.0f;
  T cos_theta = -dot(normal, inout_ray->dir);

  if(cos_theta < 0)
  {
    cos_theta *= -1.0f;
    normal *= (-1);
    eta = 1.0f/eta;
  }

	T k = 1.0f - eta*eta*(1.0-cos_theta*cos_theta);
  if(k >= 0.0f)
  {
	  inout_ray->dir = eta*inout_ray->dir + (eta*cos_theta - sqrt(k))*normal;
	  inout_ray->dir.Normalize();
  }
  else
  {
    inout_ray->pos.M[0] = 0;
    inout_ray->pos.M[1] = INFINITY;
    inout_ray->pos.M[2] = 0;

    inout_ray->dir.M[0] = 1;
    inout_ray->dir.M[0] = 0;
    inout_ray->dir.M[0] = 0;
  }

	return (k > 0);
}


template<int n,class T>
inline universal_call VECTOR<n,T> refract(const VECTOR<n,T>& dir,const VECTOR<n,T>& normal,T n1,T n2)
{
  T eta = n1/n2;
  T cos_theta = -dot(normal,dir);
  T k = 1.0f - eta*eta*(1.0-cos_theta*cos_theta);
  VECTOR<n,T> ret = eta*dir + (eta*cos_theta - sqrt(k))*normal;
  ret.Normalize();				// can be removed
  return ret;
}

template<class X>
inline universal_call X SAFE_INVERT(X e)
{
  if(e >= 0 && e < EPSILON)
  {
    e = EPSILON;
  }
  else if( e < 0 && e > -EPSILON)
  {
    e = -EPSILON;
  }

  return ((X)1)/e;
}


template<int n,class T>
class SPHERE
{
public:
	VECTOR<n,T> pos;
	T r;
	T _rSquare;
	unsigned int material_id;
  T dummy; // for align ... ???

	inline universal_call void setRadius(float rhs)
	{
     r = rhs;
	 _rSquare = rhs*rhs;
	}

	inline universal_call T rSquare() const { return _rSquare; }

#ifndef __CUDACC__
	inline universal_call SPHERE(){}
	inline universal_call SPHERE(const VECTOR<n,T>& p,float _r)
	{
		pos = p;
		r = _r;
		_rSquare = r*r;
	}
	universal_call ~SPHERE(){}
#endif

};


template<class T>
struct PACKED_SPHERE3
{
#ifndef __CUDACC__
  inline PACKED_SPHERE3() {}
  inline PACKED_SPHERE3(const VECTOR<3,T>& p, T r)
	{
		m_pos.M[0] = p.M[0];
    m_pos.M[1] = p.M[1];
    m_pos.M[2] = p.M[2];
		m_r = r;
	}
#endif

	inline universal_call void setRadius(T rhs)
	{ m_r = rhs; }

	inline universal_call T r() const { return m_r; }
	inline universal_call T rSquare() const {return m_r*m_r;}

  inline universal_call void setPosition(const VECTOR<3,T>& in_pos)
  {
    m_pos.M[0] = in_pos.M[0];
    m_pos.M[1] = in_pos.M[1];
    m_pos.M[2] = in_pos.M[2];
  }

  inline universal_call VECTOR<3,T> getPosition() const
  {
    return m_pos;
  }

public:
	VECTOR<3,T> m_pos;
  T m_r;
};


// Axis Alined Bounding Box
template<int n,class T>
class AABB
{
	typedef const VECTOR<n,T> CVEC;

public:

	enum {k = MGML_MATH::VECTOR<n,T>::k};

	VECTOR<n,T> vmin;
	VECTOR<n,T> vmax;

	universal_call AABB()
  {
    for(int i=0;i<k;i++)
    {
      vmin[i] = 1e38f;
      vmax[i] = -1e38f;
    }
  }

	universal_call AABB(CVEC& _one){vmin=_one;vmax=_one;}
	universal_call AABB(CVEC& _min,CVEC& _max){vmin=_min;vmax=_max;}

	enum {	FRONT = 0,
			    BACK  = 1,
			    LEFT  = 2,
			    RIGHT = 3,
			    TOP	  = 4,
			    BOTTOM= 5};
	// FRONT(+z),BACK(-z) - xy
	// LEFT(-x),RIGHT(+x) - yz
	// TOP(+y),BOTTOM(-y) - xz

	// ALERT ! NOT SAFE!
	inline universal_call const VECTOR<n,T>* CVPointer() const {return &vmin;}

	inline universal_call VECTOR<n,T> center() const
	 {return 0.5*(vmin + vmax);}

  inline universal_call bool contain(const VECTOR<n,T>& point) const
  {
    for(int i=0;i<n;i++)
      if( point.M[i] < vmin.M[i] || point.M[i] > vmax.M[i])
        return false;
    return true;
  }

  inline universal_call bool contain(const AABB<n,T>& a_box) const
  {
    for(int i=0;i<n;i++)
    {
      if( a_box.vmin[i] < vmin[i] || a_box.vmax[i] > vmax[i])
        return false;
    }
    return true;
  }

  inline universal_call void include(const VECTOR<n,T>& point)
  {
    for(int i=0;i<k;i++)
    {
      if( point.M[i] < vmin.M[i])
        vmin.M[i] = point.M[i];

      if( point.M[i] > vmax.M[i])
        vmax.M[i] = point.M[i];
    }
  }

	inline universal_call void include(const SPHERE<n,T>& sph)
	{
		for(int i=0;i<k;i++)
		{
			if(vmin.M[i] > sph.pos.M[i] - sph.r)
				vmin.M[i] = sph.pos.M[i] - sph.r;

			if(vmax.M[i] < sph.pos.M[i] + sph.r)
				vmax.M[i] = sph.pos.M[i] + sph.r;
		}
	}

  inline universal_call void include(const AABB<n,T>& in_box)
  {
    for(int i=0;i<k;i++)
		{
      if(vmin.M[i] > in_box.vmin.M[i])
        vmin.M[i] = in_box.vmin.M[i];

      if(vmax.M[i] < in_box.vmax.M[i])
				vmax.M[i] = in_box.vmax.M[i];
    }
  }

  inline universal_call void intersect(const AABB<n,T>& in_box)
  {
    for(int i=0;i<k;i++)
    {
      vmin.M[i] = MAX(vmin.M[i], in_box.vmin.M[i]);
      vmax.M[i] = MIN(vmax.M[i], in_box.vmax.M[i]);
    }
  }

  inline universal_call T surfaceArea() const
  {
    T a = vmax.x - vmin.x;
    T b = vmax.y - vmin.y;
    T c = vmax.z - vmin.z;
    return 2*(a*b + a*c + b*c);
  }

  inline universal_call T volume() const
  {
     T a = vmax.x - vmin.x;
     T b = vmax.y - vmin.y;
     T c = vmax.z - vmin.z;
     return a*b*c;
  }

  inline universal_call int longestAxis() const
  {
    VECTOR<n,T> boxSize = vmax - vmin;

    if(boxSize.y >= boxSize.x && boxSize.y >= boxSize.z)
      return 1;
    else if (boxSize.z >= boxSize.x && boxSize.z >= boxSize.y)
      return 2;

    return 0;
  }

	// �������� ���������� ���������� ����� � ������������ �����
	// � ������������ � ������ � ������� �����
	inline universal_call  VECTOR<2,T> get_flat_coord(int num,const VECTOR<n,T>& p1) const
	{
		VECTOR<2,T> ret;
		switch(num)
		{
			case FRONT:
			case BACK:
				ret.x = p1.x - vmin.x;
				ret.y = p1.y - vmin.y;
			break;

			case LEFT:
			case RIGHT:
				ret.x = p1.z - vmin.z;
				ret.y = p1.y - vmin.y;
			//	ret.x = p1.y - vmin.y;
			//	ret.y = p1.z - vmin.z;
			break;

			case TOP:
			case BOTTOM:
				ret.x = p1.x - vmin.x;
				ret.y = p1.z - vmin.z;
			break;

		}
		return ret;
	}

};

template<int n,class T> T SurfaceArea(const AABB<n,T>& box) {return box.surfaceArea();}
template<int n,class T> T Volume(const AABB<n,T>& box) {return box.volume();}
template<int n,class T> T MaxAxisSize(const AABB<n,T>& box)
{
  VECTOR<n,T> boxSize = box.vmax - box.vmin;
  return MAX<T>(boxSize.x, boxSize.y, boxSize.z);
}


template<int n,class T>
class TRIANGLE
{
	typedef const VECTOR<n,T> CV;

public:

#ifndef __CUDACC__
	TRIANGLE(){}
	TRIANGLE(CV& a,CV& b,CV& c)
	 { A=a;B=b;C=c; }
#endif

	VECTOR<n,T> A;
	VECTOR<n,T> B;
	VECTOR<n,T> C;

};



// some functions
//void __fastcall matrix4x4f_mult_vector4f_fast(const float* m,const float* v,float* vres);
//void __fastcall matrix4x4f_mult_matrix4x4f_fast(const float* m1,const float* m2,float* mres);



static universal_call VECTOR<3,float> matrix4x4f_mult_vector3f(const float* M,const VECTOR<3,float>& v)
{
		VECTOR<3,float> res;

		// ���������� nvcc ����� ������������ ��������� ����� - �� ����� �������������.
		res.M[0] = M[0*4+0]*v.M[0] + M[0*4+1]*v.M[1] + M[0*4+2]*v.M[2];
		res.M[1] = M[1*4+0]*v.M[0] + M[1*4+1]*v.M[1] + M[1*4+2]*v.M[2];
		res.M[2] = M[2*4+0]*v.M[0] + M[2*4+1]*v.M[1] + M[2*4+2]*v.M[2];

		res.M[0]+=M[0+3];
		res.M[1]+=M[4+3];
		res.M[2]+=M[8+3];

	  return res;
}


template<class T>
static MGML_MATH::VECTOR<4,T> matrix4x4f_mult_normal4f(const MGML_MATH::MATRIX4X4<T>& in_m, const MGML_MATH::VECTOR<4,T>& in_norm)
{
  MGML_MATH::VECTOR<4,T> norm = in_norm; norm.w = 0;

  MGML_MATH::VECTOR<4,T> p1(0,0,0,0);
  MGML_MATH::VECTOR<4,T> p2 = p1 + 100.0f*norm;

  // ��� ������� ��� �������� �� g = in_m.GetInverse().GetTranspose();
  // ��. gl_NormalMatrix
  return normalize(in_m*(p2-p1));
}


// dinamic types.
enum {TYPE_OF_TRIANGLE=0,
	    TYPE_OF_SPHERE=1,
	    TYPE_OF_BOX=2};
};

