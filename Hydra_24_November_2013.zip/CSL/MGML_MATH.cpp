// � Copyright 2008 �������� ������
#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif

#ifndef MGML_MATH_INTERSECTIONS_GUARDIAN
	#include "MGML_MATH_INTERSECTIONS.h"
#endif

using namespace MGML_MATH;

//#include <limits>

//const float MGML_MATH::Intersect<MGML_MATH::RAY<4,float>,MGML_MATH::AABB<4,float> >
//	::flt_plus_inf =  std::numeric_limits<float>::max();

const float Intersect<RAY<4,float>,AABB<4,float> >
	::flt_plus_inf =  INFINITY;

__declspec(align(16)) const float Intersect<RAY<4,float>,AABB<4,float> >
	::ps_cst_plus_inf[4] = {  flt_plus_inf,  flt_plus_inf,  flt_plus_inf,  flt_plus_inf };

__declspec(align(16)) const float Intersect<RAY<4,float>,AABB<4,float> >
	::ps_cst_minus_inf[4]= { -flt_plus_inf, -flt_plus_inf, -flt_plus_inf, -flt_plus_inf };

__declspec(align(16)) const float Intersect<RAY<4,float>,AABB<4,float> >
	::ps_cst_one[4]= { 1,1,1,1};



#ifndef __CUDACC__

/*
void __fastcall MGML_MATH::matrix4x4f_mult_vector4f_fast(const float* m,const float* v,float* vres)
{
		__asm
		{
			push ebx
			mov ebx, v
			mov ecx, m
			mov edx, vres

			movaps xmm0, [ebx]
			movaps xmm1, [ecx]
			mulps xmm1, xmm0
			movaps xmm2, [ecx+16]
			mulps xmm2, xmm0
			movaps xmm3, [ecx+32]
			mulps xmm3, xmm0
			movaps xmm4, [ecx+48]
			mulps xmm4, xmm0

			movaps xmm5, xmm1
			unpcklps xmm5, xmm2
			unpckhps xmm1, xmm2
			movaps xmm6, xmm3
			unpcklps xmm6, xmm4
			unpckhps xmm3, xmm4

			movaps xmm2, xmm5
			shufps xmm2, xmm6, 68
			shufps xmm5, xmm6, 238
			addps xmm5, xmm2

			movaps xmm4, xmm1
			shufps xmm4, xmm3, 68
			shufps xmm1, xmm3, 238
			addps xmm1, xmm4

			addps xmm1, xmm5
			movaps [edx], xmm1

			pop ebx
		};
}


void __fastcall MGML_MATH::matrix4x4f_mult_matrix4x4f_fast(const float* m1, const float* m2, float* mres)
{
	MATRIX<4,4,float> tmp(m1);
	tmp.Transpose();
	m1 = tmp.L;

	matrix4x4f_mult_vector4f_fast(m1, m2,	mres);
	matrix4x4f_mult_vector4f_fast(m1, m2+4, mres+4);
	matrix4x4f_mult_vector4f_fast(m1, m2+8, mres+8);
	matrix4x4f_mult_vector4f_fast(m1, m2+16,mres+16);
}
*/

#else



#endif