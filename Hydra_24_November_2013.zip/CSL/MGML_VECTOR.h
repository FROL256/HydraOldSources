// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#define MGML_VECTOR_GUARDIAN

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif


// ��� ������ �������� ������������� 4D �������� ��� 3D
// ���� ����� ������������ ��������� ��������� - #define DISCARD_FOURTH_DIMENTION 0
#define DISCARD_FOURTH_DIMENTION 1

namespace MGML_MATH
{
template<int n,class T> class VECTOR;
template<class T>       class MATRIX4X4;

template<int n,class T>
class VECTOR
{

public:

	enum { k = n};

  T M[n];

  inline void set(T* ptr, unsigned int N) { for(int i=0;i<n;i++) M[i] = ptr[i]; }
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// simplified versions ///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class T>
class VECTOR<4,T> // behave like VECTOR<3,T>
{
public:

  enum { k = 3 };

  union
  {
    struct
    {
      T	x,y,z,w;
    };
    T M[4];
  };

  inline universal_call VECTOR() : x(0), y(0), z(0), w(1) { }
  inline universal_call VECTOR(const T* ptr) { this->x = ptr[0]; this->y = ptr[1]; this->z = ptr[2]; this->w = ptr[3]; }
  inline universal_call VECTOR(const VECTOR<4,T>& rhs) {*this = rhs;}
  inline universal_call VECTOR(const T a,const T b,const T c, const T d) : x(a), y(b), z(c), w(d) { }
  inline universal_call void set(const T a, const T b, const T c, const T d) { this->M[0]=a; this->M[1]=b; this->M[2]=c; this->M[3]=d; }

  inline universal_call VECTOR<4,T> cross(const VECTOR<4,T>& v) const {return *this->*v;}
  inline universal_call T lenSquare() const { return this->dot(*this); }
  inline universal_call T len() const {return sqrt(lenSquare());}
  inline universal_call void Normalize() { *this/=len();}

  // operators
  //
  inline universal_call VECTOR<4,T>& operator=(const VECTOR<4,T>& rhs) { this->x = rhs.x; this->y = rhs.y; this->z = rhs.z; this->w = rhs.w; return *this; }
  inline universal_call bool operator==(const VECTOR<4,T>& rhs) { return (abs(this->M[0] - rhs.M[0]) < EPSILON) && (abs(this->M[1] - rhs.M[1]) < EPSILON) && (abs(this->M[2] - rhs.M[2]) < EPSILON) && (abs(this->M[3] - rhs.M[3]) < EPSILON); }
  inline universal_call bool operator!=(const VECTOR<4,T>& rhs) {return !(*this==rhs);}
  inline universal_call T operator[](int i) const { ASSERT(i<4); return this->M[i];}
  inline universal_call T& operator[](int i) { ASSERT(i<4); return this->M[i];}

  inline universal_call T dot(const VECTOR<4,T>& rhs) const { return this->x*rhs.x + this->y*rhs.y + this->z*rhs.z; }
  inline universal_call VECTOR<4,T> operator->*(const VECTOR<4,T>& v) const { return VECTOR<4,T>(this->y*v.z - v.y*this->z, this->z*v.x - v.z*this->x, this->x*v.y - v.x*this->y, 1.0f); }

  inline universal_call VECTOR<4,T> operator+(const VECTOR<4,T>& rhs) const { return VECTOR<4,T>(this->x + rhs.x, this->y + rhs.y, this->z + rhs.z, this->w + rhs.w); }
  inline universal_call VECTOR<4,T> operator-(const VECTOR<4,T>& rhs) const { return VECTOR<4,T>(this->x - rhs.x, this->y - rhs.y, this->z - rhs.z, this->w - rhs.w); }
  inline universal_call VECTOR<4,T> operator*(const VECTOR<4,T>& rhs) const { return VECTOR<4,T>(this->x * rhs.x, this->y * rhs.y, this->z * rhs.z, this->w * rhs.w); }
  inline universal_call VECTOR<4,T> operator/(const VECTOR<4,T>& rhs) const { return VECTOR<4,T>(this->x / rhs.x, this->y / rhs.y, this->z / rhs.z, this->w / rhs.w); }

  inline universal_call VECTOR<4,T>& operator+=(const VECTOR<4,T>& rhs) { this->x += rhs.x; this->y += rhs.y; this->z += rhs.z; this->w += rhs.w; return *this; }
  inline universal_call VECTOR<4,T>& operator-=(const VECTOR<4,T>& rhs) { this->x -= rhs.x; this->y -= rhs.y; this->z -= rhs.z; this->w -= rhs.w; return *this; }
  inline universal_call VECTOR<4,T>& operator*=(const VECTOR<4,T>& rhs) { this->x *= rhs.x; this->y *= rhs.y; this->z *= rhs.z; this->w *= rhs.w; return *this; }
  inline universal_call VECTOR<4,T>& operator/=(const VECTOR<4,T>& rhs) { this->x /= rhs.x; this->y /= rhs.y; this->z /= rhs.z; this->w /= rhs.w; return *this; }

  // with constants
  //
  inline universal_call VECTOR<4,T> operator+(const T& rhs) const { return VECTOR<4,T>(this->x + rhs, this->y + rhs, this->z + rhs, this->w + rhs); }
  inline universal_call VECTOR<4,T> operator-(const T& rhs) const { return VECTOR<4,T>(this->x - rhs, this->y - rhs, this->z - rhs, this->w - rhs); }
  inline universal_call VECTOR<4,T> operator*(const T& rhs) const { return VECTOR<4,T>(this->x * rhs, this->y * rhs, this->z * rhs, this->w * rhs); }
  inline universal_call VECTOR<4,T> operator/(const T& rhs) const { return VECTOR<4,T>(this->x / rhs, this->y / rhs, this->z / rhs, this->w / rhs); }

  inline universal_call friend VECTOR<4,T> operator+(const T lhs, const VECTOR<4,T>& rhs) {return rhs + lhs;}
  inline universal_call friend VECTOR<4,T> operator-(const T lhs, const VECTOR<4,T>& rhs) {return (-1)*(rhs - lhs);}
  inline universal_call friend VECTOR<4,T> operator*(const T lhs, const VECTOR<4,T>& rhs) {return rhs * lhs;}
  inline universal_call friend VECTOR<4,T> operator/(const T lhs, const VECTOR<4,T>& rhs) {return VECTOR<4,T>(lhs/rhs.x, lhs/rhs.y, lhs/rhs.z, lhs/rhs.w);}

  inline universal_call VECTOR<4,T>& operator+=(const T& rhs) { this->x += rhs; this->y += rhs; this->z += rhs; this->w += rhs; return *this; }
  inline universal_call VECTOR<4,T>& operator-=(const T& rhs) { this->x -= rhs; this->y -= rhs; this->z -= rhs; this->w -= rhs; return *this; }
  inline universal_call VECTOR<4,T>& operator*=(const T& rhs) { this->x *= rhs; this->y *= rhs; this->z *= rhs; this->w *= rhs; return *this; }
  inline universal_call VECTOR<4,T>& operator/=(const T& rhs) { this->x /= rhs; this->y /= rhs; this->z /= rhs; this->w /= rhs; return *this; }

  void print(std::ostream& out) const { for(int i=0;i<4;i++) out << this->M[i] << " "; }
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// VECTOOR3 ////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


template<class T>
class VECTOR<3,T>
{
public:

  enum { k = 3 };

  union
  {
    struct
    {
      T	x,y,z;
    };
    T M[3];
  };

  inline universal_call VECTOR() : x(0), y(0), z(0) { }
  inline universal_call VECTOR(const T* ptr) { this->x = ptr[0]; this->y = ptr[1]; this->z = ptr[2]; }
  inline universal_call VECTOR(const VECTOR<3,T>& rhs) {*this = rhs;}
  inline universal_call VECTOR(const T a,const T b,const T c) : x(a), y(b), z(c) { }
  inline universal_call void set(const T a,const T b,const T c) { this->M[0]=a; this->M[1]=b; this->M[2]=c; }

  inline universal_call VECTOR<3,T> cross(const VECTOR<3,T>& v) const {return *this->*v;}
  inline universal_call T lenSquare() const { return this->dot(*this); }
  inline universal_call T len() const {return sqrt(lenSquare());}
  inline universal_call void Normalize() { *this/=len();}

  // operators
  //
  inline universal_call VECTOR<3,T>& operator=(const VECTOR<3,T>& rhs) { this->x = rhs.x; this->y = rhs.y; this->z = rhs.z; return *this; }
  inline universal_call bool operator==(const VECTOR<3,T>& rhs) { return (abs(this->M[0] - rhs.M[0]) < EPSILON) && (abs(this->M[1] - rhs.M[1]) < EPSILON) && (abs(this->M[2] - rhs.M[2]) < EPSILON); }
  inline universal_call bool operator!=(const VECTOR<3,T>& rhs) {return !(*this==rhs);}
  inline universal_call T operator[](int i) const { ASSERT(i<3); return this->M[i];}
  inline universal_call T& operator[](int i) { ASSERT(i<3); return this->M[i];}

  inline universal_call T dot(const VECTOR<3,T>& rhs) const { return this->x*rhs.x + this->y*rhs.y + this->z*rhs.z; }
  inline universal_call VECTOR<3,T> operator->*(const VECTOR<3,T>& v) const { return VECTOR<3,T>(this->y*v.z - v.y*this->z, this->z*v.x - v.z*this->x, this->x*v.y - v.x*this->y); }
  
  inline universal_call VECTOR<3,T> operator+(const VECTOR<3,T>& rhs) const { return VECTOR<3,T>(this->x + rhs.x, this->y + rhs.y, this->z + rhs.z); }
  inline universal_call VECTOR<3,T> operator-(const VECTOR<3,T>& rhs) const { return VECTOR<3,T>(this->x - rhs.x, this->y - rhs.y, this->z - rhs.z); }
  inline universal_call VECTOR<3,T> operator*(const VECTOR<3,T>& rhs) const { return VECTOR<3,T>(this->x * rhs.x, this->y * rhs.y, this->z * rhs.z); }
  inline universal_call VECTOR<3,T> operator/(const VECTOR<3,T>& rhs) const { return VECTOR<3,T>(this->x / rhs.x, this->y / rhs.y, this->z / rhs.z); }

  inline universal_call VECTOR<3,T>& operator+=(const VECTOR<3,T>& rhs) { this->x += rhs.x; this->y += rhs.y; this->z += rhs.z; return *this; }
  inline universal_call VECTOR<3,T>& operator-=(const VECTOR<3,T>& rhs) { this->x -= rhs.x; this->y -= rhs.y; this->z -= rhs.z; return *this; }
  inline universal_call VECTOR<3,T>& operator*=(const VECTOR<3,T>& rhs) { this->x *= rhs.x; this->y *= rhs.y; this->z *= rhs.z; return *this; }
  inline universal_call VECTOR<3,T>& operator/=(const VECTOR<3,T>& rhs) { this->x /= rhs.x; this->y /= rhs.y; this->z /= rhs.z; return *this; }

  // with constants
  //
  inline universal_call VECTOR<3,T> operator+(const T& rhs) const { return VECTOR<3,T>(this->x + rhs, this->y + rhs, this->z + rhs); }
  inline universal_call VECTOR<3,T> operator-(const T& rhs) const { return VECTOR<3,T>(this->x - rhs, this->y - rhs, this->z - rhs); }
  inline universal_call VECTOR<3,T> operator*(const T& rhs) const { return VECTOR<3,T>(this->x * rhs, this->y * rhs, this->z * rhs); }
  inline universal_call VECTOR<3,T> operator/(const T& rhs) const { return VECTOR<3,T>(this->x / rhs, this->y / rhs, this->z / rhs); }

  inline universal_call friend VECTOR<3,T> operator+(const T lhs, const VECTOR<3,T>& rhs) {return rhs + lhs;}
  inline universal_call friend VECTOR<3,T> operator-(const T lhs, const VECTOR<3,T>& rhs) {return (-1)*(rhs - lhs);}
  inline universal_call friend VECTOR<3,T> operator*(const T lhs, const VECTOR<3,T>& rhs) {return rhs * lhs;}
  inline universal_call friend VECTOR<3,T> operator/(const T lhs, const VECTOR<3,T>& rhs) {return VECTOR<3,T>(lhs/rhs.x, lhs/rhs.y, lhs/rhs.z);}

  inline universal_call VECTOR<3,T>& operator+=(const T& rhs) { this->x += rhs; this->y += rhs; this->z += rhs; return *this; }
  inline universal_call VECTOR<3,T>& operator-=(const T& rhs) { this->x -= rhs; this->y -= rhs; this->z -= rhs; return *this; }
  inline universal_call VECTOR<3,T>& operator*=(const T& rhs) { this->x *= rhs; this->y *= rhs; this->z *= rhs; return *this; }
  inline universal_call VECTOR<3,T>& operator/=(const T& rhs) { this->x /= rhs; this->y /= rhs; this->z /= rhs; return *this; }

  void print(std::ostream& out) const { for(int i=0;i<3;i++) out << this->M[i] << " "; }

};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// VECTOR 2 /////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class T>
class VECTOR<2,T>
{
public:

  enum { k = 2 };

  union
  {
    struct
    {
      T	x,y;
    };
    T M[2];
  };

  inline universal_call VECTOR() : x(0), y(0) { }
  inline universal_call VECTOR(const T* ptr) { this->x = ptr[0]; this->y = ptr[1];}
  inline universal_call VECTOR(const VECTOR<2,T>& rhs) {*this = rhs;}
  inline universal_call VECTOR(const T a, const T b) : x(a), y(b){ }
  inline universal_call void set(const T a, const T b) { this->M[0]=a; this->M[1]=b;}

  inline universal_call T lenSquare() const { return this->dot(*this); }
  inline universal_call T len() const {return sqrt(lenSquare());}
  inline universal_call void Normalize() { *this/=len();}

  // operators
  //
  inline universal_call VECTOR<2,T>& operator=(const VECTOR<2,T>& rhs) { this->x = rhs.x; this->y = rhs.y; return *this; }
  inline universal_call bool operator==(const VECTOR<2,T>& rhs) { return (abs(this->M[0] - rhs.M[0]) < EPSILON) && (abs(this->M[1] - rhs.M[1]) < EPSILON); }
  inline universal_call bool operator!=(const VECTOR<2,T>& rhs) {return !(*this==rhs);}
  inline universal_call T operator[](int i) const { ASSERT(i<2); return this->M[i];}
  inline universal_call T& operator[](int i) { ASSERT(i<2); return this->M[i];}

  inline universal_call T dot(const VECTOR<2,T>& rhs) const { return this->x*rhs.x + this->y*rhs.y; }
 
  inline universal_call VECTOR<2,T> operator+(const VECTOR<2,T>& rhs) const { return VECTOR<2,T>(this->x + rhs.x, this->y + rhs.y); }
  inline universal_call VECTOR<2,T> operator-(const VECTOR<2,T>& rhs) const { return VECTOR<2,T>(this->x - rhs.x, this->y - rhs.y); }
  inline universal_call VECTOR<2,T> operator*(const VECTOR<2,T>& rhs) const { return VECTOR<2,T>(this->x * rhs.x, this->y * rhs.y); }
  inline universal_call VECTOR<2,T> operator/(const VECTOR<2,T>& rhs) const { return VECTOR<2,T>(this->x / rhs.x, this->y / rhs.y); }

  inline universal_call VECTOR<2,T>& operator+=(const VECTOR<2,T>& rhs) { this->x += rhs.x; this->y += rhs.y; return *this; }
  inline universal_call VECTOR<2,T>& operator-=(const VECTOR<2,T>& rhs) { this->x -= rhs.x; this->y -= rhs.y; return *this; }
  inline universal_call VECTOR<2,T>& operator*=(const VECTOR<2,T>& rhs) { this->x *= rhs.x; this->y *= rhs.y; return *this; }
  inline universal_call VECTOR<2,T>& operator/=(const VECTOR<2,T>& rhs) { this->x /= rhs.x; this->y /= rhs.y; return *this; }

  // with constants
  //
  inline universal_call VECTOR<2,T> operator+(const T& rhs) const { return VECTOR<2,T>(this->x + rhs, this->y + rhs); }
  inline universal_call VECTOR<2,T> operator-(const T& rhs) const { return VECTOR<2,T>(this->x - rhs, this->y - rhs); }
  inline universal_call VECTOR<2,T> operator*(const T& rhs) const { return VECTOR<2,T>(this->x * rhs, this->y * rhs); }
  inline universal_call VECTOR<2,T> operator/(const T& rhs) const { return VECTOR<2,T>(this->x / rhs, this->y / rhs); }

  inline universal_call friend VECTOR<2,T> operator+(const T lhs, const VECTOR<2,T>& rhs) {return rhs + lhs;}
  inline universal_call friend VECTOR<2,T> operator-(const T lhs, const VECTOR<2,T>& rhs) {return (-1)*(rhs - lhs);}
  inline universal_call friend VECTOR<2,T> operator*(const T lhs, const VECTOR<2,T>& rhs) {return rhs * lhs;}
  inline universal_call friend VECTOR<2,T> operator/(const T lhs, const VECTOR<2,T>& rhs) {return VECTOR<2,T>(lhs/rhs.x, lhs/rhs.y);}

  inline universal_call VECTOR<2,T>& operator+=(const T& rhs) { this->x += rhs; this->y += rhs; return *this; }
  inline universal_call VECTOR<2,T>& operator-=(const T& rhs) { this->x -= rhs; this->y -= rhs; return *this; }
  inline universal_call VECTOR<2,T>& operator*=(const T& rhs) { this->x *= rhs; this->y *= rhs; return *this; }
  inline universal_call VECTOR<2,T>& operator/=(const T& rhs) { this->x /= rhs; this->y /= rhs; return *this; }

  void print(std::ostream& out) const { for(int i=0;i<2;i++) out << this->M[i] << " "; }
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// external operators ////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// �������� ��� 4D ������ � �������� - �����������
//
template<class T>
universal_call VECTOR<4,T> operator*(const MGML_MATH::MATRIX4X4<T>& m, const VECTOR<4,T>& v)
{
  VECTOR<4,T> res;

	// ���������� ����� ������������ ��������� ����� - �� ����� �������������.
  //
	res.M[0] = m.M[0][0]*v.M[0] + m.M[0][1]*v.M[1] + m.M[0][2]*v.M[2] + m.M[0][3]*v.M[3];
	res.M[1] = m.M[1][0]*v.M[0] + m.M[1][1]*v.M[1] + m.M[1][2]*v.M[2] + m.M[1][3]*v.M[3];
	res.M[2] = m.M[2][0]*v.M[0] + m.M[2][1]*v.M[1] + m.M[2][2]*v.M[2] + m.M[2][3]*v.M[3];
	res.M[3] = m.M[3][0]*v.M[0] + m.M[3][1]*v.M[1] + m.M[3][2]*v.M[2] + m.M[3][3]*v.M[3];

	return res;
}


// �������� ��� 4D ������ � �������� - �����������
template<class T>
VECTOR<3,T> universal_call operator*(const MGML_MATH::MATRIX4X4<T>& m, const VECTOR<3,T>& v)
{
	VECTOR<3,T> res;

	// ���������� ����� ������������ ��������� ����� - �� ����� �������������.
	//
  res.M[0] = m.M[0][0]*v.M[0] + m.M[0][1]*v.M[1] + m.M[0][2]*v.M[2];
	res.M[1] = m.M[1][0]*v.M[0] + m.M[1][1]*v.M[1] + m.M[1][2]*v.M[2];
	res.M[2] = m.M[2][0]*v.M[0] + m.M[2][1]*v.M[1] + m.M[2][2]*v.M[2];

	res.M[0] += m.M[0][3];
	res.M[1] += m.M[1][3];
  res.M[2] += m.M[2][3];

  return res;
}

template<class T>
VECTOR<2,T> universal_call operator*(const MGML_MATH::MATRIX4X4<T>& m, const VECTOR<2,T>& v)
{
  VECTOR<2,T> res;

  // ���������� ����� ������������ ��������� ����� - �� ����� �������������.
  //
  res.M[0] = m.M[0][0]*v.M[0] + m.M[0][1]*v.M[1];
  res.M[1] = m.M[1][0]*v.M[0] + m.M[1][1]*v.M[1];
  
  res.M[0] += m.M[0][2];
  res.M[1] += m.M[1][2];

  return res;
}


template<int n,class T> inline universal_call T dot(const VECTOR<n,T>& rhs,const VECTOR<n,T>& lhs) {return rhs.dot(lhs);}

#if DISCARD_FOURTH_DIMENTION


#else
	template<int n,class T>
	inline universal_call T dot3(const VECTOR<n,T>& rhs,const VECTOR<n,T>& lhs)
		{return rhs.x*lhs.x + rhs.y*lhs.y + rhs.z*lhs.z;}
#endif


template<int n,class T> inline universal_call VECTOR<n,T> cross3(const VECTOR<n,T>& rhs,const VECTOR<n,T>& lhs) {return rhs->*lhs;}
template<int n,class T> inline universal_call VECTOR<n,T> cross(const VECTOR<n,T>& rhs,const VECTOR<n,T>& lhs) {return rhs->*lhs;}
template<int n,class T> inline universal_call T length(const VECTOR<n,T>& rhs) { return rhs.len(); }

template<int n,class T>
inline universal_call VECTOR<n,T> normalize(const VECTOR<n,T>& rhs)
{
  VECTOR<n,T> res = rhs;
  T len_inv = 1.0f/length(rhs);
  res *= len_inv;
  return res;
}

template<int n,class T> inline universal_call VECTOR<n,T> lerp (const VECTOR<n,T>& u, const VECTOR<n,T>& v, T t) { return u + t * (v - u);}
template<class T> inline universal_call T lerp(const T u, const T v, const T t) {return u + t * (v - u);}

template<int n,class T>
inline universal_call VECTOR<n,T> clamp (const VECTOR<n,T>& v, const VECTOR<n,T>& a, const VECTOR<n,T>& b)
{
  VECTOR<n,T> res = v;

  for(int i=0;i<n;i++)
  {
    if(v[i] < a[i])
      v[i] = a[i];
    else if(v[i] > b[i])
      v[i]=b[i];
  }

  return res;
}


template<int n,class T>
inline universal_call VECTOR<n,T> mul(const VECTOR<n,T>& a, const VECTOR<n,T>& b)
{
  VECTOR<n,T> res;

  for(int i=0;i<n;i++)
   res[i] = a[i]*b[i];

  return res;
}

template<class T>
inline universal_call T clamp (T x, T a, T b)
{
  if (x<a) return a;
  else if (x>b) return b;
  else return x;
}

template<int n,class T> std::ostream& operator<<(std::ostream& out,const VECTOR<n,T>& m) {m.print(out); return out; }
template<int n,class T> std::istream& operator>>(std::istream& in, VECTOR<n,T>& v) { for(int i=0;i<n;i++) in >> v.M[i]; return in; }

};

