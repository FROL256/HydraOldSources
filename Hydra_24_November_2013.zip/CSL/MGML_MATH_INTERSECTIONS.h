// � Copyright 2008 �������� ������
#define MGML_MATH_INTERSECTIONS_GUARDIAN

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif

#ifndef EXT_TRIBOXOVERLAP_GUARDIAN
	#include "EXT_TriBoxOverlap.h"
#endif


namespace MGML_MATH
{


// ������������, �� ���� ������, ���������� ��
// ��������� �����������.

struct ray_box_face_intersector
{
	int				face_number[2];
	VECTOR<2,float>	flat_coord[2];
};

///////////////////////////////////////////////////////////////////////////////////
////
template<class A,class B>
struct Intersect
{
 static  bool exec(const A& obj1,const B& obj2)
 { ERROR_INTERSECTION_UNDEFINED(obj1,obj2); return false; }

};



///////////////////////////////////////////////////////////////////////////////////
//// box-box
template<int n,class T>
struct Intersect<AABB<n,T>,AABB<n,T> >
{
 typedef AABB<n,T>      _box;

 static universal_call bool exec(const _box& box,const _box& box2)
 {
  const int k = MGML_MATH::VECTOR<n,T>::k;

  for(int i=0;i<k;i++)
  {
		if(box.vmax.M[i] > box2.vmax.M[i])
		{
			if(box2.vmax.M[i] < box.vmin.M[i])
				return false;
		}
		else
		{
			if(box.vmax.M[i] < box2.vmin.M[i])
				return false;
		}
  }
  return true;
 }

};


template<class T>
struct Intersect<AABB<3,T>,AABB<3,T> >
{
  typedef AABB<3,T>      _box;

  // Include case when boxes have shared plane (b1.min.x == b2.max.x for example), so [ | ] - true
  //
  static universal_call bool overlapOnBoundary(const _box& box,const _box& box2)
  {
    bool overlapX = ((box2.vmax.x >= box.vmax.x) && (box2.vmin.x <= box.vmax.x)) || ((box.vmax.x >= box2.vmax.x) && (box.vmin.x <= box2.vmax.x));
    bool overlapY = ((box2.vmax.y >= box.vmax.y) && (box2.vmin.y <= box.vmax.y)) || ((box.vmax.y >= box2.vmax.y) && (box.vmin.y <= box2.vmax.y));
    bool overlapZ = ((box2.vmax.z >= box.vmax.z) && (box2.vmin.z <= box.vmax.z)) || ((box.vmax.z >= box2.vmax.z) && (box.vmin.z <= box2.vmax.z));

    return overlapX && overlapY && overlapZ;
  }

  // Do not include case when boxes have shared plane (b1.min.x == b2.max.x for example), so [ | ] - false
  //
  static universal_call bool exec(const _box& box,const _box& box2)
  {
    bool notOverlapX = (box.vmax.x >= box2.vmax.x) && (box2.vmax.x <= box.vmin.x) || (box.vmax.x <= box2.vmin.x);
    bool notOverlapY = (box.vmax.y >= box2.vmax.y) && (box2.vmax.y <= box.vmin.y) || (box.vmax.y <= box2.vmin.y);
    bool notOverlapZ = (box.vmax.z >= box2.vmax.z) && (box2.vmax.z <= box.vmin.z) || (box.vmax.z <= box2.vmin.z);

    return !(notOverlapX || notOverlapY || notOverlapZ);
  }

};


template<class T>
struct Intersect<AABB<4,T>,AABB<4,T> >
{
  typedef AABB<4,T>      _box;

  // Include case when boxes have shared plane (b1.min.x == b2.max.x for example), so [ | ] - true
  //
  static universal_call bool overlapOnBoundary(const _box& box,const _box& box2)
  {
    bool overlapX = ((box2.vmax.x >= box.vmax.x) && (box2.vmin.x <= box.vmax.x)) || ((box.vmax.x >= box2.vmax.x) && (box.vmin.x <= box2.vmax.x));
    bool overlapY = ((box2.vmax.y >= box.vmax.y) && (box2.vmin.y <= box.vmax.y)) || ((box.vmax.y >= box2.vmax.y) && (box.vmin.y <= box2.vmax.y));
    bool overlapZ = ((box2.vmax.z >= box.vmax.z) && (box2.vmin.z <= box.vmax.z)) || ((box.vmax.z >= box2.vmax.z) && (box.vmin.z <= box2.vmax.z));

    return overlapX && overlapY && overlapZ;
  }

  // Do not include case when boxes have shared plane (b1.min.x == b2.max.x for example), so [ | ] - false
  //
  static universal_call bool exec(const _box& box,const _box& box2)
  {
    bool notOverlapX = (box.vmax.x >= box2.vmax.x) && (box2.vmax.x <= box.vmin.x) || (box.vmax.x <= box2.vmin.x);
    bool notOverlapY = (box.vmax.y >= box2.vmax.y) && (box2.vmax.y <= box.vmin.y) || (box.vmax.y <= box2.vmin.y);
    bool notOverlapZ = (box.vmax.z >= box2.vmax.z) && (box2.vmax.z <= box.vmin.z) || (box.vmax.z <= box2.vmin.z);

    return !(notOverlapX || notOverlapY || notOverlapZ);
  }

};




///////////////////////////////////////////////////////////////////////////////////
//// box-triangle
template<int n>
struct Intersect< AABB<n,float>, TRIANGLE<n,float> >
{
 typedef AABB<n,float>     _box;
 typedef TRIANGLE<n,float> _triangle;
 typedef VECTOR<n,float>   vec;

 //typedef STATIC_ASSERT<(n==3 || n==4)> ERROR_ONLY_3_AND_4_DIMENTION_POSSIBLE;

 static bool exec(const _box& box,const _triangle& tri)
 {
	 vec center    = box.center();
	 vec half_size = (box.vmax - box.vmin)*0.5;
	 float triverts[3][3];
	 for(int i=0;i<3;i++)
	 {
		triverts[0][i] = tri.A.M[i];
		triverts[1][i] = tri.B.M[i];
		triverts[2][i] = tri.C.M[i];
	 }

	 return EXTERNAL_TOOLS::triBoxOverlap(center.M,half_size.M,triverts);
 }



};






///////////////////////////////////////////////////////////////////////////////////
//// box-sphere
template<int n, class T>
struct Intersect< AABB<n,T>, SPHERE<n,T> >
{
 typedef AABB<n,T>		   _box;
 typedef SPHERE<n,T>       _sphere;
 typedef VECTOR<n,T>	   vec;


 static universal_call inline T sqr(T x) {return x*x;}
 static universal_call bool exec(const _box& box,const _sphere& sph)
 {
	 const int k = MGML_MATH::VECTOR<n,T>::k;

   T dmin = 0;
   for( int i = 0; i < k; i++ )
   {
     if ( sph.pos.M[i] < box.vmin.M[i] ) dmin += sqr(sph.pos.M[i] - box.vmin.M[i]);
     else if ( sph.pos.M[i] > box.vmax.M[i] ) dmin += sqr(sph.pos.M[i] - box.vmax.M[i]);
   }
   return dmin <= sph.r*sph.r;
 }

};

};

