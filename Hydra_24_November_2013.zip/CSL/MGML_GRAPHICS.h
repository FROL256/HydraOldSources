#define MGML_GRAPHICS_GUARDIAN

#ifndef MGML_MATH_GUARDIAN
	#include "MGML_MATH.h"
#endif

#ifndef MGML_GUARDIAN
	#include "MGML.h"
#endif


//#ifndef KD_TREE_GUARDIAN
//	#include "kd_tree.h"
//#endif

//#include "MGML_MESH.h"

namespace MGML_GRAPHICS
{

template <int n_,class T>
struct VERTEX;

template <int   n,
		  class T,
		  class INDEX> class TRIANGLE;


		  class D3D_HAL{};
		  class OpenGL_HAL{};

template <class T> struct OTC;

typedef MGML_MATH::VECTOR<3,unsigned char> RGB256;

template<int n>
inline universal_call RGB256 REAL_COLOR_TO_RGB256(const MGML_MATH::VECTOR<n,float>& real_color)
{
 //typedef st_assert<(n >= 3)> n_must_be_gt_3;

 float  r = real_color.x*255;
 float  g = real_color.y*255;
 float  b = real_color.z*255;

 ASSERT(r < 256 && r >= 0);
 ASSERT(g < 256 && g >= 0);
 ASSERT(b < 256 && b >= 0);

 RGB256 res;
 res.set(r,g,b);

 return res;
}

template<int n>
inline universal_call MGML_MATH::VECTOR<n,float> RGB256_TO_REAL_COLOR(const RGB256& clr)
{
	MGML_MATH::VECTOR<n,float> res;
	res.x = clr.x;
	res.y = clr.y;
	res.z = clr.z;

	res *= (1.0f/255.0f);

	return res;
}

inline universal_call UINT RGB256_TO_UINT32(const RGB256& clr)
{
	unsigned int result = 0;
	unsigned int red   = clr.x;
	unsigned int green = clr.y;
	unsigned int blue  = clr.z;

	result = red | (green << 8) | (blue << 16);

	return result;
}


inline universal_call MGML_MATH::VECTOR<4,float> UINT32_TO_REAL_COLOR(unsigned int clr)
{
	unsigned char red_b	  = (clr & 0x000000FF);
	unsigned char green_b = (clr & 0x0000FF00) >> 8;
	unsigned char blue_b  = (clr & 0x00FF0000) >> 16;

	float red	= (float)red_b;
	float green = (float)green_b;
	float blue	= (float)blue_b;

	float inv_255 = 1.0f/255.0f;

	MGML_MATH::VECTOR<4,float> res;
	res.set(inv_255*red,inv_255*green,inv_255*blue,1);

	return res;
}

template<int n>
inline universal_call unsigned int REAL_COLOR_TO_UNT32(const MGML_MATH::VECTOR<n,float>& real_color)
{
	float  r = real_color.M[0]*255.0f;
	float  g = real_color.M[1]*255.0f;
	float  b = real_color.M[2]*255.0f;

	//ASSERT(r < 256.0f && r >= 0.0f);
	//ASSERT(g < 256.0f && g >= 0.0f);
	//ASSERT(b < 256.0f && b >= 0.0f);

	unsigned char red = (unsigned char)r, green = (unsigned char)g, blue = (unsigned char)b;
	return red | (green << 8) | (blue << 16);
}


//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
class HVS_Color
{
public:

#ifndef __CUDACC__

  HVS_Color(float h, float s, float v)
    { set(h,s,v); }
  HVS_Color()
    {set(0,0,0);}

#endif

  universal_call inline void setFromRGB(const MGML_MATH::VECTOR<3,float>& rgb)
  {

  #ifndef __CUDACC__
    if(rgb.x < 0.0f || rgb.x > 1.0f)
      throw std::runtime_error("HVS_Color::fromRGB: incorrect r value");

    if(rgb.y < 0.0f || rgb.y > 1.0f)
      throw std::runtime_error("HVS_Color::fromRGB: incorrect g value");

    if(rgb.z < 0.0f || rgb.z > 1.0f)
      throw std::runtime_error("HVS_Color::fromRGB: incorrect b value");
  #endif

    float r = rgb.x;
    float g = rgb.y;
    float b = rgb.z;

    float cMax = MGML_MATH::MAX(r,g,b);
    float cMin = MGML_MATH::MIN(r,g,b);

    if(cMax-cMin < MGML_MATH::EPSILON_E6)
      M[0] = 0.0f;
    else if(cMax == r && g >= b)
      M[0] = 60.0f*(g-b)/(cMax-cMin);
    else if(cMax == r && g < b)
      M[0] = 60.0f*(g-b)/(cMax-cMin) + 360;
    else if(cMax == g)
      M[0] = 60.0f*(b-r)/(cMax-cMin) + 120;
    else if(cMax == b)
      M[0] = 60.0f*(r-g)/(cMax-cMin) + 240;
    else
    {
    #ifndef __CUDACC__
      throw std::runtime_error("HVS_Color::setFromRGB: unreached code!");
    #endif
    }

    if(cMax == 0)
      M[1] = 0;
    else
      M[1] = 1.0f - cMin/cMax;

    M[2] = cMax;
  }

  universal_call inline MGML_MATH::VECTOR<3,float> toRGB()
  {
    int Hi = (((int)getH())/60) % 6;
    float f = getH()/60.0f - (((int)getH())/60);

    float p = getV()*(1.0f - getS());
    float q = getV()*(1.0f - f*getS());
    float t = getV()*(1.0f - (1.0f-f)*getS());

    float R,G,B;

    switch(Hi)
    {
    case 0:
      R = getV(); 	G = t; 	B = p;
      break;

    case 1:
      R = q; 	G = getV(); 	B = p;
      break;

    case 2:
      R = p; 	G = getV(); 	B = t;
      break;

    case 3:
      R = p; 	G = q; 	B = getV();
      break;

    case 4:
      R = t; 	G = p; 	B = getV();
      break;

    case 5:
      R = getV(); 	G = p; 	B = q;
      break;

    default:

   #ifndef __CUDACC__
      std::runtime_error("HVS_Color::toRGB: unreached code!");
   #endif
      break;
    };

    MGML_MATH::VECTOR<3,float> res;
    res.M[0] = R;
    res.M[1] = G;
    res.M[2] = B;
    return res;
  }


  universal_call inline void Saturate(float a_S = 1.0f)
  {
#ifndef __CUDACC__
    if(a_S < 0 || a_S > 1.0f)
      throw std::runtime_error("HVS_Color::Saturate: incorrect saturation value, must be between [0..1]");
#endif
    const float WHITE_TRESHOLD = 0.05f;
    if(getS() < a_S && getS() > WHITE_TRESHOLD)
      setS(a_S);
  }

  universal_call inline void set(float a_h, float a_s, float a_v)
  {
    setH(a_h);
    setS(a_s);
    setV(a_v);
  }

  universal_call inline void setH(float val)
  {
#ifndef __CUDACC__
    if(val < 0.0f || val >= 360.0f)
      throw std::runtime_error("HVS_Color::setH: incorrect h value");
#endif
    M[0] = val;
  }

  universal_call inline void setS(float val)
  {
#ifndef __CUDACC__
    if(val < 0.0f || val > 1.0f)
      throw std::runtime_error("HVS_Color::setH: incorrect s value");
#endif
    M[1] = val;
  }

  universal_call inline void setV(float val)
  {
#ifndef __CUDACC__
    if(val < 0.0f || val > 1.0f)
      throw std::runtime_error("HVS_Color::setH: incorrect v value");
#endif
    M[2] = val;
  }

  //universal_call inline float& h() {return M[0];}
  //universal_call inline float& s() {return M[1];}
  //universal_call inline float& v() {return M[2];}

  universal_call inline float getH() const {return M[0];}
  universal_call inline float getS() const {return M[1];}
  universal_call inline float getV() const {return M[2];}

protected:
  float M[3];

};




//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////      VERTEX        /////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
template <int n_,class T>
struct VERTEX
{
	MGML_MATH::VECTOR<n_,T> pos;
	MGML_MATH::VECTOR<n_,T> norm;
	MGML_MATH::VECTOR<2,T>  t;

	unsigned int material_id;

#ifndef __CUDACC__
	VERTEX()
	{

	}
#endif

	universal_call VERTEX& operator*=(const MGML_MATH::MATRIX<n_,n_,T>& m)
	{
		pos  = pos*m;
		norm = norm*m;
		norm.Normalize();
		return *this;
	}

	friend universal_call VERTEX operator*(const MGML_MATH::MATRIX<n_,n_,T>& m,const VERTEX& v)
	{
		VERTEX res;
		res.pos  = m*v.pos;
		res.norm = m*v.norm;
		res.norm.Normalize();
		return res;
	}

	inline bool HasSameMaterialAndTextures(const VERTEX& rhs) const
	{
		return material_id == rhs.material_id;
	}
	//����������� c ������� SSE ��� ������������������ �� CPU:
	//VERTEX& operator=(VERTEX& v);

};

//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////      MATERIAL        ///////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////


template<int _n>
struct MATERIAL 
{
	typedef MGML_MATH::VECTOR<_n,float> vec;
public:

#ifndef __CUDACC__

  MATERIAL(){}

  template<int k>
  MATERIAL(const MATERIAL<k>& a_mat)
  {
    const int copycat = MGML_MATH::MIN<int>(_n,k);

    for(int i=0;i<copycat;i++)
    {
      ka[i] = a_mat.ka[i];
      kd[i] = a_mat.kd[i];
      ks[i] = a_mat.ks[i];
    }

    power = a_mat.power;
    k_reflect = a_mat.k_reflect;
    k_refract = a_mat.k_refract;
    this->n = a_mat.n;
    BRDF_id = a_mat.BRDF_id;
  }

  template<int k>
  MATERIAL<_n> operator=(const MATERIAL<k>& a_mat)
  {
    MATERIAL::MATERIAL<n>(a_mat);
    return *this;
  }
#endif

	universal_call float getReflection() const {return k_reflect;}
	universal_call float getRefraction() const {return k_refract;}

  universal_call vec getColor() const
  {
    vec color = ka + kd + ks;
    color.Normalize();
    return color;
  }

	// phong model {
	vec  ka;			  // ambient
	vec  kd;			  // diffuse
	vec  ks;			  // specular
	float  power;		  // power of cos in phong model
	// } end phong model

	float  k_reflect;	  // reflections component
	float  k_refract;	  // refractive component
	float  n;			  // refractive exponent
  float  nRange;
	unsigned int BRDF_id; // BRDF index if BRDF used

	//����������� c ������� SSE ��� ������������������ �� CPU:
	//VERTEX& operator=(VERTEX& v);
};


//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////      TRIANGLE        ///////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

class Triangle
{
public:

	Triangle(){}

	Triangle(const int a,
			 const int b,
			 const int c)
	{
		A = a;
		B = b;
		C = c;
	}

	union
	{
		int v[3];
		struct
		{
			int A,B,C;
		};
	};

	union
	{
		int  attr32pack;
		struct
		{
			unsigned char texture_id[4];
		};
	};


};




};

