#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "Cube.h"
#include "Prism.h"
#include "Camera.h"

#include "../ColladaImport/ColladaImport.h"

void MakeSpheresDemo(IGraphicsEngine* pRender);
void MakeCornellBoxDemo(IGraphicsEngine* pRender);
void MakeEmptyCornellBox(IGraphicsEngine* pRender);
void MakeDiffuseSphereInCornellBox(IGraphicsEngine* pRender);

void MakeSimpleDemo(IGraphicsEngine* pRender);
void MakeCornellBoxWalls(IGraphicsEngine* pRender);

void MakeRefractionDemo(IGraphicsEngine* pRender);

void MakeSomeLights(IGraphicsEngine* pRender);
void MakeSomePointLights(IGraphicsEngine* pRender);
void AddFloor(IGraphicsEngine* pRender, int textureId, int a_materialId = 0, float size = 50);
void MakeRandomSpheresDemo(IGraphicsEngine* pRender);

void MakeClassicCornellBoxDemo(IGraphicsEngine* pRender);
void MakeAlexanderKharlamovDemo(IGraphicsEngine* pRender);

void AddFloor2(IGraphicsEngine* pRender, int textureId, int a_materialId, float wrap = 1.0f);



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void SetVSync(bool sync);
void glTablePrintf (int row, int col, const char *fmt, ...);
void CreateSHImages(int resX, int resY, int numLayers);


unsigned char* LoadTexture(const std::string& a_fileName, int* pW, int* pH);

void MakeTestScene_DiffuseSphereOnPlane(IGraphicsEngine* pRender);
void MakeTestScene_ParallaxMappingDemo(IGraphicsEngine* pRender);
void MakeTestScene_ParallaxMappingDemo2(IGraphicsEngine* pRender);
void MakeTestScene_GlossySphereInCornellBox(IGraphicsEngine* pRender);
void MakeTestScene_GlassSphereInCornellBox(IGraphicsEngine* pRender);


void DrawDebugTreeData3();
void DrawDebugSphereBox();
void DrawDebugSpheres(std::string fileName);
void DrawDebugBoxes(std::string fileName);
void DrawDebugPoints(std::string fileName);
void DrawDebugSpheres2(std::string fileName, int maxFiles);
void DebugDrawRays(std::string fileNamePos, std::string fileNameDir, std::string fileNameColor);
void DrawDebugBoxesLayered(std::string fileName, int maxFiles);

