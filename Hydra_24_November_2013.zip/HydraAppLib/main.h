#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gl/glew.h>
#include <gl/freeglut.h> 

#ifndef MGML_GUARDIAN
#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"
#include "../gpu_rt/HydraExport.h"

#include "../ColladaImport/Camera.h"
#include "../ColladaImport/ColladaImport.h"

#include "Input.h"
#include "Cube.h"
#include "Prism.h"
#include "scenes.h"
#include "ReLight.h"

#include <sstream>

#include "../HDRCore/PostProcessEngine/image.h"
#include "../HDRCore/PostProcessEngine/filters/tonemappingfilter.h"
#include "../HDRCore/PostProcessEngine/filters/blurfilter.h"
#include "../HDRCore/PostProcessEngine/filters/boxfilter.h"

struct IHydraUserControl
{
  IHydraUserControl(){}
  virtual ~IHydraUserControl(){}

  virtual void SetScene(const HydraScene* a_data)         = 0;
  virtual void ReloadProfile(const std::string& a_path)   = 0;
  virtual void GenerateProfile(const std::string& a_path) = 0;

  virtual void LoadSceneFromNativeHydraFormat(const std::string& a_vsgfFile, const std::string& a_hydraProfilePath) = 0;

  virtual HydraScene* GetScene() = 0;
  virtual Camera& GetCamera(int index) = 0;

  virtual HashMapImportParams* GetImportParamsHash() = 0;

  virtual ITextureImporter* GetTexImporter() = 0;
};

struct HydraControlCommon : public IHydraUserControl
{
  HydraControlCommon(IGraphicsEngine* a_pRender);
  ~HydraControlCommon();

  void SetScene(const HydraScene* a_data);
  void ReloadProfile(const std::string& a_path);
  void GenerateProfile(const std::string& a_path);

  void AddNewDataFromProfile(const std::string& a_path, std::vector<std::string> a_matNames);
  void LoadSceneFromNativeHydraFormat(const std::string& a_vsgfFile, const std::string& a_hydraProfilePath);

  HydraScene* GetScene() {return m_scene;}
  Camera& GetCamera(int index);

  HashMapImportParams* GetImportParamsHash() { return &m_importTextureMaxParams; }
 
  ITextureImporter* GetTexImporter() { return m_texImporter; }

  IGraphicsEngine*  m_pRender;
  HydraScene*       m_scene;
  ITextureImporter* m_texImporter;

  HashMapImportParams m_importTextureMaxParams;
};

