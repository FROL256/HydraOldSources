#include "main.h"

//SceneObjectIds* LastImportedSceneObjectsIds()

HydraControlCommon::HydraControlCommon(IGraphicsEngine* a_pRender) : m_pRender(a_pRender), m_texImporter(new ColladaTextureImporter()) 
{ 
 
}

HydraControlCommon::~HydraControlCommon()
{
  delete m_texImporter; m_texImporter = NULL;
}

void HydraControlCommon::SetScene(const HydraScene* a_data) 
{ 
  m_scene = const_cast<HydraScene*>(a_data); 
}

Camera& HydraControlCommon::GetCamera(int index)
{
  int index2 = index - 1;
 
  if(index2 < 0) 
    index2 = 0;
  else if(index2 >= m_scene->m_cameras.size())
    index2 = m_scene->m_cameras.size()-1;

  return m_scene->m_cameras[index2];
}


void HydraControlCommon::ReloadProfile(const std::string& a_path)
{
  if(a_path == "")
     return;

  m_importTextureMaxParams.clear();

  ColladaParser profileLoader;
  profileLoader.LoadXML(a_path);

  // update materials
  //
  TiXmlElement* materials_lib = profileLoader.GetElement("library_materials");
  TiXmlElement* aliases_mat   = profileLoader.GetElement("material_alias_groups");
  std::string name =  "";

  if(materials_lib != NULL)
  {
    HashMapImportParams* importPamars = &this->m_importTextureMaxParams;

    for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
    {
      RAYTR::HydraMaterial material = ReadSingleHydraMaterialFromXMLNode(nextMat->ToElement(), aliases_mat, m_pRender, m_texImporter, name, importPamars);

      if(m_scene->materials.find(name) == m_scene->materials.end())
      {
        fprintf(stderr, "Warning: model don't have material called %s \n", name.c_str());
        continue;
      }

      int matId = m_scene->materials[name];
      RAYTR::HydraMaterial materiaOld = m_pRender->GetHydraMaterial(matId); 

      // no texture update for now
      //
      material.ambient.color_texId        = materiaOld.ambient.color_texId;
      material.diffuse.color_texId        = materiaOld.diffuse.color_texId;
      material.specular.color_texId       = materiaOld.specular.color_texId;
      material.reflection.color_texId     = materiaOld.reflection.color_texId;
      material.transparency.color_texId   = materiaOld.transparency.color_texId;
      material.displacement.height_texId  = materiaOld.displacement.height_texId;
      material.displacement.normals_texId = materiaOld.displacement.normals_texId;

      m_pRender->SetHydraMaterial(material, matId);
    }
  }

  // update lights
  //
  TiXmlElement* lights_lib  = profileLoader.GetElement("library_lights");

  if(lights_lib == NULL)
    return;

  for(TiXmlNode* nextLight = lights_lib->FirstChild("light"); nextLight != NULL; nextLight = lights_lib->IterateChildren("light", nextLight))
  {    
    RAYTR::Light light = SingleHydraLightFromXMLNode(nextLight->ToElement(), m_pRender, m_texImporter, m_scene->globalTransformMatrix, name);

    if(m_scene->lights.find(name) == m_scene->lights.end())
    {
      fprintf(stderr, "Warning: model don't have light called %s \n", name.c_str());
      continue;
    }

    int lightId = m_scene->lights[name];   
    RAYTR::Light lightOld = m_pRender->GetLight(lightId);

    if(light.GetLightType() == RAYTR::Light::LIGHT_TYPE_SKY)
    {
      for(int i=0;i<6;i++)
        light.texCudeIndices[i] = lightOld.texCudeIndices[i];
    }

    // hack
    //
    if(light.GetLightType() == RAYTR::Light::LIGHT_TYPE_AREA || light.GetLightType() == RAYTR::Light::LIGHT_TYPE_SPHERICAL)
    {
      for(int i=0;i<9;i++)
        light.L[i]= lightOld.L[i];

      light.surfaceArea = lightOld.surfaceArea;
      light.emittance   = lightOld.emittance;
    }

    m_pRender->SetLight(light, lightId);
  }

}


void HydraControlCommon::AddNewDataFromProfile(const std::string& a_path, std::vector<std::string> a_matNames)
{
  if(a_path == "")
    return;

  m_importTextureMaxParams.clear();

  ColladaParser profileLoader;
  profileLoader.LoadXML(a_path);

  std::map<std::string, HydraMaterial> localMaterials;

  HashMapImportParams* importPamars = &this->m_importTextureMaxParams;

  // add materials
  //
  TiXmlElement* materials_lib = profileLoader.GetElement("library_materials");
  TiXmlElement* aliases_mat   = profileLoader.GetElement("material_alias_groups");
  std::string name =  "";

  for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
  {
    TiXmlElement* matElem = nextMat->ToElement();
    RAYTR::HydraMaterial material = ReadSingleHydraMaterialFromXMLNode(nextMat->ToElement(), aliases_mat, m_pRender, m_texImporter, name, importPamars);

    localMaterials[name] = material;
  }


  // now we have to put materials to renderer in the order we had them in .vsgf file
  //
  for(size_t i=0;i<a_matNames.size();i++)
    m_pRender->AddMaterial(HydraMaterial());
 
  for(size_t i=0;i<a_matNames.size();i++)
  {
    const std::string& nameRef = a_matNames[i];
    HydraMaterial mat = localMaterials[nameRef];
    m_pRender->SetHydraMaterial(mat,i);
    m_scene->materials[nameRef] = i;
  }



  // add lights
  //
  TiXmlElement* lights_lib  = profileLoader.GetElement("library_lights");
  if(lights_lib == NULL)
    return;

  std::map<std::string, RAYTR::Light> localLights;
  for(TiXmlNode* nextLight = lights_lib->FirstChild("light"); nextLight != NULL; nextLight = lights_lib->IterateChildren("light", nextLight))
  {
    RAYTR::Light light = SingleHydraLightFromXMLNode(nextLight->ToElement(), m_pRender, m_texImporter, m_scene->globalTransformMatrix, name);
    localLights[name] = light;
  }

  //
  //
  for(std::map<std::string, RAYTR::Light>::iterator p2 = localLights.begin(); p2!= localLights.end(); ++p2)
    m_scene->lights[p2->first] = m_pRender->AddLight(p2->second);

}

void HydraControlCommon::LoadSceneFromNativeHydraFormat(const std::string& a_vsgfFile, const std::string& a_hydraProfilePath)
{
  HydraGeomData data;
  data.read( a_vsgfFile.c_str() );

  delete m_texImporter;
  m_texImporter = new ColladaTextureImporter();

  m_texImporter->SetCurrentPathToMainFile(a_vsgfFile);
  m_texImporter->SetTexPathStorage(&(LastImportedScene()->texpaths));

  // load materials, lights and cameras
  //
  AddNewDataFromProfile(a_hydraProfilePath, data._getMaterialsNamesVector());


  m_pRender->DeclareVertexInputLayout(IGraphicsEngine::VERTEX_POSITION | IGraphicsEngine::VERTEX_NORMAL | IGraphicsEngine::VERTEX_UV | IGraphicsEngine::VERTEX_MATERIAL_ID);

  m_pRender->SetVertexPositionPointer(data.getVertexPositionsFloat4Array(), 4*sizeof(float));
  m_pRender->SetVertexNormalPointer(data.getVertexNormalsFloat4Array(), 4*sizeof(float));
  m_pRender->SetVertexUVPointer(data.getVertexTexcoordFloat2Array(), 2*sizeof(float));

  m_pRender->AddTriangles(Matrix4x4f(), data.getTriangleVertexIndicesArray(), data.getIndicesNumber(),  data.getVerticesNumber(),
                                        (const int*)data.getTriangleMaterialIndicesArray(), data.getIndicesNumber()/3 );

  m_texImporter->ResetCurrentPath();

}



std::string GetBRDFTypeStr(const RAYTR::HydraMaterial::Reflection& a_matRefl)
{
  std::string result = "phong";

  switch(a_matRefl.brdf_id)
  {
  case RAYTR::HydraMaterial::BRDF_BLINN:
    result = "blinn";
    break;

  case RAYTR::HydraMaterial::BRDF_COOK_TORRANCE:
    result = "cook-torrance";
    break;

  case RAYTR::HydraMaterial::BRDF_WARD:
    result = "ward";
    break;
  }

  return result;
}

std::string LightTypeName(const Light& a_light)
{
  switch(a_light.m_type)
  {
  case Light::LIGHT_TYPE_POINT:
    return "point";
    break;

  case Light::LIGHT_TYPE_SPOT:
    return "spot";
    break;

  case Light::LIGHT_TYPE_DIRECTIONAL:
    return "directional";
    break;

  case Light::LIGHT_TYPE_SKY:
    return "sky";
    break;

  case Light::LIGHT_TYPE_AREA:
    return "area";
    break;

  case Light::LIGHT_TYPE_SPHERICAL:
    return "sphere";
    break;

  case Light::LIGHT_TYPE_MESH:
    return "mesh";
    break;

  default:
    return "point";
    break;
  };
}

void PutCustomLightInfo(const char* spaceTab, ostream& out, const RAYTR::Light light)
{
  if(light.m_type != RAYTR::Light::LIGHT_TYPE_SKY && light.m_type != RAYTR::Light::LIGHT_TYPE_DIRECTIONAL && light.m_type != RAYTR::Light::LIGHT_TYPE_MESH)
    out << spaceTab << "  <position>" << light.pos << " </position>" << std::endl;

  if(light.m_type == RAYTR::Light::LIGHT_TYPE_DIRECTIONAL || light.m_type == RAYTR::Light::LIGHT_TYPE_SPOT)
    out << spaceTab << "  <direction>" << light.GetNormal()*(-1.0f) << " </direction>" << std::endl;

  if(light.m_type == RAYTR::Light::LIGHT_TYPE_SPOT)
  {
    out << std::endl;
    out << spaceTab << "  <falloff_angle>" << light.GetSpotLightCutoff(0) <<  " </falloff_angle>" << std::endl;
    out << spaceTab << "  <falloff_angle2>" << light.GetSpotLightCutoff(1) << " </falloff_angle2>" << std::endl;

    out << spaceTab << "  <falloff_power>" << light.GetSpotLightExponent(0) <<  " </falloff_power>" << std::endl;
    out << spaceTab << "  <falloff_power2>" << light.GetSpotLightExponent(1) << " </falloff_power2>" << std::endl;
  }

  if(light.m_type == RAYTR::Light::LIGHT_TYPE_SKY)
  {
    out << std::endl;
    out << spaceTab << "  <ao_ray_length>" << light.GetAORayLength() << " </ao_ray_length>" << std::endl;
    out << spaceTab << "  <ao_trace>" << int(light.Active()) << " </ao_trace>" << std::endl;
  }

  if(light.m_type == RAYTR::Light::LIGHT_TYPE_AREA)
  {
    out << std::endl;
    out << spaceTab << "  <size> " << std::endl;
    out << spaceTab << "    <Half-length> " << light.GetAreaLightSize().x << " </Half-length>" << std::endl;
    out << spaceTab << "    <Half-width>  " << light.GetAreaLightSize().y << " </Half-width>" << std::endl;
    out << spaceTab << "  </size> " << std::endl;

    out << std::endl;
    out << spaceTab << "  <matrix_rot> " << std::endl;
    out << spaceTab << "    " << light.L[0] << " " << light.L[1] << " " << light.L[2] << "\n";
    out << spaceTab << "    " << light.L[3] << " " << light.L[4] << " " << light.L[5] << "\n";
    out << spaceTab << "    " << light.L[6] << " " << light.L[7] << " " << light.L[8] << "\n";
    out << spaceTab << "  </matrix_rot> " << std::endl;
  }


  if(light.m_type == RAYTR::Light::LIGHT_TYPE_SPHERICAL)
  {
    out << std::endl;
    out << spaceTab << "  <size> " << std::endl;
    out << spaceTab << "    <radius>" << light.GetSphericalLightRadius() << "</radius>" << std::endl;
    out << spaceTab << "  </size> " << std::endl;
  }

}


void HydraControlCommon::GenerateProfile(const std::string& a_path)
{
  std::ofstream fout(a_path.c_str());

  fout << "<COLLADA profile=\"HydraProfile\">" << std::endl << std::endl;

  fout << "  <library_materials>" << std::endl << std::endl;

  // create path hashmap
  //
  std::map<int, std::string> texpath;

  for(HashMapI::iterator p = m_scene->texpaths.begin(); p!= m_scene->texpaths.end(); ++p)
    texpath[p->second] = p->first;

  std::map<std::string, int> matSorted;
  for(HashMapI::iterator p = m_scene->materials.begin(); p!= m_scene->materials.end(); ++p)
    matSorted[p->first] = p->second;

  // put materials
  //
  for(std::map<std::string, int>::iterator p = matSorted.begin(); p!= matSorted.end(); ++p)
  {
    RAYTR::HydraMaterial mat = m_pRender->GetHydraMaterial(p->second);

    const char* spaceTab = "    ";

    fout   << spaceTab << "<material name= \"" << p->first.c_str() << "\">" << std::endl;
    fout   << spaceTab << "  <hydra> " << std::endl;
    
    if(length(mat.ambient.color) > 1e-5f)
    {
      if(mat.flags & RAYTR::HydraMaterial::THIS_IS_LIGHT)
      {
        fout<< std::endl;
        fout<< spaceTab << "    <emission> " << std::endl;
        fout<< spaceTab << "      <color> " << mat.ambient.color << " </color> " << std::endl;
        if(mat.ambient.color_texId != INVALID_TEXTURE && texpath.find(mat.ambient.color_texId) != texpath.end())
          fout<<spaceTab<< "      <texture> " << texpath[mat.ambient.color_texId].c_str() << " </texture>"  << std::endl;
        fout<< spaceTab << "    </emission> " << std::endl;
      }
      else
      {
        fout<< std::endl;
        fout<< spaceTab << "    <ambient> " << std::endl;
        fout<< spaceTab << "      <color> " << mat.ambient.color << " </color> " << std::endl;
        if(mat.ambient.color_texId != INVALID_TEXTURE && texpath.find(mat.ambient.color_texId) != texpath.end())
          fout<<spaceTab<< "      <texture> " << texpath[mat.ambient.color_texId].c_str() << " </texture>"  << std::endl;
        fout<< spaceTab << "    </ambient>  " << std::endl;
      }
    }

    if(length(mat.diffuse.color) > 1e-5f)
    {
      fout << std::endl;
      fout << spaceTab << "    <diffuse> " << std::endl;
      fout << spaceTab << "      <color> " << mat.diffuse.color << " </color> " << std::endl;
      if(mat.diffuse.color_texId != INVALID_TEXTURE && texpath.find(mat.diffuse.color_texId) != texpath.end())
        fout <<spaceTab<< "      <texture> " << texpath[mat.diffuse.color_texId].c_str() << " </texture>"  << std::endl;
      fout << spaceTab << "    </diffuse>  " << std::endl;
    }

    if(length(mat.specular.color) > 1e-5f)
    {
      fout << std::endl;
      fout << spaceTab << "    <specular> " << std::endl;
      fout << spaceTab << "      <color> " << mat.specular.color << " </color> " << std::endl;
      if(mat.specular.color_texId != INVALID_TEXTURE && texpath.find(mat.specular.color_texId) != texpath.end())
        fout <<spaceTab<< "      <texture> " << texpath[mat.specular.color_texId].c_str() << " </texture>"  << std::endl;
      fout << spaceTab << "      <cos_power> " << mat.specular.power << " </cos_power> " << std::endl;
      fout << spaceTab << "      <IOR> " << mat.specular.fresnelIOR << " </IOR> " << std::endl;
      fout << spaceTab << "      <brdf_type> " << GetBRDFTypeStr(mat.specular) << " </brdf_type> " << std::endl;
      fout << spaceTab << "    </specular> " << std::endl;
    }

    if(length(mat.reflection.color) > 1e-5f)
    {
      fout << std::endl;
      fout << spaceTab << "    <reflectivity> " << std::endl;
      fout << spaceTab << "      <color> " << mat.reflection.color << " </color> " << std::endl;
      if(mat.reflection.color_texId != INVALID_TEXTURE && texpath.find(mat.reflection.color_texId) != texpath.end())
        fout <<spaceTab<< "      <texture> " << texpath[mat.reflection.color_texId].c_str() << " </texture>"  << std::endl;
      fout << spaceTab << "      <cos_power> " << mat.reflection.power << " </cos_power> " << std::endl;
      fout << spaceTab << "      <IOR> " << mat.reflection.fresnelIOR << " </IOR> " << std::endl;
      fout << spaceTab << "      <brdf_type> " << GetBRDFTypeStr(mat.reflection) << " </brdf_type> " << std::endl;
      fout << spaceTab << "    </reflectivity> " << std::endl;
    }

    if(length(mat.transparency.color) > 1e-5f || mat.transparency.color_texId != INVALID_TEXTURE)
    {
      fout << std::endl;
      fout << spaceTab << "    <transparency> " << std::endl;
      fout << spaceTab << "      <color> " << mat.transparency.color << " </color> " << std::endl;
      if(mat.transparency.color_texId != INVALID_TEXTURE && texpath.find(mat.transparency.color_texId) != texpath.end())
        fout <<spaceTab<< "      <texture> " << texpath[mat.transparency.color_texId].c_str() << " </texture>"  << std::endl; //thin_surface
      if(mat.flags & HydraMaterial::TRANSPARENCY_THIN_SURFACE)
        fout <<spaceTab<< "      <thin_surface> 1 </thin_surface>"  << std::endl; //thin_surface
      fout << spaceTab << "      <cos_power> " << mat.transparency.glossiness << " </cos_power> " << std::endl;
      fout << spaceTab << "      <IOR> " << mat.transparency.IOR        << " </IOR> " << std::endl;

      fout << spaceTab << "      <fog_color> " << mat.transparency.fogColor      << " </fog_color> " << std::endl;
      fout << spaceTab << "      <fog_multiplyer> " << mat.transparency.fogMultiplyer << " </fog_multiplyer> " << std::endl;
      fout << spaceTab << "      <exit_color> " << mat.transparency.exitColor     << " </exit_color> " << std::endl;
      
      fout << spaceTab << "    </transparency> " << std::endl;
    }

    if(mat.displacement.normals_texId != INVALID_TEXTURE)
    {
      fout<< std::endl;
      fout<< spaceTab << "    <displacement> " << std::endl;
      fout<< spaceTab << "      <height> " << mat.displacement.height << " </height> " << std::endl;
      if(mat.displacement.normals_texId != INVALID_TEXTURE && texpath.find(mat.displacement.normals_texId) != texpath.end())
        fout<<spaceTab<< "      <normals_texture> " << texpath[mat.displacement.normals_texId].c_str() << " </normals_texture>"  << std::endl;
      if(mat.displacement.height_texId != INVALID_TEXTURE && texpath.find(mat.displacement.height_texId) != texpath.end())
        fout<<spaceTab<< "      <height_texture> " << texpath[mat.displacement.height_texId].c_str() << " </height_texture>"  << std::endl;
      fout<< spaceTab << "    </displacement> " << std::endl;
    }
   
    fout   << std::endl;
    fout   << spaceTab << "  </hydra> " << std::endl;
    fout   << spaceTab << "</material> " << std::endl << std::endl;

  }

  fout << "  </library_materials>" << std::endl << std::endl;


  fout << std::endl;
  fout << "  <library_lights>" << std::endl << std::endl;

  // put lights
  //

  std::map<int, std::string> nameById;

  for(HashMapI::iterator p = m_scene->lights.begin(); p!= m_scene->lights.end(); ++p)
    nameById[p->second] = p->first;

  const char* spaceTab = "    ";

  for(int i=0;i<m_pRender->GetLightNumber();i++)
  {
    RAYTR::Light light = m_pRender->GetLight(i);
    std::string lightName = "unknown" + ToString(i);

    std::map<int, std::string>::iterator p = nameById.find(i);
    if(p != nameById.end())
      lightName = p->second;

    fout << std::endl;
    fout << spaceTab << "<light name= \"" << lightName.c_str() << "\">" << std::endl;

    fout << std::endl;
    fout << spaceTab << "  <general> " << std::endl;
    fout << spaceTab << "    <type> " << LightTypeName(light) << " </type> " << std::endl;
    fout << spaceTab << "    <ignore_transform> 1 </ignore_transform> " << std::endl;
    fout << spaceTab << "  </general> " << std::endl;

    fout << std::endl;
    PutCustomLightInfo(spaceTab, fout, light);

    fout << std::endl;
    fout << spaceTab << "  <intensity> " << std::endl;
    fout << spaceTab << "    <color> " << light.color << " </color>" << std::endl;
    fout << spaceTab << "    <multiplier> " << light.intensity << " </multiplier>" << std::endl;
    fout << spaceTab << "  </intensity> " << std::endl;

    fout << std::endl;
    fout << spaceTab << "  <constant_attenuation> "  << light.kc << " </constant_attenuation>" << std::endl;
    fout << spaceTab << "  <linear_attenuation> "    << light.kl << " </linear_attenuation>" << std::endl;
    fout << spaceTab << "  <quadratic_attenuation> " << light.kq << " </quadratic_attenuation>" << std::endl;

    fout << std::endl;
    fout << spaceTab << "</light>" << std::endl;

  }
   

  fout << "  </library_lights>" << std::endl << std::endl;

  fout << std::endl;
  fout << "</COLLADA>" <<std::endl;

  fout.close();


}
