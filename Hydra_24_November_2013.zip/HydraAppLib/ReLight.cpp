#include "ReLight.h"

extern Input input;
extern Camera* cam;

/////////////////////////////////////////////////////////////////////////////////////////////////
////
TestReLightPoxy::TestReLightPoxy(IGraphicsEngine* pEngine) : IReLightProxy(pEngine)
{
 
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
TestReLightPoxy::~TestReLightPoxy()
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::SetGeometryId(const std::string& id)
{
  m_geometryId = id;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::SetCurrLight(const RAYTR::Light& light)
{
  m_currLight = light;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::LoadSettingsFromSomeWhere(const std::string& id)
{
 
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::RenderSlice(const std::string& out_fileName)
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
IGraphicsEngine::RenderSettings TestReLightPoxy::GetCurrRenderState()
{
  IGraphicsEngine::RenderSettings renderState;
  renderState.SetTraceDepth(input.trace_depth);
  renderState.SetShadow(input.shadows);
  renderState.SetAA(input.AA);
  renderState.SetIndirrectIllumination(input.indirrectIllum);

  return renderState;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::RenderingParams TestReLightPoxy::GetCurrPTParams()
{
  GPU_Path_Tracer::RenderingParams pathTracerParams;
  pathTracerParams.minRaysPerPixel = 4;
  pathTracerParams.maxRaysPerPixel = 500;
  pathTracerParams.qualityTreshold = 1.0f;
  pathTracerParams.useHDRQualityEstimation = true;
  pathTracerParams.drawBlocks = true;
  return pathTracerParams;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::LoadCustomScene(const std::string& a_geomId)
{
  SetGeometryId(a_geomId);
  LoadCustomGeometry(m_pRender);
  SetCustomLights(m_pRender);

  GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(m_pRender);
  if (pathTracer==0)
    RUN_TIME_ERROR(" TestReLightPoxy::DoRendering: dynamic_cast failed");

  pathTracer->AddLightsAsGeometry();

  // switch on first light
  //
  if(m_pRender->GetLightNumber() > 0)
  {
    RAYTR::Light currLight = m_pRender->GetLight(0);
    currLight.SetActive(true);
    m_pRender->SetLight(currLight,0);
  }
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////

std::ostream& operator<<(std::ostream& out,const RAYTR::Light& light) 
{ 
  out << "pos = " << light.pos << std::endl;
  out << "color = " << light.color << std::endl;
  out << "intensity = " << light.intensity << std::endl;
  out << "kc = " << light.kc << std::endl;
  out << "kl = " << light.kl << std::endl;
  out << "kq = " << light.kq << std::endl;

  return out; 
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::ExportLights(const std::string& path)
{
  std::string fileName = path + "/lights_info.txt";
  std::ofstream out(fileName.c_str());

  
  out << "width = " << input.ext_width << std::endl;
  out << "height = " << input.ext_height << std::endl;
  out << std::endl;

  for(int i=0;i<m_pRender->GetLightNumber();i++)
  {
    out << "light " + ToString(i) << " is record" << std::endl;
    RAYTR::Light currLight = m_pRender->GetLight(i);
    out << currLight;
    out << "end record " + ToString(i) << std::endl;
    out << std::endl;
  }
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::DoRendering(const std::string& out_path)
{
  ExportLights(out_path);

  GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(m_pRender);
  if (pathTracer==0)
    RUN_TIME_ERROR(" TestReLightPoxy::DoRendering: dynamic_cast failed");

  // switch off all lights
  //
  for(int j=0;j<m_pRender->GetLightNumber();j++)
  {
    RAYTR::Light currLight = m_pRender->GetLight(j);
    currLight.SetActive(false);
    m_pRender->SetLight(currLight,j);
  }

  for(int i=0;i<m_pRender->GetLightNumber();i++)
  {
    RAYTR::Light currLight = m_pRender->GetLight(i);
    currLight.SetActive(true);
    m_pRender->SetLight(currLight,i);
    
    // do rendering 
    //
    GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(m_pRender);
    if (pathTracer!=0)
    {
      pathTracer->SetRenderingParams(GetCurrPTParams());
      pathTracer->ResetPathTracing();

      if(input.computeIrradianceCache)
        pathTracer->ComputeIrradianceCache();

      bool pathTracingFinished = false;

      int passCounter = 0;
      while(!pathTracingFinished)
      {
        GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;

        if(input.inputXML == NULL)
        {
          pathTracerParams.drawBlocks       = input.drawBlocks;
          pathTracerParams.drawRaysStatInfo = input.drawRayStatInfo;
        }

        pathTracer->SetRenderingParams(pathTracerParams);

        pathTracer->BeginPathTracingPass(GetCurrRenderState());
        pathTracingFinished = pathTracer->EndPathTracingPass();

        glutSwapBuffers();

        if (passCounter%10 == 0 && passCounter > 0)
          std::cerr << "pass " << passCounter << " finished" << std::endl;
        passCounter++;
      }

      std::string fileName = out_path + "/image_" + ToString(i) + ".bin"; 
      pathTracer->DumpBufferToFile("HDRColorBuffer", fileName.c_str());

      std::cout << "image(" << i << ") saved successfully to " << fileName.c_str() << std::endl;
    }

    // switch off this light
    //
    currLight = m_pRender->GetLight(i);
    currLight.SetActive(false);
    m_pRender->SetLight(currLight,i);
  }


}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::SetCustomLights(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_LIGHTS);
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void TestReLightPoxy::LoadCustomGeometry(IGraphicsEngine* pRender)
{
  //pRender->Clear(IGraphicsEngine::CLEAR_GEOMETRY | IGraphicsEngine::CLEAR_LIGHTS | IGraphicsEngine::CLEAR_MATERIALS);

  //m_geometryId = input.ext_scene;
  //m_geometryId = "ClassicCornellBoxDemo";
  //m_geometryId = "CornellBoxDemo";
  //m_geometryId = "SimpleScene";
  //m_geometryId = "CubesDemo";
  //m_geometryId = "TeapotInCornellBox";
  //m_geometryId = "DiffuseSphereInCornellBox";
  //m_geometryId = "DragonInCornellBox";
  //m_geometryId = "ConferenceRoomDemo";

  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | IGraphicsEngine::CLEAR_GEOMETRY  | IGraphicsEngine::CLEAR_LIGHTS);

}


