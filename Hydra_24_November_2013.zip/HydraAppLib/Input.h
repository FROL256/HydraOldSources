#pragma once

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/GPU_Path_Tracer.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"

struct Input 
{
	Input();

	void reset() {cam_mov.set(0,0,0,1); printPerfInfo = false;}

	MGML::vec4f cam_rot, cam_mov;

	int mx,my;
	bool ldown;		// ������ ����� ������� ����?
	bool rdown;		// ������ ������ ������� ����?
	bool exit_status;
  bool drawAllGrid;
  bool pathTracingEnabled;
  bool relightEnabled;

	int trace_depth;
  int diffuse_trace_depth;
  int tree_level_visible;
	bool shadows;
  bool indirrectIllum;
  int AA;
  bool ptStupidMode;
  bool ptCaustics;

  bool computeIrradianceCache;
  bool irradianceCacheCalculated;
  bool freeIrradianceCache;

  bool computeRadianceCache;
  bool radianceCacheCalculated;

  bool tracePhotonsDebug;
  bool tracePhotonsCausticsDebug;
  bool photonTracingFinishedDebug;

  bool voxelizeNow;
  bool voxelizeOnLoad;
  bool enableDebugOutput;

  int  rcType;
  bool debugViewSHReconstructed;

  bool printPerfInfo;
  bool drawBlocks;
  bool drawRayStatInfo;
  bool recursiveTracer;

  bool saveImageNow;
  bool toneMapNow;
  bool saveImageWithReadPixels;
  bool useFiltering;
  bool savePTImagesSequence;
  std::string savedImageName;
  std::string exportFilePath;
  bool showToneMappedImage;
  bool reloadHydraProfile;
  bool generateHydraProfiles;
  bool ambientView;
  bool transformICToPhMap;
  
  // for saving and restoring cameras
  //
  int saveCamera;
  int restoreCamera;
  
  // irradiance cache presets
  //
  float icWSErrorTreshold;
  float icError;
  int   icFixedRays;
  int   icMaxPasses;
  bool  icProgressiveEvaluation;
  bool  drawIrradianceCachePixelPoints;

  // photon maps
  //
  bool drawPhotons;
  bool drawPhotonsCaustic;
  bool progressivePhotonMap;
  bool progressiveCausticMap;
  bool enablePhotonsGartheringDiffuse;
  bool enablePhotonsGartheringCaustic;
  int  maxDiffusePhotons;
  int  maxCausticPhotons;
  int  skipFirstPhotonBounce;
  int  skipGartherBounce;
  float gartherRadiusDiffuse;
  float gartherRadiusCaustic;
  float causticPower;
  int   pmDiffuseRetrace;
  int   pmCausticRetrace;
  bool  enableSROctreeForPhotonMapping;
  bool  disablePhotonVisibilityTracing;

  // general
  //
  HANDLE m_sharedMemoryHandle;
  int ext_width;
  int ext_height;
  std::string ext_scene;
  std::string ext_renderer;
  bool animateLight;
  int accelStructConstructionMode;
  int debugLayerDraw;

  bool rayBufferFullSize;
  int  rtMeasureRaysType;
  int  rtReorderType;
  int  rtReorderPattern;

  std::string inColladaFile;
  std::string inColladaProfile;

  GPU_Path_Tracer::RenderingParams pt_params;
  char* inputXML;

  int m_debugIndex;
  float3 m_debugPos;

  float hdrStrength;
  float hdrPhi;
  float hdrWitePoint;
  float hdrGamma;


  float camSpeed;
  float camApect;

  void ReadXMLFromSharedMemory();
  void ReadXMLFromFile(const std::string& fileName);

	void Mouse(int button, int state, int x, int y); //��������� ������� ����
	void MouseMotion(int x, int y);                  //����������� ����
	void Keyboard(unsigned char key,int x,int y);   //�����
	void KeyboardSpecial(int key, int x, int y);   // ���� �����

  void SetCameraForTestPerf(std::string scene_name, int cam_number);


protected:

  void ReadXMLFromDoc(TiXmlDocument& a_doc);
};


