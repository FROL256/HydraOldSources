#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"

#include "Input.h"
#include "Cube.h"
#include "Prism.h"
#include "Camera.h"

#include "scenes.h"
#include "ColladaImport.h"




struct IReLightProxy
{
  IReLightProxy(IGraphicsEngine* pEngine){m_pRender = pEngine;}
  virtual ~IReLightProxy(){}

  virtual void SetGeometryId(const std::string& id) = 0;
  virtual void SetCurrLight(const RAYTR::Light& light) = 0;
  virtual void LoadSettingsFromSomeWhere(const std::string& id) = 0;
  virtual void RenderSlice(const std::string& out_fileName) = 0;
  virtual void DoRendering(const std::string& out_path) = 0;
  virtual void LoadCustomScene(const std::string& a_geomId) = 0;

  IGraphicsEngine* m_pRender;
};


class TestReLightPoxy : public IReLightProxy
{
public:

  TestReLightPoxy(IGraphicsEngine* pEngine);
  ~TestReLightPoxy();

  void SetGeometryId(const std::string& id);
  void SetCurrLight(const RAYTR::Light& light);
  void LoadSettingsFromSomeWhere(const std::string& id);
  void RenderSlice(const std::string& out_fileName);
  void DoRendering(const std::string& out_path);
  void LoadCustomScene(const std::string& a_geomId);

protected:

  void LoadCustomGeometry(IGraphicsEngine* pRender);
  void SetCustomLights(IGraphicsEngine* pRender);
  void ExportLights(const std::string& path);
  IGraphicsEngine::RenderSettings GetCurrRenderState();
  GPU_Path_Tracer::RenderingParams GetCurrPTParams();

  std::string m_geometryId;
  RAYTR::Light m_currLight;
  int m_width;
  int m_height;

  TestReLightPoxy(const TestReLightPoxy& rhs) : IReLightProxy(NULL) {}
  TestReLightPoxy& operator=(const TestReLightPoxy& rhs) {return TestReLightPoxy(rhs);}
};



