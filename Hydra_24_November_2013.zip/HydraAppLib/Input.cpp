#include "Input.h"
#include "Camera.h"

extern Camera* cam;

Input::Input() 
{
  exit_status = false;
	trace_depth = 1;
	shadows = false;
  AA = 1;
  tree_level_visible = 0;
 
  drawAllGrid = false;
  pathTracingEnabled = false;
  animateLight = false;
  computeIrradianceCache = false;
  irradianceCacheCalculated  = false;
  indirrectIllum = false;
  relightEnabled = false;
  saveImageNow = false;
  diffuse_trace_depth = 2;
  voxelizeNow  = false;
  saveImageWithReadPixels = false;
  useFiltering = false;
  recursiveTracer = false;
  transformICToPhMap = false;
  rcType = 0;
  voxelizeOnLoad = true;
  enableDebugOutput = false;
  ptStupidMode = false;
  ptCaustics = false;
  enableSROctreeForPhotonMapping = false;
  disablePhotonVisibilityTracing = false;

  camSpeed = 1.0f;
  camApect = 90.0f;

  m_debugPos = float3(-2,0,0);

  //accelStructConstructionMode = BVH_CONSTRUCT_VERY_FAST;
  //accelStructConstructionMode = BVH_CONSTRUCT_FAST;
  accelStructConstructionMode = BVH_CONSTRUCT_QUALITY;
  //accelStructConstructionMode = KD_TREE_CONSTRUCT_FAST;
  //accelStructConstructionMode = KD_TREE_CONSTRUCT_QUALITY;

  m_debugIndex     = 0;
  debugLayerDraw   = 0;
  rtReorderType    = 0;
  rtReorderPattern = 0;

  m_sharedMemoryHandle = OpenFileMappingA( FILE_MAP_READ, false, "RTE_benchmark_shmem" );

  inColladaFile = "";
  this->ext_width  = 1024;
  this->ext_height = 768;
  //animateLight = true;

  pt_params.minRaysPerPixel  = 8;
  pt_params.maxRaysPerPixel  = 4096; //2*4096; 
  pt_params.qualityTreshold  = 0.05f; 
  pt_params.useHDRQualityEstimation  = true;
  pt_params.loaylEstimateFunctionTresholdInRays = 200;
  pt_params.drawBlocks = false;
  pt_params.drawRaysStatInfo = true;
  pt_params.enableDOF = false;
  pt_params.dofLensRadius = 0.05f;
  pt_params.dofFocalPlaneDist = 8.0f;

  // ic
  //
  icWSErrorTreshold = 4.0f;
  icError           = 0.1f;
  icFixedRays       = 4096;
  icProgressiveEvaluation = true;
  icMaxPasses = 15;
  drawIrradianceCachePixelPoints = false;
  reloadHydraProfile = false;
  
  // ph maps
  //
  drawPhotons = false;
  drawPhotonsCaustic = false;
  skipFirstPhotonBounce = 1;
  skipGartherBounce     = 1;
  progressivePhotonMap  = false;
  progressiveCausticMap = true;
  maxDiffusePhotons = 1000000;
  maxCausticPhotons = 1000000;
  enablePhotonsGartheringDiffuse = false;
  enablePhotonsGartheringCaustic = false;
  gartherRadiusDiffuse = 0.01;
  gartherRadiusCaustic = 0.001;
  causticPower = 1.0f;
  pmDiffuseRetrace = 1;
  pmCausticRetrace = 1;

  tracePhotonsCausticsDebug = false;
  tracePhotonsDebug = false;


  inputXML = NULL;

  hdrStrength  = 0.25f;
  hdrPhi       = 16.0f;
  hdrWitePoint = 2.2f;
  hdrGamma     = 2.2;
  toneMapNow   = false;

  saveCamera = 0;
  restoreCamera = 0;
  savePTImagesSequence = false;
  generateHydraProfiles = true;

  exportFilePath   = "z_export.vsgf";
  savedImageName   = "hydra";
  showToneMappedImage = false;
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::SetCameraForTestPerf(std::string scene_name, int cam_number)
{
  if(scene_name == "Conference Room")
  {
    cam_rot.set(20,65,0,1); // conf room, position 1
    cam->pos = float4(-35,2,14,1);
  }
}


//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::ReadXMLFromFile(const std::string& fileName)
{
  TiXmlDocument doc(fileName);

  if(doc.ErrorDesc() != NULL)
  {
    std::cerr << "xml read error: " << doc.ErrorDesc() << std::endl;
    return;
  }

  ReadXMLFromDoc(doc);
}

struct SharedBufferInfo
{
  enum LAST_WRITER { WRITER_HYDRA_GUI = 0, WRITER_HYDRA_SERVER = 1 };

  unsigned int xmlBytesize;
  unsigned int lastWriter;
  unsigned int writerCounter;
  unsigned int dummy;
};

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::ReadXMLFromSharedMemory()
{
  static bool first = true;
  static SharedBufferInfo* pInfo = NULL;

  if(first)
  {
    inputXML = (char *)MapViewOfFile(m_sharedMemoryHandle, FILE_MAP_READ, 0, 0, 0);
    first = false;

    pInfo = (SharedBufferInfo*)inputXML;

    if(pInfo->dummy == 0xFAFAFAFA) // ok, this is true bufferInfo
    {
      //pInfo->xmlBytesize 
      //pInfo->lastWriter
      //pInfo->writerCounter
    }

    // scan buffer to find begin of the xml data
    //
    if(inputXML != NULL)
    {
      bool headerFound = false;

      for(int start=0; start < 256; start++)
      {
        char header[8]; //
        memcpy(header,inputXML+start,5); header[5] = '\0';
        if(std::string(header) == "<?xml")
        {
          inputXML = inputXML + start;
          headerFound = true;
          break;
        }
      }

      if(!headerFound)
        std::cerr << "input.cpp: xml header not found in shared buffer" << std::endl;
    }
  }

  if(inputXML == NULL)
    return;

  // optimization, read XML only if it was updated
  //
  static unsigned lastWriteId = 0xFFFFFFFF;

  if(pInfo!=NULL)
  {
    if(lastWriteId == pInfo->writerCounter)
      return;
    else
      lastWriteId = pInfo->writerCounter;
  }

  try
  {
    TiXmlDocument doc;
    doc.Parse(inputXML,0,TIXML_ENCODING_UTF8);
    ReadXMLFromDoc(doc);
  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
  
}

extern int WinWidth;
extern int WinHeight;
extern IGraphicsEngine* pRender;
void Reshape(int Width, int Height);

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::ReadXMLFromDoc(TiXmlDocument& doc)
{
  TiXmlHandle docHandle(&doc);
  TiXmlNode* node;
  std::string text;

  TiXmlNode* presetsNode = docHandle.FirstChild("hydra_presets").Node();
  if(presetsNode == NULL)
    return;

  node = presetsNode->FirstChild("resolution");
  if(node != NULL)
  {
    std::string res_text = node->ToElement()->GetText();
    size_t xPos = res_text.find('x');

    std::string widthStr  = res_text.substr(0, xPos);
    std::string heightStr = res_text.substr(xPos+1, res_text.size());

    ext_width  = atoi(widthStr.c_str());
    ext_height = atoi(heightStr.c_str());

    if( pRender != NULL && (ext_width != WinWidth || WinHeight != ext_height))
      glutReshapeWindow(ext_width, ext_height);
  }

  node = presetsNode->FirstChild("kd_tree_mode");
  if(node != NULL)
  {
    std::string method = node->ToElement()->GetText();
    if(method == string("fast"))
      accelStructConstructionMode = BVH_CONSTRUCT_VERY_FAST;
    else if(method == string("medium"))
      accelStructConstructionMode = BVH_CONSTRUCT_FAST;
    else
      accelStructConstructionMode = BVH_CONSTRUCT_QUALITY;
  }

  node = presetsNode->FirstChild("inSceneFile");
  if(node != NULL)
    inColladaFile = node->ToElement()->GetText();

  node = presetsNode->FirstChild("inColladaProfile");
  if(node != NULL)
    inColladaProfile = node->ToElement()->GetText();
 

  node = presetsNode->FirstChild("renderer_type");
  if(node != NULL)
    this->ext_renderer = node->ToElement()->GetText();

  node = presetsNode->FirstChild("shadows");
  if(node != NULL)
    this->shadows = (bool)atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("trace_depth");
  if(node != NULL)
    this->trace_depth = atoi(node->ToElement()->GetText()) + 1;
  
  node = presetsNode->FirstChild("diff_trace_depth");
  if(node != NULL)
    diffuse_trace_depth = atoi(node->ToElement()->GetText());

  indirrectIllum = (diffuse_trace_depth > 0);

  
  node = presetsNode->FirstChild("anti_aliasing_index");
  if(node != NULL)
  {
    int aaArray[4] = {1,4,16,64};
    int index = atoi(node->ToElement()->GetText());
    if(index < 0) index = 0;
    if(index > 3) index = 3;
    this->AA = aaArray[index];
  }
  
  node = presetsNode->FirstChild("path_tracing");
  if(node != NULL)
    this->pathTracingEnabled = (bool)atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("relight");
  if(node != NULL)
    this->relightEnabled = (bool)atoi(node->ToElement()->GetText());


  node = presetsNode->FirstChild("computeIrradianceCache");
  if(node)
    computeIrradianceCache = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("computeRadianceCache");
  if(node)
    computeRadianceCache = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("save_image");
  if(node)
    saveImageNow = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("toneMapNow");
  if(node)
    toneMapNow = bool(atoi(node->ToElement()->GetText()));

  //
  //
  node = presetsNode->FirstChild("minRaysPerPixel");
  if(node)
    pt_params.minRaysPerPixel = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("maxRaysPerPixel");
  if(node)
    pt_params.maxRaysPerPixel = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("pt_error");
  if(node)
    pt_params.qualityTreshold = atof(node->ToElement()->GetText())/100.0f;

  node = presetsNode->FirstChild("drawBlocks");
  if(node)
    pt_params.drawBlocks = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("drawRaysStatInfo");
  if(node)
  {
    pt_params.drawRaysStatInfo = atoi(node->ToElement()->GetText());
    drawRayStatInfo = atoi(node->ToElement()->GetText());
  }

  node = presetsNode->FirstChild("enableDOF");
  if(node)
    pt_params.enableDOF = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("dofLensRadius");
  if(node)
    pt_params.dofLensRadius = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("dofFocalPlaneDist");
  if(node)
    pt_params.dofFocalPlaneDist = atof(node->ToElement()->GetText());


  node = presetsNode->FirstChild("ptInitialSPP");
  if(node)
    pt_params.initialSPP = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("camFlySpeed");
  if(node)
    camSpeed = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("camAspect");
  if(node)
    camApect = atof(node->ToElement()->GetText());
    



  node = presetsNode->FirstChild("ptFilterType");
  if(node)
    pt_params.filterType = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("ptCoherent");
  if(node)
    pt_params.coherent = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("ptEnableRoulette");
  if(node)
    pt_params.enableRR = bool(atoi(node->ToElement()->GetText()));


  //
  //
  node = presetsNode->FirstChild("tmStrength");
  if(node)
    hdrStrength = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("tmWhitePoint");
  if(node)
    hdrWitePoint = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("tmGamma");
  if(node)
    hdrGamma = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("tmPhi");
  if(node)
    hdrPhi = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("savedImageName");
  if(node)
    savedImageName = node->ToElement()->GetText();

  node = presetsNode->FirstChild("showImageType");
  if(node)
    showToneMappedImage = (std::string(node->ToElement()->GetText()) == std::string("Show tone mapped image"));
  
  // ic
  //
  node = presetsNode->FirstChild("icError");
  if(node)
    icError = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("icWSError");
  if(node)
    icWSErrorTreshold = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("icFixedRays");
  if(node)
    icFixedRays = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("icEvalAlg");
  if(node)
    icProgressiveEvaluation = (std::string(node->ToElement()->GetText()) == std::string("progressive"));

  node = presetsNode->FirstChild("icMaxPassesNum");
  if(node)
    icMaxPasses = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("icDrawRecords");
  if(node)
    drawIrradianceCachePixelPoints = bool(atoi(node->ToElement()->GetText()));

  // photon maps
  //
  node = presetsNode->FirstChild("drawPhotons");
  if(node)
    drawPhotons = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("drawCausticPhotons");
  if(node)
    drawPhotonsCaustic = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("skipFirstBounce");
  if(node)
    skipFirstPhotonBounce = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("gatherBounce");
  if(node)
    skipGartherBounce = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("progressivePhotonMap");
  if(node)
    progressivePhotonMap = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("progressiveCaustics");
  if(node)
    progressiveCausticMap = bool(atoi(node->ToElement()->GetText()));


  node = presetsNode->FirstChild("maxDiffusePhotons");
  if(node)
    maxDiffusePhotons = int( atof(node->ToElement()->GetText()) );

  node = presetsNode->FirstChild("maxCausticPhotons");
  if(node)
    maxCausticPhotons = int( atof(node->ToElement()->GetText()) );

  node = presetsNode->FirstChild("enableDiffusePhotonTracing");
  if(node)
    enablePhotonsGartheringDiffuse = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("enableCausticPhotonTracing");
  if(node)
    enablePhotonsGartheringCaustic = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("initialGartherRadius");
  if(node)
    gartherRadiusDiffuse = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("initialGartherRadiusCaustic");
  if(node)
    gartherRadiusCaustic = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("pmDiffuseSinglePass");
  if(node)
    tracePhotonsDebug = bool(atoi(node->ToElement()->GetText()) == 1);


  //
  //

  node = presetsNode->FirstChild("reloadHydraProfile");
  if(node)
    reloadHydraProfile = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("generateHydraProfiles");
  if(node)
    generateHydraProfiles = bool(atoi(node->ToElement()->GetText()));
  
  node = presetsNode->FirstChild("ambientView");
  if(node)
    ambientView = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("voxelizeScene");
  if(node)
    voxelizeOnLoad = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("debugOutput");
  if(node)
    enableDebugOutput = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("causticPower");
  if(node)
    causticPower = atof(node->ToElement()->GetText());

  node = presetsNode->FirstChild("ptStupidMode");
  if(node)
    ptStupidMode = bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("ptCaustics");
  if(node)
    ptCaustics = bool(atoi(node->ToElement()->GetText()));



  node = presetsNode->FirstChild("pmDiffuseVisibilityTracing");
  if(node)
    disablePhotonVisibilityTracing = !bool(atoi(node->ToElement()->GetText()));

  node = presetsNode->FirstChild("pmDiffuseFrequency");
  if(node)
    pmDiffuseRetrace = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("pmCausticFrequency");
  if(node)
    pmCausticRetrace = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("phDebugOctreeType");
  if(node)
    enableSROctreeForPhotonMapping = !bool(atoi(node->ToElement()->GetText()));

  //
  //
  node = presetsNode->FirstChild("rtFullSizeMode");
  if(node)
    rayBufferFullSize = bool(atoi(node->ToElement()->GetText()));
 
  node = presetsNode->FirstChild("rtMeasureRaysIndex");
  if(node)
    rtMeasureRaysType = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("rayReorderType");
  if(node)
    rtReorderType = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("rayReorderPattern");
  if(node)
    rtReorderPattern = atoi(node->ToElement()->GetText());

  node = presetsNode->FirstChild("ptOneSeed");
  if(node)
    pt_params.qmcOneSeed = bool(atoi(node->ToElement()->GetText()));
  

}


//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::Mouse(int button, int state, int x, int y) //��������� ������� ����
{
	if (button==GLUT_LEFT_BUTTON)		//����� ������
	{
		switch (state)
		{
			case GLUT_DOWN:		//���� ������
				ldown=true;		//���������� ����
				mx=x;			//��������� ����������
				my=y;
				break;
			case GLUT_UP:
				ldown=false;
				break;
		}
	}
	if (button==GLUT_RIGHT_BUTTON)	//������ ������
	{
		switch (state)
		{
			case GLUT_DOWN:
				rdown=true;
				mx=x;
				my=y;
				break;
			case GLUT_UP:
				rdown=false;
				break;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::MouseMotion(int x, int y)                  //����������� ����
{
  if(ldown)		// ����� ������
	{
		cam_rot.M[0]+=0.1*(y-my);	//��������� ����� ��������
		cam_rot.M[1]+=0.1*(x-mx);
		mx=x;
		my=y;
	}
	if (rdown)	//������
	{
//		global_translate.M[0]+=0.01*(x-mx);	//����������� ����� �������� ���������
//		if (tt)
//			global_translate.M[2]+=0.01*(y-my);
//		else
//			global_translate.M[1]+=0.01*(my-y);
		mx=x;
		my=y;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::Keyboard(unsigned char key, int x, int y)
{

	switch(key)
	{
	case VK_ESCAPE:
		exit_status = true;
	break;
	
	case 'q':
	case 'Q':
		cam_rot.z -= 10.0f*camSpeed;
	break;
		
	case 'e':
	case 'E':
		cam_rot.z += 10.0f*camSpeed;
	break;

  case 'W':
    cam_mov.z = -1.0f*camSpeed;
  break;

	case 'w':
		cam_mov.z = -0.1f*camSpeed;
	break;
	
	case 's':
		cam_mov.z = 0.1f*camSpeed;
	break;

  case 'S':
    cam_mov.z = 1.0f*camSpeed;
    //saveImageNow = !saveImageNow;
  break;

  case 'A':
    //cam_mov.x = -1.0f;
  //break;

	case 'a':
		cam_mov.x = -0.1f*camSpeed;
	break;

	case 'd':
		cam_mov.x = 0.1f*camSpeed;
	break;

	case 'r':
		cam_mov.y = 0.1f*camSpeed;
    break;

  case 'R':
    computeRadianceCache = !computeRadianceCache;
	  break;

	case 'f':
		cam_mov.y = -0.1f*camSpeed;
	break;

  case 'F':
    useFiltering = !useFiltering;
  break;

  case 'G':
    enablePhotonsGartheringDiffuse = !enablePhotonsGartheringDiffuse;
  break;

  case 'C':
    enablePhotonsGartheringCaustic = !enablePhotonsGartheringCaustic;
  break;

  case 'p':
    pathTracingEnabled = !pathTracingEnabled;
  break;

  case 'P':
    tracePhotonsDebug = !tracePhotonsDebug;
    break;

  case 'O':
    tracePhotonsCausticsDebug = !tracePhotonsCausticsDebug;
    break;

  case 'o':
    relightEnabled = !relightEnabled;
    break;
   
  case 'I':
  case 'i':
    computeIrradianceCache = !computeIrradianceCache;
    break;

  case 'c':
    indirrectIllum = !indirrectIllum;
    break;

	case '1':
		trace_depth=1;
	break;

  case '!':
    rcType = 0;
  break;

	case '2':
		trace_depth=2;
	break;

  case '@':
    rcType = 1;
  break;


	case '3':
		trace_depth=3;
	break;

	case '4':
		trace_depth=4;
	break;

	case '5':
		trace_depth=5;
	break;

  case '6':
		trace_depth=6;
	break;

  case '7':
		trace_depth=7;
	break;

  case '8':
		trace_depth=8;
	break;

  case '9':
		trace_depth=9;
	break;


  case '#':
    saveCamera = 3;
  break;

  case '$':
    saveCamera = 4;
  break;

  case '%':
    saveCamera = 5;
  break;


	case 'Z':
	case 'z':
		shadows=!shadows;
	break;

	case 'g':
		AA = 1;
	break;

  case 'H':
    recursiveTracer = !recursiveTracer; 
  break;

	case 'h':
		AA = 4;
	break;

  case 'J':
	case 'j':
		AA = 16;
	break;

  case 'K':
    transformICToPhMap = !transformICToPhMap;
  break;

	case 'k':
		AA = 64;
	break;

  case '{':
  case '[':
    m_debugIndex--;
  break;

  case '}':
  case ']':
    m_debugIndex++;
    if(m_debugIndex<0)
      m_debugIndex=0;
    break;

  case '>':
  case '.':
    m_debugPos.x += 0.025f;
    break;
  
  case '<':
  case ',':
    m_debugPos.x -= 0.025f;
    break;

  case 'M':
    drawPhotonsCaustic = !drawPhotonsCaustic;
    break;

  case 'n':
    drawBlocks = !drawBlocks;
    m_debugPos.y += 0.025f;
    break;

  case 'N':
    drawPhotons = !drawPhotons;
    break;

  case 'm':
    drawRayStatInfo = !drawRayStatInfo;
    m_debugPos.y -= 0.025f;
    break;

  case 'V':
    voxelizeNow = true;
    break;

  case 'v':
    m_debugPos.z += 0.025f;
    break;

  case 'b':
    drawIrradianceCachePixelPoints = !drawIrradianceCachePixelPoints;
    m_debugPos.z -= 0.025f;
    break;

 case 'B':
    saveImageWithReadPixels = !saveImageWithReadPixels;
 break;

  case '+':
    debugLayerDraw++;
    break;

  case '-':
    debugLayerDraw--;
    break;


  case 'T':
    //toneMapNow = !toneMapNow;
    debugViewSHReconstructed = !debugViewSHReconstructed;
    break;

  case 'D':
    pt_params.enableDOF = !pt_params.enableDOF;
    break;


	}

}

//////////////////////////////////////////////////////////////////////////////////////////
////
void Input::KeyboardSpecial(int key, int x, int y)
{
  switch(key)
  {
  case GLUT_KEY_F3:
    restoreCamera = 3;
    break;

  case GLUT_KEY_F4:
    restoreCamera = 4;
    break;

  case GLUT_KEY_F5:
    restoreCamera = 5;
    break;

  case GLUT_KEY_F6:
    restoreCamera = -1;
    break;

  case GLUT_KEY_F7:
    restoreCamera = -2;
    break;

  case GLUT_KEY_F8:
    restoreCamera = -3;
    break;

  }
  
}


