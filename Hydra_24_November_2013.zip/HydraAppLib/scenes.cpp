#include <gl/glew.h>

#include "scenes.h"

#pragma warning(disable:4305)

using MGML_MATH::rnd;

extern Camera* cam;


void MakeCornellBoxWalls(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS);

  RAYTR::Material materials[7];

  materials[0].ka.set(0.00,0.00,0.00);
  materials[0].kd.set(0.50,0.50,0.50);
  materials[0].ks.set(0.00,0.00,0.00);
  materials[0].reflection.set(0.0, 0.0, 0.0);
  materials[0].refraction.set(0,0,0);
  materials[0].IOR  = 1.0f;
  materials[0].SetBlinnPhongPower(60);
  materials[0].BRDF_id = RAYTR::Material::BRDF_PHONG;

  materials[1] = materials[0];
  materials[1].ka.set(0.0,0.0,0.00);
  materials[1].kd.set(0.0,0.0,0.50);
  materials[1].ks.set(0.0,0.0,0.00);
  materials[1].refraction.set(0,0,0);
  materials[1].IOR = 1.0f;
  materials[1].BRDF_id = RAYTR::Material::BRDF_PHONG;

  materials[2] = materials[0];
  materials[2].ka.set(0.0,0,0);
  materials[2].kd.set(0.50,0,0);
  materials[2].ks.set(0.0,0,0);
  materials[2].reflection.set(0.0, 0.0, 0.0);
  materials[2].BRDF_id = RAYTR::Material::BRDF_PHONG;

  materials[3] = materials[0];
  materials[3].ka.set(0.0,0.0,0.0);
  materials[3].kd.set(0.30,0.0,0.30);
  materials[3].SetReflection(float3(0.5, 0.5, 0.5));
  materials[3].BRDF_id = RAYTR::Material::BRDF_PHONG;

  materials[4] = materials[0];
  materials[4].ka.set(0.0,0.0,0.0);
  materials[4].kd.set(0.0,0.30,0.0);
  materials[4].ks.set(0.0,0.0,0.0);
  materials[4].reflection.set(0.0, 0.0,0.0);
  materials[4].BRDF_id = RAYTR::Material::BRDF_PHONG;
  //materials[4].k_refract = 0.50;
  //materials[4].IOR = 1.01f;

  materials[5].ka.set(0.00,0.00,0.00);
  materials[5].kd.set(0.30,0.30,0.30);
  materials[5].SetSeparatedReflection(float3(0.5, 0.5, 0.5), float3(0.7, 0.7, 0.7));
  //materials[5].reflectGlossiness = 0.8f;
  materials[5].refraction.set(0,0,0);;
  materials[5].SetBlinnPhongPower(60);


  materials[6] = materials[0];
  materials[6].ka.set(0.0,0.0,0.0);

  for(int i=0;i<7;i++)
    pRender->AddMaterial(materials[i]);

  Matrix4x4f t1,r1,r2,s1;

  // triangles
  Vertex4f vert[4];
  uint sideIndices[6];

  float size = 4;

  // floor
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-size,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-size,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;


  float wrap = 4.0f;
  //float wrap = 1.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);
  sideIndices[0]=0;sideIndices[1]=1;sideIndices[2]=2;
  sideIndices[3]=2;sideIndices[4]=3;sideIndices[5]=0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // top
  vert[0].pos.set(-size,size,-size,1); vert[0].norm.set(0,-1,0,1);
  vert[1].pos.set(-size,size,size,1);  vert[1].norm.set(0,-1,0,1);
  vert[2].pos.set(size, size,size,1);   vert[2].norm.set(0,-1,0,1);
  vert[3].pos.set(size, size,-size,1);  vert[3].norm.set(0,-1,0,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // left wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(1,0,0,1);
  vert[1].pos.set(-size,-size,size,1);  vert[1].norm.set(1,0,0,1);
  vert[2].pos.set(-size,size,size,1);   vert[2].norm.set(1,0,0,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(1,0,0,1);

  vert[0].material_id = 2;
  vert[1].material_id = 2;
  vert[2].material_id = 2;
  vert[3].material_id = 2;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // right wall
  vert[0].pos.set(size,-size,-size,1); vert[0].norm.set(-1,0,0,1);
  vert[1].pos.set(size,-size,size,1);  vert[1].norm.set(-1,0,0,1);
  vert[2].pos.set(size,size,size,1);   vert[2].norm.set(-1,0,0,1);
  vert[3].pos.set(size,size,-size,1);  vert[3].norm.set(-1,0,0,1);

  vert[0].material_id = 4;
  vert[1].material_id = 4;
  vert[2].material_id = 4;
  vert[3].material_id = 4;

  pRender->AddTriangles(vert,4,sideIndices,6);

  // back wall
  vert[0].pos.set(-size,-size,-size,1); vert[0].norm.set(0,0,1,1);
  vert[1].pos.set(size,-size,-size,1);  vert[1].norm.set(0,0,1,1);
  vert[2].pos.set(size,size,-size,1);   vert[2].norm.set(0,0,1,1);
  vert[3].pos.set(-size,size,-size,1);  vert[3].norm.set(0,0,1,1);

  vert[0].material_id = 0;
  vert[1].material_id = 0;
  vert[2].material_id = 0;
  vert[3].material_id = 0;

  pRender->AddTriangles(vert,4,sideIndices,6);

}

void AddFloor(IGraphicsEngine* pRender, int textureId, int a_materialId, float size)
{
  // floor triangles
  const int numVert = 4;
  const int numIndices = 6;
  Vertex4f  vert[numVert];
  unsigned int indices[numIndices];

  // triangles
  vert[0].pos.set(-size,-3,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-3,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-3,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-3,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = a_materialId;
  vert[1].material_id = a_materialId;
  vert[2].material_id = a_materialId;
  vert[3].material_id = a_materialId;

  // just one texture allowing now - set always texture_id[0]
  // we think about multititexturing if future
  //vert[0].texture_id[0] = textureId;
  //vert[1].texture_id[0] = textureId;
  //vert[2].texture_id[0] = textureId;
  //vert[3].texture_id[0] = textureId;


  float wrap = 16.0f;
  //float wrap = 1.0f;
  vert[0].t.set(0,0); vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); vert[3].t.set(wrap,0);

  indices[0]=0;indices[1]=1;indices[2]=2;
  indices[3]=2;indices[4]=3;indices[5]=0;

  // floor
  pRender->AddTriangles(vert,numVert,indices,numIndices);
}


///////////////////////////////////////////////////////////////////////////////////
////
void MakeSpheresDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | 
                 IGraphicsEngine::CLEAR_GEOMETRY  |
                 IGraphicsEngine::CLEAR_LIGHTS);

  RAYTR::Material materials[7];


  materials[0].ka.set(0.0,0.0,0.05);
  materials[0].kd.set(0.0,0.0,0.10);
  materials[0].SetSeparatedReflection(float3(0.0,0.0,0.25), float3(0.5, 0.5, 0.5));
  materials[0].reflectGlossiness = 1.0f;
  materials[0].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[0].SetRoughness(0.25f);
  materials[0].fresnelIOR = 0.50f;
  materials[0].refraction.set(0,0,0);;
  materials[0].IOR = 1.0f;


  materials[1].ka.set(0.10,0.10,0.10);
  materials[1].kd.set(0.10,0.10,0.10);
  materials[1].SetSeparatedReflection(float3(0.25,0.25,0.25), float3(0.50, 0.50, 0.50));
  materials[1].reflectGlossiness = 0.9f;
  materials[1].fresnelIOR = 0.50f;
  materials[1].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[1].SetRoughness(0.25f);
  materials[1].refraction.set(0,0,0);
  materials[1].IOR  = 1.0f;

  materials[2].ka.set(0.10,0.00,0.10);
  materials[2].kd.set(0.20,0.00,0.20);
  materials[2].SetSeparatedReflection(float3(0.30,0.00,0.30), float3(0.50,0.50,0.50));
  materials[2].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[2].SetRoughness(0.25f);
  //materials[2].k_reflect = 0.25;

  materials[3] = materials[0];
  materials[3].ka.set(0.10,0.0,0.00);
  materials[3].kd.set(0.10,0.0,0.00);
  materials[3].SetSeparatedReflection(float3(0.25,0.0,0.00), float3(0.5, 0.5, 0.5));
  materials[3].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[3].SetRoughness(0.25f);

  materials[4] = materials[0];
  materials[4].ka.set(0.0,0.10,0.0);
  materials[4].kd.set(0.0,0.15,0.0);
  materials[4].ks.set(0.0,0.25,0.0);
  materials[4].SetSeparatedReflection(float3(0.00,0.25,0.20), float3(0.5, 0.5, 0.5));
  materials[4].reflectGlossiness = 0.8f;
  materials[4].fresnelIOR = 0.75f;
  materials[4].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[4].SetRoughness(0.25f);
  //materials[4].k_refract = 0.50;
  //materials[4].IOR = 1.01f;

  materials[5].ka.set(0.10,0.10,0.00);
  materials[5].kd.set(0.10,0.10,0.00);
  materials[5].ks.set(0.20,0.20,0.00);
  materials[5].SetSeparatedReflection(float3(0.25,0.25,0.00), float3(0.5,0.5,0.5));
  materials[5].reflectGlossiness = 0.9f;
  materials[5].refraction.set(0,0,0);
  materials[5].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[5].SetRoughness(0.25f);

  materials[6].ka.set(0.10,0.10,0);
  materials[6].kd.set(0.10,0.10,0);
  materials[6].ks.set(0.20,0.20,0);
  materials[6].SetSeparatedReflection(float3(0.20,0.20,0), float3(0.5, 0.5, 0.5));
  materials[6].refraction.set(0,0,0);
  materials[6].IOR = 1.2f;
  materials[6].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[6].SetRoughness(0.25f);

  for(int i=0;i<7;i++)
    pRender->AddMaterial(materials[i]);

  AddFloor(pRender,0,1);

  AABB3f box;

  box.vmin.set(-200,0,-200);
  box.vmax.set(200,20,200);

  int N = 200;
  int M = 8;

  for(int i=0;i<N;i++)
  {
    float tx = ((float)i)/((float)(N+1));
    float x = box.vmin[0] + tx*(box.vmax[0] - box.vmin[0]);

    for(int j=0;j<N;j++)
    {
      float tz = ((float)j)/((float)(N+1));
      float z = box.vmin[2] + tz*(box.vmax[2] - box.vmin[2]);

      for(int k=0;k<M;k++)
      {
        float ty = ((float)k)/((float)(M+1));
        float y = box.vmin[1] + ty*(box.vmax[1] - box.vmin[1]);

        float r = 0.48f;
        Sphere4f sphere;
        sphere.pos.set(x,y,z,1);
        sphere.setRadius(r);
        sphere.material_id = (int)rnd(0,5);
        pRender->AddSpheres(&sphere, 1);
      }
    }
  }

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  flatLight2.pos.set(0,20,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;

  pRender->AddLight(flatLight2);

}



///////////////////////////////////////////////////////////////////////////////////
////
void MakeRandomSpheresDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | 
                 IGraphicsEngine::CLEAR_GEOMETRY  |
                 IGraphicsEngine::CLEAR_LIGHTS);

  RAYTR::Material materials[7];

  materials[0].ka.set(0.0,0.0,0.05);
  materials[0].kd.set(0.0,0.0,0.10);
  materials[0].SetSeparatedReflection(float3(0.0,0.0,0.25), float3(0.5, 0.5, 0.5));
  materials[0].reflectGlossiness = 1.0f;
  materials[0].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[0].SetRoughness(0.25f);
  materials[0].fresnelIOR = 0.50f;
  materials[0].refraction.set(0,0,0);;
  materials[0].IOR = 1.0f;


  materials[1].ka.set(0.10,0.10,0.10);
  materials[1].kd.set(0.10,0.10,0.10);
  materials[1].SetSeparatedReflection(float3(0.25,0.25,0.25), float3(0.50, 0.50, 0.50));
  materials[1].reflectGlossiness = 0.9f;
  materials[1].fresnelIOR = 0.50f;
  materials[1].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[1].SetRoughness(0.25f);
  materials[1].refraction.set(0,0,0);
  materials[1].IOR  = 1.0f;

  materials[2].ka.set(0.10,0.00,0.10);
  materials[2].kd.set(0.20,0.00,0.20);
  materials[2].SetSeparatedReflection(float3(0.30,0.00,0.30), float3(0.50,0.50,0.50));
  materials[2].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[2].SetRoughness(0.25f);
  //materials[2].k_reflect = 0.25;

  materials[3] = materials[0];
  materials[3].ka.set(0.10,0.0,0.00);
  materials[3].kd.set(0.10,0.0,0.00);
  materials[3].SetSeparatedReflection(float3(0.25,0.0,0.00), float3(0.5, 0.5, 0.5));
  materials[3].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[3].SetRoughness(0.25f);

  materials[4] = materials[0];
  materials[4].ka.set(0.0,0.10,0.0);
  materials[4].kd.set(0.0,0.15,0.0);
  materials[4].ks.set(0.0,0.25,0.0);
  materials[4].SetSeparatedReflection(float3(0.00,0.25,0.20), float3(0.5, 0.5, 0.5));
  materials[4].reflectGlossiness = 0.8f;
  materials[4].fresnelIOR = 0.75f;
  materials[4].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[4].SetRoughness(0.25f);
  //materials[4].k_refract = 0.50;
  //materials[4].IOR = 1.01f;

  materials[5].ka.set(0.10,0.10,0.00);
  materials[5].kd.set(0.10,0.10,0.00);
  materials[5].ks.set(0.20,0.20,0.00);
  materials[5].SetSeparatedReflection(float3(0.25,0.25,0.00), float3(0.5,0.5,0.5));
  materials[5].reflectGlossiness = 0.9f;
  materials[5].refraction.set(0,0,0);
  materials[5].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[5].SetRoughness(0.25f);

  materials[6].ka.set(0.10,0.10,0);
  materials[6].kd.set(0.10,0.10,0);
  materials[6].ks.set(0.20,0.20,0);
  materials[6].SetSeparatedReflection(float3(0.20,0.20,0), float3(0.5, 0.5, 0.5));
  materials[6].refraction.set(0,0,0);
  materials[6].IOR = 1.2f;
  materials[6].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[6].SetRoughness(0.25f);

  for(int i=0;i<7;i++)
    pRender->AddMaterial(materials[i]);

  AddFloor(pRender,0,1);

  AABB3f box;

  box.vmin.set(-200,0,-200);
  box.vmax.set(200,20,200);

  float size = 50.0f;

  for(int i=0;i<30000;i++)
  {
    float r = 0.48f;
    Sphere4f sphere;
    sphere.pos.set(rnd(-size,size),rnd(0.0f,size),rnd(-size,size),1);
    sphere.setRadius(rnd(0.5f, 1.0f));
    sphere.material_id = MGML_MATH::MIN((int)(rnd(0.0f,6.0f)+0.5) , 6);
    pRender->AddSpheres(&sphere, 1);

  }

  
  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  flatLight2.pos.set(0,20,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;

  pRender->AddLight(flatLight2);

}


/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeCornellBoxDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | 
                 IGraphicsEngine::CLEAR_GEOMETRY  |
                 IGraphicsEngine::CLEAR_LIGHTS);


  MakeCornellBoxWalls(pRender);

  Matrix4x4f t1,r1,r2,s1;

  t1.Identity();
  t1.SetTranslate(vec3f(1.5,-2.99,2));
  r1.SetRotationY(MGML_MATH::DEG_TO_RAD(20.0f));
  s1.SetScale(vec3f(2.0f, 2.0f, 2.0));
  Cube cube(t1*r1*s1,1,255,0); 
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);

  t1.Identity();
  t1.SetTranslate(vec3f(-1.5,-1.74,-1.5));
  r1.SetRotationY(MGML_MATH::DEG_TO_RAD(-20.0f));
  s1.SetScale(vec3f(2.6f, 4.5f, 2.6f));
  cube = Cube(t1*r1*s1,1,255,0); 
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);


  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0.0025;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}


/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeClassicCornellBoxDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | IGraphicsEngine::CLEAR_GEOMETRY  | IGraphicsEngine::CLEAR_LIGHTS);

  MakeCornellBoxWalls(pRender);

  RAYTR::Material material;
  material.ka.set(0.00,0.00,0.00);
  material.kd.set(0.00,0.00,0.00);
  material.SetSeparatedReflection(float3(0.40,0.40,0.40), float3(0.4f, 0.4f, 0.4f));
  material.refraction.set(0.5f, 0.5f, 0.5f); 
  material.IOR = 1.5f;
  material.fogMultiplier = 0.5f;

  RAYTR::Material material2;
  material2.ka.set(0.00,0.00,0.00);
  material2.kd.set(0.00,0.00,0.00);
  material2.SetSeparatedReflection(float3(0.30,0.30,0.30), float3(0.7f, 0.7f, 0.7f));
  material2.refraction.set(0.f, 0.f, 0.f); 
  material2.IOR = 1.0f;
  material2.fogMultiplier = 0.0f;

  int MaterialId  = pRender->AddMaterial(material);   
  int MaterialId2 = pRender->AddMaterial(material2);   
 
  Sphere4f spheres[2];
  spheres[0] = Sphere4f(vec4f(-2.5,-2.5,-2,1),1.5);
  spheres[0].material_id = MaterialId2;

  spheres[1] = Sphere4f(vec4f(2.6,-3.0,1,1),1);
  spheres[1].material_id = MaterialId;
  pRender->AddSpheres(spheres,2);


  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}



/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeDiffuseSphereInCornellBox(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | IGraphicsEngine::CLEAR_GEOMETRY  | IGraphicsEngine::CLEAR_LIGHTS);


  MakeCornellBoxWalls(pRender);

  Sphere4f sphere;
  sphere.pos.set(0,-2,0,1);
  sphere.setRadius(2.0f);
  sphere.material_id = 0;
  pRender->AddSpheres(&sphere, 1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0.1;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}



/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeEmptyCornellBox(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | IGraphicsEngine::CLEAR_GEOMETRY  | IGraphicsEngine::CLEAR_LIGHTS);

  MakeCornellBoxWalls(pRender);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}


/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeSomeLights(IGraphicsEngine* pRender)
{

  //RAYTR::Light pointLight;

  //pointLight.pos.set(0,4,0);
  //pointLight.kc = 1;
  //pointLight.kl = 0;
  //pointLight.kq = 0;
  //pointLight.intensity = 2.0f;
  //pointLight.color.set(1,1,1);

  //pRender->AddLight(pointLight);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,4.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0.1;
  flatLight2.kq = 0.01;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeSomePointLights(IGraphicsEngine* pRender)
{

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  flatLight2.pos.set(0,3.95,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0.1;
  flatLight2.kq = 0.01;
  flatLight2.intensity = 2.0f;
  flatLight2.color.set(1.0f,1.0f,1.0f);

  pRender->AddLight(flatLight2);
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void MakeSimpleDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_ALL);

  RAYTR::Material materials[7];

  materials[0].ka.set(0.00,0.00,0.00);
  materials[0].kd.set(0.30,0.30,0.30);
  //materials[0].ks.set(0.55,0.55,0.55);
  //materials[0].reflection.set(0.0, 0.0, 0.0);
  materials[0].SetSeparatedReflection(float3(0.55,0.55,0.55), float3(0.0, 0.0, 0.0));
  materials[0].refraction.set(0,0,0);
  materials[0].IOR  = 1.0f;
  materials[0].SetBlinnPhongPower(60);
  materials[0].BRDF_id = RAYTR::Material::BRDF_PHONG;

  materials[1] = materials[0];
  materials[1].ka.set(0.0,0.0,0.00);
  materials[1].kd.set(0.0,0.0,0.10);
  //materials[1].ks.set(0.0,0.0,0.50);
  materials[1].SetSeparatedReflection(float3(0.0,0.0,0.5), float3(0.50, 0.50, 0.50));
  materials[1].reflectGlossiness = 1.0f;
  materials[1].fresnelIOR = 1.0f;
  materials[1].refraction.set(0,0,0);
  materials[1].IOR = 1.0f;
  materials[1].BRDF_id = RAYTR::Material::BRDF_PHONG;
  materials[1].SetBlinnPhongPower(80);

  materials[2] = materials[0];
  materials[2].ka.set(0.0,0,0);
  materials[2].kd.set(0.45,0.45,0.45);
  //materials[2].ks.set(0.25,0.25,0.25);
  //materials[2].reflection.set(0.25, 0.25, 0.25);
  materials[2].SetSeparatedReflection(float3(0.25,0.25,0.25), float3(0.25, 0.25, 0.25));
  materials[2].AddTexture(3,RAYTR::Material::TEX_STORE_DIFFUSE_COLOR);

  //materials[2].k_reflect = 0.25;

  materials[3] = materials[0];
  materials[3].ka.set(0.0,0.0,0.0);
  materials[3].kd.set(0.25,0.25,0.25);
  //materials[3].ks.set(0.25,0.25,0.25);
  //materials[3].reflection.set(0.5, 0.0, 0.0);
  materials[3].SetSeparatedReflection(float3(0.25,0.25,0.25), float3(0.5, 0.0, 0.0));
  materials[3].AddTexture(2,RAYTR::Material::TEX_STORE_DIFFUSE_COLOR);

  materials[4] = materials[0];
  materials[4].ka.set(0.0,0.00,0.0);
  materials[4].kd.set(0.0,0.05,0.0);
  materials[4].SetSeparatedReflection(float3(0.0,0.40,0.0), float3(0.40, 0.40, 0.40));
  materials[4].reflectGlossiness = 0.95f;
  materials[4].fresnelIOR = 2.0f;
  materials[4].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[4].SetRoughness(0.30f);

  materials[5].ka.set(0.01,0.01,0.01);
  materials[5].kd.set(0.20,0.20,0.20);
  //materials[5].ks.set(0.20,0.20,0.20);
  //materials[5].reflection.set(0.50, 0.50, 0.50);
  materials[5].SetSeparatedReflection(float3(0.2,0.20,0.2), float3(0.50, 0.50, 0.50));
  materials[5].reflectGlossiness = 1.0f;
  materials[5].refraction.set(0,0,0);
  materials[5].SetBlinnPhongPower(60);
  materials[5].AddTexture(1,RAYTR::Material::TEX_STORE_DIFFUSE_COLOR);

  materials[6].ka.set(0.01,0.01,0.01);
  materials[6].kd.set(0.20,0.20,0);
  //materials[6].ks.set(0.30,0.30,0);
  //materials[6].reflection.set(0.5, 0.5, 0.5);
  materials[6].SetSeparatedReflection(float3(0.3,0.3,0.0), float3(0.50, 0.50, 0.0));
  materials[6].refraction.set(0,0,0);;
  materials[6].IOR = 1.2f;
  materials[6].SetBlinnPhongPower(60);

  materials[0].AddTexture(0,RAYTR::Material::TEX_STORE_DIFFUSE_COLOR);

  for(int i=0;i<7;i++)
    pRender->AddMaterial(materials[i]);

  AddFloor(pRender,2,2);

  Sphere4f spheres[2];
  spheres[0] = Sphere4f(vec4f(1.5,-2,-3,0),1);
  spheres[0].material_id = 4;

  spheres[1] = Sphere4f(vec4f(-1,-2,-3,0),1);
  spheres[1].material_id = 1;
  pRender->AddSpheres(spheres,2);

 
  LoadTextureToRender("data/parquet.bmp", pRender);
  LoadTextureToRender("data/texture1.bmp", pRender);
  LoadTextureToRender("data/texture4.bmp", pRender);
  LoadTextureToRender("data/texture5.bmp", pRender);


  // add cubes, yellow sphere
  // insert cubes
  Matrix4x4f t1,r1,r2;
  //t1.Transpose();
  Cube cube;

  //parquet cube
  t1.SetTranslate(vec3f(0,-2.5,2));
  cube = Cube(t1,1,1,0); 
  pRender->AddTriangles(cube.GetVertices(),24,cube.GetIndices(),36);

  // level 1,left common textured cube
  t1.Identity(); r1.Identity();
  t1.SetTranslate(vec3f(-1.5,-2.5,2));
  r1.SetRotationY(45);
  cube = Cube(t1*r1,1,1,5);
  pRender->AddTriangles(cube.GetVertices(),24,cube.GetIndices(),36);

  // red metal cube
  t1.Identity(); r1.Identity();
  t1.SetTranslate(vec3f(4,-2.5,0));
  r1.SetRotationY(-45);
  cube = Cube(t1*r1,1,2,5); 
  pRender->AddTriangles(cube.GetVertices(),24,cube.GetIndices(),36);

  //level 1, right common cube
  t1.Identity(); r1.Identity();
  t1.SetTranslate(vec3f(1.5,-2.5,2));
  r1.SetRotationY(20);
  cube = Cube(t1*r1,1,1,0); 
  pRender->AddTriangles(cube.GetVertices(),24,cube.GetIndices(),36);

  //level 2, left common cube
  t1.Identity(); r1.Identity();
  t1.SetTranslate(vec3f(-0.8,-1.50,2));
  r1.SetRotationY(30);
  cube = Cube(t1*r1,1,255,4); 
  pRender->AddTriangles(cube.GetVertices(),24,cube.GetIndices(),36);

  //level 2, right blue
  t1.Identity(); r1.Identity();
  t1.SetTranslate(vec3f(0.6,-1.51,2));
  r1.SetRotationY(0);
  cube = Cube(t1*r1,1,255,3); // 255 means no texture
  pRender->AddTriangles(cube.GetVertices(),24,cube.GetIndices(),36);

  // blue mirror cube
  t1.Identity();
  t1.SetTranslate(vec3f(0,-0.499,2));
  cube = Cube(t1,1,255,1); 
  //Prism prism(t1*r1,1,1);
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);

  // yellow sphere on the top
  Sphere4f sph;
  sph = Sphere4f(vec4f(0,0.51,2,1),0.5);
  sph.material_id = 6;
  pRender->AddSpheres(&sph,1);

  //	sph = Sphere4f(vec4f(1,-0.5,-2,1),0.5);
  //	sph.material_id = 5;
  //	pRender->AddSpheres(&sph,1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  flatLight2.pos.set(4,2.99,6);
  flatLight2.kc = 1;
  flatLight2.kl = 0.0;
  flatLight2.kq = 0.01;
  flatLight2.intensity = 1.0f;
  //flatLight2.SetAreaLightSize(1.5f, 1.5f);
  //flatLight2.SetNormal(vec3f(0,-1.0f,0));
  //flatLight2.UseShadingModelCorrect();
  pRender->AddLight(flatLight2);


  float3 norm = normalize(float3(-0.5,-1,0.5));

  RAYTR::Light light3;
  light3.SetLighType(RAYTR::Light::LIGHT_TYPE_DIRECTIONAL);
  light3.m_norm = norm;
  light3.pos = -1.0f*norm*1000;
  light3.kc = 1;
  light3.kl = 0;
  light3.kq = 0;
  light3.intensity = 0.5f;
  pRender->AddLight(light3);
}


////////////////////////////////////////////////////////////////////////////////////////////
/////

void MakeRefractionDemo(IGraphicsEngine* pRender)
{
  pRender->Clear(IGraphicsEngine::CLEAR_MATERIALS | IGraphicsEngine::CLEAR_GEOMETRY  | IGraphicsEngine::CLEAR_LIGHTS);

  RAYTR::Material materials[7];

  materials[0].ka.set(0.00,0.00,0.00);
  materials[0].kd.set(0.30,0.30,0.30);
  materials[0].ks.set(0.55,0.55,0.55);
  materials[0].reflection.set(0.55,0.55,0.55);
  materials[0].refraction.set(0,0,0);
  materials[0].IOR  = 1.0f;
  materials[0].SetBlinnPhongPower(60);
  materials[0].AddTexture(0, RAYTR::Material::TEX_COMBINE_MULT_COLOR);

  materials[1].ka.set(0.0,0.0,0.05);
  materials[1].kd.set(0.0,0.0,0.05);
  materials[1].SetSeparatedReflection(float3(0.0,0.0,0.40), float3(0.50, 0.50, 0.50));
  materials[1].reflectGlossiness = 1.0f;
  materials[1].fresnelIOR = 1.0f;
  materials[1].refraction.set(0,0,0);
  materials[1].IOR = 1.0f;
  materials[1].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[1].SetRoughness(0.25f);

  materials[2].ka.set(0.15,0,0);
  materials[2].kd.set(0.3,0,0);
  materials[2].ks.set(0.5,0,0);
  materials[2].reflection.set(0.0, 0.0, 0.0);
  //materials[2].k_reflect = 0.25;

  materials[3].ka.set(0.10,0.10,0.10);
  materials[3].kd.set(0.10,0.10,0.10);
  materials[3].SetSeparatedReflection(float3(0.20,0.20,0.20), float3(0.4f, 0.4f, 0.4f));
  materials[3].refraction.set(0.6f, 0.6f, 0.6f); 
  materials[3].IOR = 1.5f;
  materials[3].fogMultiplier = 2.0f;
  materials[3].reflectGlossiness = 1.0f;
  materials[3].refractGlossiness = 1.0f;

  materials[4].ka.set(0.0,0.05,0.0);
  materials[4].kd.set(0.0,0.05,0.0);
  materials[4].SetSeparatedReflection(float3(0.0,0.40,0.0), float3(0.40, 0.40, 0.40));
  materials[4].reflectGlossiness = 0.8f;
  materials[4].fresnelIOR = 2.0f;
  materials[4].BRDF_id = RAYTR::Material::BRDF_COOK_TORRANCE;
  materials[4].SetRoughness(0.30f);
  //materials[4].k_refract = 0.50;
  //materials[4].IOR = 1.01f;

  materials[5].ka.set(0.10,0.10,0.10);
  materials[5].kd.set(0.20,0.20,0.20);
  materials[5].ks.set(0.20,0.20,0.20);
  materials[5].reflection.set(0.00, 0.00, 0.00);
  materials[5].reflectGlossiness = 1.0f;
  materials[5].refraction.set(0,0,0);
  materials[5].SetBlinnPhongPower(60);

  materials[6].ka.set(0.10,0.10,0);
  materials[6].kd.set(0.20,0.20,0);
  materials[6].ks.set(0.30,0.30,0);
  materials[6].reflection.set(0.5, 0.5, 0.5);
  materials[6].refraction.set(0,0,0);
  materials[6].IOR = 1.2f;
  materials[6].SetBlinnPhongPower(60);

  for(int i=0;i<7;i++)
    pRender->AddMaterial(materials[i]);

  AddFloor(pRender,0);

  Sphere4f spheres[2];
  spheres[0] = Sphere4f(vec4f(1.5,-2,-3,1),1);
  spheres[0].material_id = 4;

  spheres[1] = Sphere4f(vec4f(-1,-2,-3,1),1);
  spheres[1].material_id = 1;
  pRender->AddSpheres(spheres,2);


  // add cubes, yellow sphere
  // insert cubes
  Matrix4x4f t1,r1,r2;
  //t1.Transpose();
  Cube cube;

  t1.Identity();
  t1.SetTranslate(vec3f(1.5,-2.0,2));
  cube = Cube(t1,1,255,3); 
  //Prism prism(t1*r1,1,1);
  pRender->AddTriangles(cube.GetVertices(), 24, cube.GetIndices(), 36);

  Sphere4f sph;
  sph = Sphere4f(vec4f(-1.5,-2,2,1), 1.0);
  sph.material_id = 3;
  pRender->AddSpheres(&sph,1);

  RAYTR::Light flatLight2;
  flatLight2.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
  flatLight2.pos.set(0,2.99,0);
  flatLight2.kc = 1;
  flatLight2.kl = 0;
  flatLight2.kq = 0;
  flatLight2.intensity = 2.0f;
  flatLight2.SetAreaLightSize(1.5f, 1.5f);
  flatLight2.m_norm = vec3f(0,-1.0f,0);
  flatLight2.UseShadingModelCorrect();

  pRender->AddLight(flatLight2);
}


void AddFloor2(IGraphicsEngine* pRender, int textureId, int a_materialId, float wrap)
{
  // floor triangles
  const int numVert = 4;
  const int numIndices = 6;
  Vertex4f  vert[numVert];
  unsigned int indices[numIndices];

  // triangles
  float size = 10;
  vert[0].pos.set(-size,-3,-size,1); vert[0].norm.set(0,1,0,1);
  vert[1].pos.set(-size,-3,size,1);  vert[1].norm.set(0,1,0,1);
  vert[2].pos.set(size,-3,size,1);   vert[2].norm.set(0,1,0,1);
  vert[3].pos.set(size,-3,-size,1);  vert[3].norm.set(0,1,0,1);

  vert[0].material_id = a_materialId;
  vert[1].material_id = a_materialId;
  vert[2].material_id = a_materialId;
  vert[3].material_id = a_materialId;

  //float wrap = 1.0f;
  vert[0].t.set(0,0); 
  vert[1].t.set(0,wrap);
  vert[2].t.set(wrap,wrap); 
  vert[3].t.set(wrap,0);

  indices[0]=0;indices[1]=1;indices[2]=2;
  indices[3]=2;indices[4]=3;indices[5]=0;

  // floor
  pRender->AddTriangles(vert,numVert,indices,numIndices);
}


#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"
using std::string;
