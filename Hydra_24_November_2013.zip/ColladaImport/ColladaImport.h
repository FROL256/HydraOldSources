#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/Common_Graphics_Engine.h"
#include "../gpu_rt/Ray_Tracer.h"
#include "../gpu_rt/GPU_Ray_Tracer.h"
#include "../gpu_rt/GPU_Path_Tracer.h"
#include "../gpu_rt/OpenGL_Render.h"
#include "Camera.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"
using std::string;

#include "HydraProfiles.h"

#include <sstream>
#include <stdlib.h>
#include <math.h>


struct MaterialTextureImportMaxParams
{

  MaterialTextureImportMaxParams(): uTiling(1.0f), vTiling(1.0f), uOffset(0.0f), vOffset(0.0f) {} 

  float uTiling;
  float vTiling;
  float uOffset;
  float vOffset;

};

#ifdef __GNUC__

  //#include <unordered_map>

  //typedef std::unordered_map<std::string, std::string> HashMapS;
  //typedef std::unordered_map<std::string, int>         HashMapI;
  //typedef std::unordered_map<std::string, HashMapS>    HashMapOfHashMapS;

  //typedef std::unordered_map<std::string, std::vector<float> > HashMapFV;
  //typedef std::unordered_map<std::string, std::vector<int> >   HashMapIV;

  #include <map>

  typedef std::map<std::string, std::string> HashMapS;
  typedef std::map<std::string, int>         HashMapI;
  typedef std::map<std::string, MaterialTextureImportMaxParams> HashMapImportParams;
  typedef std::map<std::string, HashMapS>    HashMapOfHashMapS;

  typedef std::map<std::string, std::vector<float> > HashMapFV;
  typedef std::map<std::string, std::vector<int> >   HashMapIV;

#else
  
  #include <hash_map>  

  typedef stdext::hash_map<std::string, std::string> HashMapS;
  typedef stdext::hash_map<std::string, int>         HashMapI;
  typedef stdext::hash_map<std::string, MaterialTextureImportMaxParams> HashMapImportParams;
  typedef stdext::hash_map<std::string, HashMapS>    HashMapOfHashMapS;

  typedef stdext::hash_map<std::string, std::vector<float> > HashMapFV;
  typedef stdext::hash_map<std::string, std::vector<int> >   HashMapIV;

  #pragma warning(disable:4305)  // warning C4305: �������������: �������� �� 'double' � 'const float'
  #pragma warning(disable:4503)  // warning C4503: ����� ����������� ����� ������� � ����������� ��������� ������������ ��������, ��� �������

#endif


const bool COLLADA_DEBUG = false;

template<class T>
static void DEBUG_PRINT(const std::string before, const T& x, const std::string after="")
{
  static ofstream colladaLog("collada_parsing_log.txt", ios::app);

  if(COLLADA_DEBUG)
    colladaLog << before.c_str() << x << " " << after.c_str() << std::endl;
}

struct HydraScene
{
  void clear()
  {
    materials.clear();
    lights.clear();
    cameras.clear();
    texpaths.clear();
    m_cameras.clear();
  }

  HashMapI materials;
  HashMapI lights;
  HashMapI cameras;
  HashMapI texpaths;
  std::vector<std::string> matnames;

  std::vector<Camera> m_cameras;

  Matrix4x4f globalTransformMatrix;

  std::string scenefile;
  std::string scenefolder;
};

void ImportSceneFromCollada(IGraphicsEngine* pRender,
                            const std::string fileName,
                            Camera* camera, const Matrix4x4f& a_mat,
                            const std::string a_profilePath = "");

HydraScene* LastImportedScene();

const char* GetText(TiXmlNode*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*, const char*);
const char* GetText(TiXmlNode*, const char*, const char*, const char*, const char*);

TiXmlNode* GetNode(TiXmlNode*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*, const char*);
TiXmlNode* GetNode(TiXmlNode*, const char*, const char*, const char*, const char*);


Matrix4x4f GetTransformFromNode(TiXmlNode*);


///////////////////////////////////////////////
///////////////////////////////////////////////

namespace NumericParser
{

//protected:
  typedef long long int uint64_t;

  inline static uint64_t mystrtol(const char *&a_str, uint64_t val = 0 )
  {
    for ( char c; ( c = *a_str ^ '0' ) <= 9; ++ a_str ) val = val * 10 + c;
    return val;
  }

  inline static float mystrtof(const char *&a_str )
  {
    static float const exp_table[] = { 1e38, 1e37, 1e36, 1e35, 1e34, 1e33, 1e32, 1e31, 1e30, 1e29, 1e28, 1e27, 1e26, 1e25, 1e24, 1e23, 1e22, 1e21,
      1e20, 1e19, 1e18, 1e17, 1e16, 1e15, 1e14, 1e13, 1e12, 1e11, 1e10, 1e9, 1e8, 1e7, 1e6, 1e5, 1e4, 1e3, 1e2, 10,
      1, 0.1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10, 1e-11, 1e-12, 1e-13, 1e-14, 1e-15, 1e-16, 1e-17,
      1e-18, 1e-19, 1e-20, 1e-21, 1e-22, 1e-23, 1e-24, 1e-25, 1e-26, 1e-27, 1e-28, 1e-29, 1e-30, 1e-31, 1e-32, 1e-33,
      1e-34, 1e-35, 1e-36, 1e-37, 1e-38};

    static float const *exp_lookup = &exp_table[38];

    // read sign
    //
    float sign = 1.0f;
    if(*a_str == '-')
    {
      sign = -1.0f;
      a_str++;
    }

    // read integer part
    //
    uint64_t val = mystrtol( a_str ); // read integer part
    int neg_exp = 0;
    if ( *a_str == '.' )              // read fractional part
    {
      char const *fracs = ++ a_str;
      val = mystrtol( a_str, val );
      neg_exp = int(a_str - fracs);
    }

    if ( ( *a_str | ('E'^'e') ) == 'e' ) // read exp if number has it
    {
      neg_exp += int( (*(++a_str)) == '-'? mystrtol( ++ a_str ) : - mystrtol( ++ a_str ) );
    }

    if(neg_exp < -38) neg_exp = -38;
    if(neg_exp > 38)  neg_exp = 38;

    return float(val)*exp_lookup[neg_exp]*sign;
  }

//public:

  inline static float NextFloat(const char*& a_str)
  {
    float result = mystrtof(a_str);
    while(*a_str == ' ' || *a_str == '\n' || *a_str == '\t') a_str++;
    return result;
  }

  inline static int NextInt(const char*& a_str)
  {
    int sign = 1;
    if(*a_str == '-')
    {
      sign = -1;
      a_str++;
    }

    int result = int(mystrtol(a_str));
    if(*a_str == '0') a_str++;
    while(*a_str == ' ' || *a_str == '\n' || *a_str == '\t') a_str++;
    return result*sign;
  }

  //////////////////////////////////////////////////////////////////////////////////////////////////////
  ////
  template<class T>
  void ExtractArrayFromString(const char* strValue, vector<T>* pResult, int a_size)
  {
    std::istringstream stream(strValue);
    T data;

    while(!stream.eof())
    {
      stream >> data;
      pResult->push_back(data);
    }
  }

  template<class T>
  void ExtractArrayFromString(const char* strValue, vector<T>* pResult) { ExtractArrayFromString<T>(strValue, pResult, -1); }

  template<> void ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult, int a_size);
  template<> void ExtractArrayFromString<int>(const char* in_str, vector<int>* pResult);

  template<> void ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult);
  template<> void ExtractArrayFromString<float>(const char* in_str, vector<float>* pResult, int a_size);
};


namespace STR_CNV
{

  template <class T> T StringTo(const std::string& str); // { return T(str); }


  template <> float StringTo<float>(const std::string& str);
  template <> int StringTo<int>(const std::string& str);
  template <> float2 StringTo<float2>(const std::string& str);
  template <> float3 StringTo<float3>(const std::string& str);
  template <> float4 StringTo<float4>(const std::string& str);
  template <> Matrix4x4f StringTo<Matrix4x4f>(const std::string& str);



  static std::string ToLowerCase(const std::string& a_str)
  {
    std::string str = a_str;
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
  }

  static void TransformToLowerCase(std::string& key)
  {
    std::transform(key.begin(), key.end(), key.begin(), ::tolower);
  }

};

std::string MatrixToString(const Matrix4x4f& m);


// ����� ������ ����� ��� ������������� ��������� ������������ ����������, ������� ����������, ���������� �.�.�.
// ������ ��� ����� ����� ������� ����� ��� ������� - ���������, ��������� � ���������.
//
#include "ColladaImport.h"

class IHydraMaterialImportProfile
{
public:

  typedef HashMapS ObjectParameters;

  virtual void Transform(ObjectParameters& a_data) = 0;

};

class ColladaMaterialImportProfile : public IHydraMaterialImportProfile
{
public:

  ColladaMaterialImportProfile(TiXmlElement* a_node);

  void Transform(ObjectParameters& a_data);

protected:

  TiXmlElement* m_pProfileNode;

};



struct InstList;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


class ColladaParser
{

public:

   ColladaParser();
   ~ColladaParser();

   typedef HashMapS           ObjectData;
   typedef HashMapOfHashMapS  ObjectDataList;

   bool LoadXML(const std::string& a_fileName);

   void ImportLights(ObjectDataList* pOut_list);
   void ImportMaterials(ObjectDataList* pOut_list);
   void ImportTextures(ObjectDataList* pOut_list);  // no needs in using it directly it will be called from ImportMaterials, but you still can
   void ImportCameras(ObjectDataList* pOut_list);
   void ImportGeometry(ObjectDataList* pOut_list, HashMapFV *geom, HashMapIV *geom_order, InstList *geometryAttribs);

   Matrix4x4f GetTransformMatrix(){return m_globalTransform;}

   const std::string& GetLastParsedXML() const {return m_lastXMLPath;}

   //
   //
   static void ParseHydraMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialHydraNode);
   static void ParseHydraLight(TiXmlNode* node, ObjectData* p);

   static TiXmlElement* FindNodeByName(TiXmlElement* pEffectsLib, const std::string& materialName);
   static TiXmlElement* FindElemByAttribute(TiXmlElement* a_node, const std::string& a_nodeName, const std::string& a_attributeName, const std::string& a_attributeValue);

   static std::string CutOffColladaEffectsShit(const std::string& a_name);

   //
   //
   void ParseStandartMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData);
   void ParseExtraMaterialData(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData);

   TiXmlElement* LoadXMLAndGetFirstElement(const std::string& a_profilePath, const std::string& a_str);

   TiXmlElement* GetElement(const std::string& a_name);
   TiXmlElement* GetRoot() {return m_root;}

   IHydraMaterialImportProfile* m_pHydraMatProfile;


protected:

   std::string FindTexturePath(const ObjectDataList& list, const std::string& key, const std::string& val, const std::string& second_val) const;
   std::string FindTargetTransform(TiXmlNode* pObjectsTransform, TiXmlNode* nextNode);
   void InstanceLightObjects(TiXmlNode* pNode, ObjectDataList& plist, ObjectDataList& plist2);

   void ProcessGeometryElement(ObjectDataList::iterator p, HashMapFV& geometry, HashMapIV& geometry_order, vector<int>& tmpArr,TiXmlElement* pGeometryElement, string geometryId);

   void CreateExporterProfiles(TiXmlNode* root);

   TiXmlDocument m_doc;
   TiXmlElement* m_root;
   Matrix4x4f m_globalTransform;

   ObjectDataList m_materialsRemembered;
   std::string m_lastXMLPath;
   ObjectData m_defferedErrorMesasages;

public:
   //
   //
   class IExportTool
   {
   public:

     virtual std::string GetGeometryMaterialRef(TiXmlNode* nextTri);
     virtual std::string FindIndicesArrayKey(HashMapIV& a_map, const std::string& a_name);
   };

   class MaxStandartExporter : public IExportTool
   {
      std::string FindIndicesArrayKey(HashMapIV& a_map, const std::string& a_name);
   };

   class OpenColladaExporter : public IExportTool
   {

   };


   class BlenderExporter : public IExportTool
   {
      std::string GetGeometryMaterialRef(TiXmlNode* nextTri);
   };

   IExportTool* m_pExporterSpecific;

};



struct InstList
{
  vector<string>     mesh_ids;
  vector<Matrix4x4f> matrices;
};


class GeometryStorage
{
public:

  GeometryStorage(ColladaParser::IExportTool* a_pExporter) { m_pExporter = a_pExporter;}

  void ImportModelToRender(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& m_transform, HashMapS& a_defferedErrors);

  HashMapFV geom_data;
  HashMapIV geom_indices;
  HashMapI  mat_indices;

protected:

  std::string FindIndicesArrayKey(const std::string& key);

  ColladaParser::IExportTool* m_pExporter;
};



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
class EmptyDataConverter
{
public:
  virtual void ConvertData(void* data, int w, int h) {}
};

class BumpMapConverter : public EmptyDataConverter
{
public:
  BumpMapConverter(bool flags[4]) {for(int i=0;i<4;i++) m_convertFlags[i] = flags[i];}
  void ConvertData(void* data, int w, int h);

protected:
  bool m_convertFlags[4];
};


class AlphaFromRedChannel : public EmptyDataConverter
{
public:
  AlphaFromRedChannel(){}
  void ConvertData(void* data, int w, int h);

protected:

};


//////////////////////////////////////////////////////////////////////////////////////////////////////
////

class ITextureImporter
{
public:

  ITextureImporter() : m_ptps(NULL) {}
  virtual ~ITextureImporter(){}

  virtual int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false, bool displacement = false) = 0;
  virtual void SetCurrentPathToMainFile(const std::string& path) = 0;
  virtual void ResetCurrentPath() = 0;

  virtual int  GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex) {return INVALID_TEXTURE;}

  virtual HashMapI& GetCache() {return m_cache;}

  virtual void SetTexPathStorage(HashMapI* a_ptr) { m_ptps = a_ptr; }

protected:

  virtual int  CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex) {return INVALID_TEXTURE;}

  virtual std::string GetAbsolutePath(const std::string& path) {return "";}
  virtual bool HeightFileHasChanged(const std::string& heightPath, const std::string& heightPath2);

  HashMapI m_cache;
  HashMapI m_bumpCache;
  HashMapI* m_ptps; // pTexPathsStotage
};


class DummyTextureImporter : public ITextureImporter
{
public:

  DummyTextureImporter(){}
  ~DummyTextureImporter(){}

  int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false, bool displacement = false) {return INVALID_TEXTURE;}
  void SetCurrentPathToMainFile(const std::string& path) {}
  void ResetCurrentPath() {}
  int  GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex) {return INVALID_TEXTURE;}

  HashMapI& GetCache() {return m_cache;}

protected:

  HashMapI m_cache;

};

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
class ColladaTextureImporter : public ITextureImporter
{
public:
  ColladaTextureImporter();
  ~ColladaTextureImporter();


  int  AddTextureIfExists(const std::string& path, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL, bool muteWarning = false, bool displacement = false);
  void SetCurrentPathToMainFile(const std::string& path);
  void ResetCurrentPath();

  virtual int GetNormalMapFromFisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex);

protected:

  int  CalculateNormalMapFromDisplacement(int heightTexId, IGraphicsEngine* pRender, const std::string& pathToHeightTex);

  ColladaTextureImporter(const ColladaTextureImporter& rhs){}
  ColladaTextureImporter& operator=(const ColladaTextureImporter& rhs) {return* this;}

  std::string GetPathToFolder(const std::string& pathToFile);
  std::string GetAbsolutePath(const std::string& path);

  std::string m_pathToXML;
  std::string m_pathToXMLFolder;
  std::string m_oldPath;
  int m_chdirResult;
  bool m_pathWasChanged;

  HashMapI m_normalMapCache;
};



//////////////////////////////////////////////////////////////////////////////////////////////////////
////

inline static float3 GetFloat3(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<float3>(a_param->second[a_name] );
  else
    return float3(0,0,0);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////

inline static float GetFloat(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  if(a_param->second[a_name] != "")
    return STR_CNV::StringTo<float>(a_param->second[a_name] );
  else
    return 0.0f;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
static std::string GetString(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  return a_param->second[a_name];
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
static int GetBRDFType(ColladaParser::ObjectDataList::iterator a_param, const std::string& a_name)
{
  std::string brdfType = a_param->second[a_name];
  int BRDF_id;
  if(brdfType == "phong")
    BRDF_id = RAYTR::HydraMaterial::BRDF_PHONG;
  else if (brdfType=="blinn")
    BRDF_id = RAYTR::HydraMaterial::BRDF_BLINN;
  else if (brdfType=="cook-torrance")
    BRDF_id = RAYTR::HydraMaterial::BRDF_COOK_TORRANCE;
  else if (brdfType=="fresnel_dielectric" || brdfType=="fresnel" || brdfType=="dielectric")
    BRDF_id = RAYTR::HydraMaterial::BRDF_FRESNEL_DIELECTRIC;
  else if(brdfType=="fresnel_conductor" || brdfType=="conductor")
    BRDF_id = RAYTR::HydraMaterial::BRDF_FRESNEL_CONDUCTOR;
  else
    BRDF_id = RAYTR::HydraMaterial::BRDF_PHONG;

  return BRDF_id;
}


// TODO: - create correct function
static float VRayGlosinessToCosinePower(float glosiness)
{
  return  1.0f/fmaxf(1e-6f,(1.0f - pow(glosiness, 0.001f)));
}




class IGeometryImporter
{
public:

  virtual void ImportGeometry(IGraphicsEngine* pRender, const Matrix4x4f& a_globalTransform);

};

class ColladaGeometryImporter : public IGeometryImporter
{
public:
  ColladaGeometryImporter(ColladaParser* a_parser) {m_pColladaParser = a_parser;}

protected:

  ColladaParser* m_pColladaParser;


};


class IMaterialImporter
{
public:
  IMaterialImporter(){}
  virtual ~IMaterialImporter(){}

  virtual float3 GetTransparency(ColladaParser::ObjectData& params) {return float3(0,0,0);}

protected:


};

class OpenColladaMaterialImporter : public IMaterialImporter
{
public:

  OpenColladaMaterialImporter(){}
  ~OpenColladaMaterialImporter(){}

  float3 GetTransparency(ColladaParser::ObjectData& params);

protected:

};



IMaterialImporter* CreateMaterialImporter(TiXmlNode* a_xmlRoot);


void ImportLightsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_lights,
                             const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter, HashMapI& a_lightsIds);

void ImportHydraMaterialsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_materials,
                                     GeometryStorage& a_geomStorage, ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter, HashMapI& a_matIds);

void ImportCamerasFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_cameras,
                              Camera* camera, const Matrix4x4f& a_mat, HashMapI& a_camIds, std::vector<Camera>& a_outCameras);


void ImportGeometryFromCollada(IGraphicsEngine* pRender,
                               ColladaParser::ObjectDataList& a_geometry,
                               GeometryStorage& geomStorage, const Matrix4x4f& a_mTransform,
                               InstList& geometryAttribs);

void ReplaceMaterialsWithProfile(ColladaParser::ObjectDataList& a_materialsList, TiXmlElement* a_mat_lib);
void ReplaceLightsWithProfile(ColladaParser::ObjectDataList& a_lightsList, TiXmlElement* lib);
void ReplaceCamerasWithProfile(ColladaParser::ObjectDataList& a_camList, TiXmlElement* lib);

void ReplaceMaterialsWithAliases(IGraphicsEngine* pRender, ITextureImporter* pTexImporter, ColladaParser::ObjectDataList& a_materials, TiXmlElement* alias_lib);




HydraMaterial HydraMaterialFromStringMap(ColladaParser::ObjectDataList::iterator p, IGraphicsEngine* pRender, ITextureImporter* pTexImporter, HashMapImportParams* pImportData);
RAYTR::Light  HydraLightFromStringMap(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter);

void SaveImageToFile(const std::string& a_fileName, int w, int h, unsigned int* data);
void SaveHDRImageToFile(const std::string& a_fileName, int w, int h, float4* data);

int LoadTextureToRender(const std::string& a_fileName, IGraphicsEngine* pRender, EmptyDataConverter* pConverter = NULL);


void CreateDefaultHydraProfile(const std::string& a_profilePath);


HydraMaterial ReadSingleHydraMaterialFromXMLNode(TiXmlElement* matElem, TiXmlElement* aliases_mat, 
                                                 IGraphicsEngine* pRender, ITextureImporter* pTexInporter, std::string& a_outName, HashMapImportParams* pPapams);

RAYTR::Light SingleHydraLightFromXMLNode(TiXmlElement* lightElem, IGraphicsEngine* pRender, ITextureImporter* pTexImporter, 
                                         const Matrix4x4f a_globalTransform, std::string& a_outName);
