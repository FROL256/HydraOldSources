#include "StrToken.h"
#include <string.h>

StrTokenizer::StrTokenizer() : m_str( NULL ), m_outToken( NULL ), m_maxLen( 0 ) {}

///////////////////////////////////////////////////////////////////////////////////
////
StrTokenizer::StrTokenizer
(
 const char *str,    ///< String to be parsed.
 char *outToken,     ///< Place to store the result.
 size_t maxLen       ///< Maximum lenght of @a outToken.
 )
 : m_str( str ), m_outToken( outToken ), m_maxLen( maxLen )
{
}

///////////////////////////////////////////////////////////////////////////////////
////
StrTokenizer::~StrTokenizer(){}

///////////////////////////////////////////////////////////////////////////////////
////
void StrTokenizer::Init
(
 const char *str,    ///< String to be parsed.
 char *outToken,     ///< Place to store the result.
 size_t maxLen       ///< Maximum lenght of @a outToken.
 )
{
  m_str       = str;
  m_outToken  = outToken;
  m_maxLen    = maxLen;

} 

/////////////////////////////////////////////////////////////////////////////////
char *StrTokenizer::NextToken(const char *delim)
{
  // Skip over delimiter characters

  while (( *m_str != '\0' ) && ( strchr( delim, *m_str ) != NULL ))
    m_str++;

  if ( *m_str == '\0' )
    return NULL;    // We've run out of data - no more tokens

  // Copy characters until we fill up the token, we run out, or hit a
  // delimiter.

  size_t i;

  for ( i = 0; i < ( m_maxLen - 1 ); i++ )
  {
    if ( *m_str == '\0' )
      break;
    
    if ( strchr( delim, *m_str ) == NULL )
      m_outToken[ i ] = *m_str++;
    else
    {
      // Delimiter found
      m_str++;
      break;
    }
  }
  m_outToken[ i ] = '\0';

  return m_outToken;
}

