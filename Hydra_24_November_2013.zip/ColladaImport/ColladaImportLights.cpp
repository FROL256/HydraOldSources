#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseHydraLight(TiXmlNode* node, ObjectData* p)
{
  ObjectData& params = *p;

  std::string name;

  if(node->ToElement()->Attribute("id") != NULL)
    name = node->ToElement()->Attribute("id");
  else if(node->ToElement()->Attribute("name") != NULL)
    name = node->ToElement()->Attribute("name");
  else
    RUN_TIME_ERROR("Light was declared without name");


  if(name.size() > 4 && name.substr(name.size() - 4, name.size()) == "-lib") // cut off "-lib"
    name = name.substr(0, name.size() - 4);
 
  params["name"]      = name;
  params["matrix"]    = MatrixToString(GetTransformFromNode(node)); 
  params["light_type"]= GetText(node, "general", "type");
  params["general_ignore_transform"] = GetText(node, "general", "ignore_transform");
  params["general_disable"] = GetText(node,"general","disable");
  params["general_disable_phmap"] = GetText(node,"general","disable_for_photonmap");
  params["general_sun_angle_size"] = GetText(node,"general","sun_angle_size"); //

  params["color"]     = GetText(node, "intensity", "color");
  params["intensity"] = GetText(node, "intensity", "multiplier");
  params["size_x"]    = GetText(node, "size", "Half-length");
  params["size_y"]    = GetText(node, "size", "Half-width");
  params["sphere_radius"] = GetText(node, "size", "radius");

  params["multiplier"] = GetText(node, "intensity", "reflect_multiplier");

  params["cube_positive_x"] = GetText(node, "cubemap", "surface_positive_x");
  params["cube_negative_x"] = GetText(node, "cubemap", "surface_negative_x");

  params["cube_positive_y"] = GetText(node, "cubemap", "surface_positive_y");
  params["cube_negative_y"] = GetText(node, "cubemap", "surface_negative_y");

  params["cube_positive_z"] = GetText(node, "cubemap", "surface_positive_z");
  params["cube_negative_z"] = GetText(node, "cubemap", "surface_negative_z");

  params["spheremap"] = GetText(node, "spheremap", "surface");

  for(TiXmlNode* pParam = node->FirstChild(); pParam != 0; pParam = node->IterateChildren(pParam))
  {
    TiXmlElement* pElem   = pParam->ToElement();
    if(pElem != NULL && pElem->GetText() != NULL)
      params[pElem->ValueStr()] = pElem->GetText();
  }
} 


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaParser::FindTargetTransform(TiXmlNode* pObjectsTransform, TiXmlNode* nextNode)
{
  if(nextNode == NULL)
    return "";

  const char* lightNodeName = nextNode->ToElement()->Attribute("id");
  if(lightNodeName == NULL)
    return "";

  // transform for light or camera target
  //
  TiXmlElement* pLightTarget = FindElemByAttribute(pObjectsTransform->ToElement(), "node", "id", std::string(lightNodeName) + ".Target");
  if(pLightTarget != NULL)
  {
    Matrix4x4f m = GetTransformFromNode(pLightTarget);
    return MatrixToString(m);
  }

  return std::string("");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::InstanceLightObjects(TiXmlNode* pObjectsTransform, ObjectDataList& plist, ObjectDataList& plist2)
{
  if(pObjectsTransform!=0)
  {
    for(TiXmlNode* nextNode = pObjectsTransform->FirstChild("node"); nextNode!=0; nextNode = pObjectsTransform->IterateChildren("node", nextNode))
    {
      const char* lightNodeId = nextNode->ToElement()->Attribute("id");
      if(lightNodeId==0)
        continue;

      string objectName = ToLowerCase(lightNodeId);

      if(objectName.substr(0,9) == "vraylight" || objectName.substr(0,9) == "arealight" || objectName.substr(0,10) == "hydralight")
      {
        ObjectData lightParams;
        ParseHydraLight(nextNode, &lightParams);
        plist2[lightNodeId] = lightParams;
      }

      std::string lightUrl;

      TiXmlElement* pLightInst = nextNode->FirstChildElement("instance_light");
      if(pLightInst!=NULL)
      {
        lightUrl = pLightInst->Attribute("url");
        if(lightUrl[0] == '#')
          lightUrl = lightUrl.substr(1, lightUrl.size()-1);
        lightNodeId = lightUrl.c_str();
      }

      // all hydra custom transformations will be replaced by collada transforms
      // search through the input object list
      //
      ObjectDataList::iterator p;
      for(p=plist.begin();p!=plist.end();++p)
      {
        if(p->second["name"] == lightNodeId) // light placed directly in the transfrom node ?
        {
          Matrix4x4f m = GetTransformFromNode(nextNode);
          p->second["matrix"] = MatrixToString(m);
          p->second["target_matrix"] = FindTargetTransform(pObjectsTransform, nextNode);
          plist2[lightNodeId] = p->second;
        }
        else if(p->second.find("id") != p->second.end()) // light placed where it should be
        {
          // transform for light pos
          //
          string lighName = ToLowerCase( (p->second["id"]).substr(0, objectName.size()) );
          if(lighName == objectName)
          {
            Matrix4x4f m = GetTransformFromNode(nextNode);
            p->second["matrix"] = MatrixToString(m);
            p->second["target_matrix"] = FindTargetTransform(pObjectsTransform, nextNode);
            plist2[lightNodeId] = p->second;
          }
        }
      }
    
      TiXmlElement* pInnerNode = nextNode->FirstChildElement("node");
      if(pInnerNode!=NULL)
        InstanceLightObjects(nextNode, plist, plist2); 
    }
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportLights(ObjectDataList* pOut_list)
{
  ObjectDataList& plist = *pOut_list;
  plist.clear();

  TiXmlElement* lights_lib = m_root->FirstChildElement("library_lights");
  if(lights_lib)
  {
    TiXmlNode* nextLightInLib = 0;
    for(TiXmlNode* nextLightInLib = lights_lib->FirstChild("light"); nextLightInLib!=0; nextLightInLib = lights_lib->IterateChildren("light", nextLightInLib))
    {
      ObjectData lightParams; 
      
      std::string name = nextLightInLib->ToElement()->Attribute("id"); 

      if(name.size() > 4 && name.substr(name.size() - 4, name.size()) == "-lib") // cut off "-lib"
        name = name.substr(0, name.size() - 4);

      lightParams["id"]   = name;  
      lightParams["name"] = name;  
      plist[name] = lightParams;
    }

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      //# virtual exporter type (!)
      string lightId = p->second["id"] + std::string("-lib");
      string light_url = p->second["id"].substr(1,p->second["id"].size() - 1);
      TiXmlElement* pLightElement = FindElemByAttribute(lights_lib, "light", "id", lightId);

      if(pLightElement == NULL) // may be without "-lib" suffix
      {
         lightId = p->second["id"];
         pLightElement = FindElemByAttribute(lights_lib, "light", "id", lightId);
      }

      if(pLightElement == NULL)
        RUN_TIME_ERROR("Light with id " + lightId + " not found in COLLADA XML");

      if(pLightElement->FirstChildElement("technique_common") == NULL )
      {
        ObjectData lightParams;
        ParseHydraLight(pLightElement, &lightParams);
        p->second = lightParams;
      }
      else
      {
        // get light type
        //
        TiXmlElement* pLightType = pLightElement->FirstChildElement("technique_common")->FirstChildElement();

        p->second["light_type"] = ToLowerCase(pLightType->ValueStr());

        for(TiXmlNode* pParam = pLightType->FirstChildElement();pParam != 0; pParam = pLightType->IterateChildren(pParam))
        {
          TiXmlElement* pElem = pParam->ToElement();
          p->second[pElem->ValueStr()] = pElem->GetText();
        }

        //const char* lightName = pLightElement->ToElement()->Attribute("id"); // for debug only

        // get additional parameters
        //
        TiXmlElement* pLightAdditionalParam = pLightElement->FirstChildElement("technique");
        if(pLightAdditionalParam != NULL)
        {  
          for(TiXmlNode* pParam = pLightAdditionalParam->FirstChildElement(); pParam != 0; pParam = pLightAdditionalParam->IterateChildren(pParam))
          {
            TiXmlElement* pElem = pParam->ToElement();
            p->second[pElem->ValueStr()] = pElem->GetText();
          }
        }

        // get extra params from OpenCollada
        //
        TiXmlNode* pExtra = GetNode(pLightElement, "extra", "technique", "max_light"); // use virtual functions here
        if(pExtra != NULL)
        { 
          for(TiXmlNode* pParam = pExtra->FirstChildElement(); pParam != 0; pParam = pExtra->IterateChildren(pParam))
          {
            TiXmlElement* pElem = pParam->ToElement();
            p->second[std::string("extra_light_") + pElem->ValueStr()] = pElem->GetText();
          }
        }


        TiXmlElement* pScenes = m_root->FirstChildElement("library_visual_scenes");
        TiXmlNode* nextScene = 0;
        for(TiXmlNode* nextScene = pScenes->FirstChild("visual_scene"); nextScene!=0; nextScene = pScenes->IterateChildren("visual_scene", nextScene))
        {
          TiXmlElement* pCurrScene = nextScene->ToElement();
          for(TiXmlNode* nextNode = pCurrScene->FirstChild("node"); nextNode!=0; nextNode = pCurrScene->IterateChildren("node", nextNode))
          {
            TiXmlElement* pLightNode = FindElemByAttribute(nextNode->ToElement(), "instance_light", "url", light_url);
            if(pLightNode !=0)
            {
              if (nextNode->FirstChildElement("matrix"))
                p->second["matrix"] = pLightNode->FirstChildElement("matrix")->GetText();

              if (nextNode->FirstChildElement("translate"))
                p->second["translate"] = pLightNode->FirstChildElement("translate")->GetText();
            }

          }
        }

      } // else

    } //  for(p=plist.begin();p!=plist.end();++p)

  }

  // get transformations out
  //
  ObjectDataList plistResult;

  TiXmlNode* pObjectsTransform = GetNode(m_root, "library_visual_scenes", "visual_scene");
  if(pObjectsTransform!=0)
    InstanceLightObjects(pObjectsTransform, plist, plistResult);

  // copy instanced lights back to plist
  //
  plist = plistResult;

}



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ReplaceLightsWithProfile(ColladaParser::ObjectDataList& a_lightsList, TiXmlElement* lib)
{
  if(lib == NULL)
    return;

  for(TiXmlNode* nextLight = lib->FirstChild("light"); nextLight!=0; nextLight = lib->IterateChildren("light", nextLight))
  {
    TiXmlElement* lightElem = nextLight->ToElement();
    std::string name =  "";

    if(lightElem->Attribute("id") != NULL)
      name = lightElem->Attribute("id");
    else if(lightElem->Attribute("name") != NULL)
      name = lightElem->Attribute("name");

    if(a_lightsList.find(name) == a_lightsList.end()) // even if we hav no light with this name we can add the light
      fprintf(stderr, "Warning: model don't have light called '%s' \n", name.c_str());

    ColladaParser::ObjectData params;
    ColladaParser::ParseHydraLight(nextLight, &params);    

    a_lightsList[name] = params;
  }

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
RAYTR::Light HydraLightFromStringMap(IGraphicsEngine* pRender, ColladaParser::ObjectDataList::iterator p, const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter)
{
  RAYTR::Light light;

  light.intensity = 1.0f;
  light.color  = float3(1,1,1);
  light.pos    = float3(0,0,0);
  light.m_norm = float3(0,-1,0);
  light.kc  = 1;
  light.kl  = 0;
  light.kq  = 0;


  float scale = MGML_MATH::MAX(a_mTransform.M[0][0], a_mTransform.M[1][1], a_mTransform.M[2][2]);

  //if(scale < 1e-5f)
    //scale = 1.0f;

  if(p->second["constant_attenuation"] != "")
    light.kc = GetFloat(p,"constant_attenuation");

  if(p->second["linear_attenuation"] != "")
    light.kl = GetFloat(p,"linear_attenuation");

  if(p->second["quadratic_attenuation"] != "")
    light.kq = GetFloat(p, "quadratic_attenuation");

  if(p->second["intensity"] != "")
    light.intensity = GetFloat(p,"intensity");
  else if(p->second["extra_light_multiplier"] != "")
    light.intensity = GetFloat(p,"extra_light_multiplier");

  if(p->second["color"] != "")
    light.color = GetFloat3(p,"color");

  if(p->second["position"] != "")
    light.pos = GetFloat3(p,"position");

  light.SetActive(true);
  if(p->second["general_disable"] != "" && (GetFloat(p,"general_disable") > 0.0f))
  {
    std::cerr << "light was disabled" << std::endl;
    light.SetActive(false);
  }

  if(p->second["add_as_geometry"] == "" || GetFloat(p,"add_as_geometry") > 0.0f)
    light.flags |= RAYTR::Light::LIGHT_AS_GEOMETRY;

  if(p->second["general_disable_phmap"] != "" && GetFloat(p,"general_disable_phmap") > 0.0f)
    light.flags |= RAYTR::Light::LIGHT_DISABLE_FOR_PHOTONMAP;

  // always use only matrices
  //
  Matrix4x4f lightMatrix;
  Matrix4x4f lightTargetMatrix;

  bool applyTransform = true;
  if(p->second["general_ignore_transform"] == "yes" || p->second["general_ignore_transform"] == "1")
    applyTransform = false;

  if(applyTransform)
  {
    if(p->second["matrix"] != "")
      lightMatrix = a_mTransform*StringTo<Matrix4x4f>(p->second["matrix"]);

    if(p->second["target_matrix"] != "")
      lightTargetMatrix = a_mTransform*StringTo<Matrix4x4f>(p->second["target_matrix"]);
  
    float3 target = lightTargetMatrix*float3(0,0,0);
    light.pos = lightMatrix*light.pos; //float3(0,0,0);

    float3 norm = normalize(target - light.pos);
    light.m_norm = norm;

    Matrix4x4f mRot = lightMatrix; 
    mRot.SetCol(3, float4(0,0,0,1));
    light.SetMatrixRotation(mRot.L);
  }
  else
    scale = 1.0f;

  ////////////////////////////////////////////////////////////////////
  string lightType = ToLowerCase(p->second["light_type"]);

  if(lightType == "spot")
  {
    light.SetLighType(RAYTR::Light::LIGHT_TYPE_SPOT);

    light.m_spotCutoffAngleCos[0] = cos(3.141592654f/6.0f); // default
    light.m_spotCutoffAngleCos[1] = cos(3.141592654f/4.0f); // (PI/2)*2 
    light.m_spotExponent[0] = 2.0f;
    light.m_spotExponent[1] = 1.0f;

    float angle1 = 45.0;
    if(p->second["falloff_angle"] != "")
    {
      angle1 = StringTo<float>(p->second["falloff_angle"]);
      light.m_spotCutoffAngleCos[1] = cos(0.5f*MGML_MATH::DEG_TO_RAD(angle1));

      if(p->second["falloff_angle2"] != "")
      {
        float angle2 = StringTo<float>(p->second["falloff_angle2"]);
        light.m_spotCutoffAngleCos[0] = cos(0.5f*MGML_MATH::DEG_TO_RAD(angle2));
      }
      else 
        light.m_spotCutoffAngleCos[0] = cos(0.5f*MGML_MATH::DEG_TO_RAD(angle1*0.75));

      if(p->second["falloff_exponent"] != "")
        light.m_spotExponent[1] = StringTo<float>(p->second["falloff_exponent"]);

      if(p->second["falloff_exponent2"] != "")
        light.m_spotExponent[0] = StringTo<float>(p->second["falloff_exponent2"]);

      if(p->second["direction"] != "")
        light.m_norm = GetFloat3(p,"direction");
    }

    if(p->second["sphere_radius"] != "")
    {
      float radius = GetFloat(p, "sphere_radius");
      light.SetSphericalLightRadius(radius*scale);
    }
  }
  else if (lightType== "point")
  {
    light.SetLighType(RAYTR::Light::LIGHT_TYPE_POINT);
  }
  else if(lightType == "plane" || lightType== "flat" || lightType== "area")
  {
    light.SetLighType(RAYTR::Light::LIGHT_TYPE_AREA);
   
    float size_x = 1, size_y = 1;

    if(p->second["size_x"] != "")
      size_x = StringTo<float>(p->second["size_x"]);

    if(p->second["size_y"] != "")
      size_y = StringTo<float>(p->second["size_y"]);

    if(p->second["falloff_exponent"] != "")
      light.m_spotExponent[0] = StringTo<float>(p->second["falloff_exponent"]);
    else
      light.m_spotExponent[0] = 1.0f;

    //this usually happends when profile was exported from the Hydra itself
    //
    if(p->second["matrix_rot"] != "")
    {
      stringstream strstr(p->second["matrix_rot"]);

      strstr >> light.L[0] >> light.L[1] >> light.L[2];
      strstr >> light.L[3] >> light.L[4] >> light.L[5];
      strstr >> light.L[6] >> light.L[7] >> light.L[8];
    }

    light.SetAreaLightSize(size_x, size_y);
  }
  else if(lightType == "directional")
  {
    light.SetLighType(RAYTR::Light::LIGHT_TYPE_DIRECTIONAL);

    if(p->second["direction"] != "")
    {
      light.m_norm = (-1)*normalize(GetFloat3(p, "direction"));
      light.pos = 1.0f*10000.0f*light.m_norm;
    }

    if(p->second["general_sun_angle_size"] != "")
    {
      float angle = GetFloat(p, "general_sun_angle_size");
      float angleCos = cos( MGML_MATH::DEG_TO_RAD(angle) );
      light.SetSunAngleCos(angleCos);
    }

  }
  else if(lightType == "sphere")
  {
    light.SetLighType(RAYTR::Light::LIGHT_TYPE_SPHERICAL);

    float radius = GetFloat(p, "sphere_radius");
    light.SetSphericalLightRadius(radius*scale);
  }
  else if(lightType == "sky" || lightType == "env" || lightType == "environment")
  {
    light.SetLighType(RAYTR::Light::LIGHT_TYPE_SKY);
    light.pos.set(0,10000,0);
    light.kc  = 1;
    light.kl  = 0;
    light.kq  = 0;

    float AORayLength = 1e38f;

    if(p->second["ao_ray_length"] != "" && GetFloat(p,"ao_ray_length") > 0.0f)
      AORayLength = GetFloat(p, "ao_ray_length")*scale;

    if(p->second["ao_trace"] == "" || GetFloat(p,"ao_trace") > 0.0f)
      light.SetActive(true);
    else
      light.SetActive(false);

    light.SetAORayLength(AORayLength);

    for(int i=0;i<6;i++)
      light.texCudeIndices[i] = INVALID_TEXTURE;
    
    if(p->second["cube_positive_x"] != "")
    { 
      light.texCudeIndices[0] = pTexImporter->AddTextureIfExists(p->second["cube_positive_x"], pRender);
      light.texCudeIndices[1] = pTexImporter->AddTextureIfExists(p->second["cube_negative_x"], pRender);
      light.texCudeIndices[2] = pTexImporter->AddTextureIfExists(p->second["cube_positive_y"], pRender);
      light.texCudeIndices[3] = pTexImporter->AddTextureIfExists(p->second["cube_negative_y"], pRender);
      light.texCudeIndices[4] = pTexImporter->AddTextureIfExists(p->second["cube_positive_z"], pRender);
      light.texCudeIndices[5] = pTexImporter->AddTextureIfExists(p->second["cube_negative_z"], pRender);
    }
    else if(p->second["spheremap"] != "")
    {
      light.sphTexIndex = pTexImporter->AddTextureIfExists(p->second["spheremap"], pRender);
    }  
  } 

  //else if(lightType == "mesh")
  //{
  //
  //}
  

  if(lightType == "plane" || lightType== "flat" || lightType== "area" || (lightType == "spot" && p->second["look_at"] != "")) 
  {
    // does it works?
    if(p->second["look_at"] != "")
    {
      light.m_norm = (normalize(GetFloat3(p, "look_at") - light.pos));

      Matrix4x4f oldMat, rotMat;
      light.GetMatrixRotation(oldMat.L);

      float3 default_norm = make_float3(0,-1,0);
      float3 v = cross(light.m_norm, default_norm);

      float theta = dot(light.m_norm, default_norm); 

      float cos_t = cos(theta);
      float sin_t = sin(theta);

      rotMat.M[0][0] = (1.0f-cos_t)*v.x*v.x + cos_t;
      rotMat.M[0][1] = (1.0f-cos_t)*v.x*v.y - sin_t*v.z;
      rotMat.M[0][2] = (1.0f-cos_t)*v.x*v.z + sin_t*v.y;

      rotMat.M[1][0] = (1.0f-cos_t)*v.y*v.x + sin_t*v.z;
      rotMat.M[1][1] = (1.0f-cos_t)*v.y*v.y + cos_t;
      rotMat.M[1][2] = (1.0f-cos_t)*v.y*v.z - sin_t*v.x;

      rotMat.M[2][0] = (1.0f-cos_t)*v.x*v.z - sin_t*v.y;
      rotMat.M[2][1] = (1.0f-cos_t)*v.z*v.y + sin_t*v.x;
      rotMat.M[2][2] = (1.0f-cos_t)*v.z*v.z + cos_t;

      Matrix4x4f resMat = rotMat*oldMat;
      light.SetMatrixRotation(resMat.L);
    }
    else
      light.m_norm = float3(0,-1,0);
  }

  if(p->second["fast_shading"] == "" || GetFloat(p, "fast_shading") < 1.0f)
    light.flags |= RAYTR::Light::LIGHT_COMPUTE_AREA_SHADING;

  float simpleShaing = GetFloat(p,"disable_env_map_for_shadows");
  if(simpleShaing > 0.0f)
    light.flags |= RAYTR::Light::LIGHT_ENV_USE_SIMPLE_COLOR;

  return light;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportLightsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_lights, const Matrix4x4f& a_mTransform, ITextureImporter* pTexImporter, HashMapI& a_lightsId)
{
  ColladaParser::ObjectDataList::iterator p;

  for (p=a_lights.begin(); p!=a_lights.end(); ++p)
  {
    RAYTR::Light light = HydraLightFromStringMap(pRender, p, a_mTransform, pTexImporter);
  
    string lightType = ToLowerCase(p->second["light_type"]);
    if (lightType != "ambient")
      a_lightsId[p->first] = pRender->AddLight(light);
  }

  if(pRender->GetLightNumber() == 0) // no lights in scene? Add one!
  {
    RAYTR::Light addedLight;
    addedLight.SetLighType(RAYTR::Light::LIGHT_TYPE_SKY);
    addedLight.pos.set(0,10000,0);
    addedLight.kc = 1;
    addedLight.kl = 0.0;
    addedLight.kq = 0.0;
    addedLight.intensity = 0.5f;
    addedLight.color.set(1.0f, 0.95f, 0.95f);
    addedLight.SetAORayLength(10000.0f);
    addedLight.sphTexIndex = INVALID_TEXTURE;
    pRender->AddLight(addedLight);
  }

}

