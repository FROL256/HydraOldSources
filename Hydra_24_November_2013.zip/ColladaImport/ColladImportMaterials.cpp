#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>
#include <string>
#include <direct.h>

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseHydraMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel)
{
  for(TiXmlNode* pParam = pMaterialModel->FirstChild(); pParam != 0; pParam = pMaterialModel->IterateChildren(pParam))
  {
    TiXmlElement* pElem = pParam->ToElement();
    if(pElem != NULL)
    {
      std::string firstPart = pElem->ValueStr();

      for(TiXmlNode* p = pElem->FirstChild(); p != NULL; p = pElem->IterateChildren(p))
      {
        TiXmlElement* elem = p->ToElement();
        if(elem != NULL)
          params[firstPart + "_" + p->ValueStr()] = elem->GetText();
      }
    }
  }

  params["shading_model"] = "hydra";
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseStandartMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData)
{
  for(TiXmlNode* pParam = pMaterialModel->FirstChild(); pParam != 0; pParam = pMaterialModel->IterateChildren(pParam))
  {
    TiXmlElement* pElem = pParam->ToElement();
    std::string paramName = pElem->ValueStr();

    // parsing for custom tag attributes
    //
    if(pElem->ValueStr() == "transparent")
    {
      if(pElem->Attribute("opaque") != NULL)
        params["opaque_type"] = pElem->Attribute("opaque");
      else
        params["opaque_type"] = "A_ONE";
    }

    // ��� �������� ����������� ��������
    //
    if(pElem->FirstChildElement()->ValueStr() == "texture")
    {
      //# virtual exporterType(!)
      TiXmlElement* pTextureElem = pMaterialModel->FirstChildElement(paramName)->FirstChildElement("texture");

      std::string colladaTexName = pTextureElem->Attribute("texture");
      std::string texturePath    = FindTexturePath(texturesData, "id", colladaTexName, "init_from");

      if(texturePath == "")
      {
        if(colladaTexName.size() > 8 && colladaTexName.substr(colladaTexName.size()-8, colladaTexName.size()) == "-sampler")
          colladaTexName = colladaTexName.substr(0, colladaTexName.size()-8);
        texturePath = FindTexturePath(texturesData, "id", colladaTexName, "init_from");
      }

      if(texturePath == "")
        std::cerr << "'init_from' param for texture with name " << colladaTexName << " was not found in textures param list" <<std::endl;

      params[paramName] = GetText(pMaterialModel, paramName.c_str(), "color");
      params[paramName+"_texture"]      = texturePath;
      params[paramName+"_texcoord_set"] = pTextureElem->Attribute("texcoord");
    }
    else
      params[paramName] = pElem->FirstChildElement()->GetText();
  }

  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if(pMaterialElement->FirstChildElement("profile_COMMON")->FirstChildElement("newparam") != 0)
  {
    TiXmlElement* profCommon = pMaterialElement->FirstChildElement("profile_COMMON");

    for(TiXmlNode* nextNewParam = profCommon->FirstChild("newparam"); nextNewParam != NULL; nextNewParam = profCommon->IterateChildren("newparam", nextNewParam))
    {

      TiXmlElement* pSurface = nextNewParam->FirstChildElement("surface");
      TiXmlElement* pNewParamElem = nextNewParam->ToElement();

      if(pSurface != 0)
      {
        params["surface_type"] = pSurface->Attribute("type");
        params["newparam_sur_id"] = pNewParamElem->Attribute("sid");

        for(TiXmlNode* pParam = pSurface->FirstChildElement(); pParam != 0; pParam = pSurface->IterateChildren(pParam))
        {
          TiXmlElement* pElem = pParam->ToElement();

          if(pElem->ValueStr() != "format_hint")
          {
            params[pElem->ValueStr()] = pElem->GetText();
          }

        }
      }

      TiXmlElement* pSampler2D = nextNewParam->FirstChildElement("sampler2D");

      if(pSampler2D != 0)
      {
        params["newparam_samp_id"] = pNewParamElem->Attribute("sid");
        for(TiXmlNode* pParam = pSampler2D->FirstChildElement(); pParam != 0; pParam = pSampler2D->IterateChildren(pParam))
        {
          TiXmlElement* pElem = pParam->ToElement();
          params[pElem->ValueStr()] = pElem->GetText();
        }
      }

    } // for

  }

  //TiXmlElement* extraData = pMaterialElement->FirstChildElement("profile_COMMON");


}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseExtraMaterialData(ColladaParser::ObjectData& params, TiXmlElement* pExtraMaterial, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData)
{
  TiXmlElement* pTechnique = pExtraMaterial->FirstChildElement("technique");
  if(pTechnique != NULL)
  {
    TiXmlElement* pBumpMap = pTechnique->FirstChildElement("bump");
    if(pBumpMap != NULL) //&& pBumpMap->Attribute("bumptype") == "HEIGHTFIELD"
    {
       TiXmlElement* pTexture = pBumpMap->FirstChildElement("texture");
       if(pTexture != NULL && pTexture->Attribute("texture") != NULL)
       {
         std::string colladaTexName = pTexture->Attribute("texture");
         std::string texturePath    = FindTexturePath(texturesData, "id", colladaTexName, "init_from");

         if(texturePath == "")
         {
           if(colladaTexName.size() > 8 && colladaTexName.substr(colladaTexName.size()-8, colladaTexName.size()) == "-sampler")
             colladaTexName = colladaTexName.substr(0, colladaTexName.size()-8);
           texturePath = FindTexturePath(texturesData, "id", colladaTexName, "init_from");
         }

         params["displacement_height_texture"] = texturePath;
         params["displacement_height"] = "0";
       }
    }
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaParser::CutOffColladaEffectsShit(const std::string& mat_name)
{
  int posZero = 0;

  if(mat_name.size() > 0 && mat_name[0] == '#')
    posZero = 1;

  if(mat_name.size() > 7 && mat_name.substr(mat_name.size()-7,mat_name.size()) == "-effect")
    return mat_name.substr(posZero, mat_name.size() - 8);
  else if(mat_name.size() > 3 && mat_name.substr(mat_name.size()-3, mat_name.size()) == "-fx")
    return mat_name.substr(posZero, mat_name.size() - 4);
  else
    return mat_name.substr(posZero, mat_name.size());
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::FindNodeByName(TiXmlElement* pEffectsLib, const std::string& materialName)
{
  TiXmlElement* pMaterialElement = FindElemByAttribute(pEffectsLib, "effect", "name", materialName);

  if(pMaterialElement == NULL)
    pMaterialElement = FindElemByAttribute(pEffectsLib, "effect", "id", materialName);

  if(pMaterialElement == NULL)
    pMaterialElement = FindElemByAttribute(pEffectsLib, "effect", "id", materialName+"-effect");

  return pMaterialElement;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportMaterials(ObjectDataList* pOut_list)
{
  ColladaParser::ObjectDataList texturesData;
  ImportTextures(&texturesData);

  ObjectDataList& plist = *pOut_list;
  plist.clear();

  TiXmlElement* materials_lib = m_root->FirstChildElement("library_materials");
  if(materials_lib)
  {
    TiXmlNode* nextMaterialInLib = NULL;

    // ������� ��� ����� ���������� �� ���� library_materials
    //
    for(TiXmlNode* nextMaterialInLib = materials_lib->FirstChild("material"); nextMaterialInLib!=0; nextMaterialInLib = materials_lib->IterateChildren("material", nextMaterialInLib))
    {
      ColladaParser::ObjectData materialParams;

      string urlName = nextMaterialInLib->FirstChild("instance_effect")->ToElement()->Attribute("url");
      string matName = CutOffColladaEffectsShit(urlName);

      materialParams["name"] = matName;
      plist[matName] = materialParams;
    }

    // and now import other material parameters from library_effects
    //
    TiXmlElement* pEffectsLib = m_root->FirstChildElement("library_effects");
    if(!pEffectsLib)
      throw std::runtime_error(" 'library_effects' not found in XML");

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      ColladaParser::ObjectData& params = p->second;
      string materialName = params["name"];

      //# virtual exporterType(!)
      TiXmlElement* pMaterialElement = FindNodeByName(pEffectsLib, materialName);
      if(pMaterialElement == NULL)
        RUN_TIME_ERROR("Material with name " + materialName + " not found in COLLADA XML");


      TiXmlElement* pTechnique = pMaterialElement->FirstChildElement("profile_COMMON")->FirstChildElement("technique");
      TiXmlElement* pMaterialModel = pTechnique->FirstChildElement();

      params["shading_model"] = pMaterialModel->ValueStr();

      if(params["shading_model"] == "hydra")
        ParseHydraMaterial(params, pMaterialModel);
      else
        ParseStandartMaterial(params, pMaterialModel, pMaterialElement, texturesData);

      TiXmlElement* pExtraMaterial = pTechnique->FirstChildElement("extra");

      if(pExtraMaterial!= NULL)
        ParseExtraMaterialData(params, pExtraMaterial, pMaterialElement, texturesData);

    }

  }

  // add default material for objects that hve no materials
  //
  ColladaParser::ObjectData defaultMat;

  defaultMat["shading_model"] = "phong";
  defaultMat["ambient"]       = "0.0 0.0 0.0";
  defaultMat["diffuse"]       = "0.5 0.5 0.5";
  defaultMat["specular"]      = "0.0 0.0 0.0";
  defaultMat["shininess"]     = "80.0";
  defaultMat["name"]          = "hydra_default_material";

  plist["hydra_default_material"] = defaultMat;


  // remember materials for the case
  //
  m_materialsRemembered = plist;

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ReplaceMaterialsWithProfile(ColladaParser::ObjectDataList& a_materialsList, TiXmlElement* materials_lib)
{
  if(materials_lib == NULL)
    return;

  for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
  {
    TiXmlElement* matElem = nextMat->ToElement();
    std::string name =  "";

    if(matElem->Attribute("id") != NULL)
      name = matElem->Attribute("id");
    else if(matElem->Attribute("name") != NULL)
      name = matElem->Attribute("name");

    if(a_materialsList.find(name) == a_materialsList.end())
    {
      fprintf(stderr, "Warning: model don't have material called %s \n", name.c_str());
      continue;
    }

    ColladaParser::ObjectData params;

    TiXmlElement* pMaterialModel = matElem->FirstChildElement();
    if(ToLowerCase(pMaterialModel->ValueStr()) == "hydra")
    {
      ColladaParser::ParseHydraMaterial(params, pMaterialModel);
      params["name"] = name; // IMPORTANT!!!

      a_materialsList[name] = params;
    }
    else
      fprintf(stderr, "Warning: Hydra profile has unknown material model %s \n", pMaterialModel->ValueStr().c_str());

  }

  // now make global fixes
  //
  IHydraMaterialImportProfile* pProfileFix = new ColladaMaterialImportProfile(materials_lib);

  ColladaParser::ObjectDataList::iterator p;

  for(p = a_materialsList.begin(); p!= a_materialsList.end(); ++p)
    pProfileFix->Transform(p->second);

  delete pProfileFix;


}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
IMaterialImporter* CreateMaterialImporter(TiXmlNode* a_xmlRoot)
{
  std::string importerName = GetText(a_xmlRoot, "asset", "contributor", "authoring_tool");

  if(importerName != "")
  {
    if(importerName.find("OpenCOLLADA") != std::string::npos)
      return new OpenColladaMaterialImporter;
  }

  return new IMaterialImporter;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
float3 OpenColladaMaterialImporter::GetTransparency(ColladaParser::ObjectData& params)
{
  float transparent_k = 0;
  if(params["transparency"]!="")
    transparent_k = 1.0f-StringTo<float>(params["transparency"]);

  float3 refr_color(1,1,1);
  if(params["transparent"]!="")
    refr_color = StringTo<float3>(params["transparent"]);

  return refr_color*transparent_k;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////

float3 StandartTextureMultiplyer(int texId, float3 oldValue)
{
  if(length(oldValue) < 1e-5f && texId!=INVALID_TEXTURE)
    return float3(1.0,1.0,1.0);
  else
    return oldValue;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
RAYTR::HydraMaterial StdColladaMaterialFromStringMap(ColladaParser::ObjectDataList::iterator p, IGraphicsEngine* pRender,
                                                     ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter)
{
  ColladaParser::ObjectData& params = p->second;

  std::string name = p->second["name"];

  HydraMaterial material;

  if(params["shading_model"]=="phong" || params["shading_model"]=="lambert")
  {
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_PHONG;
    if(params["shininess"]!="")
      material.specular.power = StringTo<float>(params["shininess"]);
  }
  else if (params["shading_model"]=="blinn")
  {
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_BLINN;
    if(params["shininess"]!="")
      material.specular.power = StringTo<float>(params["shininess"]);
  }
  else if (params["shading_model"]=="cook-torrance")
  {
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_COOK_TORRANCE;
    material.specular.roughness = 0.5f;
  }
  else
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_PHONG;


  material.ambient.color = float3(0,0,0); //StringTo<float3>(params["ambient"]);
  //material.ambient.color            = GetFloat3(p, "ambient_color");
  //material.ambient.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"ambient_texture"), pRender);
  //material.ambient.light_id         = -1;
  //material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");

  float3 emission = GetFloat3(p, "emission");
  if(length(emission) > 0.01f)
  {
    material.flags |= RAYTR::HydraMaterial::THIS_IS_LIGHT;
    material.ambient.color = emission;
    material.ambient.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"emission_texture"), pRender);
    material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");
    if(material.ambient.light_multiplyer < 1.0)
      material.ambient.light_multiplyer = 5.0;
  }

  if(params["vray"] == "1.0")
  {
    float3 diffuse = GetFloat3(p, "diffuse"); //StringTo<float3>(params["diffuse"]);
    float3 reflect = GetFloat3(p, "specular"); //StringTo<float3>(params["specular"]);
    float3 one(1,1,1);

    material.diffuse.color.x = diffuse.x*(one.x-reflect.x);
    material.diffuse.color.y = diffuse.y*(one.y-reflect.y);
    material.diffuse.color.z = diffuse.z*(one.z-reflect.z);
    material.diffuse.radiance = 1.0f;
    material.reflection.color = reflect;
  }
  else
  {

    material.diffuse.color = GetFloat3(p, "diffuse");

    float3 reflColor(1,1,1);
    if(params["reflective"]!="")
      reflColor = StringTo<float3>(params["reflective"]);

    float k_reflect  = GetFloat(p,"reflectivity");
    material.reflection.color = k_reflect*reflColor;
  }

  EmptyDataConverter* pTransparencyConverter = new AlphaFromRedChannel();

  material.ambient.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"ambient_texture"), pRender);
  material.diffuse.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"diffuse_texture"), pRender);
  material.specular.color_texId     = pTexImporter->AddTextureIfExists(GetString(p,"specular_texture"), pRender);
  material.reflection.color_texId   = pTexImporter->AddTextureIfExists(GetString(p,"reflective_texture"), pRender);
  material.transparency.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"transparent_texture"), pRender, pTransparencyConverter);

  if(material.transparency.color_texId != INVALID_TEXTURE)
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  material.ambient.color    = StandartTextureMultiplyer(material.ambient.color_texId,    material.ambient.color);
  material.diffuse.color    = StandartTextureMultiplyer(material.diffuse.color_texId,    material.diffuse.color);
  material.specular.color   = StandartTextureMultiplyer(material.specular.color_texId,   material.specular.color);
  material.reflection.color = StandartTextureMultiplyer(material.reflection.color_texId, material.reflection.color);

  // VRay parameters
  if(params["glossiness"]!="")
    material.reflection.power = VRayGlosinessToCosinePower(StringTo<float>(params["glossiness"]));
  else
    material.reflection.power = 1000000.0f;

  if(params["IOR"]!="")
    material.transparency.IOR = StringTo<float>(params["IOR"]);

  float3 transparent  = GetFloat3(p, "transparent");
  float  transparency = GetFloat(p, "transparency");
  std::string opaque_type = GetString(p, "opaque_type");

  float3 transparecyValue = transparent*transparency;
  if(opaque_type == "RGB_ZERO")
    transparecyValue = transparent*transparency;
  else if(opaque_type == "A_ONE")
    transparecyValue = (float3(1,1,1) - transparent)*transparency;

  material.transparency.color     = transparecyValue;
  material.transparency.fogColor  = material.transparency.color;
  material.transparency.exitColor = material.transparency.color;
  material.transparency.fogMultiplyer = 0.1f;
  material.transparency.IOR = 1.5f;

  if(length(material.transparency.color) > 0.001f)
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  // else 
  // transparency square term
  //{
  //material.transparency.color.x = sqrtf(material.transparency.color.x);
  //material.transparency.color.y = sqrtf(material.transparency.color.y);
  //material.transparency.color.z = sqrtf(material.transparency.color.z);
  // }

  // displacement
  //
  EmptyDataConverter* pConverterHeight = NULL;
  EmptyDataConverter* pConverterNormals = NULL;

  bool invertFlagsHeight[4]  = {true, true, true, true};
  pConverterHeight  = new BumpMapConverter(invertFlagsHeight);
  pConverterNormals = new EmptyDataConverter();

  std::string pathToHeightTex = GetString(p, "displacement_height_texture");
  std::string pathToNormalTex = GetString(p, "displacement_normals_texture");

  material.displacement.height        = GetFloat(p, "displacement_height");
  material.displacement.height_texId  = pTexImporter->AddTextureIfExists(pathToHeightTex, pRender, pConverterHeight,  false, true);
  material.displacement.normals_texId = pTexImporter->AddTextureIfExists(pathToNormalTex, pRender, pConverterNormals);

  if(material.displacement.normals_texId == INVALID_TEXTURE && material.displacement.height_texId != INVALID_TEXTURE)
  {
    material.displacement.normals_texId = pTexImporter->GetNormalMapFromFisplacement(material.displacement.height_texId, pRender, pathToHeightTex);
  }

  delete pConverterHeight; pConverterHeight = NULL;
  delete pConverterNormals; pConverterNormals = NULL;
  delete pTransparencyConverter; pTransparencyConverter = NULL;

  return material;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
RAYTR::HydraMaterial HydraMaterialFromStringMap(ColladaParser::ObjectDataList::iterator p, IGraphicsEngine* pRender, ITextureImporter* pTexImporter, HashMapImportParams* pStoredImportParams)
{
  RAYTR::HydraMaterial material;

  std::string name = p->second["name"];

  // ambient
  //
  material.ambient.color            = GetFloat3(p, "ambient_color");
  material.ambient.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"ambient_texture"), pRender);
  material.ambient.light_id         = -1;
  material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");

  if(length(material.ambient.color) > 0.0001f)
  {
    //std::cerr << "ambient != 0; " << name.c_str() << std::endl;
    material.ambient.color = float3(0,0,0);
  }

  if(material.ambient.light_multiplyer == 0.0f)
    material.ambient.light_multiplyer = 1.0f;

  float3 emission = GetFloat3(p, "emission_color");
  if(length(emission) > 0.01f)
  {
    material.flags |= RAYTR::HydraMaterial::THIS_IS_LIGHT;
    material.ambient.color = emission;
    material.ambient.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"emission_texture"), pRender);
    material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");
    if(material.ambient.light_multiplyer < 1.0)
      material.ambient.light_multiplyer = 5.0;
    //std::cerr << "emission texId = " <<  material.ambient.color_texId << std::endl;

    float disableEmissionPhotonMap = GetFloat(p, "emission_disable_for_photonmap");
    if(disableEmissionPhotonMap > 0.0f)
      material.flags |= HydraMaterial::EMISSION_DISABLE_FOR_PHOTONMAP;
  }


  // diffuse
  //
  material.diffuse.color       = GetFloat3(p,      "diffuse_color");
  material.diffuse.radiance    = RAYTR::fmaxf(GetFloat(p, "diffuse_radiance"), 1.0f);
  material.diffuse.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"diffuse_texture"), pRender);

  // max import crap
  //
  {
    float flipDiffuseXYTexCoord = GetFloat(p, "diffuse_texture_flipxy");
    if(flipDiffuseXYTexCoord > 0.0f)
      material.flags |= HydraMaterial::IMPORT_FLIPXY_TEXCOORD;

    float flatNormals = GetFloat(p, "hack_flat_normals");
    //float smoothNormals = GetFloat(p, "hack_smooth_normals");
    
    if(flatNormals > 0.0f)
      material.flags |= HydraMaterial::IMPORT_FLAT_SHADING;


    if(pStoredImportParams != NULL)
    {
      HashMapImportParams& importParams = (*pStoredImportParams);
      
      MaterialTextureImportMaxParams data;

      data.uTiling = GetFloat(p, "diffuse_texture_tiling_u");
      data.vTiling = GetFloat(p, "diffuse_texture_tiling_v");
      data.uOffset = GetFloat(p, "diffuse_texture_offset_u");
      data.vOffset = GetFloat(p, "diffuse_texture_offset_v");

      if(abs(data.uTiling) < 0.00001f) data.uTiling = 1.0f; 
      if(abs(data.vTiling) < 0.00001f) data.vTiling = 1.0f;

      importParams[name] = data;
    }


  }


  // specular
  //
  material.specular.color = GetFloat3(p, "specular_color");
  float power = GetFloat(p, "specular_cos_power");
  if(power < 1.0) power        = HydraMaterial::MaxCosPower();
  material.specular.power      = power;
  material.specular.brdf_id    = GetBRDFType(p, "specular_brfd_type");
  material.specular.fresnelIOR = GetFloat(p,    "specular_IOR");

  material.specular.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"specular_texture"), pRender);
  material.specular.power_texId      = pTexImporter->AddTextureIfExists(GetString(p,"specular_power_texture"), pRender);
  material.specular.fresnelIOR_texId = pTexImporter->AddTextureIfExists(GetString(p,"specular_fresnel_IOR_texture"), pRender);

  if(material.specular.brdf_id == HydraMaterial::BRDF_COOK_TORRANCE)
  {
    float rougness = GetFloat(p, "reflectivity_roughness");
    if(rougness == 0.0f)
      rougness = GetFloat(p, "specular_roughness");

    if(rougness != 0.0f)
      material.specular.roughness = rougness;
    else
      material.specular.roughness = 0.25f;
  }

  // reflection
  //
  material.reflection.color       = GetFloat3(p,   "reflectivity_color");
  material.reflection.brdf_id     = GetBRDFType(p, "reflectivity_brfd_type");
  material.reflection.fresnelIOR  = GetFloat(p,    "reflectivity_fresnel_IOR");
  material.reflection.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"reflectivity_texture"), pRender);

  float power2 = GetFloat(p, "reflectivity_cos_power");
  if(power2 < 1.0) power2   = HydraMaterial::MaxCosPower();
  material.reflection.power = power2;

  if(material.reflection.brdf_id == HydraMaterial::BRDF_COOK_TORRANCE || material.reflection.brdf_id == HydraMaterial::BRDF_FRESNEL_CONDUCTOR)
  {
    float rougness = GetFloat(p, "reflectivity_roughness");
    if(rougness != 0.0f)
      material.reflection.roughness = rougness;
    else
      material.reflection.roughness = 0.25f;

    if(material.reflection.fresnelIOR == 0.0f)
      material.reflection.fresnelIOR = 2.5f;

    if(material.specular.fresnelIOR == 0.0f)
      material.specular.fresnelIOR = material.reflection.fresnelIOR;
  }

  EmptyDataConverter* pTransparencyConverter = new AlphaFromRedChannel();

  // transparency
  //
  material.transparency.color         = GetFloat3(p, "transparency_color");
  material.transparency.color_texId   = pTexImporter->AddTextureIfExists(GetString(p, "transparency_texture"), pRender, pTransparencyConverter);
  material.transparency.exitColor     = GetFloat3(p, "transparency_exit_color");
  material.transparency.fogColor      = GetFloat3(p, "transparency_fog_color");
  material.transparency.fogMultiplyer = GetFloat(p,  "transparency_fog_multiplyer");
  material.transparency.IOR           = GetFloat(p,  "transparency_IOR");
  material.transparency.IOR_texId     = pTexImporter->AddTextureIfExists(GetString(p,"transparency_IOR_texture"), pRender);

  if(material.transparency.IOR != material.reflection.fresnelIOR)
    material.reflection.fresnelIOR = material.transparency.IOR; // this should be correct

  if(GetFloat(p,  "transparency_thin_surface"))
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  // holy shit
  //
  // transparency square term
  //material.transparency.color.x = sqrtf(material.transparency.color.x);
  //material.transparency.color.y = sqrtf(material.transparency.color.y);
  //material.transparency.color.z = sqrtf(material.transparency.color.z);


  float power3 = GetFloat(p, "transparency_cos_power");
  if(power3 < 1.0 && power3 > 10000.0f)
    power3 = HydraMaterial::MaxCosPower();
  material.transparency.glossiness = power3;

  float castColorShadow = GetFloat(p, "transparency_cast_color_shadows");
  if(castColorShadow > 0.0f)
    material.flags |= HydraMaterial::CAST_COLOR_SHADOWS;

  // displacement
  //
  bool invertHeight = GetFloat(p, "displacement_invert_height") > 0.0f;
  EmptyDataConverter* pConverterHeight = NULL;
  if(!invertHeight) // inverse
  {
    bool invertFlagsHeight[4]  = {true, true, true, true};
    pConverterHeight = new BumpMapConverter(invertFlagsHeight);
  }
  else
  {
    bool invertFlagsHeight[4]  = {false, false, false, false};
    pConverterHeight = new BumpMapConverter(invertFlagsHeight);
  }

  bool invertFlagsNormals[4];
  invertFlagsNormals[0] = GetFloat(p, "displacement_invert_normalX") > 0.0f;
  invertFlagsNormals[1] = GetFloat(p, "displacement_invert_normalY") > 0.0f;
  invertFlagsNormals[2] = GetFloat(p, "displacement_invert_normalZ") > 0.0f;
  //invertFlagsNormals[3] = invertHeight;

  EmptyDataConverter* pConverterNormals = NULL;
  if(invertFlagsNormals[0] || invertFlagsNormals[1] || invertFlagsNormals[2])
  {
    //pConverterNormals = new Char4DataInverter(invertFlagsNormals); // ��� �����������, ������� ����� �������� �� -1
    std::cerr << "Sorry, we do not support normals inversion in this release. You may do that by external program" << std::endl;
    pConverterNormals = new EmptyDataConverter();
  }
  else
    pConverterNormals = new EmptyDataConverter();

  std::string pathToHeightTex = GetString(p,"displacement_height_texture");
  std::string pathToNormalTex = GetString(p,"displacement_normals_texture");

  material.displacement.height        = GetFloat(p, "displacement_height");
  material.displacement.height_texId  = pTexImporter->AddTextureIfExists(pathToHeightTex, pRender,  pConverterHeight, false, true);
  material.displacement.normals_texId = pTexImporter->AddTextureIfExists(pathToNormalTex, pRender, pConverterNormals);

  //std::cerr << "displacement.height = " << material.displacement.height << std::endl;

  if(material.displacement.normals_texId == INVALID_TEXTURE && material.displacement.height_texId != INVALID_TEXTURE)
  {
    material.displacement.normals_texId = pTexImporter->GetNormalMapFromFisplacement(material.displacement.height_texId, pRender, pathToHeightTex);
  }

  delete pConverterHeight; pConverterHeight = NULL;
  delete pConverterNormals; pConverterNormals = NULL;
  delete pTransparencyConverter; pTransparencyConverter = NULL;

  if(GetFloat(p, "displacement_shadows") > 0.0f)
    material.flags |= HydraMaterial::TRACE_DISPLACEMENT_SHADOWS;

  material.flags |= HydraMaterial::REFRACT_CALC_TOTAL_INTERNAL_REFLECTION;

  return material;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportHydraMaterialsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_materials, GeometryStorage& a_geomStorage,
                                     ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter, HashMapI& a_matIds)
{
  ColladaParser::ObjectDataList::iterator p;
  int mat_size = int(a_materials.size());

  for (p=a_materials.begin(); p!=a_materials.end(); ++p)
  {
    ColladaParser::ObjectData& params = p->second;

    RAYTR::HydraMaterial material;

    if(params["shading_model"]=="hydra")
      material = HydraMaterialFromStringMap(p, pRender, pTexImporter, NULL);
    else
      material = StdColladaMaterialFromStringMap(p, pRender, pTexImporter, pMatImporter);

    int ind = pRender->AddMaterial(material);

    string mat_name = ColladaParser::CutOffColladaEffectsShit(params["name"]);
    a_geomStorage.mat_indices[mat_name] = ind;
    a_matIds[mat_name] = ind;
  }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ReplaceMaterialsWithAliases(IGraphicsEngine* pRender, ITextureImporter* pTexImporter, ColladaParser::ObjectDataList& materialList, TiXmlElement* a_materialsGroups)
{
  if(a_materialsGroups == NULL)
    return;

  for(TiXmlNode* pGroup = a_materialsGroups->FirstChild("group"); pGroup != NULL; pGroup = a_materialsGroups->IterateChildren("group", pGroup))
  {
    TiXmlElement* pMaterialModel = pGroup->FirstChildElement("material");
    if(pMaterialModel == NULL)
      continue;

    // remember all bound materials
    //
    HashMapI boundMaterials;
    for(TiXmlNode* pMaterialBinding = pGroup->FirstChild("bind_material"); pMaterialBinding != NULL; pMaterialBinding = pGroup->IterateChildren("bind_material", pMaterialBinding))
    {
      std::string name = pMaterialBinding->ToElement()->GetText();
      if(name != "")
        boundMaterials[name] = 1;
    }

    // get our replacement data
    //
    ColladaParser::ObjectData paramsR;
    ColladaParser::ParseHydraMaterial(paramsR, pMaterialModel->FirstChildElement());

    // replace
    //
    for(ColladaParser::ObjectDataList::iterator p=materialList.begin(); p!=materialList.end(); ++p)
    {
      ColladaParser::ObjectData& params = p->second;
      if(boundMaterials.find(p->first) == boundMaterials.end())
        continue;

      for(ColladaParser::ObjectData::iterator f = paramsR.begin(); f != paramsR.end(); ++f)
      {
        ColladaParser::ObjectData::iterator q = params.find(f->first);

        if(q != params.end())
          q->second = f->second;
        else
          params[f->first] = f->second;

      }
    }

  }

}










