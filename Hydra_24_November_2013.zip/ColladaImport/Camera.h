#pragma once

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif


using namespace MGML;

struct Camera
{

  Camera() : pos(0,0,10,1) {}
  virtual ~Camera(){}
	
  virtual void Move(const vec4f& pos);
  virtual void SetRotation(const vec4f& rot);
  virtual void LookAt(const vec3f& pos, const vec3f& lookAt);
  
  virtual void SetPerspectiveProjection(float fovy, float aspect, float zNear, float zFar);
  
  virtual Matrix4x4f GetWorldMatrix() const;
  virtual Matrix4x4f GetViewMatrix() const;
  virtual Matrix4x4f GetProjectionMatrix() const { return mProjection;}

  virtual vec4f GetRotation() const { return rotation; }
  
  virtual void Save(const std::string& fname);
  virtual void Load(const std::string& fname);

  vec4f pos;

  float GetFOV();
  float GetAspect();
  float GetNearClipPlane();
  float GetFarClipPlane();

protected:

  vec4f rotation;

  Matrix4x4f mWorld;
  Matrix4x4f mView;
  Matrix4x4f mProjection;

  void CreateFrustumMatrix(float result[16], float left, float right, float bottom, float top, float nearVal, float farVal);
	
  vec4f m_projParams;
};