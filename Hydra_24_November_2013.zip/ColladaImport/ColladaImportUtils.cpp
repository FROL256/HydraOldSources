#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
const char* GetText(TiXmlNode* node, const char* name)
{
  if(node->FirstChild(name) != 0)
    return node->FirstChildElement(name)->GetText();
  return "";
}

const char* GetText(TiXmlNode* node, const char* name, const char* name2)
{
  if(node->FirstChild(name) != 0)
    return GetText(node->FirstChild(name), name2);
  return "";
}

const char* GetText(TiXmlNode* node, const char* name, const char* name2, const char* name3)
{
  if(node->FirstChild(name) != 0)
    return GetText(node->FirstChild(name), name2, name3);
  return "";
}

const char* GetText(TiXmlNode* node, const char* name, const char* name2, const char* name3, const char* name4)
{
  if(node->FirstChild(name) != 0)
    return GetText(node->FirstChild(name), name2, name3, name4);
  return "";
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlNode* GetNode(TiXmlNode* node, const char* name)
{
  return node->FirstChild(name);
}

TiXmlNode* GetNode(TiXmlNode* node, const char* name, const char* name2)
{
  if(node->FirstChild(name) != NULL)
    return GetNode(node->FirstChild(name), name2);
  return 0;
}

TiXmlNode* GetNode(TiXmlNode* node, const char* name, const char* name2, const char* name3)
{
  if(node->FirstChild(name) != NULL)
    return GetNode(node->FirstChild(name), name2, name3);
  return 0;
}

TiXmlNode* GetNode(TiXmlNode* node, const char* name, const char* name2, const char* name3, const char* name4)
{
  if(node->FirstChild(name) != NULL)
    return GetNode(node->FirstChild(name), name2, name3, name4);
  return NULL;
}

/*
TiXmlElement* GetElement(TiXmlNode* node, const char* name)
{
  return node->FirstChildElement(name);
}

TiXmlElement* GetElement(TiXmlNode* node, const char* name, const char* name2)
{
  TiXmlElement* child = node->FirstChildElement(name);
  if(child != NULL)
    return GetElement(child, name2);
}

TiXmlElement* GetElement(TiXmlNode* node, const char* name, const char* name2, const char* name3)
{
  TiXmlElement* child = node->FirstChildElement(name);
  if(child!= NULL)
    return GetElement(child, name2, name3);
}

TiXmlElement* GetElement(TiXmlNode* node, const char* name, const char* name2, const char* name3, const char* name4)
{
  TiXmlElement* child = node->FirstChildElement(name);
  if(child!= NULL)
    return GetElement(child, name2, name3, name4);
}
*/

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
Matrix4x4f GetTransformFromNode(TiXmlNode* a_node)
{
  Matrix4x4f mTransform,m;
  for(TiXmlNode* nextNode = a_node->FirstChild(); nextNode!=0; nextNode = a_node->IterateChildren(nextNode))
  {
    string transformId = nextNode->ValueStr();

    m.Identity();

    if(transformId == "matrix" || transformId == "mat")
    {
      string matrix = nextNode->ToElement()->GetText();
      m = STR_CNV::StringTo<Matrix4x4f>(matrix);
    }
    else if(transformId == "translate")
    {
      string translate = nextNode->ToElement()->GetText();
      float3 translate_v = StringTo<float3>(translate);
      m.SetTranslate(translate_v);
    }
    // ������� ������ ������ 6 ��������, ������ ��� ������ 
    // rotateX, rotateY, rotateZ, post-rotationX, post-rotationY, post-rotationZ 
    // ���� ��������� ������������ ������� � ����, �� ��� ���� �������!
    //
    else if(transformId.substr(0,6)  == "rotate" || transformId.substr(0,13) == "post-rotation" ) 
    {
      string rotate = nextNode->ToElement()->GetText();
      float4 rotate_v = StringTo<float4>(rotate);
      float angle = rotate_v.w;
      m.SetRotation(MGML_MATH::DEG_TO_RAD(angle), to_float3(rotate_v));
    }
    else if(transformId == "scale")
    {
      string scale = nextNode->ToElement()->GetText();
      float3 scale_v = StringTo<float3>(scale);
      m.SetScale(scale_v);
    }

    mTransform = mTransform*m;
  }

  return mTransform;
}




//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::FindElemByAttribute(TiXmlElement* a_node, const std::string& a_nodeName, const std::string& a_attributeName, const std::string& a_attributeValue)
{
  TiXmlElement* res = NULL;

  // 
  for (TiXmlNode* nextNode = a_node->FirstChild(a_nodeName); nextNode!=0; nextNode = a_node->IterateChildren(a_nodeName, nextNode))
  {
    TiXmlElement* nextElem = nextNode->ToElement();

    if(nextElem->Attribute(a_attributeName) == NULL) // ������ �������� ������ ���, �����
      return NULL;

    const std::string& attribName = *(nextElem->Attribute(a_attributeName));
    if(attribName == a_attributeValue)
      return nextElem;
  }

  return res;
}


std::string MatrixToString(const Matrix4x4f& m)
{
  char temp[1024];
  sprintf(temp,"%f %f %f %f \
               %f %f %f %f \
               %f %f %f %f \
               %f %f %f %f",
               m.L[0],m.L[1],m.L[2],m.L[3],
               m.L[4],m.L[5],m.L[6],m.L[7],
               m.L[8],m.L[9],m.L[10],m.L[11],
               m.L[12],m.L[13],m.L[14],m.L[15]);
  return string(temp);
}




