#include "Camera.h"

void Camera::Move(const vec4f& move)
{
	pos += GetViewMatrix()*move;

  vec4f pos2 = pos;
  pos2 *= (-1); 
  pos2.w = 1;

  Matrix4x4f mt;
  mt.SetTranslate(pos2); mt.Transpose();

  mWorld = mt;
}

void Camera::LookAt(const vec3f& a_pos, const vec3f& lookAt)
{
  vec3f up(0,1,0);

  vec3f zaxis = normalize(lookAt - a_pos);    // The "look-at" vector.
  vec3f xaxis = normalize(cross(up, zaxis));// The "right" vector.
  vec3f yaxis = cross(zaxis, xaxis);     // The "up" vector.

  // Create a 4x4 orientation matrix from the right, up, and at vectors
  //
  Matrix4x4f orientation(
    xaxis.x, yaxis.x, zaxis.x, 0,
    xaxis.y, yaxis.y, zaxis.y, 0,
    xaxis.z, yaxis.z, zaxis.z, 0,
    0,       0,       0,     1);


  Matrix4x4f mRot = orientation; //.GetTranspose().GetInverse();

  vec3f norm = normalize(lookAt - a_pos);
  vec3f default_norm(0,0,1);

  vec3f v     = cross(norm, default_norm);
  float theta = dot(norm, default_norm); 

  float cos_t = cos(theta);
  float sin_t = sin(theta);

  mRot.M[0][0] = (1.0f-cos_t)*v.x*v.x + cos_t;
  mRot.M[0][1] = (1.0f-cos_t)*v.x*v.y - sin_t*v.z;
  mRot.M[0][2] = (1.0f-cos_t)*v.x*v.z + sin_t*v.y;

  mRot.M[1][0] = (1.0f-cos_t)*v.y*v.x + sin_t*v.z;
  mRot.M[1][1] = (1.0f-cos_t)*v.y*v.y + cos_t;
  mRot.M[1][2] = (1.0f-cos_t)*v.y*v.z - sin_t*v.x;

  mRot.M[2][0] = (1.0f-cos_t)*v.x*v.z - sin_t*v.y;
  mRot.M[2][1] = (1.0f-cos_t)*v.z*v.y + sin_t*v.x;
  mRot.M[2][2] = (1.0f-cos_t)*v.z*v.z + cos_t;
  
  
  // now make a big shit, evaluate Eiler angles from rotation matrix
  //
  {
    float theta1, theta2;
    float psi1, psi2;
    float phi1, phi2;

    if(abs(mRot.M[2][0] - 1.0f) > 1e-6f && abs(mRot.M[2][0] + 1.0f) > 1e-6f)
    {
      theta1 = -asin(mRot.M[2][0]);
      theta2 = MGML_MATH::PI - theta1;

      float cos_theta1 = cos(theta1);
      float cos_theta2 = cos(theta2);

      psi1 = atan2(mRot.M[2][1]/cos_theta1, mRot.M[2][2]/cos_theta1);
      psi2 = atan2(mRot.M[2][1]/cos_theta2, mRot.M[2][2]/cos_theta2);

      phi1 = atan2(mRot.M[1][0]/cos_theta1, mRot.M[0][0]/cos_theta1);
      phi2 = atan2(mRot.M[1][0]/cos_theta2, mRot.M[0][0]/cos_theta2);
    }
    else
    {
      phi1 = phi2 = 0.0f;
      if(abs(mRot.M[2][0] + 1.0f) < 1e-6f)
      {
        theta1 = theta2 = MGML_MATH::PI/2;
        psi1 = psi2 = phi1 + atan2(mRot.M[0][1], mRot.M[0][2]);
      }
      else
      {
        theta1 = theta2 = -MGML_MATH::PI/2;
        psi1 = psi2 = -phi1 + atan2(-mRot.M[0][1], -mRot.M[0][2]);
      }
    }

    rotation.x = MGML_MATH::RAD_TO_DEG(psi1);
    rotation.y = MGML_MATH::RAD_TO_DEG(theta1);
    rotation.z = MGML_MATH::RAD_TO_DEG(phi1);
    rotation.w = 1;

    SetRotation(rotation);

    Matrix4x4f oldMat = mRot;
    Matrix4x4f newMat = mView;

    float diff1 = oldMat.M[0][0] - newMat.M[0][0];
    float diff2 = oldMat.M[0][1] - newMat.M[0][1];
    float diff3 = oldMat.M[0][2] - newMat.M[0][2];
    float diff4 = oldMat.M[0][3] - newMat.M[0][3];

  }

  // change position
  //
  pos.x = a_pos.x;
  pos.y = a_pos.y;
  pos.z = a_pos.z;
  pos.w = 1;

  Matrix4x4f mt;
  mt.SetTranslate(pos); 
  mt.Transpose();
  mWorld = mt;

}

void Camera::SetRotation(const vec4f& in_rot)
{
  Matrix4x4f mx,my,mz;

  vec3f r;
  r.x = MGML_MATH::DEG_TO_RAD(in_rot.x);
  r.y = MGML_MATH::DEG_TO_RAD(in_rot.y);
  r.z = MGML_MATH::DEG_TO_RAD(in_rot.z);
  mx.SetRotationX(r.x);
  my.SetRotationY(r.y);
  mz.SetRotationZ(r.z);

  mView = mz*my*mx;
  rotation = in_rot;
}


void Camera::CreateFrustumMatrix(float result[16], float left, float right, float bottom, float top, float nearVal, float farVal)
{
  result[0] = 2.0f*nearVal/(right-left);
  result[1] = 0.0f;
  result[2] = 0.0f;
  result[3] = 0.0f;
  result[4] = 0.0f;
  result[5] = 2.0f*nearVal/(top-bottom);
  result[6] = 0.0f;
  result[7] = 0.0f;
  result[8] = (right+left)/(right-left);
  result[9] = (top+bottom)/(top-bottom);
  result[10] = -(farVal+nearVal)/(farVal-nearVal);
  result[11] = -1.0f;
  result[12] = 0.0f;
  result[13] = 0.0f;
  result[14] = -(2.0f*farVal*nearVal)/(farVal-nearVal);
  result[15] = 0.0f;
}

void Camera::SetPerspectiveProjection(float fovy, float aspect, float zNear, float zFar)
{
  float ymax = zNear * tanf(fovy * 3.141592654f / 360.0f);
  float ymin = -ymax;
  float xmin = ymin * aspect;
  float xmax = ymax * aspect;

  CreateFrustumMatrix(mProjection.L, xmin, xmax, ymin, ymax, zNear, zFar);

  m_projParams = vec4f(fovy, aspect, zNear, zFar);
}

float Camera::GetFOV() { return m_projParams.x; }
float Camera::GetAspect() { return m_projParams.y; }
float Camera::GetNearClipPlane() { return m_projParams.z; }
float Camera::GetFarClipPlane() { return m_projParams.w;}


Matrix4x4f Camera::GetWorldMatrix() const
{
  return mWorld;
}


Matrix4x4f Camera::GetViewMatrix() const
{
  return mView;
}


void Camera::Save(const std::string& fname)
{
  pos.w = 1;

  std::ofstream fout(fname.c_str());

  fout << pos << std::endl;
  fout << rotation << std::endl;

  fout << mWorld << std::endl;
  fout << mView << std::endl;
  fout << mProjection << std::endl;
}

void Camera::Load(const std::string& fname)
{
  std::ifstream fin(fname.c_str());

  fin >> pos;
  fin >> rotation;

  fin >> mWorld;
  fin >> mView;
  fin >> mProjection;
}
