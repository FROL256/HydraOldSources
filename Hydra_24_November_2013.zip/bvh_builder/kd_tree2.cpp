// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
//
#ifndef KD_TREE_GUARDIAN
  #include "kd_tree.h"
#endif

using namespace RAYTR;

using MGML_MATH::MAX;
using MGML_MATH::MIN;
using MGML_MATH::lerp;
using MGML_MATH::clamp;

////////////////////////////////////////////////////////////////////////////
////
KdTree::Node* KdTree::Build2(uint mode)
{
  int primitivesNumber = GetTotalPrims();

  int maxNodes = MIN(20*primitivesNumber + 10000, 10000000);
  int refPoolSize = MIN(20*primitivesNumber + 10000, 10000000);

  m_nodesPool.resize(maxNodes);
 // m_debugBoxes.reserve(1000);

  PrimitiveList plist;
  plist.reserve(primitivesNumber);

  delete [] m_vspheresMemory;
  delete [] m_vtrianglesMemory;
  m_vspheresMemory = new VSphere[m_pInputData->GetNumSpheres()];
  m_vtrianglesMemory = new VTriangle [m_pInputData->GetNumTriangles()];

  for(int i=0;i<m_pInputData->GetNumSpheres();i++)
  {
    m_vspheresMemory[i].ConstructSphere(i, this);
    plist.push_back(PrimitiveRef(m_vspheresMemory+i));
  }

  for(int i=0;i<m_pInputData->GetNumTriangles()*3;i+=3)
  {
    m_vtrianglesMemory[i/3].ConstructTriangle(i, this);
    plist.push_back(PrimitiveRef(m_vtrianglesMemory+i/3));
  }

  m_bBox = CalcBindingBox(plist);
  AABB3f bBox = m_bBox;

  Node* root = m_nodesPool.New();
  root->box = bBox;

  std::cerr << "constructing kd-tree.." << std::endl;
  m_stat.Clear();
  m_root2 = Subdivide2(root, 64, plist, mode);
  //m_root2 = Subdivide2(root, 16, plist, mode);
  
  DebugCollectStatistics(m_root2);
  OutStatistics();

  std::cerr << "total triangles: " << m_pInputData->GetNumTriangles() << std::endl;
  std::cerr << "total spheres: "   << m_pInputData->GetNumSpheres() << std::endl;

  // convert kd tree to appreciable linear format for GPU
  //
  m_kdNodesSize = m_stat.totalNodes;

  delete [] m_root;
  m_root = new KdTreeNode [m_kdNodesSize];
  
  m_objListData.reserve(sizeof(RAYTR::ObjectList::Triangle)*m_stat.totalPrims*4);

  DynamicTreeToArrayLayout(m_root, m_root2);
  
  ReleaseDynamicTreeRes(m_root2);
  m_nodesPool.resize(0);
  m_root2 = NULL;
  return m_root2;
}

////////////////////////////////////////////////////////////////////////////
////
bool KdTree::FoundAlreadySplitedAAReferences(const AABB3f& a_box, PrimitiveList& prims, float min_split, int min_axis)
{
  // Now, solve a problem of fucking axis aligned triangles. 
  // This problem arise when we have axis aligned triangles and we have a split position on such triangle. And this is shit.
  //
  bool result = false;

  for(uint i=0;i<prims.size();i++)
  {
    if(prims[i].AxisAligned(min_axis, min_split))
    {
      if(prims[i].ExistSplitOnThatPlane(min_axis, min_split))
      {
        //throw Error("FoundAlreadySplitedAAReferences return true. This must not happen!");
        result = true;
      }
      prims[i].MemorizeExistSplit(min_axis, min_split);
    }
  }

  return result;
}


////////////////////////////////////////////////////////////////////////////
////
KdTree::Node* KdTree::Subdivide2(Node* a_node, int a_Depth, PrimitiveList& plist, int a_flags)
{
  const AABB3f& nodeBox = a_node->box;

  if(a_Depth == 0 || plist.size() <= 4) 
  {
    if(plist.size()==0)
      a_node->pPrimitiveList = NULL;
    else
    {
      PrimitiveList* pList = new PrimitiveList(plist.size());
      *pList = plist;
      a_node->pPrimitiveList = pList;
    }

    return a_node;
  }

  float leafSAH = SurfaceArea(nodeBox)*plist.size();
  SplitData split = AccelerationStructure::FindSplitPosSortSAH(plist, nodeBox);

  if(leafSAH <= split.sah && plist.size() <= 64)
  {
    PrimitiveList* pList = new PrimitiveList(plist.size());
    *pList = plist;
    a_node->pPrimitiveList = pList;
    return a_node;
  }

  a_node->split = split.pos;
  a_node->splitAxis = split.axis;

  Node* left = m_nodesPool.New();
  Node* right = m_nodesPool.New();
  AABB3f& leftBox = left->box;
  AABB3f& rightBox = right->box;

  rightBox = leftBox = nodeBox;
  leftBox.vmax[split.axis] = split.pos;
  rightBox.vmin[split.axis] = split.pos;

  PrimitiveList leftPrimList; 
  PrimitiveList rightPrimList; 

  leftPrimList.reserve(plist.size());
  rightPrimList.reserve(plist.size());

  for(uint i=0;i<plist.size();i++) 
  {
    bool overlapLeft  = plist[i].IntersectWithAABB(leftBox);
    bool overlapRight = plist[i].IntersectWithAABB(rightBox);

    if (overlapLeft && overlapRight)
    {
      PrimitiveRef refRight, refLeft;

      SplitReference(plist[i], &refLeft, &refRight, split.pos, split.axis);

      bool validLeft = refLeft.Valid();
      bool validRight = refRight.Valid();

      if(validLeft)
      {
        refLeft.Box().intersect(leftBox);
        leftPrimList.push_back(refLeft);
      }
        
      if(validRight)
      {
        refRight.Box().intersect(rightBox);
        rightPrimList.push_back(refRight);
      }

      if(validLeft && validRight)
        m_stat.dublicates++;
    }
    else if (overlapLeft)
    {
      PrimitiveRef refLeft = plist[i];
      refLeft.Box().intersect(leftBox);
      
      if(MGML_MATH::Intersect<AABB3f,AABB3f>::overlapOnBoundary(leftBox, refLeft.Box()))
        leftPrimList.push_back(refLeft);
      else
        std::cerr << "drop left ref" << std::endl;
    }
    else if (overlapRight)
    {
      PrimitiveRef refRight = plist[i];
      refRight.Box().intersect(rightBox);
      
      if(MGML_MATH::Intersect<AABB3f,AABB3f>::overlapOnBoundary(rightBox, refRight.Box()))
        rightPrimList.push_back(refRight);
      else
        std::cerr << "drop right ref" << std::endl;
    }
    else if(plist[i].AxisAligned(split.axis, split.pos))
    {
      // this may happen actually when we have axis aligned triangles and we have
      // a split position on such triangle. And this is shit.
      //
      PrimitiveRef refLeft  = plist[i];
      PrimitiveRef refRight = plist[i];
      refLeft.Box().intersect(leftBox);
      refRight.Box().intersect(rightBox);

      if(MGML_MATH::Intersect<AABB3f,AABB3f>::overlapOnBoundary(leftBox, refLeft.Box()))
        leftPrimList.push_back(refLeft);
      else
        std::cerr << "drop left AA ref" << std::endl;
      
      if(MGML_MATH::Intersect<AABB3f,AABB3f>::overlapOnBoundary(rightBox, refRight.Box()))
        rightPrimList.push_back(refRight);
      else
        std::cerr << "drop right AA ref" << std::endl;
    }
    else
    {
      ASSERT(!plist[i].AxisAligned(split.axis, split.pos));
    }

  }

  // free unnecessary memory
  //
  int oldSize = plist.size();
  PrimitiveList empty;
  plist.swap(empty);

  if (leftPrimList.size() == 0 && rightPrimList.size() == 0)
  {
    // strange but can happen
    //
    a_node->pPrimitiveList = NULL;
    return a_node;
  }

  a_node->left  = Subdivide2(left, a_Depth-1,leftPrimList, a_flags);
  a_node->right = Subdivide2(right,a_Depth-1,rightPrimList,a_flags);

  if(oldSize > 10000)
    std::cerr << '.';

  return a_node;
}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////
////
KdTree::SplitData KdTree::FindObjectSplit(const PrimitiveList& a_plist, const AABB3f& a_box)
{
  SplitData res;
  res.sah = SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size();
  res.subdivideNext = false;
  res.axis = -1;

  float3 boxSize = a_box.vmax - a_box.vmin;
  float maxBoxSize = fmaxf(boxSize.x, fmaxf(boxSize.y, boxSize.z));

  std::vector<AABB3f> rightBounds(a_plist.size());

  for (int dim=0;dim<3;dim++)
  {
    if(boxSize[dim]*20 < maxBoxSize)
      continue;

    PrimitiveList currList; currList.resize(a_plist.size());
    std::copy(a_plist.begin(), a_plist.end(), currList.begin());

    // sort prims according to current axis
    //
    switch(dim)
    {
    case 0:
      std::sort(currList.begin(), currList.end(), MyBoxLessMax<0>());
      break;
    case 1:
      std::sort(currList.begin(), currList.end(), MyBoxLessMax<1>());
      break;
    case 2:
      std::sort(currList.begin(), currList.end(), MyBoxLessMax<2>());
      break;
    }

    PrimitiveList& plist = currList;

    // Sweep right to left and determine bounds.
    //
    AABB3f rightBounds1;
    for (uint i = plist.size() - 1; i > 0; i--)
    {
      rightBounds1.include(plist[i].Box());
      rightBounds[i-1] = rightBounds1;
    }

    // Sweep left to right and select lowest SAH.
    //
    AABB3f leftBounds;
    for (uint i = 1; i < plist.size(); i++)
    {
      leftBounds.include(plist[i-1].Box());

      AABB3f leftBox = leftBounds;
      AABB3f rightBox = rightBounds[i-1];
      float primsOnLeftSide  = (float)i;
      float primsOnRightSide = (float)(plist.size() - i);

      float sah = EMPTY_NODE_COST_TRAVERSE + SurfaceArea(leftBox)*primsOnLeftSide + SurfaceArea(rightBox) * primsOnRightSide;

      // calc left and right nodes intersection penalty
      //
      if (sah < res.sah)
      {
        res.sah = sah;
        res.axis = dim;
        res.primsOnLeftSide = i;
        res.primsOnRightSide = plist.size() - i;
        res.leftBounds = leftBounds;
        res.rightBounds = rightBounds[i-1];
      }
    }

  } // for (int dim=0;dim<3;dim++)

  res.subdivideNext = (res.axis != -1) && (res.sah < SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*a_plist.size());
  res.pos = res.leftBounds.vmax[res.axis];

  return res;
}










