#define KD_TREE_LAYOUT_GUARDIAN


#ifndef __CUDACC__
  #ifndef universal_call
    #define  universal_call
  #endif

  #ifndef __host__
    #define __host__
  #endif

  #ifndef __device__
    #define __device__
  #endif

#endif

class KdTreeNode
{

public:

  //No constructor because of CUDA problems with arrays
  //KdTreeNode() : m_Data( 0 ) {};

  inline void	universal_call SetLeaf(bool a_Leaf)
  {
    register int mask = ((int)a_Leaf) << 31;
    register int m_Data2 = m_Data & 0x7fffffff;
    m_Data = m_Data2 | mask;
  }
  inline unsigned int	universal_call Leaf() const { return (m_Data & 0x80000000); } // use sign bit

  inline universal_call void SetAxis(unsigned int a_Axis )
  {
    register int mask = ((a_Axis) << 29) & 0x6fffffff;
    register int m_Data2 = m_Data & 0x9fffffff;
    m_Data = m_Data2 | mask;
  }
  inline universal_call unsigned int GetAxis() const { return (m_Data & 0x6fffffff) >> 29; }

  inline universal_call void	SetLeftOffset( unsigned int a_Left )
  {
    register int mask = a_Left & 0x1fffffff;
    register int m_Data2 = m_Data & 0xe0000000;
    m_Data = m_Data2 | mask;
  }
  inline universal_call unsigned int GetLeftOffset()  const { return m_Data&0x1fffffff; }
  inline universal_call unsigned int GetRightOffset() const { return GetLeftOffset() + 1; }

  inline universal_call void	SetSplitPos( float a_Pos ) { m_split = a_Pos; }
  inline universal_call float GetSplitPos() const { return m_split; }

  inline __device__ bool Empty() const
  {
    return (GetObjectListOffsetInBytes() < 0);
  }

  inline __device__ bool NotEmptyLeaf() const
  {
    return Leaf() && (GetObjectListOffsetInBytes() >= 0);
  }

  inline __device__ bool EmptyLeaf() const
  {
    return Leaf() && (GetObjectListOffsetInBytes() >= 0);
  }

  //inline universal_call void setUpOffset(unsigned int offs) { m_up_offset = offs; }
  //inline universal_call unsigned int getUpOffset() const { return m_up_offset; }

#ifndef __CUDACC__

  inline universal_call void SetObjectListOffsetInBytes(int offs)
  {
    //ASSERT(Leaf());
    m_split = *((float*)&offs);
  }

  inline universal_call int GetObjectListOffsetInBytes() const
  {
    //ASSERT(Leaf());
    return *((int*)&m_split);
  }

  inline universal_call void SetFrom2BytesQuad(unsigned int first_quad, unsigned int second_quad)
  {
    m_split = *((float*)&first_quad);
    m_Data = second_quad;
    //m_up_offset = third_quad;
  }

  //static void* KdTreeNode::operator new(size_t size);
  //static void KdTreeNode::operator delete(void* raw_memory);
  //static void* KdTreeNode::operator new[](size_t size);
  //static void KdTreeNode::operator delete[](void* raw_memory);
#else

  inline __device__ void SetObjectListOffsetInBytes(int offs)
  {
    //ASSERT(Leaf());
    m_split = __int_as_float(offs);
  }

  inline __device__ int GetObjectListOffsetInBytes() const
  {
    //ASSERT(Leaf());
    return __float_as_int(m_split);
  }
#endif


  //protected:

  float		 m_split;
  unsigned int m_Data;

  //unsigned int m_up_offset;
  //	struct
  //	{
  //    unsigned int offset_to_left_child	: 29;
  //		unsigned int split_axis			      : 2;
  //		unsigned int is_leaf				      : 1;
  //	};
};


