#include "AccelerationStructure.h"

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

using namespace RAYTR;

using MGML_MATH::MIN;
using MGML_MATH::MAX;
using MGML_MATH::clamp;

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VTriangle::SizeInBytes() const
{
  return sizeof(ObjectList::Triangle);
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VTriangle::GetPrimType() const
{
  return ObjectList::TRIANGLE;
}

////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::VSphere::VSphere(int a_id,  AccelerationStructure* t)
{
  ConstructSphere(a_id,t);
}

////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::VSphere::ConstructSphere(int a_id,  AccelerationStructure* t)
{
  m_primitiveIndex = a_id;
  thisAccelStruct = t;

  Sphere sph;
  thisAccelStruct->m_pInputData->GetSphere(a_id,sph.pos.M,&sph.r);

  m_box.vmin = to_float3(sph.pos) - float3(sph.r,sph.r,sph.r);
  m_box.vmax = to_float3(sph.pos) + float3(sph.r,sph.r,sph.r);
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VSphere::SizeInBytes() const
{
  return sizeof(ObjectList::Sphere);
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::VSphere::GetPrimType() const
{
  return ObjectList::SPHERE;
}

void AccelerationStructure::GetTriangleVertices(int triIndex, float4* A, float4* B, float4* C) const
{
  this->m_pInputData->GetTriangle(triIndex, A->M, B->M, C->M);
}

void AccelerationStructure::GetTriangleVertices(int triIndex, float3* A, float3* B, float3* C) const
{
  this->m_pInputData->GetTriangle(triIndex, A->M, B->M, C->M);
}

////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::VTriangle::VTriangle(int i, AccelerationStructure* t)
{
  ConstructTriangle(i,t);
}

void AccelerationStructure::VTriangle::ConstructTriangle(int i, AccelerationStructure* t)
{
  m_primitiveIndex = i/3;
  thisAccelStruct = t;

  float A[3], B[3], C[3];
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, A, B, C);

  for (int axis=0;axis<3;axis++)
  {
    m_box.vmax[axis] = MGML_MATH::MAX(A[axis], B[axis], C[axis]);
    m_box.vmin[axis] = MGML_MATH::MIN(A[axis], B[axis], C[axis]);
  }
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::VTriangle::IntersectWithAABB(const AABB3f& b) const
{
  bool overlap = MGML_MATH::Intersect<AABB3f,AABB3f>::exec(m_box, b);

  if (!overlap)
    return false;

  Triangle t;
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, t.A.M, t.B.M, t.C.M);

	return MGML_MATH::Intersect<AABB3f,Triangle>::exec(b,t);
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::VTriangle::Valid() const
{
  Triangle t;
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, t.A.M, t.B.M, t.C.M);

  float d1 = length(t.A);
  float d2 = length(t.B);
  float d3 = length(t.C);

  if(d1 > 1e35f || d2 > 1e35f || d3 > 1e35f)
    return false;

  d1 = length(t.A-t.B);
  d2 = length(t.B-t.C);
  d3 = length(t.C-t.B);

  if(d1 > 1e36f || d2 > 1e36f || d3 > 1e36f)
    return false;

  if(d1 <= 1e-36f || d2 <= 1e-36f || d3 <= 1e-36f)
    return false;

  return true;
}

bool AccelerationStructure::VSphere::Valid() const
{
  return true;
}

////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::VTriangle::GetVertexPositions(Triangle* t) const
{
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, t->A.M, t->B.M, t->C.M);
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::VSphere::IntersectWithAABB(const AABB3f& b) const
{
  bool overlap = MGML_MATH::Intersect<AABB3f,AABB3f>::exec(m_box, b);

  if (!overlap)
    return false;

  AABB4f box(to_float4(b.vmin,1), to_float4(b.vmax,1));

	Sphere sph;
  thisAccelStruct->m_pInputData->GetSphere(m_primitiveIndex, sph.pos.M, &sph.r);
	return MGML_MATH::Intersect<AABB4f,Sphere>::exec(box, sph);
}


////////////////////////////////////////////////////////////////////////////
////
vec2i AccelerationStructure::VTriangle::IntersectAxisAlignedPlane(float splitPos, int axis) const
{
  vec2i res(0,0);

  float3 verts[3];
  thisAccelStruct->m_pInputData->GetTriangle(m_primitiveIndex, verts[0].M, verts[1].M, verts[2].M);

  float3 edges[3][2] = {  {verts[0], verts[1]},
                          {verts[0], verts[2]},
                          {verts[1], verts[2]} };

  for (int i=0;i<3;i++)
  {
    float v0p = edges[i][0][axis];
    float v1p = edges[i][1][axis];

    if ((v0p <= splitPos && v1p >= splitPos) || (v0p >= splitPos && v1p <= splitPos))
    {
      res.x++;
      res.y++;
      return res;
    }
  }

  if (verts[0][axis] <= splitPos)
    res.x++;
  else
    res.y++;

  return res;
}

////////////////////////////////////////////////////////////////////////////
////
vec2i AccelerationStructure::VSphere::IntersectAxisAlignedPlane(float coord, int axis) const
{
  vec2i res(0,0);

  Sphere sph;
  thisAccelStruct->m_pInputData->GetSphere(m_primitiveIndex, sph.pos.M, &sph.r);

  if ( abs(sph.pos[axis] - coord) <= sph.r)
  {
    res.x++;
    res.y++;
  }

  return res;
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::AccelerationStructure()
{
  //m_spheres = NULL;
 // m_vert = 0;
 // m_index = 0;
  m_vtrianglesMemory = NULL;
  m_vspheresMemory = NULL;
  m_pInputData = NULL;
}

////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::~AccelerationStructure()
{
  delete [] m_vtrianglesMemory;
  delete [] m_vspheresMemory;
}


////////////////////////////////////////////////////////////////////////////
////
const AABB4f AccelerationStructure::GetBoundingBox() const
{
  return AABB4f(to_float4(m_bBox.vmin, 0), to_float4(m_bBox.vmax, 1));;
}


////////////////////////////////////////////////////////////////////////////
////
const char*	AccelerationStructure::GetObjData() const
{
  return m_objListData.begin();
}

////////////////////////////////////////////////////////////////////////////
////
unsigned int AccelerationStructure::GetObjDataSize() const
{
  return m_objListData.size();
}

////////////////////////////////////////////////////////////////////////////
////
const ObjectList*	AccelerationStructure::GetObjListByOffsetInBytes(uint offset) const
{
  return (const ObjectList*)(GetObjData()+offset);
}


////////////////////////////////////////////////////////////////////////////
////
AABB3f AccelerationStructure::CalcBindingBox(const PrimitiveList& plist)
{
  // find center
  AABB3f bBox;
  size_t counter = 0;
  PrimitiveList::const_iterator p;

  for(p=plist.begin();p!=plist.end();++p)
    bBox.include(p->Box());

  for(int i=0;i<3;i++)
  {
    bBox.vmin[i] -= MGML_MATH::EPSILON_E5*(bBox.vmax[i]-bBox.vmin[i]);
    bBox.vmax[i] += MGML_MATH::EPSILON_E5*(bBox.vmax[i]-bBox.vmin[i]);
  }

  return bBox;
}

////////////////////////////////////////////////////////////////////////////
////
int AccelerationStructure::PushListInObjectListBuffer(const PrimitiveList& plist)
{
	int sph_count=0, tri_count=0, size = 0;

	PrimitiveList::const_iterator p;
	for(p=plist.begin();p!=plist.end();++p)
	{
		if(p->GetPrimType() == ObjectList::TRIANGLE)
			tri_count++;

		if(p->GetPrimType() == ObjectList::SPHERE)
			sph_count++;

		size += p->SizeInBytes();
	}

  // count size of current object list
	size +=  sizeof(ObjectList);

  if(m_objListData.size() + size >= m_objListData.capacity())
    m_objListData.reserve(m_objListData.capacity()*1.5);

  // save this offset
  int currObjectListOffset = m_objListData.size();

	char* data = m_objListData.begin() + m_objListData.size();
	char* check = data;

  // ������� ������ ��� ������ ObjectList
  //
  char* dataPointer = data;
  int temp[32];
  dataPointer += m_pInputData->WritePrimListProlog(dataPointer,100000,tri_count,sph_count,0,temp);

  // ����� ������ ������������
  //
  for (p=plist.begin();p!=plist.end();++p)
	{
		if (p->GetPrimType() == ObjectList::TRIANGLE)
      dataPointer += m_pInputData->WriteTriangle(p->GetPrimIndex(), dataPointer, 100000);
  }

  // ������ ������ �����
  //
  for(p=plist.begin();p!=plist.end();++p)
	{
		if(p->GetPrimType() == ObjectList::SPHERE)
      dataPointer += m_pInputData->WriteSphere(p->GetPrimIndex(),dataPointer, 100000);
	}

  // compare counted size of current object list and real
	//if(dataPointer - check != size)
	  //RUN_TIME_ERROR("ObjectList data corruption");
  size = dataPointer - check;

  m_objListData.resize(m_objListData.size() + size);

  return currObjectListOffset;
}

////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::StatInfo::StatInfo()
{
  m_pAccelStruct = 0;
  Clear();
}

////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::StatInfo::Clear()
{
  emptyNodes = 0;
  totalNodes = 0;
  leafes = 0;
  avgPrimInLeaf = 0;

	notEmptyLeafesNum = 0;
	maxDeep = 0;
  maxPrimsInLeaf = 0;
  primitiveListMemorySize = 0;
  dublicates = 0;
  totalPrims = 0;
  avgDeep = 0;
}



////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::StatInfo::Print(std::ostream& out, int totalPrimsNum)
{

  if(m_pAccelStruct != NULL)
    out << typeid(*m_pAccelStruct).name() <<" statistics: " << std::endl;

  out << "Nodes:                     " << totalNodes << std::endl;
	out << "Leafes:                    " << leafes << std::endl;
	out << "Empty(leafes):             " << emptyNodes << std::endl;

  int oldPrecision = out.precision(4);
	out << "Avg_Prim (not empty l-fs): " << avgPrimInLeaf << std::endl;
  out << "Max primitives in leaf:    " << maxPrimsInLeaf << std::endl;
  out.precision(oldPrecision);
  out << "ObjList size:              " << primitiveListMemorySize << " bytes" << std::endl;

	//out << "Object List data size:  " << m_objListDataTop << std::endl;
	//out << "object list data top: " << m_objListDataSize << std::endl;

  out << "Avg deep:                  " << avgDeep <<std::endl;
	out << "Max deep:                  " << maxDeep << std::endl;
  out << "Relative SAH:              " << relativeSAH << std::endl;

  out.precision(3);
  out << "Duplicates:                " << 100*(float)dublicates/(float)totalPrimsNum << "%" << std::endl;
  out << "Memory taken by objList:   " << float(m_pAccelStruct->m_objListData.size())/(1024.0f*1024.0f) << " MBytes" << std::endl;

  out.precision(oldPrecision);


}


////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::FreeList(PrimitiveList& l)
{
  PrimitiveList empty;
  l.swap(empty);

  delete [] m_vspheresMemory;
  delete [] m_vtrianglesMemory;
  m_vspheresMemory = 0;
  m_vtrianglesMemory = 0;
}


////////////////////////////////////////////////////////////////////////////
////
float  AccelerationStructure::EstimateCost(const AABB& a_Box, float split_pos, int split_axis, size_t lsumm, size_t rsumm) const
{
  AABB left_box  = a_Box, right_box = a_Box;

  left_box.vmax[split_axis]  = split_pos;
  right_box.vmin[split_axis] = split_pos;

  float left_cost  = (float)lsumm;
  float right_cost = (float)rsumm;

  float summ_cost = (float)EMPTY_NODE_COST_TRAVERSE + (SurfaceArea(left_box)*left_cost + SurfaceArea(right_box)*right_cost);

  return summ_cost;
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::SplitData AccelerationStructure::FindSplitPosTrivialSAH(const PrimitiveList& plist, const AABB3f& a_box)
{
  float foundSplitPos = 0;
  int foundSplitAxis = 0;
  int minPrimsOnLeftSide = 0;
  int minPrimsOnRightSide = 0;
  int currPrimsOnLeftSide = 0;
  int currPrimsOnRightSide = 0;

  bool	subdivideNext = false;
  float minSahValue = SAH_OVERSPLIT_TRESHOLD*plist.size()*SurfaceArea(a_box);
  float3 boxSize = a_box.vmax - a_box.vmin;

  float* boxesMin = (float*)malloc(plist.size()*sizeof(float));
  float* boxesMax = (float*)malloc(plist.size()*sizeof(float));

  AABB4f box(to_float4(a_box.vmin,0), to_float4(a_box.vmax,0));

  SAH_F<0> sahFuncX(box, plist, this);
  SAH_F<1> sahFuncY(box, plist, this);
  SAH_F<2> sahFuncZ(box, plist, this);

  sahFuncX.m_pBoxMin = boxesMin;
  sahFuncX.m_pBoxMax = boxesMax;
  sahFuncY.m_pBoxMin = boxesMin;
  sahFuncY.m_pBoxMax = boxesMax;
  sahFuncZ.m_pBoxMin = boxesMin;
  sahFuncZ.m_pBoxMax = boxesMax;

  for(int minOrMax = 0; minOrMax < 2; minOrMax++)
  {
    for(int axis=0;axis<3;axis++)
    {
      // rearrange data to be more efficient for simd
      //
      for(uint i=0;i<plist.size();i++)
      {
        const AABB3f& box = plist[i].Box();
        boxesMin[i] = box.vmin[axis];
        boxesMax[i] = box.vmax[axis];
      }

      for(PrimitiveList::const_iterator p=plist.begin();p!=plist.end();++p)
      {
        float splitPos;
        if(minOrMax==0)
          splitPos = p->Box().vmin[axis];
        else
          splitPos = p->Box().vmax[axis];

        if(splitPos <= a_box.vmin[axis] || splitPos >= a_box.vmax[axis])
          continue;

        float currSahValue = 0;
        switch(axis)
        {
        case 0:
          currSahValue = sahFuncX(splitPos);
          currPrimsOnLeftSide  = sahFuncX.GetPrimsOnLeftSide();
          currPrimsOnRightSide = sahFuncX.GetPrimsOnRightSide();
          break;

        case 1:
          currSahValue = sahFuncY(splitPos);
          currPrimsOnLeftSide  = sahFuncY.GetPrimsOnLeftSide();
          currPrimsOnRightSide = sahFuncY.GetPrimsOnRightSide();
          break;

        case 2:
          currSahValue = sahFuncZ(splitPos);
          currPrimsOnLeftSide  = sahFuncZ.GetPrimsOnLeftSide();
          currPrimsOnRightSide = sahFuncZ.GetPrimsOnRightSide();
          break;
        };

        if (currSahValue < minSahValue && !SplitCloseToBoxBoundary(splitPos, axis, a_box))
        {
          subdivideNext = true;
          minSahValue = currSahValue;
          foundSplitPos = splitPos;
          foundSplitAxis = axis;
          minPrimsOnLeftSide  = currPrimsOnLeftSide;
          minPrimsOnRightSide = currPrimsOnRightSide;
        }
      }
    }
  }

  free(boxesMin);
  free(boxesMax);

  if(subdivideNext && SplitCloseToBoxBoundary(foundSplitPos,foundSplitAxis,a_box))
    subdivideNext = false;

  SplitData res;
  res.axis = foundSplitAxis;
  res.pos  = foundSplitPos;
  res.sah  = minSahValue;
  res.subdivideNext    = subdivideNext;
  res.primsOnLeftSide  = minPrimsOnLeftSide;
  res.primsOnRightSide = minPrimsOnRightSide;
  return res;
}

////////////////////////////////////////////////////////////////////////////
////
bool AccelerationStructure::FoundAlreadySplitedAAReferences(const AABB3f& a_box, PrimitiveList& prims, float min_split, int min_axis)
{
  // Now, solve a problem of fucking axis aligned triangles.
  // This problem arise when we have axis aligned triangles and we have
  // a split position on such triangle. And this is shit.
  // This need to be checked because actually triangles that are not axis aligned but overlap the plane
  // may be processed incorrectly
  //

  for(uint i=0;i<prims.size();i++)
  {
    if(prims[i].AxisAligned(min_axis, min_split))
    {
      if(prims[i].ExistSplitOnThatPlane(min_axis, min_split))
        return true;

      prims[i].MemorizeExistSplit(min_axis, min_split);
    }
  }

  return false;
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::SplitData AccelerationStructure::FindSplitPosSortSAH(PrimitiveList& plist, const AABB3f& a_box)
{
  struct CompareMin
  {
    CompareMin(int a_axis) {axis = a_axis;}
    bool operator()(const PrimitiveRef& a, const PrimitiveRef& b) {return a.Box().vmin[axis] < b.Box().vmin[axis];}
    int axis;
  };

  struct CompareMax
  {
    CompareMax(int a_axis) {axis = a_axis;}
    bool operator()(const PrimitiveRef& a, const PrimitiveRef& b){return a.Box().vmax[axis] < b.Box().vmax[axis];}
    int axis;
  };

  PrimitiveList prims = plist;
  float min_sah = SAH_OVERSPLIT_TRESHOLD*SurfaceArea(a_box)*plist.size();
  float min_split = 1e38f;
  int   min_axis = 0;
  float epsilon = 1e-5f;
  int   min_or_max = 0;
  int   minPrimIndex = 0;

  float3 boxSize3 = a_box.vmax - a_box.vmin;
  int longestAxis = 0;

  // if ve have very long box, cut it first
  //
  float maxBoxSize = MAX(boxSize3.x, boxSize3.y, boxSize3.z);

  for(int axis = 0; axis < 3; axis++)
  {
    if(maxBoxSize > 10*boxSize3[axis])
      continue; // skip too thing axis

    // sort primitives belong to current axis and min bounds
    //
    CompareMin comparator(axis);
    std::sort(prims.begin(), prims.end(), comparator);

    for(uint i=1;i<prims.size();i++)
    {
      int onLeftSide = i;
      int onRightSide = prims.size()-i;

      ASSERT(onLeftSide > 0 && onRightSide > 0);

      float split = prims[i].Box().vmin[axis];

      if(split == a_box.vmin[axis])
        continue;

      if(prims[i].ExistSplitOnThatPlane(axis,split))
        continue;

      AABB3f box_left  = a_box;
      AABB3f box_right = a_box;
      box_left.vmax[axis]  = split;
      box_right.vmin[axis] = split;

      float sah = onLeftSide*SurfaceArea(box_left) + onRightSide*SurfaceArea(box_right);

      if (sah < min_sah)
      {
        min_sah = sah;
        min_split = split;
        min_axis = axis;
        min_or_max = 0;
        minPrimIndex = i;
      }
    }

    // sort primitives belong to current axis and max bounds
    //
    CompareMax comparator2(axis);
    std::sort(prims.begin(), prims.end(), comparator2);

    for(int i=prims.size()-2;i>=0;i--)
    {
      int onLeftSide = i+1;
      int onRightSide = prims.size()-i-1;

      ASSERT(onLeftSide > 0 && onRightSide > 0);

      float split = prims[i].Box().vmax[axis];

      if(split == a_box.vmax[axis])
        continue;

      if(prims[i].ExistSplitOnThatPlane(axis,split))
        continue;

      AABB3f box_left = a_box;
      AABB3f box_right = a_box;
      box_left.vmax[axis] = split;
      box_right.vmin[axis] = split;

      float sah = onLeftSide*SurfaceArea(box_left) + onRightSide*SurfaceArea(box_right);

      if (sah < min_sah)
      {
        min_sah = sah;
        min_split = split;
        min_axis = axis;
        min_or_max = 1;
        minPrimIndex = i;
      }
    }
  }

  // if split is bounding box plane, fail, do not split anything!
  //
  bool subdivideNext = true;
  if (min_split == a_box.vmin[min_axis] || min_split == a_box.vmax[min_axis] || FoundAlreadySplitedAAReferences(a_box, plist, min_split, min_axis))
  {
    min_sah = SurfaceArea(a_box)*plist.size();
    subdivideNext = false;
  }
  else if (plist.size() <= 32)
  {
    // recalculate SAH
    //
    AABB3f leftBox  = a_box, rightBox = a_box;
    leftBox.vmax[min_axis]  = min_split;
    rightBox.vmin[min_axis] = min_split;

    int onLeftSide = 0, onRightSide = 0;
    for(uint i=0;i<plist.size();i++)
    {
      bool overlapLeft  = plist[i]->IntersectWithAABB(leftBox);
      bool overlapRight = plist[i]->IntersectWithAABB(rightBox);

      if(overlapLeft)  onLeftSide++;
      if(overlapRight) onRightSide++;
    }

    min_sah = onLeftSide*SurfaceArea(leftBox) + onRightSide*SurfaceArea(rightBox);
  }

  SplitData res;
  res.pos = min_split;
  res.axis = min_axis;
  res.sah = min_sah;
  res.subdivideNext = subdivideNext;
  return res;
}


////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::SplitReference(const PrimitiveRef& a_ref, PrimitiveRef* a_pLeft, PrimitiveRef* a_pRight, float splitPos, int splitAxis)
{
  *a_pLeft = a_ref;
  *a_pRight = a_ref;

  AABB3f& leftBox  = a_pLeft->Box();
  AABB3f& rightBox = a_pRight->Box();
  const AABB3f& nodeBox  = a_ref.Box();

  leftBox = rightBox = AABB3f();

  if (a_ref->GetPrimType() == ObjectList::TRIANGLE && !a_ref.AxisAligned(splitAxis, splitPos))
  {
    float3 verts[3];
    m_pInputData->GetTriangle(a_ref->GetPrimIndex(), verts[0].M, verts[1].M, verts[2].M);

    // !!!!!!!! THIS IS VERY IMPORTANT TO USE (0,2,1), i mean try ALL(0, 1 and 2) vertices as v0.
    // for example  {verts[0], verts[1]}, {verts[0], verts[2]}, verts[1], verts[2] will not work!!!
    //
    float3 edges[3][2] = {  {verts[0], verts[1]},
                            {verts[2], verts[0]},
                            {verts[1], verts[2]} };

    // grow both boxes with vertices and edge-plane intersections
    //
    for (int i=0;i<3;i++)
    {
      float v0p = edges[i][0][splitAxis];
      float v1p = edges[i][1][splitAxis];

      // Insert vertex to the boxes it belongs to.
      //
      if(v0p <= splitPos)
        leftBox.include(edges[i][0]);

      if(v0p >= splitPos)
        rightBox.include(edges[i][0]);

      // Edge intersects the plane => insert intersection to both boxes.
      //
      if ((v0p < splitPos && v1p > splitPos) || (v0p > splitPos && v1p < splitPos))
      {
        float3 t = lerp(edges[i][0], edges[i][1], clamp((splitPos - v0p) / (v1p - v0p), 0.0f, 1.0f));

        leftBox.include(t);
        rightBox.include(t);
      }
    }

  }

  leftBox.vmax[splitAxis] = splitPos;
  rightBox.vmin[splitAxis] = splitPos;

  // Intersect with original bounds.
  //
  leftBox.intersect(nodeBox);
  rightBox.intersect(nodeBox);
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::SplitData AccelerationStructure::FindSplitPosGoldenCutSAH(const PrimitiveList& plist, const AABB3f& a_box)
{
  float splitPos = 0;
  int splitAxis = 0;
  int minPrimsOnLeftSide = 0;
  int minPrimsOnRightSide = 0;
  int currPrimsOnLeftSide = 0;
  int currPrimsOnRightSide = 0;
  bool	subdivideNext = false;
  float minSahValue = SAH_OVERSPLIT_TRESHOLD*plist.size()*SurfaceArea(a_box);
  float3 boxSize = a_box.vmax - a_box.vmin;
  float maxBoxSize = MAX(boxSize.x, boxSize.y, boxSize.z);
  int a_qualityFlag = GetContructionMode();

  AABB4f box(to_float4(a_box.vmin,0), to_float4(a_box.vmax,0));

  SAH_F<0> sahFuncX(box, plist, this);
  SAH_F<1> sahFuncY(box, plist, this);
  SAH_F<2> sahFuncZ(box, plist, this);

  typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<0> > solverX;
  typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<1> > solverY;
  typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<2> > solverZ;

  const int INTERVALS = (a_qualityFlag == KD_TREE_CONSTRUCT_QUALITY) ? 8 : 4;
  const int MAX_ITERATIONS = (a_qualityFlag == KD_TREE_CONSTRUCT_QUALITY) ? 20 : 10;

  solverX::MAX_ITER = MAX_ITERATIONS;
  solverY::MAX_ITER = MAX_ITERATIONS;
  solverZ::MAX_ITER = MAX_ITERATIONS;

  float* boxesMin = (float*)malloc(plist.size()*sizeof(float));
  float* boxesMax = (float*)malloc(plist.size()*sizeof(float));

  if(boxesMin==NULL || boxesMax==NULL)
    RUN_TIME_ERROR("insufficient memory for boxes min and max");

  double sahValue = 1e38;
  float foundSplit = 0;

  for(int axis = 0; axis<3; axis++)
  {
    float intervalLen = boxSize[axis]/(float)INTERVALS;
    float eps = 0.0001f*boxSize[axis];

    // rearrange data to be more efficient for simd
    //
    for(uint i=0;i<plist.size();i++)
    {
      const AABB3f& box = plist[i].Box();
      boxesMin[i] = box.vmin[axis];
      boxesMax[i] = box.vmax[axis];
    }

    for(int interval = 0; interval < INTERVALS; interval++ )
    {
      float begin = interval*intervalLen;
      float end = (interval+1)*intervalLen;

      switch(axis)
      {
      case 0:
        sahFuncX.m_pBoxMin = boxesMin;
        sahFuncX.m_pBoxMax = boxesMax;
        foundSplit = solverX::findMin(sahFuncX, begin, end, eps, &sahValue);
        currPrimsOnLeftSide  = sahFuncX.GetPrimsOnLeftSide();
        currPrimsOnRightSide = sahFuncX.GetPrimsOnRightSide();
        break;

      case 1:
        sahFuncY.m_pBoxMin = boxesMin;
        sahFuncY.m_pBoxMax = boxesMax;
        foundSplit = solverY::findMin(sahFuncY, begin, end, eps, &sahValue);
        currPrimsOnLeftSide  = sahFuncY.GetPrimsOnLeftSide();
        currPrimsOnRightSide = sahFuncY.GetPrimsOnRightSide();
        break;

      case 2:
        sahFuncZ.m_pBoxMin = boxesMin;
        sahFuncZ.m_pBoxMax = boxesMax;
        foundSplit = solverZ::findMin(sahFuncZ, begin, end, eps, &sahValue);
        currPrimsOnLeftSide  = sahFuncZ.GetPrimsOnLeftSide();
        currPrimsOnRightSide = sahFuncZ.GetPrimsOnRightSide();
        break;
      };

      if(SplitCloseToBoxBoundary(foundSplit,axis,a_box))
        continue;

      ASSERT(foundSplit >= a_box.vmin[axis] && foundSplit <= a_box.vmax[axis]);

      if(sahValue < minSahValue)
      {
        subdivideNext = true;
        minSahValue = (float)sahValue;
        splitPos = foundSplit;
        splitAxis = axis;
        minPrimsOnLeftSide  = currPrimsOnLeftSide;
        minPrimsOnRightSide = currPrimsOnRightSide;
      }

    }

  }

  free(boxesMin);
  free(boxesMax);


  // final check
  //
  if(SplitCloseToBoxBoundary(splitPos,splitAxis,a_box))
  {
    //RUN_TIME_ERROR("splitPos near box boundary, must not happen");
    minSahValue = 2.0f*SurfaceArea(a_box)*plist.size();
    subdivideNext = false;
  }



  SplitData res;
  res.axis = splitAxis;
  res.pos  = splitPos;
  res.sah  = minSahValue;
  res.subdivideNext    = subdivideNext;
  res.primsOnLeftSide  = minPrimsOnLeftSide;
  res.primsOnRightSide = minPrimsOnRightSide;
  res.leftBounds = res.rightBounds = a_box;
  res.leftBounds.vmax.M[res.axis]  = res.pos;
  res.rightBounds.vmin.M[res.axis] = res.pos;
  return res;
}

/*
////////////////////////////////////////////////////////////////////////////
////
class FindMinThreadAdapter
{
public:
  FindMinThreadAdapter(){m_thread = NULL; m_SAH = 1e38f;}
  ~FindMinThreadAdapter(){delete m_thread; m_thread = NULL;}

  void start()
  {
    delete m_thread;
    m_thread = new boost::thread(boost::bind(&FindMinThreadAdapter::do_work, this));
  }

  void finish()
  {
    m_thread->join();
    delete m_thread;
    m_thread = NULL;
  }

  void do_work()
  {
    const int MAX_ITERATIONS = (m_qualityFlag == KD_TREE_CONSTRUCT_QUALITY) ? 20 : 10;

    SAH_F<0> sahFuncX(m_box, *m_plist, m_pAccelStruct);
    SAH_F<1> sahFuncY(m_box, *m_plist, m_pAccelStruct);
    SAH_F<2> sahFuncZ(m_box, *m_plist, m_pAccelStruct);

    typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<0> > solverX;
    typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<1> > solverY;
    typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<2> > solverZ;

    solverX::MAX_ITER = MAX_ITERATIONS;
    solverY::MAX_ITER = MAX_ITERATIONS;
    solverZ::MAX_ITER = MAX_ITERATIONS;

    switch(m_axis)
    {
    case 0:
      sahFuncX.m_pBoxMin = m_boxesMin;
      sahFuncX.m_pBoxMax = m_boxesMax;
      m_split = solverX::findMin(sahFuncX, m_begin, m_end, m_eps, &m_SAH);
      m_currPrimsOnLeftSide  = sahFuncX.GetPrimsOnLeftSide();
      m_currPrimsOnRightSide = sahFuncX.GetPrimsOnRightSide();
      break;

    case 1:
      sahFuncY.m_pBoxMin = m_boxesMin;
      sahFuncY.m_pBoxMax = m_boxesMax;
      m_split = solverY::findMin(sahFuncY, m_begin, m_end, m_eps, &m_SAH);
      m_currPrimsOnLeftSide  = sahFuncY.GetPrimsOnLeftSide();
      m_currPrimsOnRightSide = sahFuncY.GetPrimsOnRightSide();
      break;

    case 2:
      sahFuncZ.m_pBoxMin = m_boxesMin;
      sahFuncZ.m_pBoxMax = m_boxesMax;
      m_split = solverZ::findMin(sahFuncZ, m_begin, m_end, m_eps, &m_SAH);
      m_currPrimsOnLeftSide  = sahFuncZ.GetPrimsOnLeftSide();
      m_currPrimsOnRightSide = sahFuncZ.GetPrimsOnRightSide();
      break;
    };

  }

  // in
  //
  AABB4f m_box;
  const AccelerationStructure::PrimitiveList*   m_plist;
  AccelerationStructure* m_pAccelStruct;
  int m_axis;
  const float* m_boxesMin;
  const float* m_boxesMax;
  float m_begin;
  float m_end;
  float m_eps;

  // out
  //
  float m_split;
  double m_SAH;
  int   m_currPrimsOnLeftSide;
  int   m_currPrimsOnRightSide;
  int   m_qualityFlag;

protected:

  boost::thread* m_thread;

};*/



////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::SplitData AccelerationStructure::FindSplitPosGoldenCutSAH_MultiThreaded(const PrimitiveList& plist, const AABB3f& a_box)
{
  /*
  float splitPos = 0;
  int splitAxis = 0;
  int minPrimsOnLeftSide = 0;
  int minPrimsOnRightSide = 0;
  int currPrimsOnLeftSide = 0;
  int currPrimsOnRightSide = 0;
  bool	subdivideNext = false;
  float minSahValue = SAH_OVERSPLIT_TRESHOLD*plist.size()*SurfaceArea(a_box);
  vec4f boxSize = a_box.vmax - a_box.vmin;
  float maxBoxSize = MAX(boxSize.x, boxSize.y, boxSize.z);
  int a_qualityFlag = GetContructionMode();

  SAH_F<0> sahFuncX(a_box, plist, this);
  SAH_F<1> sahFuncY(a_box, plist, this);
  SAH_F<2> sahFuncZ(a_box, plist, this);

  typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<0> > solverX;
  typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<1> > solverY;
  typedef OPTIMIZER<double, GOLDEN_CUT, SAH_F<2> > solverZ;

  const int INTERVALS = (a_qualityFlag == KD_TREE_CONSTRUCT_QUALITY) ? 8 : 4;
  const int MAX_ITERATIONS = (a_qualityFlag == KD_TREE_CONSTRUCT_QUALITY) ? 20 : 10;

  solverX::MAX_ITER = MAX_ITERATIONS;
  solverY::MAX_ITER = MAX_ITERATIONS;
  solverZ::MAX_ITER = MAX_ITERATIONS;

  float* boxesMinX = (float*)_aligned_malloc(plist.size()*sizeof(float), 16);
  float* boxesMaxX = (float*)_aligned_malloc(plist.size()*sizeof(float), 16);

  float* boxesMinY = (float*)_aligned_malloc(plist.size()*sizeof(float), 16);
  float* boxesMaxY = (float*)_aligned_malloc(plist.size()*sizeof(float), 16);

  float* boxesMinZ = (float*)_aligned_malloc(plist.size()*sizeof(float), 16);
  float* boxesMaxZ = (float*)_aligned_malloc(plist.size()*sizeof(float), 16);

  float* boxesMin[3] = {boxesMinX, boxesMinY, boxesMinZ};
  float* boxesMax[3] = {boxesMaxX, boxesMaxY, boxesMaxZ};

  if(boxesMinX==NULL || boxesMaxX==NULL)
    RUN_TIME_ERROR("insufficient memory for boxes min and max");

  if(boxesMinY==NULL || boxesMaxY==NULL)
    RUN_TIME_ERROR("insufficient memory for boxes min and max");

  if(boxesMinZ==NULL || boxesMaxZ==NULL)
    RUN_TIME_ERROR("insufficient memory for boxes min and max");

  double sahValue = 1e38;
  float foundSplit = 0;

  FindMinThreadAdapter* myFindMinThreads = new FindMinThreadAdapter[3*INTERVALS];

  for(int axis = 0; axis<3; axis++)
  {
    float intervalLen = boxSize[axis]/(float)INTERVALS;
    float eps = 0.0001f*boxSize[axis];

    for(uint i=0;i<plist.size();i++)
    {
      const AABB3f& box = plist[i].Box();
      boxesMin[axis][i] = box.vmin[axis];
      boxesMax[axis][i] = box.vmax[axis];
    }

    for(int interval = 0; interval < INTERVALS; interval++ )
    {
      float begin = interval*intervalLen;
      float end = (interval+1)*intervalLen;

      FindMinThreadAdapter* pThread = myFindMinThreads + axis*INTERVALS + interval;

      pThread->m_box   = a_box;
      pThread->m_plist = &plist;
      pThread->m_pAccelStruct = this;
      pThread->m_axis     = axis;
      pThread->m_boxesMin = boxesMin[axis];
      pThread->m_boxesMax = boxesMax[axis];
      pThread->m_begin    = begin;
      pThread->m_end      = end;
      pThread->m_eps      = eps;
      pThread->m_qualityFlag = a_qualityFlag;

      pThread->start();
    }
  }


  for(int axis = 0; axis<3; axis++)
  {
    float intervalLen = boxSize[axis]/(float)INTERVALS;
    float eps = 0.0001f*boxSize[axis];

    for(int interval = 0; interval < INTERVALS; interval++ )
    {
      float begin = interval*intervalLen;
      float end = (interval+1)*intervalLen;

      FindMinThreadAdapter* pThread = myFindMinThreads + axis*INTERVALS + interval;

      pThread->finish();

      float foundSplit = pThread->m_split;
      double sahValue  = pThread->m_SAH;
      currPrimsOnLeftSide  = pThread->m_currPrimsOnLeftSide;
      currPrimsOnRightSide = pThread->m_currPrimsOnRightSide;

      ASSERT(foundSplit >= a_box.vmin[axis] || foundSplit <= a_box.vmax[axis]);

      if(SplitCloseToBoxBoundary(foundSplit,axis,a_box))
        continue;

      if(sahValue < minSahValue)
      {
        subdivideNext = true;
        minSahValue = (float)sahValue;
        splitPos = foundSplit;
        splitAxis = axis;
        minPrimsOnLeftSide  = currPrimsOnLeftSide;
        minPrimsOnRightSide = currPrimsOnRightSide;
      }


    }
  }

  delete [] myFindMinThreads;

  _aligned_free(boxesMinX);
  _aligned_free(boxesMaxX);

  _aligned_free(boxesMinY);
  _aligned_free(boxesMaxY);

  _aligned_free(boxesMinZ);
  _aligned_free(boxesMaxZ);

  // final check
  //
  if(SplitCloseToBoxBoundary(splitPos,splitAxis,a_box))
  {
    //RUN_TIME_ERROR("splitPos near box boundary, must not happen");
    minSahValue = 2.0f*SurfaceArea(a_box)*plist.size();
    subdivideNext = false;
  }

  SplitData res;
  res.axis = splitAxis;
  res.pos  = splitPos;
  res.sah  = minSahValue;
  res.subdivideNext    = subdivideNext;
  res.primsOnLeftSide  = minPrimsOnLeftSide;
  res.primsOnRightSide = minPrimsOnRightSide;
  */
  SplitData res;
  return res;
}





uint AccelerationStructure::GetContructionMode()
{
  uint mode = 0;

  if(m_settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    mode = KD_TREE_CONSTRUCT_QUALITY;
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_FAST)
    mode = KD_TREE_CONSTRUCT_FAST;
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_VERY_FAST)
    mode = KD_TREE_CONSTRUCT_VERY_FAST;
  else
  {
    mode = KD_TREE_CONSTRUCT_QUALITY;
    std::cerr << "KdTreeBuilder: construction quality was not specified, using 'CONSTRUCT_QUALITY' mode";
  }

  return mode;
}







////////////////////////////////////////////////////////////////////////////
////
float AccelerationStructure::SurfaceAreaOfTriangle(const PrimitiveRef& prim)
{
  const VTriangle* pTriangle = dynamic_cast<const VTriangle*>(prim.GetRealPrimitivePointer());

  if(pTriangle==NULL)
    RUN_TIME_ERROR("SurfaceAreaOfTriangle should be called only for triangles");

  Triangle tri;
  pTriangle->GetVertexPositions(&tri);

  return length(cross3(tri.C - tri.A, tri.B - tri.A));
}

float AccelerationStructure::SubdivMetric(PrimitiveRef triRef)
{
  float triSA = SurfaceAreaOfTriangle(triRef);
  float boxSA = SurfaceArea(triRef.Box());
  return boxSA*boxSA/fmaxf(triSA,1e-5f);
}


////////////////////////////////////////////////////////////////////////////
////
AccelerationStructure::PrimitiveList AccelerationStructure::SubdividePrimitive(PrimitiveRef triRef)
{
  std::vector<PrimitiveRef> subdivs;

  float triSA = SurfaceAreaOfTriangle(triRef);
  float boxSA = SurfaceArea(triRef.Box());
  float relation = triSA/boxSA;

  int maxSubdivs; //= (int)(clamp(1.0f/relation,2.0f,128.0f));

  if(relation <= ((1.0f/1024.f)))
    maxSubdivs = 64;
  else if (relation <= ((1.0f/256.f)))
    maxSubdivs = 48;
  else if (relation <= ((1.0f/64.f)))
    maxSubdivs = 32;
  else if (relation <= ((1.0f/32.f)))
    maxSubdivs = 24;
  else if (relation <= ((1.0f/16.f)))
    maxSubdivs = 16;
  else if (relation <= ((1.0f/8.f)))
    maxSubdivs = 8;
  else if (relation <= ((1.0f/4.f)))
    maxSubdivs = 4;
  else
    maxSubdivs = 2;

  subdivs.reserve(maxSubdivs);

  std::queue<PrimitiveRef> queue;
  queue.push(triRef);

  while(!queue.empty())
  {
    PrimitiveRef prim = queue.front(); queue.pop();
    PrimitiveRef a, b;

    float3 boxSize = prim.Box().vmax - prim.Box().vmin;
    float splitPos = 0;
    int splitAxis = 0;
    float maxSize = -1;
    for(int i=0;i<3;i++)
    {
      if(maxSize < boxSize[i])
      {
        splitPos = prim.Box().center()[i];
        splitAxis = i;
        maxSize = boxSize[i];
      }
    }

    SplitReference(prim, &a, &b, splitPos, splitAxis);

    if(HaveToBeToSplited(a) && (queue.size() + subdivs.size() <= maxSubdivs) )
      queue.push(a);
    else
      subdivs.push_back(a);

    if(HaveToBeToSplited(b) && (queue.size() + subdivs.size() <= maxSubdivs))
      queue.push(b);
    else
      subdivs.push_back(b);
  }

  return subdivs;
}



////////////////////////////////////////////////////////////////////////////
////
void AccelerationStructure::EarlySplitClipping(PrimitiveList& a_plist, const AABB3f& boundingBoxOfScene)
{
  std::cerr << "early split clipping...\n";
  int lastId = 0;

  m_sceneBBoxSA = SurfaceArea(boundingBoxOfScene);

  m_primsCountBeforeEarlySplitClipping = a_plist.size();

  // calc subdiv threshold for early split clipping
  //
  if(m_settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    m_minPrimSA_OK = 0.000005f*SurfaceArea(boundingBoxOfScene);
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_QUALITY)
    m_minPrimSA_OK = 0.0000075f*SurfaceArea(boundingBoxOfScene);
  else if(m_settings.flags & AccelStructSettings::CONSTRUCT_FAST)
    m_minPrimSA_OK = 0.00001f*SurfaceArea(boundingBoxOfScene);
  else
    m_minPrimSA_OK = SurfaceArea(boundingBoxOfScene); // no split clipping

  unsigned int numTriangles = m_pInputData->GetNumTriangles();

  // sort primitives accorting to their needs to be splitted
  //
  struct CompareGreater
  {
    bool operator()(const PrimitiveRef& a, const PrimitiveRef& b) {return (a->m_aux > b->m_aux);}
  };
  for(size_t i=0;i<a_plist.size();i++)
    a_plist[i]->m_aux = SubdivMetric(a_plist[i]);

  std::sort(a_plist.begin(), a_plist.end(), CompareGreater());
  // \\ sort

  int totalSubdivs = 0;
  int maxSubdivs = (MemoryExpansionFactor(m_settings)-1)*numTriangles - MemoryExpansionFactor(m_settings) - 1;

  PrimitiveList plist;
  plist.reserve(a_plist.size()*MemoryExpansionFactor(m_settings) + 1000);

  for(size_t i=0;i<a_plist.size();i++)
  {
    PrimitiveRef triRef = a_plist[i];

    if(HaveToBeToSplited(triRef) && totalSubdivs < maxSubdivs)
    {
      std::vector<PrimitiveRef> subdivPrims = SubdividePrimitive(triRef);

      for(int i=0;i<subdivPrims.size();i++)
        plist.push_back(subdivPrims[i]);

      totalSubdivs      += (subdivPrims.size()-1);
      m_stat.dublicates += (subdivPrims.size()-1);
      lastId = plist.size();
    }
    else
      plist.push_back(triRef);
  }

  if(totalSubdivs >= maxSubdivs)
    std::cerr << "Memory was exhausted when " << 100.0f*(float)lastId/plist.size() << " % prims processed" << endl;
  else
    std::cerr << "Early split clipping memory usage: " << 100.0f*totalSubdivs/maxSubdivs << " %" << endl;

  a_plist = plist;
}




