#ifndef KD_TREE_BUILDER_REF_VFROLOV_GUARDIAN
#define KD_TREE_BUILDER_REF_VFROLOV_GUARDIAN

#include "IKdTreeBuilder.h"

namespace RAYTR
{
  class KdTree;
}

class KdTreeBuilderRef_vfrolov : public IKdTreeBuilder
{
public:

  KdTreeBuilderRef_vfrolov();
  ~KdTreeBuilderRef_vfrolov();

  void Build(const InputData* pInData, AccelStructSettings settings);

  KdTreeNode* GetKdTree() const;
  int GetKdTreeArraySize() const;

  const char* GetPrimitiveListsArray() const;
  int GetPrimitiveListsArraySize() const;

  AccelStructStatistics GetStatistics() const;
  void GetBoundingBox(float vmin[3], float vmax[3]) const;

  const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const;

  int MemoryExpansionFactor(AccelStructSettings settings) const;

protected:
  // closed copy constructor and operator=()
  //
  KdTreeBuilderRef_vfrolov(const KdTreeBuilderRef_vfrolov& arg){}
  KdTreeBuilderRef_vfrolov& operator=(const KdTreeBuilderRef_vfrolov& arg) {return *this;}

  RAYTR::KdTree* m_pMyKdTree;
};

#endif
