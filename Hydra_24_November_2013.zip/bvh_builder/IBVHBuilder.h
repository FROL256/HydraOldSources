#pragma once

#include <iostream>

#ifndef KD_TREE_LAYOUT_GUARDIAN
  #include "../bvh_builder/kd_tree_layout.h"
#endif

#ifndef BVH_LAYOUT_GUARDIAN
  #include "BVH_layout.h"
#endif

#include "../bvh_builder/IKdTreeBuilder.h"


#pragma warning(disable:4290) // warning about unsupported exeption specifications, like 'throw (std::runtime_error)' by msvc compiler


class IBVHBuilder
{
public:

  IBVHBuilder(){}
  virtual ~IBVHBuilder(){}

  typedef IKdTreeBuilder::InputData InputData;

  virtual void Build(const InputData* pInData, AccelStructSettings settings) = 0;

  virtual const BVHNode* GetBVH() const = 0;
  virtual int GetBVHArraySize() const = 0;

  virtual const char* GetPrimitiveListsArray() const = 0;
  virtual int GetPrimitiveListsArraySize() const = 0; // return primitive array size in bytes or in float4(!).

  virtual AccelStructStatistics GetStatistics() const = 0;

  virtual void GetBoundingBox(float vmin[3], float vmax[3]) const = 0;

  //virtual void

  // NEVER use this function. For Developers only.
  //
  virtual const void* GetSpecificDataStructurePointer(const std::string& a_dataStructureName) const {return NULL;}

  // this function calculates approximately memory usage factor
  // for example, if MemoryExpansionFactor() == 2 and you have N prims, the output buffer may require 2*N*sizeof(YourSpecificPrimitiveStructure)
  //
  virtual int MemoryExpansionFactor(AccelStructSettings settings) const { return 4; }  // for BVH 4 by default

private:
  IBVHBuilder(const IBVHBuilder& arg){}
  IBVHBuilder& operator=(const IBVHBuilder& arg) {return *this;}
};



