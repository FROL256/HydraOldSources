// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#define KD_TREE_GUARDIAN


#ifndef ACCEL_STRUCT_GUARDIAN
  #include "AccelerationStructure.h" 
#endif

#ifndef KD_TREE_LAYOUT_GUARDIAN
  #include "../bvh_builder/kd_tree_layout.h"
#endif


namespace RAYTR
{


#ifndef __CUDACC__


class KdTree : public AccelerationStructure
{
	typedef MGML_MATH::VECTOR<4,float>			vec;
	
public:
  
  struct Node
  {
    Node()
    {
      left = NULL;
      right = NULL;
      pPrimitiveList = NULL;
      nodeId = -1;
    }

    bool Leaf() const {return (left==0) && (right==0);}

    Node* left;
    Node* right;

    int nodeId;
    int splitAxis;
    float split;

    AABB3f box;
    PrimitiveList* pPrimitiveList;
  };

  Pool<Node> m_nodesPool;

	KdTree();
	~KdTree();

  void Draw() const;

	unsigned int GetNumNodes() const	{ return m_kdNodesTop; }
	inline KdTreeNode*	GetRoot() const { return m_root; }

	inline const char*	GetObjData() const	{ return m_objListData.begin(); }
	inline unsigned int GetObjDataSize() const { return m_objListData.size(); }

	inline KdTreeNode	GetNodeByOffset(unsigned int offset) const 
  {
    ASSERT(m_root!=0);
    return m_root[offset];
  }
	const ObjectList*	GetObjListByOffsetInBytes(unsigned int offset) const { return (const ObjectList*)(GetObjData()+offset) ;}

	void Build();
  
  inline unsigned int GetRootOffset() const {return 0;}

  float GetExactSah();

  void verifyObjectList();
  void DebugDrawDynamicTree() const; 

  const Node* DebugTree() const {return m_root2;}

  float MemoryExpansionFactor(AccelStructSettings settings) const 
  { return (float)(CalcKdTreeMemoryExpansionFactor(settings)); }

protected:
	
	unsigned int NUM_PRIMS_IN_LEAF;
  unsigned int BINNING_PLANES_NUMBER;
  unsigned int OBJECT_LIST_MAX_MEMORY_SIZE;

protected:

	KdTree& operator=(const KdTree& t) 
  { throw std::runtime_error("KdTree copy forbidden"); return (KdTree&)t; }
	
	KdTreeNode*   m_root;
	uint m_kdNodesTop;
	uint m_kdNodesSize;
	
  Node* m_root2;
  bool m_debugOutKdTree;

	void DrawBox(const AABB3f&) const;

	void  NewNodePair(KdTreeNode* curr_node, KdTreeNode** left, KdTreeNode** right);

  // for SAH
  SplitData FindSplitPosCenter(const AABB& a_Box);
  SplitData FindSplitPosCenter(const AABB3f& a_Box);

	void InsertListInLeaf(KdTreeNode* curr_node,const PrimitiveList& plist);
	void Subdivide(KdTreeNode* a_Node, const AABB3f& a_Box, int a_Depth, PrimitiveList& plist, float a_progressStart, float a_progressEnd);
  
  SplitData FindObjectSplit(const PrimitiveList& a_plist, const AABB3f& a_box);

  void DynamicTreeToArrayLayout(KdTreeNode* a_Node, const Node* node);
	
  Node* Subdivide2(Node* a_Node, int a_Depth, PrimitiveList& prims, int a_flags);
  Node* Build2(uint mode);
  void ReleaseDynamicTreeRes(Node* a_node);
  //void InsertListInLeaf(KdTreeNode* curr_node, const PrimitiveList& plist);

  bool FoundAlreadySplitedAAReferences(const AABB3f& a_box, PrimitiveList& plist, float min_split, int min_axis);
  void DebugDrawNode(Node* a_node) const;

  float PrimsSubdivideFactor() const {return 4;}

protected:

  GLUquadricObj* QuadrObj; 

  void DebugLeafDrawGeometry(KdTreeNode a_node) const;
  void DebugLeafDrawGeometry(const Node* node) const;
	void DebugTest(const KdTreeNode* node,int deep);
  void DebugCollectStatistics();
  void DebugCollectStatistics(Node* node);
	void DebugCollectStatisticsRec(const KdTreeNode* node, uint curr_deep);
  void DebugCollectStatisticsRec(const KdTree::Node* node, uint curr_deep);
  float GetExactSahRec(int a_nodeOffset, const AABB3f& box);
	void OutStatistics();

  void DrawNode(const AABB3f& box, int offset) const;

  bool m_useEarlySplitCliping;
};


#endif


}

