#pragma once

#include <iostream>
#include <math.h>

using namespace std;

class GOLDEN_CUT{};


#define SHFT(a,b,c,d)  (a)=(b);(b)=(c);(c)=(d);


template
<
  class T,
  class Method,
  class func
>
struct OPTIMIZER
{ 
  T findMin(func a_f, T a_start, T a_end, T a_eps) { return 0;} 
};



template<class T, class func>
struct OPTIMIZER<T,GOLDEN_CUT,func>
{
  static int itercount1;
  static int MAX_ITER; // = 10

  static int minbrack (const func& fun, T *ax, T *bx, T *cx, T *fa, T *fb, T *fc)
  {
    const T GOLD = 1.618033988749894848;
    const T GLIMIT = 100.0;
    const T TINY = 1.0e-5;
    T ulim, u, fu, r, q, tmp;
    int iter = 0;

    *fa = fun(*ax);
    *fb = fun(*bx);
    if (*fb > *fa) {
      SHFT(tmp,*ax,*bx,tmp)
        SHFT(tmp,*fa,*fb,tmp)
    }

    *fc = fun( *cx = *bx + GOLD*(*bx - *ax) );

    while (*fb >= *fc) {

      if(iter >= MAX_ITER)
        break;

      iter++;

      r = (*bx - *ax) * (*fb - *fc);
      q = (*bx - *cx) * (*fb - *fa);
      tmp = (fabs(q-r) > TINY) ? fabs(q-r) : TINY;
      if (q < r) tmp = -tmp;
      u = *bx - ( (*bx - *cx)*q - (*bx - *ax)*r ) / ( 2.0*tmp );
      ulim = *bx + GLIMIT*(*cx - *bx);

      if ((*bx - u) * (u - *cx) > 0.0) {
        fu = fun (u);
        if (fu < *fc) {
          *ax = *bx;
          *fa = *fb;
          *bx = u;
          *fb = fu;
          break;
        }
        else if (fu > *fb) {
          *cx = u;
          *fc = fu;
          break;
        }
        fu = fun( u = *cx + GOLD*(*cx - *bx) );
      }
      else if ((*cx - u) * (u - ulim) > 0.0) {
        fu = fun (u);
        if (fu < *fc) {
          SHFT(*bx,*cx,u,*cx+GOLD*(*cx-*bx))
            SHFT(*fb,*fc,fu,fun(u))
        }
      }
      else if ((u - ulim) * (ulim - *cx) >= 0.0) {
        u = ulim;
        fu = fun (u);
      }
      else {
        u = *cx + GOLD*(*cx - *bx);
        fu = fun (u);
      }

      SHFT(*ax,*bx,*cx,u)
        SHFT(*fa,*fb,*fc,fu)
    }

    if (*ax > *cx) {
      SHFT(tmp,*ax,*cx,tmp)
        SHFT(tmp,*fa,*fc,tmp)
    }
    return iter;
  }

  static T golden(const func& fun, T ax, T bx, T cx, T tol, T* pRes)
  {
    T x0, x1, x2, x3, f1, f2;
    const T R = 0.618033988749894848;
    const T C = 0.381966011250105152;  /* C = 1 - R */

    itercount1 = 1;
    int iter=0;

    x0 = ax;
    x3 = cx;
    if (fabs(cx-bx) > fabs(bx-ax)) {
      x1 = bx;
      x2 = bx + C*(cx-bx);
    }
    else {
      x2 = bx;
      x1 = bx - C*(bx-ax);
    }

    f1 = fun(x1);
    f2 = fun(x2);

    while (abs(x3-x0) > tol*(abs(x1)+abs(x2))) {

      itercount1++;
      iter++;

      if(iter >= MAX_ITER)
        break;

      if (f2 < f1) {
        SHFT(x0,x1,x2,R*x1+C*x3)
          f1 = f2;
        f2 = fun (x2);
      }
      else {
        SHFT(x3,x2,x1,R*x2+C*x0)
          f2 = f1;
        f1 = fun (x1);
      }
    }
    *pRes = f2;
    return (f1 < f2) ? x1 : x2;
  }

  static T findMin(const func& a_f, T a_start, T a_end, T a_eps, T* pRes) 
  { 
    T ax = a_start;
    T cx = a_end;
    T bx = 0.5*(ax+cx);
    T aval = 0, bval = 0, cval = 0;

    minbrack(a_f, &ax, &bx, &cx, &aval, &bval, &cval);
    
    itercount1 = 0;

    return golden(a_f, ax, bx, cx, a_eps, pRes);
  }

};

template<class T, class func>
int OPTIMIZER<T,GOLDEN_CUT,func>::itercount1 = 0;

template<class T, class func>
int OPTIMIZER<T,GOLDEN_CUT,func>::MAX_ITER = 10;
