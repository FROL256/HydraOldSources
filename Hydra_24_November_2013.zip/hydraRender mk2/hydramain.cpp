
#include "maxincl.h"
#include "hydrarender.h"
#include "resource.h"

HINSTANCE hInstance;
extern ClassDesc* GetHydraRenderDesc();

//***************************************************************************
// DllMain.
// Grab instance handle and initialize controls
//***************************************************************************

BOOL WINAPI DllMain(HINSTANCE hinstDLL,ULONG fdwReason,LPVOID lpvReserved) 
{
  if( fdwReason == DLL_PROCESS_ATTACH )
  {
    hInstance = hinstDLL;
    DisableThreadLibraryCalls(hInstance);
  }

  return (TRUE);
}


//***************************************************************************
// This is the interface to MAX:
//***************************************************************************

__declspec( dllexport ) const TCHAR * LibDescription() { return GetString (IDS_LIB_DESCRIPTION); }

/// MUST CHANGE THIS NUMBER WHEN ADD NEW CLASS
__declspec( dllexport ) int LibNumberClasses() {return 1;}


__declspec( dllexport ) ClassDesc* LibClassDesc(int i) 
{
	switch(i) 
  {
		case 0: return GetHydraRenderDesc();
		default: return 0;
	}
}


//***************************************************************************
// Return version so can detect obsolete DLLs
//***************************************************************************

__declspec( dllexport ) ULONG LibVersion() { return VERSION_3DSMAX; }


//***************************************************************************
// Class descriptor
//***************************************************************************

class HydraRenderClassDesc : public ClassDesc 
{
public:
	int 			    IsPublic() {return 1;}
	void *			  Create(BOOL loading = FALSE) {return new HydraRender;}
	const TCHAR*	ClassName()    {return RENDERNAME;}
	SClass_ID		  SuperClassID() {return RENDERER_CLASS_ID;}
	Class_ID		  ClassID()      {return HYDRAREND_CLASS_ID;}
	const TCHAR* 	Category()     {return _T("Renderer");}
};

static HydraRenderClassDesc HydraRenderDesc;
ClassDesc* GetHydraRenderDesc() {return &HydraRenderDesc;}


//***************************************************************************
// String resource utility function
//***************************************************************************

TCHAR *GetString(int id)
{
	static TCHAR buf[256];

	if (hInstance)
		return LoadString(hInstance, id, buf, sizeof(buf)) ? buf : NULL;
	return NULL;
}


