#include "maxincl.h"
#include "resource.h"
#include "hydrarender.h"

#include "3dsmaxport.h"

extern HINSTANCE hInstance;
static INT_PTR CALLBACK HydraRenderParamDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);


class HydraRenderParamDlg : public RendParamDlg 
{
   public:
      HydraRender *rend;
      IRendParams *ir;
      HWND hPanel;
      BOOL prog;

      HydraRenderParamDlg(HydraRender *r,IRendParams *i,BOOL prog);
      ~HydraRenderParamDlg();
      void AcceptParams();
      void RejectParams();
      void DeleteThis() {delete this;}
      void InitParamDialog(HWND hWnd);
      void InitProgDialog(HWND hWnd);
};


static const Class_ID kTabClassID(0x4ed55c11, 0x217574a0);

HydraRenderParamDlg::HydraRenderParamDlg(HydraRender *r, IRendParams *i, BOOL prog)
{
  rend       = r;
  ir         = i;
  this->prog = prog;

  // this enables GUI, but also will invoke ghosts of computer and brake your fonts
  //
  //hPanel = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_CCJRENDERDLG), HydraRenderParamDlgProc, L"Hydra Renderer", (LPARAM)this);

}

HydraRenderParamDlg::~HydraRenderParamDlg()
{
  ir->DeleteRollupPage(hPanel);
}


void HydraRenderParamDlg::InitProgDialog(HWND hWnd)
{

}


void HydraRenderParamDlg::InitParamDialog(HWND hWnd)
{
   SendDlgItemMessage(hWnd, IDC_ACCTYPE, CB_ADDSTRING, 0, (LPARAM)"kd tree");
   SendDlgItemMessage(hWnd, IDC_ACCTYPE, CB_ADDSTRING, 0, (LPARAM)"bvh");
   SendDlgItemMessage(hWnd, IDC_CONSTRMODE, CB_ADDSTRING, 0, (LPARAM)"quality");
   SendDlgItemMessage(hWnd, IDC_CONSTRMODE, CB_ADDSTRING, 0, (LPARAM)"fast");
   SendDlgItemMessage(hWnd, IDC_CONSTRMODE, CB_ADDSTRING, 0, (LPARAM)"very fast");
   SendDlgItemMessage(hWnd, IDC_RENDER, CB_ADDSTRING, 0, (LPARAM)"OpenGL");
   SendDlgItemMessage(hWnd, IDC_RENDER, CB_ADDSTRING, 0, (LPARAM)"Ray_tracer");


   CheckDlgButton(hWnd, IDC_GEOMETRY, rend->incl.geometry); 
   CheckDlgButton(hWnd, IDC_MATERIALS, rend->incl.materials); 
   CheckDlgButton(hWnd, IDC_LIGHTS, rend->incl.lights);
   SetDlgItemText(hWnd, IDC_DUMP_PATH, s2ws(rend->incl.sceneDumpName).c_str());
   SetDlgItemText(hWnd, IDC_COLLADA_PATH, s2ws(rend->incl.colladaProfile).c_str());
   SetDlgItemText(hWnd, IDC_SERVER_IP, s2ws(rend->server_IP).c_str());
  
   SendDlgItemMessage(hWnd, IDC_ACCTYPE, CB_SELECTSTRING, -1, (LPARAM)rend->incl.AccType.c_str());
   SendDlgItemMessage(hWnd, IDC_CONSTRMODE, CB_SELECTSTRING, -1, (LPARAM)rend->incl.ConstrMode.c_str());
   SendDlgItemMessage(hWnd, IDC_CONSTRMODE, CB_SELECTSTRING, -1, (LPARAM)rend->incl.render_type.c_str());
}


void HydraRenderParamDlg::AcceptParams()
{
   int index;

   rend->incl.geometry = IsDlgButtonChecked(hPanel, IDC_GEOMETRY); 
   rend->incl.materials = IsDlgButtonChecked(hPanel, IDC_MATERIALS);
   rend->incl.lights = IsDlgButtonChecked(hPanel, IDC_LIGHTS);

   GetDlgItemTextA(hPanel, IDC_DUMP_PATH, (LPSTR)rend->incl.sceneDumpName.c_str(), 128); 

   GetDlgItemTextA(hPanel, IDC_COLLADA_PATH, (LPSTR)rend->incl.colladaProfile.c_str(), 128); 
   
   GetDlgItemTextA(hPanel, IDC_SERVER_IP, (LPSTR)rend->server_IP.c_str(), 128); 

   index = SendDlgItemMessage(hPanel, IDC_ACCTYPE, CB_GETCURSEL, 0, 0);
   SendDlgItemMessage(hPanel, IDC_ACCTYPE, CB_GETLBTEXT, index, (LPARAM)rend->incl.AccType.c_str());

   index = SendDlgItemMessage(hPanel, IDC_CONSTRMODE, CB_GETCURSEL, 0, 0);
   SendDlgItemMessage(hPanel, IDC_CONSTRMODE, CB_GETLBTEXT, index, (LPARAM)rend->incl.ConstrMode.c_str());

   index = SendDlgItemMessage(hPanel, IDC_RENDER, CB_GETCURSEL, 0, 0);
   SendDlgItemMessage(hPanel, IDC_RENDER, CB_GETLBTEXT, index, (LPARAM)rend->incl.render_type.c_str());  
}



void HydraRenderParamDlg::RejectParams()
{
}


static INT_PTR CALLBACK HydraRenderParamDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitParamDialog(hWnd);
        }
        break;

      case WM_DESTROY:
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}


RendParamDlg *HydraRender::CreateParamDialog(IRendParams *ir,BOOL prog)
{
  return new HydraRenderParamDlg(this, ir, prog);
}


BaseInterface* HydraRender::GetInterface ( Interface_ID id )
{
  if ( id == TAB_DIALOG_OBJECT_INTERFACE_ID ) 
  {
    ITabDialogObject* r = this;
    return r;
  }
  else 
    return Renderer::GetInterface ( id );
}

// The width of the render rollout in dialog units.
static const int kRendRollupWidth = 222;

// ITabDialogObject
// Add the pages you want to the dialog. Use tab as the plugin
// associated with the pages. This will allows the manager
// to remove and add the correct pages to the dialog.
void HydraRender::AddTabToDialog ( ITabbedDialog* dialog, ITabDialogPluginTab* tab )
{
  dialog->AddRollout ( GetString( IDS_TAB_ROLLOUT ), NULL, kTabClassID, tab, -1, kRendRollupWidth, 0, 0, ITabbedDialog::kSystemPage );
}

// The Class_ID for the blur raytracer globals, which is also
// used by the plugin tab to identify itself.
static const Class_ID blurRaytrace ( 0x4fa95e9b, 0x9a26e66 );

// Return a combination of TAB_DIALOG_ADD_TAB and TAB_DIALOG_REMOVE_TAB
// to indicate whether the pages for the plugin tab are to be
// added or removed. TAB_DIALOG_REMOVE_TAB is only needed to
// both remove and add the plugin tab's pages. If the pages
// are not added, they will be removed.
int HydraRender::AcceptTab ( ITabDialogPluginTab* tab )
{
   switch ( tab->GetSuperClassID ( ) ) {
   case RADIOSITY_CLASS_ID:
      return 0;         // Don't show the advanced lighting tab
   }

   Class_ID id = tab->GetClassID ( );
   if ( id == blurRaytrace )
      return 0;         // Don't show the blur raytracer tab

   // Accept all other tabs
   return TAB_DIALOG_ADD_TAB;
}

