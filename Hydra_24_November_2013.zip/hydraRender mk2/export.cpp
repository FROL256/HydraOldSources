#include "HydraRender.h"
#include <hash_map>

using boost::asio::ip::tcp;

static BOOL exportSelected;


int	HydraRender::DoExport(INode* root, ViewParams* a_viewParams)
{
  incl.IncludeAdd(); // temporary solution while our guis is down

  plugin_log.Print("Entering HydraRender::DoExport");

  // clear all states
  //
  materialByName.clear();
  material_dict_max_index.clear();
  mtlList.Clear();


  nTotalNodeCount = 0;
  nCurNode = 0;
 
  PreProcess(root, nTotalNodeCount);	

  std::vector<MaterialObj> materials; materials.reserve(1000);
  std::vector<LightObj>    lights;    lights.reserve(100);
  std::vector<SphereObj>   spheres;
  std::vector<CameraObj>   cameras;
 
  cameras.push_back( ExtractCamObjFromMaxViewPortWindow(a_viewParams) ); // add first cam from active Max ViewPort

  // extract spheres, geometry(right now it is packed directy to boost archive), materials and lights from max
  //
  {
    ExtractMaterialList(&materials);
    incl.geomObjNum = ExtractAndDumpSceneData(materials, lights, spheres, cameras, root);
  }

  // export materials, light and cameras to XML
  //
  {
    std::ofstream xmlFile;
    xmlFile.open(incl.colladaProfile.c_str());

    if(!xmlFile.is_open())
    {
      plugin_log.PrintValue(incl.colladaProfile, "could not create XML export file");
      return 0;
    }

    xmlFile << "<?xml version=\"1.0\" encoding=\"utf-8\"?>" << std::endl;
    xmlFile << "<COLLADA profile=\"HydraProfile\">" << std::endl;

    ExportMaterialsXML(xmlFile, materials);
    ExportLightsXML(xmlFile, lights);
    ExportCamerasXML(xmlFile, cameras);

    xmlFile << "</COLLADA>\n";


    xmlFile.flush();
    xmlFile.close();
  }

  std::wstring configFile(L"C:/[Hydra]/pluginFiles/hydra.CONF");

  if(!CreateConfigFile(configFile))
  {
    plugin_log.Print("Config file creation failed");
    return 0;
  }

  if(!FileTransfer(configFile))
  {
    plugin_log.Print("Config file transfer failed");
    return 0;
  }


  std::wstring path = GetCOREInterface()->GetCurFilePath();

  std::wstring sceneFileName = GetCOREInterface()->GetCurFileName();

  size_t found = path.find(sceneFileName);
  if (found != std::wstring::npos)
    path.erase(found, sceneFileName.size());

 
  std::set<std::wstring> transferedTextures;

  std::vector<MaterialObj>::iterator mat;
  for(mat = materials.begin(); mat != materials.end(); ++mat)
  {
    std::vector<TextureObj>::iterator tex;
    for(tex = mat->textures.begin(); tex != mat->textures.end(); ++tex)
    {
      if( (tex->mapName != L"") && (transferedTextures.find(tex->mapName) == transferedTextures.end()) )
      { 

        size_t found;
        found = tex->mapName.find_last_of(L"/\\");
        
        std::wstring texFilePath = path + tex->mapName.substr(found+1);

        std::wstring header(L"C:/[Hydra]/pluginFiles/"+tex->mapName.substr(found+1)+L".hhh");

        if(!CreateHeaderFile(header, L"TEXTURE_FILE"))
        {
          plugin_log.PrintValue("Texture file header file not created:", ws2s(tex->mapName));
          return 0;
        }

        if(!FileTransfer(header))
        {
          plugin_log.Print("Texture file header transfer failed");
          return 0;
        }      

        plugin_log.PrintValue("Start sending texture file: ", ToNarrowString(texFilePath));
        if(!FileTransfer(texFilePath))
        {
          plugin_log.Print("Texture file header transfer failed");
          plugin_log.PrintValue("Missing texture file: ", ToNarrowString(texFilePath));
          return 0;
        }
        transferedTextures.insert(tex->mapName);
      }
    }
  }
  
  plugin_log.Print(std::string("incl.colladaProfile = ") + incl.colladaProfile);

 
  
  std::wstring header(s2ws(incl.colladaProfile)+L".hhh");

  if(!CreateHeaderFile(header, L"COLLADA_PROFILE"))
  {
    plugin_log.Print("Collada profile header file not created");
    return 0;
  }

  if(!FileTransfer(header))
  {
    plugin_log.Print("Collada profile header transfer failed");
    return 0;
  }

  if( !FileTransfer(s2ws(incl.colladaProfile)) )
  {
    plugin_log.Print("Collada profile file transfer failed");
    return 0;
  }

  if( !FileTransfer(s2ws(incl.sceneDumpName)) )
  {
    plugin_log.Print("Scene file transfer failed");
    return 0;
  }

  plugin_log.Print("Leaving HydraRender::DoExport");

  return 1;
}


int HydraRender::CreateConfigFile(std::wstring name)
{
  plugin_log.Print("Creating config file");

  std::ofstream configFile;
  configFile.open (name.c_str(), std::ios_base::binary);
  if(configFile.fail())
  {
    system("mkdir C:/[Hydra]/pluginFiles");
    configFile.open(name.c_str(), std::ios_base::binary);

    if(configFile.fail())
    {
      plugin_log.Print("Could not create config file");
      return 0;
    }
  }
  boost::archive::binary_oarchive ar(configFile);

  TransferContents transferConf;
  transferConf.contents = transferConf.CONFIG;

  ar & transferConf;

  ar & incl;

  configFile.close();

  plugin_log.Print("Config file created");

  return 1;
}


int HydraRender::CreateHeaderFile(std::wstring name, std::wstring type)
{
  plugin_log.PrintValue("Creating header file ", ToNarrowString(type));

  std::ofstream headerFile;
  std::string narrowName;

  narrowName = ws2s(name);
  headerFile.open (narrowName.c_str(), std::ios_base::binary);
  if(headerFile.fail())
  {
    plugin_log.Print("Could not create header file");
    return 0;
  }
  boost::archive::binary_oarchive ar(headerFile);

  Header head;
  if(type == L"COLLADA_PROFILE")
    head.contents = head.COLLADA_PROFILE;
  else if (type == L"TEXTURE_FILE")
    head.contents = head.TEXTURE_FILE;

  head.file_name = name;

  TransferContents transferConf;
  transferConf.contents = transferConf.HEADER;

  ar & transferConf;

  ar & head;

  headerFile.close();

  plugin_log.Print("Header file created");
  return 1;
}


CameraObj HydraRender::ExtractCamObjFromMaxViewPortWindow(ViewParams* a_viewParams)
{
  CameraObj cam;

  if(a_viewParams == NULL)
    return cam;
  
  cam.camName = L"maxViewPort";
  MaxMatrix3ToFloat16(a_viewParams->affineTM, cam.worldViewMatrix);

  cam.fov = a_viewParams->fov*RAD_TO_DEG;

  return cam;
}

void HydraRender::ExportMaterialsXML(std::ofstream& matFile, const std::vector<MaterialObj> &materials)
{
  matFile << "<library_materials>\n";

  std::vector<MaterialObj>::const_iterator mat;

  stdext::hash_map<std::string, int> processedNames;

  for(mat = materials.begin(); mat != materials.end(); ++mat)
  {
    std::string matName = ToNarrowString(mat->name);

    if(processedNames.find(matName) != processedNames.end())
      continue;

    processedNames[matName] = 1;

    matFile << "  <material name=\""<< matName.c_str() <<"\">" << std::endl;
    matFile << "  <hydra> " << std::endl << std::endl;

    if(mat->self_illumination > 0.0f)
    {
      matFile << "      <emission>\n";
      matFile << "        <color> " << mat->ambient_color[0]<<" "<<mat->ambient_color[1]<<" "<<mat->ambient_color[2]<<" </color>\n";
      matFile << "        <magnitude> " << mat->self_illumination  << " </magnitude>" << std::endl;         
      matFile << "      </emission>\n"<<std::endl;
    }

    //matFile << "      <ambient>\n";
    //matFile << "        <color> "<<0.05f*mat->ambient_color[0]<<" "<<0.05f*mat->ambient_color[1]<<" "<<0.05f*mat->ambient_color[2]<<" </color>\n";
    //matFile << "      </ambient>\n"<<std::endl;

    matFile << "      <diffuse>\n";
    matFile << "        <color> "<<mat->diffuse_color[0]<<" "<<mat->diffuse_color[1]<<" "<<mat->diffuse_color[2]<<" </color>\n";
    
    std::vector<TextureObj>::const_iterator tex;
    for(tex = mat->textures.begin(); tex != mat->textures.end(); ++tex)
    {
      if((tex->mapName != L""))
      { 
        size_t found;
        found = tex->mapName.find_last_of(L"/\\");
        matFile<<"        <texture>"<<ws2s(tex->mapName.substr(found+1))<<"</texture>\n";
        
        if( abs(tex->uTiling - 1.0) > 1e-5f || abs(tex->vTiling - 1.0f) > 1e-5f )
        {
          matFile<<"        <texture_tiling_u> " << tex->uTiling << "  </texture_tiling_u>" << std::endl;
          matFile<<"        <texture_tiling_v> " << tex->vTiling << "  </texture_tiling_v>" << std::endl;
        }

        if(abs(tex->uOffset) > 1e-5f || abs(tex->vOffset) > 1e-5f)
        {
          matFile<<"        <texture_offset_u> " << tex->uOffset << "  </texture_offset_u>" << std::endl;
          matFile<<"        <texture_offset_v> " << tex->vOffset << "  </texture_offset_v>" << std::endl;
        }

        //if(tex->)
        //matFile<<"        <texture_tiling_u>" << 
      }
    }

    matFile << "      </diffuse>\n"<<std::endl;

    matFile << "      <specular>\n";
    matFile << "        <brdf_type> phong </brdf_type>\n";
    matFile << "        <color> " << 0.75f*mat->specular_color[0]<<" "<< 0.75f*mat->specular_color[1]<<" "<< 0.75f*mat->specular_color[2]<<" </color>\n";
    matFile << "        <cos_power> " << 100*mat->shininess << " </cos_power>\n";
    matFile << "      </specular>\n"<<std::endl;

    matFile << "      <reflectivity>\n";
    matFile << "        <brdf_type> phong </brdf_type>\n";
    matFile << "        <color>"<<0.5*mat->specular_color[0]<<" "<<0.5*mat->specular_color[1]<<" "<<0.5*mat->specular_color[2]<<"</color>\n";
    matFile << "        <IOR>" << mat->IOR << "</IOR>\n";
    matFile << "        <cos_power>" << 100*mat->shininess << "</cos_power>\n";
    matFile << "      </reflectivity>\n" << std::endl;

    if(mat->opacity < 1.0f)
    {
      matFile << "      <transparency>\n";
      matFile << "        <color> " << mat->filter_color[0]*mat->opacity << " " << mat->filter_color[1]*mat->opacity << " " << mat->filter_color[2]*mat->opacity << " </color>\n";
      //matFile << "        <IOR> " << mat->IOR<< " </IOR>\n";
      matFile << "        <IOR> " << 1.01f << " </IOR>\n";
      matFile << "        <thin_surface> 1 </thin_surface>\n";
      matFile << "        <cos_power> 1e+006 </cos_power>\n";
      matFile << "        <fog_color> " << mat->filter_color[0]*mat->opacity << " " << mat->filter_color[1]*mat->opacity << " " << mat->filter_color[2]*mat->opacity << " </fog_color>\n";
      matFile << "        <fog_multiplyer> 0.1 </fog_multiplyer> \n";
      matFile << "        <exit_color> 0.001 0.001 0.001  </exit_color> \n";
 
      matFile << "      </transparency>\n"<<std::endl;
    }

    matFile << "  </hydra>" << std::endl;
    matFile << "  </material>"<< std::endl<<std::endl;
  }

  matFile   << "</library_materials>\n";
 
}

void HydraRender::ExportLightsXML(std::ofstream& xmlFile, const std::vector<LightObj> &lights)
{
  xmlFile << "<library_lights>\n";

  for(size_t i=0;i<lights.size();i++)
  {
    const LightObj& light = lights[i];

    xmlFile << std::endl;
    xmlFile << "  <light name = \"" << ToNarrowString(light.lightName).c_str() << "\"> " << std::endl;
    
    xmlFile << std::endl;
    xmlFile << "    <general>" << std::endl;
    xmlFile << "      <type> ";

    if(light.lightType == L"OMNI")
      xmlFile << "Point";
    else if(light.lightType == L"DIR" || light.lightType == L"TDIR")
      xmlFile << "Directional";
    else if(light.lightType == L"SPOT" || light.lightType == L"TSPOT")
      xmlFile << "Spot";
    else if(light.lightType == L"SKY")
      xmlFile << "Sky";
    else
      xmlFile << "Point";
    
    xmlFile << " </type>" << std::endl;
    
    xmlFile << "      <disable> ";
    if(!light.on)
      xmlFile << "1";
    else
      xmlFile << "0";
    xmlFile << " </disable> " << std::endl;

    if(!light.computeShadow)
      xmlFile << "    <noshadow> 1 </noshadow> " << std::endl;

    xmlFile << "    </general>" << std::endl;

    xmlFile << std::endl;
    xmlFile << "    <position>" << light.position[0] << " " << light.position[1] << " " << light.position[2] << " </position>" << std::endl;

    /*xmlFile << std::endl;
    xmlFile << "    <matrix> " << std::endl;
    for(int k=0;k<4;k++)
    {
      for(int j=0;j<4;j++)
        xmlFile << "      " << light.m[j*4+k] << " ";
      xmlFile << std::endl;
    }
    xmlFile << "    </matrix> " << std::endl;

    xmlFile << std::endl;
    xmlFile << "    <target_matrix> " << std::endl;
    for(int k=0;k<4;k++)
    {
      for(int j=0;j<4;j++)
        xmlFile << "      " << light.targetMatrix[j*4+k] << " ";
      xmlFile << std::endl;
    }
    xmlFile << "    </target_matrix> " << std::endl;
    */

    xmlFile << std::endl;
    xmlFile << "    <intensity> " << std::endl; 
    xmlFile << "      <color> " << light.color[0] << " " << light.color[1] << " " << light.color[2] << " </color> " << std::endl;
    xmlFile << "      <multiplier> " << light.intensity << " </multiplier> " << std::endl;
    xmlFile << "    </intensity> " << std::endl; 


    if(light.lightType == L"SKY" && light.envTexturePath != L"")
    {
      xmlFile << std::endl;
      xmlFile << "    <spheremap> " << std::endl;
      xmlFile << "      <color> " << light.color[0] << " " << light.color[1] << " " << light.color[2] << " </color> " << std::endl; 
      xmlFile << "      <surface> " << ToNarrowString(light.envTexturePath).c_str() << " </surface> " << std::endl;
      xmlFile << "    </spheremap> " << std::endl;
    }

    if(light.lightType == L"SPOT" || light.lightType == L"TSPOT")
    {
      xmlFile << std::endl;
      xmlFile << "    <falloff_angle> " << light.fallsize  << " </falloff_angle> "  << std::endl;
      xmlFile << "    <falloff_angle2> " << light.hotsize  << " </falloff_angle2> "  << std::endl;
    }

    xmlFile << std::endl;
    xmlFile << "    <constant_attenuation>"  << light.kc << "</constant_attenuation>"  << std::endl;
    xmlFile << "    <linear_attenuation>"    << light.kl << "</linear_attenuation>"    << std::endl;
    xmlFile << "    <quadratic_attenuation>" << light.kq << "</quadratic_attenuation>" << std::endl;

    xmlFile << std::endl;
    xmlFile << "  </light>" << std::endl;
  }
  

  xmlFile << "</library_lights>\n";
}


void HydraRender::ExportCamerasXML(std::ofstream& xmlFile, const std::vector<CameraObj>& cameras)
{
  xmlFile << "<library_cameras>\n";

  for(size_t i=0; i < cameras.size(); i++)
  {
    const CameraObj& camera = cameras[i];

    xmlFile << std::endl;
    xmlFile << "  <camera name = \"" << ToNarrowString(camera.camName).c_str() << "\"> " << std::endl;

    xmlFile << std::endl;
    xmlFile << "    <fov> " << camera.fov << " </fov>" << std::endl;
    xmlFile << "    <nearClipPlane> " << camera.nearClipPlane << " </nearClipPlane>" << std::endl;
    xmlFile << "    <farClipPlane> " << camera.farClipPlane << " </farClipPlane>" << std::endl;
    
    if(camera.dofEnabled)
    {
      xmlFile << std::endl;
      xmlFile << "    <DOF> " << std::endl;
      xmlFile << "      <focal_dist> " << camera.dofFocalDist << " </focal_dist>" << std::endl;
      xmlFile << "      <strength> "   << camera.dofStrength  << " </strength>" << std::endl;
      xmlFile << "    </DOF> " << std::endl;
    }

    xmlFile << std::endl;
    xmlFile << "  </camera>" << std::endl;
    
  }

  xmlFile << std::endl;
  xmlFile << "</library_cameras>\n";
}



int HydraRender::ExtractAndDumpSceneData(std::vector<MaterialObj> &materials, std::vector<LightObj> &lights, 
                                         std::vector<SphereObj> &spheres, std::vector<CameraObj>& cameras, INode* root)
{
  int numChildren = root->NumberOfChildren();

  plugin_log.Print("Exporting & creating scene dump");

  /*SetConsoleCP(1251);
  SetConsoleOutputCP(1251);
  setlocale(LC_CTYPE,"Russian");*/

  std::ofstream dump;
  //plugin_log.PrintValue("incl.sceneDumpName: ", incl.sceneDumpName);
  //std::string temp_str(incl.sceneDumpName.begin(), incl.sceneDumpName.end());
  //std::string temp_str = ws2s(incl.sceneDumpName);
  //std::string temp_str = ToNarrowString(incl.sceneDumpName);
  //plugin_log.PrintValue("temp_str: ", temp_str);
  //plugin_log.PrintValue("temp_str.c_str: ", temp_str.c_str());

 // plugin_log.PrintValue("incl.sceneDumpName: ", incl.sceneDumpName);
  //plugin_log.PrintValue("incl.sceneDumpName.c_str: ", incl.sceneDumpName.c_str());

  dump.open(incl.sceneDumpName.c_str(), std::ios_base::binary);
  if(dump.fail())
  {
    plugin_log.Print("Could not create scene dump file");
    return 0;
  }

  boost::archive::binary_oarchive ar( dump );

  TransferContents transferScene;
  transferScene.contents = transferScene.SCENE;

  ar & transferScene;

  if(incl.materials)
  {
    ar & materials;
    plugin_log.Print("Materials........OK");
  }

  int geomObjNum = 0;

  for (int idx=0; idx<numChildren; idx++) 
  {
    nodeEnum(root->GetChildNode(idx), &lights, &spheres, &cameras, ar, geomObjNum);
  }

  plugin_log.Print("Geometry........OK");

  if(spheres.size() != 0)
    incl.spheres = true;
  else 
    incl.spheres = false;
  if(incl.spheres)
  {
    plugin_log.Print("Spheres ?");
    ar & spheres;
  } 
  
  if(incl.lights)
  {
    plugin_log.Print("Lights ?");
    ar & lights;
    plugin_log.Print("Lights........OK");
  }

 /* if(incl.tree)
  {
    plugin_log.Print("Tree ?");
    ar & tree;
    plugin_log.Print("Tree........OK");
  }*/


  dump.close();
  plugin_log.Print("Scene dump created.");

  return geomObjNum;

}

int HydraRender::FileTransfer(std::wstring name)
{
  try
  {
    const unsigned int port = 1234; //port the server listen
    const unsigned int buff_size = 16384; //size of the send buffer

    std::string server_ip_or_host =server_IP+":1234";
    size_t pos = server_ip_or_host.find(':'); 

    std::string port_string = server_ip_or_host.substr(pos+1);
    server_ip_or_host = server_ip_or_host.substr(0, pos);

    boost::asio::io_service io_service;
    tcp::resolver resolver(io_service);
    tcp::resolver::query query(server_ip_or_host, port_string);
    tcp::resolver::iterator endpoint_iterator = resolver.resolve(query);
    tcp::resolver::iterator end;
    tcp::socket socket(io_service);

    boost::system::error_code error = boost::asio::error::host_not_found;

    while (error && endpoint_iterator != end)
    {
      socket.close();
      socket.connect(*endpoint_iterator++, error);
    }

    if (error)
    {
      plugin_log.Print(error);
      return 0;
    }

    plugin_log.PrintValue("connected to ", server_ip_or_host);

    std::ifstream file;
    file.open((ws2s(name)).c_str(), std::ios_base::binary | std::ifstream::in); 

    if(file.fail())
    {
      plugin_log.PrintValue("Could not open file", ws2s(name));
      return 0;
    }


    char* buff = new char[buff_size];

    unsigned int count = 0;

    plugin_log.Print("Start sending file contents...");

    while( !file.eof() ) 
    { 
      memset(buff,0,buff_size); 
      file.read(buff,buff_size); 

      boost::system::error_code ignored_error;
      unsigned int len = file.gcount(); 

      boost::asio::write(socket, boost::asio::buffer(buff,len), boost::asio::transfer_all(), ignored_error); 
      count+=len;
    }
    file.close(); 

    delete [] buff; 
    buff = 0;

    plugin_log.PrintValue("Bytes sent: ", count);
  }
  catch (std::exception& e)
  {
    plugin_log.Print(e.what());
  }
  return 1;
}


void HydraRender::ExtractMaterialList(std::vector<MaterialObj>* materials)
{
  if (!incl.materials)
    return;

  int numMtls = mtlList.Count();
  int newMtlIndex = 0;

  for (int i = 0; i < numMtls; i++) 
  {
    int subMats = mtlList.GetMtl(i)->NumSubMtls();
    if(subMats == 0)
    {
      MaterialObj mat;
      ExtractMaterial(mtlList.GetMtl(i), newMtlIndex, -1, &mat);
      
      if(materialByName.find(mat.name) == materialByName.end())
      {
        materials->push_back(mat);
        material_dict_max_index[i] = mat.name;
        materialByName[mat.name] = newMtlIndex;
        newMtlIndex++;
      }
    }
    else
    {
      for(int j = 0; j < subMats; j++)
      {
        Mtl* subMtl = mtlList.GetMtl(i)->GetSubMtl(j);
        if (subMtl) 
        {
          MaterialObj mat;
          ExtractMaterial(subMtl, 0, newMtlIndex, &mat);
          if(materialByName.find(mat.name) == materialByName.end())
          {
            materials->push_back(mat);
            material_dict_max_index[j] = mat.name;
            materialByName[mat.name] = newMtlIndex;
            newMtlIndex++;
          }
        }    
      }
    }
  }

  if(numMtls == 0)
  {
    MaterialObj mat;
    NullMaterial(&mat);
    materials->push_back(mat);
    material_dict_max_index[0] = mat.name;
    materialByName[mat.name] = 0;
  }
}

void HydraRender::ExtractMaterial(Mtl* mtl, int mtlID, int subNo, MaterialObj* mat)
{
  int i;
  TimeValue t = GetStaticFrame();

  if (!mtl) return;

  TSTR className;
  mtl->GetClassName(className);


  if (subNo == -1) 
  {
    mat->id = mtlID;
    mat->sub = 0;
  }
  else
    mat->id = subNo;

  mat->name = mtl->GetName();

  if (mtl->NumSubMtls() == 0)  
  {

    if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0)) 
    {
      StdMat* std = (StdMat*)mtl;

      mat->ambient_color[0] = std->GetAmbient(t).r;
      mat->ambient_color[1] = std->GetAmbient(t).g;
      mat->ambient_color[2] = std->GetAmbient(t).b;

      mat->diffuse_color[0] = std->GetDiffuse(t).r;
      mat->diffuse_color[1] = std->GetDiffuse(t).g;
      mat->diffuse_color[2] = std->GetDiffuse(t).b;

      mat->specular_color[0] = std->GetSpecular(t).r;
      mat->specular_color[1] = std->GetSpecular(t).g;
      mat->specular_color[2] = std->GetSpecular(t).b;

      mat->filter_color[0] = std->GetFilter(t).r;
      mat->filter_color[1] = std->GetFilter(t).g;
      mat->filter_color[2] = std->GetFilter(t).b;

      mat->shininess = std->GetShininess(t);
      mat->shine_strength = std->GetShinStr(t);
      mat->transparency = std->GetXParency(t);
      //mat->wire_size = std->WireSize(t);
      


      switch(std->GetShading()) 
      {
      case SHADE_CONST:
        mat->shading = L"CONST";
        break;
      case SHADE_PHONG:
        mat->shading = L"PHONG";
        break;
      case SHADE_METAL:
        mat->shading = L"METAL";
        break;
      case SHADE_BLINN:
        mat->shading = L"BLINN";
        break;
      default:
        mat->shading = L"OTHER";
        break;
      }
      mat->opacity = std->GetOpacity(t);
      mat->IOR = std->GetIOR(t);
      mat->opacity_falloff = std->GetOpacFalloff(t);
      mat->self_illumination = std->GetSelfIllum(t);

      mat->twosided = std->GetTwoSided();
      mat->falloff  = std->GetFalloffOut();

      mat->facemap  = std->GetFaceMap();
      mat->soften   = std->GetSoften();

      switch (std->GetTransparencyType()) 
      {
      case TRANSP_FILTER:
        mat->transparency_type = L"FILTER";
        break;
      case TRANSP_SUBTRACTIVE:
        mat->transparency_type = L"SUBTRACTIVE";
        break;
      case TRANSP_ADDITIVE:
        mat->transparency_type = L"ADDITIVE";
        break;
      default: 
        mat->transparency_type = L"OTHER";
        break;
      }
    }
    else 
    {
      mat->ambient_color[0] = mtl->GetAmbient(t).r;
      mat->ambient_color[1] = mtl->GetAmbient(t).g;
      mat->ambient_color[2] = mtl->GetAmbient(t).b;

      mat->diffuse_color[0] = mtl->GetDiffuse(t).r;
      mat->diffuse_color[1] = mtl->GetDiffuse(t).g;
      mat->diffuse_color[2] = mtl->GetDiffuse(t).b;

      mat->specular_color[0] = mtl->GetSpecular(t).r;
      mat->specular_color[1] = mtl->GetSpecular(t).g;
      mat->specular_color[2] = mtl->GetSpecular(t).b;

      mat->shininess = mtl->GetShininess(t);
      mat->shine_strength = mtl->GetShinStr(t);
      mat->transparency = mtl->GetXParency(t);
      //mat->wire_size = mtl->WireSize(t);

      mat->opacity = 0;
      mat->IOR = 0;
      mat->opacity_falloff = 0;
      mat->self_illumination = 0;
    }

    for (i=0; i<mtl->NumSubTexmaps(); i++) 
    {
      Texmap* subTex = mtl->GetSubTexmap(i);
      float amt = 1.0f;
      if (subTex) 
      {
        // If it is a standard material we can see if the map is enabled.
        if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0)) 
        {
          if (!((StdMat*)mtl)->MapEnabled(i))
            continue;
          amt = ((StdMat*)mtl)->GetTexmapAmt(i, 0);

        }
        TextureObj tex;
        DumpTexture(subTex, mtl->ClassID(), i, amt, &tex);
        mat->textures.push_back(tex);
      }
    }
  } 
}

void HydraRender::NullMaterial(MaterialObj* mat)
{

  mat->name = L"null_plugin_export_material";
  mat->num_subMat = 0;
  mat->id = 0;
   
  mat->ambient_color[0] = 0.01;
  mat->ambient_color[1] = 0.01;
  mat->ambient_color[2] = 0.01;

  mat->diffuse_color[0] = 0.5;
  mat->diffuse_color[1] = 0.5;
  mat->diffuse_color[2] = 0.5;

  mat->specular_color[0] = 0;
  mat->specular_color[1] = 0;
  mat->specular_color[2] = 0;

  mat->filter_color[0] = 0;
  mat->filter_color[1] = 0;
  mat->filter_color[2] = 0;

  mat->shininess = 80;
  mat->shine_strength = 0;
  mat->transparency = 0;

  mat->shading = L"PHONG";

  mat->opacity = 0;
  mat->IOR = 0;
  mat->opacity_falloff = 0;
  mat->self_illumination = 0;

  mat->twosided = 0;
  mat->falloff = 0;

  mat->facemap = 0;
  mat->soften = 0;

  mat->transparency_type = L"FILTER";
}

void HydraRender::DumpTexture(Texmap* tex, Class_ID cid, int subNo, float amt, TextureObj* texture)
{
  if (!tex) return;

  TSTR className;
  tex->GetClassName(className);

  texture->texName = tex->GetName();
  texture->texClass = className;

  // If we include the subtexture ID, a parser could be smart enough to get
  // the class name of the parent texture/material and make it mean something.
  //fprintf(pStream,"%s\t%s %d\n", indent.data(), ID_TEXSUBNO, subNo);

  texture->texAmount = amt;

  // Is this a bitmap texture?
  // We know some extra bits 'n pieces about the bitmap texture
  if (tex->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00)) 
  {
    TSTR mapName = ((BitmapTex *)tex)->GetMapName();
    texture->mapName = mapName;


    StdUVGen* uvGen = ((BitmapTex *)tex)->GetUVGen();
    if (uvGen) 
    {
      DumpUVGen(uvGen, texture);
    }

    TextureOutput* texout = ((BitmapTex*)tex)->GetTexout();
    texture->texInvert = texout->GetInvert();

    switch(((BitmapTex*)tex)->GetFilterType()) 
    {
    case FILTER_PYR:
      texture->texFilter = L"PYR";
      break;
    case FILTER_SAT:
      texture->texFilter = L"SAT";
      break;
    default:
      texture->texFilter = L"NONE";
      break;
    }
  }
}

void HydraRender::DumpUVGen(StdUVGen* uvGen, TextureObj* texture)
{
  int mapType = uvGen->GetCoordMapping(0);
  TimeValue t = GetStaticFrame();

  switch (mapType) 
  {
  case UVMAP_EXPLICIT:
    texture->mapType = L"EXPLICIT";
    break;
  case UVMAP_SPHERE_ENV: 
    texture->mapType = L"SPHERE_ENV";
    break;
  case UVMAP_CYL_ENV:  
    texture->mapType = L"CYL_ENV";
    break;
  case UVMAP_SHRINK_ENV: 
    texture->mapType = L"SHRINK_ENV"; 
    break;
  case UVMAP_SCREEN_ENV: 
    texture->mapType = L"SCREEN_ENV";
    break;
  }

  texture->uOffset = uvGen->GetUOffs(t);
  texture->vOffset = uvGen->GetVOffs(t);
  texture->uTiling = uvGen->GetUScl(t);
  texture->vTiling = uvGen->GetVScl(t);
  texture->angle = uvGen->GetAng(t);
  texture->blur = uvGen->GetBlur(t);
  texture->blurOffset = uvGen->GetBlurOffs(t);
  texture->noiseAmt =uvGen->GetNoiseAmt(t);
  texture->noiseSize = uvGen->GetNoiseSize(t);
  texture->noiseLevel = uvGen->GetNoiseLev(t);
  texture->noisePhase = uvGen->GetNoisePhs(t);
}


void MaxMatrix3ToFloat16(const Matrix3& pivot, float* m)
{
  Point3 row1, row2, row3, row4;

  row1 = pivot.GetRow(0);
  row2 = pivot.GetRow(1);
  row3 = pivot.GetRow(2);
  row4 = pivot.GetRow(3);

  m[0] = row1[0];
  m[1] = row1[1];
  m[2] = row1[2];
  m[3] = 0;

  m[4] = row2[0];
  m[5] = row2[1];
  m[6] = row2[2];
  m[7] = 0;

  m[8]  = row3[0];
  m[9]  = row3[1];
  m[10] = row3[2];
  m[11] = 0;

  m[12] = row4[0];
  m[13] = row4[1];
  m[14] = row4[2];
  m[15] = 1;
}

void HydraRender::ExtractNodeTM(INode* node, GeometryObj* geom)
{
  //Matrix3 pivot = node->GetNodeTM(GetStaticFrame());
  Matrix3 pivot = node->GetObjectTM(GetStaticFrame());
  MaxMatrix3ToFloat16(pivot, geom->m);
}

void HydraRender::ExtractNodeTM(INode* node, LightObj* li)
{
  Matrix3 pivot = node->GetObjectTM(GetStaticFrame());
  MaxMatrix3ToFloat16(pivot, li->m);
}

void HydraRender::ExtractGeomObject(INode* node, GeometryObj* geom, SphereObj* sphere, bool* IsSphere)
{
  ObjectState os = node->EvalWorldState(GetStaticFrame());
  if (!os.obj)
    return;

  if (os.obj->ClassID() == Class_ID(TARGET_CLASS_ID, 0))
    return;

  geom->mesh_id = node->GetName();

  ExtractNodeTM(node, geom);

  if (incl.geometry) 
    ExtractMesh(node, GetStaticFrame(), geom, sphere, IsSphere);

  if(geom->n_faces*3 != geom->pos_indeces.size())
  {
    plugin_log.Print("omg, it is hapened");
  }


  if(*IsSphere == true)
  {
    for(int j = 0; j < 16; j++)
      sphere->m[j] = geom->m[j];
    sphere->mesh_id = node->GetName();
  }

  if (incl.materials) 
  {
    Mtl* mtl = node->GetMtl();
    if (mtl) 
    {
      if(*IsSphere == true)
      {
        std::wstring matName = mtl->GetName();
        sphere->material_id = materialByName[matName];
      }
    }
    else
      sphere->material_id = 0;
  }

}


void HydraRender::ExtractLightObject(INode* node, LightObj* li)
{
  TimeValue t = GetStaticFrame();

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj) 
    return;

  LightObject* light = (LightObject*)(os.obj); // try dynamic_cast

  /*ObjLightDesc* pLightDesc = light->CreateLightDesc(node); 	
  if(pLightDesc!=NULL)
  {
    Point3 pos = pLightDesc->LightPosition(); // The position of the light in camera space. 
    
    pos = pLightDesc->camToLight*pos;         // cam space   => light space
    pos = pLightDesc->lightToWorld*pos;       // light space => world space

    li->position[0] = pos[0];
    li->position[1] = pos[1];
    li->position[2] = pos[2];

    Matrix3 mlightToWorld = pLightDesc->lightToWorld;
    MaxMatrix3ToFloat16(mlightToWorld, li->targetMatrix);

    pLightDesc->DeleteThis();
    pLightDesc = NULL;
  }*/

  li->lightName = node->GetName();

  struct LightState ls;
  Interval valid = FOREVER;

  light->EvalLightState(t, valid, &ls);

  li->lightType = L"OMNI";

  switch(ls.type) 
  {
  case OMNI_LGT:
    li->lightType = L"OMNI";
    break;

  case DIRECT_LGT:
  case TDIR_LIGHT:
    li->lightType = L"DIR";
    break;

  case FSPOT_LIGHT:
  case SPOT_LGT:

    li->lightType = L"SPOT";
    break;

  default:
    li->lightType = L"EXTRA";
    break;
  }



  bool isTargeted = false;
  bool isExtra    = false;

  // extra class ID from the samples (systems/sunlight/natLight.cpp)
  //
  {
    const ULONG SKY_LIGHT_CLASS_ID_PART_A = 0x7bf61478;

    const unsigned int PB_SKY_COLOR = 0;
    const unsigned int PB_SKY_SKY_COLOR_MAP_AMOUNT = 1;
    const unsigned int PB_SKY_COLOR_MAP = 2; // TYPE_TEXMAP
    const unsigned int PB_SKY_SKY_COLOR_MAP_ON = 3;

    ULONG classId = light->ClassID().PartA();
    GenLight* glight = (GenLight*)(light);

    bool isSpot        = false;
    bool isDirectional = false;
    bool isPoint       = false;
    bool isSky         = false;

    switch (classId)
    {
    case FSPOT_LIGHT_CLASS_ID:
    case SPOT_LIGHT_CLASS_ID: 
      isSpot = true; 
      break;

    case DIR_LIGHT_CLASS_ID: 
    case TDIR_LIGHT_CLASS_ID: 
      isDirectional = true; 
      break;

    case SKY_LIGHT_CLASS_ID_PART_A:
      isSky = true;
      li->lightType = L"SKY";
      break;

    case OMNI_LIGHT_CLASS_ID:
      isPoint = true;
      break;

    default:
      isExtra = true;
      break;
    }

    if(isSpot || isDirectional || isPoint)
      li->directLightStart = glight->GetDecayRadius(0);

    isTargeted = (classId == SPOT_LIGHT_CLASS_ID || classId == TDIR_LIGHT_CLASS_ID);

    if (isSky)
    {
      const unsigned int PBLOCK_REF = 0;		 // This is a IParamBlock
      const unsigned int PBLOCK_REF_SKY = 0; // This is a IParamBlock2

      IParamBlock2* parametersSky = (IParamBlock2*)( light->GetReference(PBLOCK_REF_SKY) );
     
      if(parametersSky != NULL)
      {
        const unsigned int PB_SKY_COLOR = 0;
        const unsigned int PB_SKY_SKY_COLOR_MAP_AMOUNT = 1;
        const unsigned int PB_SKY_COLOR_MAP = 2; // TYPE_TEXMAP
        const unsigned int PB_SKY_SKY_COLOR_MAP_ON = 3;

        //parametersSky->GetColor(PB_SKY_COLOR);

        Texmap* colorMap = parametersSky->GetTexmap(PB_SKY_COLOR_MAP, t);
        if (colorMap->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00)) 
        {
          TSTR mapName = ((BitmapTex *)colorMap)->GetMapName();
          li->envTexturePath = mapName;
        }

      }

    }
  }

  li->isTargeted = isTargeted;

  if(!li->isTargeted)  // that is wrong!
  {
    Point3 lightDirPoint = node->GetNodeTM(t).GetRow(2);
    li->direction[0] = -lightDirPoint.x;
    li->direction[1] = -lightDirPoint.y;
    li->direction[2] = -lightDirPoint.z;
  }

  // export light target
  //
  INode* targetNode = isTargeted ? node->GetTarget() : NULL;
  if(targetNode != NULL)
  {
    Matrix3 pivot = targetNode->GetObjectTM(GetStaticFrame());
    MaxMatrix3ToFloat16(pivot, li->targetMatrix);
  }
  li->isTargeted = (targetNode != NULL);

  ExtractNodeTM(node, li);

  int shadowMethod = light->GetShadowMethod();
  if(shadowMethod == LIGHTSHADOW_NONE)
    li->shadowType = L"NONE";
  else if(shadowMethod == LIGHTSHADOW_MAPPED) 
    li->shadowType = L"SHADOW_MAP";
  else
    li->shadowType = L"SHADOW_RAY";

  //if(light->GetSpotShape() == RECT_LIGHT)
  //  li->spotShape = L"RECT";
  //else
  //  li->spotShape = L"CIRCLE";

  li->useGlobal  = light->GetUseGlobal();
  li->absMapBias = light->GetAbsMapBias();
  li->overshoot  = light->GetOvershoot();


  // Export light settings for frame 0
  ExtractLightSettings(&ls, light, t, li, isExtra);


  // export custom plugin lights parameters
  //
  if(1)
  {
    IParamBlock2* params = (IParamBlock2*)( light->GetReference(0) );
    TraceNodeCustomProperties(li->lightName, light, 1);
    //TraceIParamBlock2(li->lightName, params, 1);
  }

}

void HydraRender::ExtractLightSettings(LightState* ls, LightObject* light, TimeValue t, LightObj* li, bool isExtra)
{
  li->color[0]  = ls->color.r;
  li->color[1]  = ls->color.g;
  li->color[2]  = ls->color.b;
  li->intensity = ls->intens;
  li->aspect    = ls->aspect;

  li->hotsize  = ls->hotsize;
  li->fallsize = ls->fallsize;
  
  li->attenStart = ls->attenStart;
  li->attenEnd   = ls->attenEnd;
  

  li->TDist    = light->GetTDist(t, FOREVER);
  li->mapBias  = light->GetMapBias(t, FOREVER);
  li->mapRange = light->GetMapRange(t, FOREVER);
  li->mapSize  = light->GetMapSize(t, FOREVER);
  li->rayBias  = light->GetRayBias(t, FOREVER);

  li->on = ls->on;
  li->computeShadow = ls->shadow;

  // get light attenuation
  //
  if(li->lightType != L"SKY" && !isExtra)
  {
    IParamBlock*  parameters  = (IParamBlock*)(light->GetReference(0));
    //IParamBlock2* parameters2 = (IParamBlock2*)(light->GetReference(0));
    
    if(parameters != NULL)
    {
      const unsigned int PB_DECAY = 11;
      const unsigned int PB_OMNIDECAY = 8;

      bool isPoint = (li->lightType == L"OMNI");

      int decayFunction = parameters->GetInt(isPoint ? PB_DECAY : PB_OMNIDECAY, 0);
      switch (decayFunction)
      {
      case 1:
        li->kc = 0.0f;
        li->kl = 1.0f;
        li->kq = 0.0f;
        break;

      case 2:
        li->kc = 0.0f;
        li->kl = 0.0f;
        li->kq = 1.0f;
        break;

      case 0:
        li->kc = 1.0f;
        li->kl = 0.0f;
        li->kq = 0.0f;

      default:
        li->kc = 1.0f;
        li->kl = 0.0f;
        li->kq = 0.0f;
        break;
      }
    }
  }


}


void HydraRender::ExtractCamObject(INode* node, CameraObj* cam)
{
  CameraObject* camera = (CameraObject*)(node->GetObjectRef());
  INode* targetNode = (camera->ClassID().PartA() == LOOKAT_CAM_CLASS_ID) ? node->GetTarget() : NULL;

  if(camera == NULL || cam == NULL)
    return;

  cam->camName = node->GetName();


  if(targetNode != NULL)
  {
    Matrix3 pivot = targetNode->GetObjectTM(GetStaticFrame());
    MaxMatrix3ToFloat16(pivot, cam->targetMatrix);
  }

  if(node != NULL)
  {
    Matrix3 pivot = node->GetObjectTM(GetStaticFrame());
    MaxMatrix3ToFloat16(pivot, cam->posMatrix);

    // For the CameraObject class, the transform for the node to which it is attached is used instead, 
    // whose inverse becomes the view transform matrix.
    //
    Matrix3 worldViewInv = pivot;
    Matrix3 worldView    = Inverse(worldViewInv);
    MaxMatrix3ToFloat16(worldView, cam->worldViewMatrix);
  }

  cam->isOrtho = camera->IsOrtho(); 

  const unsigned int PBLOCK_REF = 0;   // This is a IParamBlock, not a IParamBlock2.
  const unsigned int DOF_REF = 1;
  const unsigned int MP_EFFECT_REF = 2;

  // Parameter block indices
  //
  const unsigned int FOV = 0;             // float
  const unsigned int TARGET_DISTANCE = 1; // float
  const unsigned int NEAR_CLIP  = 2;      // float
  const unsigned int FAR_CLIP   = 3;      // float
  const unsigned int NEAR_RANGE = 4;      // float
  const unsigned int FAR_RANGE  = 5;      // float
  const unsigned int MULTI_PASS_EFFECT_ENABLE = 6;  // bool
  const unsigned int MULTI_PASS_EFFECT_RENDER_EFFECTS_PER_PASS = 7; // bool
  const unsigned int FOV_TYPE = 8;        // int

  IParamBlock* parameters = (IParamBlock*)(camera->GetReference(PBLOCK_REF));
  
  if(parameters == NULL)
    return;

  cam->fov           = parameters->GetFloat(FOV)*RAD_TO_DEG;
  cam->nearClipPlane = parameters->GetFloat(NEAR_CLIP);
  cam->farClipPlane  = parameters->GetFloat(FAR_CLIP);


  // export DOF and motion blur parameters
  //
  #define FMULTI_PASS_MOTION_BLUR_CLASS_ID Class_ID(0xd481518, 0x687d7c99)
  #define FMULTI_PASS_DOF_CLASS_ID Class_ID(0xd481815, 0x687d799c)
  
  if (camera->GetMultiPassEffectEnabled(0, FOREVER))
  {
    IMultiPassCameraEffect *multiPassCameraEffect = camera->GetIMultiPassCameraEffect();
    if (multiPassCameraEffect)
    {
      Class_ID id = multiPassCameraEffect->ClassID();

      // the camera could have both effects, but not in Max
      //
      if (id == FMULTI_PASS_MOTION_BLUR_CLASS_ID)
      {
        IParamBlock2 *parameters = multiPassCameraEffect->GetParamBlock(0);
        if (parameters )
        {
         
        }

      }
      else if (id == FMULTI_PASS_DOF_CLASS_ID)
      {
        IParamBlock2 *parameters = multiPassCameraEffect->GetParamBlock(0);
        if (parameters )
        {
           cam->dofEnabled   = true;
           cam->dofFocalDist = parameters->GetFloat(1); // FOCAL_DEPTH
           cam->dofStrength  = float( parameters->GetInt(7) );   // DITHER_STRENGTH
        }

      }
    }
  }

}


void HydraRender::ExtractMesh(INode* node, TimeValue t, GeometryObj* geom, SphereObj* sphere, bool* IsSphere)
{
  int i;

  Matrix3 tm = node->GetObjTMAfterWSM(t);
  BOOL negScale = TMNegParity(tm);
  int vx1, vx2, vx3;
  TSTR indent;

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj || os.obj->SuperClassID()!=GEOMOBJECT_CLASS_ID) 
  {
    plugin_log.Print("Oh, shit! Safety net. This shouldn't happen");
    return; // Safety net. This shouldn't happen.
  }

  // Order of the vertices. Get 'em counter clockwise if the objects is
  // negatively scaled.
  if (negScale) 
  {
    vx1 = 2;
    vx2 = 1;
    vx3 = 0;
  }
  else 
  {
    vx1 = 0;
    vx2 = 1;
    vx3 = 2;
  }

  BOOL needDel;
  TriObject* tri = GetTriObjectFromNode(node, t, needDel); 

  if (tri == NULL) 
  {
    geom->n_verts = 0;
    geom->n_faces = 0;
    return;
  }

  Mesh* mesh = &tri->GetMesh();
  if(mesh == NULL)
  {
    geom->n_verts = 0;
    geom->n_faces = 0;
    return;
  }

  Mtl* nodeMtl = node->GetMtl();
  //if(nodeMtl == NULL)
    //return;

  geom->n_verts = mesh->getNumVerts();
  geom->n_faces = mesh->getNumFaces();

  if(geom->n_faces == 0 || geom->n_verts == 0)
  {
    plugin_log.Print("strange empty mesh detected");
    geom->n_verts = 0;
    geom->n_faces = 0;
    return;
  }

  for (i=0; i<geom->n_verts; i++) 
  {
    Point3 v = tm * mesh->verts[i];

    geom->positions.push_back(v[0]);
    geom->positions.push_back(v[1]);
    geom->positions.push_back(v[2]);

    if(i==0)
    {
      geom->bbox[0] = v[0];
      geom->bbox[1] = v[1];
      geom->bbox[2] = v[2];

      geom->bbox[3] = v[0];
      geom->bbox[4] = v[1];
      geom->bbox[5] = v[2];
    }
    else 
    {
      if ( v[0] < geom->bbox[0] ) geom->bbox[0] = v[0];
      if ( v[1] < geom->bbox[1] ) geom->bbox[1] = v[1];
      if ( v[2] < geom->bbox[2] ) geom->bbox[2] = v[2];

      if ( v[0] > geom->bbox[3] ) geom->bbox[3] = v[0];
      if ( v[1] > geom->bbox[4] ) geom->bbox[4] = v[1];
      if ( v[2] > geom->bbox[5] ) geom->bbox[5] = v[2];
    }

  }


  for (i=0; i<geom->n_faces; i++) 
  {
    Face* f = &mesh->faces[i];
    geom->face_smoothgroups.push_back(f->smGroup);

    if(mtlList.Count() != 0 && nodeMtl != NULL)
    {
      int nodeSubMtls = nodeMtl->NumSubMtls();
      if(nodeSubMtls == 0)
      {
        int mat_id = materialByName[nodeMtl->GetName().data()];
        geom->material_id.push_back(mat_id);
      }
      else
      {
        int subMatId = f->getMatID();
        Mtl* faceMat = nodeMtl->GetSubMtl(subMatId); 

        if (faceMat == NULL)
        {
          geom->material_id.push_back(0);
        }
        else
        {
          int mat_id = materialByName[faceMat->GetName().data()];
          geom->material_id.push_back(mat_id);
        }
      } 
    }
    else
    {
      geom->material_id.push_back(0);
    }

    geom->pos_indeces.push_back(mesh->faces[i].v[vx1]);
    geom->pos_indeces.push_back(mesh->faces[i].v[vx2]);
    geom->pos_indeces.push_back(mesh->faces[i].v[vx3]);
  }

  if (GetIncludeTextureCoords()) 
  {
    // If not, export standard tverts
    int numTVx = mesh->getNumTVerts();

    //char temp[64];
    
    //sprintf(temp,"%d", geom->n_verts);
    //plugin_log.Print(std::string("n_verts = ") + std::string(temp));

    //sprintf(temp,"%d", geom->n_faces);
    //plugin_log.Print(std::string("n_faces = ") + std::string(temp));

    //sprintf(temp,"%d", numTVx);
    //plugin_log.Print(std::string("numTVx = ") + std::string(temp));

    if (numTVx) 
    {
      for (i=0; i<numTVx; i++) 
      {
        UVVert tv = mesh->tVerts[i];
        geom->tex_coords.push_back(tv[0]);
        geom->tex_coords.push_back(tv[1]);
      }

      for (i=0; i<mesh->getNumFaces(); i++) 
      {
        geom->tex_coords_indices.push_back(mesh->tvFace[i].t[vx1]);
        geom->tex_coords_indices.push_back(mesh->tvFace[i].t[vx2]);
        geom->tex_coords_indices.push_back(mesh->tvFace[i].t[vx3]);

      }

    }
  }

  *IsSphere = false;
  float radius = 0;
  Point3 center(0,0,0);
  //std::string sphereMaterialName = nodeMtl->GetName();;

  std::wstring SphereName;
  SphereName = node->NodeName();

  if (SphereName.find(L"Sphere") != std::wstring::npos || SphereName.find(L"sphere") != std::wstring::npos) 
  {
    *IsSphere = true;

    // calculate center
    //
    center.x = 0;
    center.y = 0;
    center.z = 0;

    for(int i = 0; i < geom->n_verts; i++)
    {
      Point3 v = tm * mesh->verts[i];
      center += v;
    }

    center *= (1.0f/geom->n_verts);

    // assume we have definite radius

    Point3 p1 = tm * mesh->verts[0];
    Point3 rad;
    rad = p1 - center;
    radius = rad.FLength();
    float epsilon = 0.001f;

    for(int i=0;i<geom->n_verts;i++)
    {
      Point3 v = tm * mesh->verts[i];
      Point3 temp;
      temp = v - center;
      if( abs(temp.FLength() - radius) > epsilon )
      {
        *IsSphere = false;
        break;
      }
    }
  }

  if(*IsSphere == true)
  {
   
    sphere->center[0] = center.x;   
    sphere->center[1] = center.y;  
    sphere->center[2] = center.z;  
    sphere->center[3] = 1;   

    sphere->radius = radius;   

    for(int myIndex=0;myIndex<6;myIndex++)
    {
      sphere->bbox[myIndex] = geom->bbox[myIndex];
    }
  }

  if(geom->pos_indeces.size() != geom->n_faces*3)
  {
    plugin_log.Print("pos_indeces.size() != geom->n_faces");
  }

  if (needDel) 
  {
    tri->DeleteThis();
    tri = NULL;
  }

}


BOOL HydraRender::TMNegParity(Matrix3 &m)
{
  return (DotProd(CrossProd(m.GetRow(0),m.GetRow(1)),m.GetRow(2))<0.0)?1:0;
}


TriObject* HydraRender::GetTriObjectFromNode(INode *node, TimeValue t, int &deleteIt)
{
  deleteIt = FALSE;
  Object *obj = node->EvalWorldState(t).obj;
  if (obj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0))) { 
    TriObject *tri = (TriObject *) obj->ConvertToType(t, 
      Class_ID(TRIOBJ_CLASS_ID, 0));
    // Note that the TriObject should only be deleted
    // if the pointer to it is not equal to the object
    // pointer that called ConvertToType()
    if (obj != tri) deleteIt = TRUE;
    return tri;
  }
  else {
    return NULL;
  }
}


static Point3 basic_tva[3] = { 
  Point3(0.0,0.0,0.0),Point3(1.0,0.0,0.0),Point3(1.0,1.0,0.0)
};
static Point3 basic_tvb[3] = { 
  Point3(1.0,1.0,0.0),Point3(0.0,1.0,0.0),Point3(0.0,0.0,0.0)
};
static int nextpt[3] = {1,2,0};
static int prevpt[3] = {2,0,1};

void HydraRender::make_face_uv(Face *f, Point3 *tv)
{
  int na,nhid,i;
  Point3 *basetv;
  /* make the invisible edge be 2->0 */
  nhid = 2;
  if (!(f->flags&EDGE_A))  nhid=0;
  else if (!(f->flags&EDGE_B)) nhid = 1;
  else if (!(f->flags&EDGE_C)) nhid = 2;
  na = 2-nhid;
  basetv = (f->v[prevpt[nhid]]<f->v[nhid]) ? basic_tva : basic_tvb; 
  for (i=0; i<3; i++) {  
    tv[i] = basetv[na];
    na = nextpt[na];
  }
}

void HydraRender::PreProcess(INode* node, int& nodeCount)
{
  nodeCount++;

  mtlList.AddMtl(node->GetMtl());

  for (int c = 0; c < node->NumberOfChildren(); c++) 
  {
    PreProcess(node->GetChildNode(c), nodeCount);
  }

}

BOOL HydraRender::nodeEnum(INode* node, std::vector<LightObj>* lights, std::vector<SphereObj>* spheres, std::vector<CameraObj>* cameras, boost::archive::binary_oarchive& ar, int& geomObjNum) 
{
  if(exportSelected && node->Selected() == FALSE)
    return TREE_CONTINUE;

  nCurNode++;

  //ip->ProgressUpdate((int)((float)nCurNode/nTotalNodeCount*100.0f));  // ������� progress bar!!!

  // Stop recursing if the user pressed Cancel 
  /*if (ip->GetCancel())
  return FALSE;*/

  // Only export if exporting everything or it's selected
  //
  if(!exportSelected || node->Selected()) 
  {
    // The ObjectState is a 'thing' that flows down the pipeline containing
    // all information about the object. By calling EvalWorldState() we tell
    // max to evaluate the object at end of the pipeline.
    ObjectState os = node->EvalWorldState(0); 

    // The obj member of ObjectState is the actual object we will export.
    if (os.obj) 
    {
      GeometryObj geom; 
      geom.reserveMemory(100000);

      SphereObj sphere;
      bool IsSphere = false;

      // We look at the super class ID to determine the type of the object.
      switch(os.obj->SuperClassID()) 
      {

      case GEOMOBJECT_CLASS_ID: 
        {
          ExtractGeomObject(node, &geom, &sphere, &IsSphere); 
          if(IsSphere)
          {
            spheres->push_back(sphere);
          }
          else if (geom.n_faces != 0)
          {
            ar & geom;
            geomObjNum++;	
          }

          break;
        }

      case LIGHT_CLASS_ID:
        {
          LightObj li;
          ExtractLightObject(node, &li); 
          lights->push_back(li);
          break;
        }

      case CAMERA_CLASS_ID:
        {
          CameraObj cam;
          ExtractCamObject(node, &cam);
          cameras->push_back(cam);
          break;
        }
      default:
          break;
      }
    }
  }	

  // For each child of this node, we recurse into ourselves 
  // until no more children are found.
  for (int c = 0; c < node->NumberOfChildren(); c++) {
    if (!nodeEnum(node->GetChildNode(c), lights, spheres, cameras, ar, geomObjNum))
      return FALSE;
  }

  return TRUE;
}

BOOL MtlKeeper::AddMtl(Mtl* mtl)
{
  if (!mtl) {
    return FALSE;
  }

  int numMtls = mtlTab.Count();
  for (int i=0; i<numMtls; i++) {
    if (mtlTab[i] == mtl) {
      return FALSE;
    }
  }
  mtlTab.Append(1, &mtl, 25);

  return TRUE;
}

int MtlKeeper::GetMtlID(Mtl* mtl)
{
  int numMtls = mtlTab.Count();
  for (int i=0; i<numMtls; i++) {
    if (mtlTab[i] == mtl) {
      return i;
    }
  }
  return -1;
}

int MtlKeeper::Count() { return mtlTab.Count(); }
Mtl* MtlKeeper::GetMtl(int id) { return mtlTab[id]; }
void MtlKeeper::Clear() { mtlTab.ZeroCount(); }



void HydraRender::TraceNodeCustomProperties(const std::wstring& a_objectName, LightObject* a_node, int deep)
{
  unsigned int uNumReferences = a_node->NumRefs();

  if (uNumReferences == 0)
    return;

  m_paramTrace << a_objectName.c_str() << L" is " << std::endl;

  for (unsigned int i = 0; i < uNumReferences; ++i) 
  {
    ReferenceTarget *pObjRef = a_node->GetReference(i);

    if (!pObjRef)
      continue;

    ULONG classID1 = pObjRef->SuperClassID();

    if(classID1 == PARAMETER_BLOCK2_CLASS_ID) 
    {
      m_paramTrace << "GetReference(" << i << ") = { " << std::endl;
      TraceIParamBlock2(a_objectName, (IParamBlock2 *)pObjRef, deep);
      m_paramTrace << "} " << std::endl;
    }
    
    //else 
      //TraceNodeCustomProperties(a_objectName, pObjRef, deep+1);
  }

  m_paramTrace << L"end " << a_objectName.c_str() << std::endl;

}



void HydraRender::TraceIParamBlock2(const std::wstring& a_objectName, IParamBlock2* pBlock, int deep)
{
  if(pBlock == NULL)
    return;

  ParamBlockDesc2 *desc = pBlock->GetDesc();
  unsigned int uNumParams  = desc->Count();
  unsigned int uNumParams2 = pBlock->NumParams();

  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    ParamDef& paramDef = pBlock->GetParamDef(pid);

    Interval valid = FOREVER;

    Color col;
    AColor acol;

    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    for(int i=0;i<deep;i++)
      m_paramTrace << L"  ";
    m_paramTrace << strData;

    ParamType2 typeId = pBlock->GetParameterType(pid);
    switch(typeId) 
    {
    case TYPE_ANGLE:
    case TYPE_PCNT_FRAC:
    case TYPE_WORLD:
    case TYPE_FLOAT:
      m_paramTrace << L"\t\t: float   = " << pBlock->GetFloat(pid) << std::endl;
      break;

    case TYPE_TIMEVALUE:
    case TYPE_INT:
      m_paramTrace << L"\t\t: integer = " << pBlock->GetInt(pid) << std::endl;
      break;

    case TYPE_BOOL:
      m_paramTrace << L"\t\t: boolean = " << pBlock->GetInt(pid) << std::endl;
      break;

    case TYPE_FILENAME:
    case TYPE_STRING:
      {
        const wchar_t* pstrdata = pBlock->GetStr(pid);
        if(pstrdata == NULL)
          pstrdata = L"";
        m_paramTrace << L"\t\t: string  = "  << pstrdata << std::endl;
      }
      break;

    case TYPE_RGBA:
      col = pBlock->GetColor(pid);
      m_paramTrace << L"\t\t: color   = "  << col.r << col.g << col.b << std::endl;
      break;

    case TYPE_FRGBA:
      acol = pBlock->GetAColor(pid);
      m_paramTrace << L"\t\t: colorf  = "  << acol.r << acol.g << acol.b << std::endl;
      break;

    case TYPE_PBLOCK2:
      {
        IParamBlock2* internalNode = pBlock->GetParamBlock2(pid);
        m_paramTrace << L"\t\t: IParamBlock2";
        TraceIParamBlock2(L"", internalNode, deep+1);
      }
      break;

    case TYPE_REFTARG:
      {
        INode* node = pBlock->GetINode(pid);
        ReferenceTarget* pRefTarget = pBlock->GetReferenceTarget(pid);
        IParamBlock2* node2 = pBlock->GetParamBlock2(pid);

        unsigned int uNumReferences = pBlock->NumRefs();

        if(node != NULL)
        {
          m_paramTrace << L"\t\t: INode(geometry) " << std::endl;
        }
        else if(pRefTarget != NULL )
        { 
          ULONG classId1 = pRefTarget->SuperClassID();
          ULONG classId2 = pRefTarget->ClassID().PartA();
          m_paramTrace << L"\t\t: TYPE_REFTARG; calsssId = " << classId2;
        }
        else if(node2!=NULL)
        {
          m_paramTrace << L"\t\t: IParamBlock2(TYPE_REFTARG)";
          TraceIParamBlock2(L"", node2, deep+1);
        }
        else
          m_paramTrace << L"\t\t: EmptyRefTarget" << std::endl;
       
      }
      break;


    default:
      m_paramTrace << " : unknown " << std::endl;
      break;
    }

  }

}
