#include "CUDAPipeline.h"
//#include "CudaBindings.h"

namespace SGA
{
  #include <iostream>

  //#define CUDA_SAFE_CALL(call) { cudaError_t err = (call); if (err!=cudaSuccess) throw std::runtime_error(cudaGetErrorString(err)); }
                                
  void CUDAPipeline::SetShaderVariable(const std::string& name, float var)  { SetShaderVariableGeneric(name,var);}
  void CUDAPipeline::SetShaderVariable(const std::string& name, int var)    { SetShaderVariableGeneric(name,var);}
  void CUDAPipeline::SetShaderVariable(const std::string& name, MGML_MATH::VECTOR<3,float> var) {SetShaderVariableGeneric(name,var);}
  void CUDAPipeline::SetShaderVariable(const std::string& name, const MGML_MATH::MATRIX4X4<float>& var) {SetShaderVariableGeneric(name,var);}

}

