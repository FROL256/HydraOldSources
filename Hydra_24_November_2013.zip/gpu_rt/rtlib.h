// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#define RTLIB_GUARDIAN



#ifndef CONFIG_GUARDIAN
  #include "../bvh_builder/config.h"
#endif

enum {GPU_RT_MEMORY_SAFE_MODE = 1, GPU_RT_MEMORY_FULL_SIZE_MODE = 2};

#ifndef ACCEL_STRUCT_GUARDIAN
  #include "../bvh_builder/AccelerationStructure.h"
#endif

#ifndef KD_TREE_LAYOUT_GUARDIAN
  #include "../bvh_builder/kd_tree_layout.h"
#endif

#ifndef BVH_LAYOUT_GUARDIAN
  #include "../bvh_builder/BVH_layout.h"
#endif

#ifndef TRANSIT_PRIMITIVES_GUARDIAN
  #include "Transit_Primitives.h"
#endif

#ifndef MATERIAL_GUARDIAN
  #include "Material.h"
#endif

#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif


#define BLOCK_SIZE_X 16
#define BLOCK_SIZE_Y 16
#define WARP_SIZE 32

#define Z_ORDER_BLOCK_SIZE 16
#define CMP_RESULTS_BLOCK_SIZE 256


#define HRT_RAY_MISS 0xFFFFFFFE
#define HRT_RAY_HIT 0xFFFFFFFF

#define DELTA_RAY 1e-5f

#define TEX_ARRAYS_NUMBER 9
#define TEX_ARRAYS_MIN_SIZE 32
#define TEX_ARRAYS_MAX_SIZE 16384

#define HEMISPHERE_SEQUENCE_NUM 4
#define RC_CUBE_SIZE 4

namespace RAYTR
{

enum RAY_TYPES {EYE_RAY,
				        SHADOW_RAY,
				        REFLECTED_RAY,
				        REFRACTED_RAY};

enum ACCELERATION_STRUCRURES {ACCEL_STRUCT_KD_TREE,
                              ACCEL_STRUCT_BVH,
                              ACCEL_STRUCT_HIERARHICAL_GRID};


#ifdef __CUDACC__

#include "float4.cuh"

#ifndef RANDOMC_H
  #include "random_mc.h"
#endif

//#include <curand.h>
//#include <curand_kernel.h>

static __device__ uint encodeNormal(float3 n)
{
  short x = (short)(n.x*32767.0f);
  short y = (short)(n.y*32767.0f);

  ushort sign = (n.z >= 0) ? 0 : 1;

  int sx = (int(x & 0xfffe) | sign);
  int sy = (int(y & 0xfffe) << 16 );

  return (sx | sy);
}

static __device__ float3 decodeNormal(uint a_data)
{
  const float divInv = 1.0f/32767.0f;

  short2 a_enc;

  a_enc.x = short(a_data & 0x0000FFFF);
  a_enc.y = short(int(a_data & 0xFFFF0000) >> 16);

  float sign = (a_enc.x & 0x0001) ? -1.0f : 1.0f;

  float x = short(a_enc.x & 0xfffe)*divInv;
  float y = short(a_enc.y & 0xfffe)*divInv;
  float z = sign*sqrtf(fmaxf(1.0f - x*x - y*y, 0.0f));

  return make_float3(x,y,z);
}
#else

  //#define __align__(N)

#endif

struct RaySample1
{
  float3   color;
  unsigned short x,y;     // screen x and y
};

struct RaySample2
{
  float3 pos;
  uint   compressedNorm;
};

struct RaySampleOther
{
  float u,v;
};



//#define ALIGN_POSNORM(N) __align__(N)
#define ALIGN_POSNORM(N)

struct ALIGN_POSNORM(16) HitPosNorm
{
  float3 pos;
  uint norm_xy;

#ifdef __CUDACC__

  __device__ float3 GetNormal() const { return decodeNormal(norm_xy); }
  __device__ void SetNormal(float3 a_norm) { norm_xy = encodeNormal(normalize(a_norm)); }

#endif

};

#ifdef __CUDACC__

__device__ HitPosNorm make_HitPosNorm(float4 a_data)
{
  HitPosNorm res;
  res.pos.x = a_data.x;
  res.pos.y = a_data.y;
  res.pos.z = a_data.z;
  res.norm_xy = uint(__float_as_int(a_data.w));
  return res;
}

#endif


struct __align__(8) HitTexCoord
{
  float  tex_u;
  float  tex_v;
};


struct __align__(4) HitMatRef
{
  int    m_data;

#ifndef __CUDACC__
  HitMatRef() {m_data = 0;}
#endif

  universal_call int GetHitType() const {return (m_data & 0xF0000000) >> 28;}
  universal_call int GetMaterialId() const {return m_data & 0x0FFFFFFF;}

  universal_call void SetMaterialId(int a_mat_id)
  {
    register int mask =  a_mat_id & 0x0FFFFFFF;
    register int m_data2 = m_data & 0xF0000000;
    m_data = m_data2 | mask;
  }

  universal_call void SetHitType(int a_id)
  {
    register int mask =  a_id << 28;
    register int m_data2 = m_data & 0x0FFFFFFF;
    m_data = m_data2 | mask;
  }

};

struct __align__(8) Hit_Part4
{
  uint tangentCompressed;
  uint bitangentCompressed;
};


/////////////////////////////////
struct __align__(8) Lite_Hit
{

  static inline universal_call int MakeObjectId(unsigned int a_id, unsigned int a_objType)
  {
    return (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000);
  }

  inline universal_call void SetObjectId(unsigned int a_id)
  { object_id = ( a_id & 0x3FFFFFFF) | (object_id & 0xC0000000); }

  inline universal_call unsigned int GetObjectId() const
  { return object_id & 0x3FFFFFFF; }

  inline universal_call void SetObjectType(unsigned int a_type)
  { object_id = ( ((a_type << 30) & 0xC0000000) | (object_id & 0x3FFFFFFF) ) ; }

  inline universal_call unsigned int GetObjectType() const
  { return (object_id & 0xC0000000) >> 30; }

  inline universal_call static Lite_Hit Make(float t, unsigned int a_id, unsigned int a_objType)
  {
     Lite_Hit hit;
     hit.t = t;
     hit.object_id = (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000);
     return hit;
  }

  enum {TRIANGLE, SPHERE, BOX, NONE};

  //protected:

  float t;
  unsigned int  object_id; // we can use 2 bits of object_id to store object_type
};


struct RayFlags // __align__(4) 
{
  unsigned char  diffuseBounceNum;
  unsigned char  bounceNum;
  unsigned char  bounceNumCaustic;
  unsigned char  otherFlags;
};

enum {RAY_GRAMMAR_SPECULAR             = 1, 
      RAY_GRAMMAR_DIFFUSE_REFLECTION   = 2, 
      RAY_GRAMMAR_REFLECTION           = 4, 
      RAY_GRAMMAR_REFRACTION           = 8, 
      RAY_GRAMMAR_CAUSTIC              = 16, 
      RAY_GRAMMAR_OUT_OF_SCENE         = 32,
      RAY_GRAMMAR_PHOTON_STORED        = 64,
      RAY_IC_FAILED                    = 128
};



}

class IPhotonMap;

using namespace RAYTR;

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

enum HRT_ERROR_CODES
{
		HRT_NO_MEMORY_AVALIABLE = 1,
		HRT_INCORRECT_SIZE = 2,
		HRT_ZERO_SIZE = 3,
    HRT_INCORRECT_INTERNAL_PARAMETER = 4,
		HRT_UNEXPECTED_FUNCTION_FAIL = 5
};


extern "C" const char* hrtGetErrorMessage(int err_code);
extern "C" int hrtInit(int w,int h, int a_flags);
extern "C" int hrtDelete();
extern "C" int hrtPrintInfo();

#ifdef __CUDACC__
  #ifndef GLuint
    typedef unsigned int GLuint;
  #endif
#endif

extern "C" int hrtBeginTrace(uint AA);
extern "C" int hrtEndTrace(GLuint a_pbo, unsigned int* buffer);
extern "C" int hrtRegisterPBO(GLuint a_pbo);
extern "C" int hrtUnregisterPBO();

extern "C" int hrtFillXYBufferAndClearAccumBuffers();

extern "C" int hrtTraceClientRays1D(const float4* cpu_ray_pos, const float4* cpu_ray_dir, int a_size);
extern "C" int hrtGetColor(float4* cpu_color, int a_size);

extern "C" int hrtMegaBlockTrace1D(float4* rpos, float4* rdir, float4* finalColor, int a_size, int a_deep, uint* a_realThreadsId);

//extern "C" int hrtSetWorldMatrix(const float* matrix);
extern "C" int hrtSetSpheres(const sphere4* spheres,int n);
extern "C" int hrtSetCommonVertexAttributes(const float4* vPos, const float4* vNorm, const float2* vTexCoord, const int* vMaterialIndices, int n);
extern "C" int hrtSetTangentAtrributes(const float4* vTan, int n);
extern "C" int hrtSetIndices32(const unsigned int* indices,int n);
extern "C" int hrtSetMaterialIndices32(const unsigned int* indices, int n);

extern "C" int hrtSetCurrAccelStructType(int a_type);
extern "C" int hrtSetWorldObjectListData(const char* in_objListData, uint in_sizeInBytes);
extern "C" int hrtSetPrmitiveListIndexData(const int* in_primListIndexData, uint in_size);

extern "C" int hrtSetWorldKdTree(const box3& box, const KdTreeNode* root, unsigned int nodes_count);
extern "C" int hrtSetWorldBVH(const BVHNode* root, unsigned int nodes_count);

extern "C" int hrtSetRegularBBox(float3 vmin, float3 vmax);

extern "C" int hrtSetHydraMaterials(const RAYTR::HydraMaterial* materials,int n);

extern "C" int hrtSetLights(const RAYTR::Light* a_lights, int n);
extern "C" int hrtAddLightMesh(float4* a_triangles, float2* a_probIntervals, int N);


extern "C" int hrtShadePass(int a_size, const float4* rpos, float4* rdir, const uint* ldir, // light position
                            const HitPosNorm* hitPos, const HitTexCoord* hitNorm, const HitMatRef* matData,
                            const ushort4* in_shadows, const RayFlags* in_flags, ushort4* inout_color);

extern "C" int hrtPostShadePass(int a_size, float4* rpos, float4* rdir,
                                const HitPosNorm* hitPos, const HitTexCoord* hitNorm, const HitMatRef* matData,
                                float4* inout_color, float2* aux_color, const uint* a_inCompactIndices, const ushort4* in_shaderColor, RayFlags* pt_flags, uint* a_stencilBuffer);


extern "C" int hrtOctreeLookUpPass(int a_size,const float4* rdir, const HitPosNorm* in_hitPos, const HitTexCoord* in_hitNorm, const HitMatRef* in_matData, const Hit_Part4* in_tangent,
                                   ushort4* inout_color, const ushort2* in_xy, ushort4* out_fullScreenIrradiance, RayFlags* a_flags);

extern "C" int hrtComputeHitPass(int a_size, const float4* rpos, const float4* rdir, const Lite_Hit* in_hits,
                                 HitPosNorm* out_hitPos, HitTexCoord* out_hitNorm, HitMatRef* out_matData, Hit_Part4* out_hitTangent, unsigned int* a_stencilBuffer);

extern "C" int hrtTraverseRays1D(float4* gpu_rpos, float4* gpu_rdir, Lite_Hit* gpu_out_hit, int a_size, Timer& a_timer);
extern "C" int hrtTraverseMegaBlock(float4* gpu_rpos, float4* gpu_rdir, Lite_Hit* gpu_out_hit, int a_size);
extern "C" int hrtTraceShadowRays(const HitPosNorm* in_hitPos, const RayFlags* in_flags, ushort4* shadows, uint* light_pos, float4* rdir, int a_size, Timer& a_timer);



extern "C" int hrtResetZOrderTo(float4* gpu_color, int w, int h);

extern "C" int hrtSetWindowResolution(int w, int h);
extern "C" int hrtVerifySystem();
extern "C" int hrtGetPerfInfo(float*, int index);
extern "C" size_t hrtGetAvaliableMemoryAmount();

extern "C" int hrtGetMegaBlockSize();
extern "C" int hrtSetFlags(int bits,int value);
extern "C" int hrtPushAllFlags();
extern "C" int hrtPopAllFlags();
extern "C" int hrtPushAllVars();
extern "C" int hrtPopAllVars();
extern "C" int hrtSetVariableF(int name, float value);
extern "C" int hrtSetVariableI(int name, int value);
extern "C" float hrtGetVariableF(int name);
extern "C" int   hrtGetVariableI(int name);

extern "C" int hrtDumpFloat4Buffer(const float4* a_gpu_buff, int size, const char* fileName);
extern "C" int hrtDumpBuffer(const void* a_gpu_buff, int byteSize, const char* fileName);
extern "C" int hrtLoadBuffer(const char* a_gpu_buff, int byteSize, const char* fileName);

extern "C" int hrtGetBuffer(const char* a_buffName, void* data, int byteSize, GLuint a_pbo);
extern "C" int hrtGetBufferSize(const char* a_buffName);

extern "C" float hrtGetRaysPerSec();
extern "C" float hrtGetSamplesPerSec();
extern "C" float hrtGetTraceTimePerCent();
extern "C" float hrtGetReorderTimeInSec();
extern "C" float hrtGetTotalTraceTime();
extern "C" float hrtGetOneTraversalTime();
extern "C" float hrtGetSampleTime();
extern "C" void  hrtResetCounters();

extern "C" bool hrtIfSortNow(int a_bounce);
extern "C" bool hrtIfCompactNow(int a_bounce);

extern "C" int hrtStorePositionsAndNormalsForIC(int a_size);
extern "C" int hlmAllocIrradianceCacheFullScreenBuffers(int size, int allocPart = 2);
extern "C" int hlmFreeIrradianceCacheFullScreenBuffers();
extern "C" int hlmCalcSurfaceDiscontinuity(float* discontinuityMips, float* pixelSize);
extern "C" int hlmCalcRadianceDiscontinuity(float* a_discontinuityCPU, int a_size, int a_minPixelStep);


extern "C" int hrtClearMegaTextures();
extern "C" int hrtAddMegaTexture4ub(const char* usage, bool outOfCore, const char* data, int width, int height, const float4* lut, int lutSize);

extern "C" int hrtCreateEnvLightMapCube(int w, int h, const void* data[6]);

extern "C" int hrtCreateEnvLightMapSphereHDR(int w, int h, const float* data);
extern "C" int hrtCreateEnvLightMapSphereLDR(int w, int h, const unsigned char* data);
extern "C" int hrtSetEnvLightScale(float3 a_scale);

// ray samples filtering
//
extern "C" int hrtPutRaySamplesColorXY(float4* a_data, const float4* a_geomData, int a_size, int a_offsetFirstPixel);
extern "C" int hrtPutRaySamplesGeom(const float4* a_geomData, int a_size, int a_layer);
extern "C" int hrtPutRaySamplesUV(const float2* a_uv, int a_size, int a_layer);
extern "C" int hrtPutRaySamplesShadow(const uint* a_uv, int a_size, int a_layer);

// helpers to get more memory
// use them if you are strongly out of memory inside some algorithm
//
extern "C" int hrtAllocScreenBuffersData(int w = -1, int h = -1);
extern "C" int hrtFreeScreenBuffersData();

extern "C" int hrtFreePerRayData();
extern "C" int hrtAllocPerRayData(int a_size = -1);

extern "C" int hrtPTAllocPerRayData(int a_size = -1);
extern "C" int hrtPTFreePerRayData();


extern "C" int hrtPhotonMapSetActiveMap(const char* usage, IPhotonMap* pPhotonMap, bool a_active);
extern "C" int hrtRadianceCacheSetGlobalAlpha(float a_alpha);

extern "C" int hrtClearPrimitiveIndicesFromFGFlags(int a_flag);

extern "C" int hrtThreadSynchronize();
extern "C" int hrtInitQMC();
extern "C" int hrtNextSequenceQMC();


// crap

extern "C" const char* sga_cudaMemcpyToSymbol(const char* name, void* data, int a_size);

enum {AA_STRATIFICATION_X = 1, AA_STRATIFICATION_Y = 1};

enum FLAG_BITS{HRT_COMPUTE_SHADOWS    = 1,
               HRT_DISABLE_SHADING    = 2, // need this flag for photon trace and bidirectional path tracing
               HRT_DIFFUSE_REFLECTION = 4,
               HRT_USE_RANDOM_RAYS    = 8,
               HRT_SAVE_SURFACE_DATA  = 16,
               HRT_FINAL_GARTHER      = 32,
               HRT_COMPUTE_IRRADIANCE_CACHE   = 64,
               HRT_RC_VOXELS                  = 128,
               HRT_IRRDAIANCE_CACHE_FIND_SECONDARY = 256,
               HRT_USE_PATH_TRACING_INSTEAD_OF_RT  = 512,
               HRT_DISABLE_BUMP             = 1024,
               HRT_ENV_MAP_CUBEMAP_ACTIVE   = 2048,
               HRT_ENV_MAP_SPHEREMAP_ACTIVE = 4096,
               HRT_STORE_RAY_SAMPLES        = 8192,
               HRT_USE_HDR_ESTIMATION       = 16384,
               HRT_RC_HARMONICS             = 32768,
               HRT_RC_CUBEMAPS              = 65536,
               HRT_DIFFUSE_PHOTON_TRACING   = 65536*2,
               HRT_CAUSTIC_PHOTON_TRACING   = 65536*4,
               HRT_STUPID_PT_MODE           = 65536*8,
               HRT_TRACE_GLASS_RECURSIVE    = 65536*16,
               HRT_MARK_SURFACES_FG         = 65536*32, // this mode trace rays from screen and mark visible surfaces
               HRT_COLOR_WRITE_DISABLE      = 65536*64, // this mode trace rays from screen and mark visible surfaces
               HRT_DEBUG_DRAW_LIGHT_PHOTONS = 65536*128,
               HRT_PHOTONS_STORE_MULTIPLY_COLORS = 65536*256,
               HRT_GARTHER_CAUSTICS              = 65536*512,
               HRT_TRANSFORM_IC_TO_PHMAP         = 65536*1024,
               HRT_ENABLE_PT_CAUSTICS            = 65536*2048,
               HRT_ENABLE_SR_OCTREE              = 65536*4096,
               HRT_ENABLE_QMC_ONE_SEED           = 65536*8192,
               HRT_ENABLE_COHERENT_PT            = 65536*16384
              };

enum SURFACE_MARKERS {SURF_FRONT = 0x80000000, 
                      SURF_BACK  = 0x40000000}; // we can use other 30 bits for index or sms like that


enum VARIABLE_NAMES { // int vars
                      //
                      HRT_ENABLE_DOF               = 0,
                      HRT_DEBUG_DRAW_LAYER         = 1,
                      HRT_FIRST_BOUNCE_STORE_CACHE = 2,
                      HRT_DISABLE_MRAYS_COUNTERS   = 3,
                      HRT_DEBUG_OUTPUT             = 4,
                      HRT_MEASURE_RAYS_TYPE        = 5,
                      HRT_DEBUG_SH_ENVIRONMENT     = 6,
                      HRT_IC_HARMONIC_MEAN         = 7,
                      HRT_TEXCACHE_MAX_MEMORY      = 8,
                      HRT_TRACE_DEPTH              = 9,
                      HRT_PHOTONS_STORE_BOUNCE     = 10,
                      HRT_PHOTONS_GARTHER_BOUNCE   = 11,
                      HRT_RAYS_APPENDBUFFER_SIZE   = 12,
                      HRT_DIFFUSE_TRACE_DEPTH      = 13,
                      HRT_DISPLAY_IC_INTERMEDIATE  = 14,
                      HRT_PT_FILTER_TYPE           = 15,
                      HRT_RAY_REORDER_TYPE         = 16,
                      HRT_RAY_REORDER_PATTERN      = 17,
                      HRT_VAR_ENABLE_RR            = 18
};

enum VARIABLE_FLOAT_NAMES{ // float vars
                           //
                           HRT_DOF_LENS_RADIUS      = 0,
                           HRT_DOF_FOCAL_PLANE_DIST = 1,
                           HRT_IC_WS_ERROR_TRESHOLD = 2,
                           HRT_TRACE_PROCEEDINGS_TRESHOLD = 3, 
                           HRT_ACCEPTABLE_PATH_TRACING_PIXEL_ERROR = 4,
                           HRT_CAUSTIC_POWER_MULT                  = 5
};


// globals for GPU


static __constant__ unsigned short MortonTable256[] =
{
  0x0000, 0x0001, 0x0004, 0x0005, 0x0010, 0x0011, 0x0014, 0x0015,
  0x0040, 0x0041, 0x0044, 0x0045, 0x0050, 0x0051, 0x0054, 0x0055,
  0x0100, 0x0101, 0x0104, 0x0105, 0x0110, 0x0111, 0x0114, 0x0115,
  0x0140, 0x0141, 0x0144, 0x0145, 0x0150, 0x0151, 0x0154, 0x0155,
  0x0400, 0x0401, 0x0404, 0x0405, 0x0410, 0x0411, 0x0414, 0x0415,
  0x0440, 0x0441, 0x0444, 0x0445, 0x0450, 0x0451, 0x0454, 0x0455,
  0x0500, 0x0501, 0x0504, 0x0505, 0x0510, 0x0511, 0x0514, 0x0515,
  0x0540, 0x0541, 0x0544, 0x0545, 0x0550, 0x0551, 0x0554, 0x0555,
  0x1000, 0x1001, 0x1004, 0x1005, 0x1010, 0x1011, 0x1014, 0x1015,
  0x1040, 0x1041, 0x1044, 0x1045, 0x1050, 0x1051, 0x1054, 0x1055,
  0x1100, 0x1101, 0x1104, 0x1105, 0x1110, 0x1111, 0x1114, 0x1115,
  0x1140, 0x1141, 0x1144, 0x1145, 0x1150, 0x1151, 0x1154, 0x1155,
  0x1400, 0x1401, 0x1404, 0x1405, 0x1410, 0x1411, 0x1414, 0x1415,
  0x1440, 0x1441, 0x1444, 0x1445, 0x1450, 0x1451, 0x1454, 0x1455,
  0x1500, 0x1501, 0x1504, 0x1505, 0x1510, 0x1511, 0x1514, 0x1515,
  0x1540, 0x1541, 0x1544, 0x1545, 0x1550, 0x1551, 0x1554, 0x1555,
  0x4000, 0x4001, 0x4004, 0x4005, 0x4010, 0x4011, 0x4014, 0x4015,
  0x4040, 0x4041, 0x4044, 0x4045, 0x4050, 0x4051, 0x4054, 0x4055,
  0x4100, 0x4101, 0x4104, 0x4105, 0x4110, 0x4111, 0x4114, 0x4115,
  0x4140, 0x4141, 0x4144, 0x4145, 0x4150, 0x4151, 0x4154, 0x4155,
  0x4400, 0x4401, 0x4404, 0x4405, 0x4410, 0x4411, 0x4414, 0x4415,
  0x4440, 0x4441, 0x4444, 0x4445, 0x4450, 0x4451, 0x4454, 0x4455,
  0x4500, 0x4501, 0x4504, 0x4505, 0x4510, 0x4511, 0x4514, 0x4515,
  0x4540, 0x4541, 0x4544, 0x4545, 0x4550, 0x4551, 0x4554, 0x4555,
  0x5000, 0x5001, 0x5004, 0x5005, 0x5010, 0x5011, 0x5014, 0x5015,
  0x5040, 0x5041, 0x5044, 0x5045, 0x5050, 0x5051, 0x5054, 0x5055,
  0x5100, 0x5101, 0x5104, 0x5105, 0x5110, 0x5111, 0x5114, 0x5115,
  0x5140, 0x5141, 0x5144, 0x5145, 0x5150, 0x5151, 0x5154, 0x5155,
  0x5400, 0x5401, 0x5404, 0x5405, 0x5410, 0x5411, 0x5414, 0x5415,
  0x5440, 0x5441, 0x5444, 0x5445, 0x5450, 0x5451, 0x5454, 0x5455,
  0x5500, 0x5501, 0x5504, 0x5505, 0x5510, 0x5511, 0x5514, 0x5515,
  0x5540, 0x5541, 0x5544, 0x5545, 0x5550, 0x5551, 0x5554, 0x5555
};

static inline __device__ uint ZIndex(ushort x,ushort y)
{
  return	MortonTable256[y >> 8]   << 17 |
          MortonTable256[x >> 8]   << 16 |
          MortonTable256[y & 0xFF] <<  1 |
          MortonTable256[x & 0xFF];
}

static inline universal_call unsigned short ExtractXFromZIndex(unsigned int zIndex)
{
  int result = 0;
  for(int i=0;i<16;i++)
    result |= ((1 << 2*i) & zIndex) >> i;
  return (unsigned short)result;
}


static inline universal_call unsigned short ExtractYFromZIndex(unsigned int zIndex)
{
  int result = 0;
  for(int i=0;i<16;i++)
    result |= ((1 << (2*i+1)) & zIndex ) >> i;
  return (unsigned short)(result >> 1);
}



#ifdef __CUDACC__

#include <cuda.h>
#include <cuda_runtime.h>
#include <curand.h>
#include <curand_kernel.h>

#include "cutilStuff.h"

#include <iostream>
#include <stack>
#include <fstream>

class ITextureCache
{
public:

  ITextureCache();
  virtual ~ITextureCache();

  virtual int GetNumLines() const = 0;
  virtual void SetNumLines(int a_lines) = 0;

  virtual int GetNumBinsX() const {return 0;}
  virtual int GetNumBinsY() const {return 0;}

  virtual void BeginObtainHitMissTable(){}
  virtual void EndObtainHitMissTable(){}

protected:
  ITextureCache(const ITextureCache& rhs){}
  ITextureCache& operator=(const ITextureCache& rhs) {return *this;}

};

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>
#include <thrust/sort.h>
#include <thrust/copy.h>

struct LightMeshData
{
  thrust::device_vector<float4> positions;
  thrust::device_vector<float2> intervals;
};

template<typename T> static inline T* get_pointer(thrust::device_vector<T>& rhs) { return thrust::raw_pointer_cast(&rhs[0]); }
template<typename T> static inline const T* get_pointer(const thrust::device_vector<T>& rhs) { return thrust::raw_pointer_cast(&rhs[0]); }

template<typename T> static inline T* get_pointer(thrust::host_vector<T>& rhs) { return &rhs[0]; }
template<typename T> static inline const T* get_pointer(const thrust::host_vector<T>& rhs) { return &rhs[0]; }

struct Hardware_Ray_Tracer
{
	Hardware_Ray_Tracer();
	~Hardware_Ray_Tracer();

  void InitTexRefs();
  void BindAllTexRefs();
  void UnbindAllTexRefs();

  void SetCurrLight(const int in_lightIndex);

  int GpuMemSet(void* in_gpuBuffer,int value, int size);
  int GpuMemSetF(void* in_gpuBuffer, float value, int in_size);
  int CalcPersistentThreadsAndResetWarpCounter(int size, int regCount, int myThreadCount, bool debugOutput = false);

	int width, height;
  struct cudaGraphicsResource* m_screenBuffPixels;

	int numSpheres;
	int numVertices;
	int numIndices;

  RAYTR::Light* m_lights;
  RAYTR::Light* m_lightsGPU;
  int m_numLights;

  bool m_colorShadows;

	sphere4* sphere_memory;
	uint* index_memory;
  float4* m_triangleMatrices;

  // ACCEL STRUCTURES
	char* world_kd_tree_memory;
	char* m_primListMemory;
  BVHNode* m_worldBVH;
  uint*    m_primIndices;

  int m_kdTreeSize;
  int m_bvhSize;
  int m_primListSize;
  int m_primListIndicesSize;

  float4* m_vertPositionsAndMatIndex; // x,y,z - positions; __float_as_int(w) - material id
  float4* m_vertNormals;
  float4* m_vertTangent;
  float2* m_vertTexCoord;
  uint*   m_vertCompressedNormals;

  uint*    m_matIndicesPerTriangle;
  int     m_numMaterialIndicesPerTriangle;

  struct PlainMemoryManager
  {
    PlainMemoryManager() : data(NULL), m_sizeInBytes(0) {}

    void* data;
    int   m_sizeInBytes;

    struct Buffer
    {
      Buffer(void** a_ppData, int a_size) : ppData(a_ppData), m_sizeInBytes(a_size) {}
      void** ppData;
      int m_sizeInBytes;
    };

    std::vector<Buffer> m_buffers;

    void registerBuffer(void** a_pData, int a_size) 
    {
      if(a_size % 4096 != 0) a_size = (a_size/4096 + 1)*4096; // align to 4KB 
      m_buffers.push_back(Buffer(a_pData, a_size)); 
    }

    void freeAll() { for(int i=0;i<m_buffers.size();i++) (*m_buffers[i].ppData) = NULL; cudaFree(data); data = NULL; m_buffers.clear(); }
    void allocAll()
    {
      int totalSize = 0;
      for(int i=0;i<m_buffers.size();i++) totalSize += m_buffers[i].m_sizeInBytes;
      m_sizeInBytes = totalSize;
 
      CUDA_SAFE_CALL(cudaFree(data)); 
      CUDA_SAFE_CALL(cudaMalloc((void**)&data, totalSize)); 

      char* currPointer = (char*)data;
      for(int i=0;i<m_buffers.size();i++)
      {
        (*m_buffers[i].ppData) = currPointer;
        currPointer += m_buffers[i].m_sizeInBytes;
      }
    }

    // using the same memory for different purposes
    //
    int m_viewOfMemTop;
    std::vector<Buffer> m_viewBuffers;

    void viewOfMemoryClear() { m_viewOfMemTop = 0; for(int i=0;i<m_viewBuffers.size();i++) m_viewBuffers.clear(); }
    int  viewOfMemoryAvaliableMemoryAmount() { return m_sizeInBytes - m_viewOfMemTop;}

    void* viewOfMemoryAlloc(int a_size) 
    { 
      if(m_viewOfMemTop + a_size > m_sizeInBytes) return NULL;

      char* currData = (char*)(data) + m_viewOfMemTop; 

      if(a_size % 4096 != 0) a_size = (a_size/4096 + 1)*4096; // align to 4KB 
      m_viewBuffers.push_back(Buffer(NULL, a_size));
      m_viewOfMemTop += a_size;
     
      return currData;
    }

    void viewOfMemoryFreeLast()
    {
      int i = m_viewBuffers.size()-1;
      m_viewOfMemTop -= m_viewBuffers[i].m_sizeInBytes;
      m_viewBuffers.pop_back();
    }

  };

  PlainMemoryManager m_rayMem;
  //PlainMemoryManager m_auxMem;
  //uint* tmpPhotonsKeys;
  //uint* tmpPhotonsOffs;

  // per rey data ?
  float4*   m_pathTraceColor;
  float4*   m_pathTraceColor2;
  float4*   m_pathTraceSquareSumm;

  float4*   m_raysPos;
  float4*   m_raysDir;

  float4*   m_raysPos2;
  float4*   m_raysDir2;

  uint*     m_compactionIndices[2];
  // \\ used for rays compaction and sorting

  ushort2*  m_xy; // full screen

  //curandGenerator_t m_qrng; // for one seed QMC
  
  float* m_randsQMC;
  curandDirectionVectors32_t* m_sobolDirections;
  curandStateSobol32_t* m_sobolStates;
  int m_qmcTop;
  curandGenerator_t m_qrng;

  //
  //
  uint*        m_shadowLightVector;
	Lite_Hit*	   hits;
  HitPosNorm*  m_hitPos;
  HitTexCoord* m_hitUV0;
  HitMatRef*   m_hitMaterial;
  Hit_Part4*   m_hitTangent;
  float*       m_frustumDepth;
  float4*      m_photonsTempColor;
	ushort4*     shadows;
  uint*        m_rayXYOffsets;

  struct AppendRays
  {
    AppendRays() : rays_pos(NULL), rays_dir(NULL), rays_flags(NULL), rays_knext(NULL), m_size(0), m_realRaysCount(0) {}
    //~AppendRays() { free(); }

    void alloc(int a_size);
    void free();

    float4*   rays_pos;   // pos + tid
    float4*   rays_dir;   // dir + ushort(knext.z)
    RayFlags* rays_flags; // flags
    ushort2*  rays_knext; // + ushort2(knext.x, knext.x)

    int size() { return m_realRaysCount; }
    int capacity() { return m_size; }

    int popRays(int a_popedRaysNumber);
    void setSize(int a_size) { m_realRaysCount = a_size;}

    int m_size;
    int m_realRaysCount;

  } appendBuffers;

  IPhotonMap*    m_pCurrPhMap;    // for photons storing
  IPhotonMap*    m_pDiffusePhMap; // for gather diffuse photons
  IPhotonMap*    m_pCausticPhMap; // for gather caustics

  enum {MAX_LEAFES_INTERSECT = 32};
  enum {POINT_LIGHT_SHADING_TYPE,
        SPOT_LIGHT_SHADING_TYPE,
        FLAT_LIGHT_SAMPLE_SHADING_TYPE};

  float4*  m_color;
  float2*  m_colorAux;
  uint*    m_tidCopy;

  ushort4* m_shaderColor;  // compressed (halfs) shader color; used for different purposes.
  float2*  m_auxNextColor; // store green and blue component when reflect or refract ray

  HydraMaterial* m_hydraMaterials;
  uint m_hydraMaterialsSize;

  uint* m_stencilBuffer;
  RayFlags* m_pathFlags;
  RayFlags* m_pathFlags2;

  int m_currAccelStruct;
  bool m_useInputRays;
  bool m_colectIrradiance;
  bool m_storeDepth;

  int m_gpuNumber;
  int MEGA_BLOCK_SIZE;

  IrradianceCachePoint_Part1* m_cpu_lightCache1;
  IrradianceCachePoint_Part2* m_cpu_lightCache2;
  int m_lastCacheOffset;

  ushort4* m_fullScreenIrradiance;

  // time measurements
  //
  float m_ray_traversal_time;
  float m_sampleEvalTime;
  float m_reorderTime;
  float m_shadowTime;
  float m_totalTraceTime;
  int   m_traversed_rays;
  int   m_evaledSamples;

  int g_flags;
  std::stack<int> m_flagsStack;

  cudaDeviceProp m_devProp;

  ushort* m_tempBuffers[16];
  float4* m_tempCachePosBuffer;
  int     m_tempCachePosBufferSize;

  enum {MEGA_TEX_MAX_NUMBER = 4};
  cudaArray* m_megaTexturesData[MEGA_TEX_MAX_NUMBER];
  void*      m_megaTexPinnedData[MEGA_TEX_MAX_NUMBER];
  float4*    m_megaTexLUTs[MEGA_TEX_MAX_NUMBER];
  int        m_megaTexDataTop;

  bool m_shadingTextureSWEnabled;
  bool m_normalmapTextureSWEnabled;
  ITextureCache* m_texCache;
  ITextureCache* m_texCacheNormalmaps;

  cudaArray* m_pEnvMap;

  inline bool RaySamplesSavingEnabled() const { return ((g_flags & HRT_STORE_RAY_SAMPLES) && (g_flags & HRT_USE_RANDOM_RAYS));}
  int m_raySampleNumber;

  std::vector<LightMeshData> m_meshLightsData;

  int m_currBounce;

  enum {MAXVARS = 32};
  int   m_varsI[MAXVARS];
  float m_varsF[MAXVARS];

  struct InternalVars
  {
    int   m_varsI[MAXVARS];
    float m_varsF[MAXVARS];
  };

  std::stack<InternalVars> m_varsStack;

};

typedef Hardware_Ray_Tracer HRT;

__constant__ int   g_ivars[Hardware_Ray_Tracer::MAXVARS];
__constant__ float g_fvars[Hardware_Ray_Tracer::MAXVARS];


__constant__ int  window_size[2];
__constant__ float pWorldKdTreeBox[sizeof(box3)/sizeof(float)];

__constant__ float g_sceneBoundingSphereDiameter;
__constant__ int g_currLightId = 0;

__constant__ int cm_maxThread;

__constant__ int cm_megaBlockSize;
__constant__ int cm_multiSampleBlockSize[2];

__constant__ int g_currBounce;

__constant__ float g_traceProocedingsTreshold;
__constant__ float g_pathTraceError;

__constant__ float g_dofFocalPlaneDist;
__constant__ float g_dofLensRadius;
__constant__ int   g_dofEnable;

__constant__ int g_threadZeroOffset;

__constant__ float cm_gamma[2];
__constant__ float cm_koefGamma[2];

__constant__ float3  cm_icache_kd_tree_box[2];

// path tracing and irradiance cache constants
//
__constant__ int cm_zBlocks;


__constant__ int cm_hemisphereRaysSize[4];
__constant__ int cm_hemRaysIndex = 1;

__constant__ float3 cm_octreeCenter;
__constant__ float  cm_octreeSize;
__constant__ float  g_serchRadiusSquare;
__constant__ float  g_searchRadius;
__constant__ float  g_searchRadiusInv;

__constant__ float  g_cubemapSize;

__constant__ float3 g_regularBMin;
__constant__ float3 g_regularBMax;
__constant__ float3 g_regularBCenter;
__constant__ float  g_regularBSizeInv;

__constant__ float4x4 g_mViewProjInv;
__constant__ float4x4 g_mWorldViewInv;

__constant__ float g_gamma = 2.2f;

static __device__ int g_warpCounter; // Work counter for persistent threads.

static __device__ int g_stencilMask[32] = {
  0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080,
  0x00000100, 0x00000200, 0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000,
  0x00010000, 0x00020000, 0x00040000, 0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000,
  0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000
};

__constant__ int g_disablePOMbecauseOfSpeed = 0;
__constant__ int g_envmapUseSHReconstruction = 0;
__constant__ int g_debugLayerDraw = 0;


#define PERSISTENT_THREAD_ID(tid,BLOCK_SIZE)    \
__shared__ int s_nextWarpId[(BLOCK_SIZE)/32];   \
int& nextWarpId = s_nextWarpId[threadIdx.x/32]; \
if(threadIdx.x % 32 == 0)                       \
nextWarpId = atomicAdd(&g_warpCounter, 32);     \
tid = nextWarpId + threadIdx.x % 32;            \
if(tid >= cm_maxThread) return;

//#define STENCIL_TEST(tid) \
  // if(!(tex1Dfetch(stencil_tex, (tid) >> 5) & (1 << ((tid)&0x0000001f) ))) \
    // return;

#define STENCIL_TEST2(tid, a_size) \
  if( (tid) >= (a_size) || !(tex1Dfetch(stencil_tex, (tid) >> 5) & (1 << ((tid)&0x0000001f) ))) \
  return;

//#define STENCIL_TEST(tid) \
  //if(!(tex1Dfetch(stencil_tex, (tid) >> 5) & g_stencilMask[(tid)&0x0000001f]) ) \
    //return;

//inline __host__ int blocks(int N, int threadsPerBlock) { return (N/threadsPerBlock)+1; }
inline __host__ int blocks(int N, int threadsPerBlock)   { return (N + threadsPerBlock - 1)/threadsPerBlock; }

inline __device__ uint Index2D(uint x, uint y) { return y*window_size[0] + x; }
inline __device__ uint Index2D(uint x, uint y, int pitch) { return y*pitch + x; }
inline __device__ uint IndexZBlock2D(int x, int y)
{
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint zIndex = ZIndex(zOrderX, zOrderY);

  uint wBlocks = window_size[0]/Z_ORDER_BLOCK_SIZE;
  uint blockX = x/Z_ORDER_BLOCK_SIZE;
  uint blockY = y/Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
}

inline __device__ uint IndexZBlock2DChess(int x, int y)
{
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint zIndex = ZIndex(zOrderX, zOrderY)/2;
  if( (zOrderY + zOrderX) % 2 == 1)
    zIndex += 128;

  uint wBlocks = window_size[0]/Z_ORDER_BLOCK_SIZE;
  uint blockX = x/Z_ORDER_BLOCK_SIZE;
  uint blockY = y/Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
}

inline __device__ uint Index2DSwizzled(uint x, uint y)
{
  if((g_flags & HRT_ENABLE_COHERENT_PT) && !(g_flags & (HRT_IRRDAIANCE_CACHE_FIND_SECONDARY | HRT_COMPUTE_IRRADIANCE_CACHE | HRT_ENABLE_QMC_ONE_SEED)) )
    return IndexZBlock2DChess(x,y);
  else
    return IndexZBlock2D(x,y);
}


//////////////////////////////////////////////////////////////////////////////////
////
__host__ void SafeGpuMemSet(void* in_gpuBuffer,int value, int size, char* file, int line);
#define SAFE_GPU_MEMSET(buff,value,size) SafeGpuMemSet((buff),(value),(size),__FILE__,__LINE__)


texture<uint4 , 1, cudaReadModeElementType> sph_tex;

texture<float4, 1, cudaReadModeElementType> vert_pos_tex;
texture<float4, 1, cudaReadModeElementType> vert_tangent_tex;
texture<float2, 1, cudaReadModeElementType> vert_texCoord_tex;
texture<uint , 1, cudaReadModeElementType>  vert_indices_tex;
texture<uint , 1, cudaReadModeElementType>  triMatInd_tex;
texture<uint, 1, cudaReadModeElementType>   vertNormCompressed_tex;

texture<uint2 , 1, cudaReadModeElementType> world_kd_tree_tex;
texture<float4, 1, cudaReadModeElementType> bvh_tex;
texture<float4, 1, cudaReadModeElementType> bvh_rc_tex;
texture<float4, 1, cudaReadModeElementType> rcRecords_tex;
texture<float4, 1, cudaReadModeElementType> primLists_tex;
texture<uint,   1, cudaReadModeElementType> primIndices_tex;
texture<float,  1, cudaReadModeElementType> shmat_tex;

texture<float4, 1, cudaReadModeElementType> real_color_tex;

// path tracing and irradiance cache textures
//
texture<float4, 1, cudaReadModeElementType> icache1_tex;
texture<float4, 1, cudaReadModeElementType> icache2_tex;

texture<uint4, 1, cudaReadModeElementType> zblocks_tex;

texture<float4, 1, cudaReadModeElementType> pathTracingColor_tex;

texture<float4, 1, cudaReadModeElementType> hemisphereRaysDir_tex;

texture<float4, 1, cudaReadModeElementType> iCachePos_tex;
texture<float4, 1, cudaReadModeElementType> iCacheNorm_tex;
texture<float4, 1, cudaReadModeElementType> iCacheColor_tex;

texture<float4, 1, cudaReadModeElementType> iCacheCompressed1_tex;
texture<uint4,  1, cudaReadModeElementType> iCacheCompressed2_tex;

texture<float2, 1, cudaReadModeElementType> octree_tex;
texture<uint,   1, cudaReadModeElementType> icache_indices_tex;

texture<uint, 1, cudaReadModeElementType>   stencil_tex;


texture<float4, 2, cudaReadModeElementType>          input4fTemp1_tex;
texture<float, 2, cudaReadModeElementType>           input1fTemp1_tex;
texture<unsigned short, 2, cudaReadModeElementType>  input1hTemp1_tex;

texture<float, 2, cudaReadModeElementType>  surfDiscMip0_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip1_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip2_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip3_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip4_tex;

__constant__ int g_hdrEnvMap = 0;
texture<uchar4,  2, cudaReadModeNormalizedFloat>  envMap;
texture<ushort4, 2, cudaReadModeNormalizedFloat>  envMap2;

texture<uchar4, cudaTextureTypeCubemap, cudaReadModeNormalizedFloat>  envMapCube;

const int MTCBINSIZE = 16;
__device__ int g_cacheBins1[MTCBINSIZE*MTCBINSIZE];
__device__ int g_cacheBins2[MTCBINSIZE*MTCBINSIZE];
__constant__ int g_collectCacheMissInfo = 1;
__constant__ int g_oddEvenBinStorage = 0;

struct TexCacheLine
{
  enum {LINE_IS_BUSY = 1};

  float2 vmin;
  float2 vmax;
  float2 rectSize;
  int    flags;
};

template<class Data>
struct SWTexture
{
  float width;
  float height;
  const Data* data;

  float binsX;
  float binsY;
  TexCacheLine lines[4];
};

__constant__ SWTexture<uchar4> shadingTextureSW;
__constant__ SWTexture<uchar4> normalmapTextureSW;

texture<uchar4, 2, cudaReadModeNormalizedFloat> shadingTexture;
texture<uchar4, 2, cudaReadModeNormalizedFloat> transparencyTexture;
texture<uchar4, 2, cudaReadModeNormalizedFloat> normalmapTexture;

texture<float4, 1, cudaReadModeElementType> shadingTextureLUT;
texture<float4, 1, cudaReadModeElementType> transparencyTextureLUT;
texture<float4, 1, cudaReadModeElementType> normalmapTextureLUT;

//__constant__ float



#endif
