#define MATERIAL_GUARDIAN

#ifndef MGML_GPU_GUARDIAN
  #include "../CSL/MGML_GPU.h"
#endif

#ifndef __CUDACC__

  #ifndef MGML_GUARDIAN
    #include "../CSL/MGML_ERROR.h"
  #endif

#endif

namespace RAYTR
{
  #define INVALID_TEXTURE  0x80000000
  #define CUBE_MAP_TEXTURE 0x00800000
  #define TEX_TYPE_MASK    0xff000000
  #define TEX_ID_MASK      0x007fffff

  // they are related because data are storen in one int32 variable triAlphaTest
  //
  #define ALPHA_MATERIAL_MASK   0x00FFFFFF
  #define ALPHA_LIGHTMESH_MASK  0xFF000000
  #define ALPHA_LIGHTMESH_SHIFT 24

  struct HydraMaterial
  {

    static universal_call float MaxCosPower() { return 1e6f; };

    enum BRDFS{
      BRDF_CONSTANT           = 0,
      BRDF_PHONG              = 1,
      BRDF_BLINN              = 2,
      BRDF_COOK_TORRANCE      = 3,
      BRDF_WARD               = 4,
      BRDF_FRESNEL_DIELECTRIC = 5,
      BRDF_FRESNEL_CONDUCTOR  = 6,
    };


    struct Ambient
    {
      float3 color;
      int    color_texId;           // ������� ��� = 0 : ambient_val = ambient.color*Tex2D(textures[ambient.ka_texId]);
                                    // �����             ambient_val = ambient.color
      float light_multiplyer;       // ���� ������ �������� �������� ���������� ����� �� ��� �������� � ���� ����� �������� �� ��� ���������.
      int light_id;                 // ������ �� ��������

    } ambient;


    struct Diffuse
    {
      float3 color;
      int    color_texId;           // ������� ��� = 0 : diffuse_val = diffuse.color*Tex2D(textures[diffuse.kd_texId]);
                                    // �����             diffuse_val = diffuse.color
      float radiance;               // �� ������� = 1.0f, ����� ��� ������c�� - ������������ ��������.

    } diffuse;


    struct Reflection
    {
      float3 color;
      int    color_texId;

      float  power;        // cosine power
      float  roughness;    // for Cook Torrance only
      float  fresnelIOR;   // Index Of Refraction; if material is transparent it should be equal to 'transparency.IOR'

      int    power_texId;
      int    roughness_texId;
      int    fresnelIOR_texId;

      int    brdf_id;      // contain Fresnel flag
    };

    Reflection specular;
    Reflection reflection;

    struct Transparency
    {
      float3 color;
      int color_texId;

      float3 fogColor;
      float  fogMultiplyer;

      float3 exitColor;

      float IOR;
      int IOR_texId;

      float glossiness;

    } transparency;

    struct Displacement
    {
      float height;

      int normals_texId;
      int height_texId;

    } displacement;

    enum GENERAL_FLAGS {
      THIS_IS_LIGHT            = 1,  // ���� ���� = 1 �� ������ �������� ������������ ����� �������� �����.
      IGNORE_IRRADIANCE_CAHCE  = 2,  // ���� ���� = 1 �� ��� ���������� ����� ���������-���� ��� ����� ��������� �� ����� �������������� ���������-���
      TRACE_REFLECTIONS        = 4,
      TRACE_REFRACTIONS        = 8,
      TRACE_DIFFUSE_RAYS       = 16, // ���� ���� = 1 �� ��� ���������� ����� ����-���� indirect ��������� ��������� ����
      FORCE_TRACE_DIFFUSE_RAYS = 32, // ���� ���� = 1 �� ���� ��� ����������� ����-���� indirect ����� ��������� ��������� ����
      AMBIENT_OCCLUSION        = 64, // ������������ ������������ ambient occlusion ������ ���������� ��������� �����.
      CAST_CAUSTICS            = 128,
      CAST_SPECTRAL_CAUSTICS   = 256,
      REFRACT_CALC_TOTAL_INTERNAL_REFLECTION = 512, // ���� ���� �������� �� �� ��� ���������� � ������ ������� ���������� ���������.
      TRACE_SHADOWS              = 1024,
      TRACE_DISPLACEMENT_SHADOWS = 2048,
      DEBUG_DRAW_NORMALS         = 4096,
      TRANSPARENCY_THIN_SURFACE  = 8192,
      CAST_COLOR_SHADOWS         = 16384, // ��� ������ ������, "������������� �����������"
      MATERIAL_LIGHT_MESH        = 16384*2,
      MATERIAL_LIGHT_MESH_SKIP_DIFFUSE = 16384*4,

      // piece of the import shit
      //
      IMPORT_FLIPXY_TEXCOORD           = 16384*8,  // flip x and y texcoords when importing them
      IMPORT_FLAT_SHADING              = 16384*16, // flip x and y texcoords when importing them
      EMISSION_DISABLE_FOR_PHOTONMAP   = 16384*32

    };

    enum {DEFAULT_FLAGS = TRACE_REFLECTIONS | TRACE_REFRACTIONS | TRACE_DIFFUSE_RAYS | TRACE_SHADOWS };

    int flags;

  #ifndef __CUDACC__

    HydraMaterial()
    {
      memset(this,0,sizeof(HydraMaterial));

      ambient.color = float3(0,0,0);
      ambient.color_texId  = INVALID_TEXTURE;
      diffuse.color_texId  = INVALID_TEXTURE;
      diffuse.radiance     = 1.0f;
      ambient.light_id     = 0xFFFFFFFF;

      specular.power = 60.0f;
      specular.color_texId      = INVALID_TEXTURE;
      specular.fresnelIOR_texId = INVALID_TEXTURE;
      specular.power_texId      = INVALID_TEXTURE;
      specular.brdf_id          = BRDF_PHONG;

      reflection = specular;
      reflection.power = 1e6f;

      transparency.glossiness = 1e6f;
      transparency.fogMultiplyer = 0.5f;
      transparency.color_texId = INVALID_TEXTURE;
      transparency.IOR_texId   = INVALID_TEXTURE;

      displacement.normals_texId = INVALID_TEXTURE;
      displacement.height_texId  = INVALID_TEXTURE;
      displacement.height = 1.0f;

      flags = DEFAULT_FLAGS;
    }


  #endif

  };

//#define PRINT_SHMAT_OFFSETS

#ifdef PRINT_SHMAT_OFFSETS

  static const HydraMaterial gtm_offsets;
  static const float* gtm_pStart = (const float*)&gtm_offsets;

  const int HMAT_AMBIENT_COLOR_X_OFFSET = &gtm_offsets.ambient.color.x - gtm_pStart;
  const int HMAT_AMBIENT_COLOR_Y_OFFSET = &gtm_offsets.ambient.color.y - gtm_pStart;
  const int HMAT_AMBIENT_COLOR_Z_OFFSET = &gtm_offsets.ambient.color.z - gtm_pStart;
  const int HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET = &gtm_offsets.ambient.light_multiplyer - gtm_pStart;
  const int HMAT_AMBIENT_LIGHT_ID_OFFSET = &gtm_offsets.ambient.light_id - (const int*)gtm_pStart;

  const int HMAT_DIFFUSE_COLOR_X_OFFSET  = &gtm_offsets.diffuse.color.x - gtm_pStart;
  const int HMAT_DIFFUSE_COLOR_Y_OFFSET  = &gtm_offsets.diffuse.color.y - gtm_pStart;
  const int HMAT_DIFFUSE_COLOR_Z_OFFSET  = &gtm_offsets.diffuse.color.z - gtm_pStart;
  const int HMAT_DIFFUSE_RADIANCE_OFFSET = &gtm_offsets.diffuse.radiance - gtm_pStart;

  const int HMAT_SPECULAR_COLOR_X_OFFSET     = &gtm_offsets.specular.color.x - gtm_pStart;
  const int HMAT_SPECULAR_COLOR_Y_OFFSET     = &gtm_offsets.specular.color.y - gtm_pStart;
  const int HMAT_SPECULAR_COLOR_Z_OFFSET     = &gtm_offsets.specular.color.z - gtm_pStart;
  const int HMAT_SPECULAR_POWER_OFFSET       = &gtm_offsets.specular.power   - gtm_pStart;
  const int HMAT_SPECULAR_ROUGHNESS_OFFSET   = &gtm_offsets.specular.roughness  - gtm_pStart;
  //const int HMAT_SPECULAR_GLOSSINESS_OFFSET  = &gtm_offsets.specular.glossiness - gtm_pStart;
  const int HMAT_SPECULAR_FRESNEL_IOR_OFFSET = &gtm_offsets.specular.fresnelIOR - gtm_pStart;
  const int HMAT_SPECULAR_BRDF_ID_OFFSET     = &gtm_offsets.specular.brdf_id - (const int*)gtm_pStart;

  const int HMAT_REFLECTION_COLOR_X_OFFSET     = &gtm_offsets.reflection.color.x - gtm_pStart;
  const int HMAT_REFLECTION_COLOR_Y_OFFSET     = &gtm_offsets.reflection.color.y - gtm_pStart;
  const int HMAT_REFLECTION_COLOR_Z_OFFSET     = &gtm_offsets.reflection.color.z - gtm_pStart;
  const int HMAT_REFLECTION_POWER_OFFSET       = &gtm_offsets.reflection.power   - gtm_pStart;
  const int HMAT_REFLECTION_ROUGHNESS_OFFSET   = &gtm_offsets.reflection.roughness  - gtm_pStart;
  //const int HMAT_REFLECTION_GLOSSINESS_OFFSET  = &gtm_offsets.reflection.glossiness - gtm_pStart;
  const int HMAT_REFLECTION_FRESNEL_IOR_OFFSET = &gtm_offsets.reflection.fresnelIOR - gtm_pStart;
  const int HMAT_REFLECTION_BRDF_ID_OFFSET     = &gtm_offsets.reflection.brdf_id - (const int*)gtm_pStart;

  const int HMAT_REFRACTION_COLOR_X_OFFSET      = &gtm_offsets.transparency.color.x - gtm_pStart;
  const int HMAT_REFRACTION_COLOR_Y_OFFSET      = &gtm_offsets.transparency.color.y - gtm_pStart;
  const int HMAT_REFRACTION_COLOR_Z_OFFSET      = &gtm_offsets.transparency.color.z - gtm_pStart;
  const int HMAT_REFRACTION_FOG_COLOR_X_OFFSET  = &gtm_offsets.transparency.fogColor.x - gtm_pStart;
  const int HMAT_REFRACTION_FOG_COLOR_Y_OFFSET  = &gtm_offsets.transparency.fogColor.y - gtm_pStart;
  const int HMAT_REFRACTION_FOG_COLOR_Z_OFFSET  = &gtm_offsets.transparency.fogColor.z - gtm_pStart;
  const int HMAT_REFRACTION_FOG_MULT_OFFSET     = &gtm_offsets.transparency.fogMultiplyer - gtm_pStart;
  const int HMAT_REFRACTION_EXIT_COLOR_X_OFFSET = &gtm_offsets.transparency.exitColor.x - gtm_pStart;
  const int HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET = &gtm_offsets.transparency.exitColor.y - gtm_pStart;
  const int HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET = &gtm_offsets.transparency.exitColor.z - gtm_pStart;
  const int HMAT_REFRACTION_GLOSSINESS_OFFSET   = &gtm_offsets.transparency.glossiness - gtm_pStart;
  const int HMAT_REFRACTION_IOR_OFFSET          = &gtm_offsets.transparency.IOR - gtm_pStart;

  const int HMAT_DISPLACEMENT_HEIGHT_OFFSET    = &gtm_offsets.displacement.height - gtm_pStart;

  const int HMAT_FLAGS_OFFSET                  = &gtm_offsets.flags - (const int*)gtm_pStart;


  const int HMAT_AMBIENT_COLOR_TEX_ID_OFFSET  = &gtm_offsets.ambient.color_texId  - (const int*)gtm_pStart;
  const int HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET  = &gtm_offsets.diffuse.color_texId  - (const int*)gtm_pStart;

  const int HMAT_SPECULAR_COLOR_TEX_ID_OFFSET       = &gtm_offsets.specular.color_texId - (const int*)gtm_pStart;
  const int HMAT_SPECULAR_POWER_TEX_ID_OFFSET       = &gtm_offsets.specular.power_texId - (const int*)gtm_pStart;
  const int HMAT_SPECULAR_ROUGHNESS_TEX_ID_OFFSET   = &gtm_offsets.specular.roughness_texId - (const int*)gtm_pStart;
  //const int HMAT_SPECULAR_GLOSSINESS_TEX_ID_OFFSET  = &gtm_offsets.specular.glossiness_texId - (const int*)gtm_pStart;
  const int HMAT_SPECULAR_FRESNEL_IOR_TEX_ID_OFFSET = &gtm_offsets.specular.fresnelIOR_texId - (const int*)gtm_pStart;

  const int HMAT_REFLECTION_COLOR_TEX_ID_OFFSET       = &gtm_offsets.reflection.color_texId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_POWER_TEX_ID_OFFSET       = &gtm_offsets.reflection.power_texId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_ROUGHNESS_TEX_ID_OFFSET   = &gtm_offsets.reflection.roughness_texId - (const int*)gtm_pStart;
  //const int HMAT_REFLECTION_GLOSSINESS_TEX_ID_OFFSET  = &gtm_offsets.reflection.glossiness_texId - (const int*)gtm_pStart;
  const int HMAT_REFLECTION_FRESNEL_IOR_TEX_ID_OFFSET = &gtm_offsets.reflection.fresnelIOR_texId - (const int*)gtm_pStart;

  const int HMAT_REFRACTION_COLOR_TEX_ID_OFFSET = &gtm_offsets.transparency.color_texId - (const int*)gtm_pStart;
  const int HMAT_REFRACTION_IOR_TEX_ID_OFFSET   = &gtm_offsets.transparency.IOR_texId - (const int*)gtm_pStart;

  const int HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET  = &gtm_offsets.displacement.normals_texId - (const int*)gtm_pStart;
  const int HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET = &gtm_offsets.displacement.height_texId - (const int*)gtm_pStart;

#else

#define HMAT_AMBIENT_COLOR_X_OFFSET 0
#define HMAT_AMBIENT_COLOR_Y_OFFSET 1
#define HMAT_AMBIENT_COLOR_Z_OFFSET 2
#define HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET 4
#define HMAT_AMBIENT_LIGHT_ID_OFFSET 5
#define HMAT_DIFFUSE_COLOR_X_OFFSET 6
#define HMAT_DIFFUSE_COLOR_Y_OFFSET 7
#define HMAT_DIFFUSE_COLOR_Z_OFFSET 8
#define HMAT_DIFFUSE_RADIANCE_OFFSET 10
#define HMAT_SPECULAR_COLOR_X_OFFSET 11
#define HMAT_SPECULAR_COLOR_Y_OFFSET 12
#define HMAT_SPECULAR_COLOR_Z_OFFSET 13
#define HMAT_SPECULAR_POWER_OFFSET 15
#define HMAT_SPECULAR_ROUGHNESS_OFFSET 16
#define HMAT_SPECULAR_FRESNEL_IOR_OFFSET 17
#define HMAT_SPECULAR_BRDF_ID_OFFSET 21
#define HMAT_REFLECTION_COLOR_X_OFFSET 22
#define HMAT_REFLECTION_COLOR_Y_OFFSET 23
#define HMAT_REFLECTION_COLOR_Z_OFFSET 24
#define HMAT_REFLECTION_POWER_OFFSET 26
#define HMAT_REFLECTION_ROUGHNESS_OFFSET 27
#define HMAT_REFLECTION_FRESNEL_IOR_OFFSET 28
#define HMAT_REFLECTION_BRDF_ID_OFFSET 32
#define HMAT_REFRACTION_COLOR_X_OFFSET 33
#define HMAT_REFRACTION_COLOR_Y_OFFSET 34
#define HMAT_REFRACTION_COLOR_Z_OFFSET 35
#define HMAT_REFRACTION_FOG_COLOR_X_OFFSET 37
#define HMAT_REFRACTION_FOG_COLOR_Y_OFFSET 38
#define HMAT_REFRACTION_FOG_COLOR_Z_OFFSET 39
#define HMAT_REFRACTION_FOG_MULT_OFFSET 40
#define HMAT_REFRACTION_EXIT_COLOR_X_OFFSET 41
#define HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET 42
#define HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET 43
#define HMAT_REFRACTION_GLOSSINESS_OFFSET 46
#define HMAT_REFRACTION_IOR_OFFSET 44
#define HMAT_DISPLACEMENT_HEIGHT_OFFSET 47
#define HMAT_FLAGS_OFFSET 50
#define HMAT_AMBIENT_COLOR_TEX_ID_OFFSET 3
#define HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET 9
#define HMAT_SPECULAR_COLOR_TEX_ID_OFFSET 14
#define HMAT_SPECULAR_POWER_TEX_ID_OFFSET 18
#define HMAT_SPECULAR_ROUGHNESS_TEX_ID_OFFSET 19
#define HMAT_REFLECTION_COLOR_TEX_ID_OFFSET 25
#define HMAT_REFLECTION_POWER_TEX_ID_OFFSET 29
#define HMAT_REFLECTION_ROUGHNESS_TEX_ID_OFFSET 30
#define HMAT_REFLECTION_FRESNEL_IOR_TEX_ID_OFFSET 31
#define HMAT_REFRACTION_COLOR_TEX_ID_OFFSET 36
#define HMAT_REFRACTION_IOR_TEX_ID_OFFSET 45
#define HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET 49
#define HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET 48


#endif





const int RAYTR_MAT_MAXTEXTURES = 4;

struct Material
{

  enum BRDFS{ BRDF_PHONG,
              BRDF_COOK_TORRANCE,
              BRDF_BLINN,
              BRDF_LEBEDEV,
              BRDF_THIS_IS_LIGHT};

  enum TEX_STORE_FLAGS{
              TEX_STORE_AMBIENT_COLOR  = 1,
              TEX_COMBINE_MULT_COLOR   = 2,
              TEX_STORE_DIFFUSE_COLOR  = 4,
              TEX_STORE_SPECULAR_COLOR = 8
  };

  enum MAT_FLAGS{ IS_LIGHT = 1,
                  SEPARATED_REFLECTION = 2,
                  FRESNEL_REFLECTIONS = 4
                };

#ifndef __CUDACC__

  Material()
  {
    memset(this,0,sizeof(Material));
    reflectGlossiness = 1.0f;
    refractGlossiness = 1.0f;
    fresnelIOR = 20.0f;
    BRDF_id = BRDF_PHONG;
    power = 60;
    fogMultiplier = 0.5f;
    //isLight = false;
    //separateReflection = false;
  }

  Material(const MGML::Material& in_mat){ *this = in_mat; }

  Material& operator=(const MGML::Material& in_mat)
  {
    memset(this,0,sizeof(Material));
    ka = in_mat.ka;
    kd = in_mat.kd;
    ks = in_mat.ks;
    power = in_mat.power;

    SetSeparatedReflection(in_mat.ks, float3(in_mat.k_reflect, in_mat.k_reflect, in_mat.k_reflect));
    reflectGlossiness = 1.0f;
    refractGlossiness = 1.0f;
    fresnelIOR = 20.0f;
    refraction.set(0,0,0);
    IOR = in_mat.n;
    BRDF_id = BRDF_PHONG;
    fogMultiplier = 0.5f;

    return *this;
  }
#endif

  universal_call float3 GetColor() const { return ka + kd + ks; }
  universal_call float  GetPhongPower() const { return power; }


  __host__ void SetBlinnPhongPower(float a_power)
  {
    #ifndef __CUDACC__
    if(! (BRDF_id == BRDF_PHONG || BRDF_id == BRDF_BLINN))
      throw std::runtime_error("Material::SetBlinnPhongPower: call only if BRDF_id == (Phong or Blinn)");
    #endif

    power = a_power;
  }

  __host__ void SetRoughness(float a_r)
  {
    #ifndef __CUDACC__
    if(BRDF_id != BRDF_COOK_TORRANCE)
      throw std::runtime_error("Material::SetRoughness: call only if COOK TORRANCE BRDF used (set BRDF_id)");
    #endif

    power = a_r;
  }

  inline universal_call float GetRoughness() const
  {
    #ifndef __CUDACC__
    if(BRDF_id != BRDF_COOK_TORRANCE)
      throw std::runtime_error("Material::GetRoughness: call only if COOK TORRANCE BRDF used (set BRDF_id)");
    #endif
    return power;
  }

  inline universal_call bool IsLight() const
  {
    return (flags & IS_LIGHT);
  }

  inline universal_call bool HasSeparatedReflection() const
  {
    return (flags & SEPARATED_REFLECTION);
  }

  inline universal_call int LinkToLight() const
  {
    return (int)extLink_LightId;
  }

  __host__ void SetThisIsLight(bool a_isLight, int a_lightId)
  {
    if (a_isLight)
      flags = flags | IS_LIGHT;
    else
      flags = flags & (~IS_LIGHT); // flags.IS_LIGHT = false;

    if(a_lightId>=65536)
      RUN_TIME_ERROR("Material::SetThisIsLight, max light id is 65535");

    extLink_LightId = (short)a_lightId;
  }


  __host__ void SetReflection(float3 a_ks)
  {
    ks = a_ks;
    reflection = a_ks;
    flags = flags & (~SEPARATED_REFLECTION); // flags.SEPARATED_REFLECTION = false;
  }

  __host__ void SetSeparatedReflection(float3 a_ks, float3 a_refl)
  {
    ks = a_ks;
    reflection = a_refl;
    flags = flags | SEPARATED_REFLECTION;
  }

  __host__ void AddTexture(int texId, int texFlags)
  {
    if (texturesUsed >= RAYTR_MAT_MAXTEXTURES)
      RUN_TIME_ERROR("MAXTEXTURES limit was exceed for one of material");

    textureId[texturesUsed]    = texId;
    textureFlags[texturesUsed] = texFlags;
    texturesUsed++;
  }

  /////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////  data  ////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////

  float3 ka; // ambient
  float3 kd; // diffuse
  float3 ks; // specular for direct lighting

  float3 reflection;
  float  reflectGlossiness;
  float  fresnelIOR;

  float3 refraction; // refractive component
  float  refractGlossiness; // refraction glossiness
  float  IOR;			   // index of refraction
  float  fogMultiplier; // the density of the transparent object

  int textureId[RAYTR_MAT_MAXTEXTURES];
  short textureFlags[RAYTR_MAT_MAXTEXTURES];
  short texturesUsed;

  short BRDF_id; // BRDF index. Different BRDF models can be used.
  short flags; // if outher material used
  short extLink_LightId;

  //bool isLight; // true if the material represent some light
  //bool separateReflection; // ks no equal to reflection. do not evaluate BRDF when it's true.

protected:
  float power; // Phong "power" or Cook-Torrance "roughness"

};






#ifndef __CUDACC__
  #ifndef MGML_GLOBALS
    #include "MGML_GLOBALS.h"
  #endif
#else

#endif

struct LebedevMaterial
{
  int GetSlicesNumber() const {return SLICES_NUM;}

  enum {SLICES_NUM = 7};

  float  boundaries[SLICES_NUM];

  float4 red[SLICES_NUM];
  float4 green[SLICES_NUM];
  float4 blue[SLICES_NUM];
};


struct VRayMaterial
{
  // just diffuse color
  float3 diffuse;

  // reflection color. specular must be the same: specular = reflection.
  float3 reflection;

  // the LESS this parameter, the more glossy reflection is. This parameter lies from 0 to 1. But use usually 0.6-1.0.
  // glossiness means '���������'. if glossiness == 1, material is perfect mirror.
  // Do not tangle this term with glossy - '�����������'. That's not the same.
  float  reflectGlossiness; //

  // this parameter gives blurred blinks from light sources.
  // i think we shall to do thing like that: make some 'stochastic phong specular shading' for every area light.
  // the problem is that if we have area light source, we can not just make phong shading by single point
  // we should take in account at least a set of points with given light distibution.
  float highlightGlossiness; //

  // IOR - Index Of Refraction. BUT! But this is used to compute Frenels reflection effect.
  // this effect means that the light, incoming perpendicular the surface, reflected weaker
  // then the light, incoming with big some between the normal of surface and the light direction.
  // the bigger angle, the stronger reflection
  // ������, ����� � ���, ��� ��� ������ ���� ����� �������� ������������ � ������������� ����,
  // ��� ������� ���� ��� ����������. ��������������� �������� ���� ���������� ����� �����.
  // � pbrt ���� ������ ����� �����-�� ����� ���������.
  float  fresnelIOR;

  float3 refraction; // refraction color
  float  refractGlossiness; // this the same that for reflection
  float  IOR; // index of refraction. - ���������� �����������.

  // the resulting color must be refraction*(fogColor*fogMultiplier*distance_inside_object)
  float3 fogColor; // color inside the object
  float  fogMultiplier; // the density of the transparent object

  bool affectShadow; // makes object to cast color shadows
  bool affectAlpha; // WTF is that?

  // ��� ��������� BSSRDF
  float3 translucency; // the color of Sub Surface Scattering
  float thickness;  // �������, � ������� ����� ������������� BSSRDF
  float lightMultiplier; // ��������� ��� ����� ����������������� ���������
};





}

