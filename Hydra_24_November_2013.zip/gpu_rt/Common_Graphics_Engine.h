// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#pragma warning(disable:4251)

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "IGraphicsEngine.h"

#include "../bvh_builder/IKdTreeBuilder.h"
#include "../bvh_builder/IBVHBuilder.h"

#ifndef KD_TREE_GUARDIAN
  #include "../bvh_builder/kd_tree.h"
#endif

#include "../bvh_builder/BVHTree.h"

#include "Voxelizer.h"

#include <memory>
#include <string>

#ifdef __GNUC__

  #include <unordered_map>
  typedef std::unordered_map<std::string, std::string> RTE_HashMapS;
  typedef std::unordered_map<std::string, int>         RTE_HashMapI;
  typedef std::unordered_map<std::string, float>       RTE_HashMapF;
 
#else

  #include <hash_map>  
  typedef stdext::hash_map<std::string, std::string> RTE_HashMapS;
  typedef stdext::hash_map<std::string, int>         RTE_HashMapI;
  typedef stdext::hash_map<std::string, float>       RTE_HashMapF;

#endif


using namespace MGML;
using namespace RAYTR;

using MGML_MEMORY::DynamicArray;

class DLL_API Common_Graphics_Engine : public IGraphicsEngine
{
public:

	typedef unsigned int uint;

  Common_Graphics_Engine(int w,int h);
	~Common_Graphics_Engine();

  void SetProgressBarCallback(RTE_PROGRESSBAR_CALLBACK a_callback);

  // RTE API v 2.0
  //
  void DeclareVertexInputLayout(int layout, int numUserDefinedAttributes=0) throw (std::runtime_error);

  void ReserveMemoryFor(int primTypes, int a_maxPrims) throw (std::runtime_error); // may be used otr not

  // fixed function pipeline
  //
  void SetVertexPositionPointer(const float* v, int bytePitch) throw (std::runtime_error);
  void SetVertexNormalPointer(const float* v,   int bytePitch) throw (std::runtime_error);
  void SetVertexUVPointer(const float* v,       int bytePitch) throw (std::runtime_error);
  void SetVertexTangentPointer(const float* v,  int bytePitch) throw (std::runtime_error);
  void SetVertexMaterialIdPointer(const int* v, int bytePitch) throw (std::runtime_error);

  // programmable pipeline
  //
  void SetVertexAttributePointer(const char* attrName, const double* v, int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const float* v,  int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const int* v,    int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const short* v,  int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const char* v,   int bytePitch) throw (std::runtime_error);

  int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount, int a_flags = 0); // deprecated

  int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount,
                    const int* a_materialIndices, int a_matIdNum, int a_flags = 0);

  RAYTR::HydraMaterial GetHydraMaterial(int a_id);
  void SetHydraMaterial(const RAYTR::HydraMaterial& rhs, int a_id);

  void UpdateComplete();

  void SetWindowResolution(int a_width, int a_height);

  // RTE v1.0 and general
  //
	void BuildAccelerationStructures(uint in_maxNodes = IGraphicsEngine::MAX_KD_TREE_NODES);

  void Clear(int a_flags = CLEAR_ALL);

	vec2ui        AddTriangles( const Vertex4f* v,int N_vertices, const unsigned int* indices,int N_indices, int a_flags = 0);
	unsigned int  AddSpheres(const Sphere4f* s,int N_spheres);

	uint AddTexture(const void* memory,uint w,uint h,uint format);

  uint AddLight(const RAYTR::Light& light);
  int  GetLightNumber() const;

  const RAYTR::Light& GetLight(int index) const;
  void SetLight(const RAYTR::Light& light, int index);


  void SetWorldViewMatrix(const float mat[16]);
  void SetViewMatrix(const float mat[16]);
  void SetProjectionMatrix(const float mat[16]);

  const float* GetWorldViewMatrix() const;
  const float* GetProjectionMatrix() const;

	unsigned int AddMaterial(const RAYTR::Material& mat);
  unsigned int AddMaterial(const RAYTR::HydraMaterial& mat);

  //void SetMaterial(const RAYTR::Material& mat, unsigned int N);
	//const RAYTR::Material&		GetMaterial(int index) const;

  void DebugCall(const std::string& a_name, const std::string& a_params);
  void DebugDrawAccelStruct();

  void SetVariable(const std::string& a_name, int a_val);
  void SetVariable(const std::string& a_name, float a_val);

  void GetTextureDesc(uint texId, uint* w, uint* h, uint* format = NULL);
  void GetTextureData(uint texId, void* data);

  void GetLDRImage(uint* data) const {};
  void GetHDRImage(float4* data) const {};

  void TransformDeprecatedMaterialsToHydraMarerials() {TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);}

  struct DIP
  {
    int m_vertStart;
    int m_vertEnd;

    int m_normStart;
    int m_normEnd;

    int m_texCoordStart;
    int m_texCoordEnd;

    int m_materialIdStart;
    int materialIdEnd;

    bool dynamic;
  };

  // kd tree input class
  //
  class KdTreeUserInput : public IKdTreeBuilder::InputData
  {
  public:
    KdTreeUserInput(const Common_Graphics_Engine* a_data) {m_data = a_data;}

    int  GetNumTriangles() const throw (std::runtime_error);
    void GetTriangle(int index, float A[3], float B[3], float C[3]) const throw (std::runtime_error);

    int  GetNumSpheres() const throw (std::runtime_error) ;
    void GetSphere(int index, float sph_pos[3], float* sph_r) const throw (std::runtime_error);

    // layout
    //
    int WriteTriangle(int index, void* pAddressToWrite, int sizeInBytes) const throw (std::runtime_error);
    int WriteSphere(int index, void* pAddressToWrite, int sizeInBytes) const throw (std::runtime_error);
    int WritePrimListProlog(void* pAddressToWrite, int maxBytesPermitToRight, int a_numTriangles, int a_numSpheres, int a_numPoints, int a_numCustomPrimitives[32]) const throw (std::runtime_error) ;

  private:
    const Common_Graphics_Engine* m_data;
  };

  friend class KdTreeUserInput;

protected:

  struct MyInputData
  {
    MyInputData() {Clear();}
    void Clear();

    union
    {
      const float4* m_vPosFloat4;
      const float3* m_vPosFloat3;
      const void*   m_vPosCustom;
    };
    int           m_vPosStride;

    union
    {
      const float4* m_vNormFloat4;
      const float3* m_vNormFloat3;
      const void*   m_vNormCustom;
    };
    int           m_vNormStride;

    union
    {
      const float4* m_vTexCoordFloat2;
      const void*   m_vTexCoordCustom;
    };
    int           m_vTexCoordStride;

    union
    {
      const float4* m_vTanFloat4;
      const float3* m_vTanFloat3;
      const void*   m_vTanCustom;
    };
    int           m_vTanStride;

    union
    {
      const int*    m_vMatIdInt32;
      const void*   m_vMatIdCustom;
    };
    int           m_vMatIdStride;

  } m_inputDataSet;

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////

  inline float4 GetVertexPos(int i)          const { return m_vertPos[i]; }
  inline float4 GetVertexNorm(int i)         const { return m_vertNorm[i]; }
  inline float2 GetVertexTexCoord(int i)     const { return m_vertTexCoord[i]; }
  inline int    GetTriangleMaterialId(int i) const { return m_triangleMaterialId[i]; }

  inline float4 GetVertexAttribute4f(int i, int ATTR_CODE) const { RUN_TIME_ERROR("not implemented"); float4* data = (float4*)m_vertAttr[ATTR_CODE]; return data[i]; }

  inline float4 GetSpherePos(int i)        const { return m_spheres[i].pos; }
  inline float  GetSphereRadius(int i)     const { return m_spheres[i].r; }
  inline int    GetSphereMaterialId(int i) const { return m_spheres[i].material_id; }


  class ImageStorage
  {

  public:

    enum FORMAT{RGBA8 = 4,RGBA16F = 8,RGBA32F = 16};

    ImageStorage();
    virtual ~ImageStorage(){}

    virtual void SetData(const unsigned char* data, int w, int h, int byteSize, int a_format = RGBA8);
    virtual void FreeData();

    virtual const void* GetConstData() const
    {
      if(m_data.size() > 0)
        return &m_data[0];
      else
        return NULL;
    }

    virtual void* GetData()
    {
      if(m_data.size() > 0)
        return &m_data[0];
      else
        return NULL;
    }

    int GetFormat() {return m_format;}
    int width() const {return m_width;}
    int height() const {return m_height;}

  protected:

    std::vector<unsigned char> m_data;
    int m_width;
    int m_height;
    int m_elemByteSize;
    int m_format;
  };

  class MegaTexStorageProxy : public ImageStorage
  {
    typedef ImageStorage Base;
  public:

    MegaTexStorageProxy(const char* usage, const unsigned char* data, int w, int h, int byteSize, int a_format, const std::vector<float>& a_lut);
    ~MegaTexStorageProxy(){}

    const void* GetConstData() const;
    void* GetData();
    void SetData(const unsigned char* data, int w, int h, int byteSize, int a_format = RGBA8);
    void FreeData();

    const std::vector<float>& GetLut() const {return m_lut;}

  protected:

    std::vector<float> m_lut;
    std::string m_filename;
    mutable bool savedToFile;
    int m_byteSize;

  };

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////

  void AddVertexPositionsFromInputDataSet(int a_maxVertices);
  void AddVertexNormalsFromInputDataSet(int a_maxVertices);
  void AddVertexTexCoordsFromInputDataSet(int a_maxVertices);

  void ExtractVertexMatIndicesFromInputDataSet(int a_maxVertices, std::vector<int>& vertMaterialIds);
  void TransformDeprecatedMaterialsToHydraMarerials(std::vector<RAYTR::Material>& old, std::vector<RAYTR::HydraMaterial>* newMats);

  void CalcTangentSpace();

  virtual void DrawLights();
  virtual void VerifyData();
  virtual void VerifyAllData();

  static void PlaneHammersley(float *result, int n);
  static float3 MapToHemiSphere(float r1, float r2);
  void CreateSphericalDistribution(std::vector<float4>& a_sphereUniform, int N, bool cosine = true);

  void PrecomputeSHCoeffs(std::vector<float>& out_coeffs);

  VoxelStorage<float4> m_voxelData; //x,y,z - color, w - opacity
  VoxelStorage<float4> m_radiancePos; //x,y,z - radiance along {x,y,z} axis in positive direction
  VoxelStorage<float4> m_radianceNeg; //x,y,z - radiance along {x,y,z} axis in negative direction

  VoxelStorage<float4>& VoxelizeAllGeometry();
  void VoxelizeAllSpheres();
  void VoxelizeAllTriangles();

  float m_worldViewMatrixData[16];
  float m_projectionMatrixData[16];

  float m_worldViewInvMatrixData[16];
  float m_projectInvMatrixData[16];

	int			 width;
	int			 height;

	std::vector<RAYTR::Material>      m_materials;
  std::vector<RAYTR::HydraMaterial> m_hydraMaterials;
  std::vector<RAYTR::Light>         m_lights;
  std::vector<ImageStorage>         m_images;

  std::vector<Sphere4f>            m_spheres;
  std::vector<float4>              m_vertPos;
  std::vector<float4>              m_vertNorm;
  std::vector<float4>              m_vertTangent;

  std::vector<float2>               m_vertTexCoord;
  std::vector<uint>                 m_index;
  std::vector<uint>                 m_triangleMaterialId;

  mutable std::vector<int>         m_tempPrimIndex;

  IKdTreeBuilder* m_pKdTreeBuilder;
  IBVHBuilder*    m_pBVHBuilder;

  void* m_vertAttr[MAX_VERTEX_ATTRIBUTES];
  RTE_PROGRESSBAR_CALLBACK m_displayProgress;

  int m_currInputLayout;
  float m_gatherRadius;

  bool m_lightsWasAddedAsGeometry;

  std::vector<float4> m_sphereUniformArray[HEMISPHERE_SEQUENCE_NUM];
  std::vector<float4> m_sphereUniformArray2[HEMISPHERE_SEQUENCE_NUM];
  //std::vector<float4> m_cubeUniformArray[HEMISPHERE_SEQUENCE_NUM];

  std::vector<float>   m_shCoeffsArray;
  int m_shResPhi;
  int m_shResTheta;
  int m_sphLayersNum;

  Matrix4x4f m_addTrianglesLastMat;

  AABB3f m_bBox;
  AABB3f m_regularBBox;

  bool  m_dirtyHydraMaterials;
  bool  m_dirtyLights;
  bool  m_dataVerifyed;
  bool  m_accelStructuresDirty;
  bool  m_materialsWasTransformed;
  bool  m_debugOutput;
  bool  m_voxelizeOnLoad;

  RenderSettings m_lastRenderState;

  RTE_HashMapI m_ivars;
  RTE_HashMapF m_fvars;
  RTE_HashMapS m_svars;

  float gl_ver;
};


