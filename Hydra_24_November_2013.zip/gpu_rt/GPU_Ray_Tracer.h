// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once

#include "../vsgl3/glHelper.h"
#include "IGraphicsEngine.h"

#include "Ray_Tracer.h"
#include "CUDAPipeline.h"

#include <map>

using namespace MGML_ERROR;

class DLL_API GPU_Ray_Tracer: public Ray_Tracer // ,public Singleton
{
	typedef Ray_Tracer Base;

public:

  GPU_Ray_Tracer(int w, int h, int flags = 0);
	~GPU_Ray_Tracer();

	void BeginDrawScene(RenderSettings a_renderState);			// account multithreading
	void EndDrawScene();			// account multithreading

	void BuildAccelerationStructures(uint in_maxNodes = MAX_KD_TREE_NODES);

  void PrintStatInfo(std::ostream& out);

	Ray_Tracer::RT_Core* GetRTCore();

	class DLL_API RT_Core : public Base::RT_Core
	{
	public:

		//void TraverseRays(Ray* in_out_rays, RAYTR::Hit* out_hits, size_t in_N);
		//void TraverseRays(Ray* in_out_rays, RAYTR::Hit* out_hits, size_t in_width, size_t in_height);
	};

  void GetLDRImage(uint* data) const;
  void GetHDRImage(float4* data) const;

  void SetVariable(const std::string& a_name, int a_val);
  void SetVariable(const std::string& a_name, float a_val);

  void SetWindowResolution(int a_width, int a_height);

  uint AddLight(const RAYTR::Light& a_light);

protected:

  GPU_Ray_Tracer(const GPU_Ray_Tracer&);
  GPU_Ray_Tracer& operator=(const GPU_Ray_Tracer&);

	virtual void UpdateComplete();
  virtual void CopyResultToGLBuffer();

  void InitPBO(GLuint* a_pBuffer);
  void LoadStaticDataToGPU();

  void PrintMaterialParametersOffsets(const string& a_fileName);
  std::vector<ImageStorage*> m_texArrays[TEX_ARRAYS_NUMBER];

  virtual void DrawICRecords();
  virtual void FreeICRecordsBuffer();
  virtual void DrawPhotons(const char* a_phMapName);
  virtual void FreeGLPhotonsData(const char* a_phMapName);


  void CreateEnvMapTextures();
  void CreateMegaTextures();
  void LoadDefferedMegaTexturesToGPU();
  void Pack1ChannelTexTo4ThChannel(int bytesOffsetInMaterial, int bytesOffset2InMaterial);
  
  std::map<std::string, MegaTexStorageProxy*> m_defferedMegaTexHash;

  RT_Core m_core;

  float m_avgRaysPerPixel;
  int m_startScreenBlockListSize;

  GLuint m_screenTexture;

  struct GLRes
  {
    enum {NUM_VBOS = 8, NUM_VAOS = 4};

    GLRes()
    {
      glGenBuffers(NUM_VBOS, m_vbos);      CHECK_GL_ERRORS;
      glGenVertexArrays(NUM_VAOS, m_vaos); CHECK_GL_ERRORS;

      m_vertPosBuffSize = 0;
      m_photonsBuffSize = 0;
      m_photonsCausticBuffSize = 0;
    }

    ~GLRes()
    {
      glDeleteVertexArrays(NUM_VAOS, m_vaos);  CHECK_GL_ERRORS;
      glDeleteBuffers(NUM_VBOS, m_vbos);       CHECK_GL_ERRORS;
    }

    union
    {
      struct
      {
        GLuint m_pointsPos;
        GLuint m_blocksPos;

        GLuint m_photonsPos;
        GLuint m_photonsCol;

        GLuint m_photonsCausticPos;
        GLuint m_photonsCausticCol;

        GLuint m_screenBuffer;
        GLuint m_dummy;
      };

      GLuint m_vbos[NUM_VBOS];
    };

    union
    {
      struct
      {
        GLuint m_vaoPoints;
        GLuint m_vaoBlocks;
        GLuint m_vaoPhotons;
        GLuint m_vaoPhotonsCaustic;
      };

      GLuint m_vaos[NUM_VAOS];
    };

    int m_vertPosBuffSize;
    int m_photonsBuffSize;
    int m_photonsCausticBuffSize;

  }m_glRes;

  bool  m_rtOnlyVarDrawRaysStatInfo;
  bool  m_drawLights;
  bool  m_windowWasResized;

  SGA::IPipeline* m_pipeline;
  FullScreenQuad* m_pFullScreenQuad;
  ShaderProgram   m_displayRTProg;
  ShaderProgram   m_displayPointsProg;
  ShaderProgram   m_displayPhotonsProg;
};


const std::string& RTE_GetShaderSource(const std::string& a_shaderName);
void RTE_CreateScreenTBO(GLuint* tbo, GLuint* tex, unsigned int a_size, void* a_data);
void RTE_DeleteScreenTBO(GLuint* tbo);

