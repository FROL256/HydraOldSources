#pragma once
#include <gl/glew.h>

#include "IGraphicsEngine.h"
#include "Ray_Tracer.h"
#include "GPU_Ray_Tracer.h"
#include "IrradianceCache.h"
#include "RadianceCache.h"
#include "PhotonMap.h"

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
  #include "path_tracing.h"
#endif

class DLL_API GPU_Path_Tracer: public GPU_Ray_Tracer // ,public Singleton
{
  typedef GPU_Ray_Tracer Base;

public:
  
  GPU_Path_Tracer(int w, int h, int flags = 0);
  ~GPU_Path_Tracer();

  struct DLL_API RenderingParams
  { 
    enum FILERS{PT_FILTER_TYPE_NONE = 0, PT_FILTER_TYPE_BILINEAR = 1 };

    RenderingParams()
    {
      qualityTreshold  = 1.0f; // control path tracing error
      //icErrorThreshold = 0.1f; // control ic error

      minRaysPerPixel = 8;
      maxRaysPerPixel = 1000;
      initialSPP = 1;
      useHDRQualityEstimation = true;
      drawBlocks = false;
      qmcOneSeed = false;

      enableDOF = false;
      dofLensRadius = 1.0f;
      dofFocalPlaneDist = 10.0f;

      coherent = false;
      enableRR = true;
      loaylEstimateFunctionTresholdInRays = 200;
    }

    float qualityTreshold;
    //float icErrorThreshold;
    short minRaysPerPixel;
    short maxRaysPerPixel;
    short initialSPP;
    bool  useHDRQualityEstimation;
    bool  drawBlocks;
    bool  drawRaysStatInfo;
    bool  enableDOF;
    bool  qmcOneSeed;
    bool  coherent;
    bool  enableRR;
    float dofLensRadius;
    float dofFocalPlaneDist;

    int   filterType;
    float loaylEstimateFunctionTresholdInRays;
  };

  struct DLL_API PhotonMapPresets
  {
    PhotonMapPresets(): progressivePhotonMap(true), maxDiffusePhotons(1000000), maxCausticPhotons(1000000), disableVisibilityTracing(false) {}
    
    int  maxDiffusePhotons;
    int  maxCausticPhotons;
    
    bool progressivePhotonMap;
    bool progressiveCausticMap;
    bool disableVisibilityTracing;

    int  diffuseRetracePass;
    int  causticRetracePass;
  };

  void SetPhotonMapPresets(const PhotonMapPresets& a_presets);

  void SetRenderingParams(const RenderingParams& a_params);
  void SetICPresets(const RAYTR::ICPresets& a_presets);

  void BeginPathTracingPass(RenderSettings a_renderState);			
  bool EndPathTracingPass();        // sync path tracing. return true if path tracing has finished	

  bool PathTracingFinished() const; // return true if path tracing has finished
  void ResetPathTracing();
  
  void DumpBufferToFile(const char* a_buffName, const char* a_fileName);

  void SetRaysPerPixel(int a_num) 
    {m_currRaysPerPixel = a_num;  hmctSetRaysPerPixel(m_currRaysPerPixel);}

  void ComputeIrradianceCache();
  void FreeIrradianceCache();

  void ComputeRadianceCache(int a_type);
  void FreeRadianceCache();

  void PreparePhotonMaps(RenderSettings a_renderState);

  void DebugCall(const std::string& a_name, const std::string& a_params);

  enum PATH_TRACING_STATES {STATE_BEGIN, STATE_TRACING, STATE_FINISHED};
  int GetPathTracingState() const {return m_pathTracingState;}

  void SetWindowResolution(int a_width, int a_height);

protected:

  GPU_Path_Tracer(const GPU_Path_Tracer& rhs);
  GPU_Path_Tracer& operator=(const GPU_Path_Tracer& rhs);

  typedef MGML_MEMORY::FastList<ZBlock> BlockList; 
  //typedef std::list<ZBlock> BlockList; 
  
  void MakeScreenBlockList(BlockList*);
  void DoMegaBlock(BlockList&, RenderSettings);
  bool BlockFinished(const ZBlock& block, float* a_blockDiff);
  void CheckBlockListF(GPU_Path_Tracer::BlockList* pList, const char* file, int line);
  
  void InsertPointsInOctree(const RAYTR::IrradianceCacheDataSet& a_dataSet, IrradCacheOctreeAPI* pOctree);

  void CopyResultToGLBuffer();

  void DegudDrawActiveBlocksAndStatisticsData();
  void DrawICRecords();
  void FreeICRecordsGLBuffer();

  // photon mapping
  //
  void DrawPhotons(const char* a_phMapName);
  void FreeGLPhotonsData(const char* a_phMapName);

  void MarkVisibleSurfaces(IPhotonMap* a_photonMap);
  void PhotonTracing(IPhotonMap* a_photonMap, float a_gartherRadius);

  void DiffusePhotonTracing();
  void CausticPhotonTracing();
  void TestICToPhotonmap();
  
  void CausticPhotonPass();
  void DiffusePhotonPass();

  // data
  //
  enum {START_LAST_PASS=32};
  int m_pathTracingState;
  int m_pathTracingPassNumber;

  BlockList m_screenBlockList;
  std::vector<ZBlock> m_blocksArray;

  //int m_blocksArraySize;
  int m_lastPass;
  bool m_megaBlockPathTraceInProcess;
  bool forceEnd;
  std::vector<float2> m_zBlocksCoordByIndex;
  std::vector<float3> m_zblocksPosTmp;
  float m_blockErrorMaxRed;   // for blocks color encoding
  float m_blockErrorMinGreen;  // for blocks color encoding
  int   m_maxSPP;

  RenderingParams m_params;
  ICPresets       m_icPresets;
  int m_currRaysPerPixel;

  bool m_debugICacheFileOutput;
  bool m_voxelRadianceCacheEnabled;

  AABB3f m_octreeAABB;
  float m_icAverageValidityRadius;
  RadianceCache* m_pRC;
  IPhotonMap* m_pPhotonMap;
  IPhotonMap* m_pCausticPhotonMap;
  PhotonMapPresets m_phMapPresets;

  float m_currCausticGartherRadius;
  float m_currGartherRadius;
  int   m_photonCausticPassNumber;
  int   m_photonCausticNextPassNumber;
  int   m_photonCausticPassNumber2;
  int   m_photonDiffuseNextPassNumber;
  int   m_photonDiffusePassNumber2;
  int   m_photonPassNumber;
  int   m_currPTPassNumber; 
  bool  m_photonMapsPrepared;
 
  ShaderProgram   m_display2DLines;
  Matrix4x4f      m_ortoMat;

  std::vector<ZBlock> blockesInQueue;
};

