// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include <GL/glew.h>

#include "../MegaTexture/MegaTexture/MegaTextureManager.h"

#include "GPU_Ray_Tracer.h"
#include "Fonts.h"

#include <map>
#include <string>

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

using std::map;
using std::string;

#include <sstream>

bool USE_PBO = true; 
bool USE_TBO = false;

///////////////////////////////////////////////////////////////////////////////////
////
GPU_Ray_Tracer::GPU_Ray_Tracer(int w, int h, int flags): Ray_Tracer(w,h) 
{
  CHECK_GL_ERRORS;
  m_pipeline = new SGA::CUDAPipeline();

  hrtInit(width, height, flags);

  m_rtOnlyVarDrawRaysStatInfo = false;

#ifdef PRINT_SHMAT_OFFSETS
    PrintMaterialParametersOffsets("hmat_offsets.h");
#endif

  m_drawLights = false;
  m_pFullScreenQuad = new FullScreenQuad();

  // init OpenGL3/4 resources
  //
  if(USE_PBO)
    m_displayRTProg.InitFromString(RTE_GetShaderSource("quad_vs"), RTE_GetShaderSource("quad_ps"));
  else if(USE_TBO)
    m_displayRTProg.InitFromString(RTE_GetShaderSource("quad_vs"), RTE_GetShaderSource("quad_ps_tbo"));
  
  m_displayPointsProg.InitFromString(RTE_GetShaderSource("simple_vs"), RTE_GetShaderSource("color_ps"));
  m_displayPhotonsProg.InitFromString(RTE_GetShaderSource("photons_vs"), RTE_GetShaderSource("color_ps"));

  GLuint location = glGetAttribLocation(m_displayPointsProg.program, "vertex");

  glBindVertexArray(m_glRes.m_vaoPoints);                         CHECK_GL_ERRORS;

  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_pointsPos);             CHECK_GL_ERRORS;     
  glEnableVertexAttribArray(location);                            CHECK_GL_ERRORS;
  glVertexAttribPointer(location, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;


  GLuint loc1 = glGetAttribLocation(m_displayPhotonsProg.program, "vertex");
  GLuint loc2 = glGetAttribLocation(m_displayPhotonsProg.program, "vcolor");

  // diffuse photons
  //
  glBindVertexArray(m_glRes.m_vaoPhotons);                    CHECK_GL_ERRORS;

  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsPos);        CHECK_GL_ERRORS;     
  glEnableVertexAttribArray(loc1);                            CHECK_GL_ERRORS;
  glVertexAttribPointer(loc1, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsCol);        CHECK_GL_ERRORS;     
  glEnableVertexAttribArray(loc2);                            CHECK_GL_ERRORS;
  glVertexAttribPointer(loc2, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

  // caustic photons
  //
  glBindVertexArray(m_glRes.m_vaoPhotonsCaustic);             CHECK_GL_ERRORS;

  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsCausticPos); CHECK_GL_ERRORS;     
  glEnableVertexAttribArray(loc1);                            CHECK_GL_ERRORS;
  glVertexAttribPointer(loc1, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;

  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_photonsCausticCol); CHECK_GL_ERRORS;     
  glEnableVertexAttribArray(loc2);                            CHECK_GL_ERRORS;
  glVertexAttribPointer(loc2, 4, GL_FLOAT, GL_FALSE, 0, 0);   CHECK_GL_ERRORS;


  glBindBuffer(GL_ARRAY_BUFFER, 0);  
  glBindVertexArray(0);

  InitPBO(&m_glRes.m_screenBuffer);

  hrtSetVariableI(HRT_MEASURE_RAYS_TYPE, 0);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::SetWindowResolution(int a_width, int a_height)
{
  m_windowWasResized = false;

  if(width == a_width && height == a_height)
    return;

  int widthClamped  = a_width;
  int heightClamped = a_height;

  if(widthClamped % 16 != 0 || heightClamped%16 != 0)
  {
    widthClamped  = 16*(a_width/16);  // + (16 - a_width%16);
    heightClamped = 16*(a_height/16); // + (16 - a_height%16);
  }

  if(width == widthClamped && height == heightClamped)
    return;

  width  = widthClamped;
  height = heightClamped;

  hrtPTFreePerRayData();
  hrtFreeScreenBuffersData();
  hrtFreePerRayData();

  int MEGA_BLOCK_SIZE = width*height/2;
  if(MEGA_BLOCK_SIZE > 1280*1024)
    MEGA_BLOCK_SIZE = width*height/4;

  hrtAllocScreenBuffersData(width, height);
  hrtAllocPerRayData(MEGA_BLOCK_SIZE);     
  hrtPTAllocPerRayData(MEGA_BLOCK_SIZE);

  hrtUnregisterPBO();

  if(USE_PBO)
  {
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);                                              CHECK_GL_ERRORS;
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);  CHECK_GL_ERRORS;

    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_glRes.m_screenBuffer);                              CHECK_GL_ERRORS;
    glBufferData(GL_PIXEL_UNPACK_BUFFER, width*height*sizeof(int), NULL, GL_DYNAMIC_COPY);     CHECK_GL_ERRORS;
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
  }
  else if(USE_TBO)
  {
    glBindBuffer(GL_TEXTURE_BUFFER, m_glRes.m_screenBuffer);                          CHECK_GL_ERRORS;
    glBufferData(GL_TEXTURE_BUFFER, width*height*sizeof(int), NULL, GL_STATIC_DRAW);  CHECK_GL_ERRORS;

    glBindTexture(GL_TEXTURE_BUFFER, m_screenTexture);                                CHECK_GL_ERRORS;
    glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA8, m_glRes.m_screenBuffer);                 CHECK_GL_ERRORS;

    glBindTexture(GL_TEXTURE_BUFFER, 0);
    glBindBuffer(GL_TEXTURE_BUFFER, 0);
  }

  hrtRegisterPBO(m_glRes.m_screenBuffer);

  m_windowWasResized = true;

}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::InitPBO(GLuint* a_pBuffer)
{
  GLuint& pixelBuffer = *a_pBuffer;

  if(glBindBuffer == NULL)
  {
    GLenum err=glewInit();
    if(err!=GLEW_OK)
    {
      fprintf(stderr, "glewInitError: %s\n", glewGetErrorString(err));
      RUN_TIME_ERROR("glewInit() failed");
    }
  }

  if(USE_PBO)
  {
    glGenTextures(1,&m_screenTexture);  CHECK_GL_ERRORS;
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);  CHECK_GL_ERRORS;
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);  CHECK_GL_ERRORS;

    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);        CHECK_GL_ERRORS;
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);        CHECK_GL_ERRORS;
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);  CHECK_GL_ERRORS;
    glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);  CHECK_GL_ERRORS;
    // \\ end init texture

    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, pixelBuffer);                                       CHECK_GL_ERRORS;
    glBufferData(GL_PIXEL_UNPACK_BUFFER, width * height*sizeof(int), NULL, GL_DYNAMIC_COPY); CHECK_GL_ERRORS;
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
  }
  else if(USE_TBO)
  {
    std::vector<uint> testData(width*height);
    for(int i=0;i<width*height;i++)
      testData[i] = 0xFFFFFFFF;

    // tbo
    //
    glBindBuffer(GL_TEXTURE_BUFFER, pixelBuffer);                                             CHECK_GL_ERRORS;
    glBufferData(GL_TEXTURE_BUFFER, width*height*sizeof(int), &testData[0], GL_STATIC_DRAW);  CHECK_GL_ERRORS;
    glBindBuffer(GL_TEXTURE_BUFFER, 0);

    glGenTextures(1, &m_screenTexture);                                               CHECK_GL_ERRORS;
    glBindTexture(GL_TEXTURE_BUFFER, m_screenTexture);                                CHECK_GL_ERRORS;
    glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA8, pixelBuffer);                            CHECK_GL_ERRORS;
    glBindTexture(GL_TEXTURE_BUFFER, 0);	                                            CHECK_GL_ERRORS;

  }

  hrtRegisterPBO(pixelBuffer);
}

///////////////////////////////////////////////////////////////////////////////////
////
GPU_Ray_Tracer::~GPU_Ray_Tracer()
{
  delete m_pFullScreenQuad; m_pFullScreenQuad = NULL;

  if(USE_PBO || USE_TBO)
    glDeleteTextures(1, &m_screenTexture);

  hrtDelete();
  delete m_pipeline; m_pipeline = NULL;
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::BeginDrawScene(RenderSettings a_renderState)
{
  hrtResetCounters();

  m_rtOnlyVarDrawRaysStatInfo = a_renderState.GetEnableRaysCounter();
  m_lastRenderState = a_renderState;

	UpdateComplete();

  hrtSetFlags(HRT_USE_RANDOM_RAYS, 0);
  hrtSetFlags(HRT_COMPUTE_SHADOWS, a_renderState.GetShadow());
  hrtSetFlags(HRT_DIFFUSE_REFLECTION, a_renderState.GetIndirrectIllumination());
  hrtSetFlags(HRT_COMPUTE_IRRADIANCE_CACHE | HRT_IRRDAIANCE_CACHE_FIND_SECONDARY,0);
  hrtSetFlags(HRT_FINAL_GARTHER, a_renderState.GetEnableFG());
  hrtSetFlags(HRT_GARTHER_CAUSTICS, a_renderState.GetEnableCG());
  hrtSetFlags(HRT_TRACE_GLASS_RECURSIVE, a_renderState.enableRecursiveTracing);
  hrtSetFlags(HRT_ENABLE_PT_CAUSTICS, a_renderState.ptCaustics);

  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, a_renderState.GetDiffuseTraceDepth());
  //m_pipeline->SetShaderVariable("g_diffuseMaxBounce", a_renderState.GetDiffuseTraceDepth());
  m_pipeline->SetShaderVariable("g_gamma", a_renderState.GetGamma());

  hrtSetVariableF(HRT_TRACE_PROCEEDINGS_TRESHOLD, a_renderState.GetTraceProceedingsTreshold());
  hrtSetVariableF(HRT_CAUSTIC_POWER_MULT, a_renderState.causticPower);
  hrtSetVariableI(HRT_DEBUG_DRAW_LAYER, m_ivars["g_debugLayerDraw"]);
  hrtSetVariableI(HRT_DISABLE_MRAYS_COUNTERS, int(!a_renderState.GetEnableRaysCounter()));
  hrtSetVariableI(HRT_TRACE_DEPTH, a_renderState.GetTraceDepth());
  hrtSetVariableI(HRT_PHOTONS_GARTHER_BOUNCE, a_renderState.GetGartherBounce());
  hrtSetVariableI(HRT_PHOTONS_STORE_BOUNCE, a_renderState.GetStoreBounce());
  hrtSetVariableI(HRT_DEBUG_OUTPUT, m_debugOutput);


  if(m_lights.size() == 0)
    RUN_TIME_ERROR("BeginDrawScene(): No lights were addeed to the scene!");

	hrtBeginTrace(a_renderState.GetAA());
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::CopyResultToGLBuffer()
{
  hrtEndTrace(m_glRes.m_screenBuffer, NULL);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::EndDrawScene()
{
  glViewport(0,0,width,height);

  glDisable(GL_DEPTH_TEST);  CHECK_GL_ERRORS;  
  glDisable(GL_CULL_FACE);   CHECK_GL_ERRORS;  

  this->CopyResultToGLBuffer();

  if(USE_PBO)
  {
    glBindTexture (GL_TEXTURE_2D, m_screenTexture);               CHECK_GL_ERRORS;  
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, m_glRes.m_screenBuffer); CHECK_GL_ERRORS;  
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, (GLvoid*)0); CHECK_GL_ERRORS;    // copy color from PBO to texture
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);                      CHECK_GL_ERRORS;  
  }

  glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

  int2 im_size(width, height);

  glUseProgram(m_displayRTProg.program);  CHECK_GL_ERRORS; 
  setUniform(m_displayRTProg.program, "im_size", im_size); // glProgramUniformEXT (?)
  
  if(USE_PBO)
    bindTexture(m_displayRTProg.program, 0, "screenBufferTex", m_screenTexture);
  else if(USE_TBO)
    bindTextureBuffer(m_displayRTProg.program, 0, "tboSampler", m_screenTexture);

  m_pFullScreenQuad->Draw();

  glUseProgram(0);
  glBindTexture(GL_TEXTURE_BUFFER, 0);

  glClear(GL_DEPTH_BUFFER_BIT);  

  if(m_ivars["drawIrradianceCachePixelPoints"] == 1)
    DrawICRecords();
  else
    FreeICRecordsBuffer();

  if(m_ivars["drawPhotons"] == 1)
    DrawPhotons("diffuse");
  else
    FreeGLPhotonsData("diffuse");

  if(m_ivars["drawPhotonsCaustic"] == 1)
    DrawPhotons("caustic");
  else
    FreeGLPhotonsData("caustic");

  // draw text
  //
  if(m_rtOnlyVarDrawRaysStatInfo && gl_ver <= 3.1)
  {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,width,0,height, -1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glClear(GL_DEPTH_BUFFER_BIT);

    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glColor3f(1,1,0);
    glPushAttrib(GL_CURRENT_RASTER_POSITION);
    int traceTimePerCent = (int)(hrtGetTraceTimePerCent()+0.5f);
    float raysPerSec = hrtGetRaysPerSec();
    float samplesPerSec = hrtGetSamplesPerSec();
    float reorderTimeMs = hrtGetReorderTimeInSec()*1000.0f;
    float traversalTimeMs = hrtGetOneTraversalTime()*1000.0f;
    float totalTraversalTimeMs = hrtGetTotalTraceTime()*1000.0f;
    float sampleTimeMS = hrtGetSampleTime()*1000.0f;
    int mrays = (int)(raysPerSec*1e-6f + 0.5f);

    float startY = height - 20;

    glRasterPos2f(10, startY-0);
    glPrint("M(Rays)/sec   : %d", mrays);
    
    glRasterPos2f(10, startY-20);
    glPrint("M(Samples)/sec: %f", samplesPerSec*1e-6f);

    glRasterPos2f(10, startY-40);
    glPrint("trace per cent: %d", traceTimePerCent);

    glRasterPos2f(10, startY-60);
    glPrint("Reorder   (ms): %2.2f", reorderTimeMs);
    
    glRasterPos2f(10, startY-80);
    glPrint("TraversalB(ms): %2.2f", traversalTimeMs);

    glRasterPos2f(10, startY-100);
    glPrint("TraversalT(ms): %2.2f", totalTraversalTimeMs);

    glRasterPos2f(10, startY-120);
    glPrint("SampleTime(ms): %2.2f", sampleTimeMS);

    glPopAttrib();
    glEnable(GL_TEXTURE_2D);
  }

  // just draw lights with OpenGL 
  //
  if(m_drawLights && gl_ver <= 3.1) // TODO: if nothing to do, port drawing point and directional lights to GL ? for what reason ??
  {
    glClearDepth(1.0f);									
    glDepthFunc(GL_LEQUAL);
    glClear(GL_DEPTH_BUFFER_BIT);

    Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
    Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);
    float z_near  = 0.1f;
    float z_far   = 1e5f;

    glMatrixMode(GL_PROJECTION);
    glLoadMatrixf(m_projectionMatrixData);

    glMatrixMode(GL_MODELVIEW);
    glLoadMatrixf(m_worldViewMatrixData);

    Base::DrawLights();
  }

}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::GetLDRImage(uint* data) const
{
  hrtGetBuffer("LDRColorBuffer", data, width*height*sizeof(uint), m_glRes.m_screenBuffer);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::GetHDRImage(float4* data) const
{
  hrtGetBuffer("HDRColorBuffer", data, width*height*sizeof(float4), 0);
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::UpdateComplete()
{  
  if(m_dirtyLights && m_lights.size() > 0)
  {
    hrtSetLights(&m_lights[0], int(m_lights.size()));
    m_dirtyLights = false;
  }
	
  if(m_dirtyHydraMaterials && m_hydraMaterials.size() > 0)
  {
    hrtSetHydraMaterials(&m_hydraMaterials[0], int(m_hydraMaterials.size()));
    m_dirtyHydraMaterials = false;
  }

  Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
  Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);

  Matrix4x4f mProjInverse      = SafeInverse(mProj).GetTranspose();
  Matrix4x4f mWorldViewInverse = SafeInverse(mWorldView).GetTranspose();

  m_pipeline->SetShaderVariable("g_mViewProjInv",  mProjInverse);
  m_pipeline->SetShaderVariable("g_mWorldViewInv", mWorldViewInverse);
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::LoadStaticDataToGPU()
{
  if(!m_dataVerifyed)
    VerifyAllData();

  if(m_index.size() > 0)
  {
    hrtSetCommonVertexAttributes(&m_vertPos[0], &m_vertNorm[0], &m_vertTexCoord[0], NULL, m_vertPos.size());
    //hrtSetTangentAtrributes(&m_vertTangent[0], m_vertTangent.size());
    hrtSetIndices32(&m_index[0], int(m_index.size()));
    hrtSetMaterialIndices32(&m_triangleMaterialId[0], int(m_triangleMaterialId.size()));
  }

  if(m_spheres.size() > 0)
    hrtSetSpheres(&m_spheres[0], int(m_spheres.size()));

  CreateMegaTextures();

  if(m_lights.size() > 0)
  {
    printf("sizeof(RAYTR::Light) = %d \n", sizeof(RAYTR::Light));
    hrtSetLights(&m_lights[0], int(m_lights.size()));
  }
  else
    std::cerr << "hrt warning: lights were not set" <<std::endl;

  // free memory
  //
  //m_textures       = std::vector<Image>();
  m_images         = std::vector<ImageStorage>();
  //m_vertMaterialId = std::vector<int>();

  m_vertNorm     = std::vector<float4>();
  m_vertTangent  = std::vector<float4>();
  m_vertTexCoord = std::vector<float2>();

  //m_index  = std::vector<uint>();
  //m_vertPos = std::vector<float4>();
  //m_spheres = std::vector<Sphere4f>();
  //m_triangleMaterialId = std::vector<int>();
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::BuildAccelerationStructures(uint in_constructionMode)
{
  LoadStaticDataToGPU();

  Base::BuildAccelerationStructures(in_constructionMode);

  // free unnecesary data
  m_triangleMaterialId = std::vector<uint>();

  if(in_constructionMode <= KD_TREE_CONSTRUCT_VERY_FAST)
  {
    m_pKdTreeBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);

    hrtSetWorldKdTree(m_bBox, m_pKdTreeBuilder->GetKdTree(), m_pKdTreeBuilder->GetKdTreeArraySize());
    hrtSetWorldObjectListData(m_pKdTreeBuilder->GetPrimitiveListsArray(), m_pKdTreeBuilder->GetPrimitiveListsArraySize());
    hrtSetPrmitiveListIndexData(&m_tempPrimIndex[0], m_tempPrimIndex.size());
    hrtSetCurrAccelStructType(ACCEL_STRUCT_KD_TREE);

    // �������� ������
    //
    delete m_pKdTreeBuilder;
    m_pKdTreeBuilder = NULL;
  }
  else if(in_constructionMode <= BVH_CONSTRUCT_VERY_FAST)
  {
    hrtSetWorldBVH(m_pBVHBuilder->GetBVH(), m_pBVHBuilder->GetBVHArraySize());
    hrtSetWorldObjectListData(m_pBVHBuilder->GetPrimitiveListsArray(), m_pBVHBuilder->GetPrimitiveListsArraySize()); 
    hrtSetPrmitiveListIndexData(&m_tempPrimIndex[0], m_tempPrimIndex.size());
    hrtSetCurrAccelStructType(ACCEL_STRUCT_BVH);

    m_pBVHBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);

    // �������� ������
    //
    delete m_pBVHBuilder;
    m_pBVHBuilder = NULL;
  }
  
  // calc regular AABB
  //
  float3 boxSize   = m_bBox.vmax - m_bBox.vmin;
  float maxBoxSize = fmaxf(boxSize.x, fmaxf(boxSize.y, boxSize.z));
  m_pipeline->SetShaderVariable("g_sceneBoundingSphereDiameter", maxBoxSize);

  m_regularBBox.vmin = m_bBox.center() - float3(maxBoxSize,maxBoxSize,maxBoxSize);
  m_regularBBox.vmax = m_bBox.center() + float3(maxBoxSize,maxBoxSize,maxBoxSize);
  
  hrtSetRegularBBox(m_regularBBox.vmin, m_regularBBox.vmax);
  
  // free geometry and other data
  //
  m_index    = std::vector<uint>();
  m_vertPos  = std::vector<float4>();
  m_spheres  = std::vector<Sphere4f>();
  m_tempPrimIndex = std::vector<int>();

  std::cerr << "loading megatextures to GPU..." << std::endl;
  LoadDefferedMegaTexturesToGPU();

  if(m_debugOutput)
  {
    std::cerr << std::endl;
    hrtPrintInfo();
    std::cerr << std::endl;

    std::cerr << "lightsNum = " << m_lights.size() << std::endl;
  }
}


uint GPU_Ray_Tracer::AddLight(const RAYTR::Light& a_light)
{
  RAYTR::Light light = a_light;
  
  AABB3f box;

  if(a_light.m_type == RAYTR::Light::LIGHT_TYPE_MESH)
  {
    std::vector<float4>  positions; // tri positions
    std::vector<float2>  intervals; // probability intervals
    std::vector<float>   areas;

    positions.reserve(1000);

    int matId = a_light.matId;
    std::vector<int>& indexList = m_lightMeshIdListByMatId[matId];

    for(size_t i=0;i<indexList.size();i++)
    {
      int index  = indexList[i];
      int A_offs = this->m_index[3*index+0];
      int B_offs = this->m_index[3*index+1];
      int C_offs = this->m_index[3*index+2];

      positions.push_back(GetVertexPos(A_offs));
      positions.push_back(GetVertexPos(B_offs));
      positions.push_back(GetVertexPos(C_offs));
    }

    intervals.resize(positions.size()/3);
    areas.resize(positions.size()/3);

    bool planeLight = true;
    float3 normal0 = normalize(cross(to_float3(positions[1]) - to_float3(positions[0]), 
                                     to_float3(positions[2]) - to_float3(positions[0])));
    double areaSumm = 0.0f;
    for(int i=0;i<areas.size();i++)
    {
      float3 A = to_float3(positions[i*3+0]);
      float3 B = to_float3(positions[i*3+1]);
      float3 C = to_float3(positions[i*3+2]);

      box.include(A);
      box.include(B);
      box.include(C);
    
      float3 normal = normalize(cross(B-A, C-A));
      if(dot(normal, normal0) < 0.99f)
        planeLight = false;

      areas[i] = float(areaSumm);
      areaSumm += double( 0.5f*length(cross(B-A,C-A)) );
    }
   

    float invSumm = 1.0f/float(areaSumm);
    for(int i=0;i<areas.size();i++)
      areas[i] *= invSumm;

    for(int i=0;i<intervals.size()-1;i++)
    {
      intervals[i].x = areas[i];
      intervals[i].y = areas[i+1];
    }

    int last = intervals.size()-1;
    intervals[last].x = areas[last];
    intervals[last].y = 1.0f;
    
    light.lightMeshIndex = hrtAddLightMesh(&positions[0], &intervals[0], intervals.size());
    light.pos = box.center();
    light.surfaceArea = areaSumm;
    //light.intensity   = light.surfaceArea*light.emittance;
    
    //if(planeLight)
      //light.flags |= Light::LIGHT_MESH_FLAT;
  }

  return Base::AddLight(light);
}


///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::PrintStatInfo(std::ostream& out)
{
  std::cout << "path tracing statistics: " << std::endl;
  std::cout << "avg rays per pixel = " << m_avgRaysPerPixel << std::endl;
}


//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::RT_Core* GPU_Ray_Tracer::GetRTCore()
{
	return &m_core;
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::PrintMaterialParametersOffsets(const string& a_fileName)
{
  ofstream out(a_fileName.c_str());

  out << "#define " << "HMAT_AMBIENT_COLOR_X_OFFSET" << " " << HMAT_AMBIENT_COLOR_X_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_COLOR_Y_OFFSET" << " " << HMAT_AMBIENT_COLOR_Y_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_COLOR_Z_OFFSET" << " " << HMAT_AMBIENT_COLOR_Z_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET" << " " << HMAT_AMBIENT_LIGHT_MULTIPLYER_OFFSET << std::endl; 
  out << "#define " << "HMAT_AMBIENT_LIGHT_ID_OFFSET" << " " << HMAT_AMBIENT_LIGHT_ID_OFFSET << std::endl; 
  
  out << "#define " << "HMAT_DIFFUSE_COLOR_X_OFFSET" << " " << HMAT_DIFFUSE_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_Y_OFFSET" << " " << HMAT_DIFFUSE_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_Z_OFFSET" << " " << HMAT_DIFFUSE_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_RADIANCE_OFFSET" << " " << HMAT_DIFFUSE_RADIANCE_OFFSET << std::endl;

  out << "#define " << "HMAT_SPECULAR_COLOR_X_OFFSET" << " " << HMAT_SPECULAR_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_Y_OFFSET" << " " << HMAT_SPECULAR_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_Z_OFFSET" << " " << HMAT_SPECULAR_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_POWER_OFFSET" << " " << HMAT_SPECULAR_POWER_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_ROUGHNESS_OFFSET" << " " << HMAT_SPECULAR_ROUGHNESS_OFFSET << std::endl;
  //out << "#define " << "HMAT_SPECULAR_GLOSSINESS_OFFSET" << " " << HMAT_SPECULAR_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_FRESNEL_IOR_OFFSET" << " " << HMAT_SPECULAR_FRESNEL_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_BRDF_ID_OFFSET" << " " << HMAT_SPECULAR_BRDF_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_REFLECTION_COLOR_X_OFFSET" << " " << HMAT_REFLECTION_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_Y_OFFSET" << " " << HMAT_REFLECTION_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_Z_OFFSET" << " " << HMAT_REFLECTION_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_POWER_OFFSET" << " " << HMAT_REFLECTION_POWER_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_ROUGHNESS_OFFSET" << " " << HMAT_REFLECTION_ROUGHNESS_OFFSET << std::endl;
  //out << "#define " << "HMAT_REFLECTION_GLOSSINESS_OFFSET" << " " << HMAT_REFLECTION_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_FRESNEL_IOR_OFFSET" << " " << HMAT_REFLECTION_FRESNEL_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_BRDF_ID_OFFSET" << " " << HMAT_REFLECTION_BRDF_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_REFRACTION_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_FOG_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_FOG_MULT_OFFSET" << " " << HMAT_REFRACTION_FOG_MULT_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_X_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_X_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_Y_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET" << " " << HMAT_REFRACTION_EXIT_COLOR_Z_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_GLOSSINESS_OFFSET" << " " << HMAT_REFRACTION_GLOSSINESS_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_IOR_OFFSET" << " " << HMAT_REFRACTION_IOR_OFFSET << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_HEIGHT_OFFSET" << " " << HMAT_DISPLACEMENT_HEIGHT_OFFSET << std::endl;
  
  out << "#define " << "HMAT_FLAGS_OFFSET" << " " << HMAT_FLAGS_OFFSET << std::endl;

  out << "#define " << "HMAT_AMBIENT_COLOR_TEX_ID_OFFSET" << " " << HMAT_AMBIENT_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET" << " " << HMAT_DIFFUSE_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_COLOR_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_POWER_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_POWER_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_SPECULAR_ROUGHNESS_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_ROUGHNESS_TEX_ID_OFFSET << std::endl;
  //out << "#define " << "HMAT_SPECULAR_GLOSSINESS_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_GLOSSINESS_TEX_ID_OFFSET << std::endl;
  //out << "#define " << "HMAT_SPECULAR_FRESNEL_IOR_TEX_ID_OFFSET" << " " << HMAT_SPECULAR_FRESNEL_IOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_COLOR_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_POWER_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_POWER_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_ROUGHNESS_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_ROUGHNESS_TEX_ID_OFFSET << std::endl;
  //out << "#define " << "HMAT_REFLECTION_GLOSSINESS_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_GLOSSINESS_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFLECTION_FRESNEL_IOR_TEX_ID_OFFSET" << " " << HMAT_REFLECTION_FRESNEL_IOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_COLOR_TEX_ID_OFFSET" << " " << HMAT_REFRACTION_COLOR_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_REFRACTION_IOR_TEX_ID_OFFSET" << " " << HMAT_REFRACTION_IOR_TEX_ID_OFFSET << std::endl;

  out << "#define " << "HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET" << " " << HMAT_DISPLACEMENT_HEIGHT_TEX_ID_OFFSET << std::endl;
  out << "#define " << "HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET" << " " << HMAT_DISPLACEMENT_NORMALS_TEX_ID_OFFSET << std::endl;

  out.close();
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::Pack1ChannelTexTo4ThChannel(int bytesOffsetInMaterial, int bytesOffset2InMaterial)
{
  for(int i=0;i<m_hydraMaterials.size();i++)
  {
    HydraMaterial& mat = m_hydraMaterials[i];
    int texIdTo   = *((int*)((char*)&mat + bytesOffsetInMaterial));
    int texIdFrom = *((int*)((char*)&mat + bytesOffset2InMaterial));

    if(texIdTo==INVALID_TEXTURE || texIdFrom == INVALID_TEXTURE || texIdTo == texIdFrom)
      continue;

    int w1 = m_images[texIdTo].width();
    int h1 = m_images[texIdTo].height();

    int w2 = m_images[texIdFrom].width();
    int h2 = m_images[texIdFrom].height();

    if(w1!=w2 || h1!=h2)
      RUN_TIME_ERROR("input 'paired' textures have different resolution. Check relosution of normalmap/displacement, specular/power, refl/power and e.t.c.");

    vec4ub* data1 = (vec4ub*)(m_images[texIdTo].GetData());
    vec4ub* data2 = (vec4ub*)(m_images[texIdFrom].GetData());

    for(int y=0;y<h1;y++)
    {
      int offsetY = y*w1;
      for(int x=0;x<w1;x++)
        data1[offsetY+x].w = data2[offsetY+x].x;
    }
  }

  //for(int i=0;i<m_hydraMaterials.size();i++)
  //{
  //  HydraMaterial& mat = m_hydraMaterials[i];
  //  int texIdFrom = *((int*)((char*)&mat + bytesOffset2InMaterial));
  //  if(texIdFrom != INVALID_TEXTURE)
  //    m_textures[texIdFrom].FreeData();
  //}
}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Ray_Tracer::CreateEnvMapTextures()
{
  for(int i=0;i<m_lights.size();i++)
  {
    bool validCubeTextures = true;
    for(int j=0;j<6;j++)
      validCubeTextures = validCubeTextures && (m_lights[i].texCudeIndices[j] != INVALID_TEXTURE);

    if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY && validCubeTextures)
    {
      int index0 = m_lights[i].texCudeIndices[0];
      if(index0 <= m_images.size() && index0 >= 0)
      {
        const void* data[6];

        for(int j=0;j<6;j++)
        {
          int imgIndex = m_lights[i].texCudeIndices[j];
          data[j] = m_images[imgIndex].GetConstData();
        }

        hrtCreateEnvLightMapCube(m_images[index0].width(), m_images[index0].height(), data);
        hrtSetEnvLightScale((m_lights[i].color*m_lights[i].intensity));
        hrtSetFlags(HRT_ENV_MAP_CUBEMAP_ACTIVE, 1);
        break;
      }
    }
    else if(m_lights[i].GetLightType() == Light::LIGHT_TYPE_SKY)
    {
      int index0 = m_lights[i].sphTexIndex;
    
      if(index0 == INVALID_TEXTURE)
      {
        float4 color = to_float4(m_lights[i].color*m_lights[i].intensity ,0.0f);

        float4 data[4] = {color, color, color, color};
        hrtCreateEnvLightMapSphereHDR(2, 2, (const float*)data);
      }
      else
      {
        ImageStorage* pImage = &m_images[index0];
        if(m_images[index0].GetFormat() == ImageStorage::RGBA32F)
          hrtCreateEnvLightMapSphereHDR(pImage->width(), pImage->height(), (const float*)pImage->GetConstData());
        else if(m_images[index0].GetFormat() == ImageStorage::RGBA8)
          hrtCreateEnvLightMapSphereLDR(pImage->width(), pImage->height(), (const unsigned char*)pImage->GetConstData());
      }

      hrtSetEnvLightScale((m_lights[i].color*m_lights[i].intensity));

      hrtSetFlags(HRT_ENV_MAP_SPHEREMAP_ACTIVE, 1);
      break;
    }
  }
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////
//// so we have 3 megatextures, they are: shadingTexture, transparencyTexture, displacementTexture
//
void GPU_Ray_Tracer::CreateMegaTextures()
{
  CreateEnvMapTextures();

  std::cerr << "assembling mega-textures, total tex num = " << m_images.size() << std::endl;

  if(m_hydraMaterials.size() == 0 && m_materials.size() != 0)
    TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);

  //HydraMaterial testMat;
  //Pack1ChannelTexTo4ThChannel((char*)&testMat.displacement.normals_texId - (char*)&testMat, (char*)&testMat.displacement.height_texId - (char*)&testMat);

  std::vector<int*> shadingTextureIds;
  std::vector<int*> transparencyTextureIds;
  std::vector<int*> displacementTextureIds;

  for(int i=0;i<m_hydraMaterials.size();i++)
  {
    HydraMaterial& mat = m_hydraMaterials[i];

    if(mat.ambient.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.ambient.color_texId);

    if(mat.diffuse.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.diffuse.color_texId);

    if(mat.specular.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.specular.color_texId);

    if(mat.specular.power_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.specular.power_texId);

    if(mat.reflection.color_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.reflection.color_texId);

    if(mat.reflection.power_texId != INVALID_TEXTURE)
      shadingTextureIds.push_back(&mat.reflection.power_texId);

    // other
    //
    if(mat.transparency.color_texId != INVALID_TEXTURE)
      transparencyTextureIds.push_back(&mat.transparency.color_texId);

    if(mat.displacement.normals_texId != INVALID_TEXTURE)
      displacementTextureIds.push_back(&mat.displacement.normals_texId);
  }

  std::map< std::string, std::vector<int*>* > megaTexIndicesData;


  megaTexIndicesData["shadingTexture"]         = &shadingTextureIds;
  megaTexIndicesData["transparencyTexture"]    = &transparencyTextureIds;
  megaTexIndicesData["normalmapTexture"]       = &displacementTextureIds;

  std::map< std::string, std::vector<int*>* >::iterator p;

  hrtClearMegaTextures();

  int   totalBytes = 0;
  float unusedBytes = 0;

  for(p=megaTexIndicesData.begin(); p!= megaTexIndicesData.end(); ++p)
  {
    const std::string& name = p->first;
    std::vector<int*>& idArray = *(p->second);

    MegaTextureManager<char,4> megaTexCompiler;

    MegaTextureManager<char,4>::SizeArray    sizeArray;
    std::vector<const char*> dataArray;
 
    char dummy[4] = {255,255,255,255};
    sizeArray.push_back(pair<int,int>(1,1));
    dataArray.push_back(dummy);

    std::map<int,int> processedTextures;
    int counter = 1;

    for(int i=0;i<idArray.size();i++)
    {
      int id = *(idArray[i]);

      if(id >= m_images.size())
        RUN_TIME_ERROR("a problem with megatexture indices found");

      if(processedTextures.find(id) != processedTextures.end())
      {
        *(idArray[i]) = processedTextures[id];
        continue;
      }

      sizeArray.push_back( pair<int,int>(m_images[id].width(), m_images[id].height()) );
      dataArray.push_back( (char*)m_images[id].GetData());

      *(idArray[i]) = counter; // IMPORTANT!!! Alternate textures id in HydraMaterial data structure. i+1 because 0 is a 1x1 texture = 1.0f.
      processedTextures[id] = counter;
      counter++; 
    }


    int width = 0, height = 0;
    megaTexCompiler.CalculateOffsets(sizeArray, &width, &height);
    const std::vector<float>& lookUpTable = megaTexCompiler.GetLookUpTable();

    char* megaTexData = new char [4*width*height];
    
    megaTexCompiler.BuildImage(dataArray, sizeArray, megaTexData, width, height);

    m_defferedMegaTexHash[name] = new MegaTexStorageProxy(name.c_str(), (unsigned char*)megaTexData, width, height, 4*width*height, ImageStorage::RGBA8, lookUpTable);
   
    
    if(width > 32 && height > 32)
    {
      totalBytes  += megaTexCompiler.GetUsedBytes();
      unusedBytes += float(megaTexCompiler.GetUsedBytes())*(megaTexCompiler.GetBlackAreasPercent()/100.0f);
    }

    delete [] megaTexData;
  }

  if(m_hydraMaterials.size() != 0)
    hrtSetHydraMaterials(&m_hydraMaterials[0], int(m_hydraMaterials.size())); // update materials.

  for(int i=0;i<m_images.size();i++)
    m_images[i].FreeData();

  if(totalBytes > 0)
  {
    std::cerr << "MegaTex: total memory  " << float(totalBytes)/(1024.0f*1024.0f)  << " MBytes" << std::endl;
    std::cerr << "MegaTex: unused memory " << 100.0f*unusedBytes/float(totalBytes) << "\%" << std::endl;
  }

}


void GPU_Ray_Tracer::LoadDefferedMegaTexturesToGPU()
{
  typedef std::map<std::string, MegaTexStorageProxy*>::iterator MegaTexIterator; 
  
  MegaTexIterator p;

  std::vector<MegaTexIterator> megaTexIerators; megaTexIerators.reserve(10);

  megaTexIerators.push_back(m_defferedMegaTexHash.find("transparencyTexture"));
  megaTexIerators.push_back(m_defferedMegaTexHash.find("shadingTexture"));
  megaTexIerators.push_back(m_defferedMegaTexHash.find("normalmapTexture"));

  for(p = m_defferedMegaTexHash.begin(); p!= m_defferedMegaTexHash.end(); ++p)
  {
    if(p->second == NULL) continue;
    
    bool alreadyhasThisTex = false;
    for(int i=0;i<megaTexIerators.size();i++)
    {
      if(p == megaTexIerators[i])
      {
        alreadyhasThisTex = true;
        break;
      }
    }
    if(alreadyhasThisTex) continue;

    megaTexIerators.push_back(p);
  }

  for(int i=0;i<megaTexIerators.size();i++)
  {
    p = megaTexIerators[i];
    if(p->second == NULL) 
      continue;

    const std::string& name = p->first;
   
    int width  = p->second->width();
    int height = p->second->height();
    const char* megaTexData = (const char*)(p->second->GetData());

    const std::vector<float>& lookUpTable = p->second->GetLut();
    
    size_t bytesLeft = hrtGetAvaliableMemoryAmount();
    bool outOfCore = (p->first == "shadingTexture" && width*height*4 > bytesLeft) ||
                     (p->first == "normalmapTexture" && width*height*4 > bytesLeft);

    if(outOfCore)
      std::cerr << "texture " << p->first.c_str() << " was placed io pinned memory" << std::endl;

    hrtAddMegaTexture4ub(name.c_str(), outOfCore, megaTexData, width, height, (float4*)(&lookUpTable[0]), int(lookUpTable.size()/4));
    delete p->second; p->second = NULL;
  }


}



void GPU_Ray_Tracer::SetVariable(const std::string& a_name, int a_val)
{
  Base::SetVariable(a_name, a_val);

  if(a_name == "debugViewSH")
  {
    hrtSetVariableI(HRT_DEBUG_SH_ENVIRONMENT,a_val);
  }
  else if(a_name == "g_saveRaySamples")
  {
    hrtSetFlags(HRT_STORE_RAY_SAMPLES, a_val);
  }
  else if(a_name == "g_debugLayerDraw")
  {
    m_pipeline->SetShaderVariable(a_name, a_val);
  }
  else if(a_name == "g_ptStupid")
  {
    hrtSetFlags(HRT_STUPID_PT_MODE, a_val);
  }
  else if(a_name == "g_enableSROctree")
  {
    hrtSetFlags(HRT_ENABLE_SR_OCTREE, a_val);
  }
  else if(a_name == "rtMeasureRaysType")
  {
    hrtSetVariableI(HRT_MEASURE_RAYS_TYPE, a_val);
  }
  else if(a_name == "rtReorderType")
  {
    hrtSetVariableI(HRT_RAY_REORDER_TYPE, a_val);
  }
  else if(a_name == "rtReorderPattern")
  {
    hrtSetVariableI(HRT_RAY_REORDER_PATTERN, a_val);
  }

}


void GPU_Ray_Tracer::SetVariable(const std::string& a_name, float a_val)
{
  Base::SetVariable(a_name, a_val);
  m_pipeline->SetShaderVariable(a_name, a_val);
}


extern "C" void CreateRandomRotationMatrix(float outM[16])
{
  Matrix4x4f rotX, rotY, rotZ; 

  rotX.SetRotationX( rnd(0, MGML_MATH::PI) );
  rotY.SetRotationY( rnd(0, MGML_MATH::PI) );
  rotX.SetRotationZ( rnd(0, MGML_MATH::PI) );
  
  Matrix4x4f res = rotX*rotY*rotZ;
  memcpy(outM, &res, 16*sizeof(float));
}

