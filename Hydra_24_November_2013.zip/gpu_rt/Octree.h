#pragma once

#define OCTREE_GUARDIAN

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef __CUDACC__
  #define __device__
  #define __host__
#endif

#ifndef universal_call
  #define universal_call __device__ __host__
#endif


struct OctreeNode
{
  
#ifndef __CUDACC__
  OctreeNode()
  {
    leftOffset = -1;
    numPoints = -1;
  }
#endif

  inline universal_call unsigned int GetOffsetToChild()  const { return leftOffset & 0x1fffffff; }
  inline unsigned int	universal_call Leaf() const { return (leftOffset & 0x80000000); } // use sign bit

  inline universal_call int  GetOffsetToPoints() const { return GetOffsetToChild(); }
  inline universal_call void SetOffsetToPoints(int offset) { SetOffsetToChild(offset);}

  inline universal_call int  GetNumPoints() const { return numPoints; }
  inline universal_call void SetNumPoints(int num) { numPoints = num;}

  inline void	universal_call SetLeaf(bool a_Leaf)  { leftOffset = (leftOffset & 0x7fffffff) | (((int)a_Leaf) << 31);}
  inline universal_call void SetOffsetToChild( unsigned int a_Left ) { leftOffset = (leftOffset & 0xe0000000) | (a_Left & 0x1fffffff); }

  int leftOffset;     // all childs are in leftOffset..leftOffset+7
  int numPoints;
};

#define IRRAD_CACHE_PLAIN_DATA_LAYOUT 0


#ifndef __CUDACC__

#include "../CSL/MGML_MEMORY.h"

#ifdef CERF_DLL_EXPORTS
  #define DLL_API __declspec(dllexport)
#else
  #define DLL_API __declspec(dllimport)
#endif


class DLL_API IrradCacheOctreeAPI
{
 
public:
  typedef IrradianceCachePoint_Part1 Part1;
  typedef IrradianceCachePoint_Part2 Part2;
  typedef IrradianceCachePoint_Part3 Part3;

  IrradCacheOctreeAPI(){}
  virtual ~IrradCacheOctreeAPI(){}

  virtual void Insert(const Part1* a_points1, const Part2* a_points2, const Part3* a_points3, int n) = 0;
  virtual void ConvertLayoutToLinearArray() = 0;
  virtual void SetBoundingBox(const AABB3f& aabb) = 0; // the problem is that we can not cange it after first iteration
  virtual void SetClampingFactor(float a_factor) = 0;
  virtual void SetSmoothingFactor(float a_factor) = 0;
  
  virtual AABB3f GetBoundingBox() = 0;

  virtual const OctreeNode* GetRoot() = 0;
  virtual int GetNumNodes() = 0;
  
  virtual const int* GetOctreePointIndices() const = 0;
  virtual int GetOctreeIndicesNum() const = 0;
  
  virtual const Part1* GetPointsDataPart1() = 0;
  virtual const Part2* GetPointsDataPart2() = 0;
  virtual const Part3* GetPointsDataPart3() = 0;

  virtual int GetPointNum() const = 0;

  virtual float3 GetBoxCenter() const = 0;
  virtual float  GetBoxSize() const = 0;
  virtual void   SmoothOutIllum() {}

  virtual void VerifyAndOutStatistic() {}
  virtual void DebugSave() {}
  virtual void DebugLoad() {}

  virtual void DebugDrawLookUpResult(float3 pos){}

};


class DLL_API IC_Octree : public IrradCacheOctreeAPI
{

public:

  IC_Octree();
  ~IC_Octree();

  void Insert(const Part1* a_points1, const Part2* a_points2, const Part3* a_points3, int n);
  void SetBoundingBox(const AABB3f& aabb);

  AABB3f GetBoundingBox();

  void ConvertLayoutToLinearArray();

  const OctreeNode* GetRoot();
  int GetNumNodes();

  const int* GetOctreePointIndices() const;
  int GetOctreeIndicesNum() const;

  const Part1* GetPointsDataPart1();
  const Part2* GetPointsDataPart2();
  const Part3* GetPointsDataPart3();

  int GetPointNum() const { return int(m_recordsData1.size()); }

  void SetClampingFactor(float a_factor) {m_clampingFactor = a_factor;}
  void SetSmoothingFactor(float a_factor) {m_smoothingFactor = a_factor;}
  void SmoothOutIllum();

  void VerifyAndOutStatistic();

  float3 GetBoxCenter() const {return m_centerPos;}
  float  GetBoxSize() const { return m_boxSize; }
  const float3* GetCubeVertPos() const { return cubeVertPos;}

  void DebugSave();
  void DebugLoad();
  void DebugDrawLookUpResult(float3 pos);

protected:

  struct CachePoint
  {
    CachePoint() {index=-1; self = NULL;}
    CachePoint(IC_Octree* a_self, int a_index){ self = a_self; index = a_index; m_validityRadius = self->m_recordsData3[index].validityRadius;}

    float3 GetPos()  const { return self->m_recordsData1[index].pos; }
    float3 GetNorm() const { return self->m_recordsData2[index].norm; }
    float3 GetClor() const { return self->m_recordsData3[index].color; }

    Part1 GetPart1() const {return self->m_recordsData1[index];}
    Part2 GetPart2() const {return self->m_recordsData2[index];}
    Part3 GetPart3() const {return self->m_recordsData3[index];}

    int GetIndex() const { return index;}
    void SetValidityRadius(float a_radius) {self->m_recordsData3[index].validityRadius = a_radius; m_validityRadius = a_radius;}
    float GetValidityRadius() const { return m_validityRadius;}
  
    bool operator==(const CachePoint& rhs) const {return index == rhs.index;}

  protected:
    IC_Octree* self;
    int index;
    float m_validityRadius;
  };

  typedef std::vector<CachePoint>            PointArray;
  
  struct Node
  {
    Node() {m_firstChild=NULL;}

    bool Leaf() const {return (m_firstChild==NULL);}
    Node* Childs(int i) {return m_firstChild + i;}
    void SetFirstChildPointer(Node* a_firstChild) {m_firstChild = a_firstChild;}

    PointArray points;

  protected:
    Node* m_firstChild;

  };

  Node* m_root2;
  Node* m_root3;
  Pool<Node> m_nodesPool;
  Pool<Node> m_tempNodesPool;

  void InsertInTempOctree(Node* node, PointArray& points, const float3& a_pos, float a_size, int a_depth);
  
  // Krivaneck's neighbour clamping
  //
  void PerformNeighbourClamping(PointArray& points, Node* a_accelerationTree);      // Neighbour Clamping technique described in the original Krivaneck's book
  void NeighbourClampingRec(CachePoint* p, Node* a_node, const float3& node_pos, float node_size);

  // Frolov's validity radius clamping
  //
  void PerformValidityRadiusClamping(PointArray& points, Node* a_accelerationTree);
  void ClampValidityRadius(CachePoint* p, Node* a_node, float a_maxSearchRadius);
  void FindKNearestPoints(PointArray& a_nearestArray, int k, const float3& pos, float a_searchRadius, Node* a_node, const float3& node_pos, float node_size);

  //
  //
  void Insert(Node* node, PointArray& points, const float3& a_pos, float a_size, int a_depth);
  void ConvertLayoutRec(Node* a_node, int a_nodeOffset);

  PointArray& ExtractPointsFromLeaf(Node* node, IC_Octree::PointArray& a_points, PointArray& localPoints);
  float AverageValidityRadius(const PointArray& points);
  Node* Create8Childs(Node* a_node, int a_poolId);

  void DebudOutTreeBoxes(Node* a_node, const float3& a_pos, float a_size);

  //
  //

  int New8Nodes();
  int NewPointList();

  int* MakeLinearIndicesLayout();
  void PutIndices(int nodeOffset);

  struct Statistics
  {
    float avgPointsInNode;
    int maxPointsInNode;
    int nodesNum;
    int emptyNodesNum;
    int maxDeep;
  } m_stat;

  void CollectStatictic(int octreeNodeOffset, int currDeep, float3 pos, float size);
  void CollectStatictic(Node* a_node, int currDeep, float3 a_pos, float size);

  std::vector<OctreeNode> m_root;

  std::vector<Part1> m_recordsData1;
  std::vector<Part2> m_recordsData2;
  std::vector<Part3> m_recordsData3;

  std::vector<int> m_allPointsIndices;

  float3 m_centerPos;
  float  m_boxSize;
  float3 cubeVertPos[8];
  float m_clampingFactor;
  float m_smoothingFactor;

  ofstream m_debugBoxesFile;
};




#endif


