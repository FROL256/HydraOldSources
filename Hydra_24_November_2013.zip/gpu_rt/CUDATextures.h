#define CUDA_TEXTURES_GUARDIAN

#include <cuda.h>
#include <thrust/device_vector.h>

namespace SGAPI // Simple Graphics API
{

  struct ITexture2D
  {
    ITexture2D(){}
    virtual ~ITexture2D(){}

    virtual int width() const = 0;
    virtual int height() const = 0;
    virtual int mipsNumber() const { return 0;}

    virtual int generateMips() = 0;

    virtual void bind(const char* a_name) = 0;
    virtual void bindMipLevel(const char* a_name, int a_mipLevel) = 0;
    virtual void unbind() = 0;

    virtual void freeRawData() {}
    virtual void freeArrayData() {}
    virtual void freeData() {freeRawData(); freeArrayData(); }
  };

  struct ITextureCubeLayered
  {
    ITextureCubeLayered(){}
    virtual ~ITextureCubeLayered(){}

    virtual int width() const = 0;
    virtual int mipsNumber() const { return 0;}
    virtual int cubesNumber() const = 0;
    virtual int layersNumber() const { return cubesNumber()*6;}

    virtual int generateMips() = 0;

    virtual void bind(const char* a_name) = 0;
    virtual void bindMipLevel(const char* a_name, int a_mipLevel) = 0;
    virtual void unbind() = 0;

    virtual void freeRawData() {}
    virtual void freeArrayData() {}
    virtual void freeData() {freeRawData(); freeArrayData(); }
  };

  static int possibleMips(int width, int height)
  {
    //int mips1 = 0, mips2 = 0;

    int pow2 = 1;
    int doneMipslevel = 0;
    for(int i=0;i<10;i++)
    {
      int sizeX = width/pow2;
      int sizeY = height/pow2;
      pow2 *= 2;

      //dim3 grid(sizeX/16,sizeY/16);
      //dim3 threads(16,16);
      doneMipslevel = i;

      if(sizeX==0 || sizeY==0)
        break;
    }

    return doneMipslevel-1;
  }




  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  template<class T>
  struct CUDATexture2D : public ITexture2D
  {

  public:
    CUDATexture2D(int a_width, int a_height, cudaChannelFormatDesc a_format);
    ~CUDATexture2D();

    int width() const  { return m_width; }
    int height() const { return m_height; }
    int mipsNumber() const { return m_currMipsNumber;}

    int generateMips();

    void bind(const char* a_name);
    void bindMipLevel(const char* a_name, int a_mipLevel);
    void unbind();

    T* getRawDevicePtr(int a_mipLevel);
    const T* getRawDevicePtr(int a_mipLevel) const;

    cudaArray* getArrayDevicePtr(int a_mipLevel);
    const cudaArray* getArrayDevicePtr(int a_mipLevel) const;

    void freeRawData();
    void freeArrayData();

  protected:

    enum {MAX_MIPS = 16};

    CUDATexture2D(const CUDATexture2D<T>& rhs){}
    CUDATexture2D<T>& operator=(const CUDATexture2D<T>& rhs) {return *this;}

    thrust::device_vector<T> m_data[MAX_MIPS];
    cudaArray* m_dataArray[MAX_MIPS];
    const textureReference* m_pLastTexRef;

    bool eq(cudaChannelFormatDesc a, cudaChannelFormatDesc b) const { return (a.x == b.x) && (a.y == b.y) && (a.z == b.z) && (a.w == b.w); }

    cudaChannelFormatDesc m_format;
    int m_width;
    int m_height;
    int m_currMipsNumber;

  };


  ////////////////////////////////////////////////////////////////////////////


  template<class T>
  struct CUDATextureCubeLayered : public ITextureCubeLayered
  {
  public:

    CUDATextureCubeLayered(int a_width, int a_cubesNum, cudaChannelFormatDesc a_format);
    ~CUDATextureCubeLayered();

    int width() const  { return m_width; }
    int mipsNumber() const { return m_currMipsNumber;}
    int cubesNumber() const { return m_cubesNumber;}

    int generateMips();

    void bind(const char* a_name);
    void bindMipLevel(const char* a_name, int a_mipLevel);
    void unbind();

    T* getRawDevicePtr(int a_mipLevel);
    const T* getRawDevicePtr(int a_mipLevel) const;

    cudaArray* getArrayDevicePtr(int a_mipLevel);
    const cudaArray* getArrayDevicePtr(int a_mipLevel) const;

    void freeRawData();
    void freeArrayData();

  protected:
    enum {MAX_MIPS = 16};

    CUDATextureCubeLayered(const CUDATextureCubeLayered<T>& rhs){}
    CUDATextureCubeLayered<T>& operator=(const CUDATextureCubeLayered<T>& rhs) {return *this;}

    thrust::device_vector<T> m_data[MAX_MIPS];
    cudaArray* m_dataArray[MAX_MIPS];
    const textureReference* m_pLastTexRef;

    bool eq(cudaChannelFormatDesc a, cudaChannelFormatDesc b) const { return (a.x == b.x) && (a.y == b.y) && (a.z == b.z) && (a.w == b.w); }

    cudaChannelFormatDesc m_format;
    int m_width;
    int m_currMipsNumber;
    int m_cubesNumber;
  };


}









template<class T>
SGAPI::CUDATexture2D<T>::CUDATexture2D(int a_width, int a_height, cudaChannelFormatDesc a_format) : m_width(a_width), m_height(a_height), m_format(a_format)
{
  for(int i=0;i<MAX_MIPS;i++)
    m_dataArray[i] = NULL;
  m_pLastTexRef = NULL;
  
  m_currMipsNumber = possibleMips(m_width, m_height);

  int w = a_width;
  int h = a_height;

  for(int i=0;i<m_currMipsNumber;i++)
  {
    m_data[i].resize(w*h);
    cudaMallocArray(&m_dataArray[i], &a_format, w, h);

    w = (w >> 1);
    h = (h >> 1);
  }
}



template<class T>
SGAPI::CUDATexture2D<T>::~CUDATexture2D()
{
  freeArrayData(); // raw data will be released automaticly because of thrust::device_vectors
}

template<class T>
void SGAPI::CUDATexture2D<T>::freeRawData()
{
  for(int i=0;i<MAX_MIPS;i++)
  {
    if( m_data[i].size() > 0)
      m_data[i] = thrust::device_vector<T>();
  }
}

template<class T>
void SGAPI::CUDATexture2D<T>::freeArrayData()
{
  for(int i=0;i<MAX_MIPS;i++)
  {
    if(m_dataArray[i] != NULL)
    {
      cudaFreeArray(m_dataArray[i]);
      m_dataArray[i] = NULL;
    }
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
template<class T>
T* SGAPI::CUDATexture2D<T>::getRawDevicePtr(int a_mipLevel)
{
  if(a_mipLevel >= MAX_MIPS || m_data[a_mipLevel].size() == 0)
    return NULL;

  return get_pointer(m_data[a_mipLevel]);
}

template<class T>
const T* SGAPI::CUDATexture2D<T>::getRawDevicePtr(int a_mipLevel) const
{
  if(a_mipLevel >= MAX_MIPS || m_data[a_mipLevel].size() == 0)
    return NULL;

  return get_pointer(m_data[a_mipLevel]);
}

template<class T>
cudaArray* SGAPI::CUDATexture2D<T>::getArrayDevicePtr(int a_mipLevel)
{
  if(a_mipLevel >= MAX_MIPS || m_dataArray[a_mipLevel] == NULL)
    return NULL;
  
  return m_dataArray[a_mipLevel];
}

template<class T>
const cudaArray* SGAPI::CUDATexture2D<T>::getArrayDevicePtr(int a_mipLevel) const
{
  if(a_mipLevel >= MAX_MIPS || m_dataArray[a_mipLevel] == NULL)
    return NULL;

  return m_dataArray[a_mipLevel];
}



/////////////////////////////////////////////////////////////////////////////////////////////////
////

#ifdef __CUDACC__
    
template<class T>
__global__ void Build2DMipMap(const T* in_data, T* out_data, int w, int h, int pitch)
{
  uint x = blockDim.x * blockIdx.x + threadIdx.x;
  uint y = blockDim.y * blockIdx.y + threadIdx.y;

  if(x >= w || y >= h)
    return;

  T sample1 = in_data[Index2D(2*x+0,2*y+0,2*pitch)];
  T sample2 = in_data[Index2D(2*x+1,2*y+0,2*pitch)];
  T sample3 = in_data[Index2D(2*x+0,2*y+1,2*pitch)];
  T sample4 = in_data[Index2D(2*x+1,2*y+1,2*pitch)];

  out_data[Index2D(x,y,pitch)] = 0.25*(sample1+sample2+sample3+sample4);
}

texture<ushort4, 2, cudaReadModeNormalizedFloat> g_inTex4f16;


inline __device__ ushort4 local_f4toh4(const float4& data)
{
  ushort4 res;
  res.x = __float2half_rn(data.x);
  res.y = __float2half_rn(data.y);
  res.z = __float2half_rn(data.z);
  res.w = __float2half_rn(data.w);
  return res;
}

__global__ void Build2DMipMap4f_16bit(ushort4* out_data, int w, int h, int pitch)
{
  uint x = blockDim.x * blockIdx.x + threadIdx.x;
  uint y = blockDim.y * blockIdx.y + threadIdx.y;

  if(x >= w || y >= h)
    return;

  float invW = 1.0f/(w-1);
  float invH = 1.0f/(h-1);

  float4 sample1 = tex2D(g_inTex4f16, float(2*x+0)*invW, float(2*y+0)*invH ); 
  float4 sample2 = tex2D(g_inTex4f16, float(2*x+1)*invW, float(2*y+0)*invH ); 
  float4 sample3 = tex2D(g_inTex4f16, float(2*x+0)*invW, float(2*y+1)*invH ); 
  float4 sample4 = tex2D(g_inTex4f16, float(2*x+1)*invW, float(2*y+1)*invH ); 

  out_data[Index2D(x,y,pitch)] = local_f4toh4( 0.25*(sample1+sample2+sample3+sample4) );
}


#endif


template<class T>
int SGAPI::CUDATexture2D<T>::generateMips()
{
  if(m_dataArray[0] != NULL)
  {

  }
  else if(m_data[0].size() > 0)
  {
    int pow2 = 2;
    for(int i=1;i<m_currMipsNumber;i++)
    {
      int sizeX = m_width/pow2;
      int sizeY = m_height/pow2;
      pow2 *= 2;

      dim3 grid(sizeX/16,sizeY/16);
      dim3 threads(16,16);

      if(grid.x == 0) grid.x = 1;
      if(grid.y == 0) grid.y = 1;

      if(eq(m_format, cudaCreateChannelDescHalf4()) && sizeof(T) == sizeof(ushort4))
      {
        //printf("half mip maps creation\n");

        CUDA_SAFE_CALL( cudaBindTexture2D(0, g_inTex4f16, (ushort4*)getRawDevicePtr(i-1), m_format, sizeX*2, sizeY*2, sizeX*2*sizeof(ushort4)) );

        Build2DMipMap4f_16bit <<<grid, threads>>>((ushort4*)getRawDevicePtr(i), sizeX, sizeY, sizeX);
        CUT_CHECK_ERROR("Kernel execution failed");

        CUDA_SAFE_CALL(cudaUnbindTexture(g_inTex4f16));
      }
      else
      {
        //printf("full mip maps creation\n");

        Build2DMipMap<T> <<<grid, threads>>>(getRawDevicePtr(i-1), getRawDevicePtr(i), sizeX, sizeY, sizeX);
        CUT_CHECK_ERROR("Kernel execution failed");
      }
    }
  }
  else
  {
    return 0;
  }
  

  return m_currMipsNumber;
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
template<class T>
void SGAPI::CUDATexture2D<T>::bind(const char* a_name)
{
  const textureReference* pCudaTexRef = NULL;
  cudaError err = cudaGetTextureReference(&pCudaTexRef, a_name);
  if(cudaSuccess != err)
    fprintf(stderr,"CUDA 5.0 compatability Error: %s", cudaGetErrorString(err));

  if(pCudaTexRef == NULL)
    return;

  this->unbind();
  m_pLastTexRef = pCudaTexRef;
  cudaBindTextureToArray(m_pLastTexRef, m_dataArray[0], &m_format);
}



template<class T>
void SGAPI::CUDATexture2D<T>::bindMipLevel(const char* a_name, int a_mipLevel)
{
  if(a_mipLevel >= MAX_MIPS || m_dataArray[a_mipLevel] == NULL)
    return;

  const textureReference* pCudaTexRef = NULL;
  cudaError err = cudaGetTextureReference(&pCudaTexRef, a_name);
  if(cudaSuccess != err)
    fprintf(stderr,"CUDA 5.0 compatability Error: %s", cudaGetErrorString(err));

  if(pCudaTexRef == NULL)
    return;

  this->unbind();
  m_pLastTexRef = pCudaTexRef;
  cudaBindTextureToArray(m_pLastTexRef, m_dataArray[a_mipLevel], &m_format);
}

template<class T>
void SGAPI::CUDATexture2D<T>::unbind()
{
  cudaUnbindTexture(m_pLastTexRef);
}




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


template<class T>
SGAPI::CUDATextureCubeLayered<T>::CUDATextureCubeLayered(int a_width, int a_cubesNum, cudaChannelFormatDesc a_format) : m_width(a_width), m_cubesNumber(a_cubesNum), m_format(a_format)
{
  for(int i=0;i<MAX_MIPS;i++)
    m_dataArray[i] = NULL;
  m_pLastTexRef = NULL;

  m_currMipsNumber = possibleMips(m_width, m_width);

  int w = a_width;
 
  for(int i=0;i<m_currMipsNumber;i++)
  {
    m_data[i].resize(w*w*6*a_cubesNum);
    CUDA_SAFE_CALL(cudaMalloc3DArray(&m_dataArray[i], &m_format, make_cudaExtent(w, w, 6*a_cubesNum), (cudaArrayLayered | cudaArrayCubemap) )); 
    w = (w >> 1);
  }

}


template<class T>
SGAPI::CUDATextureCubeLayered<T>::~CUDATextureCubeLayered()
{
  freeArrayData();
}


template<class T>
void SGAPI::CUDATextureCubeLayered<T>::freeRawData()
{
  for(int i=0;i<MAX_MIPS;i++)
  {
    if( m_data[i].size() > 0)
      m_data[i] = thrust::device_vector<T>();
  }
}

template<class T>
void SGAPI::CUDATextureCubeLayered<T>::freeArrayData()
{
  for(int i=0;i<MAX_MIPS;i++)
  {
    if(m_dataArray[i] != NULL)
    {
      cudaFreeArray(m_dataArray[i]);
      m_dataArray[i] = NULL;
    }
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
template<class T>
T* SGAPI::CUDATextureCubeLayered<T>::getRawDevicePtr(int a_mipLevel)
{
  if(a_mipLevel >= MAX_MIPS || m_data[a_mipLevel].size() == 0)
    return NULL;

  return get_pointer(m_data[a_mipLevel]);
}

template<class T>
const T* SGAPI::CUDATextureCubeLayered<T>::getRawDevicePtr(int a_mipLevel) const
{
  if(a_mipLevel >= MAX_MIPS || m_data[a_mipLevel].size() == 0)
    return NULL;

  return get_pointer(m_data[a_mipLevel]);
}

template<class T>
cudaArray* SGAPI::CUDATextureCubeLayered<T>::getArrayDevicePtr(int a_mipLevel)
{
  if(a_mipLevel >= MAX_MIPS || m_dataArray[a_mipLevel] == NULL)
    return NULL;

  return m_dataArray[a_mipLevel];
}

template<class T>
const cudaArray* SGAPI::CUDATextureCubeLayered<T>::getArrayDevicePtr(int a_mipLevel) const
{
  if(a_mipLevel >= MAX_MIPS || m_dataArray[a_mipLevel] == NULL)
    return NULL;

  return m_dataArray[a_mipLevel];
}



#ifdef __CUDACC__

texture<ushort4, cudaTextureTypeCubemapLayered, cudaReadModeNormalizedFloat>  cubeMapNextMip;
//texture<ushort4, cudaTextureTypeCubemap, cudaReadModeNormalizedFloat>  cubeMapNextMip;

__global__ void Build2DMipMapCube4f_16bit(ushort4* out_data, int width)
{
  uint x = blockDim.x * blockIdx.x + threadIdx.x;
  uint y = blockDim.y * blockIdx.y + threadIdx.y;
  uint z = blockDim.z * blockIdx.z + threadIdx.z;

  if(x >= width || y >= width)
    return;

  float cx, cy, cz;

  for ( unsigned int face = 0; face < 6; face ++ )
  {
    float4 color = make_float4(0,0,0,0);
    float summWeights = 0.0f;

    float fx = float(x);
    float fy = float(y);

    for(float offsX = -1.0f; offsX <= 1.0f; offsX += 1.0f)
    {
      for(float offsY = -1.0f; offsY <= 1.0f; offsY += 1.0f)
      {
        float u = ( (fx + 0.5f + offsX) / float(width) ) * 2.f - 1.f; 
        float v = ( (fy + 0.5f + offsY) / float(width) ) * 2.f - 1.f;
        float t = 1.0f;

        float3 vdir = normalize(make_float3(u,v,t));
        t = vdir.z;

        float distSquare = offsX*offsX + offsY*offsY;
        float weight = 1.0f/(1.0f + 2.0f*sqrtf(distSquare));
        //float weight = (1.0f/(sigma*sqrtf(2.0f*3.14159f)))*exp(dist*dist/(2.0f*sigma*sigma));

        //Layer 0 is positive X face
        if ( face == 0 )
        {
          cx = t;
          cy = -v;
          cz = -u;
        }
        //Layer 1 is negative X face
        else if ( face == 1 )
        {
          cx = -t;
          cy = -v;
          cz = u;
        }
        //Layer 2 is positive Y face
        else if ( face == 2 )
        {
          cx = u;
          cy = t;
          cz = v;
        }
        //Layer 3 is negative Y face
        else if ( face == 3 )
        {
          cx = u;
          cy = -t;
          cz = -v;
        }
        //Layer 4 is positive Z face
        else if ( face == 4 )
        {
          cx = u;
          cy = -v;
          cz = t;
        }
        //Layer 5 is negative Z face
        else if ( face == 5 )
        {
          cx = -u;
          cy = -v;
          cz = -t;
        }

        //float3 dir = normalize(make_float3(cx,cy,cz));
        //cx = dir.x; cy = dir.y; cz = dir.z;
#if __CUDA_ARCH__ >= 200

        color += texCubemapLayered(cubeMapNextMip, cx, cy, cz, z)*weight;
        summWeights += weight;
#endif
      }
    }
    
    color *= (1.0f/summWeights);

    out_data[z*(width*width*6) + face*width*width + y*width + x] = float4_to_half4(color);
  }

}



__global__ void Build2DMipMapCube4fDebug_16bit(ushort4* out_data, int width)
{
  uint x = blockDim.x * blockIdx.x + threadIdx.x;
  uint y = blockDim.y * blockIdx.y + threadIdx.y;
  uint z = blockDim.z * blockIdx.z + threadIdx.z;

  if(x >= width || y >= width)
    return;

  // 0.5f offset and division are necessary to access the original data points
  // in the texture (such that bilinear interpolation will not be activated).
  // For details, see also CUDA Programming Guide, Appendix D 

  float u = ( (x+0.5f) / float(width) ) * 2.f - 1.f; 
  float v = ( (y+0.5f) / float(width) ) * 2.f - 1.f;

  float cx, cy, cz;

  for ( unsigned int face = 0; face < 6; face ++ )
  {
    //Layer 0 is positive X face
    if ( face == 0 )
    {
      cx = 1;
      cy = -v;
      cz = -u;
    }
    //Layer 1 is negative X face
    else if ( face == 1 )
    {
      cx = -1;
      cy = -v;
      cz = u;
    }
    //Layer 2 is positive Y face
    else if ( face == 2 )
    {
      cx = u;
      cy = 1;
      cz = v;
    }
    //Layer 3 is negative Y face
    else if ( face == 3 )
    {
      cx = u;
      cy = -1;
      cz = -v;
    }
    //Layer 4 is positive Z face
    else if ( face == 4 )
    {
      cx = u;
      cy = -v;
      cz = 1;
    }
    //Layer 5 is negative Z face
    else if ( face == 5 )
    {
      cx = -u;
      cy = -v;
      cz = -1;
    }
#if __CUDA_ARCH__ >= 200
    // read from texture, do expected transformation and write to global memory
    int w2 = width*width;
    out_data[z*(w2*6) + face*w2 + y*width + x] = float4_to_half4( texCubemapLayered(cubeMapNextMip, cx, cy, cz, z) );
#endif
  }

}



#endif


template<class T>
int SGAPI::CUDATextureCubeLayered<T>::generateMips()
{

  int pow2 = 2;
  for(int i=1;i<m_currMipsNumber;i++)
  {
    int sizeX = m_width/pow2;
    pow2 *= 2;

    dim3 grid(sizeX/16, sizeX/16, m_cubesNumber);
    dim3 threads(16,16,1);

    if (grid.x == 0) grid.x = 1;
    if (grid.y == 0) grid.y = 1;

    if(eq(m_format, cudaCreateChannelDescHalf4()) && sizeof(T) == sizeof(ushort4))
    {
      int currWidth = sizeX*2;
      int num_faces = m_cubesNumber*6;
      
      cudaMemcpy3DParms myparms = {0};
      myparms.srcPos = make_cudaPos(0,0,0); 
      myparms.dstPos = make_cudaPos(0,0,0); 
      myparms.srcPtr = make_cudaPitchedPtr(getRawDevicePtr(i-1), currWidth * sizeof(T), currWidth, currWidth); 
      myparms.dstArray = m_dataArray[i-1];
      myparms.extent   = make_cudaExtent(currWidth, currWidth, num_faces);
      myparms.kind     = cudaMemcpyDeviceToDevice;
      CUDA_SAFE_CALL(cudaMemcpy3D(&myparms));

      cubeMapNextMip.addressMode[0] = cudaAddressModeClamp;
      cubeMapNextMip.addressMode[1] = cudaAddressModeClamp;
      cubeMapNextMip.filterMode = cudaFilterModeLinear;
      cubeMapNextMip.normalized = true;  // access with normalized texture coordinates

      CUDA_SAFE_CALL(cudaBindTextureToArray(cubeMapNextMip, m_dataArray[i-1], m_format));


      Build2DMipMapCube4f_16bit <<<grid, threads>>>((ushort4*)getRawDevicePtr(i), sizeX);
      //Build2DMipMapCube4fDebug_16bit <<<grid, threads>>>((ushort4*)getRawDevicePtr(i), sizeX);
      CUT_CHECK_ERROR("Kernel execution failed");

      CUDA_SAFE_CALL(cudaUnbindTexture(cubeMapNextMip));
    }
    else
    {
      printf("cubemaps, full mip maps creation for general types not implemented\n");

    }
  }

  return m_currMipsNumber;
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
template<class T>
void SGAPI::CUDATextureCubeLayered<T>::bind(const char* a_name)
{
  const textureReference* pCudaTexRef = NULL;
  cudaGetTextureReference(&pCudaTexRef, a_name);

  if(pCudaTexRef == NULL)
    return;

  this->unbind();
  m_pLastTexRef = pCudaTexRef;
  cudaBindTextureToArray(m_pLastTexRef, m_dataArray[0], &m_format);
}



template<class T>
void SGAPI::CUDATextureCubeLayered<T>::bindMipLevel(const char* a_name, int a_mipLevel)
{
  if(a_mipLevel >= MAX_MIPS || m_dataArray[a_mipLevel] == NULL)
    return;

  const textureReference* pCudaTexRef = NULL;
  cudaGetTextureReference(&pCudaTexRef, a_name);

  if(pCudaTexRef == NULL)
    return;

  this->unbind();
  m_pLastTexRef = pCudaTexRef;
  cudaBindTextureToArray(m_pLastTexRef, m_dataArray[a_mipLevel], &m_format);
}

template<class T>
void SGAPI::CUDATextureCubeLayered<T>::unbind()
{
  cudaUnbindTexture(m_pLastTexRef);
}




