#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "IrradianceCache.h"

#include "RadianceGrid.h"

using MGML_MATH::EPSILON_E5;

void GPU_Path_Tracer::CheckBlockListF(GPU_Path_Tracer::BlockList* pList, const char* file, int line)
{
  GPU_Path_Tracer::BlockList::iterator p;
  int counter = 0;
  for(p=pList->begin(); p!= pList->end(); ++p)
  {
    if(p->index == 0)
      counter++;
  }

  if(counter > 1)
  {
    string c = ToString(counter);
    RunTimeError(file,line,"there are " + c + " blocks with index == 0");
  }

}

#define CHECK_LIST(plist) CheckBlockListF((plist),__FILE__,__LINE__)

/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::GPU_Path_Tracer(int w, int h, int flags) : Base(w,h,flags)
{
  m_pathTracingState = STATE_BEGIN;
  hmctInit(w,h);
  hlmInit();

  SetRaysPerPixel(1);

  m_blocksArray.resize((w*h)/(ZBlock::GetSize()));
  m_avgRaysPerPixel = 0;

  m_startScreenBlockListSize = 0;
  m_debugICacheFileOutput = false;
  m_voxelRadianceCacheEnabled = false;
  m_photonMapsPrepared = false;

  for(int i=0;i<HEMISPHERE_SEQUENCE_NUM;i++)
  {
    hlmInitHemisphereRaysTexture(0, i, &m_sphereUniformArray[i][0], m_sphereUniformArray[i].size());
    hlmInitHemisphereRaysTexture(1, i, &m_sphereUniformArray2[i][0], m_sphereUniformArray2[i].size());
    hlmInitSHCoefficient(&m_shCoeffsArray[0], m_shResPhi, m_shResTheta, m_sphLayersNum);
  }

  m_pRC = NULL;
  m_pPhotonMap = hlmCreatePhotonMap(1000000, false);
  m_pCausticPhotonMap = hlmCreatePhotonMap(1000000, true);

  size_t BLOCK_NUMBER = m_blocksArray.size();
  m_zBlocksCoordByIndex.resize(BLOCK_NUMBER);
  m_zblocksPosTmp.resize(BLOCK_NUMBER);

  //m_display2DLines.InitFromString(RTE_GetShaderSource("simple_vs_2d"), RTE_GetShaderSource("color_ps"));
  m_display2DLines.InitFromString(RTE_GetShaderSource("dummy_vs_2d"), RTE_GetShaderSource("gs_quad_lines"), RTE_GetShaderSource("color_ps"));

  // resize OpenGL vertex buffer
  //
  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_blocksPos);                                CHECK_GL_ERRORS;                                    
  glBufferData(GL_ARRAY_BUFFER, BLOCK_NUMBER*sizeof(float2), NULL, GL_DYNAMIC_DRAW); CHECK_GL_ERRORS;

  // init vao for blocks
  //
  GLuint location = glGetAttribLocation(m_display2DLines.program, "vertex"); CHECK_GL_ERRORS;
  glBindVertexArray(m_glRes.m_vaoBlocks);                                    CHECK_GL_ERRORS;
  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_blocksPos);                        CHECK_GL_ERRORS;     
  glEnableVertexAttribArray(location);                                       CHECK_GL_ERRORS;
  glVertexAttribPointer(location, 3, GL_FLOAT, GL_FALSE, 0, 0);              CHECK_GL_ERRORS;
  
  glBindVertexArray(0);
  glBindBuffer(GL_ARRAY_BUFFER, 0);  

  m_ortoMat = CalcOrtoMatix(0, width, 0, height,-1,1);
}

void GPU_Path_Tracer::SetWindowResolution(int a_width, int a_height)
{
  GPU_Ray_Tracer::SetWindowResolution(a_width, a_height);
  
  if(!m_windowWasResized)
    return;

  m_blocksArray.resize((width*height)/(ZBlock::GetSize())); // width and height may not be equal to a_width and a_height
  SetRaysPerPixel(1);

  size_t BLOCK_NUMBER = m_blocksArray.size();
  m_zBlocksCoordByIndex.resize(BLOCK_NUMBER);
  m_zblocksPosTmp.resize(BLOCK_NUMBER);

  // resize OpenGL vertex buffer
  //
  glBindBuffer(GL_ARRAY_BUFFER, m_glRes.m_blocksPos);                                CHECK_GL_ERRORS;                                    
  glBufferData(GL_ARRAY_BUFFER, BLOCK_NUMBER*sizeof(float2), NULL, GL_DYNAMIC_DRAW); CHECK_GL_ERRORS;
  glBindBuffer(GL_ARRAY_BUFFER, 0);  

  m_ortoMat = CalcOrtoMatix(0, width, 0, height,-1,1);

  hrtPrintInfo();

  m_windowWasResized = false;
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
GPU_Path_Tracer::~GPU_Path_Tracer()
{
  hlmDeletePhotonMap(m_pCausticPhotonMap); m_pCausticPhotonMap = NULL;
  hlmDeletePhotonMap(m_pPhotonMap); m_pPhotonMap = NULL;
  delete m_pRC; m_pRC = NULL;

  BlockList::Free();
  hlmDelete();
  hmctDelete();
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::SetRenderingParams(const RenderingParams& a_params)
{
  m_params = a_params;
  hrtSetFlags(HRT_USE_HDR_ESTIMATION, m_params.useHDRQualityEstimation);
  
  m_pipeline->SetShaderVariable("g_pathTraceError",    a_params.qualityTreshold);
  m_pipeline->SetShaderVariable("g_dofEnable",         a_params.enableDOF);
  m_pipeline->SetShaderVariable("g_dofLensRadius",     a_params.dofLensRadius);
  m_pipeline->SetShaderVariable("g_dofFocalPlaneDist", a_params.dofFocalPlaneDist);

  m_rtOnlyVarDrawRaysStatInfo = m_params.drawRaysStatInfo;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::MakeScreenBlockList(BlockList* pList)
{ 
  while(!pList->empty())
    pList->pop_front();

  int BLOCK_NUMBER = m_blocksArray.size();
  
  BlockList::Free();
  BlockList::Allocate(BLOCK_NUMBER+10);

  for(int i=0;i<BLOCK_NUMBER;i++)
  {
    int x = (i*Z_ORDER_BLOCK_SIZE)%width; 
    int y = (i*ZBlock::GetSize() - x*Z_ORDER_BLOCK_SIZE)/width;
    m_zBlocksCoordByIndex[i] = float2(x,y); //  ������ ��� ���������

    pList->push_front(ZBlock(i,10000));
  }

  hmctGenerateEyeInitialRays();
  hmctClearColorBuffers();

  m_avgRaysPerPixel = 0; // zero when start

  // this variable need for the last pass of path tracing because i have some errors with
  // small size of kernel. so i need some hack. just reset this variable to 1 or 2
  m_lastPass = START_LAST_PASS;
  m_megaBlockPathTraceInProcess = false;
  forceEnd = false;
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DoMegaBlock(BlockList& a_blockList, RenderSettings a_renderState)
{
  if(a_blockList.empty() || forceEnd)
    return;
 
  const int zblocksInParallelNumber = hrtGetMegaBlockSize()/(ZBlock::GetSize()*m_currRaysPerPixel);

  // fetch first zblocksInParallelNumber ZBlocks from list and make array of it
  //
  int counter = 0;
  while(!a_blockList.empty() && counter < zblocksInParallelNumber)
  {
    m_blocksArray[counter] = *(a_blockList.begin());
    a_blockList.pop_front();
    counter++;
  }

  bool unprocessedTilesExists = (a_blockList.size() != 0);

  hmctSetZBlocks(&m_blocksArray[0], counter);

  for(int i=0;i<4;i++) // because eof odd and even sequences we must do it at least 2 times
  {
    if(m_params.qmcOneSeed)
      hrtNextSequenceQMC();

    hmctMegaBlockPathTraceSM(counter, 0); ASSERT(counter*ZBlock::GetSize() <= hrtGetMegaBlockSize());
   
    hmctCompareAndStoreResult(&m_blocksArray[0], counter, bool(i==3));  // compare old blocks colors with new, recompute and store the new result 
  }

  m_pathTracingPassNumber += 4;


  // extract unprocessed block to separate array
  //
  std::vector<ZBlock> blockesInQueue; blockesInQueue.reserve((width*height)/256 + 16);
  while(!a_blockList.empty())
  {
    blockesInQueue.push_back(*(a_blockList.begin()));
    a_blockList.pop_front();
  }

  // blocks sorting by dispersion
  //
  if(0)
  {
    // extract all other blocks to the same queue
    //
    while(!a_blockList.empty())
    {
      blockesInQueue.push_back(*(a_blockList.begin()));
      a_blockList.pop_front();
    }

    struct CompareBlocks { bool operator()(const ZBlock& a, const ZBlock& b) {return a.diff < b.diff;} };

    std::sort(blockesInQueue.begin(), blockesInQueue.end(), CompareBlocks());
  }

  // blocks sorting by index
  //
  if(m_params.initialSPP > 1)
  {
    // extract all other blocks to the same queue
    //
    while(!a_blockList.empty())
    {
      blockesInQueue.push_back(*(a_blockList.begin()));
      a_blockList.pop_front();
    }

    struct CompareBlocks { bool operator()(const ZBlock& a, const ZBlock& b) {return a.index < b.index;} };

    std::sort(blockesInQueue.begin(), blockesInQueue.end(), CompareBlocks());
  }


  // now see the block quality metric and if it is too small, discard this block from the list
  // 
  float maxError = 0.0f;
  float avgError = 0.0f;
  for(int i=0;i<counter;i++)
  //for(int i=counter-1;i>=0;i--)
  {
    float error = 0;

    if (!BlockFinished(m_blocksArray[i], &error))
      a_blockList.push_front(m_blocksArray[i]);
    else
      m_avgRaysPerPixel += 1*m_blocksArray[i].counter*CMP_RESULTS_BLOCK_SIZE; // was 2* ...

    if(error > maxError)
      maxError = error;
    avgError += error;
  }

  // push unprocessed blocks back to make them first in queue
  //
  for(int i=0;i<blockesInQueue.size();i++)
    a_blockList.push_front(blockesInQueue[i]);

  if(a_blockList.size() == 0)
    return;

  const int NBLOCKS = hrtGetMegaBlockSize()/ZBlock::GetSize();
  if(a_blockList.size()*m_currRaysPerPixel*2 <= NBLOCKS && !unprocessedTilesExists)
    SetRaysPerPixel(m_currRaysPerPixel*2);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::BlockFinished(const ZBlock& block, float* a_outDiff)
{
  // multi-jittered sampling (stratification)
  // stratification require, that we can stop only on each 4-th (2x2), 9-th (3x3), 16-th(4x4) or e.t.c steps
  //
  //if(block.counter%(AA_STRATIFICATION_X*AA_STRATIFICATION_Y) != 0)
  //return false; 

  int samplesPerPixel = block.counter; // was *2 due to odd and even staff

  if(a_outDiff!=NULL)
    *a_outDiff = block.diff;

  if(m_maxSPP < block.counter) // *2
    m_maxSPP = block.counter; // *2

  float acceptedBadPixels = sqrtf(float(CMP_RESULTS_BLOCK_SIZE));
  int minRaysPerPixel = m_params.minRaysPerPixel;

  if(m_params.qmcOneSeed)
  {
    acceptedBadPixels = 1.0f; //
    minRaysPerPixel   = max(minRaysPerPixel, 256);
  }

  bool summErrorOk = (block.diff <= acceptedBadPixels);
  bool maxErrorOk  = false;

  m_blockErrorMaxRed   = acceptedBadPixels*2.0f;
  m_blockErrorMinGreen = acceptedBadPixels;  

  return ((summErrorOk || maxErrorOk) && samplesPerPixel >= minRaysPerPixel) || (samplesPerPixel >= m_params.maxRaysPerPixel);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::ResetPathTracing()
{
  m_pathTracingState = STATE_BEGIN;
  m_pathTracingPassNumber = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::PathTracingFinished() const 
{ return m_screenBlockList.empty();}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::BeginPathTracingPass(RenderSettings a_renderState)
{
  hrtResetCounters();

  m_lastRenderState = a_renderState;

  GPU_Ray_Tracer::UpdateComplete();

  int NTimes = (width*height)/hrtGetMegaBlockSize(); 
  if(NTimes < 2) NTimes = 2;

  switch (m_pathTracingState)
  {
  case STATE_BEGIN:

    m_currPTPassNumber = 0;

    MakeScreenBlockList(&m_screenBlockList);
    SetRaysPerPixel(m_params.initialSPP);

    hrtSetFlags(HRT_USE_RANDOM_RAYS, 1);
    hrtSetFlags(HRT_COMPUTE_SHADOWS, a_renderState.GetShadow());
    hrtSetFlags(HRT_DIFFUSE_REFLECTION, a_renderState.GetIndirrectIllumination());
    hrtSetFlags(HRT_COMPUTE_IRRADIANCE_CACHE | HRT_IRRDAIANCE_CACHE_FIND_SECONDARY, 0);
    hrtSetFlags(HRT_FINAL_GARTHER, a_renderState.GetEnableFG());
    hrtSetFlags(HRT_GARTHER_CAUSTICS, a_renderState.GetEnableCG());
    hrtSetFlags(HRT_TRACE_GLASS_RECURSIVE, a_renderState.enableRecursiveTracing);
    hrtSetFlags(HRT_ENABLE_PT_CAUSTICS, a_renderState.ptCaustics);
    hrtSetFlags(HRT_ENABLE_COHERENT_PT, m_params.coherent);

    hrtSetVariableF(HRT_IC_WS_ERROR_TRESHOLD, m_icPresets.icWSErrorTreshold); //a_renderState.icWSErrorTreshold
    hrtSetVariableF(HRT_TRACE_PROCEEDINGS_TRESHOLD, a_renderState.GetTraceProceedingsTreshold());
    hrtSetVariableF(HRT_CAUSTIC_POWER_MULT, a_renderState.causticPower);

    hrtSetVariableI(HRT_DISABLE_MRAYS_COUNTERS, int(!a_renderState.GetEnableRaysCounter()));
    hrtSetVariableI(HRT_TRACE_DEPTH, a_renderState.GetTraceDepth());
    hrtSetVariableI(HRT_PHOTONS_GARTHER_BOUNCE, a_renderState.GetGartherBounce());
    hrtSetVariableI(HRT_PHOTONS_STORE_BOUNCE, a_renderState.GetStoreBounce());
    hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, a_renderState.GetDiffuseTraceDepth());

    if(a_renderState.GetEnableFG() && a_renderState.GetStoreBounce() == 0)
      hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, a_renderState.GetGartherBounce());

    hrtSetVariableI(HRT_DEBUG_OUTPUT, m_debugOutput);

    m_pipeline->SetShaderVariable("g_gamma", a_renderState.GetGamma());

    hrtSetVariableI(HRT_PT_FILTER_TYPE, m_params.filterType);
    hrtSetVariableI(HRT_VAR_ENABLE_RR, m_params.enableRR);

    m_startScreenBlockListSize = (int)m_screenBlockList.size();
    m_maxSPP = 0;

    if(m_params.qmcOneSeed)
    {
      hrtSetFlags(HRT_ENABLE_QMC_ONE_SEED, 1);
      hrtInitQMC();
    }
    else
      hrtSetFlags(HRT_ENABLE_QMC_ONE_SEED, 0);

    hrtFillXYBufferAndClearAccumBuffers();

    for(int i=0;i<NTimes;i++)
      DoMegaBlock(m_screenBlockList, a_renderState);

    m_pathTracingState = STATE_TRACING;
    break;

  case STATE_TRACING:

    m_currPTPassNumber++;

    if(m_screenBlockList.empty())
    {
      m_pathTracingState = STATE_FINISHED;
      //std::cout << "STATE_FINISHED, line " << __LINE__ << std::endl;
    }
    else
    {
      bool diffusePhotonsPass = (m_phMapPresets.diffuseRetracePass == 1) || ((m_currPTPassNumber % m_phMapPresets.diffuseRetracePass) == 0);
      bool causticPhotonsPass = (m_phMapPresets.causticRetracePass == 1) || ((m_currPTPassNumber % m_phMapPresets.causticRetracePass) == 0);

      //std::cerr << "caustic retrace path = " << m_phMapPresets.causticRetracePass << std::endl; 

      if(m_photonMapsPrepared && a_renderState.GetEnableCG() && m_phMapPresets.progressiveCausticMap && causticPhotonsPass)
        CausticPhotonPass();

      if(m_photonMapsPrepared && a_renderState.GetEnableFG() && m_phMapPresets.progressivePhotonMap && diffusePhotonsPass)  
        DiffusePhotonPass();

      for(int i=0;i<NTimes;i++)
        DoMegaBlock(m_screenBlockList, a_renderState);
      
      if(m_screenBlockList.empty())
      {
        m_avgRaysPerPixel /= float(width*height);
        m_pathTracingState = STATE_FINISHED;
        //std::cout << "STATE_FINISHED, line " << __LINE__ << std::endl;
      }
        
    }

    break;

  case STATE_FINISHED:

    if(m_maxSPP > 0)
    {
      std::cerr << "max samples per pixel = " << m_maxSPP << std::endl;
      m_maxSPP = 0;
    }

    break;
  }

}

///////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::CopyResultToGLBuffer()
{
  if(m_pathTracingState == STATE_TRACING)
    hmctCopyColorToGLBuffer(m_glRes.m_screenBuffer);
  else
    hrtEndTrace(m_glRes.m_screenBuffer, NULL);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
bool GPU_Path_Tracer::EndPathTracingPass()
{ 
  GPU_Ray_Tracer::EndDrawScene();
  
  DegudDrawActiveBlocksAndStatisticsData();

  return m_screenBlockList.empty() || forceEnd;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DumpBufferToFile(const char* a_buffName, const char* a_fileName)
{
  if(hmctDumpDataBuffer(a_buffName, a_fileName) != 0)
    RUN_TIME_ERROR("can't save color buffer, may be you need to create 'out_relight_data' folder");
}



/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DegudDrawActiveBlocksAndStatisticsData()
{
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);

  int counter=0;
  if(m_params.drawBlocks)
  {
    float size = Z_ORDER_BLOCK_SIZE;

    std::vector<float3>& resultData = m_zblocksPosTmp;

    for(BlockList::iterator p=m_screenBlockList.begin();p!=m_screenBlockList.end();++p)
    {
      float2 coord = m_zBlocksCoordByIndex[p->index];
      float  err   = p->diff;

      if(p->counter <= m_params.minRaysPerPixel)
        err = 1000.0f;

      if(p->counter != 0)
      {
        resultData[counter] = float3(coord.x, coord.y, err);
        counter++;
      }
    }

    glNamedBufferDataEXT(m_glRes.m_blocksPos, counter*sizeof(float3), &resultData[0], GL_DYNAMIC_DRAW); CHECK_GL_ERRORS;

    glUseProgram(m_display2DLines.program);  CHECK_GL_ERRORS; 

    setUniform(m_display2DLines.program, "size",      float2(size, size)); 
    setUniform(m_display2DLines.program, "useColorCoding", 1); 
    setUniform(m_display2DLines.program, "errBounds", float2(m_blockErrorMinGreen, m_blockErrorMaxRed)); 
    setUniform(m_display2DLines.program, "projectionMatrix", m_ortoMat); 
    setUniform(m_display2DLines.program, "color", float4(1,0,0,1)); 

    glBindVertexArray(m_glRes.m_vaoBlocks); CHECK_GL_ERRORS; 
    glDrawArrays(GL_POINTS, 0, counter);    CHECK_GL_ERRORS; 

    glBindVertexArray(0); CHECK_GL_ERRORS; 
    glUseProgram(0);      CHECK_GL_ERRORS; 
  }
  
  if(m_params.drawRaysStatInfo && gl_ver <= 3.1)
  {
    // legacy
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glLoadMatrixf(m_ortoMat.L);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glPushAttrib(GL_CURRENT_RASTER_POSITION);
    glColor3f(1,1,0);

    float startY = height - 20;
  
    glRasterPos2f(10, startY-160);
    glPrint("RAYS_PER_PIXEL: %d", m_currRaysPerPixel);

    glRasterPos2f(10, startY-140);
    glPrint("ACTIVE_TILES  : %d", counter);
    glPopAttrib();
  }
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::MarkVisibleSurfaces(IPhotonMap* a_photonMap)
{
  if(m_phMapPresets.disableVisibilityTracing)
  {
    hrtClearPrimitiveIndicesFromFGFlags(SURF_FRONT | SURF_BACK);
    return;
  }
  else
    hrtClearPrimitiveIndicesFromFGFlags(0); 

  RenderSettings oldSettings = m_lastRenderState;
  RenderSettings newSettings = m_lastRenderState;

  hrtPushAllVars();
  hrtPushAllFlags();
  if(a_photonMap->IsCausticMap())
    hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 0);
 
  hrtSetFlags(HRT_MARK_SURFACES_FG, 1);

  newSettings.SetEnableFG(false);
  if(!a_photonMap->IsCausticMap())
  {
    newSettings.SetDiffuseTraceDepth(1);
    newSettings.SetIndirrectIllumination(true);
  }

  int passNumber = 16;

  if(a_photonMap->IsCausticMap())
    passNumber = 4;

  for(int i=0;i<passNumber;i++)
  {
    this->BeginPathTracingPass(newSettings);
    this->EndPathTracingPass();
    
    if(i%8 == 0)
      m_displayProgress("tracing importance particles", float(i)/float(passNumber));

    if(i%4)
      glutSwapBuffers();
  }

  hrtPopAllVars();
  hrtPopAllFlags();
  m_lastRenderState = oldSettings;

  std::cerr << std::endl;
}


void GPU_Path_Tracer::PhotonTracing(IPhotonMap* a_photonMap, float a_gartherRadius)
{
  float vpTracingTime = 0;
  float photonsTraceTime = 0;
  float buildingOctreeTime = 0;

  BuildOctreeTimings octreeTimings;

  //std::cout << "TracePhotonsTest started" << std::endl;
  
  if(m_lights.size() > 0)
  {
    Timer mytimer(true);

    if(m_debugOutput)
    {
      hrtThreadSynchronize();
      vpTracingTime = mytimer.getElapsed(); mytimer.start();
      hrtThreadSynchronize();
    }

    mytimer.start();
    a_photonMap->TracePhotons();

    if(m_debugOutput)
    {
      hrtThreadSynchronize();
      photonsTraceTime = mytimer.getElapsed(); mytimer.start();
      hrtThreadSynchronize();
    }

    a_photonMap->BuildOctree(a_gartherRadius, &octreeTimings);

    if(m_debugOutput)
    {
      hrtThreadSynchronize();
      buildingOctreeTime = mytimer.getElapsed();
      hrtThreadSynchronize();
    }
  }
  
  //std::cerr << "m_lights.size() = " << m_lights.size() << std::endl;

  if(m_debugOutput)
  {
    std::cout << std::endl;
    std::cout << "TracePhotons time = " << photonsTraceTime << std::endl;
    std::cout << "buildOctree  time = " << buildingOctreeTime << std::endl;
    
    std::cout << std::endl;
    std::cout << "photon sort  time = " << octreeTimings.photonSortingTime << std::endl;
    std::cout << "append refs  time = " << octreeTimings.appendRefsTime << std::endl;
    std::cout << "refs   sort  time = " << octreeTimings.sortRefs << std::endl;
    std::cout << "append nodes time = " << octreeTimings.appendNodesTime << std::endl;
    std::cout << "nodes  sort  time = " << octreeTimings.sortNodes << std::endl;
    std::cout << "alloc/free   time = " << octreeTimings.allocFreeTime << std::endl;
    std::cout << "cpFromSymbol time = " << octreeTimings.memcpyFromSymbolTime << std::endl;
    std::cout << "other overh  time = " << octreeTimings.otherOverhead << std::endl;
    std::cout << "total        time = " << octreeTimings.photonSortingTime + octreeTimings.sortRefs + octreeTimings.appendRefsTime + \
      octreeTimings.allocFreeTime + octreeTimings.memcpyFromSymbolTime + octreeTimings.otherOverhead << std::endl;
  }
}

void GPU_Path_Tracer::PreparePhotonMaps(RenderSettings a_renderState)
{
  m_photonMapsPrepared = false;

  m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  m_pCausticPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pCausticPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  if(a_renderState.GetEnableFG())
    MarkVisibleSurfaces(m_pPhotonMap);
  else if (a_renderState.GetEnableCG())
    MarkVisibleSurfaces(m_pCausticPhotonMap);
  

  if(a_renderState.GetEnableFG() && m_phMapPresets.progressivePhotonMap)  // init diffuse photon map
  {
    m_currGartherRadius = m_lastRenderState.GetGartherRadius();
    m_photonPassNumber = 1;
    DiffusePhotonPass();
    hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true);
  }

  if(a_renderState.GetEnableCG() && m_phMapPresets.progressiveCausticMap) // init caustic photon map
  {
    m_currCausticGartherRadius = m_lastRenderState.GetGartherRadiusCaustic();
    m_photonCausticPassNumber = 1;
    CausticPhotonPass();
    hrtPhotonMapSetActiveMap("caustic", m_pCausticPhotonMap, true);
  }

  ResetPathTracing();
  m_photonMapsPrepared = true;
  m_photonCausticNextPassNumber = 1;
  m_photonCausticPassNumber2 = 1;
  m_photonDiffuseNextPassNumber = 1;
  m_photonDiffusePassNumber2 = 1;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::DiffusePhotonTracing()
{
  //std::cerr << "DiffusePhotonTracing(), HERE 0!" << std::endl;

  MarkVisibleSurfaces(m_pPhotonMap);

  //std::cerr << "DiffusePhotonTracing(), HERE 1!" << std::endl;

  hrtPushAllVars();
  hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, m_lastRenderState.GetDiffuseTraceDepth());

  //std::cerr << "DiffusePhotonTracing(), HERE 2!" << std::endl;

  m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  //std::cerr << "DiffusePhotonTracing(), HERE 3!" << std::endl;

  m_pPhotonMap->Clear();
  PhotonTracing(m_pPhotonMap, m_lastRenderState.GetGartherRadius());
  hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true);

  hrtPopAllVars();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::CausticPhotonTracing()
{
  MarkVisibleSurfaces(m_pCausticPhotonMap);

  m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
  m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

  m_pCausticPhotonMap->Clear();
  PhotonTracing(m_pCausticPhotonMap, m_lastRenderState.GetGartherRadiusCaustic());
  hrtPhotonMapSetActiveMap("caustic", m_pCausticPhotonMap, true);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// a simple but important note for ppm
// sqr(r[i+1])/sqr(r[i]) = (i+alpha)/(i+1);    
// r[i+1] = r[i]*sqrt( (i+alpha)/(i+1)); 
// alpha seems to be = 2/3; Must be in [0,1
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

void GPU_Path_Tracer::DiffusePhotonPass()
{
  if(m_debugOutput)
    std::cerr << "r[i] = " << m_currGartherRadius <<std::endl;

  if(m_photonPassNumber > 1)
  {
    float alpha = 3.0f/4.0f;
    float i = float(m_photonPassNumber);
    m_currGartherRadius = m_currGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
  }

  /*if(m_photonPassNumber-1 == 1)
  {
    float alpha = 3.0f/4.0f;
    float i = float(1);
    m_currCausticGartherRadius = m_currCausticGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
    m_photonDiffusePassNumber2 = 1;
    m_photonDiffuseNextPassNumber = 3;
  }
  else if(m_photonPassNumber-1 >= m_photonDiffuseNextPassNumber)
  { 
    float alpha = 3.0f/4.0f;
    float i = float(m_photonPassNumber);
    m_currCausticGartherRadius = m_currCausticGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
    m_photonDiffusePassNumber2++;
    m_photonDiffuseNextPassNumber = m_photonDiffuseNextPassNumber*2+1;
  }*/

  m_photonPassNumber++;

  hrtPushAllFlags();
  hrtPushAllVars();
  hrtSetFlags(HRT_DIFFUSE_PHOTON_TRACING, 1);
  hrtSetFlags(HRT_CAUSTIC_PHOTON_TRACING, 0);

  m_pPhotonMap->Clear();
  PhotonTracing(m_pPhotonMap, m_lastRenderState.GetGartherRadius());
  hrtPopAllVars();
  hrtPopAllFlags();

}

void GPU_Path_Tracer::CausticPhotonPass()
{
  //std::cerr << "caustic pass = " << m_photonCausticPassNumber-1 << std::endl;

  if(m_photonCausticPassNumber > 1)
  {
    float alpha = 3.0f/4.0f;
    float i = float(m_photonCausticPassNumber);
    m_currCausticGartherRadius = m_currCausticGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
  }

  hrtPushAllFlags();
  hrtSetFlags(HRT_DIFFUSE_PHOTON_TRACING, 0);
  hrtSetFlags(HRT_CAUSTIC_PHOTON_TRACING, 1);
  
  /*if(m_photonCausticPassNumber-1 == 1)
  {
    float alpha = 3.0f/4.0f;
    float i = float(1);
    m_currCausticGartherRadius = m_currCausticGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
    m_photonCausticPassNumber2 = 1;
    m_photonCausticNextPassNumber = 3;
  }
  else if(m_photonCausticPassNumber-1 >= m_photonCausticNextPassNumber)
  {
    float alpha = 3.0f/4.0f;
    float i = float(m_photonCausticPassNumber);
    m_currCausticGartherRadius = m_currCausticGartherRadius * sqrtf( (i+alpha)/(i+1.0f) );
    m_photonCausticPassNumber2++;
    m_photonCausticNextPassNumber = m_photonCausticNextPassNumber*2+1;
  }*/

  m_photonCausticPassNumber++;

  m_pCausticPhotonMap->Clear();
  PhotonTracing(m_pCausticPhotonMap, m_currCausticGartherRadius);

  if(m_debugOutput)
    std::cerr << "r[i] = " << m_currCausticGartherRadius <<std::endl;

  hrtPopAllFlags();
}

void GPU_Path_Tracer::TestICToPhotonmap()
{
   hrtPushAllFlags();
   hrtSetFlags(HRT_TRANSFORM_IC_TO_PHMAP, 1);
   std::cerr << "TestICToPhotonmap start" << std::endl;

   m_pPhotonMap->SetPhotonsBox(m_octreeAABB.vmin - float3(0.1,0.1,0.1), m_octreeAABB.vmax + float3(0.1,0.1,0.1));
   m_pPhotonMap->ResizeCurrPhotons( hlmIrradianceCacheGetSize() );

   hlmIrradianceCacheConvertToPhotonMap(m_pPhotonMap);

   float buildingOctreeTime = 0.0f;
   float radius = m_icAverageValidityRadius/2.0f;
   radius = radius/(m_octreeAABB.vmax.x - m_octreeAABB.vmin.x); // set in percentage(!)

   std::cerr << "avg validity radius = " << m_icAverageValidityRadius << std::endl;
 
   hrtThreadSynchronize();
   hrtFreePerRayData();

   Timer mytimer(true);

   m_pPhotonMap->BuildOctree(radius);

   hrtAllocPerRayData(hrtGetMegaBlockSize());  

   if(m_debugOutput)
   {
     hrtThreadSynchronize();
     buildingOctreeTime = mytimer.getElapsed();
   }

   std::cerr << "ICToPhotonmap: " << buildingOctreeTime << std::endl;
   hrtPhotonMapSetActiveMap("diffuse", m_pPhotonMap, true);

   std::cerr << "TestICToPhotonmap end" << std::endl;
   hrtPopAllFlags();
}


static float4 DownSampler(float4 data[8])
{
  float4 res;
  res.x = res.y = res.z = res.w = 0.f;

  for (int i = 0; i < 8; i++)
    res += data[i];

  return res / 8;
}

void GPU_Path_Tracer::DebugCall(const std::string& a_name, const std::string& a_params)
{
  Base::DebugCall(a_name, a_params);
  
  if(a_name == "TracePhotonsTest") //Shift + p
  {
    DiffusePhotonTracing(); 
  }
  else if(a_name == "ClearDiffusePhotons")
  {
    m_pPhotonMap->Clear();
  }
  else if(a_name == "TraceCausticPhotonsTest") //Shift + o
  {
    CausticPhotonTracing();
  }
  else if(a_name == "ClearCausticPhotons") 
  {
    m_pCausticPhotonMap->Clear();
  }
  else if(a_name == "icToPhMap") // Shift + k
  {
    TestICToPhotonmap();
  }
  else if(a_name == "voxelizeDebug") //Shift + v
  {

    m_voxelRadianceCacheEnabled = !m_voxelRadianceCacheEnabled;

    if(m_voxelRadianceCacheEnabled)
    {
      hrtPushAllFlags();
      hrtSetFlags(HRT_PHOTONS_STORE_MULTIPLY_COLORS, 1); // multiply photons color with the surface color when store them
      MarkVisibleSurfaces(m_pPhotonMap);

      m_pPhotonMap->SetLights(&m_lights[0], m_lights.size());
      m_pPhotonMap->SetSceneBox(m_bBox.vmin, m_bBox.vmax);

      m_pPhotonMap->TracePhotons();

      // Do not use this pointers on the CPU side, they are for CUDA kernels only!
      //
      HitPosNorm* photonsPosNorm = m_pPhotonMap->GetGPUPosNormPointer();
      ushort4*    photonsColors  = m_pPhotonMap->GetGPUColorPointer();
      int         photonsNum     = m_pPhotonMap->GetCurrPhotons();

      // first get opacity grid we already calculated earlier
      // read from 'm_voxelData', for example.
      
      Array3D<float4>& voxels = m_voxelData.GetArrayMipLevel(0);
      AABB3f voxel_bbox = m_voxelData.GetBoundingBox();
      float3 voxel_size = make_float3((voxel_bbox.vmax.x - voxel_bbox.vmin.x) / voxels.size().x,
                                      (voxel_bbox.vmax.y - voxel_bbox.vmin.y) / voxels.size().y,
                                      (voxel_bbox.vmax.z - voxel_bbox.vmin.z) / voxels.size().z);

      Array3D<float4>& radNeg = m_radianceNeg.GetArrayMipLevel(0);
      Array3D<float4>& radPos = m_radiancePos.GetArrayMipLevel(0);

      // build radiance grid
      
      //std::cout << "Enter building radiance grid" << std::endl;

      IRadianceGridBuilder* radianceGridBuilder = CreateNewRadianceGridBuilder();

      radianceGridBuilder->SetVoxelBox(m_voxelData.GetBoundingBox().vmin, 
                                       m_voxelData.GetBoundingBox().vmax,
                                       voxels.size().x);
      radianceGridBuilder->SetEnergyScale(m_pPhotonMap->EnegryScale());

      std::cout << "Start building radiance grid" << std::endl;

      //Timer gpuRadianceGridTimer;
      //gpuRadianceGridTimer.start();
      //float radianceGridStartTime = gpuRadianceGridTimer.getElapsed();

      radianceGridBuilder->BuildGrid(photonsPosNorm, photonsColors, photonsNum);

      //float radianceGridStopTime = gpuRadianceGridTimer.getElapsed();
      //std::cout << "radiance grid building time: " << (radianceGridStopTime - radianceGridStartTime) << "s" << std::endl;

      std::cout << "Copy colors to radiance grid" << std::endl;

      float3* voxelColors = radianceGridBuilder->GetColors();
      float3* radiancePos = radianceGridBuilder->GetRadiancePos();
      float3* radianceNeg = radianceGridBuilder->GetRadianceNeg();

      for (int z = 0; z < voxels.size().z; z++)
        for (int y = 0; y < voxels.size().y; y++)
          for (int x = 0; x < voxels.size().x; x++)
          {
            voxels(x,y,z).x = voxelColors[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].x;
            voxels(x,y,z).y = voxelColors[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].y;
            voxels(x,y,z).z = voxelColors[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].z;
            radNeg(x,y,z).x = radianceNeg[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].x;
            radNeg(x,y,z).y = radianceNeg[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].y;
            radNeg(x,y,z).z = radianceNeg[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].z;
            radPos(x,y,z).x = radiancePos[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].x;
            radPos(x,y,z).y = radiancePos[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].y;
            radPos(x,y,z).z = radiancePos[z * voxels.size().x*voxels.size().y + y * voxels.size().x + x].z;          
          }

      m_radiancePos.GenerateMips(DownSampler);
      m_radianceNeg.GenerateMips(DownSampler);

      Array3D<float4>& radPos1 = m_radiancePos.GetArrayMipLevel(1);
      Array3D<float4>& radPos2 = m_radiancePos.GetArrayMipLevel(2);
      Array3D<float4>& radPos3 = m_radiancePos.GetArrayMipLevel(3);

      Array3D<float4>& radNeg1 = m_radianceNeg.GetArrayMipLevel(1);
      Array3D<float4>& radNeg2 = m_radianceNeg.GetArrayMipLevel(2);
      Array3D<float4>& radNeg3 = m_radianceNeg.GetArrayMipLevel(3);

      radianceGridBuilder->LoadConstantData();
      radianceGridBuilder->BindOpacityTexture(voxels.size().x, voxels.GetPointer());
      radianceGridBuilder->BindRadianceTextures(voxels.size().x, radPos.GetPointer(), radNeg.GetPointer());
      radianceGridBuilder->BindRadianceTextureMips(radPos1.size().x, radPos1.GetPointer(), radNeg1.GetPointer(),
                                                   radPos2.size().x, radPos2.GetPointer(), radNeg2.GetPointer(),
                                                   radPos3.size().x, radPos3.GetPointer(), radNeg3.GetPointer());

      std::cout << "Cleanup after writing colors" << std::endl;

      delete[] voxelColors;
      delete[] radiancePos;
      delete[] radianceNeg;

      //ReleaseRadianceGridBuilder(radianceGridBuilder);

      // dump voxels to file

      //std::cout << "Dump voxels to voxels.txt" << std::endl;

      //std::ofstream voxel_out("voxels.txt");
      //std::ofstream voxel_out2("voxels2.txt");

      //voxel_out2 << voxels.size().x << ' ' << voxels.size().y << ' ' << voxels.size().z << std::endl << std::endl;

      //for (int z = 0; z < voxels.size().z; z++) {
      //  for (int y = 0; y < voxels.size().y; y++) {
      //    for (int x = 0; x < voxels.size().x; x++) {
      //      if (voxels(x,y,z).w > 1e-3) {
      //        AABB3f curVoxel_bbox;
      //        curVoxel_bbox.vmin = voxel_bbox.vmin + make_float3(x, y, z) * voxel_size;
      //        curVoxel_bbox.vmax = curVoxel_bbox.vmin + voxel_size;
      //        voxel_out << curVoxel_bbox.vmin.x << ' '
      //                  << curVoxel_bbox.vmin.y << ' '
      //                  << curVoxel_bbox.vmin.z << ' '
      //                  << curVoxel_bbox.vmax.x << ' '
      //                  << curVoxel_bbox.vmax.y << ' '
      //                  << curVoxel_bbox.vmax.z << ' '
      //                  << voxels(x,y,z).x << ' '
      //                  << voxels(x,y,z).y << ' '
      //                  << voxels(x,y,z).z << std::endl;
      //      }

      //      voxel_out2 << '(' << voxels(x,y,z).x << ',' << voxels(x,y,z).y << ',' << voxels(x,y,z).z << ',' << voxels(x,y,z).w << ") ";
          //}
      //    voxel_out2 << std::endl;
        //}
      //  voxel_out2 << std::endl;
      //}

      //voxel_out.close();
      //voxel_out2.close();

      //std::cout << "Dump finished" << std::endl;
      // now enable it in tracer

      hrtRadianceCacheSetGlobalAlpha(0.1f); // threshold in world space
      hrtPopAllFlags();
      hrtSetFlags(HRT_RC_VOXELS, 1);
    }
    else
    {

      hrtSetFlags(HRT_RC_VOXELS, 0); 
    }

  }


}

void GPU_Path_Tracer::SetPhotonMapPresets(const PhotonMapPresets& a_presets)
{
  m_phMapPresets = a_presets;

  if(m_pPhotonMap->GetMaxPhotons() != m_phMapPresets.maxDiffusePhotons)
  {
    hlmDeletePhotonMap(m_pPhotonMap);
    m_pPhotonMap = hlmCreatePhotonMap(m_phMapPresets.maxDiffusePhotons, false);
  }

  if(m_pCausticPhotonMap->GetMaxPhotons() != m_phMapPresets.maxCausticPhotons)
  {
    hlmDeletePhotonMap(m_pCausticPhotonMap);
    m_pCausticPhotonMap = hlmCreatePhotonMap(m_phMapPresets.maxCausticPhotons, true);
  }
}
