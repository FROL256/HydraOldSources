#include "IGraphicsEngine.h"

IGraphicsEngine::IGraphicsEngine(int w,int h){}
IGraphicsEngine::~IGraphicsEngine(){}

IGraphicsEngine::RenderSettings::RenderSettings()
{
  m_traceDepth  = 4;
  m_diffTraceDepth = 2;
  m_AA  = 0;
  m_traceProoceedThreshold = 1e-8f;

  m_shadows = 1;
  m_enableRaysCount = true;
  m_fgBounce = 1;
  m_enableFinalGarthering = false;
  ptCaustics = false;
}

IGraphicsEngine::RenderSettings::~RenderSettings(){}

void IGraphicsEngine::RenderSettings::SetDiffuseTraceDepth(int d) {m_diffTraceDepth = d;}
int  IGraphicsEngine::RenderSettings::GetDiffuseTraceDepth() const {return m_diffTraceDepth;}

bool IGraphicsEngine::RenderSettings::GetEnableRaysCounter() const {return m_enableRaysCount;}
void IGraphicsEngine::RenderSettings::SetEnableRaysCounter(bool a_val) {m_enableRaysCount = a_val;}

void IGraphicsEngine::RenderSettings::SetTraceDepth(int a_depth)
{
  if(a_depth > 20)
    throw std::runtime_error("RendertState: too big trace depth, 20 max");
  m_traceDepth = a_depth;
}

int  IGraphicsEngine::RenderSettings::GetTraceDepth() const  { return m_traceDepth; }
void IGraphicsEngine::RenderSettings::SetShadow(bool a_shadow) { m_shadows = a_shadow; }

bool IGraphicsEngine::RenderSettings::GetShadow() const {return (bool)m_shadows;}

void IGraphicsEngine::RenderSettings::SetAA(int a_AA)
{
  if(a_AA > 127)
    throw std::runtime_error("RendertState: too big AA multi sample value, 256 rays per pixel max");

  m_AA = a_AA;
}

int  IGraphicsEngine::RenderSettings::GetAA() const { return m_AA; }

void  IGraphicsEngine::RenderSettings::SetTraceProceedingsTreshold(float a_treshold)
{
  if(a_treshold > 0.1f || a_treshold < 1e-30f)
    RUN_TIME_ERROR("IGraphicsEngine::SetTraceProceedingsTreshold : incorrect 'TraceProceedings' treshold value, restricted by interval [1e-5,0.1]");

  m_traceProoceedThreshold = a_treshold;
}

float IGraphicsEngine::RenderSettings::GetTraceProceedingsTreshold() const { return m_traceProoceedThreshold; }



void IGraphicsEngine::RenderSettings::SetIndirrectIllumination(bool a_val)
{ m_giEnabled = a_val; }

bool IGraphicsEngine::RenderSettings::GetIndirrectIllumination() const 
 {return m_giEnabled; }



bool IGraphicsEngine::RenderSettings::GetEnableFG() const  { return m_enableFinalGarthering; }
void IGraphicsEngine::RenderSettings::SetEnableFG(bool a_value) { m_enableFinalGarthering = a_value; }

bool IGraphicsEngine::RenderSettings::GetEnableCG() const  { return m_enableCausticGarthering; }
void IGraphicsEngine::RenderSettings::SetEnableCG(bool a_value) { m_enableCausticGarthering = a_value; }

void  IGraphicsEngine::RenderSettings::SetGartherRadius(float a_val) { m_gartherRadius = a_val;}
float IGraphicsEngine::RenderSettings::GetGartherRadius() const { return m_gartherRadius; }

void  IGraphicsEngine::RenderSettings::SetGartherRadiusCaustic(float a_val) { m_gartherRadiusCaustic = a_val;}
float IGraphicsEngine::RenderSettings::GetGartherRadiusCaustic() const { return m_gartherRadiusCaustic; }

int IGraphicsEngine::RenderSettings::GetGartherBounce() const { return m_fgBounce; }
void IGraphicsEngine::RenderSettings::SetGartherBounce(int a_val) { m_fgBounce = a_val; }

int   IGraphicsEngine::RenderSettings::GetStoreBounce() const { return m_storeBounce; }
void  IGraphicsEngine::RenderSettings::SetStoreBounce(int a_val) { m_storeBounce = a_val; }

void  IGraphicsEngine::RenderSettings::SetGamma(float a_gamma) { m_gamma = a_gamma;}
float IGraphicsEngine::RenderSettings::GetGamma() const { return m_gamma; }

