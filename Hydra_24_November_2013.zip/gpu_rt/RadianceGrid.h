#pragma once

struct IRadianceGridBuilder
{
  IRadianceGridBuilder() {}
  virtual ~IRadianceGridBuilder() {}

  virtual void BuildGrid(HitPosNorm* posNorms, ushort4* colors, int size) = 0;
  virtual void SetVoxelBox(float3 boxMin, float3 boxMax, int resolution) = 0;
  virtual void SetEnergyScale(float energyScale) = 0;

  virtual float3* GetColors() = 0;
  virtual float3* GetRadiancePos() = 0;
  virtual float3* GetRadianceNeg() = 0;

  virtual void LoadConstantData() = 0;
  virtual void BindOpacityTexture(int a_volumeSize, float4* a_data) = 0;
  virtual void BindRadianceTextures(int volumeSize, float4* posData, float4* negData) = 0;
  virtual void BindRadianceTextureMips(int volumeSize1, float4* posData1, float4* negData1,
                                       int volumeSize2, float4* posData2, float4* negData2,
                                       int volumeSize3, float4* posData3, float4* negData3) = 0;
};

IRadianceGridBuilder* CreateNewRadianceGridBuilder();
void ReleaseRadianceGridBuilder(IRadianceGridBuilder*& p_gridbuilder);


//extern "C" void LoadDataAndBindTextures(void* a_self, int a_volumeSize, float4* a_data);