#pragma once

struct BuildOctreeTimings
{
  BuildOctreeTimings() {clear();}
  void clear() {photonSortingTime = appendRefsTime = sortRefs = allocFreeTime = memcpyFromSymbolTime = otherOverhead = 0.0f;
                appendNodesTime = sortNodes = 0.0f;}

  float photonSortingTime;
  float appendRefsTime;
  float appendNodesTime;
  float sortRefs;
  float sortNodes;
  float allocFreeTime;
  float memcpyFromSymbolTime;
  float otherOverhead;
  Timer timer;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// a simple but important note for ppm
// sqr(r[i+1])/sqr(r[i]) = (i+alpha)/(i+1);    
// r[i+1] = sqrt( r[i]*r[i]*(i+alpha)/(i+1)); 
// alpha seems to be = 2/3; Must be in [0,1
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

class IPhotonMap
{
public:
  IPhotonMap();
  IPhotonMap(int a_maxPhotons);
  virtual ~IPhotonMap();

  virtual void Clear() = 0;
  virtual void TracePhotons() = 0;
  virtual void BuildOctree(float a_gartherRadius, BuildOctreeTimings* a_timeData = NULL)  = 0; // construct multiple reference octree
  virtual void BindTextures() = 0;                      // bind all necessary data to texrefs 
 
  virtual bool  Full() const = 0;
  virtual float EnegryScale() const = 0;
  virtual bool  IsCausticMap() const = 0;

  virtual void  SetMaxPhotons(int a_maxPhotons) = 0;
  virtual int   GetMaxPhotons()  const = 0;
  virtual int   GetCurrPhotons() const = 0;

  virtual void  SetSceneBox(const float3& a_boxMin, const float3& a_boxMax) = 0;
  virtual void  GetPhotonsBox(float3* a_boxMin, float3* a_boxMax) const = 0;

  virtual void  SetGartherRadius(float a_radius) = 0;
  virtual float GetGartherRadius() const = 0;

  virtual void  GetOctreeSize(float* pMaxIndex, int* pLeafsArraySize) {} // this method is for internal using only

  virtual void  SetLights(const RAYTR::Light* a_lights, int a_numLights) = 0;

  virtual void  GetPhotonsPosColorToGLBuffers(GLuint posBuffId, GLuint colBuffId);
  virtual void  DebugSaveToFile(const char* posName, const char* posNormName, const char* colorNormName);

  // normally you should not use these functions, but for some reasons they are needed 
  //
  virtual void SetPhotonsBox(const float3& a_boxMin, const float3& a_boxMax) = 0;
  virtual void ResizeCurrPhotons(int a_size) = 0;
  
  virtual HitPosNorm* GetGPUPosNormPointer() = 0;
  virtual ushort4*    GetGPUColorPointer()   = 0;

protected:

  IPhotonMap(const IPhotonMap& rhs) {}
  IPhotonMap& operator=(const IPhotonMap& ths) {return *this;}

};

IPhotonMap* hlmCreatePhotonMap(int a_maxPhotons, bool a_caustic = false);
void hlmDeletePhotonMap(IPhotonMap* a_pPhotonMap);



#ifdef __CUDACC__

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#include "float4.cuh"

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

class ILight;

class PhotonMap : public IPhotonMap
{
public:
  PhotonMap(int a_maxPhotons, bool a_caustic);
  ~PhotonMap();

  void Clear();
  void TracePhotons();
  void BuildOctree(float a_gartherRadius, BuildOctreeTimings* a_timeData = NULL);
  void BindTextures();
  
  bool  Full() const;
  float EnegryScale() const;

  bool  IsCausticMap() const;

  void  SetMaxPhotons(int a_maxPhotons);
  int   GetMaxPhotons()  const;
  int   GetCurrPhotons() const;

  void  SetSceneBox(const float3& a_boxMin, const float3& a_boxMax);
  void  GetPhotonsBox(float3* a_boxMin, float3* a_boxMax) const;

  void  SetGartherRadius(float a_radius);
  float GetGartherRadius() const;

  void  SetLights(const RAYTR::Light* a_lights, int a_numLights);

  void  GetOctreeSize(float* pMaxIndex, int* pLeafsArraySize); 

  void  GetPhotonsPosColorToGLBuffers(GLuint posBuffId, GLuint colBuffId);
  void  DebugSaveToFile(const char* posName, const char* posNormName, const char* colorNormName);

  void SetPhotonsBox(const float3& a_boxMin, const float3& a_boxMax);
  void ResizeCurrPhotons(int a_size);

  HitPosNorm* GetGPUPosNormPointer();
  ushort4*    GetGPUColorPointer();
  int         GetCurPhotonsNum();

protected:

  PhotonMap(const PhotonMap& rhs) {}
  PhotonMap& operator=(const PhotonMap& ths) {return *this;}

  int  GetCurrPhotonsOnGPU();
  void ClearPhotonsOnGPU();
  void DecompressPhotonsNorm( thrust::device_vector<HitPosNorm>& a_inData, thrust::device_vector<ushort4>& a_outData);

  thrust::device_vector<HitPosNorm> m_photonsPosNorm;
  thrust::device_vector<ushort4>    m_photonsColor;
  thrust::device_vector<ushort4>    m_photonsNormDecompressed;

  int m_maxPhotons;
  int m_currPhotons;
  int m_emittedPhotons;
  bool m_causticMap;

  thrust::device_vector<uint2> m_octreeNodes;
  thrust::device_vector<uint>  m_octreeOffsets;
  thrust::device_vector<uint>  m_octreeZIndex;

  std::vector<ILight*> m_lights;

  void BeforePhotonsTrace();
  void AfterPhotonsTrace();

  float3 m_sceneBoxMin, m_sceneBoxMax;
  float3 m_photonsBoxMin, m_photonsBoxMax;
  float  m_gartherRadius;
  int    m_MAX_INDEX;


  // for debug needs only
  //
  GLuint m_glPosBuff;
  GLuint m_glColBuff;
  
  union
  {
    struct
    {
      struct cudaGraphicsResource* m_glPosRes;
      struct cudaGraphicsResource* m_glColRes;
    };

    struct cudaGraphicsResource* m_glResources[2];
  };

};

void MROctree_Last3Steps(thrust::device_ptr<uint> a_keysBegin, int a_keysSize, thrust::device_ptr<uint> a_photonOffsetsBegin,
                         thrust::device_vector<uint2>& octreeNodes, thrust::device_vector<uint>& zindex, BuildOctreeTimings* a_timeData, int a_phNum);


#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif

class ILight
{
public:
  ILight(){}
  virtual ~ILight() {}

  virtual void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size) = 0;
  
  virtual float GetIntensity() const = 0;
  virtual float GetEnergyScale() const = 0;

  virtual void  SetSceneBox(float3 a_boxMin, float3 a_boxMax);

  virtual std::string LightTypeName();

protected:
  ILight(const ILight& rhs) {}
  ILight& operator=(const ILight& rhs) { return *this; }
};

class AreaLight : public ILight
{
public:
  AreaLight();
  AreaLight(const RAYTR::Light& a_lightPOD);

  void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size);
  float GetIntensity() const;
  float GetEnergyScale() const;

  std::string LightTypeName();

protected:

  float3 pos;
  float3 norm;
  float2 size;
  float3 m_intensity;

  union
  {
    float mRot[3][3];
    float mRotL[9];
  };

};

class DirectionalLight : public ILight
{
public:
  DirectionalLight();
  DirectionalLight(const RAYTR::Light& a_lightPOD);

  void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size);
  float GetIntensity() const;
  float GetEnergyScale() const;
  void  SetSceneBox(float3 a_boxMin, float3 a_boxMax);

  std::string LightTypeName();

protected:

  float3 norm;
  float3 m_intensity;

  float3 m_boxMin, m_boxMinLS;
  float3 m_boxMax, m_boxMaxLS;

  float4x4 mViewTransform, mInvViewTransform;

};


class SpotLight : public ILight
{
public:
  SpotLight();
  SpotLight(const RAYTR::Light& a_lightPOD);

  void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size);
  float GetIntensity() const;
  float GetEnergyScale() const;

  std::string LightTypeName();

protected:

  float3 norm;
  float3 pos;
  float3 m_intensity;

  float faloffCos;
  float faloffPower;

};


class SphereLight : public ILight
{
public:
  SphereLight();
  SphereLight(const RAYTR::Light& a_lightPOD);

  void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size);
  float GetIntensity() const;
  float GetEnergyScale() const;

  std::string LightTypeName();

protected:

  float3 pos;
  float  radius;
  float3 m_intensity;


};

class PointLight : public ILight
{
public:
  PointLight();
  PointLight(const RAYTR::Light& a_lightPOD);

  void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size);
  float GetIntensity() const;
  float GetEnergyScale() const;

  std::string LightTypeName();

protected:

  float3 pos;
  float3 m_intensity;

};


class MeshLight : public ILight
{
public:
  MeshLight();
  MeshLight(const RAYTR::Light& a_lightPOD, const thrust::device_vector<float4>& a_triPos, const thrust::device_vector<float2>& a_triProb);

  void  EmitPhotons(float4* rpos, float4* rdir, ushort4* colors, int a_size);
  float GetIntensity() const;
  float GetEnergyScale() const;

  std::string LightTypeName();

protected:

  float3 pos;
  float3 m_intensity;

  thrust::device_vector<float4> m_triPos;
  thrust::device_vector<float2> m_triProb;
};


ILight* CreateLight(const RAYTR::Light& a_lightPOD);


#endif

