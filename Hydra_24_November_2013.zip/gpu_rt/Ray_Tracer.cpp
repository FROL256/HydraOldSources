// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include "Ray_Tracer.h"

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::Ray_Tracer(int w, int h): Common_Graphics_Engine(w,h)
{
  //m_LebedevBRDFs = new LebedevMaterial[MAX_LEBEDEV_BRDFS];
  m_numLebedevBRDFs = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::~Ray_Tracer()
{
  //delete m_LebedevBRDFs;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::RT_Core::SetMatrix(const MGML::Matrix4x4f &m)
{ 
	mRaysTransfrom = m;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
int Ray_Tracer::AddLebedevMaterial(const LebedevMaterial& a_mat)
{
  if (m_numLebedevBRDFs + 1 >= MAX_LEBEDEV_BRDFS) 
    RUN_TIME_ERROR("Too many Andrey's Lebedev materials");

  m_LebedevBRDFs[m_numLebedevBRDFs] = a_mat;
  m_numLebedevBRDFs++;
  return m_numLebedevBRDFs-1;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::AddLightsAsGeometry()
{
  TransformDeprecatedMaterialsToHydraMarerials(m_materials, &m_hydraMaterials);

  int oldMaterialSize = int(m_hydraMaterials.size());

  //std::cerr << "m_lights[0].surfaceArea = " << m_lights[0].surfaceArea << std::endl;
  //std::cerr << "m_lights[0].emittance   = " << m_lights[0].emittance   << std::endl;


  for(int lightIndex=0; lightIndex < m_lights.size(); lightIndex++)
  {
    Light* pLight = &m_lights[lightIndex];

    if( pLight->GetLightType() == Light::LIGHT_TYPE_POINT || 
        pLight->GetLightType() == Light::LIGHT_TYPE_SPOT  || 
        pLight->GetLightType() == Light::LIGHT_TYPE_DIRECTIONAL ||
        pLight->GetLightType() == Light::LIGHT_TYPE_SKY ||
        pLight->GetLightType() == Light::LIGHT_TYPE_MESH ||
       !(pLight->flags & Light::LIGHT_AS_GEOMETRY))
      continue;

    //std::cerr << "light rotation matrix: " << std::endl;
    //for(int i=0;i<3;i++)
    //{
    //  for(int j=0;j<3;j++)
    //   std::cerr << pLight->M[i][j] << " ";
    //  std::cerr << std::endl;
    //}
    std::cerr << std::endl;

    RAYTR::HydraMaterial material;
    material.ambient.color = pLight->color*pLight->emittance;
    material.flags |= HydraMaterial::THIS_IS_LIGHT;
    material.ambient.light_id = lightIndex;

    std::cerr << "lightIndex = " << lightIndex << std::endl;
    std::cerr << "pLight->emittance = " << pLight->emittance << std::endl;
    std::cerr << "pLight->surfaceArea = " << pLight->surfaceArea << std::endl;

    int addedMaterialId = this->AddMaterial(material);

    // now add geometry of light
    
    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA)
    {
      // quad triangles
      const int numVert = 4;
      const int numIndices = 6;
      Vertex4f  vert[numVert];
      unsigned int indices[numIndices];

      // triangles
      vec2f size = pLight->GetAreaLightSize();
      vert[0].pos.set(-size.x, 0, -size.y, 1); vert[0].norm = to_float4(pLight->GetNormal(),1);
      vert[1].pos.set(-size.x, 0, size.y, 1);  vert[1].norm = to_float4(pLight->GetNormal(),1);
      vert[2].pos.set(size.x, 0, size.y, 1);   vert[2].norm = to_float4(pLight->GetNormal(),1);
      vert[3].pos.set(size.x, 0, -size.y, 1);  vert[3].norm = to_float4(pLight->GetNormal(),1);

      Matrix4x4f mTransform, mRotation, mTranslate;
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          mRotation.M[i][j] = pLight->GetMatrixElem(i,j);
      mTranslate.SetTranslate(pLight->pos);
      mTransform = mTranslate*mRotation;

      for(int i=0;i<4;i++)
      {
        vert[i].pos = mTransform*vert[i].pos;
        vert[i].material_id = addedMaterialId;
      }

      indices[0]=0;indices[1]=1;indices[2]=2;
      indices[3]=2;indices[4]=3;indices[5]=0;

      this->AddTriangles(vert,numVert,indices,numIndices);

      /*float sizeX = length(vert[1].pos - vert[0].pos); 
      float sizeY = length(vert[1].pos - vert[2].pos);

      pLight->surfaceArea = sizeX*sizeY; // pLight->m_size.x*pLight->m_size.y*4*0.01;
      pLight->emittance   = pLight->intensity/pLight->surfaceArea;

      pLight->kc = 0.0f;
      pLight->kl = 0.0f;
      pLight->kq = 1.0f;

      std::cerr << "sizeX =  " << sizeX << std::endl;
      std::cerr << "sizeY =  " << sizeY << std::endl;
      std::cerr << "emittance   = " << pLight->emittance << std::endl;
      std::cerr << "surfaceArea = " << pLight->surfaceArea << std::endl;
      std::cerr << "intensity   = " << pLight->intensity << std::endl;

      RAYTR::HydraMaterial mat = GetHydraMaterial(addedMaterialId);
      material.ambient.color   = pLight->color*pLight->emittance;
      SetHydraMaterial(mat, addedMaterialId);
      */

    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPHERICAL)
    {      
      Sphere4f sph;
      sph = Sphere4f(vec4f(pLight->pos.x, pLight->pos.y, pLight->pos.z,1), pLight->GetSphericalLightRadius());
      sph.material_id = addedMaterialId;
      int id = this->AddSpheres(&sph,1);
      pLight->SetPrimitiveId(id);
    }
    else
      RUN_TIME_ERROR("AddLightsAsGeometry: unknown light type");
  }

  AddLightsFromEmissiveMaterials(oldMaterialSize);

  m_lightsWasAddedAsGeometry = true;
}

////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::AddLightsFromEmissiveMaterials(int a_oldMaterialSize)
{
  // add lights from emissive materials
  //
  bool emissiveLights = false;
  for(int i=0;i<a_oldMaterialSize; i++)
  {
    if(m_hydraMaterials[i].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT)
    {
      emissiveLights = true;
      break;
    }
  }

  if(!emissiveLights)
    return;

  m_lightMeshIdListByMatId.clear();

  // emissive triangle meshes
  //
  for(int i=0;i<m_triangleMaterialId.size();i++)
  {
    int matId = m_triangleMaterialId[i];
    if(matId >= a_oldMaterialSize) // these materials was added from existing lights, so we don't have to add their geometry twice
      continue;

    if(m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT)
    {

      /*
      int triStart = i;
      int triEnd   = i;

      do 
      {
        triEnd++;
        int matId2 = m_triangleMaterialId[triEnd];

        if(matId2 >= a_oldMaterialSize || !(m_hydraMaterials[matId2].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT))
          break;

      } while(triEnd < m_triangleMaterialId.size() - 1);

      triEnd++;

      i = triEnd;
      */
      if(m_lightMeshIdListByMatId.find(matId) != m_lightMeshIdListByMatId.end())
      {
        continue;
      }
      else  // remember all triangles for each emissive material
      {
        m_lightMeshIdListByMatId[matId] = std::vector<int>();
        std::vector<int>& triList = m_lightMeshIdListByMatId[matId];
        triList.reserve(1000);

        for(size_t j=0;j<m_triangleMaterialId.size(); j++)
        {
          if(m_triangleMaterialId[j] == matId)
            triList.push_back(j);
        }
        int a = 2;
      }


      // add light mesh (triStart, triEnd)
      //
      RAYTR::Light light;

      light.SetLighType(Light::LIGHT_TYPE_MESH);
      light.intensity   = m_hydraMaterials[matId].ambient.light_multiplyer;
      light.emittance   = m_hydraMaterials[matId].ambient.light_multiplyer;
      light.color       = m_hydraMaterials[matId].ambient.color;
      light.pos         = float3(0,0,0);
      light.m_norm      = float3(0,-1,0);
      light.kc          = 0.01;
      light.kl          = 0;
      light.kq          = 1.0;
      light.matId       = matId;

      if(m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::EMISSION_DISABLE_FOR_PHOTONMAP)
        light.flags |= RAYTR::Light::LIGHT_DISABLE_FOR_PHOTONMAP;

      m_hydraMaterials[matId].ambient.light_id = this->AddLight(light);
      m_hydraMaterials[matId].flags |= HydraMaterial::MATERIAL_LIGHT_MESH;

      const RAYTR::Light& lightAdded = this->GetLight(m_hydraMaterials[matId].ambient.light_id);
      if(lightAdded.IsSampledDirectly())
        m_hydraMaterials[matId].flags |= HydraMaterial::MATERIAL_LIGHT_MESH_SKIP_DIFFUSE;

    }
  }

  // emissive spheres
  //
  for(int i=0;i<m_spheres.size();i++)
  {
    int matId = m_spheres[i].material_id;
    if(matId >= a_oldMaterialSize) // these materials was added from existing lights, so we don't have to add their geometry twice
      continue;

    if(m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT) // add light sphere
    {
      RAYTR::Light light;

      float radius = m_spheres[i].r;

      light.SetLighType(Light::LIGHT_TYPE_SPHERICAL);
      light.intensity = m_hydraMaterials[matId].ambient.light_multiplyer; //10.0f/(4.0f*MGML_MATH::PI*radius*radius); 
      light.color     = m_hydraMaterials[matId].ambient.color;
      light.pos       = to_float3(m_spheres[i].pos);
      light.m_norm    = float3(0,-1,0);
      light.kc        = 1.0; // http://imdoingitwrong.wordpress.com/2011/01/31/light-attenuation/
      light.kl        = 0.0f; // 2.0f/radius;
      light.kq        = 1.0;  ///(4.0f*MGML_MATH::PI);  //1.0/(radius*radius);
      light.SetSphericalLightRadius(radius);

      this->AddLight(light);
    }

  }




}
