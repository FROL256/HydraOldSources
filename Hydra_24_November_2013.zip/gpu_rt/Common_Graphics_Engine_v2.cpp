// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
//
#include "Common_Graphics_Engine.h"
#include "Fonts.h"

//#include "../bvh_builder/IKdTreeBuilder.h"
#include "../bvh_builder/KdTreeBuilderRef_vfrolov.h"
#include "../bvh_builder/BVHBuilderRef_vfrolov.h"

#include "RadianceCache.h"

#include <stdio.h>

using namespace MGML_MATH;

// RTE API v 2.0 // 


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::ReserveMemoryFor(int primTypes, int a_maxPrims) throw (std::runtime_error)
{
  if (primTypes & INPUT_PRIMITIVE_TRIANGLES)
  {
    m_vertPos.reserve(a_maxPrims*3);
    m_vertNorm.reserve(a_maxPrims*3);
    m_vertTexCoord.reserve(a_maxPrims*3);
    m_index.reserve(3*a_maxPrims);
    m_triangleMaterialId.reserve(a_maxPrims);
  }

  if(primTypes & INPUT_PRIMITIVE_SPHERES)
    m_spheres.reserve(a_maxPrims);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::DeclareVertexInputLayout(int layout, int numUserDefinedAttributes) throw (std::runtime_error)
{
  m_currInputLayout = layout;
  m_inputDataSet.Clear();
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexPositionPointer(const float* v, int bytePitch) throw (std::runtime_error)
{
  m_inputDataSet.m_vPosCustom = v;
  m_inputDataSet.m_vPosStride = bytePitch;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexNormalPointer(const float* v, int bytePitch) throw (std::runtime_error)
{
  m_inputDataSet.m_vNormCustom = v;
  m_inputDataSet.m_vNormStride = bytePitch;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexUVPointer(const float* v, int bytePitch) throw (std::runtime_error)
{
  m_inputDataSet.m_vTexCoordCustom = v;
  m_inputDataSet.m_vTexCoordStride = bytePitch;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexTangentPointer(const float* v, int bytePitch) throw (std::runtime_error)
{
  m_inputDataSet.m_vTanCustom = v;
  m_inputDataSet.m_vTanStride = bytePitch;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexMaterialIdPointer(const int* v, int bytePitch) throw (std::runtime_error)
{
  m_inputDataSet.m_vMatIdCustom = v;
  m_inputDataSet.m_vMatIdStride = bytePitch;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexAttributePointer(const char* attrName, const double* v, int bytePitch) throw (std::runtime_error)
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexAttributePointer(const char* attrName, const float* v, int bytePitch) throw (std::runtime_error)
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexAttributePointer(const char* attrName, const int* v, int bytePitch) throw (std::runtime_error)
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexAttributePointer(const char* attrName, const short* v, int bytePitch) throw (std::runtime_error)
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::SetVertexAttributePointer(const char* attrName, const char* v, int bytePitch) throw (std::runtime_error)
{

}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::AddVertexPositionsFromInputDataSet(int a_maxVertexCount)
{
  if (m_currInputLayout & VERTEX_POSITION)
  {
    const char* sourcePos = (const char*)m_inputDataSet.m_vPosCustom;

    int oldSize = m_vertPos.size();
    m_vertPos.resize(oldSize+a_maxVertexCount);

    for(int i=0;i<a_maxVertexCount;i++)
    {
      const float* p = (const float*)(sourcePos);
      float4 pos(p[0], p[1], p[2], 1);
      m_vertPos[oldSize+i] = m_addTrianglesLastMat*pos;
      sourcePos += m_inputDataSet.m_vPosStride;
    }
  }

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::AddVertexNormalsFromInputDataSet(int a_maxVertexCount)
{
  if (m_currInputLayout & VERTEX_NORMAL)
  {
    const char* sourceNorm = (const char*)m_inputDataSet.m_vNormCustom;

    int oldSize = m_vertNorm.size();
    m_vertNorm.resize(oldSize+a_maxVertexCount);

    for(int i=0;i<a_maxVertexCount;i++)
    {
      const float* p = (const float*)(sourceNorm);
      float4 norm(p[0], p[1], p[2], 0);
      m_vertNorm[oldSize + i] = matrix4x4f_mult_normal4f(m_addTrianglesLastMat, norm);
      sourceNorm += m_inputDataSet.m_vNormStride;
    }

  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::AddVertexTexCoordsFromInputDataSet(int a_maxVertexCount)
{
  if (m_currInputLayout & VERTEX_UV)
  {
    const char* source = (const char*)m_inputDataSet.m_vTexCoordCustom;

    int oldSize = m_vertTexCoord.size();
    m_vertTexCoord.resize(oldSize+a_maxVertexCount);
    
    for(int i=0;i<a_maxVertexCount;i++)
    {
      const float* p = (const float*)(source);
      float2 pos(p[0], p[1]);
      m_vertTexCoord[oldSize+i] = pos;
      source += m_inputDataSet.m_vTexCoordStride;
    }
  }
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::ExtractVertexMatIndicesFromInputDataSet(int a_maxVertexCount, std::vector<int>& vertMaterialIds)
{
  if (m_currInputLayout & VERTEX_MATERIAL_ID)
  {
    const char* source = (const char*)m_inputDataSet.m_vMatIdCustom;

    int oldSize = vertMaterialIds.size();
    vertMaterialIds.resize(oldSize+a_maxVertexCount);

    for(int i=0;i<a_maxVertexCount;i++)
    {
      const int* p = (const int*)(source);
      vertMaterialIds[oldSize+i] = *p;
      source += m_inputDataSet.m_vMatIdStride;
    }
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount, int a_flags)
{
  if (!(m_currInputLayout & VERTEX_POSITION))
    RUN_TIME_ERROR("AddTriangles: input layout must have at least VERTEX_POSITION");

  int a_matIdNum = a_indicesNum/3;
  if(a_matIdNum*3!=a_indicesNum)
    RUN_TIME_ERROR("AddTriangles(mat id per vertex): a_indicesNum%3 not equals to 0");

  //
  //
  m_addTrianglesLastMat = a_mat;

  int oldSize = m_index.size();
  m_index.resize(oldSize + a_indicesNum);

  for(int i=0;i<a_indicesNum;i++)
  {
    unsigned int index = a_indices[i];
    m_index[oldSize + i] = index + m_vertPos.size();
  } 

  std::vector<int> vertMaterialIds;
  ExtractVertexMatIndicesFromInputDataSet(a_maxVertexCount, vertMaterialIds);

  int oldSize2 = m_triangleMaterialId.size();
  m_triangleMaterialId.resize(oldSize2 + a_matIdNum);

  for(int i=0;i<a_matIdNum;i++)
  {
    int vertId = a_indices[3*i+0];
    m_triangleMaterialId[oldSize2 + i] = vertMaterialIds[vertId];
  }

  AddVertexNormalsFromInputDataSet(a_maxVertexCount); 
  AddVertexTexCoordsFromInputDataSet(a_maxVertexCount);
  AddVertexPositionsFromInputDataSet(a_maxVertexCount);

  return oldSize;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
int  Common_Graphics_Engine::AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount,
                                          const int* a_materialIndices, int a_matIdNum, int a_flags)
{
  m_addTrianglesLastMat = a_mat;

  if (!(m_currInputLayout & VERTEX_POSITION))
    RUN_TIME_ERROR("AddTriangles: input layout must have at least VERTEX_POSITION");

  int oldSize = m_index.size();
  m_index.resize(oldSize + a_indicesNum);

  for(int i=0;i<a_indicesNum;i++)
  {
    unsigned int index = a_indices[i];
    m_index[oldSize + i] = index + m_vertPos.size();
  } 

  // add per triangle mat indices
  //
  int oldSize2 = m_triangleMaterialId.size();
  m_triangleMaterialId.resize(oldSize2 + a_matIdNum);

  if(a_matIdNum*3!=a_indicesNum)
    RUN_TIME_ERROR("AddTriangles(mat id per triangle): a_matIdNum*3 not equal to a_indicesNum");
 
  for(int i=0;i<a_matIdNum;i++)
  {
    int index = a_materialIndices[i];
    m_triangleMaterialId[oldSize2 + i] = index;
  } 

  //int oldSize3 = m_vertMaterialId.size();
  //m_vertMaterialId.resize(oldSize3 + a_matIdNum*3);

  // for enamble to mix 2 different functions
  //
  //for(int i=0;i<a_matIdNum;i++)
  //{
  //  int vertIndex = 
  //  m_vertMaterialId[vertIndex+0] = a_materialIndices[i];
  //  m_vertMaterialId[vertIndex+1] = a_materialIndices[i];
  //  m_vertMaterialId[vertIndex+2] = a_materialIndices[i];
  //}


  // add other parameters
  //
  AddVertexNormalsFromInputDataSet(a_maxVertexCount); 
  AddVertexTexCoordsFromInputDataSet(a_maxVertexCount);
  AddVertexPositionsFromInputDataSet(a_maxVertexCount);

  return oldSize;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::MyInputData::Clear()
{
  memset(this,0,sizeof(MyInputData));
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::GetTextureDesc(uint texId, uint* w, uint* h, uint* format)
{
  if(texId == INVALID_TEXTURE)
    return;

  if(texId >= m_images.size())
    RUN_TIME_ERROR(std::string("GetTextureDesc: texId") + ToString(texId) + " does not exists in engine" );

  if(w!=NULL) *w = m_images[texId].width();
  if(h!=NULL) *h = m_images[texId].height();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::GetTextureData(uint texId, void* data)
{
  if(texId == INVALID_TEXTURE)
    return;

  if(texId >= m_images.size())
    RUN_TIME_ERROR(std::string("GetTextureData: texId") + ToString(texId) + " does not exists in engine" );

  if(data!=NULL)
    memcpy(data, m_images[texId].GetConstData(), m_images[texId].width()*m_images[texId].height()*4 );
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////

void Common_Graphics_Engine::SetWorldViewMatrix(const float mat[16]) { memcpy(m_worldViewMatrixData, mat, 16*sizeof(float)); }
void Common_Graphics_Engine::SetProjectionMatrix(const float mat[16]) { memcpy(m_projectionMatrixData, mat, 16*sizeof(float));}

const float* Common_Graphics_Engine::GetWorldViewMatrix() const { return m_worldViewMatrixData; }
const float* Common_Graphics_Engine::GetProjectionMatrix() const { return m_projectionMatrixData; } 



//////////////////////////////////////////////////////////////////////////////////////////////////////
////

Common_Graphics_Engine::ImageStorage::ImageStorage()
{
  FreeData();
}


void Common_Graphics_Engine::ImageStorage::SetData(const unsigned char* data, int w, int h, int byteSize, int a_format)
{
  m_width  = w;
  m_height = h;
  m_format = a_format;

  switch(a_format)
  { 
    case RGBA8:
      m_elemByteSize = 4*sizeof(char);
      break;

    case RGBA16F:
      m_elemByteSize = 4*sizeof(short);
      break;

    case RGBA32F:
      m_elemByteSize = 4*sizeof(float);
      break;

    default:
      m_elemByteSize = 0;

  };

  m_data.assign(data, data + m_elemByteSize*w*h);
}

void Common_Graphics_Engine::ImageStorage::FreeData()
{
  m_width  = 0;
  m_height = 0;
  m_elemByteSize = 0;
  m_data = std::vector<unsigned char>();
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////


Common_Graphics_Engine::MegaTexStorageProxy::MegaTexStorageProxy(const char* usage, const unsigned char* data, int w, int h, int byteSize, int a_format, const std::vector<float>& a_lut)
{
  if(byteSize > 100*1024*1024)
  {
    m_filename = std::string(usage) + "_megatex.bin";

    std::ofstream fout(m_filename.c_str(), ios::binary);
    fout.write((const char*)data, byteSize);
    fout.close();
    savedToFile = true;

     m_data = std::vector<unsigned char>();
  }
  else if(byteSize > 0)
  {
    m_data.resize(byteSize);
    memcpy(&m_data[0], data, byteSize);
    savedToFile = false;
  }
  
  m_width  = w;
  m_height = h;
  m_format = a_format;  
  m_byteSize = byteSize;
  m_lut = a_lut;
}

void Common_Graphics_Engine::MegaTexStorageProxy::SetData(const unsigned char* data, int w, int h, int byteSize, int a_format)
{
  RUN_TIME_ERROR("forbidden");
}

const void* Common_Graphics_Engine::MegaTexStorageProxy::GetConstData() const 
{ 
  return NULL;
}

void* Common_Graphics_Engine::MegaTexStorageProxy::GetData()
{ 
  if(savedToFile)
  {
    m_data.resize(m_byteSize);
    std::ifstream fin(m_filename.c_str(), ios::binary);
    fin.read((char*)(&m_data[0]), m_byteSize);
    fin.close();
    remove(m_filename.c_str());
    savedToFile = false;
  }

  if(m_data.size() > 0)
    return &m_data[0];
  else
    return NULL;
}

void Common_Graphics_Engine::MegaTexStorageProxy::FreeData()
{
  Base::FreeData();
  m_lut = std::vector<float>();
}





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////
////
/*
void Common_Graphics_Engine::CreateCubeMapDistribution(DynamicArray<float4>& a_data, int N)
{
  a_data.resize(6*N*N);

  int width = N;

  for(int x=0;x<N;x++)
  {
    for(int y=0;y<N;y++)
    {
      float u = ( (float(x)+0.5f) / float(N) ) * 2.f - 1.f; // [-1,1] 
      float v = ( (float(y)+0.5f) / float(N) ) * 2.f - 1.f; // [-1,1]

      float cx, cy, cz;

      for ( unsigned int face = 0; face < 6; face ++ )
      {
        //Layer 0 is positive X face
        if ( face == 0 )
        {
          cx = 1;
          cy = -v;
          cz = -u;
        }

        //Layer 1 is negative X face
        else if ( face == 1 )
        {
          cx = -1;
          cy = -v;
          cz = u;
        }

        //Layer 2 is positive Y face
        else if ( face == 2 )
        {
          cx = u;
          cy = 1;
          cz = v;
        }

        //Layer 3 is negative Y face
        else if ( face == 3 )
        {
          cx = u;
          cy = -1;
          cz = -v;
        }

        //Layer 4 is positive Z face
        else if ( face == 4 )
        {
          cx = u;
          cy = -v;
          cz = 1;
        }

        //Layer 5 is negative Z face
        else if ( face == 5 )
        {
          cx = -u;
          cy = -v;
          cz = -1;
        }

        // read from texture, do expected transformation and write to global memory
        // a_data[face*width*width + y*width + x] = -texCubemap( tex, cx, cy, cz );
        //
        float3 ray_dir = normalize(float3(cx,cy,cz));
        a_data[face*width*width + y*width + x] = to_float4(ray_dir, 0);
      }
    }
  }

}
*/

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::PlaneHammersley(float *result, int n)
{
  for (int k=0; k<n ; k++)
  {
    float u = 0;
    int kk  = k;

    for (float p=0.5; kk; p*=0.5, kk>>=1)
      if (kk & 1)                           // kk mod 2 == 1
        u += p;

    float v = (k + 0.5) / n;

    result[2*k+0] = u;
    result[2*k+1] = v;
  }
}

float3 Common_Graphics_Engine::MapToHemiSphere(float r1, float r2)
{
  float e = 0.0f; 

  float cos_phi = cos(2*r1*MGML_MATH::PI);
  float sin_phi = sin(2*r1*MGML_MATH::PI);
  float cos_theta = pow(1.0f-r2, 1.0f/(e+1.0f));
  float sin_theta = sqrtf(1.0f-cos_theta*cos_theta);

  float x1 = sin_theta*cos_phi;
  float y1 = sin_theta*sin_phi;
  float z1 = cos_theta;

  return float3(x1,y1,z1);
}

/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::CreateSphericalDistribution(std::vector<float4>& a_sphereUniform, int N, bool cosine)
{
  //
  //
  int groupSize = WARP_SIZE;

  int stepX = 4;
  int stepY = 4;

  if(N % (stepX*stepY))
    RUN_TIME_ERROR("CreateSphericalUniformDistribution(size must be a multiple of 16)");

  a_sphereUniform.resize(N*N);
  int counter = 0;

  Matrix4x4f mRot;
  mRot.SetRotationX(MGML_MATH::PI/2);

  std::vector<float2> hammerslaySamples(16);
  PlaneHammersley((float*)&hammerslaySamples[0], hammerslaySamples.size());

  float e = cosine ? 1.0f : 0.0f;

  for(int groupX=0;groupX<N;groupX+=stepX)
  {
    for(int groupY=0;groupY<N;groupY+=stepY)
    {
      float b1Min = ((float)groupX/(float)(N));
      float b1Max = ((float)(groupX+stepX)/(float)(N));

      float b2Min = ((float)groupY/(float)(N));
      float b2Max = ((float)(groupY+stepY)/(float)(N));

      for(int y=0;y<stepY;y++)
      {
        for(int x=0;x<stepX;x++)
        {
          int x2 = groupX + x;
          int y2 = groupY + y;

          float r1 = b1Min + (b1Max-b1Min)*hammerslaySamples[y*stepX+x].x;  
          float r2 = b2Min + (b2Max-b2Min)*hammerslaySamples[y*stepX+x].y;  

          float3 point = MapToHemiSphere(r1,r2);

          float x1 = point.x;
          float y1 = point.y;
          float z1 = point.z;

          if(x2 == N-1 && y2 == 0) // a temporary hack to close the hole one the top of sphere
          {
            x1 = 0;
            y1 = 0;
            z1 = 1;
          }

          a_sphereUniform[counter].set(x1,y1,z1,1);
          a_sphereUniform[counter]= mRot*a_sphereUniform[counter];
          counter++;
        }
      }
    }
  }

}

static const float MyFactTable[] = {1.0f, 1.0f, 2.0f, 6.0f, 24.0f,120.0f, 720.0f, 5040.0f, 40320.0f, 362880.0f,
                                    3.6288e+006f, 3.99168e+007f, 4.79002e+008f, 6.22702e+009f, 8.71783e+010f, 1.30767e+012f, 2.09228e+013f,
                                    3.55687e+014,6.40237e+015,1.21645e+017,2.4329e+018,5.10909e+019,1.124e+021,2.5852e+022,6.20448e+023,1.55112e+025,4.03291e+026,
                                    1.08889e+028,3.04888e+029,8.84176e+030,2.65253e+032,8.22284e+033,2.63131e+035,8.68332e+036,2.95233e+038
};

struct SphericalHarmonicsMath
{

  static inline float factorial(int fact_ind) 
  { 
    int index = (fact_ind >= 0) ? fact_ind : 0;
    return MyFactTable[index];
  }

  static float P(int l, int m, float x)
  {
    // evaluate an Associated Legendre Polynomial P(l,m,x) at x
    //
    float pmm = 1.0;
    if(m>0) 
    {
      float somx2 = sqrt((1.0f-x)*(1.0f+x));
      float fact = 1.0f;
      for(int i=1; i<=m; i++) 
      {
        pmm *= (-fact) * somx2;
        fact += 2.0f;
      }
    }

    if(l==m)
      return pmm;

    float pmmp1 = x * (2.0*m+1.0) * pmm;
    if(l==m+1) 
      return pmmp1;

    float pll = 0.0;
    for(int ll=m+2; ll<=l; ++ll) 
    {
      pll = ( (2.0*ll-1.0)*x*pmmp1-(ll+m-1.0)*pmm ) / (ll-m);
      pmm = pmmp1;
      pmmp1 = pll;
    }

    return pll;
  }

  static float K(int l, int m)
  {
    // renormalisation constant for SH function
    float temp = ((2.0f*l+1.0f)*factorial(l-m)) / (4.0f*3.141592654f*factorial(l+m));
    return sqrt(temp);
  }

  static float SH(int l, int m, float theta, float phi)
  {
    // return a point sample of a Spherical Harmonic basis function
    // l is the band, range [0..N]
    // m in the range [-l..l]
    // theta in the range [0..Pi]
    // phi in the range [0..2*Pi]
    const float sqrt2 = sqrt(2.0);

    if(m==0) 
      return K(l,0)*P(l,m,cos(theta));
    else if(m>0) 
      return sqrt2*K(l,m)*cos(m*phi)*P(l,m,cos(theta));
    else
      return sqrt2*K(l,-m)*sin(-m*phi)*P(l,-m,cos(theta));
  }
};


/////////////////////////////////////////////////////////////////////////////////////
////
void Common_Graphics_Engine::PrecomputeSHCoeffs(std::vector<float>& out_coeffs)
{
  const int nBands = N_BANDS; 
  const int numFunctions  = nBands*nBands;
  
  const int tableResTheta = 192; // Y
  const int tableResPhi   = tableResTheta*2; // X


  out_coeffs.resize(tableResPhi*tableResTheta*numFunctions);
  m_shResPhi     = tableResPhi;
  m_shResTheta   = tableResTheta;
  m_sphLayersNum = numFunctions;

  const float tableResPhiInv   = 1.0f/float(tableResPhi);
  const float tableResThetaInv = 1.0f/float(tableResTheta);

  for(int l=0;l<nBands;l++) 
  {
    for(int m=-l;m<=l;m++) 
    {
      int coeffNumber = l*(l+1)+m;
      int offsetZ = coeffNumber*tableResPhi*tableResTheta;

      for(int iTheta = 0; iTheta < tableResTheta; iTheta++)
      {
        float theta = MGML_MATH::PI*float(iTheta)*tableResThetaInv;
        int offsetY = offsetZ + iTheta*tableResPhi;

        for(int iPhi=0;iPhi<tableResPhi;iPhi++)
        {
           float phi = 2.0f*MGML_MATH::PI*float(iPhi)*tableResPhiInv;
           out_coeffs[offsetY + iPhi] = SphericalHarmonicsMath::SH(l,m,theta,phi);
        }
      }
    }
  }

  //std::ofstream out("D:\\out\\buffer.bin", std::ios::binary);
  //out.write((const char*)(&out_coeffs[0]), out_coeffs.size()*sizeof(float));
  //out.close();

}



void Common_Graphics_Engine::DebugCall(const std::string& a_name, const std::string& a_params)
{
  if(a_name == "SetDebugOputputValue")
    m_debugOutput = bool(atoi(a_params.c_str()));
  else if(a_name == "SetVoxelizeOnLoad")
    m_voxelizeOnLoad = bool(atoi(a_params.c_str()));
}



