import os, zipfile, time

EXTENSIONS = [".h",".c",".cpp",".hcc",".sln",".vcproj", ".vcxproj", ".cl", ".cu", ".cuh", ".rules", ".py", ".pl", ".rc",
              ".vert",".frag", ".geom", ".tess", ".eval", ".hlsl", ".glsl", ".fx", ".vs", ".ps", ".gs", ".hs", ".ds", ".ts", ".es", 
              ".ads", ".adb", ".gpr", ".pas", ".txt", ".asm", ".def", ".cbp", ".workspace"]

PROJECT_NAME = "Hydra"           
CURR_PATH    = "."  # this is the path from where program start scan folders            
              
folder_name = CURR_PATH
arch_name   = PROJECT_NAME + time.strftime("_%d_%B_%Y", time.localtime()) + ".zip"		

zip = zipfile.ZipFile(arch_name,'w', zipfile.ZIP_DEFLATED)
print "Archive name: " + arch_name

def extInList(filename):
  return (os.path.splitext(filename)[1] in EXTENSIONS)
  
folders = [x[0] for x in os.walk(folder_name) if not ".svn" in x[0]]
files   = [folder + "\\" + file for folder in folders for file in os.listdir(folder) if extInList(file)] 
                               
for file in files:
  zip.write(file)
  