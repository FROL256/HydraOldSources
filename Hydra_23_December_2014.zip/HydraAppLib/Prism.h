#pragma once

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "SimpleMesh.h"

using namespace MGML;

struct Prism : SimpleMesh
{
	Prism(){}
	Prism(const Matrix4x4f& matrix, int matId,
		    float size, float angle = 45.0f);

	const Vertex4f*		GetVertices() const {return vert;}
	const unsigned int* GetIndices() const  {return indices;}
  void InvertNormals();

  enum { VERT_NUM = 4*3 + 3*2, INDEX_NUM = 3*(3*2+2)};

protected:
	Vertex4f	 vert[VERT_NUM];
	unsigned int indices[INDEX_NUM];

  void CalcNormals();
};

