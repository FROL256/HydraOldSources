#pragma once

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "../gpu_rt/IGraphicsEngine.h"
#include "../gpu_rt/GPU_Path_Tracer.h"

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"

struct Input 
{
	Input();
  ~Input();

	void reset() {cam_mov.set(0,0,0,1); cam_rotInst.set(0,0,0,1);  printPerfInfo = false;}

	MGML::vec4f cam_rot, cam_mov, cam_rotInst;

	int mx,my;
	bool ldown;		// ������ ����� ������� ����?
	bool rdown;		// ������ ������ ������� ����?
	bool exit_status;
  bool drawAllGrid;
  bool pathTracingEnabled;
  bool relightEnabled;

	int trace_depth;
  int diffuse_trace_depth;
  int tree_level_visible;
  
  int   mlLayersNum;
  int   mlRadius;
  float mlSigma;
  bool  mlFilterPrimary;

	bool shadows;
  bool indirrectIllum;
  int AA;
  bool ptStupidMode;
  bool ptCaustics;
  bool ptGuided;

  bool computeIrradianceCache;
  bool irradianceCacheCalculated;
  bool freeIrradianceCache;

  bool computeRadianceCache;
  bool radianceCacheCalculated;

  bool tracePhotonsDebug;
  bool tracePhotonsCausticsDebug;
  bool photonTracingFinishedDebug;
  bool enableIrradianceMap;

  bool voxelizeNow;
  bool voxelizeOnLoad;
  bool enableDebugOutput;

  int  rcType;
  bool debugViewSHReconstructed;

  bool printPerfInfo;
  bool drawBlocks;
  bool drawRayStatInfo;
  bool recursiveTracer;

  bool saveImageNow;
  bool toneMapNow;
  bool saveImageWithReadPixels;
  bool useFiltering;
  bool savePTImagesSequence;
  std::string savedImageName;
  std::string exportFilePath;
  std::string hdrFileType;
  bool showToneMappedImage;
  bool reloadHydraProfile;
  bool generateHydraProfiles;
  bool ambientView;
  bool transformICToPhMap;
  
  bool saveImageLayers;
  bool noWindow;
  bool buildIrradianceMapNow;

  std::string camType;
  std::string fromPluginRenderMethod;
  
  // for saving and restoring cameras
  //
  int saveCamera;
  int restoreCamera;
  
  // irradiance cache presets
  //
  float icWSErrorTreshold;
  float icErrorWS;
  float icErrorSS[3];
  int   icFixedRays;
  int   icMaxPasses;
  int   icBounce;
  bool  icProgressiveEvaluation;
  bool  drawIrradianceCachePixelPoints;

  // photon maps
  //
  bool drawPhotons;
  bool drawPhotonsCaustic;
  bool progressivePhotonMap;
  bool progressiveCausticMap;
  bool enablePhotonsGartheringDiffuse;
  bool enablePhotonsGartheringCaustic;
  bool enableOutputRedirect;
  int  maxDiffusePhotons;
  int  maxCausticPhotons;
  int  skipFirstPhotonBounce;
  int  skipGartherBounce;
  float gartherRadiusDiffuse;
  float gartherRadiusCaustic;
  float causticPower;
  int   pmDiffuseRetrace;
  int   pmCausticRetrace;
  bool  enableSROctreeForPhotonMapping;
  bool  disablePhotonVisibilityTracing;

  bool pmdlDraw; // pmdl --> Photon Map Direct Light
  bool pmdlAll;
  int  pmdlLightId;

  float alpha_c;
  float alpha_d;

  // general
  //
  HANDLE m_sharedMemoryHandle;
  HANDLE m_sharedOutputImageHandle;
  HANDLE m_sharedMessages;

  char*  messages;

  int ext_width;
  int ext_height;
  std::string ext_scene;
  std::string ext_renderer;
  std::string ext_renderer_hw_layer;
  bool animateLight;
  int accelStructConstructionMode;
  int debugLayerDraw;

  bool rayBufferFullSize;
  int  rtMeasureRaysType;
  int  rtReorderType;
  int  rtReorderPattern;

  //////////////////////////////////////////////////////////////////////
  std::string inColladaFile;
  std::string inColladaProfile;
  std::string inOutImageFileName;
  std::string inTempFolder;
  //////////////////////////////////////////////////////////////////////

  std::string inGeomHash;
  std::string inLightsHash;
  std::string inMatgHash;

  std::string solverPrimaryMethod;
  std::string solverSecondaryMethod;
  std::string solverTertiaryMethod;
  std::string solverCausticMethod;

  int solverManualMode;
  int solverTertiarAll;

  GPU_Path_Tracer::RenderingParams pt_params;
  
  char* inputXML;                              // extern OS shared memory where gui input saved 
  char* outputImage;                           // extarn OS shared memory where image output should be done

  int m_debugIndex;
  float3 m_debugPos;

  float hdrStrength;
  float hdrPhi;
  float hdrWitePoint;
  float hdrGamma;
  float texInGamma;

  float camSpeed;
  float camApect;

  void ReadXMLFromSharedMemory(const char* guiMemName, const char* imageMemName, const char* msgMemName);
  void ReadXMLFromFile(const std::string& fileName);

	void Mouse(int button, int state, int x, int y); //��������� ������� ����
	void MouseMotion(int x, int y);                  //����������� ����
	void Keyboard(unsigned char key,int x,int y);   //�����
	void KeyboardSpecial(int key, int x, int y);   // ���� �����

  void SetCameraForTestPerf(std::string scene_name, int cam_number);


protected:

  void ReadXMLFromDoc(TiXmlDocument& a_doc);
};


