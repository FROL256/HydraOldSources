#include "../HydraAppLib/main.h"
#include "HydraNetwork.h"

bool g_importFromFile = true;

using namespace MGML;
using namespace MGML_MATH;
using namespace std;

int WinWidth  = 640;
int WinHeight = 480;
float gl_ver  = 3.0;

IGraphicsEngine* pRender = NULL;
IReLightProxy*   pReLightApp = NULL;
IHydraUserControl* pUserControl = NULL;
Input input;  
Camera* cam = NULL;
IHydraStateMachine* pControlState = NULL;
IMLFilter* pMLFilter = NULL;

HydraRenderPassState g_state;

volatile bool pathTracingFinished = true;
int ticksOld = 0;
int ticksNew = 0;
bool stopCountTime = false;
bool firstPass = false;

bool exitNow = false;
bool takeImageOutside = false;

uint* otherLDRImage = NULL;

void UpdateProgress(const char* a_message, float a_progress)
{
  static char message[1024];
 
  memset(message, 0, 1024);
  sprintf(message, "%s: %.0f%% \r", a_message, a_progress*100.0f);

  fprintf(stderr,"%s",message);
  SendToPlugin(message);
}

int userWinWidth  = 640;
int userWinHeight = 480;
bool badResolution = false;

void UpdateImage(IGraphicsEngine* pRender, uint* a_data, bool a_lastImage)
{
 static std::vector<float4> realImageData;

 //
 SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.outputImage;

 if (pInfo != NULL && pInfo->read != 0)
 {
   GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);

   if(pathTracer!=NULL)
   {
     if(badResolution)
     {
       if(realImageData.size() != WinWidth*WinHeight*4)
         realImageData.resize(WinWidth*WinHeight*4);

       if(a_data != NULL)
         memcpy(&realImageData[0], a_data, WinWidth*WinHeight*4*sizeof(float));
       else
         pathTracer->GetHDRImage((float4*)&realImageData[0]);

       char* pOutData = input.outputImage + sizeof(SharedBufferDataInfo);
       float4* pOutDataF = (float4*)pOutData;

       for(int y=0;y<userWinHeight;y++)
       {
         int offsOld = y*WinWidth;
         int offsNew = y*userWinWidth;
       
         for(int x=0;x<userWinWidth;x++)
           pOutDataF[offsNew+x] = realImageData[offsOld+x];
       }

     }
     else
     {
       char* pOutData = input.outputImage + sizeof(SharedBufferDataInfo);
       
       if(a_data != NULL)
         memcpy(pOutData, a_data, WinWidth*WinHeight*4*sizeof(float));
       else
         pathTracer->GetHDRImage((float4*)pOutData);
     }

     pInfo->width   = WinWidth;
     pInfo->height  = WinHeight;
     pInfo->read    = 0;
     if(a_lastImage)
       pInfo->written = HYDRA_SERVER_FINISH_ID;
     else
       pInfo->written = HYDRA_SERVER_ID;
   }
 }
}

void WaitForImageBufferIsFree()
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.outputImage;

  int counter = 0;
  while(pInfo->read == 0 && counter < 10)
  {
    Sleep(100);
    std::cerr << "waiting for max plug-in read it's data ... " << std::endl;
    counter++;
  }
}

void Init()
{
  try
  {
    if(input.enableOutputRedirect)
    {
      freopen("C:\\[Hydra]\\logs\\stdout.txt", "wt", stdout);
      freopen("C:\\[Hydra]\\logs\\stderr.txt", "wt", stderr);
    }

    if(!input.noWindow)
    {
      gl_ver = GetCurrGLVersion();

      if(gl_ver <= 3.1)
        glBuildFont(); // my custom function

      std::cerr << "[main]: gl_ver  = " << gl_ver << std::endl;

      //------------------------------------------------------------------
      if(!input.noWindow)
      {

        CHECK_GL_ERRORS;
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        glViewport(0, 0, WinWidth, WinHeight);

        glClear(GL_COLOR_BUFFER_BIT);
        if(gl_ver <= 3.1)
        {
          glDisable(GL_LIGHTING);
          glDisable(GL_TEXTURE_2D);
          glColor3f(1,1,1);
          glTablePrintf (1, 3, "Init Renderer ... ");
        }
        glutSwapBuffers();
        CHECK_GL_ERRORS;

        //------------------------------------------------------------------

        glewExperimental = GL_TRUE;
        GLenum err=glewInit();
        if(err!=GLEW_OK)
        {
          fprintf(stderr, "glewInitError: %s\n", glewGetErrorString(err));
          RUN_TIME_ERROR("glewInit() failed");
        }

        // flush OpenGL errors
        int tmp = 0;
        while(glGetError()!= GL_NO_ERROR && tmp < 100) tmp++;
        SetVSync(0);
        CHECK_GL_ERRORS;

      }

      input.reset();
    }

    int flags = GPU_RT_HW_LAYER_CUDA;

    if (input.ext_renderer_hw_layer == "OpenCL")
      flags = GPU_RT_HW_LAYER_OCL;
    else if (input.ext_renderer_hw_layer == "FRSDK")
      flags = GPU_RT_HW_LAYER_FRSDK;

    if(input.rayBufferFullSize) flags |= GPU_RT_MEMORY_FULL_SIZE_MODE;
    if(input.noWindow)          flags |= GPU_RT_NOWINDOW;


    if(input.ext_renderer == "OpenGL 1")
      pRender = new OpenGL_Render(WinWidth, WinHeight);
    else   if(input.ext_renderer == "Exporter")
      pRender = new HydraExporter(WinWidth, WinHeight);
    else
      pRender = new GPU_Path_Tracer(WinWidth, WinHeight, flags);

    pReLightApp  = new TestReLightPoxy(pRender);
    pUserControl = new HydraControlCommon(pRender);
    pUserControl->SetScene(LastImportedScene()); // object ids of scene that was imported from collada

    if(input.camType == "Euler")
      cam = new Camera(); 
    else
      cam = new CameraUVN(); 

    cam->SetPerspectiveProjection(45.0f, float(WinWidth)/float(WinHeight), 0.01f, 10000.0f);

    pMLFilter = CreateFilter("default");

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // a very big shit about states machine
    //
    if(true)
    {
 
      // presete for photon maps and irradiance maps
      //
      if(input.solverPrimaryMethod == "sppm" || input.solverSecondaryMethod == "sppm" || input.solverTertiaryMethod == "sppm") 
      {
        input.enablePhotonsGartheringDiffuse = true;
        input.progressivePhotonMap           = true; 
      }

      if(input.solverPrimaryMethod == "sppm")
      {
        input.skipFirstPhotonBounce = 0;
        input.skipGartherBounce     = 0;
      }
      else if(input.solverSecondaryMethod == "sppm") 
      {
        input.skipFirstPhotonBounce = 1;
        input.skipGartherBounce     = 0;
      }
      else if(input.solverTertiaryMethod == "sppm")
      {
        if(input.solverTertiarAll)
        {
          input.skipFirstPhotonBounce = 0;
          input.skipGartherBounce     = 1;
        }
        else
        {
          input.skipFirstPhotonBounce = 1;
          input.skipGartherBounce     = 1;
        }
      }

      if(input.enableIrradianceMap)
      {
        input.buildIrradianceMapNow          = true;
        input.enablePhotonsGartheringDiffuse = true;
        input.progressivePhotonMap           = false; 
      }

      // now create appropriate states machines
      //
      if((input.solverPrimaryMethod == "path_tracing" && (input.solverSecondaryMethod == "path_tracing" || input.solverSecondaryMethod == "sppm"))
                                                      && (input.solverTertiaryMethod  == "path_tracing" || input.solverTertiaryMethod == "sppm")      
                                                      || input.solverPrimaryMethod == "sppm")
      {
        pControlState = new SimplePathTracerSM;
      }
      else if(input.solverPrimaryMethod == "multilayered")
      {
        std::cerr << "multilayered selected" << std::endl;
        pControlState = new MultyLayeredSM;
        input.saveImageLayers = true;
      }
      else if(input.solverPrimaryMethod == "path_tracing" && (input.solverSecondaryMethod == "irradiance_cache" || input.solverTertiaryMethod == "irradiance_cache"))
      {
        if(input.solverSecondaryMethod == "irradiance_cache")
          input.icBounce = 0;
        else
          input.icBounce = 1;

        pControlState = new IrradianceCahePlusPathTracerSM;
        input.progressivePhotonMap = false; 
      }
      else if(input.solverPrimaryMethod != "")
      {
        pControlState = new SimplePathTracerSM;
      }
      else
      {
        pControlState = NULL;
      }

      
      if(input.solverCausticMethod == "sppm")
      {
        input.progressiveCausticMap          = true;
        input.enablePhotonsGartheringCaustic = true;
        input.ptCaustics                     = false;
      }
      else if(input.solverCausticMethod == "path_tracing")
      {
        input.progressiveCausticMap          = false;
        input.enablePhotonsGartheringCaustic = false;
        input.ptCaustics                     = true;
      }

    }
   

    //------------------------------------------------------------------
    if(gl_ver <= 3.1 && !input.noWindow)
    {
      glClear(GL_COLOR_BUFFER_BIT);
      glTablePrintf (1, 3, "Init Renderer ... ");
      glTablePrintf (2, 3, "Loading Scene ... ");
      glutSwapBuffers();
    }
    //------------------------------------------------------------------

    UpdateProgress("Loading scene", 0.0f);

    if(input.inColladaFile != "" && input.inColladaFile.find("dummy.dae") >= input.inColladaFile.size() && 
                                    input.inColladaFile.find("empty.dae") >= input.inColladaFile.size())
    {
      if(input.inColladaFile.substr(input.inColladaFile.size()-5, 5) == ".vsgf")
      {
        std::cerr << "[main]: load scene from " << input.inColladaFile.c_str() << std::endl;

        if(input.inColladaProfile.substr(input.inColladaProfile.size()-4, 4) == ".xml")
        {
          //std::string originalColladaProfilePath = input.inColladaProfile;
          //std::string pathWithoutExtension = originalColladaProfilePath.substr(0, originalColladaProfilePath.size() - 4); // ".xml"
          //std::string pathExported = pathWithoutExtension + "_generated.xml";
          pUserControl->LoadSceneFromNativeHydraFormat(input.inColladaFile, input.inColladaProfile);
        }
        else
        {
          std::cerr << "wrong collada profile filename " <<  input.inColladaProfile.c_str() << std::endl;
          exit(0);
        }
      }
      else
      {
        Matrix4x4f mr,mt,ms, ms2;
        float k = 0.1f/0.025400;
        ms.SetScale(float3(k,k,k));

        ImportSceneFromCollada(pRender, input.inColladaFile, cam, ms, input.inColladaProfile);
        input.cam_rot = cam->GetRotation();
      }
    }
    else // actual import from max 
    {
      std::string scenePath   = "C:/[Hydra]/pluginFiles/scene.vsgf";
      std::string profilePath = "C:/[Hydra]/pluginFiles/hydra_profile_generated.xml";

      std::cerr << "[main]: load scene from " << scenePath.c_str() << std::endl;

      pUserControl->LoadSceneFromNativeHydraFormat(scenePath, profilePath);
    }

    pRender->SetProgressBarCallback(UpdateProgress);
    pRender->SetUpdateImageCallback(UpdateImage);

    if(input.reloadHydraProfile)
    {
      pUserControl->ReloadProfile(input.inColladaProfile);
      input.reloadHydraProfile = false;
    }

    if(pRender->GetLightNumber() == 0) // no lights in scene? Add one!
    {
      std::cerr << "[main]: light num = " << pRender->GetLightNumber() << ", add white sky ... "<< std::endl;

      RAYTR::Light addedLight;
      addedLight.SetLighType(RAYTR::Light::LIGHT_TYPE_SKY);
      addedLight.pos.set(0,10000,0);
      addedLight.kc = 1;
      addedLight.kl = 0.0;
      addedLight.kq = 0.0;
      addedLight.intensity = 0.5f;
      addedLight.color.set(1.0f, 0.95f, 0.95f);
      addedLight.SetAORayLength(10000.0f);
      addedLight.sphTexIndex[0] = INVALID_TEXTURE;
      addedLight.sphTexIndex[1] = INVALID_TEXTURE;
      pRender->AddLight(addedLight);
    }

    Ray_Tracer* pRayTracer = dynamic_cast<Ray_Tracer*>(pRender);
    if(pRayTracer != 0 && !input.animateLight)
      pRayTracer->AddLightsAsGeometry();  // try to add lights as geometry if needed

    pUserControl->SetScene(LastImportedScene()); // object ids of scene that was imported from collada
    if(input.generateHydraProfiles)
    {
      pUserControl->GenerateProfile(std::string(LastImportedScene()->scenefolder) + "/hydra_profile_generated.xml"); 
    }

    //------------------------------------------------------------------
    if(gl_ver <= 3.1 && !input.noWindow)
    {
      glClear(GL_COLOR_BUFFER_BIT);
      glTablePrintf (1, 3, "Init Renderer ... ");
      glTablePrintf (2, 3, "Loading Scene ... ");
      glTablePrintf (3, 3, "Building BVH ... ");
      glutSwapBuffers();
    }
    //------------------------------------------------------------------

    UpdateProgress("Building BVH", 0.0f);
    cout << "[main]: constructing BVH, please wait...\n";
    Timer treeBuildTimer;
    treeBuildTimer.start();
    float timeStart = treeBuildTimer.getElapsed();

    pRender->BuildAccelerationStructures(input.inGeomHash + input.inMatgHash, input.inLightsHash);

    float totalConstructionTime = treeBuildTimer.getElapsed() - timeStart;
    cout << "[main]: construction time: " << totalConstructionTime << "s" << endl;

    HydraExporter* pExporter = dynamic_cast<HydraExporter*>(pRender);
    if(pExporter != NULL)
      pExporter->ExportSceneGeometry(input.exportFilePath, LastImportedScene()->materials);

  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
}


//////////////////////////////////////////////////////////////////////////
////
void ShutDown()
{
  static bool exited = false;

  if(exited)
    return;

  try
  {
    exitNow = true;
    SendToPlugin("exitServer");
    cerr << "destroying resources..." << std::endl;
    cerr.flush();

    DeleteFilter(pMLFilter);

    delete cam; cam = NULL;
    delete pControlState; pControlState = NULL;
    delete pUserControl; pUserControl = NULL;
    delete pReLightApp; pReLightApp = NULL;
    delete pRender; pRender = NULL;

    input.~Input();
    free(otherLDRImage); otherLDRImage = NULL;

    cerr << "resources were destroyed" << std::endl;
    cerr.flush();

    exited = true;

    //std::ofstream exitCompleted("C:\\[Hydra]\\temp\\exit.txt");
    //exitCompleted << "Exit is fine " << std::endl;
    //exitCompleted.flush();
    //exitCompleted.close();

  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    cerr << endl << "Stack trace: " << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }
}

Timer g_totalTimer;

void Display()
{
  if(exitNow)
    return;

  static size_t FramesCount = 0;
  static size_t totalFramesCount = 0;
  static float FPS = 60; 

  static float t_process = 1;
  static float omega = 0.5;
  static float path_tracing_time = 0.0f;
  static float lastImageSavedTime = 0.0;
  static float lastImageSavedTime2 = 0.0;
  static bool imageSaved = false;

  static Timer timer; 

  try
  {
    input.ReadXMLFromSharedMemory(NULL, NULL, NULL); // already conneted whe do init, so pass NULLs

    if(input.exit_status) 
      exit(0);

    if(t_process > 1000)
      t_process = 1.0f;

    if(firstPass)
      g_totalTimer.start();

    if(!input.pathTracingEnabled)
    { 
      t_process += (omega/FPS);

      CameraUVN* pUVN = dynamic_cast<CameraUVN*>(cam);
      bool usedUVNCamera = (pUVN != NULL);

      if(usedUVNCamera && input.camType == "Euler")
      {
        Camera* pCam2 = cam->CloneToEuler();
        delete cam;
        cam = pCam2;
        std::cerr << "changed to Euler" << std::endl;
      }
      else if(!usedUVNCamera && input.camType == "UVN")
      {
        Camera* pCam2 = cam->CloneToUVN();
        delete cam;
        cam = pCam2;
        std::cerr << "changed to UVN" << std::endl;
      }

      cam->Move(input.cam_mov);
      cam->Rotate(input.cam_rotInst);
    }

    // save and restore camera
    //
    if(input.saveCamera != 0)
    {
      stringstream tmpstream; tmpstream << "cam" << input.saveCamera << ".txt";
      cam->Save(tmpstream.str());
      std::cerr << "cam.pos = " << cam->pos << std::endl;
      input.saveCamera = 0;
    }
    else if(input.restoreCamera != 0)
    {
      stringstream tmpstream; tmpstream << "cam" << input.restoreCamera << ".txt";
      cam->Load(tmpstream.str());
      cam->SetPerspectiveProjection(input.camApect/2.0f, float(WinWidth)/float(WinHeight), 0.01f, 10000.0f);    
      input.cam_rot = cam->GetRotation();
      input.restoreCamera = 0;
    }

    if(input.reloadHydraProfile)
    {
      pUserControl->ReloadProfile(input.inColladaProfile);
      input.reloadHydraProfile = false;
    }

    if(input.camType == "Euler")
      cam->SetPerspectiveProjection(input.camApect/2.0f, float(WinWidth)/float(WinHeight), cam->GetNearClipPlane(), cam->GetFarClipPlane());

    //
    //
    pRender->SetWorldViewMatrix((cam->GetWorldMatrix()*cam->GetViewMatrix()).L);
    pRender->SetProjectionMatrix(cam->GetProjectionMatrix().L);
    pRender->SetAuxCamProjParams((float*)(&cam->m_projParams));

    pRender->SetVariable("drawIrradianceCachePixelPoints", int(input.drawIrradianceCachePixelPoints));
    pRender->SetVariable("drawPhotons", int(input.drawPhotons));
    pRender->SetVariable("drawPhotonsCaustic", int(input.drawPhotonsCaustic));
    pRender->SetVariable("debugViewSH", int(input.debugViewSHReconstructed));
    pRender->SetVariable("g_debugLayerDraw", input.debugLayerDraw);
    pRender->SetVariable("g_saveRaySamples", int(input.useFiltering));
    pRender->SetVariable("g_ptStupid", int(input.ptStupidMode));
    pRender->SetVariable("g_enableSROctree", int(input.enableSROctreeForPhotonMapping));
    pRender->SetVariable("rtMeasureRaysType", input.rtMeasureRaysType);
    pRender->SetVariable("rtReorderType", input.rtReorderType);
    pRender->SetVariable("rtReorderPattern", input.rtReorderPattern);

    pRender->SetVariable("pmdlDraw", int(input.pmdlDraw));
    pRender->SetVariable("pmdlAll", int(input.pmdlAll));
    pRender->SetVariable("pmdlLightId", input.pmdlLightId);

    IGraphicsEngine::RenderSettings settings;

    settings.SetTraceDepth(input.trace_depth);
    settings.SetDiffuseTraceDepth(input.diffuse_trace_depth);
    settings.SetShadow(input.shadows);
    settings.SetAA(input.AA);
    settings.SetIndirrectIllumination(input.indirrectIllum);
    settings.SetEnableRaysCounter(input.drawRayStatInfo);

    settings.SetEnableFG(input.enablePhotonsGartheringDiffuse);
    settings.SetEnableCG(input.enablePhotonsGartheringCaustic);
    settings.SetGartherBounce(input.skipGartherBounce);
    settings.SetStoreBounce(input.skipFirstPhotonBounce);
    settings.SetGartherRadius(input.gartherRadiusDiffuse);
    settings.SetGartherRadiusCaustic(input.gartherRadiusCaustic);
    settings.SetGamma(input.hdrGamma, input.texInGamma);
    settings.enableRecursiveTracing = input.recursiveTracer; // not used now
    settings.causticPower      = input.causticPower;
    settings.ptCaustics        = input.ptCaustics && !input.enablePhotonsGartheringCaustic;
    settings.icBounce          = input.icBounce;
    settings.guidedPathTracing = input.ptGuided;

    if(input.irradianceCacheCalculated) //////////////////////////////////////////////////////////////////// #TEMP !!!
      settings.SetDiffuseTraceDepth(settings.icBounce);

    pRender->DebugCall("SetDebugOputputValue", ToString(int(input.enableDebugOutput)));

    // voxels
    //
    if(input.voxelizeNow == true)
    {
      pRender->DebugCall("voxelizeDebug","");
      input.voxelizeNow = false;
    }

    // simple test for octree paper
    // 
    if(input.transformICToPhMap == true)
    {
      pRender->DebugCall("icToPhMap","");
      input.transformICToPhMap = false;
    }

    // RC
    //
    if(input.computeRadianceCache && !input.radianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->ComputeRadianceCache(input.rcType);
        input.radianceCacheCalculated = true;
      }
    }
    else if(!input.computeRadianceCache && input.radianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        pathTracer->FreeRadianceCache();
        input.radianceCacheCalculated = false;
      }
    }

    // IC
    //
    if(!input.computeIrradianceCache && input.irradianceCacheCalculated)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
        pathTracer->FreeIrradianceCache();

      input.irradianceCacheCalculated = false;
    }
    else if(input.computeIrradianceCache && !input.relightEnabled && !input.irradianceCacheCalculated)
    {
      UpdateProgress("Building Irradiance Cache", 0);

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=0)
      {
        GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;
        pathTracerParams.drawBlocks       = false;
        pathTracerParams.drawRaysStatInfo = false;
        pathTracer->SetRenderingParams(pathTracerParams);

        RAYTR::ICPresets icPresets;

        //std::cerr << "input.icWSErrorTreshold = " << input.icWSErrorTreshold << std::endl;
        icPresets.icWSErrorTreshold       = input.icWSErrorTreshold;
        icPresets.drawICRecords           = input.drawIrradianceCachePixelPoints;
        icPresets.icError                 = input.icErrorWS;
        icPresets.icErrorSS[0]            = input.icErrorSS[0];
        icPresets.icErrorSS[1]            = input.icErrorSS[1];
        icPresets.icErrorSS[2]            = input.icErrorSS[2];
        icPresets.icFixedRays             = input.icFixedRays;
        icPresets.icMaxPasses             = input.icMaxPasses;
        icPresets.icProgressiveEvaluation = input.icProgressiveEvaluation;

        pathTracer->SetICPresets(icPresets);
        pathTracer->ComputeIrradianceCache();
      }

      input.irradianceCacheCalculated = true;
    }

    // Photon maps Debug
    //
    if((input.tracePhotonsDebug || input.tracePhotonsCausticsDebug) && !input.photonTracingFinishedDebug)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if(pathTracer!=NULL)
      {
        GPU_Path_Tracer::PhotonMapPresets presets;

        presets.maxDiffusePhotons     = input.maxDiffusePhotons;
        presets.maxCausticPhotons     = input.maxCausticPhotons;
        presets.progressivePhotonMap  = input.progressivePhotonMap;
        presets.progressiveCausticMap = input.progressiveCausticMap;
        presets.diffuseRetracePass    = input.pmDiffuseRetrace;
        presets.causticRetracePass    = input.pmCausticRetrace;
        presets.disableVisibilityTracing = input.disablePhotonVisibilityTracing;
        presets.alphaC                = input.alpha_c;
        presets.alphaD                = input.alpha_d;
        pathTracer->SetPhotonMapPresets(presets);
      }

      if(input.tracePhotonsDebug)
        pRender->DebugCall("TracePhotonsTest","");
      else
        pRender->DebugCall("TraceCausticPhotonsTest","");

      input.photonTracingFinishedDebug = false;
      input.tracePhotonsDebug = false;
      input.tracePhotonsCausticsDebug = false;
    }

    
    HydraRenderPassState currState = g_state;


    // PT
    //
    if(input.pathTracingEnabled)
    {
      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);

      if(firstPass)
      {
        timer.start();
        firstPass = false;

        if(pathTracer!=NULL)
        {
          GPU_Path_Tracer::PhotonMapPresets presets;

          presets.maxDiffusePhotons        = input.maxDiffusePhotons;
          presets.maxCausticPhotons        = input.maxCausticPhotons;
          presets.progressivePhotonMap     = input.progressivePhotonMap;
          presets.progressiveCausticMap    = input.progressiveCausticMap;
          presets.diffuseRetracePass       = input.pmDiffuseRetrace;
          presets.causticRetracePass       = input.pmCausticRetrace;
          presets.disableVisibilityTracing = input.disablePhotonVisibilityTracing;
          presets.alphaC                   = input.alpha_c;
          presets.alphaD                   = input.alpha_d;

          pathTracer->SetRenderingParams(input.pt_params);
          pathTracer->SetPhotonMapPresets(presets);
        }

       
        if (pathTracer != NULL && ((input.progressivePhotonMap && input.enablePhotonsGartheringDiffuse) || (input.progressiveCausticMap && input.enablePhotonsGartheringCaustic) || currState.state == STATE_PREPARE_PHOTON_MAP) || settings.guidedPathTracing)
        {
          pathTracer->PreparePhotonMaps(settings);
        }

        if(input.buildIrradianceMapNow)
        {
          pathTracer->FreeIrradianceMap();
          pathTracer->BuildIrradianceMap(16);
          input.buildIrradianceMapNow = false;
        }

      }


      if (pathTracer!=NULL)
      {
        GPU_Path_Tracer::RenderingParams pathTracerParams = input.pt_params;

        if(input.inputXML == NULL)
        {
          pathTracerParams.drawBlocks       = input.drawBlocks;
          pathTracerParams.drawRaysStatInfo = input.drawRayStatInfo;
        }

        pathTracer->SetRenderingParams(pathTracerParams);


        // multilayered renderer
        //
        if(input.saveImageLayers)
        {
          settings.SetRenderLayer(currState.layer);
          settings.SetRenderLayerDepth(currState.layerdDepth);

          if(currState.clearNow)
            pathTracer->ResetPathTracing();
        }

        if(currState.state != STATE_PREPARE_PHOTON_MAP)
        {
          pathTracer->BeginPathTracingPass(settings);
          pathTracingFinished = pathTracer->EndPathTracingPass();
        }

        UpdateProgress("Path Tracing", pRender->EtimateTotalRenderingProgress());
        

        bool additionalCondition = (totalFramesCount % 2 == 0);

        if (input.outputImage != NULL && additionalCondition)
          UpdateImage(pRender);

        if(!stopCountTime)
        {
          float timeElaspedPerFrame = timer.getElapsed();
          path_tracing_time  = g_totalTimer.getElapsed();
          lastImageSavedTime = g_totalTimer.getElapsed();
        }


        // save temp image if possible and no shared buffer was provided. do that each 60 seconds;
        //
        if ((g_totalTimer.getElapsed() - lastImageSavedTime2) > 60.0f && !takeImageOutside && input.inOutImageFileName != "" && input.outputImage == NULL)
        {
          std::cout << "input.outputImage == NULL, saving temp image to disk" << std::endl;
          SaveImageFromRender(pRender, path_tracing_time, false, WinWidth, WinHeight);
          lastImageSavedTime2 = g_totalTimer.getElapsed();
        }

        // save final image
        //
        static std::string oldImageName = "";

        if(pathTracingFinished && !stopCountTime || 
          (input.saveImageNow || input.toneMapNow) || // && oldImageName != input.savedImageName
          (input.savePTImagesSequence && lastImageSavedTime > 1000))
        {
          bool saveImages = (g_state.layer == IGraphicsEngine::LAYER_COLOR);

          if(!input.saveImageNow && !pathTracingFinished)
            stopCountTime = true;

          std::cerr << endl;
          pathTracer->PrintStatInfo(std::cerr);

          if((!imageSaved || oldImageName != input.savedImageName))
          {
            if(saveImages)
              SaveImageFromRender(pRender, path_tracing_time, takeImageOutside, WinWidth, WinHeight);

            if(input.outputImage!= NULL)
            {
              WaitForImageBufferIsFree();
              UpdateImage(pRender, NULL, false);
            }

            if(!input.saveImageNow)
            {
              input.saveImageNow = false;
              imageSaved = true;
              stopCountTime = true;
            }
            else
              input.saveImageNow = false;

            if(input.savePTImagesSequence)
            {
              imageSaved    = false;
              stopCountTime = false;
              lastImageSavedTime = 0;
            }

            input.toneMapNow = false;

            oldImageName = input.savedImageName;

          }

        }
      }
    }
    else if (input.relightEnabled)
    {
      pReLightApp->DoRendering("out_relight_data");
      input.relightEnabled = false;
      exit(0);
    }
    else
    {
      pathTracingFinished = false;
      firstPass = true;
      FPS = 60;
      path_tracing_time = 0.0f;
      stopCountTime = false;
      takeImageOutside = false;

      GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
      if (pathTracer!=0)
        pathTracer->ResetPathTracing();
      imageSaved = false;

      pRender->BeginDrawScene(settings); 

      OpenGL_Render* pCGE = dynamic_cast<OpenGL_Render*>(pRender);
      if(pCGE!=0)
      {
        pCGE->SetDebugDrawIndex(input.m_debugIndex);
      }

      pRender->EndDrawScene();
    }

    if(input.saveImageWithReadPixels)
    {
      unsigned int* data = new unsigned int[WinWidth*WinHeight];
      glReadPixels(0,0,WinWidth,WinHeight,GL_RGBA, GL_UNSIGNED_BYTE, data);

      SaveImageToFile("ic_records.png", WinWidth,WinHeight, data);

      delete [] data;
      input.saveImageWithReadPixels = false;
    }

    //if(input.showToneMappedImage && input.pathTracingEnabled && dst.GetPointer() != NULL)
      //glDrawPixels(WinWidth, WinHeight, GL_RGB, GL_FLOAT, dst.GetPointer());
    
    if(pControlState != NULL)
      g_state = pControlState->NextState(currState, pathTracingFinished); // when automatic control with state machines used


    // multilayered renderer
    //
    if(input.saveImageLayers && g_state.clearNow || input.saveImageLayers && (g_state.state == STATE_POST_PROCESS))
    {
      float4* g_imageMem = NULL;

      try
      {
        std::string name = std::string("C:\\[Hydra]\\filter\\input_bin\\") + ImageLayerName(currState) + ".imagef4";
        g_imageMem = new float4[WinWidth*WinHeight];

        pRender->GetHDRImage(g_imageMem);

        SaveFloat4ImageDump(WinWidth, WinHeight, g_imageMem, name);
        delete [] g_imageMem; g_imageMem = NULL;

        GPU_Path_Tracer* pathTracer = dynamic_cast<GPU_Path_Tracer*>(pRender);
        if(pathTracer != NULL && currState.layer == IGraphicsEngine::LAYER_NORMALS)
        {
          pathTracer->SaveMultyLayeredSubSamples("C:\\[Hydra]\\filter\\input_bin\\layer_0_8_subsamples.imagef4", 
                                                 "C:\\[Hydra]\\filter\\input_bin\\bad_pixels.arrayi2"); // ------->> compute image subsamples for boundary pixels
        }

      }
      catch(...)
      {
        delete [] g_imageMem; g_imageMem = NULL;
        throw;
      }
    }


    if(!input.noWindow)
      glutSwapBuffers();
    
    input.reset();
  }
  catch(std::bad_alloc e)
  {
    cerr << std::endl;
    string err_msg = NotEnoughMemory();
    ALERT(err_msg);
    cout << err_msg << endl; 
    exit(-1);
  }
  catch(const std::runtime_error& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(const std::exception& e)
  {
    cerr << std::endl;
    cerr << e.what() << endl; 
    exit(-1);
  }
  catch(...)
  {
    cerr << std::endl;
    cout << "Unexpected Exception!" << endl;
    exit(-1);
  }

  // -----------------------  �������� �E������ FPS. -----------------------
  totalFramesCount++;
  FramesCount++;
  if(FramesCount > 1)
  {
    FPS = float(FramesCount)/(timer.getElapsed());
    FramesCount=0;
    timer.start();

    if(!input.noWindow)
    {
      char Title[64];

      if(!input.pathTracingEnabled)
        sprintf(Title, "FPS=%.1f", FPS);
      else if (!pathTracingFinished)
        sprintf(Title, "path tracing: %.2f sec", path_tracing_time);
      else
        sprintf(Title, "path tracing: %.2f sec, finished!", path_tracing_time);

      glutSetWindowTitle(Title);
    }
  }

  //\\ -----------------------  �������� �E������ FPS. -----------------------
}

void Reshape(int Width, int Height) 
{
  if(exitNow)
    return;

  int widthClamped  = Width; //Width + (16 - Width%16);
  int heightClamped = Height; //Height + (16 - Height%16);

  if (Width % 16 != 0)
    widthClamped = Width + (16 - (Width%16));

  if (Height % 16 != 0)
    heightClamped = Height + (16 - (Height%16));

  if(cam == NULL || pRender == NULL)
    return;

  cam->SetPerspectiveProjection(cam->GetFOV(), float(widthClamped)/float(heightClamped), cam->GetNearClipPlane(), cam->GetFarClipPlane());
  pRender->SetWindowResolution(widthClamped, heightClamped);

  WinWidth  = widthClamped;
  WinHeight = heightClamped;
  input.ext_width  = widthClamped;
  input.ext_height = heightClamped;
}




void Mouse(int button, int state, int x, int y) { input.Mouse(button,state,x,y); glutPostRedisplay(); }
void MouseMotion(int x, int y) { input.MouseMotion(x,y); glutPostRedisplay(); }
void Keyboard(unsigned char key,int x,int y){ input.Keyboard(key,x,y); glutPostRedisplay();}   //�E��E
void KeyboardSpecial(int key, int x, int y) { input.KeyboardSpecial(key,x,y); glutPostRedisplay();  }   // ���� �E��E
void Idle() { Display(); glutPostRedisplay(); } 

