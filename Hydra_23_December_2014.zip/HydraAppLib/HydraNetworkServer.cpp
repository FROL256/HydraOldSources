#include "HydraNetwork.h"
#include "Input.h"

struct ServerShmemView : public IHydraNetServerAPI
{
  ServerShmemView(const char* a_data, unsigned int a_size);
  ~ServerShmemView();

  void sendToPlugin(const char* a_data, unsigned int a_size);

  bool haveAnyMessageFromPlugin();
  unsigned int recieveFromPlugin(char* a_data, unsigned int a_maxSize);

  int getImageType() const;

  bool  imageWasRead();
  void* mapImageData();
  void  unmapImageData();

  void* mapImageDataHDR();
  void  unmapImageDataHDR();

protected:

};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

extern Input input;  


ServerShmemView::ServerShmemView(const char* a_data, unsigned int a_size)
{

}


ServerShmemView::~ServerShmemView()
{

}


void ServerShmemView::sendToPlugin(const char* a_message, unsigned int a_size)
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.messages;

  char* messageData = input.messages + sizeof(SharedBufferDataInfo);
  memset(messageData, 0, 1024);
  memcpy(messageData, a_message, a_size);

  pInfo->width   = strlen(a_message)+1;
  pInfo->height  = 1;
  pInfo->read    = 0;
  pInfo->written = HYDRA_SERVER_ID;
}

bool ServerShmemView::haveAnyMessageFromPlugin()
{
  return false;
}

unsigned int ServerShmemView::recieveFromPlugin(char* a_data, unsigned int a_maxSize)
{
  return 0;
}

bool  ServerShmemView::imageWasRead()
{
  return false;
}

void* ServerShmemView::mapImageData()
{
  return NULL;
}

void  ServerShmemView::unmapImageData()
{

}


void* ServerShmemView::mapImageDataHDR()
{
  return NULL;
}

void  ServerShmemView::unmapImageDataHDR()
{

}


int ServerShmemView::getImageType() const
{
  return SEND_IMAGE_LDR;
}


bool RenderWasCanceledByUser()
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.messages;

  char* messageData = input.messages + sizeof(SharedBufferDataInfo);

  if(!strcmp(messageData, "CancelRender") && pInfo->written == HYDRA_PLUGIN_ID)
    return true;

  return false;
}


void SendToPlugin(const char* a_message)
{
  SharedBufferDataInfo* pInfo = (SharedBufferDataInfo*)input.messages;

  char* messageData = input.messages + sizeof(SharedBufferDataInfo);
  if(a_message == NULL || input.messages == NULL)
    return;

  memset(messageData, 0, 1024);
  strcpy(messageData, a_message);

  pInfo->width   = strlen(a_message)+1;
  pInfo->height  = 1;
  pInfo->read    = 0;
  pInfo->written = HYDRA_SERVER_ID;
}
