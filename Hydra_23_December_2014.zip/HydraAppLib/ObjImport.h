#include "../gpu_rt/IGraphicsEngine.h"

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include <iostream>

void AddMeshFromOBJ(const std::string& a_fileName, IGraphicsEngine* pRender, const Matrix4x4f& a_mat);
void AddMeshFromOBJ(GLMmodel* pmodel1, IGraphicsEngine* pRender, const Matrix4x4f& a_mat, int a_externMatId = -1);

