#include "hydraRender mk3.h"
#include <hash_map>


inline float hordToSectorScale(float fov, float aspect)
{
  float angle        = fov;
  float sectorLength = angle*PI/180.0f;
  float hordLength   = 2.0f*sin(DEG_TO_RAD*angle*0.5f);
  float hordToSector = hordLength/sectorLength;
  float magicScale   = aspect/hordToSector;
  return magicScale*fov;
}


inline float tanScale(float fov, float aspect)
{
  float x  = tan(fov*DEG_TO_RAD);
  return atan(x*aspect)*RAD_TO_DEG; 
}


void hydraRender_mk3::ExtractCamObject(INode* node, CameraObj* cam, TimeValue t)
{
  /*TimeValue t = GetStaticFrame();
  Interval valid = FOREVER;*/

	//TimeValue t;
	//Point3 trans;
	Matrix3 pmat, pmatT;
	Interval ivalid;
	int tpf = GetTicksPerFrame();
	int start = GetCOREInterface()->GetAnimRange().Start() / tpf,
		end = GetCOREInterface()->GetAnimRange().End() / tpf;

  CameraObject* camera = (CameraObject*)(node->GetObjectRef());
  INode* targetNode = (camera->ClassID().PartA() == LOOKAT_CAM_CLASS_ID) ? node->GetTarget() : NULL;

  if(camera == NULL || cam == NULL)
    return;

  cam->camName = node->GetName();


  if(targetNode != NULL)
  {
    Matrix3 pivot = toMeters(targetNode->GetObjectTM(t));
    MaxMatrix3ToFloat16(pivot, cam->targetMatrix);
  }
  else
  {
    Point3 camDirPoint = node->GetNodeTM(t).GetRow(2);
    cam->direction[0] = -camDirPoint.x;
    cam->direction[1] = -camDirPoint.y;
    cam->direction[2] = -camDirPoint.z;
  }
  cam->isTargeted = (targetNode != NULL);

  if(node != NULL)
  {
    Matrix3 pivot = toMeters(node->GetObjectTM(t));
    MaxMatrix3ToFloat16(pivot, cam->posMatrix);

    // For the CameraObject class, the transform for the node to which it is attached is used instead,  // THIS CODE IS A PIECE OF NOT WORKING SHIT!
    // whose inverse becomes the view transform matrix.
    //
    Matrix3 worldViewInv = pivot;
    Matrix3 worldView    = Inverse(worldViewInv);
    MaxMatrix3ToFloat16(worldView, cam->worldViewMatrix);
  }

  cam->isOrtho = camera->IsOrtho(); 

  const unsigned int PBLOCK_REF = 0;   // This is a IParamBlock, not a IParamBlock2.
  const unsigned int DOF_REF = 1;
  const unsigned int MP_EFFECT_REF = 2;

  // Parameter block indices
  //
  const unsigned int FOV = 0;             // float
  const unsigned int TARGET_DISTANCE = 1; // float
  const unsigned int NEAR_CLIP  = 2;      // float
  const unsigned int FAR_CLIP   = 3;      // float
  const unsigned int NEAR_RANGE = 4;      // float
  const unsigned int FAR_RANGE  = 5;      // float
  const unsigned int MULTI_PASS_EFFECT_ENABLE = 6;  // bool
  const unsigned int MULTI_PASS_EFFECT_RENDER_EFFECTS_PER_PASS = 7; // bool
  const unsigned int FOV_TYPE = 8;        // int

  IParamBlock* parameters = (IParamBlock*)(camera->GetReference(PBLOCK_REF));

  if(parameters == NULL)
    return; 
	
	float derp = GetCOREInterface()->GetRendApertureWidth();

	derp;

  cam->fov           = camera->GetFOV(t, ivalid)*RAD_TO_DEG; //parameters->GetFloat(FOV)*RAD_TO_DEG;
  cam->nearClipPlane = toMeters(parameters->GetFloat(NEAR_CLIP));
  cam->farClipPlane  = toMeters(parameters->GetFloat(FAR_CLIP));

  int renderWidth  = rendParams.nMaxx - rendParams.nMinx; // don't work!
  int renderHeight = rendParams.nMaxy - rendParams.nMiny;
	/*
  if(renderWidth != renderHeight) // it seems that when this is happend 3ds max assume spherical screen, not planar
  {
    float aspect = float(renderHeight)/float(renderWidth);
    cam->fov = hordToSectorScale(cam->fov, aspect); 
  }
	*/
	Matrix3 mConv;
	mConv = getConversionMatrix();

	Point3 maxPos, maxPosT;
	Point3 pos, target, dir;

	
	/*
	if (rendParams.rendTimeType != REND_TIMESINGLE)
	{
		cam->isAnimated = true;
		cam->frames = end - start;

		
		//plugin_log.Print("CAMERA****************************\n");
		for (int f = start; f <= end; f++)
		{
			std::ostringstream stringStream;
			t = f*tpf;
			ivalid = FOREVER;
			pmat = toMeters(node->GetParentTM(t));
			pmatT = toMeters(targetNode->GetParentTM(t));
			//pmat = node->GetObjectTM(t);

			node->GetTMController()->GetValue(t, &pmat, ivalid, CTRL_RELATIVE);
			targetNode->GetTMController()->GetValue(t, &pmatT, ivalid, CTRL_RELATIVE);
			//trans = toMeters(pmat.GetTrans());

			maxPos = toMeters(Point3(0, 0, 0)*pmat);
			pos = maxPos*mConv;

			maxPosT = toMeters(Point3(0, 0, 0)*pmatT);
			target = maxPosT*mConv;

			dir = (Point3(cam->direction[0], cam->direction[1], cam->direction[2]).Normalize())*mConv;

			if (!cam->isTargeted)
				target = pos + 100.0f*dir;
			
			//stringStream << "Position at frame: " << f << " out of " << end << " =( " << trans.x << ", " << trans.y << ", " << trans.z << ")\n";
			//stringStream << "Position at frame: " << f << " out of " << end << " =( " << pos.x << ", " << pos.y << ", " << pos.z << ")\n";
			//plugin_log.Print(stringStream.str());


			//stringStream << std::endl;
			//stringStream << "    <frame>" << std::endl;
			stringStream << "    <position> " << pos.x << " " << pos.y << " " << pos.z << "  </position>" << std::endl;
			stringStream << "    <look_at> " << target.x << " " << target.y << " " << target.z << "  </look_at>" << std::endl;
			//stringStream << "    </frame>" << std::endl;
			//stringStream << "Position at frame: " << f << " out of " << end << " =( " << pos.x << ", " << pos.y << ", " << pos.z << ")\n";	
			cam->perFrame.push_back(stringStream.str());
		}
		//plugin_log.Print("****************************CAMERA\n");
		//cam->animMatrices = stringStream.str();
	}*/
	/*else
	{
		Matrix3 camTransform, camTransformT;

		camTransform = Float16ToMaxMatrix3(cam->posMatrix);
		camTransformT = Float16ToMaxMatrix3(cam->targetMatrix);

		Point3 maxPos, maxPosT;
		maxPos = Point3(0, 0, 0)*camTransform;
		maxPosT = Point3(0, 0, 0)*camTransformT;

		Point3 pos, target, dir;
		pos = maxPos*mConv;
		target = maxPosT*mConv;
		dir = (Point3(cam->direction[0], cam->direction[1], cam->direction[2]).Normalize())*mConv;

		if (!cam->isTargeted)
			target = pos + 100.0f*dir;

		std::ostringstream stringStream;

		stringStream << "    <position> " << pos.x << " " << pos.y << " " << pos.z << "  </position>" << std::endl;
		stringStream << "    <look_at> " << target.x << " " << target.y << " " << target.z << "  </look_at>" << std::endl;
		cam->perFrame.push_back(stringStream.str());
	}*/

}


CameraObj hydraRender_mk3::ExtractCamObjFromMaxViewPortWindow(INode *vnode, ViewParams* a_viewParams, TimeValue t)
{
  CameraObj cam;

  if(vnode != NULL)
  {
    ObjectState os;
    os = vnode->EvalWorldState(0);

    if(os.obj->SuperClassID() == CAMERA_CLASS_ID)
      ExtractCamObject(vnode, &cam, t);
  }
  else
  {
    ViewExp& viewExp = GetCOREInterface()->GetActiveViewExp();
   
    if (viewExp.IsPerspView() || (a_viewParams == NULL))
    {
       cam.camName = L"maxViewPort2";
       cam.isOrtho = !viewExp.IsPerspView();
       cam.fov     = viewExp.GetFOV()*RAD_TO_DEG;

       Matrix3 aTM, coordSysTM;
       viewExp.GetAffineTM(aTM);
       coordSysTM = Inverse(aTM);
       
       Point3 viewDir, viewPos;
       viewDir = ::Normalize(coordSysTM.GetRow(2));
       viewPos = toMeters(coordSysTM.GetRow(3));

       cam.direction[0] = -viewDir.x;
       cam.direction[1] = -viewDir.y;
       cam.direction[2] = -viewDir.z;
       cam.isTargeted   = false;

       Matrix3 posMatrix(1);
       posMatrix.SetRow(3, viewPos);

       MaxMatrix3ToFloat16(posMatrix, cam.posMatrix);
    }
    else if (a_viewParams != NULL)
    {
      cam.camName = L"maxViewPort";
      MaxMatrix3ToFloat16(a_viewParams->affineTM, cam.worldViewMatrix);

      cam.fov  = a_viewParams->fov*RAD_TO_DEG;
      cam.zoom = a_viewParams->zoom;
    }

  }

  return cam;
}


void hydraRender_mk3::ExportCamerasXML(std::ofstream& xmlFile, const std::vector<CameraObj>& cameras, TimeValue t)
{
  Matrix3 mConv;
  mConv = getConversionMatrix();

  xmlFile << "<library_cameras>\n";

	for (size_t i = 0; i < cameras.size(); i++)
	{
		const CameraObj& camera = cameras[i];

		std::string camName = ToNarrowString(camera.camName);

		xmlFile << std::endl;
		xmlFile << "  <camera name = \"" << camName.c_str() << "\"> " << std::endl;

		xmlFile << std::endl;
		xmlFile << "    <fov> " << camera.fov << " </fov>" << std::endl;
		xmlFile << "    <nearClipPlane> " << camera.nearClipPlane << " </nearClipPlane>" << std::endl;
		xmlFile << "    <farClipPlane> " << camera.farClipPlane << " </farClipPlane>" << std::endl;
		xmlFile << "    <zoom> " << camera.zoom << " </zoom>" << std::endl;


		if (camera.dofEnabled)
		{
			xmlFile << std::endl;
			xmlFile << "    <DOF> " << std::endl;
			xmlFile << "      <focal_dist> " << camera.dofFocalDist << " </focal_dist>" << std::endl;
			xmlFile << "      <strength> " << camera.dofStrength << " </strength>" << std::endl;
			xmlFile << "    </DOF> " << std::endl;
		}


		int tpf = GetTicksPerFrame();
		int start = GetCOREInterface()->GetAnimRange().Start() / tpf,
			end = GetCOREInterface()->GetAnimRange().End() / tpf;

		xmlFile << std::endl;
		xmlFile << "    <up> " << 0.0f << " " << 1.0f << " " << 0.0f << "  </up>" << std::endl;

		if (camera.perFrame.size() == 0)
		{
			Matrix3 camTransform, camTransformT;

			camTransform = Float16ToMaxMatrix3(camera.posMatrix);
			camTransformT = Float16ToMaxMatrix3(camera.targetMatrix);

			Point3 maxPos, maxPosT;
			maxPos = Point3(0, 0, 0)*camTransform;
			maxPosT = Point3(0, 0, 0)*camTransformT;

			Point3 pos, target, dir;
			pos = maxPos*mConv;
			target = maxPosT*mConv;
			dir = (Point3(camera.direction[0], camera.direction[1], camera.direction[2]).Normalize())*mConv;

			if (!camera.isTargeted)
				target = pos + 100.0f*dir;

			xmlFile << "    <position> " << pos.x << " " << pos.y << " " << pos.z << "  </position>" << std::endl;
			xmlFile << "    <look_at> " << target.x << " " << target.y << " " << target.z << "  </look_at>" << std::endl;
		}
		else
		{
			xmlFile << camera.perFrame.at(t / tpf - start);
		}
		xmlFile << "    <animated> " << camera.isAnimated << "    </animated> " << std::endl;
		

		xmlFile << std::endl;
    xmlFile << "  </camera>" << std::endl;

  }

  xmlFile << std::endl;
  xmlFile << "</library_cameras>\n";
}


