#include "hydraRender mk3.h"

#include <MeshNormalSpec.h>
#include <mentalray/imrPhysicalSkyEnvironmentMap.h>

#include <hash_map>
#include <map>
#include <sys/stat.h>
#include <time.h>

static BOOL exportSelected;


void hydraRender_mk3::writeXML(TimeValue t)
{
	std::ofstream xmlFile;
	xmlFile.open(incl.colladaProfile.c_str());

	if (!xmlFile.is_open())
	{
		plugin_log.PrintValue(incl.colladaProfile, "could not create XML export file");
		return;
	}

	xmlFile << "<?xml version=\"1.0\" encoding=\"utf-8\"?>" << std::endl;
	xmlFile << "<COLLADA profile=\"HydraProfile\">" << std::endl;

	ExportMaterialsXML(xmlFile, materials);
	ExportLightsXML(xmlFile, lights);
	ExportCamerasXML(xmlFile, cameras, t);

	//geomMD5

	xmlFile << std::endl;
	xmlFile << "<library_geometry>" << std::endl;
	xmlFile << "  <geom_md5hash>   " << geomMD5.c_str() << " </geom_md5hash>" << std::endl;
	xmlFile << "  <lights_md5hash> " << lightsMD5.c_str() << " </lights_md5hash>" << std::endl;
	xmlFile << "  <matg_md5hash>   " << matGMD5.c_str() << " </matg_md5hash>" << std::endl;
	xmlFile << "</library_geometry>" << std::endl;

	xmlFile << std::endl;
	xmlFile << "</COLLADA>\n";


	xmlFile.flush();
	xmlFile.close();
}

int	hydraRender_mk3::DoExport(INode* root, INode *vnode, ViewParams* a_viewParams, TimeValue t)
{
  incl.IncludeAdd(); // temporary solution while our guis is down

  plugin_log.Print("Entering HydraRender::DoExport");

  // clear all states
  //
  materialByAddress.clear();
  material_dict_max_index.clear();
  mtlList.Clear();

  geomMD5   = "";
  lightsMD5 = "";

  nTotalNodeCount = 0;
  nCurNode = 0;
 
  PreProcess(root, nTotalNodeCount);	

	cameras.clear();
	materials.clear();
	lights.clear();

  materials.reserve(1000);
  lights.reserve(100);
  

  cameras.push_back( ExtractCamObjFromMaxViewPortWindow(vnode, a_viewParams, t) ); // add first cam from active Max ViewPort

  // extract spheres, geometry(right now it is packed directy to boost archive), materials and lights from max
  //

  {
    ExtractMaterialList(&materials);
		plugin_log.Print("after extract material list");
	
    incl.geomObjNum = ExtractAndDumpSceneData(materials, lights, cameras, root, t);
  }

  int q = createProcTextures();

	int i = 0;
	for (auto& thread : threads)
	{
		plugin_log.PrintValue("Waiting for threads: ", i);
		i++;
		thread.join();
	}
	//WaitForMultipleObjects(q, hThreadArray, TRUE, INFINITE);

  plugin_log.Print("before MD5");

	checkProcTexMD5(&materials);

	plugin_log.Print("Proc tex threads done.");
	/*
	for(int i=0; i<q; i++)
  {
      CloseHandle(hThreadArray[i]);
  }*/
	threads.clear();

  // export materials, light and cameras to XML
  //
  {
		writeXML(GetCOREInterface()->GetTime());
  }

  std::wstring configFile(L"C:/[Hydra]/pluginFiles/hydra.CONF");

  if(!CreateConfigFile(configFile))
  {
    plugin_log.Print("Config file creation failed");
    return 0;
  }

  if(!FileTransfer(configFile))
  {
    plugin_log.Print("Config file transfer failed");
    return 0;
  }


  std::wstring path = GetCOREInterface()->GetCurFilePath();

  std::wstring sceneFileName = GetCOREInterface()->GetCurFileName();

  size_t found = path.find(sceneFileName);
  if (found != std::wstring::npos)
    path.erase(found, sceneFileName.size());

 
  std::set<std::wstring> transferedTextures;

  std::vector<MaterialObj>::iterator mat;
  for(mat = materials.begin(); mat != materials.end(); ++mat)
  {
    std::vector<TextureObj>::iterator tex;
    for(tex = mat->textures.begin(); tex != mat->textures.end(); ++tex)
    {
      if( (tex->mapName != L"") && (transferedTextures.find(tex->mapName) == transferedTextures.end()) )
      { 

        size_t found;
        found = tex->mapName.find_last_of(L"/\\");
        
        std::wstring texFilePath = path + tex->mapName.substr(found+1);

        std::wstring header(L"C:/[Hydra]/pluginFiles/"+tex->mapName.substr(found+1)+L".hhh");

        if(!CreateHeaderFile(header, L"TEXTURE_FILE"))
        {
          plugin_log.PrintValue("Texture file header file not created:", ws2s(tex->mapName));
          return 0;
        }

        if(!FileTransfer(header))
        {
          plugin_log.Print("Texture file header transfer failed");
          return 0;
        }      

        plugin_log.PrintValue("Start sending texture file: ", ToNarrowString(texFilePath));
        if(!FileTransfer(texFilePath))
        {
          plugin_log.Print("Texture file header transfer failed");
          plugin_log.PrintValue("Missing texture file: ", ToNarrowString(texFilePath));
          return 0;
        }

        transferedTextures.insert(tex->mapName);
      }
    }
  }
  
  plugin_log.Print(std::string("incl.colladaProfile = ") + incl.colladaProfile);

 
  
  std::wstring header(s2ws(incl.colladaProfile)+L".hhh");

  if(!CreateHeaderFile(header, L"COLLADA_PROFILE"))
  {
    plugin_log.Print("Collada profile header file not created");
    return 0;
  }

  if(!FileTransfer(header))
  {
    plugin_log.Print("Collada profile header transfer failed");
    return 0;
  }

  if( !FileTransfer(s2ws(incl.colladaProfile)) )
  {
    plugin_log.Print("Collada profile file transfer failed");
    return 0;
  }

  if( !FileTransfer(s2ws(incl.sceneDumpName)) )
  {
    plugin_log.Print("Scene file transfer failed");
    return 0;
  }

  plugin_log.Print("Leaving HydraRender::DoExport");

  return 1;
}


int hydraRender_mk3::CreateConfigFile(std::wstring name)
{
  plugin_log.Print("Creating config file");

  std::ofstream configFile;
  configFile.open (name.c_str(), std::ios_base::binary);
  if(configFile.fail())
  {
    system("mkdir C:/[Hydra]/pluginFiles");
    configFile.open(name.c_str(), std::ios_base::binary);

    if(configFile.fail())
    {
      plugin_log.Print("Could not create config file");
      return 0;
    }
  }

  configFile.close();
  plugin_log.Print("Config file created");

  return 1;
}


int hydraRender_mk3::CreateHeaderFile(std::wstring name, std::wstring type)
{
  return 1;
}


int hydraRender_mk3::ExtractAndDumpSceneData(std::vector<MaterialObj> &materials, std::vector<LightObj> &lights, 
																												std::vector<CameraObj>& cameras, INode* root, TimeValue t)
{
  int numChildren = root->NumberOfChildren();

  plugin_log.Print("Exporting & creating scene dump");

  /*SetConsoleCP(1251);
  SetConsoleOutputCP(1251);
  setlocale(LC_CTYPE,"Russian");*/

  std::ofstream dump;
  //plugin_log.PrintValue("incl.sceneDumpName: ", incl.sceneDumpName);
  //std::string temp_str(incl.sceneDumpName.begin(), incl.sceneDumpName.end());
  //std::string temp_str = ws2s(incl.sceneDumpName);
  //std::string temp_str = ToNarrowString(incl.sceneDumpName);
  //plugin_log.PrintValue("temp_str: ", temp_str);
  //plugin_log.PrintValue("temp_str.c_str: ", temp_str.c_str());

 // plugin_log.PrintValue("incl.sceneDumpName: ", incl.sceneDumpName);
  //plugin_log.PrintValue("incl.sceneDumpName.c_str: ", incl.sceneDumpName.c_str());


  TransferContents transferScene;
  transferScene.contents = transferScene.SCENE;

  int geomObjNum = 0;
	unsigned int allVerticesNum = 0;
	unsigned int allIndicesNum = 0;

	clock_t start, finish;
	start = clock();

	for (int idx=0; idx<numChildren; idx++) 
  {
		nodeEnumCheckGeometry(root->GetChildNode(idx), allVerticesNum, allIndicesNum, t);
  }


	vsgfFileSize = allVerticesNum*( sizeof(float)*4*2 + sizeof(float)*2 );
  vsgfFileSize += (allIndicesNum/3)*4*sizeof(unsigned int);

	plugin_log.PrintValue("Total vertices number: ", allVerticesNum);
	plugin_log.PrintValue("Total indeces number: ", allIndicesNum);

	std::ofstream fout(vsgfFilename.c_str(), std::ios::out | std::ios::binary);

  writeInit(fout, allVerticesNum, allIndicesNum);


	int vertWritten = 0;

	if(rendParams.writeToDisk)
	{
		pos_out.open(posFilename.c_str(), std::ios::out | std::ios::binary);
		norm_out.open(normFilename.c_str(), std::ios::out | std::ios::binary); 
		tex_out.open(texFilename.c_str(), std::ios::out | std::ios::binary);
		v_ind_out.open(vIndFilename.c_str(), std::ios::out | std::ios::binary);
		m_ind_out.open(mIndFilename.c_str(), std::ios::out | std::ios::binary);
	}
	else
	{
		pos_out_v.reserve(allVerticesNum*4);
		norm_out_v.reserve(allVerticesNum*4);
		tex_out_v.reserve(allVerticesNum*2);
		v_ind_out_v.reserve(allVerticesNum); 
		m_ind_out_v.reserve(allVerticesNum/3);
	}

	
  for (int idx=0; idx<numChildren; idx++) 
    nodeEnum(root->GetChildNode(idx), &lights, &cameras, geomObjNum, vertWritten, t);


  hashwrapper *h = new md5wrapper();
  h->resetContext();

	if(rendParams.writeToDisk)
	{
		pos_out.flush();
		pos_out.close();
		norm_out.flush();
		norm_out.close();
		tex_out.flush();
		tex_out.close();
		v_ind_out.flush();
		v_ind_out.close();
		m_ind_out.flush();
		m_ind_out.close();
		std::ifstream pos_in(posFilename.c_str(), std::ios::in | std::ios::binary);
		std::ifstream norm_in(normFilename.c_str(), std::ios::in | std::ios::binary); 
		std::ifstream tex_in(texFilename.c_str(), std::ios::in | std::ios::binary);
		std::ifstream v_ind_in(vIndFilename.c_str(), std::ios::in | std::ios::binary);
		std::ifstream m_ind_in(mIndFilename.c_str(), std::ios::in | std::ios::binary);
	
		writeFinal(fout, pos_in, norm_in, tex_in, v_ind_in, m_ind_in, allVerticesNum, allIndicesNum);

		pos_in.close();
		norm_in.close();
		tex_in.close();
		v_ind_in.close();
		m_ind_in.close();
	}
	else
	{
    h->updateContext((unsigned char*) &pos_out_v[0], pos_out_v.size()*sizeof(float));
    //h->updateContext((unsigned char*) &norm_out_v[0], norm_out_v.size()*sizeof(float));
    //h->updateContext((unsigned char*) &tex_out_v[0], tex_out_v.size()*sizeof(float));
    h->updateContext((unsigned char*) &v_ind_out_v[0], v_ind_out_v.size()*sizeof(int));
    //h->updateContext((unsigned char*) &m_ind_out_v[0], m_ind_out_v.size()*sizeof(int));

		writeVectorFinal(fout, pos_out_v, norm_out_v, tex_out_v, v_ind_out_v, m_ind_out_v, allVerticesNum, allIndicesNum);

		pos_out_v.clear();
		norm_out_v.clear();
		tex_out_v.clear();
		v_ind_out_v.clear();
		m_ind_out_v.clear();
	}

	plugin_log.Print(".vsgf written");

	fout.flush();
  fout.close();
 
	//geomMD5 = h->getHashFromFile(vsgfFilename);
  geomMD5 = h->hashIt();
	delete h; h = NULL;

	finish = clock();

	float tt = (float)((finish - start)/CLOCKS_PER_SEC);
	float tt2 = (float)(finish - start);
	plugin_log.PrintValue("geometry export time: ", tt);
	plugin_log.PrintValue("geometry export time (clocks): ", tt2);
	

  // trying to get Environment settings and push them to Sky Light
  //
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  TimeValue t      = GetStaticFrame();
  Texmap* envMap   = GetCOREInterface()->GetEnvironmentMap();
  BOOL    useMap   = GetCOREInterface()->GetUseEnvironmentMap();
  Point3 bgColor   = GetCOREInterface()->GetBackGround(t, FOREVER);	
  Point3 amColor   = GetCOREInterface()->GetAmbient(t, FOREVER);	
  Point3 tIntColor = GetCOREInterface()->GetLightTint(t, FOREVER);
  float  tIntLevel = GetCOREInterface()->GetLightLevel(t, FOREVER);

  if(envMap != NULL)
  {
    BaseInterface* envMapInterface = envMap->GetInterface(IID_MR_PHYSICAL_SKY_ENV_MAP);
    IMRPhysicalSkyEnvironmentMap* mrEnvMap = dynamic_cast<IMRPhysicalSkyEnvironmentMap*>(envMapInterface);

    if(mrEnvMap == NULL)
      plugin_log.Print("mental ray EnvironmentMap == NULL");
    else
      plugin_log.Print("mental ray EnvironmentMap is ok");
  }

  LightObj* pEnvLight = FindEnvLight(lights);  // find existing skylight or make a new one if none is found

  if(pEnvLight != NULL)
  {
    if (!pEnvLight->useSeparateDiffuseLight)
    {
      pEnvLight->colorSecondary[0] = pEnvLight->color[0] * pEnvLight->intensity; // move original skylight color to secondary color
      pEnvLight->colorSecondary[1] = pEnvLight->color[1] * pEnvLight->intensity;
      pEnvLight->colorSecondary[2] = pEnvLight->color[2] * pEnvLight->intensity;
    }

    pEnvLight->color[0]  = bgColor.x*rendParams.env_mult;                                        // put environment color here
    pEnvLight->color[1]  = bgColor.y*rendParams.env_mult;
    pEnvLight->color[2]  = bgColor.z*rendParams.env_mult;

    pEnvLight->envTexAmt = 1.0f;
    pEnvLight->intensity = 1.0; 

    if(envMap != NULL && useMap && envMap->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00))
    {
      BitmapTex* pBitBapEnv = dynamic_cast<BitmapTex*>(envMap);
      if(pBitBapEnv != NULL)
      {
        TextureOutput* pTexOut = pBitBapEnv->GetTexout();
        StdTexoutGen* pGen = dynamic_cast<StdTexoutGen*>(pTexOut); 
        
        float outputAmount = 1.0f;
        if(pGen != NULL)
          outputAmount = pGen->GetOutAmt(t);

        pEnvLight->color[0]  = 1.0f*outputAmount*rendParams.env_mult;
        pEnvLight->color[1]  = 1.0f*outputAmount*rendParams.env_mult;
        pEnvLight->color[2]  = 1.0f*outputAmount*rendParams.env_mult;
        pEnvLight->envTexturePath = pBitBapEnv->GetMapName();
				pEnvLight->envTextureSampler = ExportTextureSamplerStr(pBitBapEnv->GetUVGen());
      }
    }
  }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


  IFileResolutionManager* pFRM = IFileResolutionManager::GetInstance();

  for(int i=0;i<lights.size();i++) // Tint-ing all lights and fix their tex path
  {
    if(lights[i].lightType == L"SKY")
    {
      lights[i].envTexturePath          = ToWideString(GetCorrectTexPath(lights[i].envTexturePath.c_str(), pFRM));
      lights[i].envTexturePathSecondary = ToWideString(GetCorrectTexPath(lights[i].envTexturePathSecondary.c_str(), pFRM));

      lights[i].colorSecondary[0] *= tIntColor.x*tIntLevel;
      lights[i].colorSecondary[1] *= tIntColor.y*tIntLevel;
      lights[i].colorSecondary[2] *= tIntColor.z*tIntLevel;
    }
    else if(lights[i].lightType == L"SKY_PORTAL")
    {
      lights[i].skyPortalEnvTex = ToWideString(GetCorrectTexPath(lights[i].skyPortalEnvTex.c_str(), pFRM));
    }
    else
    {
      lights[i].color[0]  *= tIntColor.x;
      lights[i].color[1]  *= tIntColor.y;
      lights[i].color[2]  *= tIntColor.z;
      lights[i].intensity *= tIntLevel;
    }
  }

  return geomObjNum;

}




void MaxMatrix3ToFloat16(const Matrix3& pivot, float* m)
{
  Point3 row1, row2, row3, row4;

  row1 = pivot.GetRow(0);
  row2 = pivot.GetRow(1);
  row3 = pivot.GetRow(2);
  row4 = pivot.GetRow(3);

  m[0] = row1[0];
  m[1] = row1[1];
  m[2] = row1[2];
  m[3] = 0;

  m[4] = row2[0];
  m[5] = row2[1];
  m[6] = row2[2];
  m[7] = 0;

  m[8]  = row3[0];
  m[9]  = row3[1];
  m[10] = row3[2];
  m[11] = 0;

  m[12] = row4[0];
  m[13] = row4[1];
  m[14] = row4[2];
  m[15] = 1;
}


Matrix3 Float16ToMaxMatrix3(const float* a_m)
{
  Matrix3 m;
  m.SetRow(0, Point3(a_m[0*4+0], a_m[0*4+1], a_m[0*4+2]));
  m.SetRow(1, Point3(a_m[1*4+0], a_m[1*4+1], a_m[1*4+2]));
  m.SetRow(2, Point3(a_m[2*4+0], a_m[2*4+1], a_m[2*4+2]));
  m.SetRow(3, Point3(a_m[3*4+0], a_m[3*4+1], a_m[3*4+2]));
  return m;
}


float scaleWithMatrix(float a_val, const Matrix3& a_externTransform)
{
  Point3 tmpVec(0.0f, a_val, 0.0f);

  Matrix3 extTransform = a_externTransform;
  extTransform.SetRow(3, Point3(0,0,0));
  
  return (extTransform*tmpVec).Length();
}

void hydraRender_mk3::ExtractNodeTM(INode* node, GeometryObj* geom, TimeValue t)
{
  Matrix3 pivot = toMeters(node->GetObjectTM(t));
  MaxMatrix3ToFloat16(pivot, geom->m);
}

void hydraRender_mk3::ExtractNodeTM(INode* node, LightObj* li, TimeValue t)
{
  Matrix3 pivot = toMeters(node->GetObjectTM(t));
  MaxMatrix3ToFloat16(pivot, li->m);
}

void hydraRender_mk3::ExtractGeomObject(INode* node, GeometryObj* geom, TimeValue t)
{
  ObjectState os = node->EvalWorldState(t);
  if (!os.obj)
    return;

  if (os.obj->ClassID() == Class_ID(TARGET_CLASS_ID, 0))
    return;

	/*if (node->IsHidden() != 0) //check if hidden
	{
		return;
	}*/
  geom->mesh_id = node->GetName();

  ExtractNodeTM(node, geom, t);

  if (incl.geometry) 
    ExtractMesh(node, t, geom);

  if(geom->n_faces*3 != geom->pos_indeces.size())
  {
    plugin_log.Print("omg, it is hapened");
  }



  //if (incl.materials) 
  if(true)
  {
    Mtl* mtl = node->GetMtl();
  }

}

void hydraRender_mk3::CheckGeomObject(INode* node, TimeValue t, unsigned int& allVerticesNum, unsigned int& allIndicesNum)
{
  ObjectState os = node->EvalWorldState(GetStaticFrame());
  if (!os.obj)
    return;

  if (os.obj->ClassID() == Class_ID(TARGET_CLASS_ID, 0))
    return;

  if (incl.geometry) 
	{
		BOOL needDel;
		TriObject* tri = GetTriObjectFromNode(node, t, needDel); 

		if (tri == NULL) 
		{
			return;
		}

		Mesh* mesh = &tri->GetMesh();
		if(mesh == NULL)
		{
			return;
		}

		if(mesh->getNumFaces() == 0 || mesh->getNumVerts() == 0)
		{
			plugin_log.Print("strange empty mesh detected");
			return;
		}

		allVerticesNum += mesh->getNumFaces()*3;
		allIndicesNum += mesh->getNumFaces()*3;

		if (needDel) 
		{
			tri->DeleteThis();
			tri = NULL;
		}
	}

}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void hydraRender_mk3::ExtractMesh(INode* node, TimeValue t, GeometryObj* geom)
{
  int i;

  Matrix3 tm = node->GetObjTMAfterWSM(t);

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj || os.obj->SuperClassID()!=GEOMOBJECT_CLASS_ID) 
  {
    plugin_log.Print("Oh, shit! Safety net. This shouldn't happen");
    return; // Safety net. This shouldn't happen.
  }

  // Order of the vertices. Get 'em counter clockwise if the objects is negatively scaled.
  // 
  int vx1 = 0;
  int vx2 = 1;
  int vx3 = 2;

  /*BOOL negScale = TMNegParity(tm);
  if (negScale) 
  {
    vx1 = 2;
    vx2 = 1;
    vx3 = 0;
  }
  else 
  {
    vx1 = 0;
    vx2 = 1;
    vx3 = 2;
  }*/

  BOOL needDel;
  TriObject* tri = GetTriObjectFromNode(node, t, needDel); 

  if (tri == NULL) 
  {
    geom->n_verts = 0;
    geom->n_faces = 0;
    return;
  }

  Mesh* mesh = &tri->GetMesh();
  if(mesh == NULL)
  {
    geom->n_verts = 0;
    geom->n_faces = 0;
    return;
  }

  CalcMaxNormalsAsInExample(mesh, geom, tm);
  CalcMaxNormalsAsInOpenColladaPlugin(mesh, geom, tm);

  Mtl* nodeMtl = node->GetMtl();
  //if(nodeMtl == NULL)
    //return;

  geom->n_verts = mesh->getNumVerts();
  geom->n_faces = mesh->getNumFaces();

  if(geom->n_faces == 0 || geom->n_verts == 0)
  {
    plugin_log.Print("strange empty mesh detected");
    geom->n_verts = 0;
    geom->n_faces = 0;
    return;
  }

  for (i=0; i<geom->n_verts; i++) 
  {
    Point3 v = toMeters(tm * mesh->verts[i]);

    geom->positions.push_back(v[0]);
    geom->positions.push_back(v[1]);
    geom->positions.push_back(v[2]);

    if(i==0)
    {
      geom->bbox[0] = v[0];
      geom->bbox[1] = v[1];
      geom->bbox[2] = v[2];

      geom->bbox[3] = v[0];
      geom->bbox[4] = v[1];
      geom->bbox[5] = v[2];
    }
    else 
    {
      if ( v[0] < geom->bbox[0] ) geom->bbox[0] = v[0];
      if ( v[1] < geom->bbox[1] ) geom->bbox[1] = v[1];
      if ( v[2] < geom->bbox[2] ) geom->bbox[2] = v[2];

      if ( v[0] > geom->bbox[3] ) geom->bbox[3] = v[0];
      if ( v[1] > geom->bbox[4] ) geom->bbox[4] = v[1];
      if ( v[2] > geom->bbox[5] ) geom->bbox[5] = v[2];
    }

  }

  geom->face_smoothgroups.resize(0);

  for (i=0; i<geom->n_faces; i++) 
  {
    Face* f = &mesh->faces[i];
    geom->face_smoothgroups.push_back(f->smGroup);

    if(mtlList.Count() != 0 && nodeMtl != NULL)
    {
      int nodeSubMtls = nodeMtl->NumSubMtls();
      if(nodeSubMtls == 0)
      {
        //int mat_id = materialByName[nodeMtl->GetName().data()];
        int mat_id = materialByAddress[nodeMtl];
        geom->material_id.push_back(mat_id);
      }
      else
      {
        int subMatId = f->getMatID();
        Mtl* faceMat = nodeMtl->GetSubMtl(subMatId); 

        if (faceMat == NULL)
        {
          geom->material_id.push_back(0);
        }
        else
        {
          //int mat_id = materialByName[faceMat->GetName().data()];
          int mat_id = materialByAddress[faceMat];
          geom->material_id.push_back(mat_id);
        }
      } 
    }
    else
    {
      geom->material_id.push_back(0);
    }

    geom->pos_indeces.push_back(mesh->faces[i].v[vx1]);
    geom->pos_indeces.push_back(mesh->faces[i].v[vx2]);
    geom->pos_indeces.push_back(mesh->faces[i].v[vx3]);
  }

  if (GetIncludeTextureCoords()) 
  {
    // If not, export standard tverts
    int numTVx = mesh->getNumTVerts();

    //char temp[64];
    
    //sprintf(temp,"%d", geom->n_verts);
    //plugin_log.Print(std::string("n_verts = ") + std::string(temp));

    //sprintf(temp,"%d", geom->n_faces);
    //plugin_log.Print(std::string("n_faces = ") + std::string(temp));

    //sprintf(temp,"%d", numTVx);
    //plugin_log.Print(std::string("numTVx = ") + std::string(temp));

    if (numTVx) 
    {
      for (i=0; i<numTVx; i++) 
      {
        UVVert tv = mesh->tVerts[i];
        geom->tex_coords.push_back(tv[0]);
        geom->tex_coords.push_back(tv[1]);
      }

      for (i=0; i<mesh->getNumFaces(); i++) 
      {
        geom->tex_coords_indices.push_back(mesh->tvFace[i].t[vx1]);
        geom->tex_coords_indices.push_back(mesh->tvFace[i].t[vx2]);
        geom->tex_coords_indices.push_back(mesh->tvFace[i].t[vx3]);
      }

    }
  }

  if(geom->pos_indeces.size() != geom->n_faces*3)
  {
    plugin_log.Print("pos_indeces.size() != geom->n_faces");
  }

  if (needDel) 
  {
    tri->DeleteThis();
    tri = NULL;
  }

}


BOOL hydraRender_mk3::TMNegParity(Matrix3 &m)
{
  return (DotProd(CrossProd(m.GetRow(0),m.GetRow(1)),m.GetRow(2))<0.0)?1:0;
}


TriObject* hydraRender_mk3::GetTriObjectFromNode(INode *node, TimeValue t, int &deleteIt)
{
  deleteIt = FALSE;
  Object *obj = node->EvalWorldState(t).obj;
  if (obj->CanConvertToType(Class_ID(TRIOBJ_CLASS_ID, 0))) { 
    TriObject *tri = (TriObject *) obj->ConvertToType(t, 
      Class_ID(TRIOBJ_CLASS_ID, 0));
    // Note that the TriObject should only be deleted
    // if the pointer to it is not equal to the object
    // pointer that called ConvertToType()
    if (obj != tri) deleteIt = TRUE;
    return tri;
  }
  else {
    return NULL;
  }
}


static Point3 basic_tva[3] = { 
  Point3(0.0,0.0,0.0),Point3(1.0,0.0,0.0),Point3(1.0,1.0,0.0)
};
static Point3 basic_tvb[3] = { 
  Point3(1.0,1.0,0.0),Point3(0.0,1.0,0.0),Point3(0.0,0.0,0.0)
};
static int nextpt[3] = {1,2,0};
static int prevpt[3] = {2,0,1};

void hydraRender_mk3::make_face_uv(Face *f, Point3 *tv)
{
  int na,nhid,i;
  Point3 *basetv;
  /* make the invisible edge be 2->0 */
  nhid = 2;
  if (!(f->flags&EDGE_A))  nhid=0;
  else if (!(f->flags&EDGE_B)) nhid = 1;
  else if (!(f->flags&EDGE_C)) nhid = 2;
  na = 2-nhid;
  basetv = (f->v[prevpt[nhid]]<f->v[nhid]) ? basic_tva : basic_tvb; 
  for (i=0; i<3; i++) {  
    tv[i] = basetv[na];
    na = nextpt[na];
  }
}

void hydraRender_mk3::PreProcess(INode* node, int& nodeCount)
{
  nodeCount++;

  mtlList.AddMtl(node->GetMtl());

  for (int c = 0; c < node->NumberOfChildren(); c++) 
  {
    PreProcess(node->GetChildNode(c), nodeCount);
  }

}

BOOL hydraRender_mk3::nodeEnumCheckGeometry(INode* node, unsigned int& allVerticesNum, unsigned int& allIndicesNum, TimeValue t)
{
	if(exportSelected && node->Selected() == FALSE)
    return TREE_CONTINUE;

  if((!exportSelected || node->Selected()) && node->IsHidden() == 0) 
  {
    ObjectState os = node->EvalWorldState(t); 

    if (os.obj) 
    {
      bool IsSphere = false;
      if(os.obj->SuperClassID() == GEOMOBJECT_CLASS_ID) 			
				CheckGeomObject(node, t, allVerticesNum, allIndicesNum);
    }
  }	

  // For each child of this node, we recurse into ourselves 
  // until no more children are found.
  for (int c = 0; c < node->NumberOfChildren(); c++) {
    if (!nodeEnumCheckGeometry(node->GetChildNode(c), allVerticesNum, allIndicesNum, t))
      return FALSE;
  }

  return TRUE;
}

BOOL hydraRender_mk3::nodeEnum(INode* node, std::vector<LightObj>* lights, std::vector<CameraObj>* cameras, int& geomObjNum, int& vertWritten, TimeValue t)
{
  if(exportSelected && node->Selected() == FALSE)
    return TREE_CONTINUE;

  nCurNode++;

  //ip->ProgressUpdate((int)((float)nCurNode/nTotalNodeCount*100.0f));  // ������Eprogress bar!!!

  // Stop recursing if the user pressed Cancel 
  /*if (ip->GetCancel())
  return FALSE;*/

  // Only export if exporting everything or it's selected
  //
  if((!exportSelected || node->Selected()) && node->IsHidden() == 0) 
  {
    // The ObjectState is a 'thing' that flows down the pipeline containing
    // all information about the object. By calling EvalWorldState() we tell
    // max to evaluate the object at end of the pipeline.
    //
    ObjectState os;
    os = node->EvalWorldState(t); 

    // The obj member of ObjectState is the actual object we will export.
    if (os.obj) 
    {
      m_geomTemp.clear(); // put object to this variable, make it 'global' to prevent memory allocations


      // We look at the super class ID to determine the type of the object.
      switch(os.obj->SuperClassID()) 
      {

      case GEOMOBJECT_CLASS_ID: 
        {
          ExtractGeomObject(node, &m_geomTemp, t); 
          if (m_geomTemp.n_faces != 0)
          {
            geomObjNum++;	
						//plugin_log.PrintValue("geom object #", geomObjNum);
						geomObjToVsgf(&m_geomTemp, vertWritten);
						//plugin_log.PrintValue("geom object done", geomObjNum);
          }

          break;
        }

      case LIGHT_CLASS_ID:
        {
          LightObj li;
          ExtractLightObject(node, &li, t); 
          lights->push_back(li);
          break;
        }

      case CAMERA_CLASS_ID:
        {
          CameraObj cam;
          ExtractCamObject(node, &cam, t);
          cameras->push_back(cam);
          break;
        }
      default:
          break;
      }
    }
  }	

  // For each child of this node, we recurse into ourselves 
  // until no more children are found.
  for (int c = 0; c < node->NumberOfChildren(); c++) {
    if (!nodeEnum(node->GetChildNode(c), lights, cameras, geomObjNum, vertWritten, t))
      return FALSE;
  }

  return TRUE;
}

void hydraRender_mk3::geomObjToVsgf(GeometryObj* geom, int& vertWritten)
{
  typedef unsigned int uint;

	if(geom->positions.size()!=0)
  {
    std::map <int, std::vector <int> > vertexFaceIndeces; // i don;t know wtf, but i can't detete this !!!!!!!!!!!!!!!!!!!!!

    //float* face_normals = new float[geom->n_faces*3];

		if(geom->n_faces*3 > geom->pos_indeces.size())
		{
			plugin_log.Print("ComputeVertexFaceIndices, mesh.n_faces is out of range!");
			plugin_log.PrintValue("mesh.n_faces*3 = ", geom->n_faces*3);
			plugin_log.PrintValue("mesh.pos_indeces.size() = ", geom->pos_indeces.size());
		}

 		int N_vertices = geom->n_faces*3;
		int N_indices = geom->n_faces*3;

    float* allMemory = new float[N_vertices*4 + N_indices + N_indices/3 + N_vertices*2 + N_vertices*4]; // alloc all buffers in one call

    float* p                 = allMemory;
    float* v                 = p;        p += N_vertices*4;
    uint* indices            = (uint*)p; p += N_indices;
    uint* triMaterialIndices = (uint*)p; p += N_indices/3;
    float* texcoords         = p;        p += N_vertices*2;
    float *v_normals         = p;        p += N_vertices*4;

		Matrix3 swapAxis(1);
    swapAxis.SetRow(0, Point3(1,0,0));
    swapAxis.SetRow(1, Point3(0,0,-1));
    swapAxis.SetRow(2, Point3(0,1,0));

    std::vector<float> faceNormals(3*geom->n_faces);

		for(int i=0; i<geom->n_faces; i++)
		{
			int index1 = geom->pos_indeces[i*3+0];
			int index2 = geom->pos_indeces[i*3+1];
			int index3 = geom->pos_indeces[i*3+2];

			Point3 v1p, v2p, v3p;

			v1p.x = geom->positions[index1*3];
			v1p.y = geom->positions[index1*3+1];
			v1p.z = geom->positions[index1*3+2];

			v2p.x = geom->positions[index2*3];
			v2p.y = geom->positions[index2*3+1];
			v2p.z = geom->positions[index2*3+2];

			v3p.x = geom->positions[index3*3];
			v3p.y = geom->positions[index3*3+1];
			v3p.z = geom->positions[index3*3+2];

			Point3 v1p_t, v2p_t, v3p_t;
			v1p_t = swapAxis*v1p;
			v2p_t = swapAxis*v2p;
			v3p_t = swapAxis*v3p;

      Point3 faceNorm;
      faceNorm = ::Normalize( (v2p - v1p)^(v3p - v2p) );
      faceNorm = swapAxis*faceNorm; // MUST DO AFTER CALCULATING POINTS, 3DS MAX Math BUG, if apply 0 to points (v1p,v2p,v3p) => does not works !!!
      faceNormals[i*3+0] = faceNorm.x;
      faceNormals[i*3+1] = faceNorm.y;
      faceNormals[i*3+2] = faceNorm.z;


			v[i*12+0] = v1p_t.x; v[i*12+1] = v1p_t.y; v[i*12+2] = v1p_t.z; v[i*12+3] = 1;
			v[i*12+4] = v2p_t.x; v[i*12+5] = v2p_t.y; v[i*12+6] = v2p_t.z; v[i*12+7] = 1;
			v[i*12+8] = v3p_t.x; v[i*12+9] = v3p_t.y; v[i*12+10] = v3p_t.z; v[i*12+11] = 1;

			indices[i*3+0] = i*3+0 + vertWritten;
			indices[i*3+1] = i*3+1 + vertWritten;
			indices[i*3+2] = i*3+2 + vertWritten;

      triMaterialIndices[i] = geom->material_id[i]; // geom->material_id[i]; // 0
			

      if(geom->tex_coords.size()!=0)
      {
        int tindex1 = geom->tex_coords_indices[i*3+0];
        int tindex2 = geom->tex_coords_indices[i*3+1];
        int tindex3 = geom->tex_coords_indices[i*3+2];

        texcoords[i*6+0] = geom->tex_coords[tindex1*2+0];
				texcoords[i*6+1] = geom->tex_coords[tindex1*2+1];
        texcoords[i*6+2] = geom->tex_coords[tindex2*2+0];
				texcoords[i*6+3] = geom->tex_coords[tindex2*2+1];
				texcoords[i*6+4] = geom->tex_coords[tindex3*2+0];
				texcoords[i*6+5] = geom->tex_coords[tindex3*2+1];
      }
		}

    // recompute normals based on smoothing groups
    //
    int normalsSpecifiedCount = geom->normsSpecified.size()/3;
    int normalIndexCount      = geom->normsSpecIndices.size();

    if(normalsSpecifiedCount > 0)
    {
      //m_paramTrace << "norms are specified!" << std::endl;

      for(int i=0; i<normalIndexCount; i++)
      {
        int normalIndex = geom->normsSpecIndices[i];

        Point3 norm;
        norm.x = geom->normsSpecified[normalIndex*3+0];
        norm.y = geom->normsSpecified[normalIndex*3+1];
        norm.z = geom->normsSpecified[normalIndex*3+2];

        norm   = swapAxis*norm;

        v_normals[i*4+0] = norm.x; 
        v_normals[i*4+1] = norm.y; 
        v_normals[i*4+2] = norm.z; 
        v_normals[i*4+3] = 0.0f; 
      }
    }
    else
    {
      //m_paramTrace << "norms are NOT specified!" << std::endl;

      for(int i=0; i<geom->n_faces; i++)
      {
        DWORD smGroup = geom->face_smoothgroups[i];

        Point3 vertNorms[3];

        for(int vId=0; vId<3;vId++)
        {
          bool normalIsInvalid = false;
          int vNormKeyOffset = geom->vNormsKeys[i*3+vId];
          VNorm& vnorm1      = geom->vnorms[vNormKeyOffset];

          Point3 norm;
          norm = vnorm1.GetNormal(smGroup, geom->vnormsMemoryPool, normalIsInvalid);
          norm = swapAxis*norm;

          Point3 faceNorm;
          faceNorm.x = faceNormals[i*3+0];
          faceNorm.y = faceNormals[i*3+1];
          faceNorm.z = faceNormals[i*3+2];

          float faceNDotVertexN = DotProd(norm, faceNorm);

          if(normalIsInvalid || faceNDotVertexN < 0.5f) // recalculate normal as face normal if it is invalid or too different from max algorithm normal
          {
            norm.x = faceNormals[i*3+0];
            norm.y = faceNormals[i*3+1];
            norm.z = faceNormals[i*3+2];
          }

          v_normals[i*12+vId*4+0] = norm.x; 
          v_normals[i*12+vId*4+1] = norm.y; 
          v_normals[i*12+vId*4+2] = norm.z; 
          v_normals[i*12+vId*4+3] = 0.0f;

          vertNorms[vId] = norm;
        }


      }
    }

		if(rendParams.writeToDisk)
		{
			writeUpdateFloat(pos_out, sizeof(float)*4*(geom->n_faces*3), v);
			writeUpdateFloat(norm_out, sizeof(float)*4*(geom->n_faces*3), v_normals);
			writeUpdateFloat(tex_out, sizeof(float)*2*(geom->n_faces*3), texcoords);
			writeUpdateUint(v_ind_out, sizeof(unsigned int)*(geom->n_faces*3), indices);
			writeUpdateUint(m_ind_out, sizeof(unsigned int)*(geom->n_faces), triMaterialIndices);
		}
		else
		{
			writeVectorUpdateFloat(pos_out_v, 4*(geom->n_faces*3), v);
			writeVectorUpdateFloat(norm_out_v, 4*(geom->n_faces*3), v_normals);
			writeVectorUpdateFloat(tex_out_v, 2*(geom->n_faces*3), texcoords);
			writeVectorUpdateUint(v_ind_out_v, (geom->n_faces*3), indices);
			writeVectorUpdateUint(m_ind_out_v, (geom->n_faces), triMaterialIndices);
		}

		vertWritten += geom->n_faces*3;

    delete [] allMemory;
    //delete [] face_normals;
  }

}

std::string hydraRender_mk3::GetMaterialListStr()
{
  std::stringstream strstr;

	for(size_t i=0; i < material_dict_max_index.size(); i++)
    strstr << ws2s(material_dict_max_index[i]).c_str() << "\n";

  return strstr.str();
}

void hydraRender_mk3::writeInit(std::ostream& a_out, unsigned int allVerticesNum, unsigned int allIndicesNum)
{
	unsigned int flags = 0;

	std::stringstream strstr;

  for(size_t i=0; i < material_dict_max_index.size(); i++)
    strstr << material_dict_max_index[i].c_str() << "\n";

  const std::string& strData = GetMaterialListStr();
  vsgfFileSize += strData.size();
 
  unsigned int materialsNum = material_dict_max_index.size();

	a_out.write((const char*)&vsgfFileSize, sizeof(unsigned long long int)); // uint64
  a_out.write((const char*)&allVerticesNum, sizeof(unsigned int));         // uint32
  a_out.write((const char*)&allIndicesNum, sizeof(unsigned int));          // uint32
  a_out.write((const char*)&materialsNum, sizeof(unsigned int));           // uint32
  a_out.write((const char*)&flags, sizeof(unsigned int));                  // uint32
}

void hydraRender_mk3::writeUpdateFloat(std::ostream& a_out, std::streamsize bytes, float* arr)
{
	a_out.write((const char*)arr, bytes);
}

void hydraRender_mk3::writeUpdateUint(std::ostream& a_out, std::streamsize bytes, unsigned int* arr)
{
	a_out.write((const char*)arr, bytes);
}

void hydraRender_mk3::writeVectorUpdateFloat(std::vector<float> &v_out, unsigned int elements, float* arr)
{
	//a_out.write((const char*)arr, bytes);
	for(int i = 0; i < elements; i++)
		v_out.push_back(arr[i]);
}

void hydraRender_mk3::writeVectorUpdateUint(std::vector<unsigned int> &v_out, unsigned int elements, unsigned int* arr)
{
	//a_out.write((const char*)arr, bytes);
	for(int i = 0; i < elements; i++)
		v_out.push_back(arr[i]);
}
/*
void hydraRender_mk3::writeUpdate(std::ostream& pos_out, std::ostream& norm_out, std::ostream& tex_out, std::ostream& v_ind_out, std::ostream& m_ind_out,
																	unsigned int verticesNum, unsigned int indicesNum, float* positions, float* normals, float* texcoords,
																	unsigned int* vertIndices, unsigned int* matIndices)
{
	pos_out.write((const char*)positions, sizeof(float)*4*verticesNum);
  norm_out.write((const char*)normals, sizeof(float)*4*verticesNum);
  tex_out.write((const char*)texcoords, sizeof(float)*2*verticesNum);
  v_ind_out.write((const char*)vertIndices, sizeof(unsigned int)*indicesNum);
  m_ind_out.write((const char*)matIndices, sizeof(unsigned int)*(indicesNum/3)); 
}*/
void hydraRender_mk3::readAndWrite(std::ostream& a_out, std::istream& a_in, unsigned int buf_size)
{
  char* buf = new char[buf_size];

	while ((a_in.rdstate() & std::ifstream::eofbit) == 0)
	{
		a_in.read(buf, buf_size);
		a_out.write(buf, a_in.gcount());
	}

  delete [] buf;
}

void hydraRender_mk3::readVectorAndWrite(std::ostream& a_out, std::vector<float> &v_in)
{
	a_out.write((const char*)&v_in[0], v_in.size() * sizeof(float));
}

void hydraRender_mk3::readVectorAndWrite(std::ostream& a_out, std::vector<unsigned int> &v_in)
{
  a_out.write((const char*)&v_in[0], v_in.size() * sizeof(unsigned int));
}

void hydraRender_mk3::writeFinal(std::ostream& a_out, std::istream& pos_in, std::istream& norm_in, std::istream& tex_in, std::istream& v_ind_in, std::istream& m_ind_in, unsigned int allVerticesNum, unsigned int allIndicesNum)
{
	readAndWrite(a_out, pos_in, 4096);
	readAndWrite(a_out, norm_in, 4096);
	readAndWrite(a_out, tex_in, 4096);
	readAndWrite(a_out, v_ind_in, 4096);
	readAndWrite(a_out, m_ind_in, 4096);

  const std::string& strData = GetMaterialListStr();
	a_out.write(strData.c_str(), strData.size());
}

void hydraRender_mk3::writeVectorFinal(std::ostream& a_out, std::vector<float> &pos_in, std::vector<float> &norm_in, std::vector<float> &tex_in, std::vector<unsigned int> &v_ind_in,std::vector<unsigned int> &m_ind_in, unsigned int allVerticesNum, unsigned int allIndicesNum)
{
	readVectorAndWrite(a_out, pos_in);
	readVectorAndWrite(a_out, norm_in);
	readVectorAndWrite(a_out, tex_in);
	readVectorAndWrite(a_out, v_ind_in);
	readVectorAndWrite(a_out, m_ind_in);

  const std::string& strData = GetMaterialListStr();
	a_out.write(strData.c_str(), strData.size());
}

Point3 hydraRender_mk3::ComputeSmGroupNormal(const std::vector<int>& faceIndeces, int faceNum, const std::vector<int> &face_smoothgroups, float *face_normals)
{
  Point3 v(0,0,0);
  int counter = 0;

  Point3 faceNorm;
  faceNorm.x = face_normals[faceNum*3 + 0];
  faceNorm.y = face_normals[faceNum*3 + 1];
  faceNorm.z = face_normals[faceNum*3 + 2];

  v = faceNorm;

  for(int i = 0; i < faceIndeces.size(); i++)
  {
    Point3 norm;
    norm.x = face_normals[faceIndeces[i]*3 + 0];
    norm.y = face_normals[faceIndeces[i]*3 + 1];
    norm.z = face_normals[faceIndeces[i]*3 + 2];

    if(face_smoothgroups[faceNum] == face_smoothgroups[faceIndeces[i]] && v%norm > 0.173648f ) // if angle is less than 80 degrees 
    {
      v.x += norm.x;
      v.y += norm.y;
      v.z += norm.z;
      counter++;
    }

  }

  v = v*(1.0f/float(counter));
	return ::Normalize(v);
}