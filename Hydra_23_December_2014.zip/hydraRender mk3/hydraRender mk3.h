#ifndef __HYDRARENDER_H__
#define __HYDRARENDER_H__

//**************************************************************************/
// Copyright (c) 1998-2007 Autodesk, Inc.
// All rights reserved.
// 
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION: Includes for Plugins
// AUTHOR: ALICE
//***************************************************************************/

#include "3dsmaxsdk_preinclude.h"
#include "resource.h"

#include <ctime>
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <hash_map>  
#include <string>
#include <thread>

#include <lslights.h>
#include <iparamb2.h>

#include <ITabDialog.h>

#include "IFileResolutionManager.h"

#include "../HydraServer/ImportStructs.h"
#include "../HydraServer/HydraLogger.h"
#include "../HydraAppLib/HydraNetwork.h" 
//#include "../gpu_rt/HydraExport.h"
#include "hashlibpp.h"

#include "../HDRCore/PostProcessEngine/image.h"
#include "../HDRCore/PostProcessEngine/filters/tonemappingfilter.h"
#include "../HDRCore/PostProcessEngine/filters/blurfilter.h"
#include "../HDRCore/PostProcessEngine/filters/boxfilter.h"

#ifndef TIXML_USE_STL
#define TIXML_USE_STL
#endif
#include "../tinyxml/tinyxml.h"


#define hydraRender_mk3_CLASS_ID	Class_ID(0x7da90dd1, 0x758b0286)
extern TCHAR *GetString(int id);

extern HINSTANCE hInstance;

#define BOOST_ALL_NO_LIB
#define MAX_THREADS 4

#define RENDER_METHOD_PT   0
#define RENDER_METHOD_SPPM 1
#define RENDER_METHOD_IC   2

//#define MAX2014


std::wstring ToWideString(const std::string& rhs);
std::string ToNarrowString(const std::wstring& rhs);

std::wstring s2ws(const std::string& s);
std::string ws2s(const std::wstring& s);

void    MaxMatrix3ToFloat16(const Matrix3& pivot, float* m);
Matrix3 Float16ToMaxMatrix3(const float* a_m);
float   scaleWithMatrix(float a_val, const Matrix3& a_externTransform);
/*
typedef struct texData {
    Texmap* tex;
		TextureObj* texture;
    int resolution;
	} texData, *pTexData;
*/
class HydraRender;

class MtlKeeper 
{
public:
  BOOL	AddMtl(Mtl* mtl);
  int		GetMtlID(Mtl* mtl);
  int		Count();
  Mtl*	GetMtl(int id);
  void Clear();

  Tab<Mtl*> mtlTab;
};



class HydraRenderParams : public RenderGlobalContext {
public:
	RendType	rendType;				
	int			nMinx;
	int			nMiny;
	int			nMaxx;
	int			nMaxy;
	int			nNumDefLights;			// The default lights passed into the renderer
	Point2		scrDUV;
	DefaultLight*	pDefaultLights;
	FrameRendParams*	pFrp;			// Frame specific members
	RendProgressCallback*	progCallback;	// Render progress callback

	BOOL inMtlEditor;

	// Standard options
	// These options are configurable for all plugin renderers
	BOOL		bVideoColorCheck;
	BOOL		bForce2Sided;
	BOOL		bRenderHidden;
	BOOL		bSuperBlack;
	BOOL		bRenderFields;
	BOOL		bNetRender;

	// Render effects
	Effect*		effect;

	int rendTimeType;
	TimeValue rendStart, rendEnd;
	int nthFrame;
	bool rendSaveFile;

	//BitArray	gbufChan;	
	GBufReader*	gbufReader;
	GBufWriter*	gbufWriter;

	//Hydra params
	long timeLimit;
	int primary, secondary, tertiary, manualMode, causticsMode;
  bool useHydraGUI, useToneMapping, enableDOF, noRandomLightSel, enableLog, debugOn, allSecondary, allTertiary, timeLimitOn;
	bool primaryMLFilter, secondaryMLFilter, writeToDisk;
	float focalplane, lensradius;

	//path tracing
  int icBounce;
	int seed;
	int minrays, maxrays, raybounce, diffbounce, useRR, causticRays;
	float relative_error;
	bool guided;

	//SPPM Caustics
	int maxphotons_c, retrace_c;
	float initial_radius_c, caustic_power, alpha_c;
	bool visibility_c;

	//SPPM Diffuse
	int maxphotons_d, retrace_d;
	float initial_radius_d, alpha_d;
	bool visibility_d, irr_map;

	//Irradiance cache
	int ic_eval;
	int maxpass, fixed_rays;
	float ws_err, ss_err4, ss_err2, ss_err1, ic_relative_error;
		
	//Multi-Layer
	bool filterPrimary;
	float r_sigma, s_sigma;
	int layerNum;

	//Tone mapping
	float white_point, gamma, strength, phi;
	bool bloom;

	//Environment
	float env_mult;


	HydraRenderParams();
	void		SetDefaults();
	void		ComputeViewParams(const ViewParams&vp);
	Point3		RayDirection(float sx, float sy);

	int				NumRenderInstances();
  RenderInstance*	GetRenderInstance(int i);
};

class MyView : public View {
public:
	HydraRenderParams*	pRendParams;
	Point2		ViewToScreen(Point3 p);
};


class HydraRenderParamDlg;

class hydraRender_mk3 : public Renderer, public ITabDialogObject {
	public:
		
    BOOL		bOpen;					// Indicate that Open() has been called
	  int			nCurNodeID;		  // Node counter
	  BOOL		bFirstFrame;		// Indicate that this is the first frame
	  BOOL		bUvMessageDone;	// indicate that we have already warned the 


	  HydraRenderParams	rendParams; // Render parameters


		// Loading/Saving
		IOResult Load(ILoad *iload); 
		IOResult Save(ISave *isave); 

		//From Animatable
		Class_ID ClassID() {return hydraRender_mk3_CLASS_ID;}		
		SClass_ID SuperClassID() { return RENDERER_CLASS_ID; }
		void GetClassName(TSTR& s) {s = GetString(IDS_CLASS_NAME);}

		RefTargetHandle Clone( RemapDir &remap );

		#ifdef MAX2014
    virtual RefResult NotifyRefChanged(Interval changeInt, RefTargetHandle hTarget, PartID& partID,  RefMessage message);
		#else
		virtual RefResult NotifyRefChanged(const Interval& changeInt, RefTargetHandle hTarget, PartID& partID, RefMessage message, BOOL propagate);
		#endif

		int NumSubs() { return 1; }
		TSTR SubAnimName(int i) { return GetString(IDS_PARAMS); }				

	//	int NumRefs() { return 1; }


    virtual int Open(INode *scene, INode *vnode, ViewParams *viewPar, RendParams &rp, HWND hwnd, DefaultLight *defaultLights=NULL, int numDefLights=0, RendProgressCallback *prog=NULL);
    virtual int Render(TimeValue t, Bitmap *tobm, FrameRendParams &frp, HWND hwnd, RendProgressCallback *prog=NULL, ViewParams *viewPar=NULL);
    virtual void Close(HWND hwnd, RendProgressCallback *prog=NULL);
    virtual bool ApplyRenderEffects (TimeValue t, Bitmap *pBitmap, bool updateDisplay=true) 
    {
        TODO("Apply the render effects at the specified time value.");
        return false;
    }
    virtual RendParamDlg* CreateParamDialog(IRendParams *ir, BOOL prog=FALSE);

		//int RenderPresetsPreSave ( ITargetedIO * root, BitArray saveCategories); 	

		// Get extension interfaces. Used to return the
	  // ITabDialogObject interface for the renderer
		using Renderer::GetInterface;
		BaseInterface* GetInterface ( Interface_ID id );
		// ITabDialogObject
		// Add your tab(s) to the dialog. This will only be called if
		// both this object and the dialog agree that the tab should
		// be added. Dialog is the address of the dialog.
		virtual void AddTabToDialog ( ITabbedDialog* dialog, ITabDialogPluginTab* tab );

		// Return true if the tabs added by the ITabDialogPluginTab tab
		// are acceptable for this dialog. Dialog is the dialog being
		// filtered.
		virtual int AcceptTab ( ITabDialogPluginTab* tab );
    
    virtual void ResetParams();

    int			CheckAbort(int done, int total);
	  void		SetProgTitle(const TCHAR *title);

		void DeleteThis() { delete this; }		
		
		//Constructor/Destructor
		hydraRender_mk3();
		~hydraRender_mk3();


    IScanRenderer* m_pScanlineRender;
    std::string server_IP;


    HydraLogger plugin_log; 
    std::wofstream m_paramTrace;
		
    std::string geomMD5;
    std::string lightsMD5;
    std::string matGMD5;

		RealPixel*	pGbufRealPix;


		std::string vsgfFilename;
		std::string posFilename, normFilename, texFilename, vIndFilename, mIndFilename;
		std::ofstream pos_out, norm_out, tex_out, v_ind_out, m_ind_out;
		std::vector<float> pos_out_v, norm_out_v, tex_out_v;
		std::vector<unsigned int> v_ind_out_v, m_ind_out_v;
		std::map<std::string, std::wstring> procTexMD5s; //md5 -> path
		bool flat_shading;
		//int resolution; //procedural texture resolution

		std::vector<CameraObj>   cameras;
		std::vector<MaterialObj> materials;
		std::vector<LightObj>    lights;

		unsigned long long int vsgfFileSize;

    Included incl;
    bool bIncludeNormals;
    bool bIncludeTextureCoords;
    int		nMeshFrameStep;
    int		nKeyFrameStep;
    TimeValue	nStaticFrame;

    //Interface*	ip;
    int			nTotalNodeCount;
    int			nCurNode;
    BOOL    mtlEditorWasOpen;
    MtlKeeper	mtlList;
    std::hash_map<Mtl*, int>         materialByAddress;
    std::hash_map<int, std::wstring> material_dict_max_index;
    GeometryObj m_geomTemp;

		INode *pScene;
		INode *pVnode;

		DWORD   dwThreadIdArray[MAX_THREADS];
    HANDLE  hThreadArray[MAX_THREADS]; 
		std::vector<std::thread> threads;

		//pTexData procTex[MAX_THREADS];

		//int procTexToCheck;
		int start_res;
		//Texmap* procTexs[128];
		std::vector<Texmap*> procTexsV;

		Bitmap *last_render;
    std::vector<float> m_hdrImageData;
		BitmapInfo no_tonemap_BI;
		
    std::string hydraRender_mk3::GetMaterialListStr();

		LPCWSTR GetHydraVersion() { return L"Hydra Render v1.9f"; }

		void hydraRender_mk3::ToneMap(Bitmap* tobm, int renderHeight, int renderWidth);
		void hydraRender_mk3::copyBitmap(Bitmap* from, Bitmap* to);
		void hydraRender_mk3::displayLastRender();

		int DoExport(INode* root, INode *vnode, ViewParams* a_viewParams, TimeValue t);

		int createProcTextures();
		void checkProcTexMD5(std::vector<MaterialObj> *materials);

    void ExtractMesh(INode* node, TimeValue t, GeometryObj* geom);
    BOOL TMNegParity(Matrix3 &m);
    TriObject* GetTriObjectFromNode(INode *node, TimeValue t, int &deleteIt);
    Point3	GetVertexNormal(Mesh* mesh, int faceNo, RVertex* rv);
    void	make_face_uv(Face *f, Point3 *tv);
    void PreProcess(INode* node, int& nodeCount);
    BOOL nodeEnum(INode* node, std::vector<LightObj>* li, 
									std::vector<CameraObj>* cameras, int& geomObjNum, int& vertWritten, TimeValue t);
		
		BOOL nodeEnumCheckGeometry(INode* node, unsigned int& allVerticesNum, unsigned int& allIndicesNum, TimeValue t);
		void geomObjToVsgf(GeometryObj* geom, int& vertWritten);
		void writeInit(std::ostream& a_out, unsigned int allVerticesNum, unsigned int allIndicesNum);
		//void writeUpdate(unsigned int verticesNum, unsigned int indicesNum, float* positions, float* normals, float* texcoords, unsigned int* vertIndices, unsigned int* matIndices);
		void writeFinal(std::ostream& a_out, std::istream& pos_in, std::istream& norm_in, std::istream& tex_in, std::istream& v_ind_in, std::istream& m_ind_in, unsigned int allVerticesNum, unsigned int allIndicesNum);
		void writeUpdateFloat(std::ostream& a_out, std::streamsize bytes, float* arr);
		void writeUpdateUint(std::ostream& a_out, std::streamsize bytes, unsigned int* arr);
		void readAndWrite(std::ostream& a_out, std::istream& a_in, unsigned int buf_size);
		Point3 ComputeSmGroupNormal(const std::vector<int>& faceIndeces, int faceNum, const std::vector<int> &face_smoothgroups, float *face_normals);
		/*void setData(uint32 a_vertNum, float* a_pos, float* a_norm, float* a_tangent, float* a_texCoord, 
								 uint32 a_indicesNum, uint32* a_triVertIndices, uint32* a_triMatIndices);
		void setNewGeometryObject(uint32 a_vertNum, float* a_pos, float* a_norm, float* a_tangent, float* a_texCoord, 
								 uint32 a_indicesNum, uint32* a_triVertIndices, uint32* a_triMatIndices);*/
		void writeVectorUpdateFloat(std::vector<float>& v_out, unsigned int elements, float* arr);
		void writeVectorUpdateUint(std::vector<unsigned int>& v_out, unsigned int elements, unsigned int* arr);
		void readVectorAndWrite(std::ostream& a_out, std::vector<float> &v_in);
		void readVectorAndWrite(std::ostream& a_out, std::vector<unsigned int> &v_in);
		void writeVectorFinal(std::ostream& a_out, std::vector<float> &pos_in, std::vector<float> &norm_in, std::vector<float> &tex_in, std::vector<unsigned int> &v_ind_in,std::vector<unsigned int> &m_ind_in, unsigned int allVerticesNum, unsigned int allIndicesNum);

		void writeXML(TimeValue t);

		void CheckGeomObject(INode* node, TimeValue t, unsigned int& allVerticesNum, unsigned int& allIndicesNum);

    void CalcMaxNormalsAsInExample(Mesh* mesh, GeometryObj* geom, Matrix3 tm);
    void CalcMaxNormalsAsInOpenColladaPlugin(Mesh* mesh, GeometryObj* geom, Matrix3 tm);
    
    void ExportNodeHeader(INode* node, TCHAR* type);
		void ExtractGeomObject(INode* node, GeometryObj* geom, TimeValue t);
    void ExtractMaterialList(std::vector<MaterialObj>* materials);
    void ExtractMaterial(Mtl* mtl, int mtlID, int subNo, MaterialObj* mat);
    void NullMaterial(MaterialObj* mat);
		void ExtractNodeTM(INode* node, GeometryObj* geom, TimeValue t);
		void ExtractNodeTM(INode* node, LightObj* li, TimeValue t);
		void ExtractLightObject(INode* node, LightObj* li, TimeValue t);
		void ExtractCamObject(INode* node, CameraObj* cam, TimeValue t);
    void ExtractLightSettings(LightState* ls, LightObject* light, TimeValue t, LightObj* li, bool isExtra);
    bool IsPhotometricMentalRayLight(LightObject* a_node);
    bool IsMrSkyPortal(LightObject* a_node);

  
		CameraObj ExtractCamObjFromMaxViewPortWindow(INode *vnode, ViewParams* a_viewParams, TimeValue t);
  
    LightObj* FindEnvLight(std::vector<LightObj>& a_lightsArray);

		//DWORD WINAPI ProcTexResolution(LPVOID lpParam);
    void DumpTexture(Texmap* tex, Class_ID cid, int subNo, float amt, TextureObj* texture);
    void MaxBitMapDataToTextureObj(Texmap* tex, TextureObj* texture);
    void MaxNormalMapToTextureObj(Texmap* tex, TextureObj* texture);
		void MaxOtherMapToTextureObj(Texmap* tex, TextureObj* texture);
    void DumpUVGen(StdUVGen* uvGen, TextureObj* texture);
    Point3 ComputeAverageNormal(std::vector < std::pair <Point3, int> > vn, int smGr);
    Point3 GetVertexNormal2(Mesh* mesh, int faceId, int vertexId);


    int ExtractAndDumpSceneData(std::vector<MaterialObj> &materials, std::vector<LightObj> &lights,
																std::vector<CameraObj>& cameras, INode* root, TimeValue t);

    inline float GetGlobalLightScale() const 
    { 
      if(GetUnitDisplayType() == UNITDISP_GENERIC)
        return 0.05f;
      else 
        return 0.0007f;
    }

    inline float toMeters(float a_val)
    {
      return GetMasterScale(UNITS_METERS)*a_val;
    }

    inline Point3 toMeters(Point3 p)
    {
      p.x = toMeters(p.x);
      p.y = toMeters(p.y);
      p.z = toMeters(p.z);
      return p;
    }

    inline Matrix3 toMeters(Matrix3 m)
    {
      Point3 translate = m.GetTrans();
      m.SetTrans(toMeters(translate));
      return m;
    }

    inline Matrix3 getConversionMatrix()
    {
      Matrix3 m;
      m.SetRow(0, Point3(1,0,0));
      m.SetRow(1, Point3(0,0,-1));
      m.SetRow(2, Point3(0,1,0));
      m.SetRow(3, Point3(0,0,0));
      return m;
    }

    // exploring IParamBlock2
    //
    IParamBlock2* FindBlockOfParameter(const std::wstring& a_paramName, ReferenceTarget* a_light);
    IParamBlock2* FindBlockOfParameter(const std::wstring& a_paramName, IParamBlock2* a_paramRec);

    bool  FindBool(const std::wstring& a_paramName,  ReferenceTarget* a_light);
    float FindFloat(const std::wstring& a_paramName, ReferenceTarget* a_light);
    Color FindColor(const std::wstring& a_paramName, ReferenceTarget* a_light);
    int FindInt(const std::wstring& a_paramName, ReferenceTarget* a_light);
    Texmap* FindTex(const std::wstring& a_paramName, ReferenceTarget* a_light);

    void TraceNodeCustomProperties(const std::wstring& a_objectName, ReferenceTarget* a_node, int deep = 0);
    void TraceIParamBlock2(const std::wstring& a_objectName, IParamBlock2* a_block, int deep = 0);
    void TraceIParamBlock(const std::wstring& a_objectName, IParamBlock* a_block, int deep = 0);

    //
    //
 
    IHydraNetPluginAPI* CreateHydraServerConnection();

    int FileTransfer(std::wstring name);
    int CreateConfigFile(std::wstring name);
    int CreateHeaderFile(std::wstring name, std::wstring type);

    void ExportMaterialsXML(std::ofstream& xmlFile, const std::vector<MaterialObj> &materials);
    void ExportLightsXML(std::ofstream& xmlFile, const std::vector<LightObj>& lights);
		void ExportCamerasXML(std::ofstream& xmlFile, const std::vector<CameraObj>& cameras, TimeValue t);

    void ExportOneTextureXML(std::ofstream& xmlFile, int slotId, const MaterialObj* mat, IFileResolutionManager* pFRM, std::string tag_name = "texture");
    void ExportTextureSamplerXML(std::ofstream& matFile, const TextureObj* tex, std::string tag_name = "sampler");
		std::string ExportTextureSamplerStr( StdUVGen* uvGen, std::string tag_name = "sampler");

    void FixPresets(TiXmlElement* root, int renderWidth, int renderHeight);
    void FixGuiByMethod(HydraRenderParamDlg* pGuiParams, int rendMethod, int rendQuality);
    void FixGuiForManualSettings(HydraRenderParamDlg* pGuiParams);

    inline BOOL	GetIncludeNormals()			{ return bIncludeNormals; }
    inline BOOL	GetIncludeTextureCoords()	{ return bIncludeTextureCoords; }
    inline int	GetMeshFrameStep()			{ return nMeshFrameStep; }
    inline int	GetKeyFrameStep()			{ return nKeyFrameStep; }
    inline TimeValue GetStaticFrame()		{ return nStaticFrame; }


    inline void SetMeshFrameStep(int val)			{ nMeshFrameStep = val; }
    inline void SetKeyFrameStep(int val)			{ nKeyFrameStep = val; }
    inline void SetStaticFrame(TimeValue val)		{ nStaticFrame = val; }
};



class hydraRender_mk3ClassDesc : public ClassDesc2 
{
public:
	virtual int IsPublic() 							{ return TRUE; }
	virtual void* Create(BOOL /*loading = FALSE*/) 		{ return new hydraRender_mk3(); }
	virtual const TCHAR *	ClassName() 			{ return GetString(IDS_CLASS_NAME); }
	virtual SClass_ID SuperClassID() 				{ return RENDERER_CLASS_ID; }
	virtual Class_ID ClassID() 						{ return hydraRender_mk3_CLASS_ID; }
	virtual const TCHAR* Category() 				{ return GetString(IDS_CATEGORY); }

	virtual const TCHAR* InternalName() 			{ return _T("hydraRender_mk3"); }	// returns fixed parsable name (scripter-visible name)
	virtual HINSTANCE HInstance() 					{ return hInstance; }					// returns owning module handle
	

};

static hydraRender_mk3ClassDesc hydraRender_mk3Desc;


static const Class_ID kTabClassID(0x71f46739, 0x266d64bc);
//static const Class_ID kTabClassID2(0x1d4f46df, 0x28162cac);

class HydraRenderParamDlg : public RendParamDlg 
{
   public:
      hydraRender_mk3 *rend;
      IRendParams *ir;
      HWND hMain;
			HWND hPathTracing, hSPPMC, hSPPMD, hToneMap, hIrrCache, hMulti, hEnv;
			int rollupIndices[8];
      BOOL prog;

			enum rollUps {SPPMC, SPPMD, MULTI, IRRCACHE, PATH, TONEMAP, MAIN, ENV};

			//main tab
			ICustEdit *focalplane_edit;
			ICustEdit *lensradius_edit;
			ICustEdit *timelimit_edit;

      ISpinnerControl *focalplane_spin;
			ISpinnerControl *lensradius_spin;
			ISpinnerControl *timelimit_spin;

			//path tracing tab
			ICustEdit *minrays_edit;
			ICustEdit *maxrays_edit;
			ICustEdit *raybounce_edit;
			ICustEdit *diffbounce_edit;
			ICustEdit *relative_error_edit;

			ISpinnerControl *minrays_spin;
			ISpinnerControl *maxrays_spin;
			ISpinnerControl *raybounce_spin;
			ISpinnerControl *diffbounce_spin;
			ISpinnerControl *relative_error_spin;

			//SPPM Caustics tab
			ICustEdit *maxphotons_c_edit;
			ICustEdit *initial_radius_c_edit;
			ICustEdit *caustic_power_edit;
			ICustEdit *retrace_c_edit;
			ICustEdit *alpha_c_edit;

			ISpinnerControl *maxphotons_c_spin;
			ISpinnerControl *initial_radius_c_spin;
			ISpinnerControl *caustic_power_spin;
			ISpinnerControl *retrace_c_spin;
			ISpinnerControl *alpha_c_spin;

			//SPPM Diffuse tab
			ICustEdit *maxphotons_d_edit;
			ICustEdit *initial_radius_d_edit;
			ICustEdit *retrace_d_edit;
			ICustEdit *alpha_d_edit;

			ISpinnerControl *maxphotons_d_spin;
			ISpinnerControl *initial_radius_d_spin;
			ISpinnerControl *retrace_d_spin;
			ISpinnerControl *alpha_d_spin;
			
			//Irradiance cache tab
			ICustEdit *ws_err_edit;
			ICustEdit *ss_err4_edit;
			ICustEdit *ss_err2_edit;
			ICustEdit *ss_err1_edit;
			ICustEdit *maxpass_edit;
			ICustEdit *ic_relative_error_edit;

			ISpinnerControl *ws_err_spin;
			ISpinnerControl *ss_err4_spin;
			ISpinnerControl *ss_err2_spin;
			ISpinnerControl *ss_err1_spin;
			ISpinnerControl *maxpass_spin;
			ISpinnerControl *ic_relative_error_spin;
			
			//Tone mapping tab
			ICustEdit *white_point_edit;
			ICustEdit *gamma_edit;
			ICustEdit *strength_edit;
			ICustEdit *phi_edit;

			ISpinnerControl *white_point_spin;
			ISpinnerControl *gamma_spin;
			ISpinnerControl *strength_spin;
			ISpinnerControl *phi_spin;

			ICustButton *tone_map;

			//Multi-Layer tab
			ICustEdit *s_sigma_edit;
			ICustEdit *r_sigma_edit;
			ICustEdit *layer_num_edit;

			ISpinnerControl *s_sigma_spin;
			ISpinnerControl *r_sigma_spin;
			ISpinnerControl *layer_num_spin;

			//Environment
			ICustEdit *env_mult_edit;
			ISpinnerControl *env_mult_spin;

		
      HydraRenderParamDlg(hydraRender_mk3 *r,IRendParams *i,BOOL prog);
      ~HydraRenderParamDlg();
      void AcceptParams();
      void RejectParams();
      void DeleteThis() {delete this;}

      void InitMainHydraDialog(HWND hWnd);
			void InitPathTracingDialog(HWND hWnd);
			void InitSPPMCDialog(HWND hWnd);
			void InitSPPMDDialog(HWND hWnd);
			void InitIrrCacheDialog(HWND hWnd);
			void InitToneMapDialog(HWND hWnd);
			void InitMultiLayerDialog(HWND hWnd);
			void InitEnvironmentDialog(HWND hWnd);

      void InitProgDialog(HWND hWnd);

			void RemovePage(HWND &hPanel);
			void AddPage(HWND &hPanel, int IDD);
};



std::string GetMethodPresets(int methodId, int qualityId);
std::string GetCorrectTexPath(const wchar_t* a_name, IFileResolutionManager* pFRM);

void FixValueXML(TiXmlElement* root, const std::string& fieldName, const std::string& fieldValue);
int GetIntValueXML(TiXmlElement* node, const std::string& fieldName);
float GetFloatValueXML(TiXmlElement* node, const std::string& fieldName);

std::string MethodName(int a_name);
float angleOfEdges(Point3 edgeA, Point3 edgeB);
bool isFileExist(const char *fileName);

#endif // __HYDRARENDER_H__