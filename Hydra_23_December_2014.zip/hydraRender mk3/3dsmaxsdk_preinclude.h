//**************************************************************************/
// Copyright (c) 1998-2005 Autodesk, Inc.
// All rights reserved.
// 
// These coded instructions, statements, and computer programs contain
// unpublished proprietary information written by Autodesk, Inc., and are
// protected by Federal copyright law. They may not be disclosed to third
// parties or copied or duplicated in any form, in whole or in part, without
// the prior written consent of Autodesk, Inc.
//**************************************************************************/
// DESCRIPTION: Include this file before including any 3ds Max SDK files. It 
//              define the macros required to add linkable todo compile-time 
//              messages and lower the warning level to 3.
// AUTHOR: Jean-Francois Yelle - created Mar.20.2007
//***************************************************************************/

// useful for #pragma message
#define STRING2(x) #x
#define STRING(x) STRING2(x)
#define TODO(x) __FILE__ "(" STRING(__LINE__) "): TODO: "x

#include "winsock2.h"
#include "Max.h"
#include "bmmlib.h"
#include "meshadj.h"
#include "modstack.h"
#include "stdmat.h"
#include "templt.h"
#include "render.h"
#include <float.h>		// Include these guys, otherwise sqrt() doesn't work!
#include <math.h>
#include <notify.h>


//2012
#include <string>
//#include "dataclassdesc.h"
//#include "plugapi.h"
//#include "baseinterface.h"