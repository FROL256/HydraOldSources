#include "hydraRender mk3.h"
#include <hash_map>
#include <sys/stat.h>
#include <time.h>
#include <sstream>
#include <thread>
 
#include <codecvt>

// convert UTF - 8 string to wstring
std::wstring utf8_to_wstring(const std::string& str)
{
  std::wstring_convert<std::codecvt_utf8<wchar_t>> myconv;
  return myconv.from_bytes(str);
}

// convert wstring to UTF-8 string
std::string wstring_to_utf8(const std::wstring& str)
{
  std::wstring_convert<std::codecvt_utf8<wchar_t>> myconv;
  return myconv.to_bytes(str);
}

namespace VRayMtlParameters 
{
	#define VRAYMTL_NSUBTEX 17
 
	#define VRAYMTL_SUBTEXNO_DIFFUSE 0
	#define VRAYMTL_SUBTEXNO_REFLECT 1
	#define VRAYMTL_SUBTEXNO_REFRACT 2
	#define VRAYMTL_SUBTEXNO_BUMP 3
	#define VRAYMTL_SUBTEXNO_REFLECT_GLOSSINESS 4
	#define VRAYMTL_SUBTEXNO_REFRACT_GLOSSINESS 5
	#define VRAYMTL_SUBTEXNO_DISPLACEMENT 6
	#define VRAYMTL_SUBTEXNO_ENVIRONMENT 7
	#define VRAYMTL_SUBTEXNO_TRANSLUCENCY 8
	#define VRAYMTL_SUBTEXNO_IOR 9
	#define VRAYMTL_SUBTEXNO_HILIGHT_GLOSSINESS 10
	#define VRAYMTL_SUBTEXNO_FRESNELIOR 11
	#define VRAYMTL_SUBTEXNO_OPACITY 12
	#define VRAYMTL_SUBTEXNO_ROUGHNESS 13
	#define VRAYMTL_SUBTEXNO_ANISO 14
	#define VRAYMTL_SUBTEXNO_ANISO_ROTATION 15
	#define VRAYMTL_SUBTEXNO_FOG 16

  // Parameter block IDs
  enum 
	{
    vrayMtl_old_id,
    vrayMtl_basic_id,
    vrayMtl_BRDF_id,
    vrayMtl_options_id,
    vrayMtl_maps_id,
    vrayMtl_reflIMap_id,
    vrayMtl_refrIMap_id,
  };
 
 
#define SUBTEX_PARAM_ID 100
#define ON_OFFSET 50
#define MULT_OFFSET 100
 
#define VRAYMTL_TEXMAP_PARAMID(subtexNo) (SUBTEX_PARAM_ID+subtexNo)
#define VRAYMTL_TEXMAP_ON_PARAMID(subtexNo) (SUBTEX_PARAM_ID+subtexNo+ON_OFFSET)
#define VRAYMTL_TEXMAP_MULT_PARAMID(subtexNo) (SUBTEX_PARAM_ID+subtexNo+MULT_OFFSET)
 
}




inline bool file_exists (const std::string& name) {
  struct stat buffer;   
  return (stat (name.c_str(), &buffer) == 0); 
}



void hydraRender_mk3::ExtractMaterialList(std::vector<MaterialObj>* materials)
{
  //if (!incl.materials)
    //return;
	
  int numMtls = mtlList.Count();
  int newMtlIndex = 0;

  for (int i = 0; i < numMtls; i++) 
  {
    int subMats = mtlList.GetMtl(i)->NumSubMtls();
    if(subMats == 0)
    {
      MaterialObj mat;
      ExtractMaterial(mtlList.GetMtl(i), newMtlIndex, -1, &mat);

      //if(materialByName.find(mat.name) == materialByName.end())
      if (materialByAddress.find(mtlList.GetMtl(i)) == materialByAddress.end())
      {
        materials->push_back(mat);
        materialByAddress[mtlList.GetMtl(i)] = newMtlIndex;
        newMtlIndex++;
      }
    }
    else
    {
      for(int j = 0; j < subMats; j++)
      {
        Mtl* subMtl = mtlList.GetMtl(i)->GetSubMtl(j);
        if (subMtl) 
        {
          MaterialObj mat;
          ExtractMaterial(subMtl, 0, newMtlIndex, &mat);

          //if(materialByName.find(mat.name) == materialByName.end())
          if (materialByAddress.find(subMtl) == materialByAddress.end())
          {
            materials->push_back(mat);
            materialByAddress[subMtl] = newMtlIndex;
            newMtlIndex++;
          }
        }    
      }
    }
  }

  if(numMtls == 0)
  {
    MaterialObj mat;
    NullMaterial(&mat);
    materials->push_back(mat);
  }

  // fill material id's
  //
  std::vector<MaterialObj>::const_iterator mat;
  for(mat = materials->begin(); mat != materials->end(); ++mat)
  {
    int maxId = int(mat - materials->begin());
    material_dict_max_index[maxId] = mat->name;
  }

}


void hydraRender_mk3::ExtractMaterial(Mtl* mtl, int mtlID, int subNo, MaterialObj* mat)
{
  int i;
  TimeValue t = GetStaticFrame();

  if (!mtl) return;

  TSTR className;
  mtl->GetClassName(className);


  if (subNo == -1) 
  {
    mat->id = mtlID;
    mat->sub = 0;
  }
  else
    mat->id = subNo;

  mat->name = mtl->GetName();

  const ULONG HYDRA_MAT_CLASS_ID_PART_A = 0xa3f0e60d;
	const ULONG VRAYMTL_CLASS_ID_PART_A = 0x37bf3f2f;

  if (mtl->NumSubMtls() == 0)  
  {

    if (mtl->ClassID().PartA() == DMTL_CLASS_ID) 
    {
      StdMat2* std = (StdMat2*)mtl;

      mat->ambient_color[0] = std->GetAmbient(t).r;
      mat->ambient_color[1] = std->GetAmbient(t).g;
      mat->ambient_color[2] = std->GetAmbient(t).b;

      mat->diffuse_color[0] = std->GetDiffuse(t).r;
      mat->diffuse_color[1] = std->GetDiffuse(t).g;
      mat->diffuse_color[2] = std->GetDiffuse(t).b;

      mat->specular_color[0] = std->GetSpecular(t).r;
      mat->specular_color[1] = std->GetSpecular(t).g;
      mat->specular_color[2] = std->GetSpecular(t).b;

      mat->emission_color[0] = std->GetSelfIllumColor(t).r;
      mat->emission_color[1] = std->GetSelfIllumColor(t).g;
      mat->emission_color[2] = std->GetSelfIllumColor(t).b;

      mat->filter_color[0] = std->GetFilter(t).r;
      mat->filter_color[1] = std->GetFilter(t).g;
      mat->filter_color[2] = std->GetFilter(t).b;

      mat->shininess      = std->GetShininess(t);
      mat->shine_strength = std->GetShinStr(t);
      mat->transparency   = std->GetXParency(t);
      
      switch(std->GetShading()) 
      {
      case SHADE_CONST:
        mat->shading = L"CONST";
        break;
      case SHADE_PHONG:
        mat->shading = L"PHONG";
        break;
      case SHADE_METAL:
        mat->shading = L"METAL";
        break;
      case SHADE_BLINN:
        mat->shading = L"PHONG";
        break;
      default:
        mat->shading = L"OTHER";
        break;
      }

      mat->opacity           = std->GetOpacity(t);
      mat->IOR               = std->GetIOR(t);
      mat->opacity_falloff   = std->GetOpacFalloff(t);
      mat->self_illumination = std->GetSelfIllum(t);

      mat->twosided          = std->GetTwoSided();
      mat->falloff           = std->GetFalloffOut();
      mat->facemap           = std->GetFaceMap();
      mat->soften            = std->GetSoften();

      switch (std->GetTransparencyType()) 
      {
      case TRANSP_FILTER:
        mat->transparency_type = L"FILTER";
        break;
      case TRANSP_SUBTRACTIVE:
        mat->transparency_type = L"SUBTRACTIVE";
        break;
      case TRANSP_ADDITIVE:
        mat->transparency_type = L"ADDITIVE";
        break;
      default: 
        mat->transparency_type = L"OTHER";
        break;
      }

			mat->displacement_on = true; // always true for standart materials see xml export, use other variable to detect absence
    }
    else  if (mtl->ClassID().PartA() == HYDRA_MAT_CLASS_ID_PART_A)
    {
      mat->isHydraNative = true;

      mat->diffuse_color[0] = FindColor(L"DiffuseColor", mtl).r;
      mat->diffuse_color[1] = FindColor(L"DiffuseColor", mtl).g;
      mat->diffuse_color[2] = FindColor(L"DiffuseColor", mtl).b;

      mat->emission_color[0] = FindColor(L"EmissionColor", mtl).r;
      mat->emission_color[1] = FindColor(L"EmissionColor", mtl).g;
      mat->emission_color[2] = FindColor(L"EmissionColor", mtl).b;

      mat->reflect_color[0] = FindColor(L"ReflectivityColor", mtl).r;
      mat->reflect_color[1] = FindColor(L"ReflectivityColor", mtl).g;
      mat->reflect_color[2] = FindColor(L"ReflectivityColor", mtl).b;

      mat->transparency_color[0] = FindColor(L"TransparencyColor", mtl).r;
      mat->transparency_color[1] = FindColor(L"TransparencyColor", mtl).g;
      mat->transparency_color[2] = FindColor(L"TransparencyColor", mtl).b;

      mat->fog_color[0] = FindColor(L"FogColor", mtl).r;
      mat->fog_color[1] = FindColor(L"FogColor", mtl).g;
      mat->fog_color[2] = FindColor(L"FogColor", mtl).b;

      mat->exit_color[0] = FindColor(L"ExitColor", mtl).r;
      mat->exit_color[1] = FindColor(L"ExitColor", mtl).g;
      mat->exit_color[2] = FindColor(L"ExitColor", mtl).b;

			mat->translucency_color[0] = FindColor(L"TranslucencyColor", mtl).r;
			mat->translucency_color[1] = FindColor(L"TranslucencyColor", mtl).g;
			mat->translucency_color[2] = FindColor(L"TranslucencyColor", mtl).b;

      mat->displacement_on = FindBool(L"DisplacementState", mtl);
      mat->displacement_invert_height_on = FindBool(L"DisplacementInvertHeightState", mtl);
      mat->diffuse_mult_on = FindBool(L"DiffuseColorMultiplier", mtl);   
      mat->emission_mult_on = FindBool(L"EmissionColorMultiplier", mtl);
      mat->transparency_mult_on = FindBool(L"TransparencyColorMultiplier", mtl);
      mat->reflect_mult_on = FindBool(L"ReflectColorMultiplier", mtl);
      mat->transparency_thin_on = FindBool(L"ThinTransparency", mtl);
			mat->affect_shadows_on = FindBool(L"AffectShadows", mtl);
			mat->no_ic_records = FindBool(L"NoICRecords", mtl);
			mat->emission_gi = FindBool(L"EmissionGI", mtl);
			mat->shadow_matte = FindBool(L"ShadowMatte", mtl);
			mat->translucency_mult_on = FindBool(L"TranslucencyColorMultOn", mtl);
			
			mat->reflect_ior         = FindFloat(L"ReflectivityIOR", mtl);
			mat->reflect_roughness   = FindFloat(L"ReflectivityRoughness", mtl);
      mat->reflect_cospower    = FindFloat(L"ReflectivityCosPower", mtl);
      mat->transparency_cospower = FindFloat(L"TransparencyCosPower", mtl);
      mat->fog_multiplier      = FindFloat(L"FogMultiplier", mtl);
      mat->displacement_height = FindFloat(L"Height", mtl);
      mat->diffuse_mult        = FindFloat(L"DiffuseColorMultiplier", mtl);
      mat->emission_mult       = FindFloat(L"EmissionColorMultiplier", mtl);
      mat->transparency_mult   = FindFloat(L"TransparencyColorMultiplier", mtl);
      mat->reflect_mult        = FindFloat(L"ReflectColorMultiplier", mtl);
			mat->translucency_mult = FindFloat(L"TranslucencyColorMultiplier", mtl);
			mat->bump_amount = FindFloat(L"BumpAmount", mtl);
			mat->bump_radius = FindFloat(L"BumpRadius", mtl);
			mat->bump_sigma = FindFloat(L"BumpSigma", mtl);

      mat->reflect_brdf = FindInt(L"ReflectivityBRDF", mtl);
      if(mat->reflect_brdf == 1) // fresnel dielectric
        mat->reflect_brdf = 3;

      mat->IOR = FindFloat(L"IOR", mtl);
			mat->reflect_gloss_or_cos = FindInt(L"ReflectGlossOrCos", mtl);
			mat->transparency_gloss_or_cos = FindInt(L"TranspGlossOrCos", mtl);	
			mat->reflect_glossiness = FindFloat(L"ReflectGlossiness", mtl);
			mat->transparency_glossiness = FindFloat(L"TranspGlossiness", mtl);		
			mat->reflect_fresnel_on = FindBool(L"ReflectFresnelOn", mtl);
			mat->lock_specular = FindBool(L"LockSpecularToReflection", mtl);

			if(mat->lock_specular)
			{
				mat->specular_color[0] = mat->reflect_color[0];
				mat->specular_color[1] = mat->reflect_color[1];
				mat->specular_color[2] = mat->reflect_color[2];
				mat->specular_mult_on = mat->reflect_mult_on;
				mat->specular_ior          = mat->reflect_ior;
				mat->specular_roughness    = mat->reflect_roughness;
				mat->specular_cospower     = mat->reflect_cospower;
				mat->specular_mult         = mat->reflect_mult;
				mat->specular_brdf         = mat->reflect_brdf;
				mat->specular_gloss_or_cos = mat->reflect_gloss_or_cos;
				mat->specular_glossiness   = mat->reflect_glossiness;
				mat->specular_fresnel_on   = mat->reflect_fresnel_on;
			}
			else
			{
				mat->specular_color[0] = FindColor(L"SpecularColor", mtl).r;
				mat->specular_color[1] = FindColor(L"SpecularColor", mtl).g;
				mat->specular_color[2] = FindColor(L"SpecularColor", mtl).b;
				mat->specular_mult_on = FindBool(L"SpecularColorMultiplier", mtl);
				mat->specular_ior        = FindFloat(L"SpecularIOR", mtl);
				mat->specular_roughness  = FindFloat(L"SpecularRoughness", mtl);
				mat->specular_cospower   = FindFloat(L"SpecularCosPower", mtl);
				mat->specular_mult       = FindFloat(L"SpecularColorMultiplier", mtl);
				mat->specular_brdf = FindInt(L"SpecularBRDF", mtl);
        if(mat->specular_brdf == 1) // fresnel dielectric
          mat->specular_brdf = 3;
				
        mat->specular_gloss_or_cos = FindInt(L"SpecularGlossOrCos", mtl);
				mat->specular_glossiness = FindFloat(L"SpecularGlossiness", mtl);
				mat->specular_fresnel_on = FindBool(L"SpecularFresnelOn", mtl);
			}
    }
		else  if (mtl->ClassID().PartA() == VRAYMTL_CLASS_ID_PART_A) 
    {
			mat->isVrayMtl = true;
			mat->diffuse_color[0] = FindColor(L"diffuse", mtl).r;
      mat->diffuse_color[1] = FindColor(L"diffuse", mtl).g;
      mat->diffuse_color[2] = FindColor(L"diffuse", mtl).b;

      mat->emission_color[0] = FindColor(L"selfIllumination", mtl).r;
      mat->emission_color[1] = FindColor(L"selfIllumination", mtl).g;
      mat->emission_color[2] = FindColor(L"selfIllumination", mtl).b;

      mat->reflect_color[0] = FindColor(L"reflection", mtl).r;
      mat->reflect_color[1] = FindColor(L"reflection", mtl).g;
      mat->reflect_color[2] = FindColor(L"reflection", mtl).b;

      mat->reflect_glossiness  = FindFloat(L"reflection_glossiness", mtl);
      mat->specular_glossiness = mat->reflect_glossiness;

      mat->transparency_color[0] = FindColor(L"refraction", mtl).r;
      mat->transparency_color[1] = FindColor(L"refraction", mtl).g;
      mat->transparency_color[2] = FindColor(L"refraction", mtl).b;

      if(mat->transparency_color[0] > 1e-5f || mat->transparency_color[1] > 1e-5f || mat->transparency_color[2] > 1e-5f)
      {
        mat->reflect_brdf = 3; // fresnel_dielectric
        mat->transparency = 1.0f;
      }
      else
      {
        mat->reflect_brdf = 0; //phong
        mat->transparency = 0.0f;
      }

      mat->fog_color[0] = FindColor(L"refraction_fogColor", mtl).r;
      mat->fog_color[1] = FindColor(L"refraction_fogColor", mtl).g;
      mat->fog_color[2] = FindColor(L"refraction_fogColor", mtl).b;

      mat->exit_color[0] = FindColor(L"refract_exitColor", mtl).r;
      mat->exit_color[1] = FindColor(L"refract_exitColor", mtl).g;
      mat->exit_color[2] = FindColor(L"refract_exitColor", mtl).b;

			mat->affect_shadows_on = true; //FindBool(L"refraction_affectShadows", mtl);
			mat->emission_gi = FindBool(L"selfIllumination_gi", mtl);
			
			mat->reflect_ior = FindFloat(L"reflection_ior", mtl);

      mat->IOR = FindFloat(L"refraction_ior", mtl);
			mat->reflect_gloss_or_cos = 0;
			mat->transparency_gloss_or_cos = 0;
			mat->reflect_glossiness = FindFloat(L"reflection_glossiness", mtl);
			mat->transparency_glossiness = FindFloat(L"refraction_glossiness", mtl);		
			mat->reflect_fresnel_on = FindBool(L"reflection_fresnel", mtl);
			mat->fog_multiplier = FindFloat(L"refraction_fogMultiplier", mtl);		

			mat->specular_color[0] = mat->reflect_color[0];
			mat->specular_color[1] = mat->reflect_color[1];
			mat->specular_color[2] = mat->reflect_color[2];
			mat->specular_ior      = mat->reflect_ior;
			mat->specular_gloss_or_cos = mat->reflect_gloss_or_cos;
			mat->lock_specular = FindBool(L"reflection_lockGlossiness", mtl);

			if(!mat->lock_specular)
				mat->specular_glossiness = FindFloat(L"hilight_glossiness", mtl);
			else
				mat->specular_glossiness = mat->reflect_glossiness;

			mat->specular_fresnel_on = mat->reflect_fresnel_on;
			mat->specular_brdf = mat->reflect_brdf;

			mat->bump_amount = FindFloat(L"texmap_bump_multiplier", mtl);
			mat->displacement_height = FindFloat(L"texmap_displacement_multiplier", mtl);
			mat->displacement_on = FindBool(L"texmap_displacement_on", mtl);

			mat->diffuse_mult        = FindFloat(L"texmap_diffuse_multiplier", mtl) / 100;
      mat->transparency_mult   = FindFloat(L"texmap_refraction_multiplier", mtl) / 100;
      mat->reflect_mult        = FindFloat(L"texmap_reflection_multiplier", mtl) / 100;
			mat->specular_mult       = mat->reflect_mult;
			mat->emission_mult       = FindFloat(L"texmap_selfIllumination_multiplier", mtl) / 100;
			//FindFloat(L"selfIllumination_multiplier", mtl)
	  }
    else
    {
      mat->ambient_color[0] = mtl->GetAmbient(t).r;
      mat->ambient_color[1] = mtl->GetAmbient(t).g;
      mat->ambient_color[2] = mtl->GetAmbient(t).b;

      mat->diffuse_color[0] = mtl->GetDiffuse(t).r;
      mat->diffuse_color[1] = mtl->GetDiffuse(t).g;
      mat->diffuse_color[2] = mtl->GetDiffuse(t).b;

      mat->specular_color[0] = mtl->GetSpecular(t).r;
      mat->specular_color[1] = mtl->GetSpecular(t).g;
      mat->specular_color[2] = mtl->GetSpecular(t).b;

      mat->emission_color[0] = 0.0f;
      mat->emission_color[1] = 0.0f;
      mat->emission_color[2] = 0.0f;

      mat->shininess         = mtl->GetShininess(t);
      mat->shine_strength    = mtl->GetShinStr(t);
      mat->transparency      = mtl->GetXParency(t);
      mat->opacity           = 0.0f; //mtl->GetOpacity(t);
      mat->IOR               = 1.0f; //mtl->GetIOR(t);
      mat->opacity_falloff   = 0.0f; //mtl->GetOpacFalloff(t);
      mat->self_illumination = mtl->GetSelfIllum(t);
    }
		


    mat->textureSlotNames.clear();
    mat->textures.clear();
    mat->textureAmount.clear();

    mat->textureSlotNames.resize(mtl->NumSubTexmaps());
    mat->textureAmount.resize(mtl->NumSubTexmaps());

    std::wstring hydraMapNames[] = {L"DiffuseMap", L"SpecularMap",  L"ReflectivityMap", L"EmissionMap",
																		L"TransparencyMap", L"NormalMap", L"SpecularGlossinessMap",
																		L"ReflectGlossinessMap", L"TranspGlossinessMap", L"OpacityMap", L"TranslucencyMap"};

		std::wstring vrayMapNames[] = {L"texmap_diffuse", L"texmap_reflection",  L"texmap_refraction", L"texmap_bump",
																		L"texmap_reflectionGlossiness", L"texmap_refractionGlossiness", L"texmap_ior", L"texmap_displacement", L"texmap_translucent",
																		L"texmap_environment", L"texmap_hilightGlossiness", L"texmap_reflectionIOR", L"texmap_opacity", L"texmap_roughness",
																		L"texmap_anisotropy", L"texmap_anisotropy_rotation", L"texmap_fog", L"texmap_selfIllumination"};

    for (i=0; i<mtl->NumSubTexmaps(); i++) 
    {
      Texmap* subTex;
      if(mat->isHydraNative)
        subTex = FindTex(hydraMapNames[i], mtl);
      else if(mat->isVrayMtl)
				subTex = FindTex(vrayMapNames[i], mtl);
			else
				subTex = mtl->GetSubTexmap(i);
      float amt = 1.0f;
      if (subTex) 
      {
        // If it is a standard material we can see if the map is enabled.
        if (mtl->ClassID() == Class_ID(DMTL_CLASS_ID, 0)) 
        {
          if (!((StdMat*)mtl)->MapEnabled(i))
            continue;
          amt = ((StdMat*)mtl)->GetTexmapAmt(i, 0);
        }
				else if(mtl->ClassID().PartA() == VRAYMTL_CLASS_ID_PART_A)
				{
					if(!FindBool(vrayMapNames[i]+L"_on", mtl))
						continue;
				}

        TextureObj tex;
        DumpTexture(subTex, mtl->ClassID(), i, amt, &tex);
        mat->textures.push_back(tex);

        MSTR slotName = mtl->GetSubTexmapSlotName(i);
        const wchar_t* slotNameData = slotName.data();
				if (slotName == L"Hilight gloss")
					mat->hilight_gloss_tex = true;
				if (slotName == L"texmap_reflectionGlossiness" || slotName == L"Refl. gloss.")
					mat->reflect_gloss_tex = true;
				if (slotName == L"texmap_refractionGlossiness" || slotName == L"Refr. gloss.")
					mat->refr_gloss_tex = true;
        mat->textureSlotNames[mat->textures.size()-1] = std::wstring(slotNameData); 
        mat->textureAmount   [mat->textures.size()-1] = amt;
      }
    }
  } 

 
  //TraceNodeCustomProperties (mat->name, mtl, 1);
}

void hydraRender_mk3::NullMaterial(MaterialObj* mat)
{

  mat->name = L"null_plugin_export_material";
  mat->num_subMat = 0;
  mat->id = 0;

  mat->ambient_color[0] = 0.01;
  mat->ambient_color[1] = 0.01;
  mat->ambient_color[2] = 0.01;

  mat->diffuse_color[0] = 0.5;
  mat->diffuse_color[1] = 0.5;
  mat->diffuse_color[2] = 0.5;

  mat->specular_color[0] = 0;
  mat->specular_color[1] = 0;
  mat->specular_color[2] = 0;

  mat->filter_color[0] = 0;
  mat->filter_color[1] = 0;
  mat->filter_color[2] = 0;

  mat->shininess = 80;
  mat->shine_strength = 0;
  mat->transparency = 0;

  mat->shading = L"PHONG";

  mat->opacity = 0;
  mat->IOR = 0;
  mat->opacity_falloff = 0;
  mat->self_illumination = 0;

  mat->twosided = 0;
  mat->falloff = 0;

  mat->facemap = 0;
  mat->soften = 0;

  mat->transparency_type = L"FILTER";

  mat->isHydraNative = false;

  mat->emission_color[0] = 0;
  mat->emission_color[1] = 0;
  mat->emission_color[2] = 0;

  mat->reflect_color[0] = 0;
  mat->reflect_color[1] = 0;
  mat->reflect_color[2] = 0;

  mat->transparency_color[0] = 0;
  mat->transparency_color[1] = 0;
  mat->transparency_color[2] = 0;

	mat->translucency_color[0] = 0;
	mat->translucency_color[1] = 0;
	mat->translucency_color[2] = 0;

  mat->fog_color[0] = 0;
  mat->fog_color[1] = 0;
  mat->fog_color[2] = 0;

  mat->exit_color[0] = 0;
  mat->exit_color[1] = 0;
  mat->exit_color[2] = 0;

  mat->displacement_on = 0;
  mat->displacement_invert_height_on = 0;
  mat->diffuse_mult_on = 0;
  mat->specular_mult_on = 0;
  mat->emission_mult_on = 0;
  mat->transparency_mult_on = 0;
  mat->reflect_mult_on = 0;
  mat->transparency_thin_on = 0;
	mat->affect_shadows_on = 1;
	mat->translucency_mult_on = 0;

	mat->specular_ior = 0;
	mat->reflect_ior = 0;
  mat->specular_roughness = 0;
	mat->reflect_roughness = 0;
  mat->reflect_cospower = 0;
  mat->transparency_cospower = 0;
	mat->specular_cospower = 0;
  mat->fog_multiplier = 0;
  mat->displacement_height = 0;
  mat->diffuse_mult = 0;
  mat->specular_mult = 0;
  mat->emission_mult = 0;
  mat->transparency_mult = 0;
  mat->reflect_mult = 0;
	mat->translucency_mult = 0;

	mat->no_ic_records = false;

  mat->specular_brdf = 0;
  mat->reflect_brdf = 0;

	mat->specular_gloss_or_cos = 1;
	mat->reflect_gloss_or_cos = 1;
	mat->transparency_gloss_or_cos = 1;
	mat->specular_glossiness = 1;
	mat->reflect_glossiness = 1;
	mat->transparency_glossiness = 1;
	mat->specular_fresnel_on = false;
	mat->reflect_fresnel_on = false;

	mat->lock_specular = true;
	mat->hilight_gloss_tex = false;
	mat->refr_gloss_tex = false;
	mat->reflect_gloss_tex = false;
	mat->shadow_matte = false;
}

void hydraRender_mk3::DumpTexture(Texmap* tex, Class_ID cid, int subNo, float amt, TextureObj* texture)
{
  if (!tex) 
    return;

  TSTR className;
  tex->GetClassName(className);

  texture->texName = tex->GetName();
  texture->texClass = className;

  // If we include the subtexture ID, a parser could be smart enough to get
  // the class name of the parent texture/material and make it mean something.
  //fprintf(pStream,"%s\t%s %d\n", indent.data(), ID_TEXSUBNO, subNo);

  texture->texAmount = amt;

  // Is this a simple bitmap texture?
  // We know some extra bits 'n pieces about the bitmap texture
  //
  if (tex->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00)) 
  {
    MaxBitMapDataToTextureObj(tex, texture);
  }
  else if(texture->texClass == L"Normal Bump") // this is normalmap based bump texture
  {
    MaxNormalMapToTextureObj(tex, texture);
  }
	else
	{
		MaxOtherMapToTextureObj(tex, texture);
	}

}

void tryResolution(Texmap* tx, int& res)
{
	const int resolution = res;

	Bitmap *bmap;
	Bitmap *bmap2;
	//Bitmap *bmap3;
	BitmapInfo bi, bi2/*, bi3*/;

	BMM_Color_64 **upSc = new BMM_Color_64*[resolution*2];
	BMM_Color_64 *computed = new BMM_Color_64[resolution*2];
	BMM_Color_64 *temp = new BMM_Color_64[resolution];

	/*TSTR mapName = tData->tex->GetName();
	std::wstring mapPath, mapName_w, mapPath2;
	mapName_w = mapName;
	mapPath = L"C:\\[Hydra]\\pluginFiles\\upScale" + mapName_w + L".bmp";
	mapPath2 = L"C:\\[Hydra]\\pluginFiles\\comp" + mapName_w + L".bmp";*/

	for(int i = 0; i < resolution*2; ++i)
	{
    upSc[i] = new BMM_Color_64[resolution*2];
	}

	bi.SetType(BMM_TRUE_64);
	bi.SetWidth(resolution);
	bi.SetHeight(resolution);
	//bi.SetFlags(MAP_HAS_ALPHA);
	bi.SetCustomFlag(0);
	
	//bi.SetPath(mapPath.c_str());
	bmap = TheManager->Create(&bi);
	tx->RenderBitmap(0, bmap);

	bi2.SetType(BMM_TRUE_64);
	bi2.SetWidth(resolution*2);
	bi2.SetHeight(resolution*2);
	//bi.SetFlags(MAP_HAS_ALPHA);
	bi2.SetCustomFlag(0);

	//bi2.SetPath(mapPath2.c_str());
	bmap2 = TheManager->Create(&bi2);
	tx->RenderBitmap(0, bmap2);

	bmap2->OpenOutput(& bi2);
	bmap2->Write(&bi2);
	bmap2->Close(& bi2);

	/*bi3.SetType(BMM_TRUE_64);
	bi3.SetWidth(resolution*2);
	bi3.SetHeight(resolution*2);
	//bi.SetFlags(MAP_HAS_ALPHA);
	bi3.SetCustomFlag(0);

	//bi3.SetPath(mapPath.c_str());

	bmap3 = TheManager->Create(&bi3);*/

	for(int i = 0; i < resolution; i++)
	{
		bmap->GetPixels(0, i, resolution, temp);
		for(int j = 0; j < resolution; j++)
		{
			upSc[i*2][j*2] = temp[j];	
			upSc[i*2][j*2+1] = temp[j];

			upSc[i*2+1][j*2] = temp[j];	
			upSc[i*2+1][j*2+1] = temp[j];
		}
	/*	bmap3->PutPixels(0, i*2, resolution*2, upSc[i*2]);
		bmap3->PutPixels(0, i*2 + 1, resolution*2, upSc[i*2 + 1]);*/
	}

/*	bmap3->OpenOutput(& bi3);
	bmap3->Write(&bi3);
	bmap3->Close(& bi3);*/

	int errCount = 0;


	for(int i = 0; i < resolution*2; i++)
	{
		bmap2->GetPixels(0, i, resolution*2, computed);
		for(int j = 0; j < resolution*2; j++)
		{
			int err = abs(upSc[i][j].r - computed[j].r) +	abs(upSc[i][j].g - computed[j].g) + abs(upSc[i][j].b - computed[j].b);
			if(err > 66*5) //~5% for 16-bit per channel
				errCount++;		
		}
		if(errCount > 5*(resolution*resolution*4)/100) //~5%
			break;

	}

	if(errCount > 5*(resolution*resolution*4)/100) //~5%
		res = resolution*2;

	bmap->DeleteThis();
	bmap2->DeleteThis();

	for(int i = 0; i <resolution*2; ++i) 
	{
    delete [] upSc[i];
	}
	delete [] upSc;
	delete [] computed;
	delete [] temp;
}


void ProcTexResolutionT(std::vector<Texmap*> texmaps, std::vector<Texmap*>::iterator begin, std::vector<Texmap*>::iterator end)
{
	HydraLogger plugin_log2;
	plugin_log2.OpenLogFile("C:/[Hydra]/pluginFiles/plugin_log2.txt");
	for (auto it = begin; it != end; ++it) 
	{
		plugin_log2.PrintValue("Enter, thread id:", std::this_thread::get_id());
		Texmap* texD = *it;
		//InterlockedDecrement((LPLONG)&curTex);

		int start_res, finish_res, execNum, res;
		start_res = 64;
		res = start_res;
		execNum = 0;

		plugin_log2.PrintValue("Before res alg, thread id:", std::this_thread::get_id());

		clock_t start, finish;
		start = clock();

		do
		{
			start_res = res;
			finish_res = res;
			tryResolution(texD, res);
			execNum++;
			finish_res = res;
			if (finish_res >= 1024) break;
		} while (finish_res != start_res /*|| finish_res <= 1024*/);


		finish = clock();

		float tt = (float)((finish - start) / CLOCKS_PER_SEC);

		plugin_log2.PrintValue("Resolution found, thread id:", std::this_thread::get_id());
		/*plugin_log2.OpenLogFile("C:/[Hydra]/pluginFiles/plugin_log2.txt");
		plugin_log2.PrintValue("Execution time: ", tt);
		plugin_log2.PrintValue("finish - start: ", finish - start);
		plugin_log2.PrintValue("Executed number: ", execNum);
		plugin_log2.PrintValue("procedural texture res: ", res);*/


		TSTR mapName1 = texD->GetName();
		std::wstring mapName = mapName1;
		std::wstring mapPath;
		mapPath = L"C:\\[Hydra]\\pluginFiles\\" + mapName + L".bmp";

		//plugin_log2.PrintValue("tex path: ", ws2s(mapPath));

		Bitmap *bmap;
		BitmapInfo bi;


		bi.SetType(BMM_TRUE_64);
		bi.SetWidth(res);
		bi.SetHeight(res);
		//bi.SetFlags(MAP_HAS_ALPHA);
		bi.SetCustomFlag(0);

		bi.SetPath(mapPath.c_str());

		bmap = TheManager->Create(&bi);

		TimeValue t = 0;
		UVGen* uvGen = texD->GetTheUVGen();
		float uOffset, vOffset, uTiling, vTiling, angle, angleUVW[3];
		StdUVGen* stdUVgen;
		plugin_log2.PrintValue("Before if(uvGen), thread id:", std::this_thread::get_id());
		if (uvGen)
		{
			stdUVgen = (StdUVGen*)uvGen;

			uOffset = stdUVgen->GetUOffs(t);
			vOffset = stdUVgen->GetVOffs(t);
			uTiling = stdUVgen->GetUScl(t);
			vTiling = stdUVgen->GetVScl(t);
			angle = stdUVgen->GetAng(t);
			angleUVW[0] = stdUVgen->GetUAng(t);
			angleUVW[1] = stdUVgen->GetVAng(t);
			angleUVW[2] = stdUVgen->GetWAng(t);

			stdUVgen->Reset();
			/*stdUVgen->SetUOffs(0.0f,t);
			stdUVgen->SetVOffs(0.0f,t);
			stdUVgen->SetUScl(1.0f, t);
			stdUVgen->SetVScl(1.0f,t);
			stdUVgen->SetAng(0.0f,t);

			stdUVgen->SetUAng(0.0f,t);
			stdUVgen->SetVAng(0.0f,t);
			stdUVgen->SetWAng(0.0f,t);
			*/
			GetCOREInterface()->RenderTexmap(texD, bmap);

			//texD->RenderBitmap(0, bmap);
			bmap->OpenOutput(&bi);
			bmap->Write(&bi);
			bmap->Close(&bi);


			stdUVgen->SetUOffs(uOffset, t);
			stdUVgen->SetVOffs(vOffset, t);
			stdUVgen->SetUScl(uTiling, t);
			stdUVgen->SetVScl(vTiling, t);
			stdUVgen->SetAng(angle, t);

			stdUVgen->SetUAng(angleUVW[0], t);
			stdUVgen->SetVAng(angleUVW[1], t);
			stdUVgen->SetWAng(angleUVW[2], t);

			//uvGen = (UVGen*)stdUVgen;
		}
		else
		{
			texD->RenderBitmap(0, bmap);
			bmap->OpenOutput(&bi);
			bmap->Write(&bi);
			bmap->Close(&bi);
		}
		plugin_log2.PrintValue("Loop end, thread id:", std::this_thread::get_id());
		bmap->DeleteThis();
	}
	plugin_log2.Print("Inshallah!");
}

void hydraRender_mk3::checkProcTexMD5(std::vector<MaterialObj> *materials)
{
	for (int i = 0; i < procTexsV.size()/*procTexToCheck*/; i++)
	{
		std::wstring name = procTexsV.at(i)->GetName();//procTexs[i]->GetName();
		std::wstring mapPath;
		mapPath = L"C:\\[Hydra]\\pluginFiles\\" + name + L".bmp";

		//plugin_log.PrintValue("Checking md5....",ws2s(mapPath));

		std::vector<MaterialObj>::iterator it = materials->begin();
		while(it != materials->end())
		{
			std::vector<TextureObj>::iterator tex =it->textures.begin();
			while(tex != it->textures.end())
			{
				if(tex->mapName == mapPath)
				{
          std::string texMD5 = "";

          std::ifstream fileTest(mapPath);
          if (fileTest.is_open())
          {
            fileTest.close();

            hashwrapper *h = new md5wrapper();
            h->test();
            texMD5 = h->getHashFromFile(ws2s(mapPath));
            delete h;
          }
					

					//plugin_log.PrintValue("Found...",ws2s(tex->mapName));
	
					std::map<std::string, std::wstring>::const_iterator md = procTexMD5s.find(texMD5);

					if(md!=procTexMD5s.end())
					{
						tex->mapName = md->second;
						tex->displacementMapPath = md->second; // for the case when guys put color map to bump slot
					}
					else
					{
						procTexMD5s[texMD5] = mapPath;
					}
				}
				tex++;
			}
			it++;
		}

	}
}

int hydraRender_mk3::createProcTextures()
{
	int q;
	if (/*procTexToCheck*/procTexsV.size() < MAX_THREADS)
		q = procTexsV.size();// procTexToCheck;
	else
		q = MAX_THREADS;
	
	if (!q)
		return 0;
	const int grainsize = procTexsV.size() / q;
	auto work_iter = std::begin(procTexsV);
	
	for(int i = 0; i < q; i++)
	{
		/*hThreadArray[i] = CreateThread( 
										NULL,                   // default security attributes
										0,                      // use default stack size  
										ProcTexResolution,       // thread function name
										procTexs,          // argument to thread function 
										0,                      // use default creation flags 
										&dwThreadIdArray[i]);   // returns the thread identifier
										*/
		threads.push_back(std::thread(ProcTexResolutionT, procTexsV, work_iter, work_iter + grainsize));
		work_iter += grainsize;
	}

	return q;
}


void hydraRender_mk3::MaxOtherMapToTextureObj(Texmap* tex, TextureObj* texture)
{
	TimeValue t = GetStaticFrame();
	
	TSTR mapName = tex->GetName();
  texture->mapName = mapName;
	std::wstring mapPath;
	mapPath = L"C:\\[Hydra]\\pluginFiles\\" + texture->mapName + L".bmp";
	texture->mapName = mapPath;
	texture->displacementMapPath = mapPath;
	texture->hasDisplacement     = true;

	UVGen* uvGen = tex->GetTheUVGen();
	Matrix3 uvTrans;
	if(uvGen)
		DumpUVGen((StdUVGen*)uvGen, texture);
	else
	{
		texture->uOffset = 0;
		texture->vOffset = 0;
		texture->uTiling = 1;
		texture->vTiling = 1;
		texture->angle = 0;

		texture->angleUVW[0] = 0;
		texture->angleUVW[1] = 0;
		texture->angleUVW[2] = 0;
	}

	//procTexs[procTexToCheck] = tex;
	//plugin_log.PrintValue("proc tex", ws2s(mapPath));
	procTexsV.push_back(tex);

	//procTexToCheck++;
	//curTex++;

}

void hydraRender_mk3::MaxNormalMapToTextureObj(Texmap* tex, TextureObj* texture)
{
  bool hasNormalmap = false;
  bool hasDisplacementMap = false;

  TextureObj texNormal;
  TextureObj texDisplacement;

  for(int i=0;i<tex->NumSubTexmaps();i++)
  {
    Texmap* subTex = tex->GetSubTexmap(i);

    if (subTex != NULL)
    {
      MSTR slotName  = tex->GetSubTexmapSlotName(i);
      const wchar_t* slotNameData = slotName.data();

      TextureObj* pResult = NULL; 

      if(std::wstring(slotNameData) == L"Normal")
      {
        pResult = &texNormal;
        pResult->nmFlipRed          = FindBool (L"flip red",        tex);
        pResult->nmFlipGreen        = FindBool (L"flip green",      tex);
        pResult->nmSwapRedAndGreen  = FindBool (L"swap red green",  tex);
        hasNormalmap = true;
      }
      else if (std::wstring(slotNameData) == L"Additional Bump")
      {
        pResult                     = &texDisplacement;
        hasDisplacementMap          = true; 
        pResult->displacementAmount = FindFloat(L"Bump Multiplier", tex);
      }

      if( subTex->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00) )
      {
        TSTR className;
        subTex->GetClassName(className);
        pResult->texName  = subTex->GetName();
        pResult->texClass = className;
        MaxBitMapDataToTextureObj(subTex, pResult);
      }
    }
  } 

  if(hasNormalmap)
    *texture = texNormal;
  else if(hasDisplacementMap)
    *texture = texDisplacement;

  texture->normalMapPath       = texNormal.mapName;
  texture->displacementMapPath = texDisplacement.mapName;

  texture->isBump             = true;
  texture->hasNormals         = hasNormalmap;
  texture->hasDisplacement    = hasDisplacementMap;

  texture->displacementAmount = texDisplacement.displacementAmount;
  texture->nmFlipRed          = texNormal.nmFlipRed;
  texture->nmFlipGreen        = texNormal.nmFlipGreen;
  texture->nmSwapRedAndGreen  = texNormal.nmSwapRedAndGreen;

  //TraceNodeCustomProperties(texture->mapName, tex, 1);
}

void hydraRender_mk3::MaxBitMapDataToTextureObj(Texmap* tex, TextureObj* texture)
{
  BitmapTex* pBitMap = (BitmapTex*)tex; // replace with dynamic cast ?
  if (pBitMap == NULL)
    return;

  TSTR mapName = pBitMap->GetMapName();
  texture->mapName             = mapName;
  texture->displacementMapPath = mapName; // for the case when guys put color map to bump slot
  texture->hasDisplacement     = true;

  // uv matrix
  //
  StdUVGen* uvGen = pBitMap->GetUVGen();
  if (uvGen) 
    DumpUVGen(uvGen, texture);

  // crop matrix
  //
  bool applyTexCrop = FindBool (L"Apply", pBitMap);
  if (applyTexCrop)
  {
    texture->cporuoffs  = FindFloat(L"Clip U Offset", pBitMap);
    texture->cporvoffs  = FindFloat(L"Clip V Offset", pBitMap);
    texture->cropuscale = FindFloat(L"Clip U Width", pBitMap);
    texture->cropvscale = FindFloat(L"Clip V Width", pBitMap);
  }

  //
  //
  TextureOutput* texout = pBitMap->GetTexout();
  texture->texInvert    = texout->GetInvert();

  switch (pBitMap->GetFilterType())
  {
  case FILTER_PYR:
    texture->texFilter = L"PYR";
    break;
  case FILTER_SAT:
    texture->texFilter = L"SAT";
    break;
  default:
    texture->texFilter = L"NONE";
    break;
  }

  //TraceNodeCustomProperties(texture->mapName, pBitMap);
}



void hydraRender_mk3::DumpUVGen(StdUVGen* uvGen, TextureObj* texture)
{
	TimeValue t = GetStaticFrame();
	
	int mapType = uvGen->GetCoordMapping(0);
	switch (mapType) 
	{
	case UVMAP_EXPLICIT:
		texture->mapType = L"EXPLICIT";
		break;
	case UVMAP_SPHERE_ENV: 
		texture->mapType = L"SPHERE_ENV";
		break;
	case UVMAP_CYL_ENV:  
		texture->mapType = L"CYL_ENV";
		break;
	case UVMAP_SHRINK_ENV: 
		texture->mapType = L"SHRINK_ENV"; 
		break;
	case UVMAP_SCREEN_ENV: 
		texture->mapType = L"SCREEN_ENV";
		break;
	}

  texture->uOffset = uvGen->GetUOffs(t);
  texture->vOffset = uvGen->GetVOffs(t);
  texture->uTiling = uvGen->GetUScl(t);
  texture->vTiling = uvGen->GetVScl(t);
  texture->angle   = uvGen->GetAng(t);
  texture->blur    = uvGen->GetBlur(t);

  texture->angleUVW[0] = uvGen->GetUAng(t);
  texture->angleUVW[1] = uvGen->GetVAng(t);
  texture->angleUVW[2] = uvGen->GetWAng(t);

  texture->blurOffset = uvGen->GetBlurOffs(t);
  texture->noiseAmt   = uvGen->GetNoiseAmt(t);
  texture->noiseSize  = uvGen->GetNoiseSize(t);
  texture->noiseLevel = uvGen->GetNoiseLev(t);
  texture->noisePhase = uvGen->GetNoisePhs(t);

  texture->texTilingFlags = uvGen->GetTextureTiling();

}

// get local texture path
//size_t found;
//found = tex->mapName.find_last_of(L"/\\");
//matFile<<"        <texture>"<<ws2s(tex->mapName.substr(found+1))<<"</texture>\n";

std::string  hydraRender_mk3::ExportTextureSamplerStr(StdUVGen* uvGen, std::string tag_name)
{
	TimeValue t = GetStaticFrame();

	std::stringstream ss;

	float uOffset;
	float vOffset;
	float uTiling;
	float vTiling;
	float angle;
  float angleUVW[3];
	int texTilingFlags;

  Matrix3 rotU(1), rotV(1), rotW(1);
  Matrix3 scale(1), trans(1);

  Matrix3 moveToCenter(1), moveToCenterInv(1);
  moveToCenter.SetTrans(Point3(0.5f, 0.5f, 0.0f));
  moveToCenterInv.SetTrans(Point3(-0.5f, -0.5f, 0.0f));

	uOffset = uvGen->GetUOffs(t);
  vOffset = uvGen->GetVOffs(t);
  uTiling = uvGen->GetUScl(t);
  vTiling = uvGen->GetVScl(t);
  angle   = uvGen->GetAng(t);

  angleUVW[0] = uvGen->GetUAng(t);
  angleUVW[1] = uvGen->GetVAng(t);
  angleUVW[2] = uvGen->GetWAng(t);

  texTilingFlags = uvGen->GetTextureTiling();


  rotU.RotateX(angleUVW[0]);
  rotV.RotateY(angleUVW[1]);
  rotW.RotateZ(angleUVW[2]);

  scale.SetScale(Point3(uTiling, vTiling, 1.0f));
  trans.SetTrans(Point3(-uOffset, -vOffset, 0.0f));

  scale = moveToCenterInv*scale*moveToCenter;

  Matrix3 texMatrix;
  texMatrix = trans*scale*rotU*rotV*rotW;


  float matrixData[16];
  MaxMatrix3ToFloat16(texMatrix, matrixData);

  ss << std::endl;
  ss <<"        <" + tag_name + "> " << std::endl;

  ss <<"          <matrix> " << std::endl;

  for(int x=0;x<4;x++)
  {
    ss <<"            ";
    for(int y=0;y<4;y++)
      ss << matrixData[y*4+x] << " ";
    ss << std::endl;
  }

  ss <<"          </matrix> " << std::endl;

  if(texTilingFlags & U_WRAP)
    ss <<"          <addressing_mode_u> wrap </addressing_mode_u> " << std::endl;
  else if(texTilingFlags & U_MIRROR)
    ss <<"          <addressing_mode_u> mirror </addressing_mode_u> " << std::endl;
  else
    ss <<"          <addressing_mode_u> clamp </addressing_mode_u> " << std::endl;

  if(texTilingFlags & V_WRAP)
    ss <<"          <addressing_mode_v> wrap </addressing_mode_v> " << std::endl;
  else if(texTilingFlags & V_MIRROR)
    ss <<"          <addressing_mode_v> mirror </addressing_mode_v> " << std::endl;
  else
    ss <<"          <addressing_mode_v> clamp </addressing_mode_v> " << std::endl;


  ss <<"        </" + tag_name + "> " << std::endl;
  ss << std::endl;

	return ss.str();
}


void hydraRender_mk3::ExportTextureSamplerXML(std::ofstream& matFile, const TextureObj* tex, std::string tag_name)
{
  Matrix3 rotU(1), rotV(1), rotW(1);
  Matrix3 scale(1), trans(1);
  
  // common tex matrix
  //
  Matrix3 moveToCenter(1), moveToCenterInv(1);
  moveToCenter.SetTrans(Point3(0.5f, 0.5f, 0.0f));
  moveToCenterInv.SetTrans(Point3(-0.5f, -0.5f, 0.0f));

  rotU.RotateX(tex->angleUVW[0]);
  rotV.RotateY(tex->angleUVW[1]);
  rotW.RotateZ(tex->angleUVW[2]);

  scale.SetScale(Point3(tex->uTiling, tex->vTiling, 1.0f));
  trans.SetTrans(Point3(-tex->uOffset, -tex->vOffset, 0.0f));

  Matrix3 cropMatrix(1);
  Matrix3 cropedToCenter(1), cropedToCenterInv(1);
  {
    Matrix3 scale2(1), trans2(1);

    float offsetX = tex->cporuoffs;
    float offsetY = (1.0f - tex->cporvoffs - tex->cropvscale*1.0f);

    float scaleX = tex->cropuscale;
    float scaleY = tex->cropvscale;

    scale2.SetScale(Point3(scaleX, scaleY, 1.0f));
    trans2.SetTrans(Point3(offsetX, offsetY, 0.0f));

    cropMatrix = (scale2*trans2);

    float cropCenterX = offsetX + 0.5f*scaleX;
    float cropCenterY = offsetY + 0.5f*scaleY;

    //
    //

    cropedToCenter.IdentityMatrix();
    cropedToCenterInv.IdentityMatrix();

    cropedToCenter.SetTrans(Point3(-cropCenterX + 0.5f, -cropCenterY + 0.5f, 0.0f));
    cropedToCenterInv.SetTrans(Point3(cropCenterX - 0.5f, cropCenterY - 0.5f, 0.0f));
  }


  Matrix3 texMatrix(1);
  Matrix3 scaleRotTransform(1);
  
  scaleRotTransform = moveToCenterInv*(rotU*rotV*rotW*scale)*moveToCenter;
  texMatrix         = cropMatrix*trans*( cropedToCenter*scaleRotTransform*cropedToCenterInv );

  //texMatrix = trans*(moveToCenterInv*scale*moveToCenter)*rotU*rotV*rotW;
  //texMatrix = cropMatrix*trans*(cropedToCenter*(rotU*rotV*rotW)*cropedToCenterInv);

  float matrixData[16];
  MaxMatrix3ToFloat16(texMatrix, matrixData);

  matFile<< std::endl;
  matFile<<"        <" + tag_name + "> " << std::endl;

  matFile<<"          <matrix> " << std::endl;

  for(int x=0;x<4;x++)
  {
    matFile<<"            ";
    for(int y=0;y<4;y++)
      matFile << matrixData[y*4+x] << " ";
    matFile << std::endl;
  }

  matFile<<"          </matrix> " << std::endl;

  if(tex->texTilingFlags & U_WRAP)
    matFile<<"          <addressing_mode_u> wrap </addressing_mode_u> " << std::endl;
  else if(tex->texTilingFlags & U_MIRROR)
    matFile<<"          <addressing_mode_u> mirror </addressing_mode_u> " << std::endl;
  else
    matFile<<"          <addressing_mode_u> clamp </addressing_mode_u> " << std::endl;

  if(tex->texTilingFlags & V_WRAP)
    matFile<<"          <addressing_mode_v> wrap </addressing_mode_v> " << std::endl;
  else if(tex->texTilingFlags & V_MIRROR)
    matFile<<"          <addressing_mode_v> mirror </addressing_mode_v> " << std::endl;
  else
    matFile<<"          <addressing_mode_v> clamp </addressing_mode_v> " << std::endl;


  matFile<<"        </" + tag_name + "> " << std::endl;
  matFile<< std::endl;
}

std::string GetCorrectTexPath(const wchar_t* a_name, IFileResolutionManager* pFRM)
{
  std::string texPath;

  if(pFRM!=NULL)
  {
    MaxSDK::Util::Path path(a_name);

    if(pFRM->GetFullFilePath(path, MaxSDK::AssetManagement::kBitmapAsset))
      texPath = wstring_to_utf8(path.GetCStr());
    else
      texPath = wstring_to_utf8(a_name);
  }
  else
    texPath = wstring_to_utf8(a_name);

  return texPath;
}


void hydraRender_mk3::ExportOneTextureXML(std::ofstream& matFile, int slotId, const MaterialObj* mat, IFileResolutionManager* pFRM, std::string tag_name)
{
  if(slotId >= 0 && slotId < mat->textures.size())
  {
    const TextureObj* tex = &mat->textures[slotId];
    std::string texPath = GetCorrectTexPath(tex->mapName.c_str(), pFRM);
    matFile<<"        <" + tag_name + "> " << texPath.c_str() << " </" + tag_name + ">\n"; 
		if(tag_name == "glossiness_texture")
			ExportTextureSamplerXML(matFile, tex, "glossiness_sampler");
		else if (tag_name == "opacity_texture")
			ExportTextureSamplerXML(matFile, tex, "opacity_sampler");
		else
			ExportTextureSamplerXML(matFile, tex);
  }
}

void evalComponentColor(std::vector<MaterialObj>::const_iterator mat, const float color[3], float mult, bool multOn, int slotId,
                        float* pRed, float* pGreen, float* pBlue)
{
  if (slotId >= 0 && slotId < mat->textures.size())
  {
    if (mat->isHydraNative)
    {
      if (multOn)
      {
        (*pRed)   = color[0] * mult;
        (*pGreen) = color[1] * mult;
        (*pBlue)  = color[2] * mult;
      }
      else
      {
        (*pRed)   = mult;
        (*pGreen) = mult;
        (*pBlue)  = mult;
      }
    }
    else
    {
      float amt = mat->textures[slotId].texAmount;
      (*pRed)   = amt;
      (*pGreen) = amt;
      (*pBlue)  = amt;
    }
  }
  else
  {
    if (mat->isHydraNative)
    {
      (*pRed)   = color[0] * mult;
      (*pGreen) = color[1] * mult;
      (*pBlue)  = color[2] * mult;
    }
    else
    {
      (*pRed)   = color[0];
      (*pGreen) = color[1];
      (*pBlue)  = color[2];
    }
  }

}


void hydraRender_mk3::ExportMaterialsXML(std::ofstream& matFile, const std::vector<MaterialObj> &materials)
{
  matFile << "<library_materials>\n";

  std::vector<MaterialObj>::const_iterator mat;
  //stdext::hash_map<std::string, int> processedNames;

  // spetial thing for material changes that influence BVH 
  //
  this->matGMD5 = "";
  std::string matPath = "C:\\[Hydra]\\pluginFiles\\mhash.dat";
  std::ofstream matHashData(matPath.c_str(), std::ios::binary | std::ios::trunc);


  IFileResolutionManager* pFRM = IFileResolutionManager::GetInstance();

  for(mat = materials.begin(); mat != materials.end(); ++mat)
  {
    std::string matName = wstring_to_utf8(mat->name);

    //if(processedNames.find(matName) != processedNames.end())
      //continue;

    //processedNames[matName] = 1;

    int maxId = int(mat - materials.begin());

    matFile << "  <material name=\""<< matName.c_str() << "\" maxid = \"" << maxId  <<  "\">" << std::endl;
    matFile << "  <hydra> " << std::endl << std::endl;

    // export emissive properties
    //

    std::wstring emissiveNames[4] = {L"Self-Illumination",  L"Emission map",  L"EmissionMap", L"Self-illum"};
    int slotId = mat->FindTextureSlot(emissiveNames, 4);


    float emissiveRed   = 0.0f;
    float emissiveGreen = 0.0f;
    float emissiveBlue  = 0.0f;

    evalComponentColor(mat, mat->emission_color, mat->emission_mult, mat->emission_mult_on, slotId, &emissiveRed, &emissiveGreen, &emissiveBlue);

    if (emissiveRed > 0.0f || emissiveGreen > 0.0f || emissiveBlue > 0.0f)
    {
      matFile << std::endl;
      matFile << "    <emission>\n";
      matFile << std::endl;

      matFile << "        <color> " << emissiveRed << " " << emissiveGreen << " " << emissiveBlue << " </color>\n";

			if(mat->isHydraNative || mat->isVrayMtl)
				matFile << "        <cast_GI> " << mat->emission_gi << " </cast_GI>\n";

      ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);

      matFile <<   "        <magnitude> " << 1.0f << " </magnitude>" << std::endl;   
      matFile << std::endl;
      
      matFile << "    </emission>\n"<<std::endl;
    }

    // export diffuse properties
    //
    std::wstring diffNames[3] = { L"Diffuse Color", L"Diffuse map", L"DiffuseMap" };
    slotId = mat->FindTextureSlot(diffNames, 3);

    float diffuseRed = 0.0f;
    float diffuseGreen = 0.0f;
    float diffuseBlue = 0.0f;

    evalComponentColor(mat, mat->diffuse_color, mat->diffuse_mult, mat->diffuse_mult_on, slotId, &diffuseRed, &diffuseGreen, &diffuseBlue);

    if (diffuseRed > 0.0f || diffuseGreen > 0.0f || diffuseBlue > 0.0f)
    {
      matFile << "      <diffuse>\n";
      matFile << std::endl;

      matFile << "        <color> " << diffuseRed << " " << diffuseGreen << " " << diffuseBlue << " </color>\n";

      matFile << "        <no_ic_records> " << mat->no_ic_records << " </no_ic_records>\n";

      ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);

      matFile << std::endl;
      matFile << "      </diffuse>\n" << std::endl;
    }

    // export specular properties
    //

    float specR = mat->specular_color[0]*mat->shine_strength;
    float specG = mat->specular_color[1]*mat->shine_strength;
    float specB = mat->specular_color[2]*mat->shine_strength;

    std::wstring specularNames[6] = {L"Specular Color",  L"Specular map", L"Reflection",  L"Reflective map", L"SpecularMap", L"Reflect map"};
    slotId = mat->FindTextureSlot(specularNames, 6);

    matFile << std::endl;
    matFile << "      <specular>\n";
    matFile << std::endl;

    if(mat->isHydraNative)
    {
      matFile << "        <brdf_type> ";
      switch(mat->specular_brdf)
      {
      case 0:
        matFile << "phong";
        break;
      case 1:
        matFile << "phong";
        break;
      case 2:
        matFile << "cook-torrance";
        break;
			case 3:
        matFile << "fresnel_dielectric";
        break;
			case 4:
        matFile << "fresnel_conductor";
        break;
      }
      matFile << " </brdf_type>\n";
      matFile << std::endl;
    }
    else
      matFile << "        <brfd_type> phong </brfd_type>\n";
    
		

    if(slotId >= 0 && slotId < mat->textures.size())
    {
			if(mat->isHydraNative)
			{
				if (mat->specular_mult_on)
					matFile << "        <color> " << mat->specular_color[0]*mat->specular_mult << " "<< mat->specular_color[1]*mat->specular_mult << " " << mat->specular_color[2]*mat->specular_mult << " </color>\n";
				else
					matFile << "        <color> " << mat->specular_mult << " "<< mat->specular_mult << " " << mat->specular_mult << " </color>\n";
			}
			/*else if(mat->isVrayMtl)
				matFile << "        <color> " << mat->specular_color[0]*mat->specular_mult << " "<< mat->specular_color[1]*mat->specular_mult << " " << mat->specular_color[2]*mat->specular_mult << " </color>\n";
			*/
			else
			{
				float amt = mat->textures[slotId].texAmount;
				matFile << "        <color>" << amt << " " << amt << " " << amt << " </color>\n";
			}
    }
    else if(mat->isHydraNative)
			matFile << "        <color> " << mat->specular_color[0]*mat->specular_mult << " "<< mat->specular_color[1]*mat->specular_mult << " " << mat->specular_color[2]*mat->specular_mult << " </color>\n";
    else if(mat->isVrayMtl)
			matFile << "        <color> " << mat->specular_color[0] << " "<< mat->specular_color[1] << " " << mat->specular_color[2] << " </color>\n";
		else
      matFile<< "        <color> " << specR <<" "<< specG <<" "<< specB <<" </color>\n";
    
    if(mat->isHydraNative)
		{
      matFile << "        <roughness> " << mat->specular_roughness << " </roughness>" << std::endl;
			
			if(!mat->specular_gloss_or_cos) //need to get cos_power from glossiness
				matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(mat->specular_glossiness) << " </cos_power>" << std::endl;
			else
				matFile << "        <cos_power> " << mat->specular_cospower << " </cos_power>" << std::endl;

			matFile << "        <fresnel_IOR> " << mat->specular_ior << " </fresnel_IOR>" << std::endl;
			matFile << "        <fresnel> " << mat->specular_fresnel_on << " </fresnel>" << std::endl;
    }
		else if(mat->isVrayMtl)
		{
			if (slotId >= 0 && slotId < mat->textures.size() || mat->reflect_gloss_tex)
				matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(1.0) << " </cos_power>" << std::endl;
			else
				matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(mat->specular_glossiness) << " </cos_power>" << std::endl;

			matFile << "        <fresnel_IOR> " << mat->specular_ior << " </fresnel_IOR>" << std::endl;
			matFile << "        <fresnel> " << mat->specular_fresnel_on << " </fresnel>" << std::endl;
		}
    else
    {
      float specCosPower = GetCosPowerFromMaxShiness(mat->shininess);
      if(specCosPower > 4096)
        specCosPower = 4096;
      matFile << "        <cos_power> " << specCosPower  << " </cos_power>\n";
    }
    
    ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);
		matFile << std::endl;

		std::wstring specularGlossNames[] = {L"SpecularGlossinessMap", L"Hilight gloss"};
		
    slotId = mat->FindTextureSlot(specularGlossNames, 2);
		ExportOneTextureXML(matFile, slotId, &(*mat), pFRM, "glossiness_texture");
    matFile << std::endl;

    matFile << "      </specular>\n"<<std::endl;

    //
    //
    bool isTransparent = (mat->transparency > 0.001f);

    matFile << std::endl;
    matFile << "      <reflectivity>\n";
    matFile << std::endl;

    if(mat->isHydraNative)
    {
      matFile << "        <brdf_type> "; 
      switch(mat->reflect_brdf)
      {
      case 0:
        matFile << "phong";
        break;
      case 1:
        matFile << "phong";
        break;
      case 2:
        matFile << "cook-torrance";
        break;
			case 3:
        matFile << "fresnel_dielectric";
        break;
			case 4:
        matFile << "fresnel_conductor";
        break;
      }
      matFile << " </brdf_type>\n";
    }
    else
    {
      if(isTransparent)
        matFile <<"        <brfd_type> fresnel_dielectric </brfd_type> \n";
      else
        matFile <<"        <brfd_type> phong </brfd_type>\n";
    }

		std::wstring reflNames[9] = {L"Reflectivity Color",  L"Reflectivity map", L"ReflectivityMap", L"Specular Color",  L"Specular map", L"Reflection",  L"Reflective map", L"SpecularMap", L"Reflect map"};
    slotId = mat->FindTextureSlot(reflNames, 9);

    if(slotId >= 0 && slotId < mat->textures.size())
    {
      if(mat->isHydraNative)
			{
				if (mat->reflect_mult_on)
					matFile << "        <color> " << mat->reflect_color[0]*mat->reflect_mult << " "<< mat->reflect_color[1]*mat->reflect_mult << " " << mat->reflect_color[2]*mat->reflect_mult << " </color>\n";
				else
					matFile << "        <color> " << mat->reflect_mult << " "<< mat->reflect_mult << " " << mat->reflect_mult << " </color>\n";
			}
			/*else if(mat->isVrayMtl)
				matFile << "        <color> " << mat->reflect_color[0]*mat->reflect_mult << " "<< mat->reflect_color[1]*mat->reflect_mult << " " << mat->reflect_color[2]*mat->reflect_mult << " </color>\n";
				*/
			else
			{
				float amt = mat->textures[slotId].texAmount;
				matFile << "        <color>" << amt << " " << amt << " " << amt << " </color>\n";
			}
    }
		else if(mat->isHydraNative)
			matFile << "        <color> " << mat->reflect_color[0]*mat->reflect_mult << " "<< mat->reflect_color[1]*mat->reflect_mult << " " << mat->reflect_color[2]*mat->reflect_mult << " </color>\n";
		else if(mat->isVrayMtl)
			matFile << "        <color> " << mat->reflect_color[0] << " "<< mat->reflect_color[1] << " " << mat->reflect_color[2] << " </color>\n";
    else if(isTransparent)
      matFile<< "        <color> 1 1 1 </color>\n";
    else
      matFile<< "        <color> " << specR <<" "<< specG <<" "<< specB <<" </color>\n";

    ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);
		
    if(mat->isHydraNative)
		{
			if(!mat->reflect_gloss_or_cos) //need to get cos_power from glossiness
				matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(mat->reflect_glossiness) << " </cos_power>" << std::endl;
			else
				matFile << "        <cos_power> " << mat->reflect_cospower << " </cos_power>" << std::endl;

			matFile << "        <roughness> " << mat->reflect_roughness << " </roughness>" << std::endl;   
			matFile << "        <fresnel_IOR> " << mat->reflect_ior << " </fresnel_IOR>" << std::endl;
			matFile << "        <fresnel> " << mat->reflect_fresnel_on << " </fresnel>" << std::endl;
		}
		else if(mat->isVrayMtl)
		{
			if (slotId >= 0 && slotId < mat->textures.size() || mat->reflect_gloss_tex)
				matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(1.0) << " </cos_power>" << std::endl;
			else
				matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(mat->reflect_glossiness) << " </cos_power>" << std::endl;
			matFile << "        <fresnel_IOR> " << mat->reflect_ior << " </fresnel_IOR>" << std::endl;
			matFile << "        <fresnel> " << mat->reflect_fresnel_on << " </fresnel>" << std::endl;
		}
    else
    {
      matFile << "        <fresnel_IOR>"  << mat->IOR << "</fresnel_IOR>\n";
      matFile << "        <cos_power>" << GetCosPowerFromMaxShiness(mat->shininess) << "</cos_power>\n";
    }

		std::wstring reflectGlossNames[] = {L"ReflectGlossinessMap", L"Refl. gloss."};
    slotId = mat->FindTextureSlot(reflectGlossNames, 2);
		ExportOneTextureXML(matFile, slotId, &(*mat), pFRM, "glossiness_texture");
    matFile << std::endl;
    
    matFile << "      </reflectivity>\n" << std::endl;

    // export transparency properties
    //
    float trasnpR = mat->filter_color[0]*mat->transparency;
    float trasnpG = mat->filter_color[1]*mat->transparency;
    float trasnpB = mat->filter_color[2]*mat->transparency;

    std::wstring anyTransparency[6] = {L"Filter Color",  L"Transparency map", L"Refraction", L"Opacity",  L"TransparencyMap", L"Refract map"};
    slotId = mat->FindTextureSlot(anyTransparency, 6);

		if(isTransparent || (slotId >= 0 && slotId < mat->textures.size()) || mat->isHydraNative || mat->isVrayMtl)
    {
      matFile << std::endl;
      matFile << "      <transparency>\n";
      matFile << std::endl;

      std::wstring opacityNames[1] = {L"Opacity"};
      slotId = mat->FindTextureSlot(opacityNames, 1);

      if(slotId >= 0 && slotId < mat->textures.size())
      {
         matFile<< "        <color> 0.0 0.0 0.0 </color>\n";
         matFile<< "        <thin_surface> 1 </thin_surface>\n";
         ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);
      }
      else
      {
        std::wstring transpNames[5] = {L"Filter Color",  L"Transparency map", L"Refraction",  L"TransparencyMap", L"Refract map"};
        slotId = mat->FindTextureSlot(transpNames, 5);

        if(slotId >= 0 && slotId < mat->textures.size())
        {
          if(mat->isHydraNative)
					{
						if(mat->transparency_mult_on) 
							matFile << "        <color> " << mat->transparency_color[0]*mat->transparency_mult << " "<< mat->transparency_color[1]*mat->transparency_mult << " " << mat->transparency_color[2]*mat->transparency_mult << " </color>\n";
						else
							matFile << "        <color> " << mat->transparency_mult << " "<< mat->transparency_mult << " " << mat->transparency_mult << " </color>\n";
					}
					/*else if(mat->isVrayMtl)
						matFile << "        <color> " << mat->transparency_color[0]*mat->transparency_mult << " "<< mat->transparency_color[1]*mat->transparency_mult << " " << mat->transparency_color[2]*mat->transparency_mult << " </color>\n";
						*/
					else
					{
						float amt = mat->textures[slotId].texAmount;
						matFile << "        <color>" << amt << " " << amt << " " << amt << " </color>\n";
					}
        }
				else if(mat->isHydraNative)
					matFile << "        <color> " << mat->transparency_color[0]*mat->transparency_mult << " "<< mat->transparency_color[1]*mat->transparency_mult << " " << mat->transparency_color[2]*mat->transparency_mult << " </color>\n";
				else if(mat->isVrayMtl)
					matFile << "        <color> " << mat->transparency_color[0] << " "<< mat->transparency_color[1] << " " << mat->transparency_color[2] << " </color>\n";
				else
          matFile<< "        <color> " << trasnpR <<" "<< trasnpG <<" "<< trasnpB <<" </color>\n";

        ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);

        if(mat->isHydraNative)
        {
					if(!mat->transparency_gloss_or_cos) //need to get cos_power from glossiness
						matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(mat->transparency_glossiness) << " </cos_power>" << std::endl;
					else
						matFile << "        <cos_power> " << mat->transparency_cospower << " </cos_power>" << std::endl;

          matFile << "        <thin_surface> " << (int)mat->transparency_thin_on << " </thin_surface>" << std::endl;
          matFile << "        <fog_color> " << mat->fog_color[0] << " "<< mat->fog_color[1] << " " << mat->fog_color[2] << " </fog_color>" << std::endl;
          matFile << "        <exit_color> " << mat->exit_color[0] << " "<< mat->exit_color[1] << " " << mat->exit_color[2] << " </exit_color>" << std::endl;
          matFile << "        <IOR> " << mat->IOR << " </IOR>" << std::endl;
          matFile << "        <fog_multiplyer> " << mat->fog_multiplier << " </fog_multiplyer>" << std::endl;
					matFile << "        <skip_shadow> " << !mat->affect_shadows_on << " </skip_shadow>" << std::endl;
					matFile << "        <shadow_matte> " << mat->shadow_matte << " </shadow_matte>" << std::endl;

          matHashData << mat->transparency_thin_on; // this cause BVH to rebuild because of flags put to geom in BVH
          matHashData << mat->affect_shadows_on;    // this cause BVH to rebuild because of flags put to geom in BVH
        }
				else if(mat->isVrayMtl)
				{
					if (slotId >= 0 && slotId < mat->textures.size() || mat->refr_gloss_tex)
						matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(1.0) << " </cos_power>" << std::endl;
					else
						matFile << "        <cos_power> " << GetCosPowerFromMaxShiness(mat->transparency_glossiness) << " </cos_power>" << std::endl;

					matFile << "        <fog_color> " << mat->fog_color[0] << " "<< mat->fog_color[1] << " " << mat->fog_color[2] << " </fog_color>" << std::endl;
          matFile << "        <exit_color> " << mat->exit_color[0] << " "<< mat->exit_color[1] << " " << mat->exit_color[2] << " </exit_color>" << std::endl;
          matFile << "        <IOR> " << mat->IOR << " </IOR>" << std::endl;
          matFile << "        <fog_multiplyer> " << mat->fog_multiplier << " </fog_multiplyer>" << std::endl;
					matFile << "        <skip_shadow> " << !mat->affect_shadows_on << " </skip_shadow>" << std::endl;

					matHashData << mat->affect_shadows_on;    // this cause BVH to rebuild because of flags put to geom in BVH
				}
        else
        {
          matFile << "        <IOR> " << mat->IOR<< " </IOR>\n";
          matFile << "        <thin_surface> 0 </thin_surface>\n";
          matFile << "        <cos_power> 1e+006 </cos_power>\n";
          matFile << "        <fog_color> " << trasnpR << " " << trasnpG << " " << trasnpB << " </fog_color>\n";
          matFile << "        <fog_multiplyer>" << 10.0f*mat->opacity_falloff << "</fog_multiplyer> \n";
          matFile << "        <exit_color> 0.0 0.0 0.0 </exit_color> \n";
        }
      }
     
			std::wstring transpGlossNames[] = {L"TranspGlossinessMap", L"Refr. gloss."};
			slotId = mat->FindTextureSlot(transpGlossNames, 2);
			ExportOneTextureXML(matFile, slotId, &(*mat), pFRM, "glossiness_texture");
			matFile << std::endl;

			std::wstring hydraOpacityNames[] = { L"OpacityMap"};
			slotId = mat->FindTextureSlot(hydraOpacityNames, 1);
      matHashData << slotId; // rebuild bvh if opacity map changed
			ExportOneTextureXML(matFile, slotId, &(*mat), pFRM, "opacity_texture");
			matFile << std::endl;

      matFile << std::endl;
      matFile << "      </transparency>\n"<<std::endl;
    }

		//translucency
		if (mat->isHydraNative) // � ��� ����� VRay?
		{
			matFile << std::endl;
			matFile << "      <translucency>\n";
			matFile << std::endl;

			std::wstring translucencyNames[1] = { L"TranslucencyMap" };
			slotId = mat->FindTextureSlot(translucencyNames, 1);

			if (slotId >= 0 && slotId < mat->textures.size())
			{
				if (mat->translucency_mult_on)
					matFile << "        <color> " << mat->translucency_color[0] * mat->translucency_mult << " " << mat->translucency_color[1] * mat->translucency_mult << " " << mat->translucency_color[2] * mat->translucency_mult << " </color>\n";
				else
					matFile << "        <color> " << mat->translucency_mult << " " << mat->translucency_mult << " " << mat->translucency_mult << " </color>\n";
			}
			else
				matFile << "        <color> " << mat->translucency_color[0] * mat->translucency_mult << " " << mat->translucency_color[1] * mat->translucency_mult << " " << mat->translucency_color[2] * mat->translucency_mult << " </color>\n";

			matFile << std::endl;

			ExportOneTextureXML(matFile, slotId, &(*mat), pFRM);

			matFile << "      </translucency>\n" << std::endl;
		}

    // export displacement
    std::wstring transpNames[6] = {L"Bump",  L"Displacement",  L"NormalMap",  L"HeightMap", L"Bump map", L"Displacement"};
    slotId = mat->FindTextureSlot(transpNames, 6);
		if(slotId >= 0 && slotId < mat->textures.size())
    {
      float amtHeight = mat->textures[slotId].displacementAmount;
      float amtBump   = mat->textures[slotId].texAmount;

      matFile << std::endl;
      matFile << "      <displacement>\n";
      matFile << std::endl;

      const TextureObj* tex = &mat->textures[slotId];
      std::string texPath   = GetCorrectTexPath(tex->mapName.c_str(), pFRM);

			if(mat->isHydraNative)
      {
				amtHeight = mat->displacement_height; //*amtHeight
        amtHeight = toMeters(amtHeight);
				if(tex->texClass != L"Normal Bump")
					matFile << "        <bump_amount> " << mat->bump_amount <<  " </bump_amount> " << std::endl;
        amtBump = 0.0f;

				matFile << "        <bump_radius> " << mat->bump_radius <<  " </bump_radius> " << std::endl;
				matFile << "        <bump_sigma> " << mat->bump_sigma <<  " </bump_sigma> " << std::endl;
      }
      else
        matFile << "        <bump_amount> " << amtBump <<  " </bump_amount> " << std::endl;

      if(!tex->hasDisplacement || !mat->displacement_on)
        amtHeight = 0.0f;

      matFile << "        <height> " << amtHeight <<  " </height> " << std::endl;

      if(tex->hasNormals)
        matFile<<"        <normals_texture> " << GetCorrectTexPath(tex->normalMapPath.c_str(), pFRM) << " </normals_texture>\n";
      
      if(tex->hasDisplacement)
        matFile<<"        <height_texture> " << GetCorrectTexPath(tex->displacementMapPath.c_str(), pFRM) << " </height_texture>\n";

      if(tex->nmFlipRed)
        matFile<<"        <invert_normalX> 1 </invert_normalX>\n";

      if(!tex->nmFlipGreen)
        matFile<<"        <invert_normalY> 1 </invert_normalY>\n";

      if(tex->nmSwapRedAndGreen)
        matFile<<"        <swap_normalXY>  1 </swap_normalXY>\n";

			if(mat->isHydraNative && mat->displacement_invert_height_on)
				matFile<<"        <invert_height> 1 </invert_height>\n";

      ExportTextureSamplerXML(matFile, tex);

      matFile << std::endl;
      matFile << "      </displacement>\n" << std::endl;
    }

    matFile << "  </hydra>" << std::endl;
    matFile << "  </material>"<< std::endl<<std::endl;
  }

  matFile   << "</library_materials>\n";


  matHashData.close();
  hashwrapper *h = new md5wrapper();
	this->matGMD5 = h->getHashFromFile(matPath);
	delete h; h = NULL;

}


BOOL MtlKeeper::AddMtl(Mtl* mtl)
{
  if (!mtl) {
    return FALSE;
  }

  int numMtls = mtlTab.Count();
  for (int i=0; i<numMtls; i++) {
    if (mtlTab[i] == mtl) {
      return FALSE;
    }
  }
  mtlTab.Append(1, &mtl, 25);

  return TRUE;
}

int MtlKeeper::GetMtlID(Mtl* mtl)
{
  int numMtls = mtlTab.Count();
  for (int i=0; i<numMtls; i++) {
    if (mtlTab[i] == mtl) {
      return i;
    }
  }
  return -1;
}

int MtlKeeper::Count() { return mtlTab.Count(); }
Mtl* MtlKeeper::GetMtl(int id) { return mtlTab[id]; }
void MtlKeeper::Clear() { mtlTab.ZeroCount(); }
