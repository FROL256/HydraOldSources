#include "hydraRender mk3.h"

#include <MeshNormalSpec.h>

#include <hash_map>
#include <map>


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void VNorm::AddNormal(Point3 n, DWORD s, std::vector<VNorm>& a_pool)
{
  if (!(s&smooth) && init) 
  {
    if (nextOffInPool >= 0) 
      a_pool[nextOffInPool].AddNormal(n,s,a_pool);
    else
    {
      a_pool.push_back(VNorm(n,s));
      nextOffInPool = a_pool.size()-1;
    }
  }
  else 
  {
    if(init)
    {
      if(DotProd(avgNorm, n) > 0.25f) // angle less that 75 degree
      {
        avgNorm += n;
        smooth |= s;
      }
    }
    else
    {
      avgNorm = n;
      smooth |= s;
    }

    init = true;
  }
}

void VNorm::Normalize(std::vector<VNorm>& a_pool)
{
  if (nextOffInPool >= 0) 
    a_pool[nextOffInPool].Normalize(a_pool);

  float lenSquared = avgNorm.LengthSquared();
  if(lenSquared < 1e-12f)
  {
    invalid = true;
    avgNorm = Point3(0,0,-1);
    return;
    //std::ofstream invalidNormals("C:\\[Hydra]\\logs\\invalidNormals.txt", std::ios::app);
    //invalidNormals << "Invalid zero normal detected! --> " << avgNorm.x << " " << avgNorm.y << " " << avgNorm.z << ", init = " << init << "\n";
    //invalidNormals.flush();
    //invalidNormals.close();
  }

  avgNorm = ::Normalize(avgNorm);
}

Point3 VNorm::GetNormal(DWORD a_smGroup, std::vector<VNorm>& a_pool, bool& a_invalid)
{
  if( (smooth & a_smGroup) || (nextOffInPool < 0) )
  {
    a_invalid = invalid;
    return avgNorm;
  }
  else
    return a_pool[nextOffInPool].GetNormal(a_smGroup, a_pool, a_invalid);
}

float angleOfEdges(Point3 edgeA, Point3 edgeB)
{
  float dp = DotProd(edgeA,edgeB);
  
  if (dp>1) 
    dp=1.0f; // shouldn't happen, but might
  if (dp<-1) 
    dp=-1.0f; // shouldn't happen, but might
 
  return abs(acos(dp));
}

void hydraRender_mk3::CalcMaxNormalsAsInExample(Mesh* mesh, GeometryObj* geom, Matrix3 tm) // this does not work ...
{
  int vx = 0;
  int vy = 1;
  int vz = 2;

  /*BOOL negScale = TMNegParity(tm);
  if (negScale) 
  {
    vx = 2;
    vy = 1;
    vz = 0;
  }
  else 
  {
    vx = 0;
    vy = 1;
    vz = 2;
  }*/

  Face *face; 
  Point3 *verts;
  Point3 v0, v1, v2, edgeA, edgeB;

  Point3 fNormal(0,0,0);
  Point3 zero(0,0,0);
  
  Tab<Point3> fnorms;
  
  face  = mesh->faces; 
  verts = mesh->verts;

  geom->vnorms.resize(mesh->getNumVerts());
  fnorms.SetCount(mesh->getNumFaces());

  for (int i = 0; i < mesh->getNumVerts(); i++) 
  {
    geom->vnorms[i].avgNorm = zero;
    geom->vnorms[i].smooth  = 0;
    geom->vnorms[i].init    = false;
    geom->vnorms[i].nextOffInPool = -1; 
  }

  geom->vnormsMemoryPool.reserve(mesh->getNumFaces()*10); 
  geom->vnormsMemoryPool.resize(0);

  geom->vNormsKeys.resize(mesh->getNumFaces()*3);

  for (int i = 0; i < mesh->getNumFaces(); i++, face++) 
  {
    // Calculate the surface normal
    //
    v0 = tm*verts[face->v[vx]];
    v1 = tm*verts[face->v[vy]];
    v2 = tm*verts[face->v[vz]];

    geom->vNormsKeys[i*3+0] = face->v[vx];
    geom->vNormsKeys[i*3+1] = face->v[vy];
    geom->vNormsKeys[i*3+2] = face->v[vz];

    edgeA   = ::Normalize(v1-v0);
    edgeB   = ::Normalize(v2-v1);

    //fNormal = edgeA^edgeB;
    //float angle = 1.0f;

    fNormal = ::Normalize(edgeA^edgeB);
    float angle = angleOfEdges(edgeA,edgeB);
    if(angle < 0.001f)
      angle = 0.001f;

    for (int j=0; j<3; j++) 
      geom->vnorms[face->v[j]].AddNormal(fNormal*angle, face->smGroup, geom->vnormsMemoryPool);

    fnorms[i] = fNormal;
  }

  for (int i=0; i < mesh->getNumVerts(); i++)
    geom->vnorms[i].Normalize(geom->vnormsMemoryPool);

}

void hydraRender_mk3::CalcMaxNormalsAsInOpenColladaPlugin(Mesh* mesh, GeometryObj* geom, Matrix3 tm)
{
  if(mesh == NULL)
    return;

  int vx = 0;
  int vy = 1;
  int vz = 2;

  geom->normsSpecified.resize(0);
  geom->normsSpecIndices.resize(0);

  MeshNormalSpec* normalSpec = mesh->GetSpecifiedNormals();

  if(normalSpec == NULL)
    return;

  if(normalSpec->GetNumNormals() == 0)
    return;

  /////////////////////////////////////////////////// --> original OpenCollada code
  /*if(normalSpec == NULL)
  {
    mesh->SpecifyNormals();
    normalSpec = mesh->GetSpecifiedNormals();
  }

  if( normalSpec->GetNumNormals() == 0 )
	{
		normalSpec->SetParent( mesh );
		normalSpec->CheckNormals();
	}*/

	if(normalSpec == NULL)
	 	return;


  ////////////////////////////////////////////////////////////////////////////////////////////////

  bool isSetMESH_NORMAL_NORMALS_BUILT    = normalSpec->GetFlag(MESH_NORMAL_NORMALS_BUILT);
	bool isSetMESH_NORMAL_NORMALS_COMPUTED = normalSpec->GetFlag(MESH_NORMAL_NORMALS_COMPUTED);
	bool isSetMESH_NORMAL_MODIFIER_SUPPORT = normalSpec->GetFlag(MESH_NORMAL_MODIFIER_SUPPORT);

  if( !isSetMESH_NORMAL_NORMALS_BUILT || !isSetMESH_NORMAL_NORMALS_COMPUTED )
    return;

  /////////////////////////////////////////////////// --> original OpenCollada code
  /*
	if( !isSetMESH_NORMAL_NORMALS_BUILT || !isSetMESH_NORMAL_NORMALS_COMPUTED )
	{
		normalSpec->SetParent( mesh );
		normalSpec->CheckNormals();
	}

	if( normalSpec->GetNumNormals() == 0 )
	{
		normalSpec->SetParent( mesh );
		normalSpec->CheckNormals();
	}*/

	int normalCount = normalSpec->GetNumNormals();

  if(normalCount == 0)
	 	return;

  geom->normsSpecified.resize(normalCount*3);
  
  Matrix3 tmRot = tm;

  tmRot.SetTranslate(Point3(0,0,0));

  Point3 normal;
  for( int i = 0; i < normalCount; ++i )
  {
  	normal = tmRot*normalSpec->Normal(i);
    normal = ::Normalize(normal);

    geom->normsSpecified[i*3+0] = normal.x;
    geom->normsSpecified[i*3+1] = normal.y;
    geom->normsSpecified[i*3+2] = normal.z;
  }


  geom->normsSpecIndices.resize(mesh->getNumFaces()*3);

  for(int faceIndex=0; faceIndex < mesh->getNumFaces(); faceIndex++)
  {
    //for(int vertexIndex = 0; vertexIndex < 3; vertexIndex++ )
    //{
    //  int normalIndex = normalSpec->GetNormalIndex(faceIndex, vertexIndex);
    //  geom->normsSpecIndices[faceIndex*3 + vertexIndex] = normalIndex;
    //}

    int normalIndex1 = normalSpec->GetNormalIndex(faceIndex, 0);
    int normalIndex2 = normalSpec->GetNormalIndex(faceIndex, 1);
    int normalIndex3 = normalSpec->GetNormalIndex(faceIndex, 2);

    geom->normsSpecIndices[faceIndex*3 + 0] = normalIndex1;
    geom->normsSpecIndices[faceIndex*3 + 1] = normalIndex2;
    geom->normsSpecIndices[faceIndex*3 + 2] = normalIndex3;
  }

}


