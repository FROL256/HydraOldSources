#include "3dsmaxsdk_preinclude.h"
#include "resource.h"
#include "hydraRender mk3.h"

#include "3dsmaxport.h"

extern HINSTANCE hInstance;

static INT_PTR CALLBACK HydraRenderParamDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK PathTracingDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK SPPMCDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK SPPMDDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK IrrCacheDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK ToneMapDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK MultiLayerDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
static INT_PTR CALLBACK EnvironmentDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);


HydraRenderParamDlg::HydraRenderParamDlg(hydraRender_mk3 *r, IRendParams *i, BOOL prog)
{
  rend       = r;
  ir         = i;
  this->prog = prog;

	for(int i = 0; i < 8; i++)
		rollupIndices[i] = -1;

	hMain = nullptr;
	hPathTracing = nullptr;
	hSPPMC = nullptr;
	hSPPMD = nullptr;
	hIrrCache = nullptr;
	hToneMap = nullptr;
	hMulti = nullptr;
	hEnv = nullptr;

  if(!prog)
	{
		rollupIndices[MAIN] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_HYDRADIALOG), HydraRenderParamDlgProc, L"Hydra Renderer", (LPARAM)this);
		hMain = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[MAIN]);
		rollupIndices[PATH] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_PATHTRACING), PathTracingDlgProc, L"Path tracing", (LPARAM)this);
		hPathTracing = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[PATH]);
		rollupIndices[SPPMC] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_SPPM_CAUSTIC), SPPMCDlgProc, L"SPPM (Caustics)", (LPARAM)this, APPENDROLL_CLOSED);
		hSPPMC = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[SPPMC]);
		rollupIndices[SPPMD] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_SPPM_DIFF), SPPMDDlgProc, L"SPPM (Diffuse)", (LPARAM)this, APPENDROLL_CLOSED);
		hSPPMD = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[SPPMD]);
		rollupIndices[IRRCACHE] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_IRRCACHE), IrrCacheDlgProc, L"Irradiance Cache", (LPARAM)this, APPENDROLL_CLOSED);
		hIrrCache = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[IRRCACHE]);
		rollupIndices[MULTI] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_MULTILAYER), MultiLayerDlgProc, L"Multi-Layer", (LPARAM)this, APPENDROLL_CLOSED);
		hMulti = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[MULTI]);
		rollupIndices[TONEMAP] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_TONEMAP), ToneMapDlgProc, L"Tone map", (LPARAM)this, APPENDROLL_CLOSED);
		hToneMap = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[TONEMAP]);
		rollupIndices[ENV] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_ENVIRONMENT), EnvironmentDlgProc, L"Environment", (LPARAM)this, APPENDROLL_CLOSED);
		hEnv = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[ENV]);
		

		/*
		AddPage(hMain, IDD_HYDRADIALOG);
		AddPage(hPathTracing, IDD_PATHTRACING);
		AddPage(hSPPMC, IDD_SPPM_CAUSTIC);
		AddPage(hSPPMD, IDD_SPPM_DIFF);
		AddPage(hIrrCache, IDD_IRRCACHE);
		AddPage(hMulti, IDD_MULTILAYER);
		AddPage(hToneMap, IDD_TONEMAP);
		AddPage(hEnv, IDD_ENVIRONMENT);*/
	}

}

HydraRenderParamDlg::~HydraRenderParamDlg()
{
 /* if(hMain) ir->DeleteTabRollupPage(kTabClassID, hMain);
	if(hPathTracing) ir->DeleteTabRollupPage(kTabClassID, hPathTracing);
	if(hSPPMC) ir->DeleteTabRollupPage(kTabClassID, hSPPMC);
	if(hSPPMD) ir->DeleteTabRollupPage(kTabClassID, hSPPMD);
	if(hIrrCache) ir->DeleteTabRollupPage(kTabClassID, hIrrCache);
	if(hMulti) ir->DeleteTabRollupPage(kTabClassID, hMulti);
	if(hToneMap) ir->DeleteTabRollupPage(kTabClassID, hToneMap);*/

	for(int i = 0; i < 8; i++)
	{
		if(rollupIndices[i] != -1)
			ir->GetTabIRollup(kTabClassID)->DeleteRollup(rollupIndices[i], 1);
	}
	hMain = NULL;
	hPathTracing = NULL;
	hSPPMC = NULL;
	hSPPMD = NULL;
	hIrrCache = NULL;
	hMulti = NULL;
	hToneMap = NULL;
	hEnv = NULL;

}


void HydraRenderParamDlg::InitProgDialog(HWND hWnd)
{
	hMain = NULL;
	hPathTracing = NULL;
	hSPPMC = NULL;
	hSPPMD = NULL;
	hIrrCache = NULL;
	hMulti = NULL;
  hToneMap = NULL;
	hEnv = NULL;
}


void HydraRenderParamDlg::InitMainHydraDialog(HWND hWnd)
{
	//PRIMARY BOUNCE
	SendDlgItemMessage(hWnd, IDC_PRIMARY, CB_ADDSTRING, 0, (LPARAM)(L"Path Tracing"));
  SendDlgItemMessage(hWnd, IDC_PRIMARY, CB_ADDSTRING, 0, (LPARAM)(L"SPPM"));

  //SECONDARY BOUNCE
	SendDlgItemMessage(hWnd, IDC_SECONDARY, CB_ADDSTRING, 0, (LPARAM)(L"Path Tracing"));
  SendDlgItemMessage(hWnd, IDC_SECONDARY, CB_ADDSTRING, 0, (LPARAM)(L"SPPM"));
  SendDlgItemMessage(hWnd, IDC_SECONDARY, CB_ADDSTRING, 0, (LPARAM)(L"Irradiance Cache"));

	//TERTIARY BOUNCE
	SendDlgItemMessage(hWnd, IDC_TERTIARY, CB_ADDSTRING, 0, (LPARAM)(L"Path Tracing"));
  SendDlgItemMessage(hWnd, IDC_TERTIARY, CB_ADDSTRING, 0, (LPARAM)(L"SPPM"));
  SendDlgItemMessage(hWnd, IDC_TERTIARY, CB_ADDSTRING, 0, (LPARAM)(L"Irradiance Cache"));

	/*SendDlgItemMessage(hWnd, IDC_PRIMARY, CB_SELECTSTRING, -1, (LPARAM)(L"Path Tracing"));
	SendDlgItemMessage(hWnd, IDC_SECONDARY, CB_SELECTSTRING, -1, (LPARAM)(L"Path Tracing"));
	SendDlgItemMessage(hWnd, IDC_TERTIARY, CB_SELECTSTRING, -1, (LPARAM)(L"Path Tracing"));*/

	SendDlgItemMessage(hWnd, IDC_PRIMARY, CB_SETCURSEL, rend->rendParams.primary, 0);
	SendDlgItemMessage(hWnd, IDC_SECONDARY, CB_SETCURSEL, rend->rendParams.secondary, 0);
	SendDlgItemMessage(hWnd, IDC_TERTIARY, CB_SETCURSEL, rend->rendParams.tertiary, 0);

	//CAUSTICS
	SendDlgItemMessage(hWnd, IDC_CAUSTICS, CB_ADDSTRING, 0, (LPARAM)(L"None"));
  SendDlgItemMessage(hWnd, IDC_CAUSTICS, CB_ADDSTRING, 0, (LPARAM)(L"SPPM"));
  SendDlgItemMessage(hWnd, IDC_CAUSTICS, CB_ADDSTRING, 0, (LPARAM)(L"Path Tracing"));

	//SendDlgItemMessage(hWnd, IDC_CAUSTICS, CB_SELECTSTRING, -1, (LPARAM)(L"None"));
	SendDlgItemMessage(hWnd, IDC_CAUSTICS, CB_SETCURSEL, rend->rendParams.causticsMode, 0);

	//TIME
	SendDlgItemMessage(hWnd, IDC_TIMEUNIT, CB_ADDSTRING, 0, (LPARAM)(L"Seconds"));
  SendDlgItemMessage(hWnd, IDC_TIMEUNIT, CB_ADDSTRING, 0, (LPARAM)(L"Minutes"));
	SendDlgItemMessage(hWnd, IDC_TIMEUNIT, CB_SELECTSTRING, -1, (LPARAM)(L"Seconds"));
	
	focalplane_edit = GetICustEdit(GetDlgItem(hWnd, IDC_FOCAL));
	lensradius_edit = GetICustEdit(GetDlgItem(hWnd, IDC_LENS));
	timelimit_edit = GetICustEdit(GetDlgItem(hWnd, IDC_TIMELIMIT_EDIT));
	timelimit_edit->SetText(0);
	timelimit_edit->Disable();
  
	focalplane_edit->SetText(rend->rendParams.focalplane);
	lensradius_edit->SetText(rend->rendParams.lensradius);

	focalplane_spin = GetISpinner(GetDlgItem(hWnd, IDC_FOCAL_SPIN));
  focalplane_spin->SetLimits(0.0f, 1000.0f, FALSE);
  focalplane_spin->SetResetValue(8.0f);   // Right click reset value
  focalplane_spin->SetValue(rend->rendParams.focalplane, FALSE); // FALSE = don't send notify yet.
	focalplane_spin->SetScale(1.0f);       // value change step
  focalplane_spin->LinkToEdit(GetDlgItem(hWnd, IDC_FOCAL), EDITTYPE_FLOAT);

	lensradius_spin = GetISpinner(GetDlgItem(hWnd, IDC_LENS_SPIN));
  lensradius_spin->SetLimits(0.00f, 1.0f, FALSE);
  lensradius_spin->SetResetValue(0.05f); 
  lensradius_spin->SetValue(rend->rendParams.lensradius, FALSE); 
	lensradius_spin->SetScale(0.005f);      // value change step
  lensradius_spin->LinkToEdit(GetDlgItem(hWnd, IDC_LENS), EDITTYPE_FLOAT);

	timelimit_spin = GetISpinner(GetDlgItem(hWnd, IDC_TIMELIMIT_SPIN));
  timelimit_spin->SetLimits(0, 60000, FALSE);
  timelimit_spin->SetResetValue(0); 
  timelimit_spin->SetValue(rend->rendParams.timeLimit, FALSE); 
	timelimit_spin->SetScale(1);      // value change step
  timelimit_spin->LinkToEdit(GetDlgItem(hWnd, IDC_TIMELIMIT_EDIT), EDITTYPE_INT);

  CheckDlgButton(hWnd, IDC_GUI, rend->rendParams.useHydraGUI);
	CheckDlgButton(hWnd, IDC_TONEMAP, rend->rendParams.useToneMapping);
	CheckDlgButton(hWnd, IDC_DOF_ON, rend->rendParams.enableDOF);
	CheckDlgButton(hWnd, IDC_RANDOMLIGHT_ON, rend->rendParams.noRandomLightSel);
	CheckDlgButton(hWnd, IDC_LOG, rend->rendParams.enableLog);
	CheckDlgButton(hWnd, IDC_DEBUG, rend->rendParams.debugOn);
	CheckDlgButton(hWnd, IDC_TIMELIMIT, rend->rendParams.timeLimit);
	CheckDlgButton(hWnd, IDC_PRIMARY_ML, rend->rendParams.primaryMLFilter);
	CheckDlgButton(hWnd, IDC_SECONDARY_ML, rend->rendParams.secondaryMLFilter);

	//CheckDlgButton(hWnd, IDC_ALL_SECONDARY, 0);
	CheckDlgButton(hWnd, IDC_ALL_TERTIARY, rend->rendParams.allTertiary);
	CheckDlgButton(hWnd, IDC_WRITE_TO_DISK, rend->rendParams.writeToDisk);
	

	EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY_ML ), !rend->rendParams.secondary);			
	EnableWindow(GetDlgItem( hWnd, IDC_PRIMARY_ML ), !rend->rendParams.primary);	

	SetWindowText(GetDlgItem( hWnd, IDC_VERSION), rend->GetHydraVersion());	
}



void HydraRenderParamDlg::InitPathTracingDialog(HWND hWnd)
{
	minrays_edit = GetICustEdit(GetDlgItem(hWnd, IDC_MINRAY));
	minrays_edit->SetText(rend->rendParams.minrays);
	
	minrays_spin = GetISpinner(GetDlgItem(hWnd, IDC_MINRAY_SPIN));
  minrays_spin->SetLimits(16, 65536, FALSE);
  minrays_spin->SetResetValue(16); 
  minrays_spin->SetValue(rend->rendParams.minrays, FALSE); 
	minrays_spin->SetScale(8); //value change step
  minrays_spin->LinkToEdit(GetDlgItem(hWnd, IDC_MINRAY), EDITTYPE_INT);


	maxrays_edit = GetICustEdit(GetDlgItem(hWnd, IDC_MAXRAY));
	maxrays_edit->SetText(rend->rendParams.maxrays);
	
	maxrays_spin = GetISpinner(GetDlgItem(hWnd, IDC_MAXRAY_SPIN));
  maxrays_spin->SetLimits(64, 65536, FALSE);
  maxrays_spin->SetResetValue(1024); 
  maxrays_spin->SetValue(rend->rendParams.maxrays, FALSE); 
	maxrays_spin->SetScale(16); //value change step
  maxrays_spin->LinkToEdit(GetDlgItem(hWnd, IDC_MAXRAY), EDITTYPE_INT);


	raybounce_edit = GetICustEdit(GetDlgItem(hWnd, IDC_RAYBOUNCE));
	raybounce_edit->SetText(rend->rendParams.raybounce);
	
	raybounce_spin = GetISpinner(GetDlgItem(hWnd, IDC_RAYBOUNCE_SPIN));
  raybounce_spin->SetLimits(0, 64, FALSE);
  raybounce_spin->SetResetValue(4); 
  raybounce_spin->SetValue(rend->rendParams.raybounce, FALSE); 
	raybounce_spin->SetScale(1); //value change step
  raybounce_spin->LinkToEdit(GetDlgItem(hWnd, IDC_RAYBOUNCE), EDITTYPE_INT);


	diffbounce_edit = GetICustEdit(GetDlgItem(hWnd, IDC_DIFFBOUNCE));
	diffbounce_edit->SetText(rend->rendParams.diffbounce);
	
	diffbounce_spin = GetISpinner(GetDlgItem(hWnd, IDC_DIFFBOUNCE_SPIN));
  diffbounce_spin->SetLimits(0, 16, FALSE);
  diffbounce_spin->SetResetValue(2); 
  diffbounce_spin->SetValue(rend->rendParams.diffbounce, FALSE); 
	diffbounce_spin->SetScale(1); //value change step
  diffbounce_spin->LinkToEdit(GetDlgItem(hWnd, IDC_DIFFBOUNCE), EDITTYPE_INT);


	relative_error_edit = GetICustEdit(GetDlgItem(hWnd, IDC_RELATIVE_ERR));
	relative_error_edit->SetText(rend->rendParams.relative_error);

	relative_error_spin = GetISpinner(GetDlgItem(hWnd, IDC_RELATIVE_ERR_SPIN));
  relative_error_spin->SetLimits(0.00f, 100.0f, FALSE);
  relative_error_spin->SetResetValue(5.0f);   // Right click reset value
  relative_error_spin->SetValue(rend->rendParams.relative_error, FALSE); // FALSE = don't send notify yet.
	relative_error_spin->SetScale(1.0f);       // value change step
  relative_error_spin->LinkToEdit(GetDlgItem(hWnd, IDC_RELATIVE_ERR), EDITTYPE_FLOAT);


	SendDlgItemMessage(hWnd, IDC_SEED, CB_ADDSTRING, 0, (LPARAM)(L"None"));
  SendDlgItemMessage(hWnd, IDC_SEED, CB_ADDSTRING, 0, (LPARAM)(L"Per warp"));
  SendDlgItemMessage(hWnd, IDC_SEED, CB_ADDSTRING, 0, (LPARAM)(L"All"));

  //SendDlgItemMessage(hWnd, IDC_SEED, CB_SELECTSTRING, -1, (LPARAM)(L"None"));
	SendDlgItemMessage(hWnd, IDC_SEED, CB_SETCURSEL, rend->rendParams.seed, 0);

	CheckDlgButton(hWnd, IDC_CAUSTICS_ON, rend->rendParams.causticRays);
	CheckDlgButton(hWnd, IDC_RR_ON, rend->rendParams.useRR);
	CheckDlgButton(hWnd, IDC_GUIDED, rend->rendParams.guided);

}

void HydraRenderParamDlg::InitSPPMCDialog(HWND hWnd)
{
	maxphotons_c_edit = GetICustEdit(GetDlgItem(hWnd, IDC_MAXPHOTONS_C));
	maxphotons_c_edit->SetText(rend->rendParams.maxphotons_c);

	maxphotons_c_spin = GetISpinner(GetDlgItem(hWnd, IDC_MAXPHOTONS_C_SPIN));
  maxphotons_c_spin->SetLimits(1, 2000, FALSE);
  maxphotons_c_spin->SetResetValue(1000);   // Right click reset value
  maxphotons_c_spin->SetValue(rend->rendParams.maxphotons_c, FALSE); // FALSE = don't send notify yet.
	maxphotons_c_spin->SetScale(50);       // value change step
  maxphotons_c_spin->LinkToEdit(GetDlgItem(hWnd, IDC_MAXPHOTONS_C), EDITTYPE_INT);


	initial_radius_c_edit = GetICustEdit(GetDlgItem(hWnd, IDC_INIT_RADIUS_C));
	initial_radius_c_edit->SetText(rend->rendParams.initial_radius_c);

	initial_radius_c_spin = GetISpinner(GetDlgItem(hWnd, IDC_INIT_RADIUS_C_SPIN));
  initial_radius_c_spin->SetLimits(0.5, 32.0f, FALSE);
  initial_radius_c_spin->SetResetValue(4);   // Right click reset value
  initial_radius_c_spin->SetValue(rend->rendParams.initial_radius_c, FALSE); // FALSE = don't send notify yet.
	initial_radius_c_spin->SetScale(0.5f);       // value change step
  initial_radius_c_spin->LinkToEdit(GetDlgItem(hWnd, IDC_INIT_RADIUS_C), EDITTYPE_FLOAT);


	caustic_power_edit = GetICustEdit(GetDlgItem(hWnd, IDC_CAUSTICPOW));
	caustic_power_edit->SetText(rend->rendParams.caustic_power);

	caustic_power_spin = GetISpinner(GetDlgItem(hWnd, IDC_CAUSTICPOW_SPIN));
  caustic_power_spin->SetLimits(0, 10, FALSE);
  caustic_power_spin->SetResetValue(1);   // Right click reset value
  caustic_power_spin->SetValue(rend->rendParams.caustic_power, FALSE); // FALSE = don't send notify yet.
	caustic_power_spin->SetScale(0.5);       // value change step
  caustic_power_spin->LinkToEdit(GetDlgItem(hWnd, IDC_CAUSTICPOW), EDITTYPE_FLOAT);

	retrace_c_edit = GetICustEdit(GetDlgItem(hWnd, IDC_RETRACE_C));
	retrace_c_edit->SetText(rend->rendParams.retrace_c);

	retrace_c_spin = GetISpinner(GetDlgItem(hWnd, IDC_RETRACE_C_SPIN));
  retrace_c_spin->SetLimits(1, 16, FALSE);
  retrace_c_spin->SetResetValue(rend->rendParams.retrace_c);   // Right click reset value
  retrace_c_spin->SetValue(rend->rendParams.retrace_c, FALSE); // FALSE = don't send notify yet.
	retrace_c_spin->SetScale(1);                 // value change step
  retrace_c_spin->LinkToEdit(GetDlgItem(hWnd, IDC_RETRACE_C), EDITTYPE_INT);

	alpha_c_edit = GetICustEdit(GetDlgItem(hWnd, IDC_ALPHA_EDIT_C));
	alpha_c_edit->SetText(rend->rendParams.alpha_c);

	alpha_c_spin = GetISpinner(GetDlgItem(hWnd, IDC_ALPHA_SPIN_C));
  alpha_c_spin->SetLimits(0.66f, 1.0f, FALSE);
  alpha_c_spin->SetResetValue(rend->rendParams.alpha_c);   // Right click reset value
  alpha_c_spin->SetValue(rend->rendParams.alpha_c, FALSE); // FALSE = don't send notify yet.
	alpha_c_spin->SetScale(0.05f);                 // value change step
  alpha_c_spin->LinkToEdit(GetDlgItem(hWnd, IDC_ALPHA_EDIT_C), EDITTYPE_FLOAT);


	CheckDlgButton(hWnd, IDC_VISIBILITY_C_ON, rend->rendParams.visibility_c);
}

void HydraRenderParamDlg::InitSPPMDDialog(HWND hWnd)
{
	maxphotons_d_edit = GetICustEdit(GetDlgItem(hWnd, IDC_MAXPHOTONS_D));
	maxphotons_d_edit->SetText(rend->rendParams.maxphotons_d);

	maxphotons_d_spin = GetISpinner(GetDlgItem(hWnd, IDC_MAXPHOTONS_D_SPIN));
  maxphotons_d_spin->SetLimits(1, 2000, FALSE);
  maxphotons_d_spin->SetResetValue(1000);   // Right click reset value
  maxphotons_d_spin->SetValue(rend->rendParams.maxphotons_d, FALSE); // FALSE = don't send notify yet.
	maxphotons_d_spin->SetScale(50);       // value change step
  maxphotons_d_spin->LinkToEdit(GetDlgItem(hWnd, IDC_MAXPHOTONS_D), EDITTYPE_INT);


	initial_radius_d_edit = GetICustEdit(GetDlgItem(hWnd, IDC_INIT_RADIUS_D));
	initial_radius_d_edit->SetText(rend->rendParams.initial_radius_d);

	initial_radius_d_spin = GetISpinner(GetDlgItem(hWnd, IDC_INIT_RADIUS_D_SPIN));
  initial_radius_d_spin->SetLimits(1, 64, FALSE);
  initial_radius_d_spin->SetResetValue(10);   // Right click reset value
  initial_radius_d_spin->SetValue(rend->rendParams.initial_radius_d, FALSE); // FALSE = don't send notify yet.
	initial_radius_d_spin->SetScale(0.5f);     // value change step
  initial_radius_d_spin->LinkToEdit(GetDlgItem(hWnd, IDC_INIT_RADIUS_D), EDITTYPE_FLOAT);


	retrace_d_edit = GetICustEdit(GetDlgItem(hWnd, IDC_RETRACE_D));
	retrace_d_edit->SetText(rend->rendParams.retrace_d);

	retrace_d_spin = GetISpinner(GetDlgItem(hWnd, IDC_RETRACE_D_SPIN));
  retrace_d_spin->SetLimits(1, 16, FALSE);
  retrace_d_spin->SetResetValue(rend->rendParams.retrace_d);   // Right click reset value
  retrace_d_spin->SetValue(rend->rendParams.retrace_d, FALSE); // FALSE = don't send notify yet.
	retrace_d_spin->SetScale(1);                 // value change step
  retrace_d_spin->LinkToEdit(GetDlgItem(hWnd, IDC_RETRACE_D), EDITTYPE_INT);

	alpha_d_edit = GetICustEdit(GetDlgItem(hWnd, IDC_ALPHA_EDIT_D));
	alpha_d_edit->SetText(rend->rendParams.alpha_d);

	alpha_d_spin = GetISpinner(GetDlgItem(hWnd, IDC_ALPHA_SPIN_D));
  alpha_d_spin->SetLimits(0.66f, 1.0f, FALSE);
  alpha_d_spin->SetResetValue(rend->rendParams.alpha_d);   // Right click reset value
  alpha_d_spin->SetValue(rend->rendParams.alpha_d, FALSE); // FALSE = don't send notify yet.
	alpha_d_spin->SetScale(0.05f);                 // value change step
  alpha_d_spin->LinkToEdit(GetDlgItem(hWnd, IDC_ALPHA_EDIT_D), EDITTYPE_FLOAT);

	CheckDlgButton(hWnd, IDC_VISIBILITY_D_ON, rend->rendParams.visibility_d);
	CheckDlgButton(hWnd, IDC_IRRMAP, rend->rendParams.irr_map);
}

void HydraRenderParamDlg::InitIrrCacheDialog(HWND hWnd)
{
	ws_err_edit = GetICustEdit(GetDlgItem(hWnd, IDC_WS_ERR));
	ws_err_edit->SetText(rend->rendParams.ws_err);

	ws_err_spin = GetISpinner(GetDlgItem(hWnd, IDC_WS_ERR_SPIN));
  ws_err_spin->SetLimits(0.01f, 100.00f, FALSE);
  ws_err_spin->SetResetValue(40.00f);   // Right click reset value
  ws_err_spin->SetValue(rend->rendParams.ws_err, FALSE); // FALSE = don't send notify yet.
	ws_err_spin->SetScale(1.0f);       // value change step
  ws_err_spin->LinkToEdit(GetDlgItem(hWnd, IDC_WS_ERR), EDITTYPE_FLOAT);


	ss_err4_edit = GetICustEdit(GetDlgItem(hWnd, IDC_SS_ERR4));
	ss_err4_edit->SetText(rend->rendParams.ss_err4);

	ss_err4_spin = GetISpinner(GetDlgItem(hWnd, IDC_SS_ERR4_SPIN));
  ss_err4_spin->SetLimits(0.01f, 100.00f, FALSE);
  ss_err4_spin->SetResetValue(16.00f);   // Right click reset value
  ss_err4_spin->SetValue(rend->rendParams.ss_err4, FALSE); // FALSE = don't send notify yet.
	ss_err4_spin->SetScale(1.0f);       // value change step
  ss_err4_spin->LinkToEdit(GetDlgItem(hWnd, IDC_SS_ERR4), EDITTYPE_FLOAT);


	ss_err2_edit = GetICustEdit(GetDlgItem(hWnd, IDC_SS_ERR2));
	ss_err2_edit->SetText(rend->rendParams.ss_err2);

	ss_err2_spin = GetISpinner(GetDlgItem(hWnd, IDC_SS_ERR2_SPIN));
  ss_err2_spin->SetLimits(0.01f, 100.00f, FALSE);
  ss_err2_spin->SetResetValue(4.00f);   // Right click reset value
  ss_err2_spin->SetValue(rend->rendParams.ss_err2, FALSE); // FALSE = don't send notify yet.
	ss_err2_spin->SetScale(1.0f);       // value change step
  ss_err2_spin->LinkToEdit(GetDlgItem(hWnd, IDC_SS_ERR2), EDITTYPE_FLOAT);


	ss_err1_edit = GetICustEdit(GetDlgItem(hWnd, IDC_SS_ERR1));
	ss_err1_edit->SetText(rend->rendParams.ss_err1);

	ss_err1_spin = GetISpinner(GetDlgItem(hWnd, IDC_SS_ERR1_SPIN));
  ss_err1_spin->SetLimits(0.01f, 100.00f, FALSE);
  ss_err1_spin->SetResetValue(1.00f);   // Right click reset value
  ss_err1_spin->SetValue(rend->rendParams.ss_err1, FALSE); // FALSE = don't send notify yet.
	ss_err1_spin->SetScale(1.0f);       // value change step
  ss_err1_spin->LinkToEdit(GetDlgItem(hWnd, IDC_SS_ERR1), EDITTYPE_FLOAT);


	ic_relative_error_edit = GetICustEdit(GetDlgItem(hWnd, IDC_IC_RELATIVE_ERR));
	ic_relative_error_edit->SetText(rend->rendParams.ic_relative_error);

	ic_relative_error_spin = GetISpinner(GetDlgItem(hWnd, IDC_IC_RELATIVE_ERR_SPIN));
  ic_relative_error_spin->SetLimits(0.01f, 100.00f, FALSE);
  ic_relative_error_spin->SetResetValue(10.00f);   // Right click reset value
  ic_relative_error_spin->SetValue(rend->rendParams.ic_relative_error, FALSE); // FALSE = don't send notify yet.
	ic_relative_error_spin->SetScale(1.0f);       // value change step
  ic_relative_error_spin->LinkToEdit(GetDlgItem(hWnd, IDC_IC_RELATIVE_ERR), EDITTYPE_FLOAT);


	maxpass_edit = GetICustEdit(GetDlgItem(hWnd, IDC_MAXPASSES));
	maxpass_edit->SetText(rend->rendParams.maxpass);

	maxpass_spin = GetISpinner(GetDlgItem(hWnd, IDC_MAXPASSES_SPIN));
  maxpass_spin->SetLimits(2, 128, FALSE);
  maxpass_spin->SetResetValue(16);   // Right click reset value
  maxpass_spin->SetValue(rend->rendParams.maxpass, FALSE); // FALSE = don't send notify yet.
	maxpass_spin->SetScale(4);       // value change step
  maxpass_spin->LinkToEdit(GetDlgItem(hWnd, IDC_MAXPASSES), EDITTYPE_INT);

	SendDlgItemMessage(hWnd, IDC_FIXEDRAYS, CB_ADDSTRING, 0, (LPARAM)(L"1024"));
	SendDlgItemMessage(hWnd, IDC_FIXEDRAYS, CB_ADDSTRING, 0, (LPARAM)(L"4096"));
	SendDlgItemMessage(hWnd, IDC_FIXEDRAYS, CB_ADDSTRING, 0, (LPARAM)(L"16384"));
	SendDlgItemMessage(hWnd, IDC_FIXEDRAYS, CB_ADDSTRING, 0, (LPARAM)(L"65536"));

	std::wostringstream oss;
	oss << rend->rendParams.fixed_rays;
	std::wstring s = oss.str();

	SendDlgItemMessage(hWnd, IDC_FIXEDRAYS, CB_SELECTSTRING, -1, (LPARAM)s.c_str());
	//SendDlgItemMessage(hWnd, IDC_FIXEDRAYS, CB_SETCURSEL, rend->rendParams.fixed_rays, 0);

	SendDlgItemMessage(hWnd, IDC_IC_EVAL, CB_ADDSTRING, 0, (LPARAM)(L"fixed rays"));
  SendDlgItemMessage(hWnd, IDC_IC_EVAL, CB_ADDSTRING, 0, (LPARAM)(L"progressive"));

  //SendDlgItemMessage(hWnd, IDC_IC_EVAL, CB_SELECTSTRING, -1, (LPARAM)(L"fixed rays"));
	SendDlgItemMessage(hWnd, IDC_IC_EVAL, CB_SETCURSEL, rend->rendParams.ic_eval, 0);
}

void HydraRenderParamDlg::InitMultiLayerDialog(HWND hWnd)
{
	s_sigma_edit = GetICustEdit(GetDlgItem(hWnd, IDC_SSIGMA));
	s_sigma_edit->SetText(rend->rendParams.s_sigma);

	s_sigma_spin = GetISpinner(GetDlgItem(hWnd, IDC_SSIGMA_SPIN));
  s_sigma_spin->SetLimits(1, 16, FALSE);
  s_sigma_spin->SetResetValue(5);   // Right click reset value
  s_sigma_spin->SetValue(rend->rendParams.s_sigma, FALSE); // FALSE = don't send notify yet.
	s_sigma_spin->SetScale(1);       // value change step
  s_sigma_spin->LinkToEdit(GetDlgItem(hWnd, IDC_SSIGMA), EDITTYPE_INT);

	r_sigma_edit = GetICustEdit(GetDlgItem(hWnd, IDC_RSIGMA));
	r_sigma_edit->SetText(rend->rendParams.r_sigma);

	r_sigma_spin = GetISpinner(GetDlgItem(hWnd, IDC_RSIGMA_SPIN));
  r_sigma_spin->SetLimits(1.0f, 5.00f, FALSE);
  r_sigma_spin->SetResetValue(2.0f);   // Right click reset value
  r_sigma_spin->SetValue(rend->rendParams.r_sigma, FALSE); // FALSE = don't send notify yet.
	r_sigma_spin->SetScale(0.5f);       // value change step
  r_sigma_spin->LinkToEdit(GetDlgItem(hWnd, IDC_RSIGMA), EDITTYPE_FLOAT);

	layer_num_edit = GetICustEdit(GetDlgItem(hWnd, IDC_LAYERNUM));
	layer_num_edit->SetText(rend->rendParams.layerNum);

	layer_num_spin = GetISpinner(GetDlgItem(hWnd, IDC_LAYERNUM_SPIN));
  layer_num_spin->SetLimits(1, 5, FALSE);
  layer_num_spin->SetResetValue(1);   // Right click reset value
  layer_num_spin->SetValue(rend->rendParams.layerNum, FALSE); // FALSE = don't send notify yet.
	layer_num_spin->SetScale(1);       // value change step
  layer_num_spin->LinkToEdit(GetDlgItem(hWnd, IDC_LAYERNUM), EDITTYPE_INT);

	CheckDlgButton(hWnd, IDC_FILTER, rend->rendParams.filterPrimary);
}

void HydraRenderParamDlg::InitToneMapDialog(HWND hWnd)
{
	white_point_edit = GetICustEdit(GetDlgItem(hWnd, IDC_WHITE));
	white_point_edit->SetText(rend->rendParams.white_point);

	white_point_spin = GetISpinner(GetDlgItem(hWnd, IDC_WHITE_SPIN));
  white_point_spin->SetLimits(0.00f, 30.00f, FALSE);
  white_point_spin->SetResetValue(2.5f);   // Right click reset value
  white_point_spin->SetValue(rend->rendParams.white_point, FALSE); // FALSE = don't send notify yet.
	white_point_spin->SetScale(0.5f);       // value change step
  white_point_spin->LinkToEdit(GetDlgItem(hWnd, IDC_WHITE), EDITTYPE_FLOAT);


	gamma_edit = GetICustEdit(GetDlgItem(hWnd, IDC_GAMMA));
	gamma_edit->SetText(rend->rendParams.gamma);

	gamma_spin = GetISpinner(GetDlgItem(hWnd, IDC_GAMMA_SPIN));
  gamma_spin->SetLimits(0.00f, 100.00f, FALSE);
  gamma_spin->SetResetValue(2.2f);   // Right click reset value
  gamma_spin->SetValue(rend->rendParams.gamma, FALSE); // FALSE = don't send notify yet.
	gamma_spin->SetScale(0.1f);       // value change step
  gamma_spin->LinkToEdit(GetDlgItem(hWnd, IDC_GAMMA), EDITTYPE_FLOAT);


	strength_edit = GetICustEdit(GetDlgItem(hWnd, IDC_STRENGTH));
	strength_edit->SetText(rend->rendParams.strength);

	strength_spin = GetISpinner(GetDlgItem(hWnd, IDC_STRENGTH_SPIN));
  strength_spin->SetLimits(0.01f, 10.00f, FALSE);
  strength_spin->SetResetValue(0.25f);   // Right click reset value
  strength_spin->SetValue(rend->rendParams.strength, FALSE); // FALSE = don't send notify yet.
	strength_spin->SetScale(0.05f);       // value change step
  strength_spin->LinkToEdit(GetDlgItem(hWnd, IDC_STRENGTH), EDITTYPE_FLOAT);


	phi_edit = GetICustEdit(GetDlgItem(hWnd, IDC_PHI));
	phi_edit->SetText(rend->rendParams.phi);

	phi_spin = GetISpinner(GetDlgItem(hWnd, IDC_PHI_SPIN));
  phi_spin->SetLimits(0.1f, 256.00f, FALSE);
  phi_spin->SetResetValue(16.0f);   // Right click reset value
  phi_spin->SetValue(rend->rendParams.phi, FALSE); // FALSE = don't send notify yet.
	phi_spin->SetScale(1.0f);       // value change step
  phi_spin->LinkToEdit(GetDlgItem(hWnd, IDC_PHI), EDITTYPE_FLOAT);

	tone_map = GetICustButton(GetDlgItem(hWnd, IDC_DO_TONEMAP));

	tone_map->SetType(CBT_PUSH);

	CheckDlgButton(hWnd, IDC_BLOOM_ON, rend->rendParams.bloom);

}

void HydraRenderParamDlg::InitEnvironmentDialog(HWND hWnd)
{
	env_mult_edit = GetICustEdit(GetDlgItem(hWnd, IDC_ENV_MULT));
	env_mult_edit->SetText(rend->rendParams.env_mult);

	env_mult_spin = GetISpinner(GetDlgItem(hWnd, IDC_ENV_MULT_SPIN));
  env_mult_spin->SetLimits(0.0f, 100.00f, FALSE);
  env_mult_spin->SetResetValue(1.0f);   // Right click reset value
  env_mult_spin->SetValue(rend->rendParams.env_mult, FALSE); // FALSE = don't send notify yet.
	env_mult_spin->SetScale(1.0f);       // value change step
  env_mult_spin->LinkToEdit(GetDlgItem(hWnd, IDC_ENV_MULT), EDITTYPE_FLOAT);
}

void HydraRenderParamDlg::RemovePage(HWND &hPanel)
{
	if(hPanel != NULL)
	{
		ir->DeleteTabRollupPage(kTabClassID, hPanel);
		hPanel = NULL;
	}
}

void HydraRenderParamDlg::AddPage(HWND &hPanel, int IDD)
{
	if (hPanel == nullptr)
	{
		switch(IDD)
		{
		case IDD_HYDRADIALOG:
			hMain = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_HYDRADIALOG), HydraRenderParamDlgProc, L"Hydra Renderer", (LPARAM)this);
			break;
		case IDD_PATHTRACING:
			hPathTracing = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_PATHTRACING), PathTracingDlgProc, L"Path tracing", (LPARAM)this);
			break;
		case IDD_TONEMAP:
			hToneMap = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_TONEMAP), ToneMapDlgProc, L"Tone mapping", (LPARAM)this);
			/*rollupIndices[TONEMAP] = ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_TONEMAP), ToneMapDlgProc, L"Tone mapping", (LPARAM)this, APPENDROLL_CLOSED);
			hToneMap = ir->GetTabIRollup(kTabClassID)->GetPanelDlg(rollupIndices[TONEMAP]);
			ShowWindow(hToneMap,SW_SHOWNOACTIVATE);*/
			break;
		case IDD_SPPM_CAUSTIC:
			hSPPMC = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_SPPM_CAUSTIC), SPPMCDlgProc, L"SPPM (Caustics)", (LPARAM)this);
			break;
		case IDD_SPPM_DIFF:
			hSPPMD = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_SPPM_DIFF), SPPMDDlgProc, L"SPPM (Diffuse)", (LPARAM)this);
			break;
		case IDD_IRRCACHE:
			hIrrCache = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_IRRCACHE), IrrCacheDlgProc, L"Irradiance Cache", (LPARAM)this);
			break;
		case IDD_MULTILAYER:
			hIrrCache = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_MULTILAYER), MultiLayerDlgProc, L"Multi-Layer", (LPARAM)this);
			break;
		case IDD_ENVIRONMENT:
			hEnv = ir->AddTabRollupPage(kTabClassID, hInstance, MAKEINTRESOURCE(IDD_ENVIRONMENT), EnvironmentDlgProc, L"Environment", (LPARAM)this);
			break;
		default:
			break;
		}
	}

}

void HydraRenderParamDlg::AcceptParams()
{
  rend->rendParams.useHydraGUI   = IsDlgButtonChecked(hMain, IDC_GUI); 

	rend->rendParams.primary      = SendDlgItemMessage(hMain, IDC_PRIMARY, CB_GETCURSEL, 0, 0);
	rend->rendParams.secondary    = SendDlgItemMessage(hMain, IDC_SECONDARY, CB_GETCURSEL, 0, 0);
	rend->rendParams.tertiary     = SendDlgItemMessage(hMain, IDC_TERTIARY, CB_GETCURSEL, 0, 0);
	//rend->allSecondary = IsDlgButtonChecked(hMain, IDC_ALL_SECONDARY);
	rend->rendParams.allTertiary  = IsDlgButtonChecked(hMain, IDC_ALL_TERTIARY);
  rend->rendParams.manualMode   = 1;
	rend->rendParams.causticsMode = SendDlgItemMessage(hMain, IDC_CAUSTICS, CB_GETCURSEL, 0, 0);

	rend->rendParams.timeLimitOn   = IsDlgButtonChecked(hMain, IDC_TIMELIMIT);
	if(rend->rendParams.timeLimitOn)
	{
		rend->rendParams.timeLimit = timelimit_spin->GetIVal();
		if(SendDlgItemMessage(hMain, IDC_TIMEUNIT, CB_GETCURSEL, 0, 0))
			rend->rendParams.timeLimit *= 60;
	}
	else
		rend->rendParams.timeLimit = 0;

	rend->rendParams.useToneMapping   = IsDlgButtonChecked(hMain, IDC_TONEMAP);
	rend->rendParams.focalplane = focalplane_spin->GetFVal();
	rend->rendParams.lensradius = lensradius_spin->GetFVal();
	rend->rendParams.enableDOF = IsDlgButtonChecked(hMain, IDC_DOF_ON);
	rend->rendParams.noRandomLightSel = IsDlgButtonChecked(hMain, IDC_RANDOMLIGHT_ON);
	rend->rendParams.enableLog = IsDlgButtonChecked(hMain, IDC_LOG);
	rend->rendParams.debugOn = IsDlgButtonChecked(hMain, IDC_DEBUG);
	rend->rendParams.primaryMLFilter = IsDlgButtonChecked(hMain, IDC_PRIMARY_ML);
	rend->rendParams.secondaryMLFilter = IsDlgButtonChecked(hMain, IDC_SECONDARY_ML);
	rend->rendParams.writeToDisk = IsDlgButtonChecked(hMain, IDC_WRITE_TO_DISK);

	//path tracing
	rend->rendParams.seed = SendDlgItemMessage(hPathTracing, IDC_SEED, CB_GETCURSEL, 0, 0);
	rend->rendParams.minrays = minrays_spin->GetIVal();
	rend->rendParams.maxrays = maxrays_spin->GetIVal();
	rend->rendParams.raybounce  = raybounce_spin->GetIVal();
	rend->rendParams.diffbounce = diffbounce_spin->GetIVal();
	rend->rendParams.relative_error = relative_error_spin->GetFVal();
  rend->rendParams.useRR          = IsDlgButtonChecked(hPathTracing, IDC_RR_ON);
  rend->rendParams.causticRays    = IsDlgButtonChecked(hPathTracing, IDC_CAUSTICS_ON);
	rend->rendParams.guided = IsDlgButtonChecked(hPathTracing, IDC_GUIDED);

	//SPPM Caustics
	rend->rendParams.maxphotons_c = maxphotons_c_spin->GetIVal();
	rend->rendParams.caustic_power = caustic_power_spin->GetFVal();
	rend->rendParams.retrace_c = retrace_c_spin->GetIVal();
	rend->rendParams.initial_radius_c = initial_radius_c_spin->GetFVal();
	rend->rendParams.visibility_c = IsDlgButtonChecked(hSPPMC, IDC_VISIBILITY_C_ON); 
	rend->rendParams.alpha_c = alpha_c_spin->GetFVal();
	
	//SPPM Diffuse
	rend->rendParams.maxphotons_d = maxphotons_d_spin->GetIVal();
	rend->rendParams.retrace_d = retrace_d_spin->GetIVal();
	rend->rendParams.initial_radius_d = initial_radius_d_spin->GetFVal();
	rend->rendParams.visibility_d = IsDlgButtonChecked(hSPPMD, IDC_VISIBILITY_D_ON); 
	rend->rendParams.irr_map = IsDlgButtonChecked(hSPPMD, IDC_IRRMAP); 
	rend->rendParams.alpha_d = alpha_d_spin->GetFVal();
	
	//Irradiance cache
	rend->rendParams.ic_eval = SendDlgItemMessage(hIrrCache, IDC_IC_EVAL, CB_GETCURSEL, 0, 0);
	rend->rendParams.maxpass = maxpass_spin->GetIVal();
	//rend->fixed_rays = SendDlgItemMessage(hIrrCache, IDC_FIXEDRAYS, CB_GETCURSEL, 0, 0);
	wchar_t fixedRays[8];
	int nIndex = SendDlgItemMessage(hIrrCache, IDC_FIXEDRAYS, CB_GETCURSEL, 0, 0 );
	SendDlgItemMessage(hIrrCache, IDC_FIXEDRAYS, CB_GETLBTEXT, nIndex, (LPARAM)fixedRays);
	rend->rendParams.fixed_rays = _wtoi(fixedRays);

	rend->rendParams.ws_err = ws_err_spin->GetFVal();
	rend->rendParams.ss_err4 = ss_err4_spin->GetFVal();
	rend->rendParams.ss_err2 = ss_err2_spin->GetFVal();
	rend->rendParams.ss_err1 = ss_err1_spin->GetFVal();
	rend->rendParams.ic_relative_error = ic_relative_error_spin->GetFVal();

	//Tone mapping
	rend->rendParams.white_point = white_point_spin->GetFVal();
  rend->rendParams.gamma = gamma_spin->GetFVal();
	rend->rendParams.strength = strength_spin->GetFVal();
	rend->rendParams.phi = phi_spin->GetFVal();
	rend->rendParams.bloom = IsDlgButtonChecked(hToneMap, IDC_BLOOM_ON); 

	//Multi-Layer
	rend->rendParams.r_sigma = r_sigma_spin->GetFVal();
	rend->rendParams.s_sigma = s_sigma_spin->GetFVal();
	rend->rendParams.layerNum = layer_num_spin->GetIVal();
	rend->rendParams.filterPrimary = IsDlgButtonChecked(hMulti, IDC_FILTER); 

	//Environment
	rend->rendParams.env_mult = env_mult_spin->GetFVal();
}



void HydraRenderParamDlg::RejectParams()
{

}


static INT_PTR CALLBACK HydraRenderParamDlgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitMainHydraDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseISpinner(dlg->focalplane_spin);
					ReleaseISpinner(dlg->lensradius_spin);
					ReleaseISpinner(dlg->timelimit_spin);
					ReleaseICustEdit(dlg->focalplane_edit);
					ReleaseICustEdit(dlg->lensradius_edit);
					ReleaseICustEdit(dlg->timelimit_edit);

				}
        break;      

      case WM_COMMAND:
				switch (HIWORD(wParam)) 
				{ 
					case LBN_SELCHANGE: 
					{
						if(LOWORD( wParam ) == IDC_PRIMARY)
						{
							int pr = SendDlgItemMessage(dlg->hMain, IDC_PRIMARY, CB_GETCURSEL, 0, 0);
							if (pr == RENDER_METHOD_SPPM) //SPPM 
							{
								SendDlgItemMessage(dlg->hMain, IDC_SECONDARY, CB_SELECTSTRING, -1, (LPARAM)(L"SPPM"));
								SendDlgItemMessage(dlg->hMain, IDC_TERTIARY, CB_SELECTSTRING, -1, (LPARAM)(L"SPPM"));
								//SendDlgItemMessage(dlg->hMain, IDC_CAUSTICS, CB_SELECTSTRING, -1, (LPARAM)(L"SPPM"));
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY ), FALSE);
								EnableWindow(GetDlgItem( hWnd, IDC_TERTIARY ), FALSE);
								EnableWindow(GetDlgItem( hWnd, IDC_ALL_TERTIARY ), TRUE);
								//EnableWindow(GetDlgItem( hWnd, IDC_CAUSTICS ), FALSE);
								//dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->SPPMD], TRUE);
								CheckDlgButton(hWnd, IDC_PRIMARY_ML, FALSE);
								CheckDlgButton(hWnd, IDC_SECONDARY_ML, FALSE);
								EnableWindow(GetDlgItem( hWnd, IDC_PRIMARY_ML ), FALSE);									
							}
							else  //PT
							{
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY ), TRUE);
								EnableWindow(GetDlgItem( hWnd, IDC_TERTIARY ), TRUE);
								EnableWindow(GetDlgItem( hWnd, IDC_PRIMARY_ML ), TRUE);					
								//EnableWindow(GetDlgItem( hWnd, IDC_CAUSTICS ), TRUE);
							}

							dlg->rend->FixGuiForManualSettings(dlg);
						}
						else if(LOWORD( wParam ) == IDC_SECONDARY)
						{
							int pr = SendDlgItemMessage(dlg->hMain, IDC_SECONDARY, CB_GETCURSEL, 0, 0);
							if (pr == RENDER_METHOD_SPPM) //SPPM
							{
								SendDlgItemMessage(dlg->hMain, IDC_TERTIARY, CB_SELECTSTRING, -1, (LPARAM)(L"SPPM"));
								EnableWindow(GetDlgItem( hWnd, IDC_TERTIARY ), FALSE);
								EnableWindow(GetDlgItem( hWnd, IDC_ALL_TERTIARY ), TRUE);

								CheckDlgButton(hWnd, IDC_SECONDARY_ML, FALSE);
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY_ML ), FALSE);								
								//dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->SPPMD], TRUE);
							}
							else if(pr == RENDER_METHOD_IC) //IC
							{
								//dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->IRRCACHE], TRUE);
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY ), TRUE);
								EnableWindow(GetDlgItem( hWnd, IDC_TERTIARY ), TRUE);

								CheckDlgButton(hWnd, IDC_SECONDARY_ML, FALSE);
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY_ML ), FALSE);
                dlg->rend->rendParams.icBounce = 0;
							}
							else //PT
							{
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY ), TRUE);
								EnableWindow(GetDlgItem( hWnd, IDC_TERTIARY ), TRUE);
								EnableWindow(GetDlgItem( hWnd, IDC_SECONDARY_ML ), TRUE);			
							}

							dlg->rend->FixGuiForManualSettings(dlg);
						}
						else if(LOWORD( wParam ) == IDC_TERTIARY)
						{
              dlg->rend->rendParams.icBounce = 0;

							int pr = SendDlgItemMessage(dlg->hMain, IDC_TERTIARY, CB_GETCURSEL, 0, 0);
							if (pr == RENDER_METHOD_SPPM) // SPPM
							{
								EnableWindow(GetDlgItem( hWnd, IDC_ALL_TERTIARY ), TRUE);
								//dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->SPPMD], TRUE);
							}
							else if (pr == RENDER_METHOD_IC) //IC
							{
								EnableWindow(GetDlgItem( hWnd, IDC_ALL_TERTIARY ), FALSE);
								//dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->IRRCACHE], TRUE);
                dlg->rend->rendParams.icBounce = 1;
							}
							else //PT
								EnableWindow(GetDlgItem( hWnd, IDC_ALL_TERTIARY ), FALSE);

							dlg->rend->FixGuiForManualSettings(dlg);
						}
						else if(LOWORD( wParam ) == IDC_CAUSTICS)
						{
							//int pr = SendDlgItemMessage(dlg->hMain, IDC_CAUSTICS, CB_GETCURSEL, 0, 0);
							//if(pr == RENDER_METHOD_SPPM) //SPPM
							//	dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->SPPMC], TRUE);
							dlg->rend->FixGuiForManualSettings(dlg);
						}
					}
					break;

					case BN_CLICKED:  
						if(LOWORD( wParam ) == IDC_TONEMAP)
						{
							/*LRESULT chkState = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
							if (chkState == BST_CHECKED)
							{	
								//dlg->rollupIndices[dlg->TONEMAP] = dlg->ir->GetTabIRollup(kTabClassID)->AppendRollup(hInstance, MAKEINTRESOURCE(IDD_TONEMAP), ToneMapDlgProc, L"Tone mapping", (LPARAM)dlg);
								//dlg->hToneMap = dlg->ir->GetTabIRollup(kTabClassID)->GetPanelDlg(dlg->TONEMAP);
								
								//dlg->ir->GetTabIRollup(kTabClassID)->Show(dlg->rollupIndices[dlg->TONEMAP]);
								//dlg->AddPage(dlg->hToneMap, IDD_TONEMAP);
								dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->TONEMAP], TRUE);
							}
							else
							{
								//dlg->ir->GetTabIRollup(kTabClassID)->DeleteRollup(dlg->rollupIndices[dlg->TONEMAP], 1);
								//dlg->hToneMap = NULL;
								dlg->ir->GetTabIRollup(kTabClassID)->SetPanelOpen(dlg->rollupIndices[dlg->TONEMAP], FALSE);
								//dlg->ir->GetTabIRollup(kTabClassID)->Hide(dlg->rollupIndices[dlg->TONEMAP]);
								//dlg->RemovePage(dlg->hToneMap);
							}*/
						}
						else if(LOWORD( wParam ) == IDC_TIMELIMIT)
						{
							LRESULT chkState = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
							if (chkState == BST_CHECKED)
							{
								EnableWindow(GetDlgItem( hWnd, IDC_TIMEUNIT), TRUE);
								dlg->timelimit_edit->Enable();
								dlg->timelimit_spin->Enable();
							}
							else
							{
								EnableWindow(GetDlgItem( hWnd, IDC_TIMEUNIT), FALSE);
								dlg->timelimit_edit->Disable();
								dlg->timelimit_spin->Disable();
							}
						}
						else if(LOWORD( wParam ) == IDC_PRIMARY_ML)
						{
							LRESULT chkState = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
							if (chkState == BST_CHECKED)
              {
								CheckDlgButton(hWnd, IDC_SECONDARY_ML, TRUE);
                dlg->rend->rendParams.primaryMLFilter = 1;
                dlg->rend->FixGuiForManualSettings(dlg);  // automaticly reduce max rays per pixel
              }
						}
            else if(LOWORD( wParam ) == IDC_SECONDARY_ML)
						{
							LRESULT chkState = SendMessage((HWND)lParam, BM_GETCHECK, 0, 0);
							if (chkState == BST_UNCHECKED)
								CheckDlgButton(hWnd, IDC_PRIMARY_ML, FALSE);
              else
              {
                dlg->rend->rendParams.secondaryMLFilter = 1;
                dlg->rend->FixGuiForManualSettings(dlg);  // automaticly reduce max rays per pixel
              }
						}
						break;
				}
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK PathTracingDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitPathTracingDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->minrays_edit);
					ReleaseICustEdit(dlg->maxrays_edit);
					ReleaseICustEdit(dlg->raybounce_edit);
					ReleaseICustEdit(dlg->diffbounce_edit);
					ReleaseICustEdit(dlg->relative_error_edit);

					ReleaseISpinner(dlg->minrays_spin);
					ReleaseISpinner(dlg->maxrays_spin);
					ReleaseISpinner(dlg->raybounce_spin);
					ReleaseISpinner(dlg->diffbounce_spin);
					ReleaseISpinner(dlg->relative_error_spin);
				}
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK SPPMCDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitSPPMCDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->maxphotons_c_edit);
					ReleaseICustEdit(dlg->initial_radius_c_edit);
					ReleaseICustEdit(dlg->caustic_power_edit);
					ReleaseICustEdit(dlg->retrace_c_edit);
					ReleaseICustEdit(dlg->alpha_c_edit);

					ReleaseISpinner(dlg->maxphotons_c_spin);
					ReleaseISpinner(dlg->initial_radius_c_spin);
					ReleaseISpinner(dlg->caustic_power_spin);
					ReleaseISpinner(dlg->retrace_c_spin);
					ReleaseISpinner(dlg->alpha_c_spin);
				}
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK SPPMDDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitSPPMDDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->maxphotons_d_edit);
					ReleaseICustEdit(dlg->initial_radius_d_edit);
					ReleaseICustEdit(dlg->retrace_d_edit);
					ReleaseICustEdit(dlg->alpha_d_edit);

					ReleaseISpinner(dlg->maxphotons_d_spin);
					ReleaseISpinner(dlg->initial_radius_d_spin);
					ReleaseISpinner(dlg->retrace_d_spin);
					ReleaseISpinner(dlg->alpha_d_spin);
				}
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK IrrCacheDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitIrrCacheDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->ws_err_edit);
					ReleaseICustEdit(dlg->ss_err4_edit);
					ReleaseICustEdit(dlg->ss_err2_edit);
					ReleaseICustEdit(dlg->ss_err1_edit);
					ReleaseICustEdit(dlg->maxpass_edit);
					ReleaseICustEdit(dlg->ic_relative_error_edit);

					ReleaseISpinner(dlg->ws_err_spin);
					ReleaseISpinner(dlg->ss_err4_spin);
					ReleaseISpinner(dlg->ss_err2_spin);
					ReleaseISpinner(dlg->ss_err1_spin);
					ReleaseISpinner(dlg->maxpass_spin);
					ReleaseISpinner(dlg->ic_relative_error_spin);
				}
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK MultiLayerDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitMultiLayerDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->r_sigma_edit);
					ReleaseICustEdit(dlg->s_sigma_edit);
					ReleaseICustEdit(dlg->layer_num_edit);

					ReleaseISpinner(dlg->r_sigma_spin);
					ReleaseISpinner(dlg->s_sigma_spin);
					ReleaseISpinner(dlg->layer_num_spin);
				}
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK ToneMapDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
            dlg->InitToneMapDialog(hWnd);
        }
				//dlg->ir->GetTabIRollup(kTabClassID)->Hide(dlg->rollupIndices[dlg->TONEMAP]);
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->white_point_edit);
					ReleaseICustEdit(dlg->gamma_edit);
					ReleaseICustEdit(dlg->strength_edit);
					ReleaseICustEdit(dlg->phi_edit);

					ReleaseISpinner(dlg->white_point_spin);
					ReleaseISpinner(dlg->gamma_spin);
					ReleaseISpinner(dlg->strength_spin);
					ReleaseISpinner(dlg->phi_spin);

					ReleaseICustButton(dlg->tone_map);
				}
        break;      

      case WM_COMMAND:
        switch (HIWORD(wParam)) 
				{ 
					case BN_CLICKED:  
						if(LOWORD( wParam ) == IDC_DO_TONEMAP)
						{
							if(dlg->rend->last_render != NULL)
							{
								int renderWidth  = dlg->rend->rendParams.nMaxx - dlg->rend->rendParams.nMinx;
								int renderHeight = dlg->rend->rendParams.nMaxy - dlg->rend->rendParams.nMiny;
										
								SetFocus(dlg->rend->last_render->GetWindow());
								SetActiveWindow(dlg->rend->last_render->GetWindow());

								SetFocus(hWnd);
								SetActiveWindow(hWnd);

								dlg->rend->ToneMap(dlg->rend->last_render, renderHeight, renderWidth);						
								dlg->rend->displayLastRender();
								/**/
								
							}
						}
					/*default:
						dlg->AcceptParams();*/
				}
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

static INT_PTR CALLBACK EnvironmentDlgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
  HydraRenderParamDlg *dlg = DLGetWindowLongPtr<HydraRenderParamDlg*>(hWnd);
  switch (msg) 
  {
      case WM_INITDIALOG:
        
        dlg = (HydraRenderParamDlg*)lParam;
        DLSetWindowLongPtr(hWnd, lParam);
        if (dlg) 
        {
          if (dlg->prog)
            dlg->InitProgDialog(hWnd);
          else
						dlg->InitEnvironmentDialog(hWnd);
        }
        break;

      case WM_DESTROY:
				if (!dlg->prog)
				{
					ReleaseICustEdit(dlg->env_mult_edit);

					ReleaseISpinner(dlg->env_mult_spin);
				}
        break;      

      case WM_COMMAND:
        // We don't care about the UI controls.
        // We take the value in AcceptParams() instead.
        break;

      case WM_LBUTTONDOWN:
      case WM_MOUSEMOVE:
      case WM_LBUTTONUP:
        dlg->ir->RollupMouseMessage(hWnd,msg,wParam,lParam);
        break;
      default:
        return FALSE;
  }  
  return TRUE;
}

RendParamDlg *hydraRender_mk3::CreateParamDialog(IRendParams *ir,BOOL prog)
{
  return new HydraRenderParamDlg(this, ir, prog);
}


void FixValueXML(TiXmlElement* root, const std::string& fieldName, const std::string& fieldValue)
{
  TiXmlElement* res = root->FirstChildElement(fieldName);
  if(res!=NULL)
  {
    TiXmlNode* data = res->FirstChild();
    if(data!=NULL)
      data->SetValue(fieldValue);
  }
  else
    MessageBoxA(NULL, fieldName.c_str(), "xml parameter not found", 0);
}

int GetIntValueXML(TiXmlElement* node, const std::string& fieldName)
{
  TiXmlElement* leaf = node->FirstChildElement(fieldName);
  if(leaf == NULL)
    return 0;

  return atoi(leaf->GetText());
}

float GetFloatValueXML(TiXmlElement* node, const std::string& fieldName)
{
  TiXmlElement* leaf = node->FirstChildElement(fieldName);
  if(leaf == NULL)
    return 0.0f;

  return atof(leaf->GetText());
}


static const int kRendRollupWidth = 222;
//static const Class_ID blurRaytrace ( 0x4fa95e9b, 0x9a26e66 );


BaseInterface* hydraRender_mk3::GetInterface ( Interface_ID id )
{
   if ( id == TAB_DIALOG_OBJECT_INTERFACE_ID ) {
      ITabDialogObject* r = this;
      return r;
   }
   else {
      return Renderer::GetInterface ( id );
   }
}

// ITabDialogObject
// Add the pages you want to the dialog. Use tab as the plugin
// associated with the pages. This will allows the manager
// to remove and add the correct pages to the dialog.
void hydraRender_mk3::AddTabToDialog ( ITabbedDialog* dialog, ITabDialogPluginTab* tab )
{
   dialog->AddRollout ( GetString( IDS_CLASS_NAME ), NULL,
      kTabClassID, tab, -1, kRendRollupWidth, 0,
      0, ITabbedDialog::kSystemPage );
}

int hydraRender_mk3::AcceptTab ( ITabDialogPluginTab* tab )
{
	switch(tab->GetSuperClassID()) 
	{
		case RADIOSITY_CLASS_ID:
			return 0;              
  }

  Class_ID id = tab->GetClassID();
  if (id == hydraRender_mk3_CLASS_ID)
		return TAB_DIALOG_ADD_TAB;
	else
		return 0;
	/*switch ( tab->GetSuperClassID ( ) ) {
   case RADIOSITY_CLASS_ID:
      return 0;         // Don't show the advanced lighting tab
   }

   Class_ID id = tab->GetClassID ( );
   if ( id == blurRaytrace )
      return 0;         // Don't show the blur raytracer tab

   // Accept all other tabs
   return TAB_DIALOG_ADD_TAB;*/
}