#include "hydraRender mk3.h"
#include <hash_map>

#include <genlight.h>
#include <lslights.h>
#include <icustattribcontainer.h>
#include <mentalray/imrSkyPortalLight.h>
#include <INodeMentalRayProperties.h>

void hydraRender_mk3::ExportLightsXML(std::ofstream& xmlFile, const std::vector<LightObj> &lights)
{
  Matrix3 mConv;
  mConv = getConversionMatrix();

  std::string lhashPath = "C:\\[Hydra]\\pluginFiles\\lhash.dat";
  std::ofstream lightHashData(lhashPath.c_str(), std::ios::binary | std::ios::trunc);

  xmlFile << "<library_lights>\n";

  for(size_t i=0;i<lights.size();i++)
  {
    const LightObj& light = lights[i];

    if(!light.on && (light.lightType == L"SKY_PORTAL" || light.lightType == L"SKY"))
      continue;

    xmlFile << std::endl;
    xmlFile << "  <light name = \"" << ToNarrowString(light.lightName).c_str() << "\"> " << std::endl;
    
    xmlFile << std::endl;
    xmlFile << "    <general>" << std::endl;
    xmlFile << "      <type> ";

    if(light.lightType == L"OMNI")
      xmlFile << "Point";
    else if(light.lightType == L"DIR" || light.lightType == L"TDIR")
      xmlFile << "Directional";
    else if(light.lightType == L"SPOT" || light.lightType == L"TSPOT")
      xmlFile << "Spot";
    else if(light.lightType == L"AREA")
      xmlFile << "Plane";
    else if(light.lightType == L"DISK")
      xmlFile << "Disk";
    else if(light.lightType == L"SPHERE")
      xmlFile << "Sphere";
    else if(light.lightType == L"SKY")
      xmlFile << "Sky";
    else if(light.lightType == L"SKY_PORTAL")
      xmlFile << "Plane";
    else
      xmlFile << "Point";
    
    xmlFile << " </type>" << std::endl;
   

    if(light.lightType == L"AREA" || light.lightType == L"DISK" || light.lightType == L"SPHERE" || light.lightType == L"OMNI" || light.lightType == L"SKY_PORTAL")
    {
      std::string raySetFile = "thisWillBeAFile.ies";
      if(light.lightDitributionType == LightObj::LD_RAYSET)
        xmlFile << "      <distribution file = '" << raySetFile.c_str() << "'> ";
      else
        xmlFile << "      <distribution> ";

      if(light.lightDitributionType == LightObj::LD_UNIFORM)
        xmlFile << "uniform";
      else if(light.lightDitributionType == LightObj::LD_DIFFUSE)
        xmlFile << "diffuse";
      else if(light.lightDitributionType == LightObj::LD_SPOT)
        xmlFile << "spot";
      else if(light.lightDitributionType == LightObj::LD_RAYSET)
        xmlFile << "rayset";

      xmlFile << " </distribution> " << std::endl; 
    }


    xmlFile << "      <disable> ";

    if(!light.on)
      xmlFile << "1";
    else
      xmlFile << "0";
    xmlFile << " </disable> " << std::endl;

    if(!light.computeShadow)
      xmlFile << "      <noshadow> 1 </noshadow> " << std::endl;

    if(!light.isVisiable)
      xmlFile << "      <hideLightGeometry> 1 </hideLightGeometry> " << std::endl;

    lightHashData << light.isVisiable;

    if(light.lightType == L"SKY_PORTAL")
    {
      xmlFile << "      <sky_portal> 1 </sky_portal> " << std::endl;
      xmlFile << "      <sky_portal_source> " << ToNarrowString(light.skyPortalEnvMode)   <<  " </sky_portal_source> " << std::endl;
      xmlFile << "      <sky_portal_tex> "    << ToNarrowString(light.skyPortalEnvTex)    <<  " </sky_portal_tex> " << std::endl;
			xmlFile << light.skyPortalEnvTexSampler;
      lightHashData << light.isVisiable;  // must reconstruct BVH when hide or switch off sky portals
    }

    if(light.causticLight)
      xmlFile << "      <causticlight> 1 </causticlight> " << std::endl;

    xmlFile << "    </general>" << std::endl;

    Matrix3 lightTransform, lightTransformT;

    lightTransform  = Float16ToMaxMatrix3(light.m);
    lightTransformT = Float16ToMaxMatrix3(light.targetMatrix);

    Point3 pos, target, dir;

    pos    = mConv*(lightTransform*Point3(0,0,0));                                
    target = mConv*(lightTransformT*Point3(0,0,0));
    dir    = mConv*Point3(light.direction[0], light.direction[1], light.direction[2]).Normalize();

    if(light.isTargeted)
      dir = (target - pos).Normalize();


    float sizeX = light.sizeX;
    float sizeY = light.sizeY;

    float scaleIntensity = 1.0f;
    if(light.lightType == L"AREA" || light.lightType == L"SPHERE" ||  light.lightType == L"DISK" || light.lightType == L"SKY_PORTAL")
    {
      lightTransform.SetRow(3, Point3(0,0,0)); // kill translate

      float kf = scaleWithMatrix(1.0f, lightTransform);
      scaleIntensity = 1.0f/(kf*kf); 

      if(light.lightType == L"SPHERE")
      {
        sizeX = scaleWithMatrix(sizeX, lightTransform);
      
        lightHashData << pos.x << pos.y << pos.z << sizeX;
      }
      else if (light.lightType == L"AREA" || light.lightType == L"DISK" || light.lightType == L"SKY_PORTAL")
      {
        Matrix3 swapAxis;
        swapAxis.SetRow(0, Point3(1,0,0));
        swapAxis.SetRow(1, Point3(0,0,-1));
        swapAxis.SetRow(2, Point3(0,1,0));

        Matrix3 swapAxisInv;
        swapAxisInv.SetRow(0, Point3(1,0,0));
        swapAxisInv.SetRow(1, Point3(0,0,1));
        swapAxisInv.SetRow(2, Point3(0,-1,0));

        Matrix3 matrixLight2;
        matrixLight2 = swapAxisInv*lightTransform*swapAxis;

        dir = ((-1.0f)*matrixLight2.GetRow(1)).Normalize();

        xmlFile << std::endl;
        xmlFile << "    <matrix_rot> " << std::endl;
        xmlFile << "      " << matrixLight2.GetColumn(0).x << " " << matrixLight2.GetColumn(0).y << " " << matrixLight2.GetColumn(0).z << std::endl;
        xmlFile << "      " << matrixLight2.GetColumn(1).x << " " << matrixLight2.GetColumn(1).y << " " << matrixLight2.GetColumn(1).z << std::endl;
        xmlFile << "      " << matrixLight2.GetColumn(2).x << " " << matrixLight2.GetColumn(2).y << " " << matrixLight2.GetColumn(2).z << std::endl;
        xmlFile << "    </matrix_rot> " << std::endl;

        if(light.isVisiable)
        {
          lightHashData << pos.x << pos.y << pos.z << sizeX << sizeY;
          lightHashData << dir.x << dir.y << dir.z;

          lightHashData << matrixLight2.GetColumn(0).x << matrixLight2.GetColumn(0).y << matrixLight2.GetColumn(0).z << std::endl;
          lightHashData << matrixLight2.GetColumn(1).x << matrixLight2.GetColumn(1).y << matrixLight2.GetColumn(1).z << std::endl;
          lightHashData << matrixLight2.GetColumn(2).x << matrixLight2.GetColumn(2).y << matrixLight2.GetColumn(2).z << std::endl;
        }
      }


    }


    xmlFile << std::endl;
    xmlFile << "    <position> " << pos.x << " " << pos.y << " " << pos.z << " </position>" << std::endl;
    
    if(light.lightType != L"SPHERE" && light.lightType != L"POINT")
      xmlFile << "    <direction> " << dir.x << " " << dir.y << " " << dir.z << " </direction>" << std::endl;


    if(light.lightType == L"AREA" || light.lightType == L"SKY_PORTAL")
    {
      xmlFile << std::endl;
      xmlFile << "    <size>" << std::endl;
      xmlFile << "      <Half-length> " << sizeX << " </Half-length> " << std::endl;
      xmlFile << "      <Half-width> "  << sizeY << " </Half-width> " << std::endl;
      xmlFile << "    </size>" << std::endl;
    }
    else if(light.lightType == L"SPHERE" || light.lightType == L"DISK")
    {
      xmlFile << std::endl;
      xmlFile << "    <size>" << std::endl;
      xmlFile << "      <radius> " << sizeX << " </radius> " << std::endl;
      xmlFile << "    </size>" << std::endl;
    }
    else if(light.lightType == L"DIR" || light.lightType == L"TDIR")
    {
      xmlFile << std::endl;
      xmlFile << "    <size>" << std::endl;
      xmlFile << "      <inner_radius> " << toMeters(light.hotsize) << " </inner_radius> " << std::endl;
      xmlFile << "      <outer_radius> " << toMeters(light.fallsize) << " </outer_radius> " << std::endl;
      xmlFile << "    </size>" << std::endl;
    }

    if(false)
    {
      xmlFile << std::endl;
      xmlFile << "    <matrix> " << std::endl;
      for(int k=0;k<4;k++)
      {
        for(int j=0;j<4;j++)
          xmlFile << "      " << light.m[j*4+k] << " "; // transpose dmatrix ?
        xmlFile << std::endl;
      }
      xmlFile << "    </matrix> " << std::endl;

      xmlFile << std::endl;
      xmlFile << "    <target_matrix> " << std::endl;
      for(int k=0;k<4;k++)
      {
        for(int j=0;j<4;j++)
          xmlFile << "      " << light.targetMatrix[j*4+k] << " "; // transpose dmatrix ?
        xmlFile << std::endl;
      }
      xmlFile << "    </target_matrix> " << std::endl;
    }


    xmlFile << std::endl;
    xmlFile << "    <intensity> " << std::endl; 
    xmlFile << "      <color> " << light.color[0] << " " << light.color[1] << " " << light.color[2] << " </color> " << std::endl;
    xmlFile << "      <multiplier> " << scaleIntensity*light.intensity*light.envTexAmt << " </multiplier> " << std::endl;
    xmlFile << "    </intensity> " << std::endl; 

    if(light.lightType == L"SKY" && light.envTexturePath != L"")
    {
      xmlFile << std::endl;
      xmlFile << "    <spheremap> " << std::endl;
      xmlFile << "      <surface> " << ToNarrowString(light.envTexturePath) << " </surface> " << std::endl;
			xmlFile << light.envTextureSampler;
      xmlFile << "    </spheremap> " << std::endl;
    }

    if(light.lightType == L"SKY" && light.useSeparateDiffuseLight)
    {
      xmlFile << std::endl;
      xmlFile << "    <spheremap_diffuse> " << std::endl;
      xmlFile << "      <color> " << light.colorSecondary[0] << " " << light.colorSecondary[1] << " " << light.colorSecondary[2] << " </color> " << std::endl; 
      xmlFile << "      <surface> " << ToNarrowString(light.envTexturePathSecondary) << " </surface> " << std::endl;
			xmlFile << light.envTextureSamplerSecondary;
      xmlFile << "    </spheremap_diffuse> " << std::endl;
    }

    if(light.lightType == L"SPOT" || light.lightType == L"TSPOT" || light.lightDitributionType == LightObj::LD_SPOT)
    {
      xmlFile << std::endl;
      xmlFile << "    <falloff_angle> " << light.fallsize  << " </falloff_angle> "  << std::endl;
      xmlFile << "    <falloff_angle2> " << light.hotsize  << " </falloff_angle2> "  << std::endl;
    }

    xmlFile << std::endl;
    xmlFile << "    <constant_attenuation>"  << light.kc << "</constant_attenuation>"  << std::endl;
    xmlFile << "    <linear_attenuation>"    << light.kl << "</linear_attenuation>"    << std::endl;
    xmlFile << "    <quadratic_attenuation>" << light.kq << "</quadratic_attenuation>" << std::endl;

    if(light.mrDisablePhotonsD || light.mrDisablePhotonsC)
    {
      xmlFile << std::endl;
      xmlFile << "    <mrDisablePhotonsGI>"       << int(light.mrDisablePhotonsD) << "</mrDisablePhotonsGI>"  << std::endl;
      xmlFile << "    <mrDisablePhotonsCaustic>"  << int(light.mrDisablePhotonsC) << "</mrDisablePhotonsCaustic>"    << std::endl;
    }

    xmlFile << std::endl;
    xmlFile << "  </light>" << std::endl;
  }
  

  xmlFile << "</library_lights>\n";

  lightHashData.close();

  hashwrapper *h = new md5wrapper();
	this->lightsMD5 = h->getHashFromFile(lhashPath);
	delete h;

}

bool IsThisFuckingMentalRayLightVisible(LightObject* light, TimeValue t, Interval valid)
{
  bool isVisiable = true;

  LightscapeLight* pMRLight = (LightscapeLight*)light;
  ICustAttribContainer* pAttribs = light->GetCustAttribContainer();

  if(pAttribs!=NULL)
  {
    int n = pAttribs->GetNumCustAttribs();
    for(int i=0;i<n;i++)
    {
      CustAttrib* pAttr = pAttribs->GetCustAttrib(i);
      if(pAttr!=NULL)
      { 
        std::wstring name = pAttr->GetName();
        if(name.find(L"Area Light Sampling Custom Attribute") != std::wstring::npos)
        {
          LightscapeLight::AreaLightCustAttrib* pAreaCustomAttribs = pMRLight->GetAreaLightCustAttrib(pAttr);
          isVisiable = pAreaCustomAttribs->IsLightShapeRenderingEnabled(t, &valid);
        }
      }
    }
  }

  return isVisiable;
}



void hydraRender_mk3::ExtractLightObject(INode* node, LightObj* li, TimeValue t)
{

  ObjectState os = node->EvalWorldState(t);
  if (!os.obj) 
    return;

  LightObject* light = (LightObject*)(os.obj); 
  li->lightName = node->GetName();

  struct LightState ls;
  Interval valid = FOREVER;


  light->EvalLightState(t, valid, &ls);

  li->lightType = L"OMNI";

  switch(ls.type) 
  {
  case OMNI_LGT:
    li->lightType = L"OMNI";
    break;

  case DIRECT_LGT:
  case TDIR_LIGHT:
    li->lightType = L"DIR";
    break;

  case FSPOT_LIGHT:
  case SPOT_LGT:

    li->lightType = L"SPOT";
    break;

  default:
    li->lightType = L"EXTRA";
    break;
  }



  bool isTargeted = false;
  bool isExtra    = false;

  // extra class ID from the samples (systems/sunlight/natLight.cpp)
  //
  {
    const ULONG SKY_LIGHT_CLASS_ID_PART_A = 0x7bf61478;

    const unsigned int PB_SKY_COLOR = 0;
    const unsigned int PB_SKY_SKY_COLOR_MAP_AMOUNT = 1;
    const unsigned int PB_SKY_COLOR_MAP = 2; // TYPE_TEXMAP
    const unsigned int PB_SKY_SKY_COLOR_MAP_ON = 3;

    ULONG classId = light->ClassID().PartA();
    GenLight* glight = (GenLight*)(light);

    bool isSpot        = false;
    bool isDirectional = false;
    bool isPoint       = false;
    bool isSky         = false;

    switch (classId)
    {
    case FSPOT_LIGHT_CLASS_ID:
    case SPOT_LIGHT_CLASS_ID: 
      isSpot = true; 
      break;

    case DIR_LIGHT_CLASS_ID: 
    case TDIR_LIGHT_CLASS_ID: 
      isDirectional = true; 
      break;

    case SKY_LIGHT_CLASS_ID_PART_A:
      isSky = true;
      li->lightType = L"SKY";
      break;

    case OMNI_LIGHT_CLASS_ID:
      isPoint = true;
      break;

    default:
      isExtra = true;
      break;
    }

    
    // Export light settings for frame 0
    ExtractLightSettings(&ls, light, t, li, isExtra);

    if(isSpot || isDirectional || isPoint)
      li->directLightStart = glight->GetDecayRadius(0);

    isTargeted = (classId == SPOT_LIGHT_CLASS_ID || classId == TDIR_LIGHT_CLASS_ID);

    if(isSky)
    {
      li->colorSecondary[0] = li->color[0]*li->intensity; 
      li->colorSecondary[1] = li->color[1]*li->intensity;
      li->colorSecondary[2] = li->color[2]*li->intensity;

      const unsigned int PBLOCK_REF = 0;		 // This is a IParamBlock
      const unsigned int PBLOCK_REF_SKY = 0; // This is a IParamBlock2

      IParamBlock2* parametersSky = (IParamBlock2*)( light->GetReference(PBLOCK_REF_SKY) );

      if(parametersSky != NULL)
      {
				Texmap* colorMap        = FindTex(L"Sky Color Map", light);
        float  texAmt           = FindFloat(L"Sky Color Map Amt", light); 
        int useSeparateSkyLight = FindInt(L"Skylight Mode", light); 
        bool useMap             = FindBool(L"Sky Color Map On", light);

        li->colorSecondary[0] *= (texAmt / 100.0f);
        li->colorSecondary[1] *= (texAmt / 100.0f);
        li->colorSecondary[2] *= (texAmt / 100.0f);

        li->useSeparateDiffuseLight = bool(useSeparateSkyLight);

        if (useMap && colorMap != NULL && colorMap != NULL && colorMap->ClassID() == Class_ID(BMTEX_CLASS_ID, 0x00))
        {

          BitmapTex* pBitMapTex = dynamic_cast<BitmapTex*>(colorMap);
          if(pBitMapTex!=NULL && useMap)
          {
            TSTR mapName = pBitMapTex->GetMapName();
            li->envTexturePathSecondary = mapName;
						if(pBitMapTex->GetUVGen())
							li->envTextureSamplerSecondary = ExportTextureSamplerStr(pBitMapTex->GetUVGen());
          }
        }

      }

    }
  }

  li->isTargeted = isTargeted;
  //if(!li->isTargeted)
  if(true)
  {
    Point3 lightDirPoint = node->GetNodeTM(t).GetRow(2);
    li->direction[0] = -lightDirPoint.x;
    li->direction[1] = -lightDirPoint.y;
    li->direction[2] = -lightDirPoint.z;
  }

  // export light target
  //
  INode* targetNode = isTargeted ? node->GetTarget() : NULL;
  if(targetNode != NULL)
  {
    Matrix3 pivot = toMeters(targetNode->GetObjectTM(GetStaticFrame()));
    MaxMatrix3ToFloat16(pivot, li->targetMatrix);
  }
  li->isTargeted = (targetNode != NULL);

  ExtractNodeTM(node, li, t);

  int shadowMethod = light->GetShadowMethod();
  if(shadowMethod == LIGHTSHADOW_NONE)
    li->shadowType = L"NONE";
  else if(shadowMethod == LIGHTSHADOW_MAPPED) 
    li->shadowType = L"SHADOW_MAP";
  else
    li->shadowType = L"SHADOW_RAY";

  li->useGlobal  = light->GetUseGlobal();
  li->absMapBias = light->GetAbsMapBias();
  li->overshoot  = light->GetOvershoot();

  if(IsPhotometricMentalRayLight(light))
  {
    li->causticLight = FindBool(L"Ambient Only", light); // this is temporary hax :) We need to move this checkbox some-where else

    LightscapeLight* pMRLight = (LightscapeLight*)light;
 
    float intensityCd = pMRLight->GetResultingIntensity(t, valid); //pMRLight->GetOriginalIntensity(); //pMRLight->GetResultingIntensity(t, valid);
    float sizeX       = toMeters(pMRLight->GetLength(t, valid));
    float sizeY       = toMeters(pMRLight->GetWidth(t, valid));

    float sphereRadius = toMeters(pMRLight->GetRadius(t, valid));

    LightscapeLight::DistTypes lightDistributionType = pMRLight->GetDistribution(); 

    li->isVisiable = IsThisFuckingMentalRayLightVisible(light, t, valid);
    li->kc = 0.0f;
    li->kl = 0.0f;
    li->kq = 1.0f;

    intensityCd *= GetGlobalLightScale(); // magic mental ray scale


    switch(pMRLight->Type())
    {
      case  LightscapeLight::TARGET_POINT_TYPE:
      case  LightscapeLight::POINT_TYPE:

        li->intensity = intensityCd; // because using half sizes 
        li->lightType = L"POINT";
        li->sizeX     = 1.0f;
        li->sizeY     = 1.0f;

        if(lightDistributionType == LightscapeLight::DistTypes::SPOTLIGHT_DIST)
        {
          li->lightType = L"SPOT";
          li->lightDitributionType = LightObj::LD_SPOT;
          li->intensity = intensityCd; 
        }
        else
          li->lightDitributionType = LightObj::LD_UNIFORM;

      break;

      case  LightscapeLight::TARGET_SPHERE_TYPE:
      case  LightscapeLight::SPHERE_TYPE:

        li->intensity = intensityCd*(1.0f/(PI*sphereRadius*sphereRadius)); // because using half sizes 
        li->lightType = L"SPHERE";
        li->sizeX     = sphereRadius;
        li->sizeY     = sphereRadius;
        li->lightDitributionType = LightObj::LD_UNIFORM;
      
      break;

   
      case LightscapeLight::TARGET_DISC_TYPE:  
      case LightscapeLight::DISC_TYPE:

        li->intensity = intensityCd*(1.0f/(PI*sphereRadius*sphereRadius)); // because using half sizes 
        li->lightType = L"DISK";
        li->sizeX     = sphereRadius;
        li->sizeY     = sphereRadius;
        
        if(lightDistributionType == LightscapeLight::DistTypes::SPOTLIGHT_DIST)
          li->lightDitributionType = LightObj::LD_SPOT;
        else
          li->lightDitributionType = LightObj::LD_DIFFUSE;

      break;

      case LightscapeLight::TARGET_AREA_TYPE:
      case LightscapeLight::AREA_TYPE:

        li->intensity = intensityCd*(1.0f/(sizeX*sizeY)); // because using half sizes 
        li->lightType = L"AREA";
        li->sizeX     = sizeY*0.5;
        li->sizeY     = sizeX*0.5;

        if(lightDistributionType == LightscapeLight::DistTypes::SPOTLIGHT_DIST)
          li->lightDitributionType = LightObj::LD_SPOT;
        else
          li->lightDitributionType = LightObj::LD_DIFFUSE;

      break;
      

      default:
        
        li->intensity = intensityCd*(5.0f/GetGlobalLightScale()); // because using half sizes 
        li->lightType = L"POINT";
        li->sizeX     = 1.0f;
        li->sizeY     = 1.0f;
        li->lightDitributionType = LightObj::LD_UNIFORM;

      break;

    }

    
  }
  else if(IsMrSkyPortal(light))
  {
     BaseInterface* bi = light->GetInterface(IID_MR_SKY_PORTAL_LIGHT);
     IMrSkyPortalLight* mrSkyPortal = dynamic_cast<IMrSkyPortalLight*>(bi);

     li->lightType = L"SKY_PORTAL";
     li->intensity = mrSkyPortal->GetMultiplier(t, valid);
     li->lightDitributionType = LightObj::LD_UNIFORM;

     li->sizeY = 0.5f*toMeters(mrSkyPortal->GetLength(t, valid));
     li->sizeX = 0.5f*toMeters(mrSkyPortal->GetWidth(t, valid));

     li->isVisiable = mrSkyPortal->GetVisibleInRendering(t, valid);

     li->skyPortalEnvMode = L"environment";

     int mode = FindInt(L"Mode", light);

     if(mode == 2)
     {
       li->skyPortalEnvMode = L"skylight";
     }
     else if(mode == 1)
     {
       Texmap* pCustomMap = mrSkyPortal->GetIlluminationMap();	
       BitmapTex* pBitMapTex = dynamic_cast<BitmapTex*>(pCustomMap);

       if(pBitMapTex != NULL)
       {
         li->skyPortalEnvMode = L"custom";
         li->skyPortalEnvTex  = pBitMapTex->GetMapName();
				 if(pBitMapTex->GetUVGen())
					li->skyPortalEnvTexSampler = ExportTextureSamplerStr(pBitMapTex->GetUVGen());
       }
       else
         li->skyPortalEnvMode = L"self color";
     }

  }

  INodeMentalRayProperties* mrProperties = INodeMentalRayProperties::Get_INodeMentalRayProperties(*node);

  if(mrProperties != NULL)
  {
    li->mrDisablePhotonsD = mrProperties->MRGetExcludeGlobalIllum();
    li->mrDisablePhotonsC = mrProperties->MRGetExcludeCaustics();
  }

  // export custom plugin lights parameters
  //
  //TraceNodeCustomProperties(li->lightName, light, 1);

}

void hydraRender_mk3::ExtractLightSettings(LightState* ls, LightObject* light, TimeValue t, LightObj* li, bool isExtra)
{
  li->color[0]  = ls->color.r;
  li->color[1]  = ls->color.g;
  li->color[2]  = ls->color.b;
  li->intensity = ls->intens;
  li->aspect    = ls->aspect;

  li->hotsize  = ls->hotsize;
  li->fallsize = ls->fallsize;

  li->attenStart = ls->attenStart;
  li->attenEnd   = ls->attenEnd;


  li->TDist    = light->GetTDist(t, FOREVER);
  li->mapBias  = light->GetMapBias(t, FOREVER);
  li->mapRange = light->GetMapRange(t, FOREVER);
  li->mapSize  = light->GetMapSize(t, FOREVER);
  li->rayBias  = light->GetRayBias(t, FOREVER);

  li->on = ls->on;
  li->computeShadow = ls->shadow;
  
  GenLight* pLightObject2 = dynamic_cast<GenLight*>(light);
 
  if(pLightObject2 != NULL)
  {
    //m_paramTrace << "pLightObject2->GetDecayType() = " << pLightObject2->GetDecayType() << std::endl;
    
    int decayFunction = pLightObject2->GetDecayType();
    switch (decayFunction)
    {
    case 1:
      li->kc = 0.0f;
      li->kl = 1.0f;
      li->kq = 0.0f;
      break;

    case 2:
      li->kc = 0.0f;
      li->kl = 0.0f;
      li->kq = 1.0f;
      break;

    case 0:
      li->kc = 1.0f;
      li->kl = 0.0f;
      li->kq = 0.0f;

    default:
      li->kc = 1.0f;
      li->kl = 0.0f;
      li->kq = 0.0f;
      break;
    }
    
  }


}


bool hydraRender_mk3::IsPhotometricMentalRayLight(LightObject* a_light)
{
  return a_light->IsSubClassOf(LIGHTSCAPE_LIGHT_CLASS);
}

bool hydraRender_mk3::IsMrSkyPortal(LightObject* a_light)
{ 
   BaseInterface* bi = a_light->GetInterface(IID_MR_SKY_PORTAL_LIGHT);
   IMrSkyPortalLight* mrSkyPortal = dynamic_cast<IMrSkyPortalLight*>(bi);
   if(mrSkyPortal!=NULL)
     return true;
   return false;
}

IParamBlock2* hydraRender_mk3::FindBlockOfParameter(const std::wstring& a_paramName, ReferenceTarget* a_node)
{
  for (unsigned int i = 0; i < a_node->NumRefs(); ++i) 
  {
    ReferenceTarget *pObjRef = a_node->GetReference(i);
    if (!pObjRef)
      continue;

    if(pObjRef->SuperClassID() == PARAMETER_BLOCK2_CLASS_ID) 
    {
      IParamBlock2* foundBlock = FindBlockOfParameter(a_paramName, (IParamBlock2 *)pObjRef);
      if(foundBlock!=NULL)
        return foundBlock;
    }
  }

  return NULL;
}


IParamBlock2* hydraRender_mk3::FindBlockOfParameter(const std::wstring& a_paramName, IParamBlock2* pBlock)
{
  if(pBlock == NULL)
    return NULL;

  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid        = pBlock->IndextoID(p);    
    MSTR paramName     = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    if(std::wstring(strData) == a_paramName)
      return pBlock;

    ParamType2 typeId = pBlock->GetParameterType(pid);

    if(typeId == TYPE_PBLOCK2)
    {
      IParamBlock2* internalNode = pBlock->GetParamBlock2(pid);
      IParamBlock2* result = FindBlockOfParameter(a_paramName, internalNode);
      if(result != NULL)
        return result;
    }
  }

  return NULL;
}

float hydraRender_mk3::FindFloat(const std::wstring& a_paramName, ReferenceTarget* a_light)
{
  IParamBlock2* pBlock = FindBlockOfParameter(a_paramName, a_light);
  if(pBlock == NULL)
    return 0.0f;

  // must check that we do have this parameter with float type
  //
  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    if(std::wstring(strData) == a_paramName)
    {
      ParamType2 typeId = pBlock->GetParameterType(pid);

      switch(typeId) 
      {
      case TYPE_ANGLE:
      case TYPE_PCNT_FRAC:
      case TYPE_WORLD:
      case TYPE_FLOAT:
        return pBlock->GetFloat(pid);
        break;

      default:
        //return 0.0f;
        break;
      };
    }
  }

  return 0.0f;
}

Color hydraRender_mk3::FindColor(const std::wstring& a_paramName, ReferenceTarget* a_light)
{
  IParamBlock2* pBlock = FindBlockOfParameter(a_paramName, a_light);
  if(pBlock == NULL)
    return Color(0, 0, 0);

  // must check that we do have this parameter with float type
  //
  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    if(std::wstring(strData) == a_paramName)
    {
      ParamType2 typeId = pBlock->GetParameterType(pid);

      switch(typeId) 
      {
      case TYPE_RGBA:
        return pBlock->GetColor(pid);
        break;

      default:
        return Color(0, 0, 0);
        break;
      };
    }
  }

  return Color(0, 0, 0);
}

int hydraRender_mk3::FindInt(const std::wstring& a_paramName, ReferenceTarget* a_light)
{
  IParamBlock2* pBlock = FindBlockOfParameter(a_paramName, a_light);
  if(pBlock == NULL)
    return 0;

  // must check that we do have this parameter with float type
  //
  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    if(std::wstring(strData) == a_paramName)
    {
      ParamType2 typeId = pBlock->GetParameterType(pid);

      switch(typeId) 
      {
      case TYPE_INT:
        return pBlock->GetInt(pid);
        break;

      default:
        return 0;
        break;
      };
    }
  }

  return 0;
}

Texmap* hydraRender_mk3::FindTex(const std::wstring& a_paramName, ReferenceTarget* a_light)
{
  IParamBlock2* pBlock = FindBlockOfParameter(a_paramName, a_light);
  if(pBlock == NULL)
    return 0;

  // must check that we do have this parameter with float type
  //
  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    if(std::wstring(strData) == a_paramName)
    {
      ParamType2 typeId = pBlock->GetParameterType(pid);

      switch(typeId) 
      {
      case TYPE_TEXMAP:
        return pBlock->GetTexmap(pid);
        break;

      default:
        return 0;
        break;
      };
    }
  }

  return 0;
}

bool hydraRender_mk3::FindBool(const std::wstring& a_paramName, ReferenceTarget* a_light)
{
  IParamBlock2* pBlock = FindBlockOfParameter(a_paramName, a_light);
  if(pBlock == NULL)
    return 0.0f;

  // must check that we do have this parameter with bool type
  //
  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    if(std::wstring(strData) == a_paramName)
    {
      ParamType2 typeId = pBlock->GetParameterType(pid);

      switch(typeId) 
      {
      case TYPE_BOOL:
        return bool(pBlock->GetInt(pid));
        break;

      default:
        return false;
        break;
      };
    }
  }

  return false;
}


void hydraRender_mk3::TraceNodeCustomProperties(const std::wstring& a_objectName, ReferenceTarget* a_node, int deep)
{
  unsigned int uNumReferences = a_node->NumRefs();

  if (uNumReferences == 0)
    return;

  m_paramTrace << a_objectName.c_str() << L" is " << std::endl;

  for (unsigned int i = 0; i < uNumReferences; ++i) 
  {
    ReferenceTarget *pObjRef = a_node->GetReference(i);

    if (!pObjRef)
      continue;

    ULONG classID1 = pObjRef->SuperClassID();

    if(classID1 == PARAMETER_BLOCK2_CLASS_ID) 
    {
			m_paramTrace << "ClassID : " << pObjRef->ClassID().PartA() << " : " << pObjRef->ClassID().PartB() << std::endl;
			m_paramTrace << "SClassID : " << classID1 << std::endl;
      m_paramTrace << "GetReference(" << i << ")[IParamBlock2] = { " << std::endl;
      TraceIParamBlock2(a_objectName, (IParamBlock2 *)pObjRef, deep);
      m_paramTrace << "} " << std::endl;
    }
    else //if(classID1 == CUST_ATTRIB_CLASS_ID)
    {
      MSTR className;
      pObjRef->GetClassName(className);

      m_paramTrace << "unknown className =" << ToNarrowString(className.data()).c_str() << std::endl;
      //m_paramTrace << "CustomAttrib ???? (" << i << ") = { " << std::endl;
      //ICustAttribContainer* pAttribs = pBlock->GetCustAttribContainer();
      //m_paramTrace << "} " << std::endl;
    }
  }

  m_paramTrace << L"end " << a_objectName.c_str() << std::endl;

}


void hydraRender_mk3::TraceIParamBlock2(const std::wstring& a_objectName, IParamBlock2* pBlock, int deep)
{
  if(pBlock == NULL)
    return;

  ParamBlockDesc2 *desc = pBlock->GetDesc();
  unsigned int uNumParams  = desc->Count();
  unsigned int uNumParams2 = pBlock->NumParams();

  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = pBlock->IndextoID(p);    
    //ParamDef& paramDef = pBlock->GetParamDef(pid);

    Interval valid = FOREVER;

    Color col;
    AColor acol;

    MSTR paramName  = pBlock->GetLocalName(pid); 
    const wchar_t* strData = paramName.data();

    for(int i=0;i<deep;i++)
      m_paramTrace << L"  ";
    m_paramTrace << strData;

    ParamType2 typeId = pBlock->GetParameterType(pid);
    switch(typeId) 
    {
    case TYPE_ANGLE:
    case TYPE_PCNT_FRAC:
    case TYPE_WORLD:
    case TYPE_FLOAT:
      m_paramTrace << L"\t\t: float   = " << pBlock->GetFloat(pid) << std::endl;
      break;

    case TYPE_TIMEVALUE:
    case TYPE_INT:
      m_paramTrace << L"\t\t: integer = " << pBlock->GetInt(pid) << std::endl;
      break;

    case TYPE_BOOL:
      m_paramTrace << L"\t\t: boolean = " << pBlock->GetInt(pid) << std::endl;
      break;

    case TYPE_FILENAME:
    case TYPE_STRING:
      {
        const wchar_t* pstrdata = pBlock->GetStr(pid);
        if(pstrdata == NULL)
          pstrdata = L"";
        m_paramTrace << L"\t\t: string  = "  << pstrdata << std::endl;
      }
      break;

    case TYPE_RGBA:
      col = pBlock->GetColor(pid);
      m_paramTrace << L"\t\t: color   = "  << col.r << col.g << col.b << std::endl;
      break;

    case TYPE_FRGBA:
      acol = pBlock->GetAColor(pid);
      m_paramTrace << L"\t\t: colorf  = "  << acol.r << acol.g << acol.b << std::endl;
      break;

    case TYPE_PBLOCK2:
      {
        IParamBlock2* internalNode = pBlock->GetParamBlock2(pid);
        m_paramTrace << L"\t\t: IParamBlock2";
        TraceIParamBlock2(L"", internalNode, deep+1);
      }
      break;

    case TYPE_REFTARG:
      {
        INode* node = pBlock->GetINode(pid);
        ReferenceTarget* pRefTarget = pBlock->GetReferenceTarget(pid);
        IParamBlock2* node2 = pBlock->GetParamBlock2(pid);

        //ULONG classID1 = pObjRef->SuperClassID();

        unsigned int uNumReferences = pBlock->NumRefs();

        if(node != NULL)
        {
          m_paramTrace << L"\t\t: INode(geometry) " << std::endl;
        }
        else if(pRefTarget != NULL )
        { 
          ULONG classId1 = pRefTarget->SuperClassID();
          ULONG classId2 = pRefTarget->ClassID().PartA();
          m_paramTrace << L"\t\t: TYPE_REFTARG; calsssId = " << classId2;
        }
        else if(node2!=NULL)
        {
          m_paramTrace << L"\t\t: IParamBlock2(TYPE_REFTARG)";
          TraceIParamBlock2(L"", node2, deep+1);
        }
        else
          m_paramTrace << L"\t\t: EmptyRefTarget" << std::endl;

      }
      break;


    default:
      m_paramTrace << " : unknown " << std::endl;
      break;
    }

  }

}


void hydraRender_mk3::TraceIParamBlock(const std::wstring& a_objectName, IParamBlock* pBlock, int deep)
{
  if(pBlock == NULL)
    return;


  for (int p=0; p<pBlock->NumParams(); p++) 
  {
    ParamID pid = p; //pBlock->IndextoID(p);    //  AnimNumToParamNum 	

    Interval valid = FOREVER;

    Color col;
    Point3 acol;

    //MSTR paramName  = pBlock->GetLocalName(pid); 
    //const wchar_t* strData = paramName.data();

    std::wstringstream outStr; outStr << p;
    const wchar_t* strData = (std::wstring(L"parameter ") + outStr.str() + std::wstring(L" ")).c_str(); 

    for(int i=0;i<deep;i++)
      m_paramTrace << L"  ";
    m_paramTrace << strData;

    ParamType typeId = pBlock->GetParameterType(pid);
    switch(typeId) 
    {

    case TYPE_FLOAT:
      m_paramTrace << L"\t\t: float   = " << pBlock->GetFloat(pid) << std::endl;
      break;

    case TYPE_INT:
      m_paramTrace << L"\t\t: integer = " << pBlock->GetInt(pid) << std::endl;
      break;

    case TYPE_BOOL:
      m_paramTrace << L"\t\t: boolean = " << pBlock->GetInt(pid) << std::endl;
      break;

    case TYPE_RGBA:
      col = pBlock->GetColor(pid);
      m_paramTrace << L"\t\t: color   = "  << col.r << col.g << col.b << std::endl;
      break;

    case TYPE_POINT3:
      acol = pBlock->GetPoint3(pid);
      m_paramTrace << L"\t\t: colorf  = "  << acol.x << acol.y << acol.z << std::endl;
      break;

    default:
      m_paramTrace << " : unknown " << std::endl;
      break;
    }

  }

}


LightObj* hydraRender_mk3::FindEnvLight(std::vector<LightObj>& a_lightsArray)
{
  for(size_t i=0; i<a_lightsArray.size();i++)
  {
    if(a_lightsArray[i].lightType == L"SKY")
    {
      a_lightsArray[i].on = true;
      return &(a_lightsArray[i]);
    }
  }

  a_lightsArray.push_back(LightObj());
  LightObj* pEnvLight = &(a_lightsArray[a_lightsArray.size()-1]);

  pEnvLight->lightName = L"MaxEnvironment";
  pEnvLight->lightType = L"SKY";
  pEnvLight->on        = true;
  pEnvLight->intensity = 1.0f;

  return pEnvLight;
}

