#include "hydraRender mk3.h"
#include <hash_map>


#include "../HydraAppLib/HydraNetwork.h" 

struct PluginShmemPipe : public IHydraNetPluginAPI
{
  PluginShmemPipe(const char* imageFileName, const char* messageFileName, const char* guiFile, bool createFiles, int width, int height);
  virtual ~PluginShmemPipe();

  void sendToServer(const char* a_data, unsigned int a_size);
  void waitForAnyServerReply();

  void updatePresets(const char* a_presetsXML);

  int   getImageType() const;
  bool  haveNewImageFromServer();
  
  void* mapImageData();
  void  unmapImageData();
  bool  lastImageWasFinal() const;

  bool  hasConnection() const;

  bool haveAnyMessageFromServer();
  unsigned int recieveFromServer(char* a_data, unsigned int a_maxSize);

  bool  imageWasReadHDR();
  void* mapImageDataHDR();
  void  unmapImageDataHDR();

protected:

  HANDLE m_hFile, m_hImageFile, m_hGuiFile;
  char* m_shmem;
  char* m_imageShmem;
  char* m_guiShmem;

  STARTUPINFOA m_hydraStartupInfo;
  PROCESS_INFORMATION m_hydraProcessInfo;
  bool m_hydraServerStarted;

  unsigned int m_lastImageType;

  enum {MESSAGE_BUFF_SIZE = 1024};

  struct SharedBufferDataInfo* bufferInfo() { return (struct SharedBufferDataInfo*)m_shmem; }
  char* bufferData() { return m_shmem + sizeof(struct SharedBufferDataInfo); }

  struct SharedBufferDataInfo* imageBufferInfo() { return (struct SharedBufferDataInfo*)m_imageShmem; }
  char* imageBufferDara() { return m_imageShmem + sizeof(struct SharedBufferDataInfo); }
};


struct PluginSocketPipe : public IHydraNetPluginAPI
{
  void sendToServer(const char* a_data, unsigned int a_size);
  void updatePresets(const char* a_presetsXML);

  bool  hasConnection() const;

  bool haveAnyMessageFromServer();
  unsigned int recieveFromServer(char* a_data, unsigned int a_maxSize);
  
  bool  haveNewImageFromServer();
  int   getImageType() const;

  void* mapImageData();
  void  unmapImageData();
  bool  lastImageWasFinal() const;

  bool  imageWasReadHDR();
  void* mapImageDataHDR();
  void  unmapImageDataHDR();

protected:

};


IHydraNetPluginAPI* hydraRender_mk3::CreateHydraServerConnection()
{
  IHydraNetPluginAPI* pImpl = NULL;

  int renderWidth  = rendParams.nMaxx - rendParams.nMinx;
  int renderHeight = rendParams.nMaxy - rendParams.nMiny;
 
  
  if(true)
  {
    // if there is a shared memory connection, create shared memory pipe
    //
    HANDLE guiFile   = OpenFileMappingA(FILE_MAP_WRITE | FILE_MAP_READ, false, "HydraGuiShmem");
    HANDLE imageFile = OpenFileMappingA(FILE_MAP_WRITE | FILE_MAP_READ, false, "HydraLDRImage");

    if(guiFile!= NULL)
      CloseHandle(guiFile);

    if(imageFile != NULL)
      CloseHandle(imageFile);

    bool createFiles = !this->rendParams.useHydraGUI; //(guiFile == NULL);
    
    pImpl = new PluginShmemPipe("HydraLDRImage", "HydraMessageShmem", "HydraGuiShmem", createFiles, renderWidth, renderHeight);

    m_paramTrace << "renderWidth  = " << renderWidth  << std::endl;
    m_paramTrace << "renderHeight = " << renderHeight << std::endl;
    m_paramTrace << "renderWidth  = " << createFiles  << std::endl;
  }
  else if(false) // if there is a TCP connection, create socket pipe
  {

  }
  else
  {
   
  }


  if(pImpl->hasConnection())
  {
    return pImpl;
  }
  else
  {
    delete pImpl;
    return NULL;
  }

}

struct SharedBufferInfo2
{
  enum LAST_WRITER { WRITER_HYDRA_GUI = 0, WRITER_HYDRA_SERVER = 1 };

  unsigned int xmlBytesize;
  unsigned int lastWriter;
  unsigned int writerCounter;
  unsigned int dummy;
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool isFileExist(const char *fileName)
{
  std::ifstream infile(fileName);
  return infile.good();
}


const int GUI_FILE_SIZE = 32768;

PluginShmemPipe::PluginShmemPipe(const char* imageFileName, const char* messageFileName, const char* guiFileName, bool createFiles, int width, int height) : m_hydraServerStarted(false)
{
  // for some fucking reason of fucking fuck, the second (!) call to CreateFileMappingA will not allocate bigger size of shmem
  // so, need to allocate enough when first call happened.
  // This is very big piece of shit and it should be debugged. <--  // 64 MB CRAP !!! Fucking Windows fuck fuck fuck!!!
  //

 
  if(createFiles)
  {
    m_hImageFile = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, (width+16)*(height+16)*sizeof(float)*4 + 1024, imageFileName); 
    m_hFile      = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, 1024 + sizeof(int)*4, messageFileName); 
    m_hGuiFile   = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, GUI_FILE_SIZE, guiFileName); 

    //if(m_hImageFile == INVALID_HANDLE_VALUE)
      //MessageBoxA(NULL,"Can't create FileMapping","", MB_OK);
  }
  else
  {
    m_hImageFile = OpenFileMappingA(FILE_MAP_WRITE | FILE_MAP_READ, false, imageFileName);
    m_hFile      = OpenFileMappingA(FILE_MAP_WRITE | FILE_MAP_READ, false, messageFileName);
    m_hGuiFile   = OpenFileMappingA(FILE_MAP_WRITE | FILE_MAP_READ, false, guiFileName);
  }

  m_shmem      = (char*)MapViewOfFile(m_hFile,      FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, 0); 
  m_imageShmem = (char*)MapViewOfFile(m_hImageFile, FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, 0); 
  m_guiShmem   = (char*)MapViewOfFile(m_hGuiFile,   FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, 0);

  // put initial data
  //

  SharedBufferDataInfo* pInfo      = bufferInfo();
  SharedBufferDataInfo* pImageInfo = imageBufferInfo();

  pImageInfo->read    = 1;
  pImageInfo->width   = 0; // write width
  pImageInfo->height  = 0; // write height
  pImageInfo->written = 0;

  if(pInfo->written == HYDRA_SERVER_ID || pInfo->written == HYDRA_PLUGIN_ID)
  {
    memset(bufferData(), 1024, 0);
    pInfo->written == HYDRA_PLUGIN_ID;
    pInfo->read    = 1;
  }

  if(createFiles)
  {  
    SharedBufferInfo2* pInfo2 = (SharedBufferInfo2*)m_guiShmem;

    pInfo2->xmlBytesize   = 0;
    pInfo2->lastWriter    = 0; 
    pInfo2->writerCounter = 0;
    pInfo2->dummy         = 0xFAFAFAFA; // magic end of the structure in the buffer
  }

  ZeroMemory(&m_hydraStartupInfo, sizeof(STARTUPINFOA));
  ZeroMemory(&m_hydraProcessInfo, sizeof(PROCESS_INFORMATION));
  
  m_hydraStartupInfo.cb = sizeof(STARTUPINFO);
  m_hydraStartupInfo.dwFlags     = STARTF_USESHOWWINDOW;
  m_hydraStartupInfo.wShowWindow = SW_SHOWMINNOACTIVE;


  if(!isFileExist("C:\\[Hydra]\\bin\\hydra.exe"))
  {
    m_hydraServerStarted = false;
  }
  else
    m_hydraServerStarted = CreateProcessA("C:\\[Hydra]\\bin\\hydra.exe", NULL, NULL, NULL, FALSE, NULL, NULL, NULL, &m_hydraStartupInfo, &m_hydraProcessInfo);
}

PluginShmemPipe::~PluginShmemPipe()
{
  if(m_hydraServerStarted && m_hydraProcessInfo.hProcess != 0 && m_hydraProcessInfo.hProcess != INVALID_HANDLE_VALUE)
  {
    // ask process for exit

    //TerminateProcess(m_hydraProcessInfo.hProcess, NO_ERROR);
    //ExitProcess(m_hydraProcessInfo.hProcess);
  }

  UnmapViewOfFile(m_hImageFile); CloseHandle(m_hImageFile); m_hImageFile = INVALID_HANDLE_VALUE;
  UnmapViewOfFile(m_hFile);      CloseHandle(m_hFile);
  UnmapViewOfFile(m_hGuiFile);   CloseHandle(m_hGuiFile);
}

bool  PluginShmemPipe::hasConnection() const 
{ 
  return (m_hImageFile != NULL) && (m_hImageFile!=NULL) && (m_hGuiFile!=NULL) && m_hydraServerStarted; 
}

void PluginShmemPipe::sendToServer(const char* a_data, unsigned int a_size)
{
  char* data = new char[4096];
  sprintf(data, "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <hydra_presets> <%s> 1 </%s> </hydra_presets>", a_data, a_data); // seems that doen not work ...
  this->updatePresets(data);
  delete data;

  SharedBufferDataInfo* pInfo = bufferInfo();
 
  memset(bufferData(), 1024, 0);
  pInfo->written = HYDRA_PLUGIN_ID;
  pInfo->read    = 1;
  strcpy(bufferData(), a_data);

}


void PluginShmemPipe::waitForAnyServerReply()
{

}


void PluginShmemPipe::updatePresets(const char* a_presetsXML)
{
  SharedBufferInfo2* pInfo = (SharedBufferInfo2*)m_guiShmem;
  char* data = m_guiShmem + sizeof(SharedBufferInfo2);

  //memset(m_guiShmem, 0, GUI_FILE_SIZE);
  strcpy(data, a_presetsXML);

  pInfo->xmlBytesize   = strlen(a_presetsXML);
  pInfo->lastWriter    = 0; 
  pInfo->dummy         = 0xFAFAFAFA; // magic end of the structure in the buffer
  pInfo->writerCounter = pInfo->writerCounter+2;

}

bool PluginShmemPipe::haveAnyMessageFromServer()
{
  struct SharedBufferDataInfo* pInfo = bufferInfo(); 
  return (pInfo->written == HYDRA_SERVER_ID || pInfo->written == HYDRA_SERVER_FINISH_ID) && (pInfo->read == 0);
}

unsigned int PluginShmemPipe::recieveFromServer(char* a_data, unsigned int a_maxSize)
{
  if(haveAnyMessageFromServer())
  {
    struct SharedBufferDataInfo* pInfo = bufferInfo(); 
    unsigned int size = (unsigned int)(pInfo->width*pInfo->height);

    if(size == 0xFFFFFFFF) size = 0;
    if(size > a_maxSize)   size = a_maxSize;
    if(size > MESSAGE_BUFF_SIZE) size = MESSAGE_BUFF_SIZE;
    
    if(pInfo->written != HYDRA_PLUGIN_ID)
      memcpy(a_data, bufferData(), size);

    memset(bufferData(), 1024, 0);
    pInfo->written = HYDRA_PLUGIN_ID;
    pInfo->read    = 1;

    return size;
  }
  
  return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool  PluginShmemPipe::haveNewImageFromServer()
{
  struct SharedBufferDataInfo* pInfo = imageBufferInfo(); 
  return (pInfo->written == HYDRA_SERVER_ID || pInfo->written == HYDRA_SERVER_FINISH_ID) && (pInfo->read == 0);
}

void* PluginShmemPipe::mapImageData()
{
  if(haveNewImageFromServer())
    return imageBufferDara();
  else 
    return NULL;
}

void  PluginShmemPipe::unmapImageData()
{
  if(haveNewImageFromServer())
  {
    struct SharedBufferDataInfo* pInfo = imageBufferInfo(); 
    
    m_lastImageType = pInfo->written;
    
    pInfo->read     = 1;
    pInfo->written  = HYDRA_PLUGIN_ID;
  }
}

bool PluginShmemPipe::lastImageWasFinal() const { return m_lastImageType == HYDRA_SERVER_FINISH_ID; }


bool  PluginShmemPipe::imageWasReadHDR()
{
  return false;
}

void* PluginShmemPipe::mapImageDataHDR()
{
  return NULL;
}

void  PluginShmemPipe::unmapImageDataHDR()
{

}

int PluginShmemPipe::getImageType() const
{
  return SEND_IMAGE_LDR;
}

int hydraRender_mk3::FileTransfer(std::wstring name)
{
  return 0;
}

