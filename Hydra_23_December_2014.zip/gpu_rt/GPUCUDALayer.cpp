#include "GPUAbstractLayer.h"

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
  #include "path_tracing.h"
#endif


void IHWLayer::SetAllFlagsAndVars(const AllRenderVarialbes& a_vars)
{
  m_vars = a_vars;
}

AllRenderVarialbes IHWLayer::GetAllFlagsAndVars() const
{
  return m_vars;
}


void IHWLayer::PushState()
{
  m_varsStack.push(m_vars);
  m_flagsStack.push(m_flags);
}

void IHWLayer::PopState()
{
  m_vars  = m_varsStack.top();
  m_flags = m_flagsStack.top();

  m_varsStack.pop();
  m_flagsStack.pop();
}



void AllRenderVarialbes::SetVariableI(int a_name, int a_val)
{
  if (a_name<GMAXVARS)
    m_varsI[a_name] = a_val;
}

void AllRenderVarialbes::SetVariableF(int a_name, float a_val)
{
  if (a_name<GMAXVARS)
    m_varsF[a_name] = a_val;
}

void AllRenderVarialbes::SetFlags(unsigned int bits, unsigned int a_value)
{
  if (a_value == 0)
    m_flags = m_flags & (~bits);
  else
    m_flags |= bits;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class CUDAHWLayer : public IHWLayer
{

public:

  CUDAHWLayer(int w, int h, int a_flags);
  ~CUDAHWLayer();

  void Clear(IGraphicsEngine::CLEAR_FLAGS a_flags);

  void SetGeom(InputGeom a_input);
  void SetBVH(InputGeomBVH a_input);

  void SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum); // set All PlainMaterials, including intermediate and auxilary
  void SetAllPODLights(RAYTR::Light* a_materialsAll, PlainLight* a_lights2, size_t a_number); // unlike materials, lights always represented as POD
  void SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data);
  void SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats);
  void SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16]);
  
  void SetAllFlagsAndVars(const AllRenderVarialbes& a_vars);
  AllRenderVarialbes GetAllFlagsAndVars() const;

  //
  //
  unsigned int AddLightMesh(LightMeshData a_lmesh);

  //
  //
  void GetLDRImageToGL(GLuint ogl_buffer) const;
  void GetLDRImage(uint* data, int width, int height) const;
  void GetHDRImage(float4* data, int width, int height) const;

  void ResetPerfCounters();
  
  void BeginTracingPass();
  void EndTracingPass();
  void InitPathTracing(int seed);
  
  bool ImplementBlocksPT();
  void BeginBlocksPTPass(BlockList& a_list, int a_minRaysPerPixel, int a_maxRaysPerPixel);
  void EndBlocksPTPass();

  void ResizeScreen(int w, int h, int a_flags);

  void RegisterOutputGLBuffer(GLuint ogl_buffer);
  void UnregisterOutputGLBuffer();


  size_t GetAvaliableMemoryAmount(bool allMem);
  MRaysStat GetRaysStat();

protected:
  

};


CUDAHWLayer::CUDAHWLayer(int w, int h, int a_flags)
{
  hrtInit(w, h, a_flags);
  hmctInit(w, h);
  hlmInit();
}


CUDAHWLayer::~CUDAHWLayer()
{
  hlmDelete();
  hmctDelete();
  hrtDelete();
}


void CUDAHWLayer::ResizeScreen(int width, int height, int a_flags)
{
  hrtPTFreePerRayData();
  hrtFreeScreenBuffersData();
  hrtFreePerRayData();

  int MEGA_BLOCK_SIZE = width*height / 2;
  if (MEGA_BLOCK_SIZE > 1280 * 1024)
    MEGA_BLOCK_SIZE = width*height / 4;

  hrtAllocScreenBuffersData(width, height);
  hrtAllocPerRayData(MEGA_BLOCK_SIZE);
  hrtPTAllocPerRayData(MEGA_BLOCK_SIZE);
}

size_t CUDAHWLayer::GetAvaliableMemoryAmount(bool allMem)
{
  return hrtGetAvaliableMemoryAmount(allMem);
}

void CUDAHWLayer::SetGeom(InputGeom a_input)
{
  if(a_input.vertPos == NULL || a_input.vertNorm == NULL || a_input.vertTexCoord == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid vertex data null pointer");

  if (a_input.indices == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid indices null pointer");

  if (a_input.materialIndices == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid triangle material indices null pointer");

  if (a_input.numIndices % 3 != 0)
    RUN_TIME_ERROR("CUDAHWLayer::SetGeom: invalid input.numIndices value, must be multiple of 3");

  hrtSetCommonVertexAttributes(a_input.vertPos, a_input.vertNorm, a_input.vertTexCoord, NULL, int(a_input.vertNum));
  //hrtSetTangentAtrributes(a_input.vertTangent, int(a_input.vertNum));
  hrtSetIndices32(a_input.indices, int(a_input.numIndices));
  
}


void CUDAHWLayer::SetBVH(InputGeomBVH a_input)
{
  if (a_input.nodes == NULL || a_input.primListData == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetBVH: invalid bvh data null pointer");

  if (a_input.numNodes == NULL || a_input.primListSizeInBytes == NULL)
    RUN_TIME_ERROR("CUDAHWLayer::SetBVH: invalid bvh data size");

  hrtSetWorldBVH(a_input.nodes, uint(a_input.numNodes));
  hrtSetWorldObjectListData(a_input.primListData, uint(a_input.primListSizeInBytes), uint(a_input.triNumInList));
  hrtSetCurrAccelStructType(ACCEL_STRUCT_BVH);
}

void CUDAHWLayer::SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum)
{

}

void CUDAHWLayer::SetAllPODLights(RAYTR::Light* a_lights, PlainLight* a_lights2, size_t a_number)
{
  //fprintf(stderr, "[cpp ]: sizeof(Light) = %d\n", sizeof(RAYTR::Light));
  hrtSetLights(a_lights, int(a_number));
}


void CUDAHWLayer::SetAllFlagsAndVars(const AllRenderVarialbes& a_vars)
{
  this->IHWLayer::SetAllFlagsAndVars(a_vars);

  hrtSetAllFlags(a_vars.m_flags);
  
  for (int i = 0; i < GMAXVARS; i++)
  {
    hrtSetVariableI(i, a_vars.m_varsI[i]);
    hrtSetVariableF(i, a_vars.m_varsF[i]);
  }

}

AllRenderVarialbes CUDAHWLayer::GetAllFlagsAndVars() const
{
  AllRenderVarialbes state = IHWLayer::GetAllFlagsAndVars();

  state.m_flags = hrtGetFlags();

  for (int i = 0; i < GMAXVARS; i++)
  {
    state.m_varsI[i] = hrtGetVariableI(i);
    state.m_varsF[i] = hrtGetVariableF(i);
  }

  return state;
}

void CUDAHWLayer::SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats)
{
  if (a_sizeInFloats%16 != 0)
    RUN_TIME_ERROR("CUDAHWLayer::SetAllTextureMatrices: invalid matrices a_sizeInFloats");

  hrtSetTextureMatrices(a_data, a_sizeInFloats/16);
}

void CUDAHWLayer::SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data)
{
  switch (usage)
  {
  case MEGATEX_SHADING:
    hrtAddMegaTexture4ub("shadingTexture", a_data.outOfCore, a_data.data, a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
    break;

  case MEGATEX_SHADING_HDR:
    hrtAddMegaTexture4f("shadingTextureHDR", a_data.outOfCore, (const float*)a_data.data, a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
    break;

  case MEGATEX_NORMAL:
    hrtAddMegaTexture4ub("normalmapTexture", a_data.outOfCore, a_data.data, a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
    break;
  
  case MEGATEX_OPACITY:
  {
    std::vector<unsigned char> tempData(a_data.w*a_data.h);

    for (int i = 0; i < tempData.size(); i++)
    {
      unsigned char r = a_data.data[4*i + 0];
      unsigned char g = a_data.data[4*i + 1];
      unsigned char b = a_data.data[4*i + 2];
      unsigned char a = a_data.data[4*i + 3];

      int avg = (int(r) + int(g) + int(b)) / 3; // or alpha ??? WARNING: this is different for different textures

      tempData[i] = (unsigned char)(avg);
    }

    hrtAddMegaTexture1ub("opacityTexture", a_data.outOfCore, (const char*)&tempData[0], a_data.w, a_data.h, a_data.lookUpTable, a_data.lookUpTableSize);
  }
  break;

  default:
    RUN_TIME_ERROR("CUDAHWLayer::SetMegaTexture: invalid usage");
    break;
  };
 
}

void CUDAHWLayer::Clear(IGraphicsEngine::CLEAR_FLAGS a_flags)
{
  if (a_flags & IGraphicsEngine::CLEAR_TEXTURES)
    hrtClearMegaTextures();

  if (a_flags & IGraphicsEngine::CLEAR_LIGHTS)
  {
    // clear lights 
    // clear light meshes
  }

  if (a_flags & IGraphicsEngine::CLEAR_MATERIALS)
  {

  }

  if (a_flags & IGraphicsEngine::CLEAR_GEOMETRY)
  {

  }


}

void CUDAHWLayer::SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16])
{
  sga_cudaMemcpyToSymbol("g_mViewProjInv", mProjInverse, 16 * sizeof(float));
  sga_cudaMemcpyToSymbol("g_mWorldViewInv", mWorldViewInverse, 16 * sizeof(float));

  hrtSetCamMatrices(mProjInverse, mWorldViewInverse);

}


//
//
void CUDAHWLayer::GetLDRImageToGL(GLuint ogl_buffer) const
{
  hrtEndTrace(ogl_buffer, NULL);
}

void CUDAHWLayer::GetLDRImage(uint* data, int width, int height) const
{
  hrtGetBuffer("LDRColorBuffer", data, width*height*sizeof(uint), 0);
}

void CUDAHWLayer::GetHDRImage(float4* data, int width, int height) const
{
  hrtGetBuffer("HDRColorBuffer", data, width*height*sizeof(float4), 0);
}


void CUDAHWLayer::InitPathTracing(int seed)
{
  // hrtInitRandom(seed);
  hrtFillXYBufferAndClearAccumBuffers();
}

bool CUDAHWLayer::ImplementBlocksPT() { return false; }
void CUDAHWLayer::BeginBlocksPTPass(BlockList& a_list, int a_minRaysPerPixel, int a_maxRaysPerPixel) { }
void CUDAHWLayer::EndBlocksPTPass() {}

MRaysStat CUDAHWLayer::GetRaysStat() 
{ 
  return hrtGetRaysStat(); 
}

unsigned int CUDAHWLayer::AddLightMesh(LightMeshData a_lmesh)
{
  return hrtAddLightMesh(a_lmesh.positions, a_lmesh.texCoords, a_lmesh.texCoords, int(a_lmesh.size));
}

void CUDAHWLayer::ResetPerfCounters()
{
  hrtResetCounters();
}

void CUDAHWLayer::BeginTracingPass()
{
  hrtBeginTrace(0);
}

void CUDAHWLayer::EndTracingPass()
{
 
}


void CUDAHWLayer::RegisterOutputGLBuffer(GLuint ogl_buffer)
{
  hrtRegisterPBO(ogl_buffer);
}

void CUDAHWLayer::UnregisterOutputGLBuffer()
{
  hrtUnregisterPBO();
}




IHWLayer* CreateCudaImpl(int w, int h, int a_flags) { return new CUDAHWLayer(w, h, a_flags); }

