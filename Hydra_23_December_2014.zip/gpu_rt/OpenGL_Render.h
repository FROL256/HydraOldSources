// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once

#include "IGraphicsEngine.h"
#include "Common_Graphics_Engine.h"
#include "Fonts.h"

#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif


class DLL_API OpenGL_Render: public Common_Graphics_Engine // : public Singleton
{
	typedef IGraphicsEngine		   Interface;
	typedef Common_Graphics_Engine Realisation;

public:

	typedef Common_Graphics_Engine Base;
	typedef unsigned int uint;

  OpenGL_Render(int w, int h, bool wireFrame = false);
	~OpenGL_Render();

	void BeginDrawScene(RenderSettings a_renderState);			// account multi threading
	void EndDrawScene();			// account multi threading

  void BuildAccelerationStructures(const std::string& a_geomMD5, const std::string& a_lightsMD5);

  void SetDebugDrawIndex(int a_packet) { m_degugDrawIndex = a_packet;}

	uint AddTexture(const void* memory, unsigned int w, unsigned int h, unsigned int format);

	//enum {MAX_NUM_VERTICES = 1000000,
  //		  MAX_NUM_SPHERES  = 1024,
	//	    MAX_NUM_POINT_LIGHTS = 8};

protected:

	void setLights();
  void DebugDrawNormals();
  void DebugDrawSphericalDistribution();
  void DebugDrawCurrRayPacket();
  void DebugDrawColoredPoints();
  void DebugDrawBoxes();
  void DebugDrawRays();
  void DebugDrawPoints();

  void DebugDrawRaysSphericalInices();
  void DebugDrawRaysCurrSphericalIndex();

  static std::vector<float3> GetTestSphericalPoints(int N);

	virtual OpenGL_Render& operator=(const OpenGL_Render& x)
	{ 
		throw std::runtime_error("OpenGL_Render:: attempt to call protected operator=() "); 
		return (OpenGL_Render&)x;
	}

	GLUquadricObj* QuadrObj; 

	struct GL_List
	{

		enum {	MAX_LISTS_NUM = 64,
				    MAX_TRIANGLE_NUM = 3000000};

		GL_List()
		{
			lists_num	= 1;
			render		= 0;
		}

		virtual ~GL_List()
		{
			//delete [] lists;
			render		= 0;
			lists_num	= 1;
		}

		void Init(	const uint* indices,	uint num_ind, const OpenGL_Render* a_render);

		inline void Draw()
		{
			//glCallLists(lists_num,GL_UNSIGNED_INT,lists);

			for(uint i=1;i<lists_num;i++)
				glCallList(i);
		}

		uint	lists_num;
		const OpenGL_Render* render;
	};

	GL_List all_scene_list;
	bool init_scene_list;
  bool m_wireFrame;

  // debug data
  //
  enum {DEBUG_RAYS_SIZE = (1024*768/2)};
  std::vector<float4> m_debugRaysPos;
  std::vector<float4> m_debugRaysDir;

  enum {MAX_DEBUG_BOXES = 10000};
  int m_degugDrawIndex;
  AABB3f* m_debugBoxes;
  int m_numDebugBoxes;

  void DebugDrawTangents();
  
public:

  IC_Octree* m_debugOctree;
};