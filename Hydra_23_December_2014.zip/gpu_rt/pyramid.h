#define PYRAMID_GUARDIAN

#ifndef universal_call
  #define universal_call __device__ __host__
#endif

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

const int BLOCK_SIZE_PYRAMID = 256;
const int MAX_SHARED_SIZE_PYRAMID = 4096;

template<int N>
struct CALC_DEGREE{};

template<>
struct CALC_DEGREE<2>
{
  enum {RET = 1};
};

template<>
struct CALC_DEGREE<4>
{
  enum {RET = 2};
};


template<>
struct CALC_DEGREE<8>
{
  enum {RET = 3};
};

template<>
struct CALC_DEGREE<16>
{
  enum {RET = 4};
};

template<>
struct CALC_DEGREE<32>
{
  enum {RET = 5};
};


template<>
struct CALC_DEGREE<64>
{
  enum {RET = 6};
};


template<>
struct CALC_DEGREE<128>
{
  enum {RET = 7};
};


template<>
struct CALC_DEGREE<256>
{
  enum {RET = 8};
};

template<>
struct CALC_DEGREE<512>
{
  enum {RET = 9};
};



///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class OP_MIN
{
public:
  static inline universal_call T exec(const T& A, const T& B)
  {
    if(A<B)
      return A;
    else
      return B;
  }
};

///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class OP_MAX
{
public:
  static inline universal_call T exec(const T& A, const T& B)
  {
    if(A>B)
      return A;
    else
      return B;
  }
};

///////////////////////////////////////////////////////////////////////////////////
////
template<>
class OP_MIN<Lite_Hit>
{
public:
  static inline universal_call Lite_Hit exec(const Lite_Hit& A, const Lite_Hit& B)
  {
    if(A.t<B.t)
      return A;
    else
      return B;
  }
};



///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class OP_ADD
{
public:
  static inline universal_call T exec(const T& A, const T& B)
  {
    return A + B;
  }
};

///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class OP_AND
{
public:
  static inline universal_call T exec(const T& A, const T& B)
  {
    return A & B;
  }
};

///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class OP_OR
{
public:
  static inline universal_call T exec(const T& A, const T& B)
  {
    return A | B;
  }
};


///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class OP_MIN_GT_ZERO
{
public:
  static inline universal_call T exec(const T& A, const T& B)
  {
    if ((A < B && A > 0) || B == 0)
      return A;
    else
      return B;
  }
};


///////////////////////////////////////////////////////////////////////////////////
////
template<class T>
class LESS
{
public:
  static inline universal_call bool exec(const T& A, const T& B)
    { return A < B; }
};






///////////////////////////////////////////////////////////////////////////////////
////
template
<
    class T, 
    template <class> class F
>
T PyramidAlgorithm(T* in_data, int in_size, bool bufferOnGPU)
{   
  	T *data_gpu;
    T *gpu_res;
    T *cpu_res;
 
    int size_in_bytes = in_size*sizeof(T);
    int blocksNumber = in_size*sizeof(T)/MAX_SHARED_SIZE_PYRAMID;
    if(blocksNumber <= 1)
      blocksNumber = 1;

    if(bufferOnGPU)
    {
      data_gpu = in_data;
    }
    else
    {
      checkCudaErrors(cudaMalloc((void**) &data_gpu, (in_size+1)*sizeof(T)));
		  checkCudaErrors(cudaMemcpy(data_gpu, in_data, size_in_bytes, cudaMemcpyHostToDevice) );
    }

    cpu_res = (T*)malloc(blocksNumber*sizeof(T));
    checkCudaErrors(cudaMalloc((void**) &gpu_res, blocksNumber*sizeof(T)));
    // + 1 - the last element is result
  
    dim3 grid(blocksNumber, 1, 1);
		dim3 threads(BLOCK_SIZE_PYRAMID, 1, 1);

    //const int STRIDE = MAX_SHARED_SIZE_PYRAMID/sizeof(T);

    //Pyramid_kernel<int, F> <<<grid, threads>>> (data_gpu, MIN(in_size,STRIDE), gpu_res);
		//checkCudaErrors(cudaMemcpy(cpu_res, gpu_res, sizeof(T)*blocksNumber, cudaMemcpyDeviceToHost));

    // �������� �� ����������� ����� � ������ �������� �������.
    // ����� ����� ������ ��� �� ���� ����� ������ ������� ����� ���� �� ������ 256.
    T res = cpu_res[0];
    for(int i=1;i<blocksNumber;i++)
      res = F<T>::exec(res,cpu_res[i]);

    free(cpu_res);

    if(!bufferOnGPU)
    {
      checkCudaErrors(cudaFree(gpu_res));
      checkCudaErrors(cudaFree(data_gpu));
    }

    return res;
}



