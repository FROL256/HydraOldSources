// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include <GL/glew.h>
#include <string>

#include "GPU_Ray_Tracer.h"
#include "GPU_Path_Tracer.h"
#include "Fonts.h"

#ifdef __GNUC__

  //#include <unordered_map>
  //typedef std::unordered_map<std::string, const std::string*> ShaderTableT;

  #include <map>
  typedef std::map<std::string, const std::string*> ShaderTableT;

#else

  #include <hash_map>  
  typedef stdext::hash_map<std::string, const std::string*> ShaderTableT;

#endif


#include "../vsgl3/glHelper.h"

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif


const std::string g_quadVS = "                              \n\
#version 330                                                \n\
                                                            \n\
in  vec2 vertex;                                            \n\
out vec2 fragmentTexCoord;                                  \n\
                                                            \n\
void main(void)                                             \n\
{                                                           \n\
  fragmentTexCoord = vertex * 0.5 + 0.5;                    \n\
  gl_Position = vec4(vertex, 0.0, 1.0);                     \n\
}                                                           ";

const std::string g_quadPS = "                              \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
in  vec2 fragmentTexCoord;                                  \n\
out vec4 fragColor;                                         \n\
                                                            \n\
uniform ivec2 im_size;                                      \n\
uniform sampler2D screenBufferTex;                          \n\
                                                            \n\
void main(void)                                             \n\
{	                                                          \n\
  fragColor = texture(screenBufferTex, fragmentTexCoord);   \n\
}                                                           "; 


const std::string g_quadPS_TBO = "                          \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
in  vec2 fragmentTexCoord;                                  \n\
out vec4 fragColor;                                         \n\
                                                            \n\
uniform ivec2 im_size;                                      \n\
uniform samplerBuffer tboSampler;                           \n\
                                                            \n\
void main(void)                                             \n\
{	                                                          \n\
  vec2 xy    = fragmentTexCoord*vec2(im_size.x, im_size.y); \n\
  int offset = int(xy.y*im_size.x + xy.x + im_size.x/2);    \n\
  fragColor  = texelFetch(tboSampler, offset);              \n\
}                                                           "; 

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const std::string g_simpleVS = "                            \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
uniform mat4 projectionMatrix;                              \n\
uniform mat4 modelViewMatrix;                               \n\
uniform vec4 color;                                         \n\
                                                            \n\
in  vec4 vertex;                                            \n\
out vec4 vertColor;                                         \n\
                                                            \n\
void main(void)                                             \n\
{                                                           \n\
  vertColor    = color;                                     \n\
  vec4 viewPos = modelViewMatrix*vec4(vertex.xyz, 1.0);     \n\
  gl_Position  = projectionMatrix*viewPos;                  \n\
}                                                           ";


const std::string g_simpleVSColored = "                     \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
uniform mat4 projectionMatrix;                              \n\
uniform mat4 modelViewMatrix;                               \n\
                                                            \n\
uniform float lid = -1;                                     \n\
                                                            \n\
in  vec4 vertex;                                            \n\
in  vec4 vcolor;                                            \n\
out vec4 vertColor;                                         \n\
                                                            \n\
void main(void)                                             \n\
{                                                           \n\
  vertColor    = vcolor;                                    \n\
  vec4 viewPos = modelViewMatrix*vec4(vertex.xyz, 1.0);     \n\
  gl_Position  = projectionMatrix*viewPos;                  \n\
                                                            \n\
  if(lid >= 0.0)                                            \n\
    if(abs(vcolor.w - lid) > 0.001)                         \n\
      gl_Position.w = 0.0;                                  \n\
                                                            \n\
}                                                           ";


const std::string g_simpleVS2D = "                          \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
uniform mat4 projectionMatrix;                              \n\
uniform vec4 color;                                         \n\
                                                            \n\
in  vec2 vertex;                                            \n\
out vec4 vertColor;                                         \n\
                                                            \n\
void main(void)                                             \n\
{                                                           \n\
  vertColor    = color;                                     \n\
  vec4 viewPos = vec4(vertex.xy, 0.0, 1.0);                 \n\
  gl_Position  = projectionMatrix*viewPos;                  \n\
}                                                           ";



const std::string g_simpleVS2DDummy = "                     \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
in  vec3 vertex;                                            \n\
out vec3 vpos;                                              \n\
                                                            \n\
void main(void)                                             \n\
{                                                           \n\
  vpos = vertex;                                            \n\
}                                                           ";


const std::string g_gsQuadLine = "                                  \n\
                                                                    \n\
#version 330                                                        \n\
                                                                    \n\
uniform mat4 projectionMatrix;                                      \n\
uniform vec2 size;                                                  \n\
uniform vec2 errBounds;                                             \n\
uniform vec4 color;                                                 \n\
uniform int  useColorCoding;                                        \n\
                                                                    \n\
in  vec3 vpos [];                                                   \n\
out vec4 vertColor;                                                 \n\
                                                                    \n\
layout (points) in;                                                 \n\
layout (line_strip, max_vertices = 5) out;                          \n\
                                                                    \n\
void main(void)                                                     \n\
{                                                                   \n\
  vec2 pos = vpos[0].xy;                                            \n\
  float t  = 1.0;                                                   \n\
  if(vpos[0].z <= errBounds.y && useColorCoding > 0)                \n\
    t = (vpos[0].z - errBounds.x)/(errBounds.y - errBounds.x);      \n\
  float a = clamp(t, 0.0, 1.0);                                     \n\
                                                                    \n\
  vertColor = vec4(1.0,0.0,0.0,1.0)*a+(1.0-a)*vec4(0.0,1.0,0.0,1.0);\n\
                                                                    \n\
  gl_Position = projectionMatrix*vec4(pos,0,1);                     \n\
  EmitVertex();                                                     \n\
                                                                    \n\
  gl_Position = projectionMatrix*vec4(pos+vec2(0,size.y),0,1);      \n\
  EmitVertex();                                                     \n\
                                                                    \n\
  gl_Position = projectionMatrix*vec4(pos+vec2(size.x,size.y),0,1); \n\
  EmitVertex();                                                     \n\
                                                                    \n\
  gl_Position = projectionMatrix*vec4(pos+vec2(size.x,0),0,1);      \n\
  EmitVertex();                                                     \n\
                                                                    \n\
  gl_Position = projectionMatrix*vec4(pos,0,1);                     \n\
  EmitVertex();                                                     \n\
}                                                                   ";



const std::string g_coloredPS = "                           \n\
                                                            \n\
#version 330                                                \n\
                                                            \n\
in  vec4 vertColor;                                         \n\
out vec4 fragColor;                                         \n\
                                                            \n\
void main(void)                                             \n\
{	                                                          \n\
  fragColor = vertColor;                                    \n\
}                                                           ";

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

const std::string g_emptyShader = "";




const std::string& RTE_GetShaderSource(const std::string& a_shaderName)
{
  static ShaderTableT shadertable;

  static bool firstCall = true;

  if(firstCall)
  {
    shadertable["quad_vs"] = &g_quadVS;
    shadertable["quad_ps"] = &g_quadPS;
    shadertable["quad_ps_tbo"] = &g_quadPS_TBO;
    
    shadertable["simple_vs"]    = &g_simpleVS;
    shadertable["photons_vs"]   = &g_simpleVSColored;

    shadertable["color_ps"]     = &g_coloredPS;
    shadertable["simple_vs_2d"] = &g_simpleVS2D;

    shadertable["dummy_vs_2d"]  = &g_simpleVS2DDummy;
    shadertable["gs_quad_lines"]= &g_gsQuadLine;
      
    shadertable[""]          = &g_emptyShader;
    firstCall = false;
  }

  if(shadertable.find(a_shaderName) != shadertable.end())
    return *(shadertable[a_shaderName]);
  else
    return g_emptyShader;

}

// #CHECK_THIS, do not works
void RTE_CreateScreenTBO(GLuint* tbo, GLuint* tex, unsigned int a_size, void* a_data) //unsigned int size = a_width*a_height*sizeof(unsigned int); 
{
  // create buffer object
  glGenBuffers(1, tbo);                                             CHECK_GL_ERRORS;  
  glBindBuffer(GL_TEXTURE_BUFFER, *tbo);                            CHECK_GL_ERRORS;                                    
  glBufferData(GL_TEXTURE_BUFFER, a_size, a_data, GL_DYNAMIC_DRAW); CHECK_GL_ERRORS; // initialize buffer object    

  glGenTextures(1, tex);                                        CHECK_GL_ERRORS;  
  glBindTexture(GL_TEXTURE_BUFFER, *tex);                       CHECK_GL_ERRORS;  
  glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA8, *tbo);               CHECK_GL_ERRORS;  
  glBindBuffer(GL_TEXTURE_BUFFER, 0);                           CHECK_GL_ERRORS;  
} 

// #CHECK_THIS
void RTE_DeleteScreenTBO(GLuint* tbo) 
{
  glDeleteBuffers(1, tbo);                                      CHECK_GL_ERRORS;
  *tbo = 0;
} 


void GPU_Ray_Tracer::DrawICRecords(){}
void GPU_Ray_Tracer::FreeICRecordsBuffer(){}

void GPU_Path_Tracer::DrawICRecords()
{
  Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
  Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);

  int bufferByteSize = hrtGetBufferSize("ICRecordsPositions");
  int recordsNum = bufferByteSize/sizeof(IrradianceCachePoint_Part1);

  if(bufferByteSize == 0)
    return;

  if(m_glRes.m_vertPosBuffSize < bufferByteSize)
  {
    glNamedBufferDataEXT(m_glRes.m_pointsPos, bufferByteSize, NULL, GL_DYNAMIC_COPY);  CHECK_GL_ERRORS;
    m_glRes.m_vertPosBuffSize = bufferByteSize;
  }

  hrtGetBuffer("ICRecordsPositions", NULL, bufferByteSize, m_glRes.m_pointsPos); // copy positions to m_debugBuffers.m_vertPosBuff

  glUseProgram(m_displayPointsProg.program);  CHECK_GL_ERRORS; 

  setUniform(m_displayPointsProg.program, "modelViewMatrix", mWorldView); 
  setUniform(m_displayPointsProg.program, "projectionMatrix", mProj); 
  setUniform(m_displayPointsProg.program, "color", float4(0,0,1,1)); 

  glBindVertexArray(m_glRes.m_vaoPoints); CHECK_GL_ERRORS; 
  glDrawArrays(GL_POINTS, 0, recordsNum); CHECK_GL_ERRORS; 

  glBindVertexArray(0);                   CHECK_GL_ERRORS; 
  glUseProgram(0);                        CHECK_GL_ERRORS; 
}

void GPU_Path_Tracer::FreeICRecordsGLBuffer()
{
  if(m_glRes.m_vertPosBuffSize != 0)
  {
    glNamedBufferDataEXT(m_glRes.m_pointsPos, 0, NULL, GL_DYNAMIC_COPY); CHECK_GL_ERRORS; 
    m_glRes.m_vertPosBuffSize = 0; 
  }
}


void GPU_Ray_Tracer::DrawPhotons(const char* a_phMapName){}
void GPU_Ray_Tracer::FreeGLPhotonsData(const char* a_phMapName) {}


void GPU_Path_Tracer::DrawPhotons(const char* a_phMapName)
{
  GLuint* pPosBuff = NULL;
  GLuint* pColBuff = NULL;
  int*    pSize    = NULL;
  GLuint currVAO   = GLuint(-1);
  IPhotonMap* pPhotonMap = NULL;

  bool customLightId = false;
  if(std::string(a_phMapName) == "diffuse")
  {
    pPosBuff   = &m_glRes.m_photonsPos;
    pColBuff   = &m_glRes.m_photonsCol;
    pSize      = &m_glRes.m_photonsBuffSize;
    pPhotonMap = m_pPhotonMap;
    currVAO    = m_glRes.m_vaoPhotons;
  } 
  else if(std::string(a_phMapName) == "caustic")
  {
    pPosBuff   = &m_glRes.m_photonsCausticPos;
    pColBuff   = &m_glRes.m_photonsCausticCol;
    pSize      = &m_glRes.m_photonsCausticBuffSize;
    pPhotonMap = m_pCausticPhotonMap;
    currVAO    = m_glRes.m_vaoPhotonsCaustic;
  }
  else
  {
    pPosBuff   = &m_glRes.m_photonsDLPos;
    pColBuff   = &m_glRes.m_photonsDLCol;
    pSize      = &m_glRes.m_photonsDLBuffSize;
    pPhotonMap = m_pLightDirectPhotonMap;
    currVAO    = m_glRes.m_vaoPhotonsDL;
    customLightId = (m_ivars["pmdlAll"] != 1);
  }

  GLuint& posBuff = *pPosBuff;
  GLuint& colBuff = *pColBuff;
  int&    bufSize = *pSize;

  int currBuffSize = pPhotonMap->GetMaxPhotons()*sizeof(float4); // pPhotonMap->GetCurrPhotons()*sizeof(float4);
  if(pPhotonMap->GetCurrPhotons() == 0)
    return;

  if(bufSize != currBuffSize)
  {
    glNamedBufferDataEXT(posBuff, currBuffSize, NULL, GL_STATIC_DRAW); CHECK_GL_ERRORS; 
    glNamedBufferDataEXT(colBuff, currBuffSize, NULL, GL_STATIC_DRAW); CHECK_GL_ERRORS; 
    bufSize = currBuffSize;
  }

  pPhotonMap->GetPhotonsPosColorToGLBuffers(posBuff, colBuff);

  Matrix4x4f mWorldView = Matrix4x4f(m_worldViewMatrixData);
  Matrix4x4f mProj      = Matrix4x4f(m_projectionMatrixData);

  glUseProgram(m_displayPhotonsProg.program);  CHECK_GL_ERRORS; 

  setUniform(m_displayPhotonsProg.program, "modelViewMatrix",  mWorldView); 
  setUniform(m_displayPhotonsProg.program, "projectionMatrix", mProj); 

  if(customLightId)
    setUniform(m_displayPhotonsProg.program, "lid",  float(m_ivars["pmdlLightId"]));
  else
    setUniform(m_displayPhotonsProg.program, "lid", -1.0f);

  //setUniform(m_displayPhotonsProg.program, "color", float4(1,1,1,1)); 

  glBindVertexArray(currVAO); CHECK_GL_ERRORS; 
  glDrawArrays(GL_POINTS, 0, pPhotonMap->GetCurrPhotons()); CHECK_GL_ERRORS; 

  glBindVertexArray(0);                   CHECK_GL_ERRORS; 
  glUseProgram(0);                        CHECK_GL_ERRORS; 
}

void GPU_Path_Tracer::FreeGLPhotonsData(const char* a_phMapName)
{ 
  return; // a bug with glBufferData ?

  GLuint* pPosBuff = NULL;
  GLuint* pColBuff = NULL;
  int*    pSize    = NULL;
  IPhotonMap* pPhotonMap = NULL;

  if(std::string(a_phMapName) == "diffuse")
  {
    pPosBuff = &m_glRes.m_photonsPos;
    pColBuff = &m_glRes.m_photonsCol;
    pSize    = &m_glRes.m_photonsBuffSize;
    pPhotonMap = m_pPhotonMap;
  } 
  else if(std::string(a_phMapName) == "caustic")
  {
    pPosBuff = &m_glRes.m_photonsCausticPos;
    pColBuff = &m_glRes.m_photonsCausticCol;
    pSize    = &m_glRes.m_photonsCausticBuffSize;
    pPhotonMap = m_pCausticPhotonMap;
  }
  else
  {

  }

  GLuint& posBuff = *pPosBuff;
  GLuint& colBuff = *pColBuff;
  int&    bufSize = *pSize;

  int currBuffSize = pPhotonMap->GetCurrPhotons()*sizeof(float4);
  if(currBuffSize == 0)
    return;

  if(bufSize != 0)
  {
    glNamedBufferDataEXT(posBuff, 0, NULL, GL_STATIC_DRAW); CHECK_GL_ERRORS; 
    glNamedBufferDataEXT(colBuff, 0, NULL, GL_STATIC_DRAW); CHECK_GL_ERRORS; 
    bufSize = 0;
  }


}




