#define TRANSIT_PRIMITIVES_GUARDIAN

#ifndef MGML_GPU_GUARDIAN
  #include "../CSL/MGML_GPU.h"
#endif

namespace RAYTR
{

#ifdef __CUDACC__

  // ALERT!! THIS IS VERY DANGEROUS !!!!!!!

  __align__(16) struct sphere4
  {
    float4 pos;
    float r;
    float _rSquare;
    unsigned int material_id;
    float dummy;
  };

  __align__(16) struct box4
  {
    float4 vmin;
    float4 vmax;
  };

  struct box3
  {
    float3 vmin;
    float3 vmax;
  };

#else
  
  typedef MGML::Sphere4f sphere4;
  typedef MGML::Vertex4f vertex4;
  typedef MGML::AABB4f box4;
  typedef MGML::AABB3f box3;

#endif

//static STATIC_ASSERT<sizeof(sphere4) == 32> ERROR_size_of_sphere4_MUST_BE_28;
//static STATIC_ASSERT<sizeof(vertex4) == 48> ERROR_size_of_vertex4_MUST_BE_48;
//static STATIC_ASSERT<sizeof(box4) == 32> ERROR_size_of_box4_MUST_BE_32;
//static STATIC_ASSERT<sizeof(box3) == 24> ERROR_size_of_box3_MUST_BE_24;

}
