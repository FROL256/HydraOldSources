// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#pragma warning(disable:4251)

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif

#include "IGraphicsEngine.h"

#include "../bvh_builder/IBVHBuilder.h"
#include "../bvh_builder/BVHTree.h"

#include "Voxelizer.h"

#include <memory>
#include <string>

#ifdef __GNUC__

  #include <unordered_map>
  typedef std::unordered_map<std::string, std::string> RTE_HashMapS;
  typedef std::unordered_map<std::string, int>         RTE_HashMapI;
  typedef std::unordered_map<std::string, float>       RTE_HashMapF;
 
#else

  #include <hash_map>  
  typedef stdext::hash_map<std::string, std::string> RTE_HashMapS;
  typedef stdext::hash_map<std::string, int>         RTE_HashMapI;
  typedef stdext::hash_map<std::string, float>       RTE_HashMapF;

#endif


using namespace MGML;
using namespace RAYTR;

using MGML_MEMORY::DynamicArray;

class DLL_API Common_Graphics_Engine : public IGraphicsEngine
{
public:

	typedef unsigned int uint;

  Common_Graphics_Engine(int w, int h, int a_flags = 0);
	~Common_Graphics_Engine();

  void SetProgressBarCallback(RTE_PROGRESSBAR_CALLBACK a_callback);
  void SetUpdateImageCallback(RTE_UPDATEIMAGE_CALLBACK a_callback);

  // RTE API v 2.0
  //
  void DeclareVertexInputLayout(int layout, int numUserDefinedAttributes=0) throw (std::runtime_error);

  void ReserveMemoryFor(int primTypes, int a_maxPrims) throw (std::runtime_error); // may be used otr not

  // fixed function pipeline
  //
  void SetVertexPositionPointer(const float* v, int bytePitch) throw (std::runtime_error);
  void SetVertexNormalPointer(const float* v,   int bytePitch) throw (std::runtime_error);
  void SetVertexUVPointer(const float* v,       int bytePitch) throw (std::runtime_error);
  void SetVertexTangentPointer(const float* v,  int bytePitch) throw (std::runtime_error);
  void SetVertexMaterialIdPointer(const int* v, int bytePitch) throw (std::runtime_error);

  // programmable pipeline
  //
  void SetVertexAttributePointer(const char* attrName, const double* v, int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const float* v,  int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const int* v,    int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const short* v,  int bytePitch) throw (std::runtime_error);
  void SetVertexAttributePointer(const char* attrName, const char* v,   int bytePitch) throw (std::runtime_error);

  int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount, int a_flags = 0); // deprecated

  int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount,
                    const int* a_materialIndices, int a_matIdNum, int a_flags = 0);

  int AddTextureMatrix(const Matrix4x4f& a_mat);
  Matrix4x4f GetTextureMatrix(int a_matrixId);

  RAYTR::HydraMaterial GetHydraMaterial(int a_id);
  void SetHydraMaterial(const RAYTR::HydraMaterial& rhs, int a_id);

  void UpdateComplete();

  void SetWindowResolution(int a_width, int a_height);

  // RTE v1.0 and general
  //
	void BuildAccelerationStructures(const std::string& a_geomMD5, const std::string& a_lightsMD5);

  void Clear(int a_flags = CLEAR_ALL);

	vec2ui        AddTriangles( const Vertex4f* v,int N_vertices, const unsigned int* indices,int N_indices, int a_flags = 0);
	unsigned int  AddSpheres(const Sphere4f* s,int N_spheres);

	uint AddTexture(const void* memory,uint w,uint h,uint format);

  uint AddLight(const RAYTR::Light& light);
  int  GetLightNumber() const;

  const RAYTR::Light& GetLight(int index) const;
  void SetLight(const RAYTR::Light& light, int index);


  void SetWorldViewMatrix(const float mat[16]);
  void SetViewMatrix(const float mat[16]);
  void SetProjectionMatrix(const float mat[16]);

  const float* GetWorldViewMatrix() const;
  const float* GetProjectionMatrix() const;

  void SetAuxCamProjParams(const float pamams[4]);

  unsigned int AddMaterial(const RAYTR::HydraMaterial& mat);

  //void SetMaterial(const RAYTR::Material& mat, unsigned int N);
	//const RAYTR::Material&		GetMaterial(int index) const;

  void DebugCall(const std::string& a_name, const std::string& a_params);
  void DebugDrawAccelStruct();

  void SetVariable(const std::string& a_name, int a_val);
  void SetVariable(const std::string& a_name, float a_val);

  void GetTextureDesc(uint texId, uint* w, uint* h, uint* format = NULL);
  void GetTextureData(uint texId, void* data);
  const void* GetTextureDataPtr(uint texId) const;

  void GetLDRImage(uint* data) const {};
  void GetHDRImage(float4* data) const {};

  float EtimateTotalRenderingProgress() const { return 0.0f;}

  struct DIP
  {
    int m_vertStart;
    int m_vertEnd;

    int m_normStart;
    int m_normEnd;

    int m_texCoordStart;
    int m_texCoordEnd;

    int m_materialIdStart;
    int materialIdEnd;

    bool dynamic;
  };

  // kd tree input class
  //
  class BVHUserInput : public RAYTR::InputData
  {
  public:
    BVHUserInput(const Common_Graphics_Engine* a_data) : indicesWritten(0) {m_data = a_data;}

    int  GetNumTriangles() const throw (std::runtime_error);
    void GetTriangle(int index, float A[3], float B[3], float C[3]) const throw (std::runtime_error);

    int  GetNumSpheres() const throw (std::runtime_error) ;
    void GetSphere(int index, float sph_pos[3], float* sph_r) const throw (std::runtime_error);

    mutable int indicesWritten;

  private:
    const Common_Graphics_Engine* m_data;
  };

  friend class BVHUserInput;

  size_t PutPrimitivesToFinalBuffer(const std::vector<BvhLeafInfo>& a_beginEndArray,
    const std::vector<int>&         a_indexArray,
    std::vector<BVHNode>&           a_inBVH,
    std::vector<char>&              outMemory,
    RAYTR::InputData*               pInput);

  int WriteTriangle(int index, void* pAddressToWrite, char* pAddressStart);

protected:

  struct MyInputData
  {
    MyInputData() {Clear();}
    void Clear();

    union
    {
      const float4* m_vPosFloat4;
      const float3* m_vPosFloat3;
      const void*   m_vPosCustom;
    };
    int           m_vPosStride;

    union
    {
      const float4* m_vNormFloat4;
      const float3* m_vNormFloat3;
      const void*   m_vNormCustom;
    };
    int           m_vNormStride;

    union
    {
      const float4* m_vTexCoordFloat2;
      const void*   m_vTexCoordCustom;
    };
    int           m_vTexCoordStride;

    union
    {
      const float4* m_vTanFloat4;
      const float3* m_vTanFloat3;
      const void*   m_vTanCustom;
    };
    int           m_vTanStride;

    union
    {
      const int*    m_vMatIdInt32;
      const void*   m_vMatIdCustom;
    };
    int           m_vMatIdStride;

  } m_inputDataSet;

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////

  inline float4 GetVertexPos(int i)          const { return m_vertPos[i]; }
  inline float4 GetVertexNorm(int i)         const { return m_vertNorm[i]; }
  inline float2 GetVertexTexCoord(int i)     const { return m_vertTexCoord[i]; }
  inline int    GetTriangleMaterialId(int i) const { return m_triangleMaterialId[i]; }

  inline float4 GetVertexAttribute4f(int i, int ATTR_CODE) const { RUN_TIME_ERROR("not implemented"); float4* data = (float4*)m_vertAttr[ATTR_CODE]; return data[i]; }

  inline float4 GetSpherePos(int i)        const { return m_spheres[i].pos; }
  inline float  GetSphereRadius(int i)     const { return m_spheres[i].r; }
  inline int    GetSphereMaterialId(int i) const { return m_spheres[i].material_id; }


  class ImageStorage
  {

  public:

    enum FORMAT{RGBA8 = 4, RGBA16F = 8, RGBA32F = 16};

    ImageStorage();
    virtual ~ImageStorage(){}

    virtual void SetData(const unsigned char* data, int w, int h, int a_format = RGBA8);
    virtual void FreeData();

    virtual const void* GetConstData() const
    {
      if(m_data.size() > 0)
        return &m_data[0];
      else
        return NULL;
    }

    virtual void* GetData()
    {
      if(m_data.size() > 0)
        return &m_data[0];
      else
        return NULL;
    }


    virtual void resizeToHalfSize()
    {
      std::vector<unsigned char> copy = m_data;

      m_data   = std::vector<unsigned char>(copy.size() / 4);
      m_width  = m_width / 2;
      m_height = m_height / 2;

      if (m_elemByteSize == RGBA8)
      {
        vec4ub* oldArray = (vec4ub*)(&copy[0]);
        vec4ub* newArray = (vec4ub*)(&m_data[0]);

        #pragma omp parallel for
        for (int y = 0; y < m_height; y++)
        {
          int offset1 = (2*y+0)*2*m_width;
          int offset2 = (2*y+1)*2*m_width;

          for (int x = 0; x < m_width; x++)
          {
            vec4ub x0 = oldArray[offset1 + 2*x + 0];
            vec4ub x1 = oldArray[offset1 + 2*x + 1];
            vec4ub x2 = oldArray[offset2 + 2*x + 0];
            vec4ub x3 = oldArray[offset2 + 2*x + 1];

            int4 summ;

            summ.x = x0.x + x1.x + x2.x + x3.x;
            summ.y = x0.y + x1.y + x2.y + x3.y;
            summ.z = x0.z + x1.z + x2.z + x3.z;
            summ.w = x0.w + x1.w + x2.w + x3.w;

            summ = summ / 4;

            if (summ.x > 255) summ.x = 255;
            if (summ.y > 255) summ.y = 255;
            if (summ.z > 255) summ.z = 255;
            if (summ.w > 255) summ.w = 255;

            newArray[m_width*y + x] = vec4ub(summ.x, summ.y, summ.z, summ.w);
          }
        }

      }
      else if (m_elemByteSize == RGBA16F)
      {
        MGML_MATH::VECTOR<2, unsigned short>* oldArray = (MGML_MATH::VECTOR<2, unsigned short>*)(&copy[0]);
        MGML_MATH::VECTOR<2, unsigned short>* newArray = (MGML_MATH::VECTOR<2, unsigned short>*)(&m_data[0]);

        #pragma omp parallel for
        for (int y = 0; y < m_height; y++)
        {
          int offset1 = (2*y + 0)*2*m_width;
          for (int x = 0; x < m_width; x++)
          {
            newArray[y*m_width + x] = oldArray[offset1 + 2*x + 0];
          }
        }
      }
      else // RGBA32F
      {
        float4* oldArray = (float4*)(&copy[0]);
        float4* newArray = (float4*)(&m_data[0]);

        #pragma omp parallel for
        for (int y = 0; y < m_height; y++)
        {
          int offset1 = (2*y + 0)*2*m_width;
          int offset2 = (2*y + 1)*2*m_width;

          for (int x = 0; x < m_width; x++)
          {
            float4 x0 = oldArray[offset1 + 2*x + 0];
            float4 x1 = oldArray[offset1 + 2*x + 1];
            float4 x2 = oldArray[offset2 + 2*x + 0];
            float4 x3 = oldArray[offset2 + 2*x + 1];

            newArray[y*m_width + x] = 0.25f*(x0 + x1 + x2 + x3);
          }
        }
      }

    }

    int bpp() const {return m_elemByteSize;}
    int width() const {return m_width;}
    int height() const {return m_height;}

  protected:

    std::vector<unsigned char> m_data;
    int m_width;
    int m_height;
    int m_elemByteSize;
  };

  class MegaTexStorageProxy : public ImageStorage
  {
    typedef ImageStorage Base;
  public:

    MegaTexStorageProxy(const char* usage, const unsigned char* data, int w, int h, int byteSize, const std::vector<float>& a_lut);
    ~MegaTexStorageProxy();

    const void* GetConstData() const;
    void* GetData();
    void SetData(const unsigned char* data, int w, int h, int byteSize);
    void FreeData();

    inline const std::vector<float>& GetLut() const {return m_lut;}
    inline const int bpp() {return m_bpp;}

    uint  totalBytes;
    float unusedBytes;

  protected:

    std::vector<float> m_lut;
    std::string m_filename;
    mutable bool savedToFile;
    int m_byteSize;
    int m_bpp;
  };

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////

  void AddVertexPositionsFromInputDataSet(int a_maxVertices);
  void AddVertexNormalsFromInputDataSet(int a_maxVertices);
  void AddVertexTexCoordsFromInputDataSet(int a_maxVertices);

  void ExtractVertexMatIndicesFromInputDataSet(int a_maxVertices, std::vector<int>& vertMaterialIds);

  void CalcTangentSpace();

  virtual void DrawLights();
  virtual void VerifyData();
  virtual void VerifyAllData();

  static void PlaneHammersley(float *result, int n);
  static float3 MapToHemiSphere(float r1, float r2);
  void CreateSphericalDistribution(std::vector<float4>& a_sphereUniform, int N, bool cosine = true);

  void PrecomputeSHCoeffs(std::vector<float>& out_coeffs);

  VoxelStorage<float4> m_voxelData; //x,y,z - color, w - opacity
  VoxelStorage<float4> m_radiancePos; //x,y,z - radiance along {x,y,z} axis in positive direction
  VoxelStorage<float4> m_radianceNeg; //x,y,z - radiance along {x,y,z} axis in negative direction

  VoxelStorage<float4>& VoxelizeAllGeometry();
  void VoxelizeAllSpheres();
  void VoxelizeAllTriangles();

  float m_worldViewMatrixData[16];
  float m_projectionMatrixData[16];

  float m_worldViewInvMatrixData[16];
  float m_projectInvMatrixData[16];

	int	  width;
	int		height;
  int   m_initFlags;
  float4 m_projParams;

  std::vector<RAYTR::HydraMaterial> m_hydraMaterials;
  std::vector<RAYTR::Light>         m_lights;
  std::vector<ImageStorage>         m_images;

  std::vector<Sphere4f>            m_spheres;
  std::vector<float4>              m_vertPos;
  std::vector<float4>              m_vertNorm;
  std::vector<float4>              m_vertTangent;

  std::vector<float2>              m_vertTexCoord;
  std::vector<uint>                m_index;
  std::vector<uint>                m_triangleMaterialId;

  std::vector<Matrix4x4f>          m_texMatrices;

  //////////////////////////////////////////////////////////////////
  IBVHBuilder*             m_pBVHBuilder;
  BvhOutData               m_bvhGlobal;
  std::vector<char>        m_bvhObjListData;
  //////////////////////////////////////////////////////////////////

  std::string m_geomMD5;
  std::string m_lightsMD5;
  
  bool LoadBVHCache(const std::string& a_path, const std::string& a_geomMD5, const std::string& a_lightsMD5);
  void UpdateBVHCache(const std::string& a_path, const std::string& a_geomMD5, const std::string& a_lightsMD5);

  void* m_vertAttr[MAX_VERTEX_ATTRIBUTES];
  RTE_PROGRESSBAR_CALLBACK m_updateProgressCall;
  RTE_UPDATEIMAGE_CALLBACK m_updateImageCall;

  int m_currInputLayout;
  float m_gatherRadius;

  bool m_lightsWasAddedAsGeometry;

  std::vector<float4> m_sphereUniformArray[HEMISPHERE_SEQUENCE_NUM];
  std::vector<float4> m_sphereUniformArray2[HEMISPHERE_SEQUENCE_NUM];
  //std::vector<float4> m_cubeUniformArray[HEMISPHERE_SEQUENCE_NUM];

  std::vector<float>   m_shCoeffsArray;
  int m_shResPhi;
  int m_shResTheta;
  int m_sphLayersNum;

  Matrix4x4f m_addTrianglesLastMat;

  AABB3f m_bBox;
  AABB3f m_regularBBox;

  bool  m_dirtyHydraMaterials;
  bool  m_dirtyLights;
  bool  m_dataVerifyed;
  bool  m_accelStructuresDirty;
  bool  m_debugOutput;
  bool  m_voxelizeOnLoad;

  RenderSettings m_lastRenderState;

  RTE_HashMapI m_ivars;
  RTE_HashMapF m_fvars;
  RTE_HashMapS m_svars;

  float gl_ver;
};


