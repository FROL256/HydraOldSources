#include "Common_Graphics_Engine.h"
#include "Rasterizer.h"
#include "Voxelizer.h"
#include "VoxelizerGPU.h"

struct VoxelData // for Anton and his custom needs
{
  enum {EMPTY = 1};

  VoxelData() { m_flags = EMPTY;}
  bool Empty() const { return (m_flags & EMPTY);}
 
  int m_flags; // please use bit fields, either 'bit flags' to store boolean values
};



typedef unsigned char uint8;


static float4 DownSampler(float4 data[8])
{
  float4 res;
  res.x = res.y = res.z = res.w = 0.f;

  for (int i = 0; i < 8; i++)
    res += data[i];

  return res / 8;
}


static inline float3 PointEpsilon(const float3 u) { return make_float3( 1e-5f*fmax(abs(u.x), 1.0f), 
                                                                        1e-5f*fmax(abs(u.y), 1.0f), 
                                                                        1e-5f*fmax(abs(u.z), 1.0f)
                                                                      ); 
                                                  }

VoxelStorage<float4>& Common_Graphics_Engine::VoxelizeAllGeometry()
{
  std::cout << "voxelization has begun ..." << std::endl;
  
  AABB3f twickedBox = AABB3f(m_bBox.vmin - PointEpsilon(m_bBox.vmin),  m_bBox.vmax + PointEpsilon(m_bBox.vmax));

  int voxelResolution = 128;

  m_voxelData.Resize(voxelResolution,voxelResolution,voxelResolution);
  m_radiancePos.Resize(voxelResolution,voxelResolution,voxelResolution);
  m_radianceNeg.Resize(voxelResolution,voxelResolution,voxelResolution);
  
  m_voxelData.SetBoundingBox(twickedBox);
  m_radiancePos.SetBoundingBox(twickedBox);
  m_radianceNeg.SetBoundingBox(twickedBox);

  Array3D<float4>& voxels = m_voxelData.GetArrayMipLevel(0);

  for(int x=0;x<voxels.size().x;x++)
    for(int y=0;y<voxels.size().y;y++)
      for(int z=0;z<voxels.size().z;z++)
        voxels(x,y,z).x = voxels(x,y,z).y = voxels(x,y,z).z = voxels(x,y,z).w = 0.f;

  //VoxelizeAllSpheres();
  //Timer voxelizeTimer(true);

  //float voxelizeStartTime = voxelizeTimer.getElapsed();
  //VoxelizeAllTriangles();
  //float voxelizeStopTime = voxelizeTimer.getElapsed();
  //std::cout << "voxelization time: " << (voxelizeStopTime - voxelizeStartTime) << "s" << std::endl;
  //m_voxelData.GenerateMips(DownSampler);
  //m_voxelData.SaveToFiles("boxes");
  //return m_voxelData;

  std::cout << "gpu voxelizer start .." << std::endl;

  // gpu path
  //
  agv::IVoxelStorageGPU* pVoxelStorageGPU = agv::CreateVoxelStorage("AntonVoxelizer");
  //agv::IVoxelStorageGPU* pVoxelStorageGPU = agv::CreateVoxelStorage("OctreeVoxelStorageGPU");

  AABB3f voxelBBox = m_voxelData.GetBoundingBox();
  pVoxelStorageGPU->SetVoxelBox(voxelBBox.vmin, voxelBBox.vmax, voxels.size().x);
  
  float3 *triangles = new float3[m_index.size()];
  for (size_t i = 0; i < m_index.size(); i++) {
    triangles[i] = to_float3(GetVertexPos(m_index[i]));
  }

  pVoxelStorageGPU->SetTriangleMesh(triangles, m_index.size());
 
  
  Timer gpuVoxelizeTimer(true);

  pVoxelStorageGPU->VoxelizeTriangles();
  hrtThreadSynchronize();

  float voxelizeStopTime = gpuVoxelizeTimer.getElapsed();
  std::cout << "voxelization time: " << voxelizeStopTime << "s" << std::endl;
  
  int *voxelsGPU = pVoxelStorageGPU->GetVoxels();
  for (int x = 0; x < voxels.size().x; x++)
    for (int y = 0; y < voxels.size().y; y++)
      for (int z = 0; z < voxels.size().z; z++) 
      {
        voxels(x,y,z).w = (float)voxelsGPU[z * voxels.size().x * voxels.size().y + y * voxels.size().x + x];
      }

  delete[] voxelsGPU;

  agv::ReleaseVoxelStorage(pVoxelStorageGPU);

  m_voxelData.GenerateMips(DownSampler);
  m_voxelData.SaveToFiles("boxes");

  std::cout << "gpu voxelizer finish..." << std::endl;

  return m_voxelData;
}

template<class Data>
void RasterizeSphereTo3DArray(const Sphere4f& a_sph, VoxelStorage<Data>& voxelStorage)
{
  AABB3f box = voxelStorage.GetBoundingBox();

  Array3D<float4>& voxels = voxelStorage.GetArrayMipLevel(0);

  float3 spherePos   = to_float3(a_sph.pos);
  float  sphereRadius = a_sph.r;

  float3 sphBBoxVmin = spherePos - float3(a_sph.r, a_sph.r, a_sph.r);
  float3 sphBBoxVmax = spherePos + float3(a_sph.r, a_sph.r, a_sph.r);

  float3 t1 = (sphBBoxVmin - box.vmin)/(box.vmax-box.vmin);
  float3 t2 = (sphBBoxVmax - box.vmin)/(box.vmax-box.vmin);

  float3   startVoxelf = t1*float3(voxels.size().x, voxels.size().y, voxels.size().z);
  float3   endVoxelf   = t2*float3(voxels.size().x, voxels.size().y, voxels.size().z);

  int3     startVoxel = int3(startVoxelf.x, startVoxelf.y, startVoxelf.z);
  int3     endVoxel   = int3(endVoxelf.x+0.5f, endVoxelf.y+0.5f,   endVoxelf.z+0.5f);

  float voxelSize = (box.vmax.x - box.vmin.x)/float(voxels.size().x);

  for(int x=startVoxel.x; x<=endVoxel.x; x++)
  {
    for(int y=startVoxel.y; y<=endVoxel.y; y++)
    {
      for(int z=startVoxel.z; z<=endVoxel.z; z++)
      {
        AABB3f voxelBox;

        voxelBox.vmin = float3( box.vmin.x + x*voxelSize, box.vmin.y + y*voxelSize, box.vmin.z + z*voxelSize);
        voxelBox.vmax = voxelBox.vmin + 1.0f*float3(voxelSize,voxelSize,voxelSize);

        if(length(voxelBox.vmin - spherePos) < sphereRadius && length(voxelBox.vmax - spherePos) < sphereRadius)
          ;
        else if(MGML_MATH::Intersect<AABB3f, Sphere3f>::exec(voxelBox, Sphere3f(spherePos, sphereRadius)) )
          voxels(x,y,z) = float4(0,0,0,1);

      }
    }
  }

}



void Common_Graphics_Engine::VoxelizeAllSpheres()
{
  for(int sphId = 0; sphId < m_spheres.size(); sphId++)
    RasterizeSphereTo3DArray<float4>(m_spheres[sphId], m_voxelData);
}


typedef MGML_MATH::TRIANGLE<2, float> ProjectedTriangle;
typedef MGML_MATH::TRIANGLE<3,float> MyTriangle;

// slow implementation, waiting for Anton's fast rasterizer
//
template<class Data>
void RasterizeTriangleTo3DArray(const float3& A, const float3& B, const float3& C, VoxelStorage<Data>& voxelStorage)
{
  AABB3f box = voxelStorage.GetBoundingBox();

  Array3D<float4>& voxels = voxelStorage.GetArrayMipLevel(0);

  float voxelSize = (box.vmax.x - box.vmin.x)/float(voxels.size().x);
  
  AABB3f triBox;
  triBox.include(A);
  triBox.include(B);
  triBox.include(C);

  MyTriangle tri(A,B,C);

  float3 t1 = (triBox.vmin - box.vmin)/(box.vmax-box.vmin);
  float3 t2 = (triBox.vmax - box.vmin)/(box.vmax-box.vmin);

  float3   startVoxelf = t1*float3(voxels.size().x, voxels.size().y, voxels.size().z);
  float3   endVoxelf   = t2*float3(voxels.size().x, voxels.size().y, voxels.size().z);

  int3     startVoxel = int3(startVoxelf.x, startVoxelf.y, startVoxelf.z);
  int3     endVoxel   = int3(endVoxelf.x+0.5f, endVoxelf.y+0.5f,   endVoxelf.z+0.5f);


  for(int x=startVoxel.x; x<=endVoxel.x; x++)
  {
    for(int y=startVoxel.y; y<=endVoxel.y; y++)
    {
      for(int z=startVoxel.z; z<=endVoxel.z; z++)
      {
        AABB3f voxelBox;

        voxelBox.vmin = float3( box.vmin.x + x*voxelSize, box.vmin.y + y*voxelSize, box.vmin.z + z*voxelSize);
        voxelBox.vmax = voxelBox.vmin + 1.0f*float3(voxelSize,voxelSize,voxelSize);

        if(MGML_MATH::Intersect<AABB3f,AABB3f>::exec(triBox,voxelBox))
          if(MGML_MATH::Intersect<AABB3f,MyTriangle>::exec(voxelBox,tri))
            voxels(x,y,z) = float4(0,0,0,1);
      }
    }
  }

}

//voxelization through rasterization
//
enum Axis {X_AXIS, Y_AXIS, Z_AXIS};

static std::pair<ProjectedTriangle, Axis> BestProjection(const MyTriangle& tr)
{
  ProjectedTriangle tr_projected;

  MGML::vec3f tr_normal = cross(tr.A, tr.B);

  float x_projection = abs(tr_normal.x),
    y_projection = abs(tr_normal.y),
    z_projection = abs(tr_normal.z);

  if (x_projection > y_projection) {
    if (z_projection > x_projection) {
      tr_projected.A.x = tr.A.x;
      tr_projected.A.y = tr.A.y;
      tr_projected.B.x = tr.B.x;
      tr_projected.B.y = tr.B.y;
      tr_projected.C.x = tr.C.x;
      tr_projected.C.y = tr.C.y;
      return std::make_pair(tr_projected, Z_AXIS);
    } else {
      tr_projected.A.x = tr.A.y;
      tr_projected.A.y = tr.A.z;
      tr_projected.B.x = tr.B.y;
      tr_projected.B.y = tr.B.z;
      tr_projected.C.x = tr.C.y;
      tr_projected.C.y = tr.C.z;
      return std::make_pair(tr_projected, X_AXIS);
    }
  } else {
    if (z_projection > y_projection) {
      tr_projected.A.x = tr.A.x;
      tr_projected.A.y = tr.A.y;
      tr_projected.B.x = tr.B.x;
      tr_projected.B.y = tr.B.y;
      tr_projected.C.x = tr.C.x;
      tr_projected.C.y = tr.C.y;
      return std::make_pair(tr_projected, Z_AXIS);
    } else {
      tr_projected.A.x = tr.A.x;
      tr_projected.A.y = tr.A.z;
      tr_projected.B.x = tr.B.x;
      tr_projected.B.y = tr.B.z;
      tr_projected.C.x = tr.C.x;
      tr_projected.C.y = tr.C.z;
      return std::make_pair(tr_projected, Y_AXIS);
    }
  }
}

int3 MapToVoxelBox(float x, float y, float z, AABB3f bbox, int boxResX, int boxResY, int boxResZ)
{
  return int3((int)((x - bbox.vmin.x) * boxResX / (bbox.vmax.x - bbox.vmin.x)),
              (int)((y - bbox.vmin.y) * boxResY / (bbox.vmax.y - bbox.vmin.y)),
              (int)((z - bbox.vmin.z) * boxResZ / (bbox.vmax.z - bbox.vmin.z)));
}

template <class Data>
void RasterizeTriangleTo3DArrayFast(const float3& A, const float3& B, const float3& C, VoxelStorage<Data>& voxelStorage)
{
  AABB3f box = voxelStorage.GetBoundingBox();

  Array3D<float4>& voxels = voxelStorage.GetArrayMipLevel(0);

  float voxelSizeX = (box.vmax.x - box.vmin.x)/float(voxels.size().x);
  float voxelSizeY = (box.vmax.y - box.vmin.y)/float(voxels.size().y);
  float voxelSizeZ = (box.vmax.z - box.vmin.z)/float(voxels.size().z);

  static Rasterizer rasterizer;

  std::pair<ProjectedTriangle, Axis> triangle_axis_pair = BestProjection(MyTriangle(A, B, C));
  rasterizer.setTriangle(PointF(triangle_axis_pair.first.A.x, triangle_axis_pair.first.A.y),
                         PointF(triangle_axis_pair.first.B.x, triangle_axis_pair.first.B.y),
                         PointF(triangle_axis_pair.first.C.x, triangle_axis_pair.first.C.y));
  switch (triangle_axis_pair.second) {
    case X_AXIS:
      rasterizer.setResolution(SizeF(voxelSizeY, voxelSizeZ));
      break;
    case Y_AXIS:
      rasterizer.setResolution(SizeF(voxelSizeX, voxelSizeZ));
      break;
    case Z_AXIS:
      rasterizer.setResolution(SizeF(voxelSizeX, voxelSizeY));
      break;
    default:
      break;
  }
  std::vector<Point>* pixels = rasterizer.rasterize();

  //plane equation coefficients
  float plane_A = A.y * (B.z - C.z) + B.y * (C.z - A.z) + C.y * (A.z - B.z);
  float plane_B = A.z * (B.x - C.x) + B.z * (C.x - A.x) + C.z * (A.x - B.x);
  float plane_C = A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y);
  float minus_plane_D = A.x * (B.y * C.z - B.z * C.y) + B.x * (C.y * A.z - C.z * A.y) + C.x * (A.y * B.z - A.z * B.y);

  switch (triangle_axis_pair.second) {
    case X_AXIS:
      for (std::vector<Point>::iterator i = pixels->begin(); i < pixels->end(); ++i) {
        float x = (minus_plane_D - plane_B * (voxelSizeY * (.5f + (float)i->x())) - plane_C * (voxelSizeZ * (.5f + (float)i->y()))) / plane_A;
        int3 coords = MapToVoxelBox(x, (float)i->x() + voxelSizeY / 2, (float)i->y() + voxelSizeZ / 2, box, voxels.size().x, voxels.size().y, voxels.size().z);
        voxels(coords.x, coords.y, coords.z) = float4(0,0,0,1);
      }
      break;
    case Y_AXIS:
      for (std::vector<Point>::iterator i = pixels->begin(); i < pixels->end(); ++i) {
        float y = (minus_plane_D - plane_A * (voxelSizeX * (.5f + (float)i->x())) - plane_C * (voxelSizeZ * (.5f + (float)i->y()))) / plane_B;
        int3 coords = MapToVoxelBox((float)i->x() + voxelSizeX / 2, y, (float)i->y() + voxelSizeZ / 2, box, voxels.size().x, voxels.size().y, voxels.size().z);
        voxels(coords.x, coords.y, coords.z) = float4(0,0,0,1);
      }
      break;
    case Z_AXIS:
      for (std::vector<Point>::iterator i = pixels->begin(); i < pixels->end(); ++i) {
        float z = (minus_plane_D - plane_A * (voxelSizeX * (.5f + (float)i->x())) - plane_B * (voxelSizeY * (.5f + (float)i->y()))) / plane_C;
        int3 coords = MapToVoxelBox((float)i->x() + voxelSizeX / 2, (float)i->y() + voxelSizeY / 2, z, box, voxels.size().x, voxels.size().y, voxels.size().z);
        voxels(coords.x, coords.y, coords.z) = float4(0,0,0,1);
      }
      break;
    default:
      break;
  }

  delete pixels;
}

void Common_Graphics_Engine::VoxelizeAllTriangles()
{
  std::cout <<"here 1" << std::endl;

  for(int triOffs = 0; triOffs < m_index.size(); triOffs+=3)
  {
    int iA = m_index[triOffs+0];
    int iB = m_index[triOffs+1];
    int iC = m_index[triOffs+2];

    float3 A = to_float3(GetVertexPos(iA));
    float3 B = to_float3(GetVertexPos(iB));
    float3 C = to_float3(GetVertexPos(iC));

    RasterizeTriangleTo3DArray<float4>(A,B,C,m_voxelData);
  }

   std::cout <<"here 1" << std::endl;
}


