#ifndef RTCLIGHT
#define RTCLIGHT

#include "globals.h"


enum PLAIN_LIGHT_TYPES {
  PLAIN_LIGHT_TYPE_POINT_OMNI   = 0,
  PLAIN_LIGHT_TYPE_POINT_SPOT   = 1,
  PLAIN_LIGHT_TYPE_DIRECT       = 2,
  PLAIN_LIGHT_TYPE_SKY_DOME     = 3,
  PLAIN_LIGHT_TYPE_AREA_DIFFUSE = 4,
  PLAIN_LIGHT_TYPE_AREA_SPOT    = 5,
  PLAIN_LIGHT_TYPE_DISK_DIFFUSE = 5,
  PLAIN_LIGHT_TYPE_DISK_SPOT    = 6,
  PLAIN_LIGHT_TYPE_SPHERE       = 7,
  PLAIN_LIGHT_TYPE_MESH         = 8,

};

enum PLAIN_LIGHT_FLAGS{
  DUMMY_FLAG = 1,
};


#define LIGHT_DATA_SIZE 32

struct PlainLightT
{
  float data[LIGHT_DATA_SIZE];
};

typedef struct PlainLightT PlainLight;


typedef struct ShadowSampleT
{

  float3 pos;
  float3 color;
  float  pdf;
  float  maxDist;

} ShadowSample;


#define PLIGHT_TYPE  0
#define PLIGHT_FLAGS 1

#define PLIGHT_POS_X 2
#define PLIGHT_POS_Y 3
#define PLIGHT_POS_Z 4

#define PLIGHT_NORM_X 5
#define PLIGHT_NORM_Y 6
#define PLIGHT_NORM_Z 7

#define PLIGHT_COLOR_X 8
#define PLIGHT_COLOR_Y 9
#define PLIGHT_COLOR_Z 10

#define PLIGHT_COLOR_TEX        11
#define PLIGHT_COLOR_TEX_MATRIX 12

#define PLIGHT_SURFACE_AREA     13

#define AREA_LIGHT_SIZE_X       14
#define AREA_LIGHT_SIZE_Y       15

#define AREA_LIGHT_MATRIX_E00   16
#define AREA_LIGHT_MATRIX_E01   17
#define AREA_LIGHT_MATRIX_E02   18
#define AREA_LIGHT_MATRIX_E10   19
#define AREA_LIGHT_MATRIX_E11   20
#define AREA_LIGHT_MATRIX_E12   21
#define AREA_LIGHT_MATRIX_E20   22
#define AREA_LIGHT_MATRIX_E21   23
#define AREA_LIGHT_MATRIX_E22   24



ID_CALL float areaDiffuseLightEvalPDF(__constant PlainLight* pLight, float3 rayDir, float hitDist)
{

  float3 lightNorm = make_float3(pLight->data[PLIGHT_NORM_X], pLight->data[PLIGHT_NORM_Y], pLight->data[PLIGHT_NORM_Z]);
  float pdfA       = 1.0f / pLight->data[PLIGHT_SURFACE_AREA];
  float cosVal     = fmax(dot(rayDir, -1.0f*lightNorm), 0.0f);

  return PdfAtoW(pdfA, hitDist, cosVal);
}

ID_CALL float3 areaDiffuseLightGetIntensity(__constant PlainLight* pLight, float2 a_texCoord)
{
  return make_float3(pLight->data[PLIGHT_COLOR_X], pLight->data[PLIGHT_COLOR_Y], pLight->data[PLIGHT_COLOR_Z]);
}


ID_CALL ShadowSample areaDiffuseLightSample(__constant PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  float offsetX = rands.x * 2.0f - 1.0f;
  float offsetY = rands.y * 2.0f - 1.0f;

  float3 samplePos;

  samplePos.x = offsetX*pLight->data[AREA_LIGHT_SIZE_X];
  samplePos.y = 0.0f;
  samplePos.z = offsetY*pLight->data[AREA_LIGHT_SIZE_Y];

  //
  // transform with rotation matrix
  //

  //
  //
  samplePos = samplePos + make_float3(pLight->data[PLIGHT_POS_X], pLight->data[PLIGHT_POS_Y], pLight->data[PLIGHT_POS_Z]);

  float3 rayDir = normalize(samplePos - illuminatingPoint);
  float hitDist = length(samplePos - illuminatingPoint);
 
  ShadowSample res;

  res.pos       = samplePos;
  res.color     = areaDiffuseLightGetIntensity(pLight, make_float2(rands.x, rands.y));
  res.pdf       = areaDiffuseLightEvalPDF(pLight, rayDir, hitDist);
  res.maxDist   = hitDist;

  return res;
}





ID_CALL ShadowSample lightSample(__constant PlainLight* pLight, float4 rands, float3 illuminatingPoint)
{
  return areaDiffuseLightSample(pLight, rands, illuminatingPoint);
}


ID_CALL float lightEvalPDF(__constant PlainLight* pLight, float3 rayDir, float hitDist)
{
  return areaDiffuseLightEvalPDF(pLight, rayDir, hitDist);
}

ID_CALL float3 lightGetIntensity(__constant PlainLight* pLight, float2 a_texCoord)
{
  return areaDiffuseLightGetIntensity(pLight, a_texCoord);
}





#endif

