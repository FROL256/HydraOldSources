#include "GPUOCLLayer.h"
#include "crandom.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void GPUOCLLayer::CL_SCREEN_BUFFERS::free()
{

  for (auto i = 0; i < subBuffersNum; i++)
  {
    if (colorSubBuffers[i]) clReleaseMemObject(colorSubBuffers[i]);
    colorSubBuffers[i] = 0;
  }

  if (ptColorSummBuff)       clReleaseMemObject(ptColorSummBuff);
  if (ptColorSummSquareBuff) clReleaseMemObject(ptColorSummSquareBuff);
  if (xyCoord)               clReleaseMemObject(xyCoord);
  if (pbo)                   clReleaseMemObject(pbo);

  if (zblocks)               clReleaseMemObject(zblocks);

  ptColorSummBuff       = 0;
  ptColorSummSquareBuff = 0;
  xyCoord               = 0;
  pbo                   = 0;
  zblocks               = 0;
}


void GPUOCLLayer::CL_BUFFERS_RAYS::free()
{
  if(rayPos)   clReleaseMemObject(rayPos);
  if(rayDir)   clReleaseMemObject(rayDir);
  if(hits)     clReleaseMemObject(hits);
  if(rayFlags) clReleaseMemObject(rayFlags);

  if (hitPosNorm)  clReleaseMemObject(hitPosNorm);
  if (hitTexCoord) clReleaseMemObject(hitTexCoord);
  if (hitMatId)    clReleaseMemObject(hitMatId);
  if (hitTangent)  clReleaseMemObject(hitTangent);
  if (hitFlatNorm) clReleaseMemObject(hitFlatNorm);

  if (pathThoroughput) clReleaseMemObject(pathThoroughput);
  if (pathMisDataPrev) clReleaseMemObject(pathMisDataPrev);
  if (pathShadeColor)  clReleaseMemObject(pathShadeColor);
  if (pathIrradColor)  clReleaseMemObject(pathIrradColor);

  if (pathTempColor)   clReleaseMemObject(pathTempColor);
  if (randGenState)    clReleaseMemObject(randGenState);

  rayPos = 0;
  rayDir = 0;
  hits   = 0;
  rayFlags = 0;

  hitPosNorm  = 0;
  hitTexCoord = 0;
  hitMatId    = 0;
  hitTangent  = 0;
  hitFlatNorm = 0;

  pathThoroughput = 0;
  pathMisDataPrev = 0;
  pathShadeColor  = 0;
  pathIrradColor  = 0;

  pathTempColor   = 0;
  randGenState    = 0;

}

void GPUOCLLayer::CL_BUFFERS_RAYS::resize(cl_context ctx, cl_command_queue cmdQueue, size_t a_size)
{
  free();

  cl_int ciErr1;

  MEGABLOCKSIZE = a_size; // /2
  rayPos   = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4*sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  rayDir   = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4*sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  hits     = clCreateBuffer(ctx, CL_MEM_READ_WRITE, sizeof(Lite_Hit)*MEGABLOCKSIZE,   NULL, &ciErr1);
  rayFlags = clCreateBuffer(ctx, CL_MEM_READ_WRITE, sizeof(uint)*MEGABLOCKSIZE,       NULL, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in resize rays buffers");

  hitPosNorm  = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4 * sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  hitTexCoord = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 2 * sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  hitMatId    = clCreateBuffer(ctx, CL_MEM_READ_WRITE, sizeof(HitMatRef)*MEGABLOCKSIZE, NULL, &ciErr1);
  hitTangent  = clCreateBuffer(ctx, CL_MEM_READ_WRITE, sizeof(Hit_Part4)*MEGABLOCKSIZE, NULL, &ciErr1);
  hitFlatNorm = clCreateBuffer(ctx, CL_MEM_READ_WRITE, sizeof(uint)*MEGABLOCKSIZE, NULL, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in resize rays buffers");

  pathThoroughput = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4 * sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  pathMisDataPrev = clCreateBuffer(ctx, CL_MEM_READ_WRITE,     sizeof(MisData) *MEGABLOCKSIZE, NULL, &ciErr1);
  pathShadeColor  = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4 * sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  pathIrradColor  = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4 * sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in resize rays buffers");

  pathTempColor = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 4 * sizeof(cl_float)*MEGABLOCKSIZE, NULL, &ciErr1);
  randGenState  = clCreateBuffer(ctx, CL_MEM_READ_WRITE, 1 * sizeof(RandomGen)*MEGABLOCKSIZE, NULL, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in resize rays buffers");
}

void GPUOCLLayer::CL_SCENE_DATA::free()
{
  if (bvhBuff)     clReleaseMemObject(bvhBuff);
  if (objListBuff) clReleaseMemObject(objListBuff);

  if (vertNormsCompressed) clReleaseMemObject(vertNormsCompressed);
  if (vertTexCoord)        clReleaseMemObject(vertTexCoord);
  if (vertIndices)         clReleaseMemObject(vertIndices);

  if (materialData)    clReleaseMemObject(materialData);
  if (materialOffsets) clReleaseMemObject(materialOffsets);

  if (lightData)       clReleaseMemObject(lightData);

  bvhBuff = 0;
  objListBuff = 0;

  vertNormsCompressed = 0;
  vertTexCoord = 0;
  vertIndices = 0;

  materialData    = 0;
  materialOffsets = 0;
  lightData       = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


GPUOCLLayer::GPUOCLLayer(int w, int h, int a_flags)
{ 
  m_flags = a_flags;

  CHECK_CL(clGetPlatformIDs(1, &m_globals.platform, NULL));
  CHECK_CL(clGetDeviceIDs(m_globals.platform, CL_DEVICE_TYPE_GPU, 1, &m_globals.device, NULL));

  cl_int ciErr1;
 
  if (a_flags & GPU_RT_NOWINDOW)
    m_globals.ctx = clCreateContext(0, 1, &m_globals.device, NULL, NULL, &ciErr1);
  else
  {
    cl_context_properties properties[] = {
      CL_GL_CONTEXT_KHR,   (cl_context_properties)wglGetCurrentContext(), // WGL Context
      CL_WGL_HDC_KHR,      (cl_context_properties)wglGetCurrentDC(),      // WGL HDC
      CL_CONTEXT_PLATFORM, (cl_context_properties)m_globals.platform,     // OpenCL platform
      0
    };

    m_globals.ctx = clCreateContext(properties, 1, &m_globals.device, NULL, NULL, &ciErr1);
  }

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in clCreateContext");

  m_globals.cmdQueue = clCreateCommandQueue(m_globals.ctx, m_globals.device, 0, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in clCreateCommandQueue");

  initCLExtensions(m_globals.device);

  //
  //
  std::string optionsGeneral = "-cl-mad-enable -cl-no-signed-zeros -cl-single-precision-constant -cl-denorms-are-zero "; // -cl-uniform-work-group-size 
  std::string optionsInclude = "-I '../gpu_rt' -D OCL_COMPILER"; // put function that will find shader include folder

  std::string options = optionsGeneral + optionsInclude;

  std::cout << "[cl_core]: building cl programs ..." << std::endl;

  m_progs.screen = CLProgram(m_globals.device, m_globals.ctx, "shaders\\screen.cl", options.c_str());
  m_progs.trace  = CLProgram(m_globals.device, m_globals.ctx, "shaders\\trace.cl", options.c_str());

  std::cout << "[cl_core]: build cl programs complete" << std::endl;

  ResizeScreen(w, h, a_flags);

  m_globals.cMortonTable = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, sizeof(MortonTable256), MortonTable256, &ciErr1);   if (ciErr1 != CL_SUCCESS) RUN_TIME_ERROR("Error in clCreateBuffer");
  m_globals.cVarsIF      = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY, GMAXVARS*2*sizeof(int), NULL, &ciErr1);                                    if (ciErr1 != CL_SUCCESS) RUN_TIME_ERROR("Error in clCreateBuffer");

  cl_buffer_region info1, info2;
  
  info1.origin = 0;
  info1.size   = sizeof(int)*GMAXVARS;

  info2.origin = sizeof(int)*GMAXVARS;
  info2.size   = sizeof(float)*GMAXVARS;

  m_globals.cVarsI = clCreateSubBuffer(m_globals.cVarsIF, CL_MEM_READ_ONLY, CL_BUFFER_CREATE_TYPE_REGION, &info1, &ciErr1); if (ciErr1 != CL_SUCCESS) RUN_TIME_ERROR("Error in clCreateBuffer");
  m_globals.cVarsF = clCreateSubBuffer(m_globals.cVarsIF, CL_MEM_READ_ONLY, CL_BUFFER_CREATE_TYPE_REGION, &info2, &ciErr1); if (ciErr1 != CL_SUCCESS) RUN_TIME_ERROR("Error in clCreateBuffer");
 
}


GPUOCLLayer::~GPUOCLLayer()
{
  m_scene.free();
  m_screen.free();
  m_rays.free();

  if(m_globals.cVarsF)       clReleaseMemObject(m_globals.cVarsF);
  if(m_globals.cVarsI)       clReleaseMemObject(m_globals.cVarsI);
  if(m_globals.cVarsIF)      clReleaseMemObject(m_globals.cVarsIF);
  if(m_globals.cMortonTable) clReleaseMemObject(m_globals.cMortonTable);

  if(m_globals.cmdQueue) clReleaseCommandQueue(m_globals.cmdQueue);
  if(m_globals.ctx)      clReleaseContext(m_globals.ctx);
}


void GPUOCLLayer::memsetu32(cl_mem buff, uint a_val, size_t a_size)
{
  cl_kernel kern = m_progs.screen.kernel("MemSetu32");

  size_t szLocalWorkSize = 256;
  cl_int iNumElements = cl_int(a_size);

  CHECK_CL(clSetKernelArg(kern, 0, sizeof(cl_mem),  (void*)&buff));
  CHECK_CL(clSetKernelArg(kern, 1, sizeof(cl_uint), (void*)&a_val));
  CHECK_CL(clSetKernelArg(kern, 2, sizeof(cl_int),  (void*)&iNumElements));
 
  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kern, 1, NULL, &a_size, &szLocalWorkSize, 0, NULL, NULL));
}

void GPUOCLLayer::memsetf4(cl_mem buff, float4 a_val, size_t a_size)
{
  cl_kernel kern = m_progs.screen.kernel("MemSetf4");

  size_t szLocalWorkSize = 256;
  cl_int iNumElements    = cl_int(a_size);

  CHECK_CL(clSetKernelArg(kern, 0, sizeof(cl_mem),    (void*)&buff));
  CHECK_CL(clSetKernelArg(kern, 1, sizeof(cl_float4), (void*)&a_val));
  CHECK_CL(clSetKernelArg(kern, 2, sizeof(cl_int),    (void*)&iNumElements));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kern, 1, NULL, &a_size, &szLocalWorkSize, 0, NULL, NULL));
}


void GPUOCLLayer::ResizeScreen(int width, int height, int a_flags)
{
  m_screen.free();

  //
  //
  cl_int ciErr1;

  m_screen.ptColorSummBuff       = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE, 4*sizeof(cl_float)*width*height, NULL, &ciErr1);
  m_screen.ptColorSummSquareBuff = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE, 4*sizeof(cl_float)*width*height, NULL, &ciErr1);
  m_screen.xyCoord               = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE, sizeof(cl_ushort2)*width*height, NULL, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("[cl_core]: Failed to create cl full screen color buffers ");

  m_screen.zblocks = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE, sizeof(ZBlock)*(width*height) / ZBlock::GetSize(), NULL, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("[cl_core]: Failed to create cl full screen zblocks buffer ");

  if (m_flags & GPU_RT_NOWINDOW)
    m_screen.pbo = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE, sizeof(cl_uint)*m_width*m_height, NULL, &ciErr1);

  m_width  = width;
  m_height = height;

  size_t memAmount      = GetAvaliableMemoryAmount(true);
  size_t MEGABLOCK_SIZE = calcMegaBlockSize(m_width, m_height, memAmount);
  
  if (a_flags & GPU_RT_MEMORY_FULL_SIZE_MODE)
    MEGABLOCK_SIZE = m_width*m_height;

  cl_buffer_region info1;

  info1.origin = 0;
  info1.size   = MEGABLOCK_SIZE*sizeof(float4);

  m_screen.subBuffersNum = (m_width*m_height) / MEGABLOCK_SIZE;

  if((m_screen.subBuffersNum*MEGABLOCK_SIZE) < (m_width*m_height))
    m_screen.subBuffersNum++;

  for (auto i = 0; i < m_screen.subBuffersNum; i++)
  { 
    if ((info1.origin + info1.size) > (m_width*m_height)*sizeof(float4))
      info1.size = m_width*m_height*sizeof(float4) - info1.origin;

    m_screen.colorSubBuffers[i] = clCreateSubBuffer(m_screen.ptColorSummBuff, CL_MEM_READ_WRITE, CL_BUFFER_CREATE_TYPE_REGION, &info1, &ciErr1);

    if (ciErr1 != CL_SUCCESS) 
      RUN_TIME_ERROR("Error in clCreateBuffer");

    info1.origin += info1.size;
  }

  memsetf4(m_screen.ptColorSummBuff, float4(0, 0, 0, 0), m_width*m_height);
  memsetf4(m_screen.ptColorSummSquareBuff, float4(0, 0, 0, 0), m_width*m_height);
  memsetu32(m_screen.xyCoord, 0, m_width*m_height);

  m_rays.resize(m_globals.ctx, m_globals.cmdQueue, MEGABLOCK_SIZE);

  memsetf4(m_rays.rayPos, float4(0, 0, 0, 0), m_rays.MEGABLOCKSIZE);
  memsetf4(m_rays.rayDir, float4(0, 0, 0, 0), m_rays.MEGABLOCKSIZE);

  CHECK_CL(clFinish(m_globals.cmdQueue)); 
}

size_t GPUOCLLayer::GetAvaliableMemoryAmount(bool allMem)
{
  cl_ulong memTotal = 0;
  size_t   paramValueSize = 0;

  CHECK_CL(clGetDeviceInfo(m_globals.device, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &memTotal, &paramValueSize));

  //char vendor[1024];
  //char name[1024];
  //clGetDeviceInfo(m_globals.device, CL_DEVICE_VENDOR, sizeof(vendor), vendor, NULL);
  //clGetDeviceInfo(m_globals.device, CL_DEVICE_NAME, sizeof(name), name, NULL);
  //std::cerr << "Device " << m_globals.device << " is a " << vendor << " " << name << ".\n";

  return size_t(memTotal);
}

void GPUOCLLayer::SetGeom(InputGeom a_input)
{
  if (a_input.vertPos == NULL || a_input.vertNorm == NULL || a_input.vertTexCoord == NULL)
    RUN_TIME_ERROR("GPUOCLLayer::SetGeom: invalid vertex data null pointer");

  if (a_input.indices == NULL)
    RUN_TIME_ERROR("GPUOCLLayer::SetGeom: invalid indices null pointer");

  if (a_input.materialIndices == NULL)
    RUN_TIME_ERROR("GPUOCLLayer::SetGeom: invalid triangle material indices null pointer");

  if (a_input.numIndices % 3 != 0)
    RUN_TIME_ERROR("GPUOCLLayer::SetGeom: invalid input.numIndices value, must be multiple of 3");


  if (m_scene.vertNormsCompressed) clReleaseMemObject(m_scene.vertNormsCompressed);
  if (m_scene.vertTexCoord)        clReleaseMemObject(m_scene.vertTexCoord);
  if (m_scene.vertIndices)         clReleaseMemObject(m_scene.vertIndices);

  std::vector<uint> compressedNorm(a_input.vertNum);
  for (size_t i = 0; i < compressedNorm.size(); i++)
    compressedNorm[i] = encodeNormal(to_float3(a_input.vertNorm[i]));


  cl_int ciErr1;

  m_scene.vertNormsCompressed = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, compressedNorm.size()*sizeof(uint), (void*)&compressedNorm[0], &ciErr1);
  m_scene.vertTexCoord        = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, a_input.vertNum*sizeof(float2),     (void*)a_input.vertTexCoord, &ciErr1);
  m_scene.vertIndices         = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, a_input.numIndices*sizeof(int),     (void*)a_input.indices, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in clCreateBuffer");
}


void GPUOCLLayer::SetBVH(InputGeomBVH a_input)
{
  if (a_input.nodes == NULL || a_input.primListData == NULL)
    RUN_TIME_ERROR("GPUOCLLayer::SetBVH: invalid bvh data null pointer");

  if (a_input.numNodes == NULL || a_input.primListSizeInBytes == NULL)
    RUN_TIME_ERROR("GPUOCLLayer::SetBVH: invalid bvh data size");


  if (m_scene.bvhBuff)     clReleaseMemObject(m_scene.bvhBuff);
  if (m_scene.objListBuff) clReleaseMemObject(m_scene.objListBuff);

  cl_int ciErr1;

  m_scene.bvhBuff     = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY  | CL_MEM_COPY_HOST_PTR, a_input.numNodes*sizeof(BVHNode), (void*)(a_input.nodes), &ciErr1);
  m_scene.objListBuff = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, a_input.primListSizeInBytes, (void*)(a_input.primListData), &ciErr1);

  if(ciErr1 != CL_SUCCESS) 
    RUN_TIME_ERROR("Error in clCreateBuffer");
}

void GPUOCLLayer::SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum)
{
  if (m_scene.materialData)     clReleaseMemObject(m_scene.materialData);
  if (m_scene.materialOffsets)  clReleaseMemObject(m_scene.materialOffsets);

  cl_int ciErr1;

  m_scene.materialData    = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY  | CL_MEM_COPY_HOST_PTR, a_number*sizeof(PlainMaterial), (void*)(a_materialsAll), &ciErr1);
  m_scene.materialOffsets = clCreateBuffer(m_globals.ctx, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, a_matNum*sizeof(int), (void*)(indices), &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Error in clCreateBuffer");
}

void GPUOCLLayer::SetAllPODLights(RAYTR::Light* a_lights, PlainLight* a_lights2, size_t a_number)
{
  if (a_lights2 == NULL)
    return;

  if (m_scene.lightData) clReleaseMemObject(m_scene.lightData);

  cl_int ciErr1;
  m_scene.lightData = clCreateBuffer(m_globals.ctx, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, a_number*sizeof(PlainLight), (void*)(a_lights2), &ciErr1);
}


void GPUOCLLayer::SetAllFlagsAndVars(const AllRenderVarialbes& a_vars)
{
  this->IHWLayer::SetAllFlagsAndVars(a_vars);

  // your custom setup
}

AllRenderVarialbes GPUOCLLayer::GetAllFlagsAndVars() const
{
  AllRenderVarialbes state = IHWLayer::GetAllFlagsAndVars();

  // your custom 'get-up' :)

  return state;
}

void GPUOCLLayer::SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats)
{
  if (a_sizeInFloats % 16 != 0)
    RUN_TIME_ERROR("GPUOCLLayer::SetAllTextureMatrices: invalid matrices a_sizeInFloats");


}

void GPUOCLLayer::SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data)
{

}

void GPUOCLLayer::Clear(IGraphicsEngine::CLEAR_FLAGS a_flags)
{
  if (a_flags & IGraphicsEngine::CLEAR_TEXTURES)
  {

  }

  if (a_flags & IGraphicsEngine::CLEAR_LIGHTS)
  {
    // clear lights 
    // clear light meshes
  }

  if (a_flags & IGraphicsEngine::CLEAR_MATERIALS)
  {

  }

  if (a_flags & IGraphicsEngine::CLEAR_GEOMETRY)
  {

  }


}

void GPUOCLLayer::SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16])
{
  memcpy(m_mProjInverse, mProjInverse, sizeof(float)*16);
  memcpy(m_mWorldViewInverse, mWorldViewInverse, sizeof(float)*16);
}


//
//
void GPUOCLLayer::GetLDRImageToGL(GLuint ogl_buffer) const
{
 
  if (m_flags & GPU_RT_NOWINDOW)
  {
    // may not actually implement this
    //glBindBuffer(GL_ARRAY_BUFFER, ogl_buffer);
    //glBufferData(GL_ARRAY_BUFFER, m_width*m_height*sizeof(int), &m_tempImage[0], GL_DYNAMIC_COPY);
    //glBindBuffer(GL_ARRAY_BUFFER, 0);
  }
  else
  {
    cl_kernel colorKern = m_progs.screen.kernel("RealColorToRGB256");

    CHECK_CL(clEnqueueAcquireGLObjects(m_globals.cmdQueue, 1, &m_screen.pbo, 0, 0, 0));


    size_t global_item_size[2] = { m_width, m_height };
    size_t local_item_size[2]  = { 16, 16 };

    CHECK_CL(clSetKernelArg(colorKern, 0, sizeof(cl_mem), (void*)&m_screen.ptColorSummBuff));
    CHECK_CL(clSetKernelArg(colorKern, 1, sizeof(cl_mem), (void*)&m_screen.pbo));
    CHECK_CL(clSetKernelArg(colorKern, 2, sizeof(cl_int), (void*)&m_width));
    CHECK_CL(clSetKernelArg(colorKern, 3, sizeof(cl_mem), (void*)&m_globals.cMortonTable));
    CHECK_CL(clSetKernelArg(colorKern, 4, sizeof(cl_mem), (void*)&m_globals.cVarsF));

    CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, colorKern, 2, NULL, global_item_size, local_item_size, 0, NULL, NULL));


    CHECK_CL(clEnqueueReleaseGLObjects(m_globals.cmdQueue, 1, &m_screen.pbo, 0, 0, 0));
    
    CHECK_CL(clFinish(m_globals.cmdQueue)); // should prevent queue overflow
  }

}

void GPUOCLLayer::GetLDRImage(uint* data, int width, int height) const
{
  if (m_flags & GPU_RT_NOWINDOW)
  {

  }
  else
  {
    cl_kernel colorKern = m_progs.screen.kernel("RealColorToRGB256");

    CHECK_CL(clEnqueueAcquireGLObjects(m_globals.cmdQueue, 1, &m_screen.pbo, 0, 0, 0));

    size_t global_item_size[2] = { m_width, m_height };
    size_t local_item_size[2] = { 16, 16 };

    CHECK_CL(clSetKernelArg(colorKern, 0, sizeof(cl_mem), (void*)&m_screen.ptColorSummBuff));
    CHECK_CL(clSetKernelArg(colorKern, 1, sizeof(cl_mem), (void*)&m_screen.pbo));
    CHECK_CL(clSetKernelArg(colorKern, 2, sizeof(cl_int), (void*)&m_width));
    CHECK_CL(clSetKernelArg(colorKern, 3, sizeof(cl_mem), (void*)&m_globals.cMortonTable));
    CHECK_CL(clSetKernelArg(colorKern, 4, sizeof(cl_mem), (void*)&m_globals.cVarsF));

    CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, colorKern, 2, NULL, global_item_size, local_item_size, 0, NULL, NULL));

    CHECK_CL(clEnqueueReadBuffer(m_globals.cmdQueue, m_screen.pbo, CL_TRUE, 0, m_width*m_height*sizeof(uint), data, 0, NULL, NULL));

    CHECK_CL(clEnqueueReleaseGLObjects(m_globals.cmdQueue, 1, &m_screen.pbo, 0, 0, 0));

    CHECK_CL(clFinish(m_globals.cmdQueue)); // should prevent queue overflow
  }

}

void GPUOCLLayer::GetHDRImage(float4* data, int width, int height) const
{
  // reset from ZCurve to common order
  // CHECK_CL(clEnqueueReadBuffer(m_globals.cmdQueue, m_screen.ptColorSummBuff, CL_TRUE, 0, m_width*m_height*sizeof(cl_float4), data, 0, NULL, NULL));
}

void GPUOCLLayer::InitPathTracing(int seed)
{
  runKernelInitRandomGen(m_rays.randGenState, m_rays.MEGABLOCKSIZE, seed);

  // memsetf4(m_screen.ptColorSummBuff, make_float4(0, 0, 0, 0), m_width*m_height);
  // memsetf4(m_screen.ptColorSummSquareBuff, make_float4(0, 0, 0, 0), m_width*m_height);
}

bool GPUOCLLayer::ImplementBlocksPT() { return true; }


void GPUOCLLayer::simpleBlockTrace(std::vector<ZBlock>& a_blocks)
{
  CHECK_CL(clEnqueueWriteBuffer(m_globals.cmdQueue, m_screen.zblocks, CL_FALSE, 0, sizeof(ZBlock)*a_blocks.size(), &a_blocks[0], 0, NULL, NULL));     // 0.1) copy all a_blocks to gpu buffer

  size_t totalRaysSize = a_blocks.size()*ZBlock::GetSize();
  size_t megaBlockSize = m_rays.MEGABLOCKSIZE;

  int iterNum      = blocks(totalRaysSize, megaBlockSize);
  int blocksInPass = blocks(m_rays.MEGABLOCKSIZE, ZBlock::GetSize());

  for (int iter = 0; iter < iterNum; iter++)
  {
    int firstBlockOffset = iter*blocksInPass;
    size_t currSize      = megaBlockSize;

    if (iter*megaBlockSize > totalRaysSize)
      currSize = iter*megaBlockSize - totalRaysSize;

    runKernelMakeEyeRaysBlocks(m_rays.rayPos, m_rays.rayDir, currSize, m_screen.zblocks, firstBlockOffset);  // 1) make rays for blocks from firstBlockOffset

    trace1D(m_rays.rayPos, m_rays.rayDir, m_rays.pathTempColor, currSize);

    runKernelBlocksStoreColor(m_rays.pathTempColor, currSize, m_screen.zblocks, firstBlockOffset);  // 3) save color summs from m_rays.pathTempColor to (m_screen.ptColorSummBuff, m_screen.ptColorSummSquareBuff)
  }

  CHECK_CL(clEnqueueReadBuffer(m_globals.cmdQueue, m_screen.zblocks, CL_TRUE, 0, sizeof(ZBlock)*a_blocks.size(), &a_blocks[0], 0, NULL, NULL));     // 0.1) copy all a_blocks to gpu buffer

}

void GPUOCLLayer::BeginBlocksPTPass(BlockList& a_blockList, int a_minRaysPerPixel, int a_maxRaysPerPixel)
{ 
  if (true)
  {
    if (a_blockList.size() == 0)
      return;

    runKernelRememberXY();

    m_tempBlocks.resize(a_blockList.size());

    int counter = 0;
    while (!a_blockList.empty())
    {
      m_tempBlocks[counter] = *(a_blockList.begin());
      a_blockList.pop_front();
      counter++;
    }

    simpleBlockTrace(m_tempBlocks);

    for (int i = 0; i<m_tempBlocks.size(); i++)
    {
      float error = 0;

      if (!BlockFinished(m_tempBlocks[i], a_minRaysPerPixel, a_maxRaysPerPixel, &error))
        a_blockList.push_front(m_tempBlocks[i]);  
    }

  }

}

void GPUOCLLayer::EndBlocksPTPass() 
{

}


MRaysStat GPUOCLLayer::GetRaysStat()
{
  MRaysStat res = m_stat;
  res.raysPerSec /= float(m_statTimesAccount);
 
  m_stat.raysPerSec    = 0;
  m_stat.samplesPerSec = 0;

  m_statTimesAccount   = 0;

  return res;
}


unsigned int GPUOCLLayer::AddLightMesh(LightMeshData a_lmesh)
{
  return 0; // return light mesh index that was just added
}

void GPUOCLLayer::ResetPerfCounters()
{
  memset(&m_stat, 0, sizeof(MRaysStat));
}

void GPUOCLLayer::BeginTracingPass()
{
  runKernelRememberXY();

  cl_kernel makeRaysKern   = m_progs.screen.kernel("MakeEyeRays");

  int iter = 0;
  for (size_t offset = 0; offset < m_width*m_height; offset += m_rays.MEGABLOCKSIZE)
  {
    size_t localWorkSize  = 256;
    size_t globalWorkSize = m_rays.MEGABLOCKSIZE;
    cl_int iOffset        = cl_int(offset);

    if (offset + globalWorkSize >(m_width*m_height))
      globalWorkSize = (m_width*m_height) - offset;

    CHECK_CL(clSetKernelArg(makeRaysKern, 0, sizeof(cl_mem), (void*)&m_screen.xyCoord));
    CHECK_CL(clSetKernelArg(makeRaysKern, 1, sizeof(cl_int), (void*)&iOffset));
    CHECK_CL(clSetKernelArg(makeRaysKern, 2, sizeof(cl_mem), (void*)&m_rays.rayPos));
    CHECK_CL(clSetKernelArg(makeRaysKern, 3, sizeof(cl_mem), (void*)&m_rays.rayDir));
    CHECK_CL(clSetKernelArg(makeRaysKern, 4, sizeof(cl_int), (void*)&m_width));
    CHECK_CL(clSetKernelArg(makeRaysKern, 5, sizeof(cl_int), (void*)&m_height));
    CHECK_CL(clSetKernelArg(makeRaysKern, 6, sizeof(cl_int), (void*)&m_flags));
    CHECK_CL(clSetKernelArg(makeRaysKern, 7, sizeof(float4x4), (void*)&m_mProjInverse));
    CHECK_CL(clSetKernelArg(makeRaysKern, 8, sizeof(float4x4), (void*)&m_mWorldViewInverse));

    CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, makeRaysKern, 1, NULL, &globalWorkSize, &localWorkSize, 0, NULL, NULL));

    //trace1D(m_rays.rayPos, m_rays.rayDir, m_screen.colorSubBuffers[iter], globalWorkSize);
    trace1DPrimaryOnly(m_rays.rayPos, m_rays.rayDir, m_screen.colorSubBuffers[iter], globalWorkSize);

    iter++;
  }
}

void GPUOCLLayer::EndTracingPass()
{
  CHECK_CL(clFinish(m_globals.cmdQueue));
}


void GPUOCLLayer::trace1D(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, size_t a_size)
{
  // update variables
  //
  CHECK_CL(clEnqueueWriteBuffer(m_globals.cmdQueue, m_globals.cVarsI, CL_FALSE, 0, GMAXVARS*sizeof(int), m_vars.m_varsI, 0, NULL, NULL));
  CHECK_CL(clEnqueueWriteBuffer(m_globals.cmdQueue, m_globals.cVarsF, CL_FALSE, 0, GMAXVARS*sizeof(int), m_vars.m_varsF, 0, NULL, NULL));
  
  cl_kernel kernShowN = m_progs.trace.kernel("ShowNormals");
  cl_kernel kernShowT = m_progs.trace.kernel("ShowTexCoord");
  cl_kernel kernFill  = m_progs.trace.kernel("ColorIndexTriangles");

  //cl_kernel kern = m_progs.screen.kernel("FillColorTest");
  
  size_t localWorkSize = 256;
  int    isize = int(a_size);

  // trace rays
  //
  if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS])
  {
    clFinish(m_globals.cmdQueue);
    m_timer.start();
  }

  memsetu32(m_rays.rayFlags, 0, a_size);                 // fill flags with zero data
  memsetf4(a_outColor, make_float4(0,0,0,0), a_size);    // fill initial out color with black
  memsetf4(m_rays.pathThoroughput, make_float4(1.0f, 1.0f, 1.0f, 1.0f), a_size); // fill path thoroughput with 1

  float timeForSample = 0.0f;
  float timeForBounce = 0.0f;
  float timeForTrace  = 0.0f;
  float timeBeforeShadow = 0.0f;
  float timeForShadow = 0.0f;
  float timeStart     = 0.0f;

  int measureBounce   = m_vars.m_varsI[HRT_MEASURE_RAYS_TYPE];
  if (measureBounce > 2) measureBounce = -1;

  for (int bounce = 0; bounce < m_vars.m_varsI[HRT_TRACE_DEPTH]; bounce++)
  {
    if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS] && bounce == measureBounce)
    {
      clFinish(m_globals.cmdQueue);
      timeStart = m_timer.getElapsed();
    }

    runKernelTrace(a_rpos, a_rdir, a_size);

    if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS] && bounce == measureBounce)
    {
      clFinish(m_globals.cmdQueue);
      timeForTrace = (m_timer.getElapsed() - timeStart);
      m_stat.raysPerSec += float(a_size) / timeForTrace;
      m_statTimesAccount++;
    }

    runKernelComputeHit(a_rpos, a_rdir, a_size);


    if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS] && bounce == measureBounce)
    {
      clFinish(m_globals.cmdQueue);
      timeBeforeShadow = m_timer.getElapsed();
    }

    if (!(m_vars.m_flags & HRT_DISABLE_SHADING))
      runKernelShadowTrace(a_rpos, a_rdir, m_rays.pathShadeColor, m_rays.pathShadeColor, a_size); // -- path shadow color instead of pathShadeColor second time
    else
      memsetf4(m_rays.pathShadeColor, make_float4(0,0,0,0), a_size);


    if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS] && bounce == measureBounce)
    {
      clFinish(m_globals.cmdQueue);
      timeForShadow = (m_timer.getElapsed() - timeBeforeShadow);
      //m_stat. += float(a_size) / timeForTrace;
      //m_statTimesAccount++;
    }

    runKernelNextBounce(a_rpos, a_rdir, a_outColor, a_size);

    if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS] && bounce == measureBounce)
    {
      clFinish(m_globals.cmdQueue);
      timeForBounce = (m_timer.getElapsed() - timeStart);
    }
  }

  if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS])
  {
    clFinish(m_globals.cmdQueue);
    timeForSample = m_timer.getElapsed();
  }

  m_stat.traversalTimeMs  = timeForTrace*1000.0f;
  m_stat.sampleTimeMS     = timeForSample*1000.0f;
  m_stat.bounceTimeMS     = timeForBounce*1000.0f;
  m_stat.shadowTimeMs     = timeForShadow*1000.0f;
  m_stat.samplesPerSec    = float(a_size) / timeForSample;
  m_stat.traceTimePerCent = ((timeForTrace + timeForShadow) / timeForBounce)*100.0f;
}

void GPUOCLLayer::trace1DPrimaryOnly(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, size_t a_size)
{
  // update variables
  //
  CHECK_CL(clEnqueueWriteBuffer(m_globals.cmdQueue, m_globals.cVarsI, CL_FALSE, 0, GMAXVARS*sizeof(int), m_vars.m_varsI, 0, NULL, NULL));
  CHECK_CL(clEnqueueWriteBuffer(m_globals.cmdQueue, m_globals.cVarsF, CL_FALSE, 0, GMAXVARS*sizeof(int), m_vars.m_varsF, 0, NULL, NULL));

  cl_kernel kernShowN = m_progs.trace.kernel("ShowNormals");
  cl_kernel kernShowT = m_progs.trace.kernel("ShowTexCoord");
  cl_kernel kernFill  = m_progs.trace.kernel("ColorIndexTriangles");

  //cl_kernel kern = m_progs.screen.kernel("FillColorTest");

  size_t localWorkSize = 256;
  int    isize = int(a_size);

  // trace rays
  //

  memsetu32(m_rays.rayFlags, 0, a_size);                 // fill flags with zero data
  memsetf4(a_outColor, make_float4(0, 0, 0, 0), a_size);    // fill initial out color with black
  memsetf4(m_rays.pathThoroughput, make_float4(1.0f, 1.0f, 1.0f, 1.0f), a_size); // fill path thoroughput with 1

  if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS])
  {
    clFinish(m_globals.cmdQueue);
    m_timer.start();
  }
  
  runKernelTrace(a_rpos, a_rdir, a_size);
  
  if (m_vars.m_varsI[HRT_ENABLE_MRAYS_COUNTERS])
  {
    clFinish(m_globals.cmdQueue);
    m_stat.raysPerSec += float(a_size) / m_timer.getElapsed();
    m_statTimesAccount++;
  }
  
  runKernelComputeHit(a_rpos, a_rdir, a_size);


  //
  //

  if (true)
  {
    CHECK_CL(clSetKernelArg(kernShowN, 0, sizeof(cl_mem), (void*)&m_rays.hitPosNorm));
    CHECK_CL(clSetKernelArg(kernShowN, 1, sizeof(cl_mem), (void*)&a_outColor));
    CHECK_CL(clSetKernelArg(kernShowN, 2, sizeof(cl_int), (void*)&isize));

    CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernShowN, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
  }
  else if (false)
  {
    CHECK_CL(clSetKernelArg(kernShowT, 0, sizeof(cl_mem), (void*)&m_rays.hitTexCoord));
    CHECK_CL(clSetKernelArg(kernShowT, 1, sizeof(cl_mem), (void*)&a_outColor));
    CHECK_CL(clSetKernelArg(kernShowT, 2, sizeof(cl_int), (void*)&isize));

    CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernShowT, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
  }
  else
  {
    CHECK_CL(clSetKernelArg(kernFill, 0, sizeof(cl_mem), (void*)&m_rays.hits));
    CHECK_CL(clSetKernelArg(kernFill, 1, sizeof(cl_mem), (void*)&a_outColor));
    CHECK_CL(clSetKernelArg(kernFill, 2, sizeof(cl_int), (void*)&isize));

    CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernFill, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
  }

}



void GPUOCLLayer::RegisterOutputGLBuffer(GLuint ogl_buffer)
{
  UnregisterOutputGLBuffer();

  cl_int ciErr1 = 0;
  m_screen.pbo = clCreateFromGLBuffer(m_globals.ctx, CL_MEM_WRITE_ONLY, ogl_buffer, &ciErr1);

  if (ciErr1 != CL_SUCCESS)
    RUN_TIME_ERROR("Failed to share cl-gl full screen LDR buffer");

}

void GPUOCLLayer::UnregisterOutputGLBuffer()
{
  if (m_screen.pbo) 
    clReleaseMemObject(m_screen.pbo);

  m_screen.pbo = 0;
}


IHWLayer* CreateOclImpl(int w, int h, int a_flags) { return new GPUOCLLayer(w, h, a_flags); }







