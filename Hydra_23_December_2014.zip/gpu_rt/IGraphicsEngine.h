// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#include <string>

#ifndef MGML_GUARDIAN
	#include "../CSL/MGML.h"
#endif


#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

using namespace MGML;

#ifdef CERF_DLL_EXPORTS
	#define DLL_API __declspec(dllexport)
#else
	#define DLL_API __declspec(dllimport)
#endif

class DLL_API IGraphicsEngine;

typedef void (*RTE_UPDATEIMAGE_CALLBACK)(IGraphicsEngine* pRender, uint* a_data, bool a_lastImage);


class DLL_API IGraphicsEngine
{
public:

	typedef unsigned int uint;
	enum {MAX_KD_TREE_NODES = 1000000, MAX_VERTEX_ATTRIBUTES = 10};

  IGraphicsEngine(int w, int h);
  virtual ~IGraphicsEngine();

  enum INPUT_TEXTURE_FORMAT{ RGBA8 = 4, RGBA16F = 8, RGBA32F = 16};
  
  virtual void SetProgressBarCallback(RTE_PROGRESSBAR_CALLBACK a_callback) = 0;
  virtual void SetUpdateImageCallback(RTE_UPDATEIMAGE_CALLBACK a_callback) = 0;

  // RTE API v 1.0
  //
  virtual vec2ui  AddTriangles(const Vertex4f* v,int N_vertices, const uint* indices,int N_indices, int a_flags = 0) = 0;
  virtual uint	  AddMaterial(const RAYTR::HydraMaterial& mat) = 0;
  virtual uint	  AddSpheres(const Sphere4f* s,int N_spheres) = 0;
  virtual uint    AddTexture(const void* memory, uint w, uint h, uint format = RGBA8) = 0;
  virtual uint    AddLight(const RAYTR::Light& light) = 0;

  // RTE API v 2.0
  //

  enum VERTEX_ATTRIB{ VERTEX_POSITION     = 1,
                      VERTEX_NORMAL       = 2, 
                      VERTEX_UV           = 4,
                      VERTEX_TANGENT      = 8,
                      VERTEX_MATERIAL_ID  = 16,
                      VERTEX_USER_DEFINED = 32};

  enum CLEAR_FLAGS{ CLEAR_MATERIALS = 1, 
                    CLEAR_GEOMETRY  = 2, 
                    CLEAR_LIGHTS    = 4,
                    CLEAR_TEXTURES  = 8,
                    CLEAR_ALL       = CLEAR_MATERIALS | CLEAR_GEOMETRY | CLEAR_LIGHTS | CLEAR_TEXTURES};

  enum INPUT_PRIMITIVES { INPUT_PRIMITIVE_TRIANGLES = 1,
                          INPUT_PRIMITIVE_SPHERES = 2};

  enum GEOM_TYPE{ INPUT_GEOMETRY_STATIC = 0,
                  INPUT_GEOMETRY_DYNAMIC = 1};

  // this is for 'multi-pass' i.e. multi-layer rendering
  //
  enum RENDER_LAYER {LAYER_COLOR                  = RAYTR::LAYER_COLOR, 
                     LAYER_POSITIONS              = RAYTR::LAYER_POSITIONS,
                     LAYER_NORMALS                = RAYTR::LAYER_NORMALS,
                     LAYER_TEXCOORD               = RAYTR::LAYER_TEXCOORD,
                     LAYER_TEXCOLOR_AND_MATERIAL  = RAYTR::LAYER_TEXCOLOR_AND_MATERIAL,
                     LAYER_INCOMING_PRIMARY       = RAYTR::LAYER_INCOMING_PRIMARY, 
                     LAYER_INCOMING_RADIANCE      = RAYTR::LAYER_INCOMING_RADIANCE,
                     LAYER_COLOR_PRIMARY_AND_REST = RAYTR::LAYER_COLOR_PRIMARY_AND_REST,
                     LAYER_COLOR_THE_REST         = RAYTR::LAYER_COLOR_THE_REST};

  virtual void DeclareVertexInputLayout(int layout, int numUserDefinedAttributes = 0) throw (std::runtime_error) = 0;

  virtual void ReserveMemoryFor(int primTypes, int a_maxPrims) throw (std::runtime_error) = 0;

  // fixed function pipeline
  //
  virtual void SetVertexPositionPointer(const float* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexNormalPointer(const float* v,   int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexUVPointer(const float* v,       int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexTangentPointer(const float* v,  int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexMaterialIdPointer(const int* v, int bytePitch) throw (std::runtime_error) = 0; // deprecated

  // programmable pipeline
  //
  virtual void SetVertexAttributePointer(const char* attrName, const double* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const float* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const int* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const short* v, int bytePitch) throw (std::runtime_error) = 0;
  virtual void SetVertexAttributePointer(const char* attrName, const char* v, int bytePitch) throw (std::runtime_error) = 0;

  virtual int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount, int a_flags = 0) = 0;

  // RTE API v 2.1
  //
  virtual int  AddTriangles(const Matrix4x4f& a_mat, const uint* a_indices, int a_indicesNum, int a_maxVertexCount,
                            const int* a_materialIndices, int a_matIdNum, int a_flags = 0) = 0; // ignore VertexMaterialIdPointer


  virtual int AddTextureMatrix(const Matrix4x4f& a_mat) = 0;
  virtual Matrix4x4f GetTextureMatrix(int a_matrixId) = 0;

  // RTE general
  //
  class DLL_API RenderSettings
  {
  public:
    RenderSettings();
    ~RenderSettings();

    void SetTraceDepth(int);
    int  GetTraceDepth() const;

    void SetDiffuseTraceDepth(int);
    int  GetDiffuseTraceDepth() const;

    void SetShadow(bool);
    bool GetShadow() const;

    void SetAA(int);
    int  GetAA() const;

    void SetIndirrectIllumination(bool);
    bool GetIndirrectIllumination() const;

    void  SetTraceProceedingsTreshold(float);
    float GetTraceProceedingsTreshold() const ;

    bool  GetEnableRaysCounter() const ;
    void  SetEnableRaysCounter(bool);

    bool  GetEnableFG() const ;
    void  SetEnableFG(bool);

    void  SetEnableCG(bool);
    bool  GetEnableCG() const ;

    void  SetGartherRadius(float);
    float GetGartherRadius() const ;

    void  SetGartherRadiusCaustic(float);
    float GetGartherRadiusCaustic() const ;

    int   GetGartherBounce() const ;
    void  SetGartherBounce(int);

    int   GetStoreBounce() const ;
    void  SetStoreBounce(int);

    void  SetGamma(float a_gamma, float a_gammaTex = -1.0f);
    float GetGamma() const ;
    float GetGammaTex() const ;

    void SetRenderLayer(RENDER_LAYER a_layer);
    RENDER_LAYER GetRenderLayer() const;

    void SetRenderLayerDepth(int a_depth);
    int  GetRenderLayerDepth() const;

    float causticPower;
    bool  ptCaustics;
    bool  guidedPathTracing;
    int   icBounce;

  protected: 

    int m_AA             : 8;
    int m_traceDepth     : 8;
    int m_diffTraceDepth : 8;
    int m_fgBounce       : 8;
    int m_storeBounce    : 8;
    RENDER_LAYER m_renderLayer : 8;
    int m_renderLayerDepth     : 8 ;
    
    bool m_shadows               : 1;
    bool m_giEnabled             : 1;
    bool m_enableRaysCount       : 1;
    bool m_enableFinalGarthering : 1;
    bool m_enableCausticGarthering : 1;

  public:

    bool enableRecursiveTracing  : 1;

    float m_gamma;
    float m_gammaTex;
    float m_traceProoceedThreshold;
    float m_gartherRadius;
    float m_gartherRadiusCaustic;

  };

	virtual void BeginDrawScene(RenderSettings a_renderState) = 0;			// you can do some thing between this calls
	virtual void EndDrawScene() = 0;			                          // \\ you can do some thing between this calls

	virtual void DrawScene(const RenderSettings a_renderState) { BeginDrawScene(a_renderState); EndDrawScene(); }
  virtual void BuildAccelerationStructures(const std::string& a_geomMD5, const std::string& a_lightsMD5) = 0;

  virtual void Clear(int a_flags = CLEAR_ALL) = 0;

  virtual int  GetLightNumber() const = 0;

  virtual void SetLight(const RAYTR::Light& light,int index) = 0;	
  virtual const RAYTR::Light& GetLight(int index) const = 0;

  virtual RAYTR::HydraMaterial GetHydraMaterial(int a_id) = 0;
  virtual void SetHydraMaterial(const RAYTR::HydraMaterial& rhs, int a_id) = 0;
 
  virtual void SetWorldViewMatrix(const float mat[16]) = 0;
  virtual void SetProjectionMatrix(const float mat[16]) = 0;

  virtual const float* GetWorldViewMatrix() const = 0;
  virtual const float* GetProjectionMatrix() const = 0;

  virtual void SetAuxCamProjParams(const float pamams[4]) = 0;

	//virtual const RAYTR::Material&		GetMaterial(int index) const = 0;          // deprecated
  //virtual void SetMaterial(const RAYTR::Material& mat, unsigned int N) = 0;    // depracated

  virtual void SetVariable(const std::string& a_name, int a_val){}
  virtual void SetVariable(const std::string& a_name, float a_val){}

  virtual void GetTextureDesc(uint texId, uint* w, uint* h, uint* format = NULL) = 0;
  virtual void GetTextureData(uint texId, void* data) = 0;
  virtual const void* GetTextureDataPtr(uint texId) const = 0;

  virtual void GetLDRImage(uint* data) const = 0;
  virtual void GetHDRImage(float4* data) const = 0;

  virtual void DebugCall(const std::string& a_name, const std::string& a_params){}

  virtual void SetWindowResolution(int a_width, int a_height) = 0;

  virtual float EtimateTotalRenderingProgress() const = 0;

private:
	IGraphicsEngine(const IGraphicsEngine& rhs){}
	IGraphicsEngine& operator=(const IGraphicsEngine& rhs) {return *this;}
};
