#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "RadianceCache.h"
#include "Voxelizer.h"


/////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::ComputeRadianceCache(int a_type)
{
  delete m_pRC; m_pRC = NULL;

  if(a_type == 0)
    m_pRC = new SHRadianceCache();
  else if(a_type == 1)
    m_pRC = new CBMRadianceCache();

  float voxelSize = 1.0f;

  // recomment this back if you need radiance cache
  {
    //m_pRC->Build(m_voxelData, &voxelSize);
    //m_pRC->EvaluateRadiance();
    //m_pRC->BuildRecordsBVH();
  }

  std::cerr << "voxelSize = " << voxelSize << std::endl;
  hrtRadianceCacheSetGlobalAlpha(voxelSize);

  if(a_type == 0)
    hrtSetFlags(HRT_RC_HARMONICS, 1);
  //else if(a_type == 1)
    //hrtSetFlags(HRT_RC_CUBEMAPS, 1);

  std::cout << "radiance cache calculated" << std::endl;
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::FreeRadianceCache()
{
  hrtSetFlags(HRT_RC_HARMONICS, 0);

  delete m_pRC; m_pRC = NULL;
  delete m_pBVHBuilder; m_pBVHBuilder = NULL;
  std::cout << "radiance cache destroyed" << std::endl;
}


/////////////////////////////////////////////////////////////////////////////////////////////
////
RadianceCache::RadianceCache()
{
  m_selfId = hlmRadianceCacheCreate();
  m_pBVHBuilder = NULL;
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
RadianceCache::~RadianceCache()
{
  hlmRadianceCacheDestroy(m_selfId);
  delete m_pBVHBuilder; m_pBVHBuilder = NULL;
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void RadianceCache::Build(const VoxelStorage<unsigned char>& a_voxelStorage, float* a_pOutVoxelSize) 
{
  typedef unsigned char uint8;

  const Array3D<uint8>& voxels = a_voxelStorage.GetArrayMipLevel(3);
  
  AABB3f box = a_voxelStorage.GetBoundingBox();
  float voxelSize = (box.vmax.x - box.vmin.x)/float(voxels.size().x);

  m_rcPositions.reserve(m_rcPositions.size() + 16384);

  for(int x=0;x<voxels.size().x;x++)
  {
    float cx = float(x)+0.5f;
    for(int y=0;y<voxels.size().y;y++)
    {
      float cy = float(y)+0.5f;
      for(int z=0;z<voxels.size().z;z++)
      {
        float cz = float(z)+0.5f;

        bool placeRecord = (voxels(x,y,z) == 1);
        
        //if(!placeRecord)
        if(0)
        {
          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y+1,z) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y+1,z) == 1); 
          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y-1,z) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y-1,z) == 1); 

          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x+1,y,z) == 1) && (voxels(x,y,z-1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x-1,y,z) == 1) && (voxels(x,y,z-1) == 1); 

          if(!placeRecord) placeRecord = (voxels(x,y+1,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x,y+1,z) == 1) && (voxels(x,y,z-1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x,y-1,z) == 1) && (voxels(x,y,z+1) == 1); 
          if(!placeRecord) placeRecord = (voxels(x,y-1,z) == 1) && (voxels(x,y,z-1) == 1); 
        }


        if(placeRecord)
        {
          float3 center = float3( box.vmin.x + cx*voxelSize, box.vmin.y + cy*voxelSize, box.vmin.z + cz*voxelSize);
          float r = sqrtf(3)*voxelSize; // sqrt(r*r + r*r + r*r)
          m_rcPositions.push_back(float4(center.x, center.y, center.z, r));
        } 
      }
    }
  }

  //std::ofstream fout("rc_spheres.txt");
  //for(int i=0;i<m_rcPositions.size();i++)
    //fout << m_rcPositions[i] << std::endl;

  if(a_pOutVoxelSize != NULL)
    (*a_pOutVoxelSize) = voxelSize;
}

/////////////////////////////////////////////////////////////////////////////////////////////
////
void RadianceCache::InsertRecords(const float4* a_recordsData, int a_numRecords)
{
  int oldSize = m_rcPositions.size();
  m_rcPositions.resize(m_rcPositions.size() + a_numRecords);

  for(int i=0;i<a_numRecords;i++)
    m_rcPositions[oldSize+i] = a_recordsData[i];
}


void RadianceCache::GenerateNewRecordPositions()
{
  m_rcPositions.resize(0);
  m_rcPositions.push_back(float4(0,0,0,0));
}


class BVHSpheresInput : public RAYTR::InputData
{
public:
  BVHSpheresInput(const DynamicArray<float4>& a_spheres) : m_spheres(a_spheres) {}

  int  GetNumSpheres() const throw (std::runtime_error) {return m_spheres.size(); }
  void GetSphere(int index, float sph_pos[3], float* sph_r) const throw (std::runtime_error)
  {
    float4 data = m_spheres[index];
    sph_pos[0] = data.x;
    sph_pos[1] = data.y;
    sph_pos[2] = data.z;
    (*sph_r)   = data.w;
  }

private:
  
   const DynamicArray<float4>& m_spheres;

};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void RadianceCache::BuildRecordsBVH()
{
  /*
  BVHSpheresInput input(m_rcPositions);
  
  delete m_pBVHBuilder;
  m_pBVHBuilder = new BVHBuilderRef_vfrolov;

  AccelStructSettings  presets;
  presets.flags = AccelStructSettings::INPUT_SPHERES | AccelStructSettings::CONSTRUCT_QUALITY | 
                  AccelStructSettings::DISABLE_EARLY_SPLIT_CLIPPING | AccelStructSettings::STORE_PRIMITIVE_ID_IN_LEAF;

  presets.maxDeep = 64;
  presets.maxPrimInLeaf = 32;
  presets.recomendedPrimInLeaf = 1;

  m_pBVHBuilder->Build(&input, presets);
  m_pBVHBuilder->GetBoundingBox(m_bBox.vmin.M, m_bBox.vmax.M);
  
  //m_debugSpheresOut.open("rc_spheres.txt");
  //DebugCheckBVH(m_pBVHBuilder->GetBVH(), m_pBVHBuilder->GetBVH(), (const float4*)m_pBVHBuilder->GetPrimitiveListsArray());
  //m_debugSpheresOut.close();

  hlmRadianceCacheSetBVH(m_selfId, m_pBVHBuilder->GetBVH(), m_pBVHBuilder->GetBVHArraySize());
 
  delete m_pBVHBuilder; m_pBVHBuilder = NULL;
  */

}


void RadianceCache::DebugCheckBVH(const BVHNode* a_root, const BVHNode* a_node, const float4* fdata)
{
  if(a_node->Leaf())
  {
    int sphereOffset = a_node->GetObjectListOffset();
  
    float4 data = m_rcPositions[sphereOffset];
    m_debugSpheresOut << data << std::endl;
  }
  else
  {
    const BVHNode* left  = a_root + a_node->GetLeftOffset();
    const BVHNode* right = a_root + a_node->GetRightOffset();

    DebugCheckBVH(a_root, left, fdata);
    DebugCheckBVH(a_root, right, fdata);
  }

}


void SHRadianceCache::EvaluateRadiance()
{
  if(m_rcPositions.size() == 0)
    return;

  hlmRadianceCacheComputeHarmonics(m_selfId, 1, &m_rcPositions[0], m_rcPositions.size());
}


void CBMRadianceCache::EvaluateRadiance()
{
  if(m_rcPositions.size() == 0)
    return;

  hlmRadianceCacheComputeCubeMaps(m_selfId, 1, &m_rcPositions[0], m_rcPositions.size());
}

