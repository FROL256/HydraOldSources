#ifndef CTFETCH
#define CTFETCH

#include "globals.h"

#ifdef __CUDACC__


/////////////////////////////////////////////////////////////////////////////////////////
////


texture<float4, 1, cudaReadModeElementType> bvh_tex;
texture<float4, 1, cudaReadModeElementType> primLists_tex;


__device__ int2 getObjectList(unsigned int offset, __constant float4* objListTex)
{
  int2 res;
  float4 tmp = tex1Dfetch(primLists_tex, offset);
  res.x      = __float_as_int(tmp.x);
  res.y      = __float_as_int(tmp.y);
  return res;
}


__device__ BVHNode GetBVHNode(unsigned int offset, __constant float4* bvhTex)
{
  float4 nodeHalf1 = tex1Dfetch(bvh_tex, 2 * offset);
  float4 nodeHalf2 = tex1Dfetch(bvh_tex, 2 * offset + 1);

  BVHNode node;
  node.m_boxMin.x = nodeHalf1.x;
  node.m_boxMin.y = nodeHalf1.y;
  node.m_boxMin.z = nodeHalf1.z;
  node.m_leftOffsetAndLeaf = __float_as_int(nodeHalf1.w);

  node.m_boxMax.x = nodeHalf2.x;
  node.m_boxMax.y = nodeHalf2.y;
  node.m_boxMax.z = nodeHalf2.z;
  node.m_escapeIndex = __float_as_int(nodeHalf2.w);

  return node;
}

#else
#ifdef OCL_COMPILER // replace OpenCL functions in common C++ later

const sampler_t samplerReadElement = CLK_NORMALIZED_COORDS_FALSE | CLK_FILTER_NEAREST;

IDH_CALL int2 getObjectList(unsigned int offset, __constant float4* objListTex)
{
  int2 res;
  float4 tmp = objListTex[offset]; 
  res.x = __float_as_int(tmp.x);
  res.y = __float_as_int(tmp.y);
  return res;
}


IDH_CALL BVHNode GetBVHNode(unsigned int offset, __constant float4* bvhTex)
{
  float4 nodeHalf1 = bvhTex[2*offset + 0]; // = read_1Dimagef(bvhTex, samplerReadElement, 2 * offset);
  float4 nodeHalf2 = bvhTex[2*offset + 1]; // = read_1Dimagef(bvhTex, samplerReadElement, 2 * offset + 1);

  BVHNode node;
  node.m_boxMin.x = nodeHalf1.x;
  node.m_boxMin.y = nodeHalf1.y;
  node.m_boxMin.z = nodeHalf1.z;
  node.m_leftOffsetAndLeaf = __float_as_int(nodeHalf1.w);

  node.m_boxMax.x = nodeHalf2.x;
  node.m_boxMax.y = nodeHalf2.y;
  node.m_boxMax.z = nodeHalf2.z;
  node.m_escapeIndex = __float_as_int(nodeHalf2.w);

  return node;
}


#endif
#endif





#endif
