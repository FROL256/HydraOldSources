#pragma once

// agv - Anton Guryanov Voxelizer  :)
namespace agv
{

  struct IVoxelStorageGPU
  {
    IVoxelStorageGPU(){}
    virtual ~IVoxelStorageGPU(){}

    virtual void SetTriangleMesh(float3* triangles, int len) = 0;
    virtual void SetVoxelBox(float3 boxMin, float3 boxMax, int resolution) = 0;
    virtual void VoxelizeTriangles() = 0;
    
    virtual int GetResolution() = 0;
    virtual float3 GetVoxelBoxMin() = 0;
    virtual float3 GetVoxelBoxMax() = 0;
    virtual int* GetVoxels() = 0;

  protected:

    IVoxelStorageGPU(const IVoxelStorageGPU& rhs){}
    IVoxelStorageGPU& operator=(const IVoxelStorageGPU& rhs) {return *this;}

  };

  IVoxelStorageGPU* CreateVoxelStorage(const char* a_className);
  void ReleaseVoxelStorage(IVoxelStorageGPU*& a_pStorage);


}



