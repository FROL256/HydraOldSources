// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#include "Ray_Tracer.h"

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::Ray_Tracer(int w, int h, int a_flags): Common_Graphics_Engine(w,h,a_flags)
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
Ray_Tracer::~Ray_Tracer()
{

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::RT_Core::SetMatrix(const MGML::Matrix4x4f &m)
{ 
	mRaysTransfrom = m;
}


float toRadians(float a_grad) { return MGML_MATH::DEG_TO_RAD(a_grad); }


void Ray_Tracer::AddSphereAsMesh(RAYTR::Light* pLight, int addedMaterialId)
{
  //return; 

  /*
  const int numVert = 4;
  const int numIndices = 6;
  Vertex4f  vert[numVert];
  unsigned int indices[numIndices];

  // triangles
  vec2f size(1,1);
  vert[0].pos.set(-size.x, 0, -size.y, 1); vert[0].norm = to_float4(float3(0, -1, 0), 0);
  vert[1].pos.set(-size.x, 0, size.y, 1);  vert[1].norm = to_float4(float3(0, -1, 0), 0);
  vert[2].pos.set(size.x, 0, size.y, 1);   vert[2].norm = to_float4(float3(0, -1, 0), 0);
  vert[3].pos.set(size.x, 0, -size.y, 1);  vert[3].norm = to_float4(float3(0, -1, 0), 0);
 
  for (int i = 0; i<numVert; i++)
    vert[i].material_id = addedMaterialId;

  indices[0] = 0; indices[1] = 1; indices[2] = 2;
  indices[3] = 2; indices[4] = 3; indices[5] = 0;

  this->AddTriangles(vert, numVert, indices, numIndices);
  */

  
  int   in_detail = 50;
  float in_radius = pLight->GetSphericalLightRadius();
  float3 center   = pLight->pos;
  float  pi       = 3.1415926;

  int nVertices = (in_detail + 1) * (in_detail + 1) * 2;
  int nFaces    = in_detail * in_detail * 2 * 2;

  vector<float3> vertices;

  for (int i = 0; i <= in_detail * 2; i++)
  {
    for (int j = 0; j <= in_detail; j++)
    {
      float phi = (float)i / in_detail * 2 * pi;
      float theta = (float)j / in_detail * pi - pi / 2;

      float3 vertex = center + make_float3(cos(phi) * cos(theta), sin(phi) * cos(theta), sin(theta)) * in_radius;
      vertices.push_back(vertex);
    }
  }

  std::vector<unsigned int> indices;

  indices.reserve(in_detail * 2 * in_detail * 2 * 3);

  for (int i = 0; i < in_detail * 2; i++)
  {
    for (int j = 0; j < in_detail; j++)
    {
      // make 2 triangles
      {
        int ia = i * (in_detail + 1) + j;
        int ib = (i + 1) * (in_detail + 1) + j + 1;
        int ic = i * (in_detail + 1) + j + 1;

        indices.push_back(ia);
        indices.push_back(ib);
        indices.push_back(ic);
      }
      {
        int ia = i * (in_detail + 1) + j;
        int ib = (i + 1) * (in_detail + 1) + j;
        int ic = (i + 1) * (in_detail + 1) + j + 1;

        indices.push_back(ia);
        indices.push_back(ib);
        indices.push_back(ic);
      }
    }
  }

  std::vector<Vertex4f> realVert(vertices.size());

  for (int i = 0; i < realVert.size(); i++)
  {
    realVert[i].pos  = to_float4(vertices[i], 1.0f);
    realVert[i].norm = to_float4(normalize(vertices[i] - center), 0.0f);
    realVert[i].t = float2(0, 0);
    realVert[i].material_id = addedMaterialId;
  }

  this->AddTriangles(&realVert[0], realVert.size(), &indices[0], indices.size());
  

  /*

  float radius = in_radius;

  int numberParallels = numberSlices;
  int numberVertices  = (numberParallels + 1) * (numberSlices + 1);
  int numberIndices   = numberParallels * numberSlices * 6;

  Vertex4f*     vert = new Vertex4f[numberVertices + 1];
  unsigned int* indices = new unsigned int[numberIndices + 3];

  float angleStep = (2.0f * MGML_MATH::PI) / ((float)numberSlices);
  float helpVector[3] = { 0.0f, 1.0f, 0.0f };

  for (int i = 0; i < numberParallels + 1; i++)
  {
    for (int j = 0; j < numberSlices + 1; j++)
    {
      int vertexIndex = (i * (numberSlices + 1) + j); //*4;
     
      vert[vertexIndex].pos.x = radius * sinf(angleStep * (float)i) * sinf(angleStep * (float)j);
      vert[vertexIndex].pos.y = radius * cosf(angleStep * (float)i);
      vert[vertexIndex].pos.z = radius * sinf(angleStep * (float)i) * cosf(angleStep * (float)j);
      vert[vertexIndex].pos.w = 1.0f;

      vert[vertexIndex].norm.x = vert[vertexIndex].pos.x / radius;
      vert[vertexIndex].norm.y = vert[vertexIndex].pos.y / radius;
      vert[vertexIndex].norm.z = vert[vertexIndex].pos.z / radius;
      vert[vertexIndex].norm.w = 0.0f;

      vert[vertexIndex].norm = normalize(vert[vertexIndex].norm);

      vert[vertexIndex].pos.x += pLight->pos.x; // move to pLight->pos
      vert[vertexIndex].pos.y += pLight->pos.y; // move to pLight->pos
      vert[vertexIndex].pos.z += pLight->pos.z; // move to pLight->pos

      vert[vertexIndex].t.x = (float)j / (float)numberSlices;
      vert[vertexIndex].t.y = (1.0f - (float)i) / (float)(numberParallels - 1);

      vert[vertexIndex].material_id = addedMaterialId;
    }
  }

  unsigned int* indexBuf = indices;
  for (int i = 0; i < numberParallels; i++)
  {
    for (int j = 0; j < numberSlices; j++)
    {
      *indexBuf++ = i * (numberSlices + 1) + j;
      *indexBuf++ = (i + 1) * (numberSlices + 1) + j;
      *indexBuf++ = (i + 1) * (numberSlices + 1) + (j + 1);

      *indexBuf++ = i * (numberSlices + 1) + j;
      *indexBuf++ = (i + 1) * (numberSlices + 1) + (j + 1);
      *indexBuf++ = i * (numberSlices + 1) + (j + 1);
    }
  }*/

  //this->AddTriangles(vert, numberVertices, indices, numberIndices);

  //delete [] vert;
  //delete [] indices;

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::AddLightsAsGeometry()
{
  // add lights
  //
  int oldMaterialSize = int(m_hydraMaterials.size());

  for(int lightIndex=0; lightIndex < m_lights.size(); lightIndex++)
  {
    Light* pLight = &m_lights[lightIndex];

    if(!(pLight->flags & Light::LIGHT_AS_GEOMETRY) && !(pLight->flags & RAYTR::Light::LIGHT_SKY_PORTAL)) // for sky portals we have special case
      continue;

    if( pLight->GetLightType() == Light::LIGHT_TYPE_POINT || 
        pLight->GetLightType() == Light::LIGHT_TYPE_SPOT  || 
        pLight->GetLightType() == Light::LIGHT_TYPE_DIRECTIONAL ||
        pLight->GetLightType() == Light::LIGHT_TYPE_SKY ||
        pLight->GetLightType() == Light::LIGHT_TYPE_MESH)
      continue;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    RAYTR::HydraMaterial material;
    material.ambient.color = pLight->color*pLight->emittance; // 
    material.flags |= HydraMaterial::THIS_IS_LIGHT;
    material.ambient.light_id = lightIndex;

    material.diffuse.color      = float3(0,0,0);
    material.specular.color     = float3(0,0,0);
    material.reflection.color   = float3(0,0,0);
    material.transparency.color = float3(0,0,0);

    if(pLight->flags & RAYTR::Light::LIGHT_SKY_PORTAL) // special case for sky portals
    {
      material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE; // ok
      material.flags |= HydraMaterial::MATERIAL_SKIP_SHADOW;

      //std::cerr << "sky portal detected" << std::endl;

      if(!(pLight->flags & Light::LIGHT_AS_GEOMETRY))
      {
        material.flags |= HydraMaterial::EMISSIVE_MATERIAL_SKIP_SKY_PORTAL; // skip invisiable sky portal
        pLight->flags  |= Light::LIGHT_AS_GEOMETRY;
        //std::cerr << "invisiable sky portal detected" << std::endl;
      }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    int addedMaterialId = this->AddMaterial(material);

    if (pLight->flags & RAYTR::Light::LIGHT_SKY_PORTAL)
    {
      //std::cerr << "sky portal mat id = " << addedMaterialId << std::endl;
      //if(m_hydraMaterials[addedMaterialId].flags & HydraMaterial::TRANSPARENCY_THIN_SURFACE)
        //std::cerr << "sky portal mat, thin" << std::endl;

      //if (m_hydraMaterials[addedMaterialId].flags & HydraMaterial::MATERIAL_SKIP_SHADOW)
        //std::cerr << "sky portal mat, spik shadow" << std::endl;
    }

    // now add geometry of light
    //
    if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA)
    {
      // quad triangles
      const int numVert = 4;
      const int numIndices = 6;
      Vertex4f  vert[numVert];
      unsigned int indices[numIndices];

      // triangles
      vec2f size = pLight->GetAreaLightSize();
      vert[0].pos.set(-size.x, 0, -size.y, 1); vert[0].norm = to_float4(pLight->GetNormal(),1);
      vert[1].pos.set(-size.x, 0, size.y, 1);  vert[1].norm = to_float4(pLight->GetNormal(),1);
      vert[2].pos.set(size.x, 0, size.y, 1);   vert[2].norm = to_float4(pLight->GetNormal(),1);
      vert[3].pos.set(size.x, 0, -size.y, 1);  vert[3].norm = to_float4(pLight->GetNormal(),1);

      Matrix4x4f mTransform, mRotation, mTranslate;
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          mRotation.M[i][j] = pLight->GetMatrixElem(i,j);
      mTranslate.SetTranslate(pLight->pos);
      mTransform = mTranslate*mRotation;

      for(int i=0;i<numVert;i++)
      {
        vert[i].pos = mTransform*vert[i].pos;
        vert[i].material_id = addedMaterialId;
      }

      indices[0]=0;indices[1]=1;indices[2]=2;
      indices[3]=2;indices[4]=3;indices[5]=0;

      this->AddTriangles(vert,numVert,indices,numIndices);

    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_AREA_DISK)
    {
      const int numVert = 64;
      const int numIndices = numVert*3;

      Vertex4f*     vert    = new Vertex4f[numVert+1];
      unsigned int* indices = new unsigned int[numIndices+3];

      const int LAST_VERT = numVert;

      // disk center
      //
      vert[LAST_VERT].pos.set(0, 0, 0, 1); 
      vert[LAST_VERT].norm = to_float4(pLight->GetNormal(),1 );
      vert[LAST_VERT].material_id = addedMaterialId;

      // disk perimeter
      //
      float R = pLight->GetSphericalLightRadius();

      for(int i=0;i<numVert;i++)
      {
        float angle = 2.0f*MGML_MATH::PI*float(i)/float(numVert);

        vec2f pos;
        pos.x = cos(angle);
        pos.y = sin(angle);

        vert[i].pos.set(pos.x*R, 0, pos.y*R, 1); 
        vert[i].norm = to_float4(pLight->GetNormal(), 1);
        vert[i].material_id = addedMaterialId;
      }

      for(int i=0;i<numVert;i++)
      {
        indices[i*3+0] = LAST_VERT;
        indices[i*3+1] = i;
        indices[i*3+2] = i+1;
      }

      indices[numIndices+0] = LAST_VERT;
      indices[numIndices+1] = numVert-1;
      indices[numIndices+2] = 0;

      Matrix4x4f mTransform, mRotation, mTranslate;
      for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
          mRotation.M[i][j] = pLight->GetMatrixElem(i,j);

      mTranslate.SetTranslate(pLight->pos);
      mTransform = mTranslate*mRotation;

      for(int i=0;i<numVert+1;i++)
        vert[i].pos = mTransform*vert[i].pos;

      this->AddTriangles(vert, numVert+1, indices, numIndices+3);

      delete [] vert; vert = NULL;
      delete [] indices; indices = NULL;

    }
    else if(pLight->GetLightType() == Light::LIGHT_TYPE_SPHERICAL)
    {      
      //Sphere4f sph;
      //sph = Sphere4f(vec4f(pLight->pos.x, pLight->pos.y, pLight->pos.z,1), pLight->GetSphericalLightRadius());
      //sph.material_id = addedMaterialId;
      //int id = this->AddSpheres(&sph,1);
      //pLight->SetPrimitiveId(id);
      AddSphereAsMesh(pLight, addedMaterialId);
    }
    else
      RUN_TIME_ERROR("AddLightsAsGeometry: unknown light type");
  }

  AddLightsFromEmissiveMaterials(oldMaterialSize);


  m_lightsWasAddedAsGeometry = true;
}

////////////////////////////////////////////////////////////////////////
////
void Ray_Tracer::AddLightsFromEmissiveMaterials(int a_oldMaterialSize)
{
  // add lights from emissive materials
  //
  bool emissiveLights = false;
  for(int i=0;i<a_oldMaterialSize; i++)
  {
    if(m_hydraMaterials[i].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT)
    {
      emissiveLights = true;
      break;
    }
  }

  if(!emissiveLights)
    return;

  m_lightMeshIdListByMatId.clear();

  // emissive triangle meshes
  //
  for(int i=0;i<m_triangleMaterialId.size();i++)
  {
    int matId = m_triangleMaterialId[i];
    if(matId >= a_oldMaterialSize) // these materials was added from existing lights, so we don't have to add their geometry twice
      continue;

    if(m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT)
    {
      if(m_lightMeshIdListByMatId.find(matId) != m_lightMeshIdListByMatId.end())
      {
        continue;
      }
      else  // remember all triangles for each emissive material
      {
        m_lightMeshIdListByMatId[matId] = std::vector<int>();
        std::vector<int>& triList = m_lightMeshIdListByMatId[matId];
        triList.reserve(1000);

        for(size_t j=0;j<m_triangleMaterialId.size(); j++)
        {
          if(m_triangleMaterialId[j] == matId)
            triList.push_back(j);
        }
        int a = 2;
      }


      // add light mesh (triStart, triEnd)
      //
      RAYTR::Light light;

      light.SetLighType(Light::LIGHT_TYPE_MESH);
      light.intensity   = m_hydraMaterials[matId].ambient.light_multiplyer;
      light.emittance   = m_hydraMaterials[matId].ambient.light_multiplyer;
      light.color       = m_hydraMaterials[matId].ambient.color;
      light.pos         = float3(0,0,0);
      light.m_norm      = float3(0,-1,0);
      light.kc          = 0.01;
      light.kl          = 0;
      light.kq          = 1.0;
      light.matId       = matId;

      bool disablePhotons =  (m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::EMISSION_DISABLE_FOR_PHOTONMAP) || 
                             (m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::EMISSIVE_FORBID_CAST_GI); 
      
      // if material is a thin wall that skips shadow, disable photon maps
      //                    ((m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::MATERIAL_SKIP_SHADOW) && (m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::TRANSPARENCY_THIN_SURFACE) ||

      if(disablePhotons)
        light.flags |= RAYTR::Light::LIGHT_DISABLE_FOR_PHOTONMAP;

      light.emissiveTexId = m_hydraMaterials[matId].ambient.color_texId;
      light.emissiveTexMatrixId = m_hydraMaterials[matId].ambient.color_texMatrixId;

      m_hydraMaterials[matId].ambient.light_id = this->AddLight(light);
      m_hydraMaterials[matId].flags |= HydraMaterial::MATERIAL_LIGHT_MESH;

      const RAYTR::Light& lightAdded = this->GetLight(m_hydraMaterials[matId].ambient.light_id);
      if(lightAdded.IsSampledDirectly())
        m_hydraMaterials[matId].flags |= HydraMaterial::MATERIAL_LIGHT_MESH_SKIP_DIFFUSE;

    }
  }

  // emissive spheres
  //
  for(int i=0;i<m_spheres.size();i++)
  {
    int matId = m_spheres[i].material_id;
    if(matId >= a_oldMaterialSize) // these materials was added from existing lights, so we don't have to add their geometry twice
      continue;

    if(m_hydraMaterials[matId].flags & RAYTR::HydraMaterial::THIS_IS_LIGHT) // add light sphere
    {
      RAYTR::Light light;

      float radius = m_spheres[i].r;

      light.SetLighType(Light::LIGHT_TYPE_SPHERICAL);
      light.intensity = m_hydraMaterials[matId].ambient.light_multiplyer; //10.0f/(4.0f*MGML_MATH::PI*radius*radius); 
      light.color     = m_hydraMaterials[matId].ambient.color;
      light.pos       = to_float3(m_spheres[i].pos);
      light.m_norm    = float3(0,-1,0);
      light.kc        = 1.0; // http://imdoingitwrong.wordpress.com/2011/01/31/light-attenuation/
      light.kl        = 0.0f; // 2.0f/radius;
      light.kq        = 1.0;  ///(4.0f*MGML_MATH::PI);  //1.0/(radius*radius);
      light.SetSphericalLightRadius(radius);

      this->AddLight(light);
    }

  }




}
