// � Copyright 2014 Vladimir Frolov, KIAM RAS
//
#include "GPU_Ray_Tracer.h"

#include <map>
#include <string>

using namespace MGML_MATH;

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

class AreaDiffuseLight : public ILight
{
public:

  AreaDiffuseLight(float3 a_pos, float2 a_size, float3 a_norm, const float a_matrix[3][3], float3 a_intensity, int a_texId, int a_texMatrixId, float a_lightSurfaceArea, bool isSkyPortal)
  {
    m_plain.data[PLIGHT_POS_X] = a_pos.x;
    m_plain.data[PLIGHT_POS_Y] = a_pos.y;
    m_plain.data[PLIGHT_POS_Z] = a_pos.z;

    m_plain.data[PLIGHT_NORM_X] = a_norm.x;
    m_plain.data[PLIGHT_NORM_Y] = a_norm.y;
    m_plain.data[PLIGHT_NORM_Z] = a_norm.z;

    m_plain.data[PLIGHT_COLOR_X] = a_intensity.x;
    m_plain.data[PLIGHT_COLOR_Y] = a_intensity.y;
    m_plain.data[PLIGHT_COLOR_Z] = a_intensity.z;

    m_plain.data[PLIGHT_COLOR_TEX]        = a_texId;
    m_plain.data[PLIGHT_COLOR_TEX_MATRIX] = a_texMatrixId;

    m_plain.data[PLIGHT_SURFACE_AREA]  = a_lightSurfaceArea;

    m_plain.data[AREA_LIGHT_SIZE_X] = a_size.x;
    m_plain.data[AREA_LIGHT_SIZE_Y] = a_size.y;

    m_plain.data[AREA_LIGHT_MATRIX_E00] = a_matrix[0][0];
    m_plain.data[AREA_LIGHT_MATRIX_E01] = a_matrix[0][1];
    m_plain.data[AREA_LIGHT_MATRIX_E02] = a_matrix[0][2];

    m_plain.data[AREA_LIGHT_MATRIX_E10] = a_matrix[1][0];
    m_plain.data[AREA_LIGHT_MATRIX_E11] = a_matrix[1][1];
    m_plain.data[AREA_LIGHT_MATRIX_E12] = a_matrix[1][2];

    m_plain.data[AREA_LIGHT_MATRIX_E20] = a_matrix[2][0];
    m_plain.data[AREA_LIGHT_MATRIX_E21] = a_matrix[2][1];
    m_plain.data[AREA_LIGHT_MATRIX_E22] = a_matrix[2][2];

    ((int*)m_plain.data)[PLIGHT_TYPE]  = PLAIN_LIGHT_TYPE_AREA_DIFFUSE;
  }


  ShadowSample Sample(float4 rands, float3 illuminatingPoint)                  const { return areaDiffuseLightSample(&m_plain, rands, illuminatingPoint); }
  float        EvalPDF(float3 illuminatingPoint, float3 rayDir, float hitDist) const { return areaDiffuseLightEvalPDF(&m_plain, rayDir, hitDist); }
  float3       GetIntensity(float2 a_texCoord)                                 const { return areaDiffuseLightGetIntensity(&m_plain, a_texCoord); }


protected:
  

};



void GPU_Ray_Tracer::ConvertAllLegacyLights(const std::vector<RAYTR::Light>& a_legacy, std::vector<ILight*>* a_pLightsModern)
{
  a_pLightsModern->resize(a_legacy.size());

  for (size_t i = 0; i < a_pLightsModern->size(); i++)
    a_pLightsModern->at(i) = NULL;

  int counter = 0;
  for (size_t i = 0; i < a_pLightsModern->size(); i++)
  {

    if (a_legacy[i].GetLightType() == RAYTR::Light::LIGHT_TYPE_AREA)
    {
      a_pLightsModern->at(counter) = new AreaDiffuseLight(a_legacy[i].pos, a_legacy[i].GetAreaLightSize(), a_legacy[i].GetNormal(), a_legacy[i].M, a_legacy[i].color*a_legacy[i].intensity, a_legacy[i].emissiveTexId, a_legacy[i].emissiveTexMatrixId, a_legacy[i].surfaceArea, (a_legacy[i].flags & Light::LIGHT_SKY_PORTAL));
      counter++;
    }
  
  }

}

void GPU_Ray_Tracer::ConvertAllModernLights(const std::vector<ILight*>& a_pLightsModern, std::vector<PlainLight>* a_pLightsPlain)
{
  a_pLightsPlain->resize(a_pLightsModern.size());

  for (size_t i = 0; i < a_pLightsModern.size(); i++)
  {
    if (a_pLightsModern[i] != NULL)
      a_pLightsPlain->at(i) = a_pLightsModern[i]->ConvertToPlainLight();
  }
}

