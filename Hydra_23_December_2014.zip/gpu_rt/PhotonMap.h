#pragma once

struct BuildOctreeTimings
{
  BuildOctreeTimings() {clear();}
  void clear() {photonSortingTime = appendRefsTime = sortRefs = allocFreeTime = memcpyFromSymbolTime = otherOverhead = 0.0f;
                appendNodesTime = sortNodes = 0.0f;}

  float photonSortingTime;
  float appendRefsTime;
  float appendNodesTime;
  float sortRefs;
  float sortNodes;
  float allocFreeTime;
  float memcpyFromSymbolTime;
  float otherOverhead;
  Timer timer;
};


//////////////////////////////////////////////////////////////////////////////////////////////////////////
// a simple but important note for ppm
// sqr(r[i+1])/sqr(r[i]) = (i+alpha)/(i+1);    
// r[i+1] = sqrt( r[i]*r[i]*(i+alpha)/(i+1)); 
// alpha seems to be = 2/3; Must be in [0,1
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

class IPhotonMap
{
public:
  IPhotonMap();
  IPhotonMap(int a_maxPhotons);
  virtual ~IPhotonMap();

  virtual void Clear() = 0;
  virtual void FreePhotonsMemory() = 0;
  virtual void TracePhotons() = 0;
  virtual void BuildOctree(float a_gartherRadius, BuildOctreeTimings* a_timeData = NULL)  = 0; // construct multiple reference octree
  
  virtual void BindTextures() = 0;                      // bind all necessary data to texrefs 
  virtual void UnbindTextures() = 0;

  virtual void  SetMaxPhotons(int a_maxPhotons) = 0;
  virtual int   GetMaxPhotons()  const = 0;
  virtual int   GetCurrPhotons() const = 0;

  virtual bool  IsCausticMap() const = 0;
  virtual bool  HasPhotonEmitters() const = 0;
  virtual PhotonMapArgs KernelData() const = 0;


  virtual void  SetSceneBox(const float3& a_boxMin, const float3& a_boxMax) = 0;
  virtual void  SetLights(const RAYTR::Light* a_lights, int a_numLights) = 0;
  virtual void  SetGartherRadius(float a_radius) = 0;


  virtual void BuildLightsTable() = 0; // this is for DL sampling only
  virtual LightTableInfo LightsTable() = 0;

  virtual void  GetPhotonsPosColorToGLBuffers(GLuint posBuffId, GLuint colBuffId);
  virtual void  DebugSaveToFile(const char* posName, const char* posNormName, const char* colorNormName);

  // normally you should not use these functions, but for some reasons they are needed 
  //
  //virtual void SetPhotonsBox(const float3& a_boxMin, const float3& a_boxMax) = 0;
  virtual void ResizeCurrPhotons(int a_size) = 0;
  
  virtual HitPosNorm* GetGPUPosNormPointer() = 0;
  virtual ushort4*    GetGPUColorPointer()   = 0;

  virtual void RememberCurrentBoundingBox() = 0;

  virtual uint*  GetGPULighList() = 0;
  virtual uint2* GetGPULighListBegEnd() = 0;


  float3 m_photonsBoxMin;  // have to store them here, because core CUDA code have to update them on the CPU side while working with IPhotonMap
  float3 m_photonsBoxMax;

protected:

  IPhotonMap(const IPhotonMap& rhs) {}
  IPhotonMap& operator=(const IPhotonMap& ths) {return *this;}

};


class IIrradianceMap
{
public:

  virtual void Update(IPhotonMap* a_pPhotonMap) = 0;
  virtual void Clear() = 0;

  virtual void BindTextures() = 0;  
  virtual void GetOctreeSize(float* pMaxIndex, int* pLeafsArraySize) = 0;
  virtual void GetPhotonsBox(float3* a_boxMin, float3* a_boxMax) const = 0;
};


IPhotonMap* hlmCreatePhotonMap(int a_maxPhotons, bool a_caustic = false, bool a_dlmap = false);
void hlmDeletePhotonMap(IPhotonMap* a_pPhotonMap);


IIrradianceMap* hlmCreateIrradianceMap();
void hlmDeleteIrradianceMap(IIrradianceMap* a_pPhotonMap);


#ifdef __CUDACC__

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#include "float4.cuh"

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

class ILight;

class PhotonMap : public IPhotonMap
{
public:
  PhotonMap(int a_maxPhotons, bool a_caustic, bool a_dlmap);
  ~PhotonMap();

  void Clear();
  void FreePhotonsMemory();

  void TracePhotons();
  void BuildOctree(float a_gartherRadius, BuildOctreeTimings* a_timeData = NULL);
  void BindTextures();
  void UnbindTextures();

  PhotonMapArgs KernelData() const;

  float EnegryScale() const;
  bool  IsCausticMap() const;
  bool  HasPhotonEmitters() const;

  void  SetMaxPhotons(int a_maxPhotons);
  int   GetMaxPhotons()  const;
  int   GetCurrPhotons() const;


  void  SetSceneBox(const float3& a_boxMin, const float3& a_boxMax);
  void  GetPhotonsBox(float3* a_boxMin, float3* a_boxMax) const;

  void  SetGartherRadius(float a_radius);
  float GetGartherRadius() const;

  void  SetLights(const RAYTR::Light* a_lights, int a_numLights);

  void  GetOctreeSize(float* pMaxIndex, int* pLeafsArraySize) const; 

  void  GetPhotonsPosColorToGLBuffers(GLuint posBuffId, GLuint colBuffId);
  void  DebugSaveToFile(const char* posName, const char* posNormName, const char* colorNormName);

  void  BuildLightsTable();
  LightTableInfo LightsTable();

  //void SetPhotonsBox(const float3& a_boxMin, const float3& a_boxMax);
  void ResizeCurrPhotons(int a_size);

  HitPosNorm* GetGPUPosNormPointer();
  ushort4*    GetGPUColorPointer();
  int         GetCurPhotonsNum();

  uint*  GetGPULighList();
  uint2* GetGPULighListBegEnd();

  void RememberCurrentBoundingBox();

  thrust::device_vector<uint>  m_octreeZIndex;

protected:

  PhotonMap(const PhotonMap& rhs) {}
  PhotonMap& operator=(const PhotonMap& ths) {return *this;}

  int  GetCurrPhotonsOnGPU();
  void ClearPhotonsOnGPU();
  void DecompressPhotonsNorm( thrust::device_vector<HitPosNorm>& a_inData, thrust::device_vector<ushort4>& a_outData);

  thrust::device_vector<HitPosNorm> m_photonsPosNorm;
  thrust::device_vector<ushort4>    m_photonsColor;
  thrust::device_vector<ushort4>    m_photonsNormDecompressed;

  int m_maxPhotons;
  int m_currPhotons;
  int m_emittedPhotons;
  bool m_causticMap;     // caustic map
  bool m_dlMap;          // direct light sampling map

  thrust::device_vector<uint2> m_octreeNodes;
  thrust::device_vector<uint>  m_octreeOffsets;
  thrust::device_vector<uint>  m_lightsTable;
  LightTableInfo               m_ltInfo;

  thrust::device_vector<uint>  m_lightTableList;
  thrust::device_vector<uint2> m_lightTableListBeginEnd;

  int                           m_passNum;
  PhotonMapArgs                 m_firstPortionData;

  std::vector<ILight*> m_lights;
  int m_originalLightsNumber; // original lights number, including lights that does not emit any photons. 

  void BeforePhotonsTrace();
  void AfterPhotonsTrace();

  float3 m_sceneBoxMin, m_sceneBoxMax;
  
  // photonsMpaArgs data
  float  m_gartherRadius;
  int    m_MAX_INDEX;



  // for debug needs only
  //
  GLuint m_glPosBuff;
  GLuint m_glColBuff;
  
  union
  {
    struct
    {
      struct cudaGraphicsResource* m_glPosRes;
      struct cudaGraphicsResource* m_glColRes;
    };

    struct cudaGraphicsResource* m_glResources[2];
  };

};


class IrradianceMap : public IIrradianceMap
{
public:

  IrradianceMap();
  ~IrradianceMap();

  void Update(IPhotonMap* a_pPhotonMap);
  void Clear();

  void BindTextures();  
  void GetOctreeSize(float* pMaxIndex, int* pLeafsArraySize);
  void GetPhotonsBox(float3* a_boxMin, float3* a_boxMax) const;

protected:

  thrust::device_vector<float4> m_imapData;
  thrust::device_vector<uint>   m_iMapOctreeZIndex;
  PhotonMapArgs                 m_firstPortionData;
  int                           m_passNum;

};


void MROctree_Last3Steps(thrust::device_ptr<uint> a_keysBegin, int a_keysSize, thrust::device_ptr<uint> a_photonOffsetsBegin,
                         thrust::device_vector<uint2>& octreeNodes, thrust::device_vector<uint>& zindex, BuildOctreeTimings* a_timeData, int a_phNum);


#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif

class ILight
{
public:
  ILight(){}
  virtual ~ILight() {}

  virtual void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size) = 0;
  virtual void  SetSceneBox(float3 a_boxMin, float3 a_boxMax);
  virtual std::string LightTypeName();

protected:
  ILight(const ILight& rhs) {}
  ILight& operator=(const ILight& rhs) { return *this; }

  int m_lightId;
};

class AreaLight : public ILight
{
public:
  AreaLight();
  AreaLight(const RAYTR::Light& a_lightPOD, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  std::string LightTypeName();

protected:

  float3 pos;
  float3 norm;
  float2 size;
  float3 m_intensity;
  float  surfaceArea;
  int    m_lightDistrType;
  int    m_flags;
  float  m_spotCos[2];

  union
  {
    float mRot[3][3];
    float mRotL[9];
  };

};


class AreaDiskLight : public ILight
{
public:
  AreaDiskLight();
  AreaDiskLight(const RAYTR::Light& a_lightPOD, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  std::string LightTypeName();

protected:

  float3 pos;
  float3 norm;
  float  m_radius;
  float3 m_intensity;
  float  surfaceArea;
  int    m_lightDistrType;
  int    m_flags;
  float  m_spotCos[2];

  union
  {
    float mRot[3][3];
    float mRotL[9];
  };

};

class DirectionalLight : public ILight
{
public:
  DirectionalLight();
  DirectionalLight(const RAYTR::Light& a_lightPOD, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  void  SetSceneBox(float3 a_boxMin, float3 a_boxMax);
  std::string LightTypeName();

protected:

  float3 pos;
  float3 norm;
  float3 m_intensity;

  float3 m_boxMin, m_boxMinLS;
  float3 m_boxMax, m_boxMaxLS;

  float  m_circleSize[2];

  float4x4 mViewTransform, mInvViewTransform;

};


class SpotLight : public ILight
{
public:
  SpotLight();
  SpotLight(const RAYTR::Light& a_lightPOD, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  std::string LightTypeName();

protected:

  float3 norm;
  float3 pos;
  float3 m_intensity;

  float faloffCos1;
  float faloffCos2;

};


class SphereLight : public ILight
{
public:
  SphereLight();
  SphereLight(const RAYTR::Light& a_lightPOD, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  std::string LightTypeName();

protected:

  float3 pos;
  float  radius;
  float3 m_intensity;
  float  surfaceArea;


};

class PointLight : public ILight
{
public:
  PointLight();
  PointLight(const RAYTR::Light& a_lightPOD, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  std::string LightTypeName();

protected:

  float3 pos;
  float3 m_intensity;

};


class MeshLight : public ILight
{
public:
  MeshLight();
  MeshLight(const RAYTR::Light& a_lightPOD, const thrust::device_vector<float4>& a_triPos, const thrust::device_vector<float2>& a_triTexCoord, const thrust::device_vector<float2>& a_triProb, int a_lightId);

  void  EmitPhotons(float4* rpos, float4* rdir, float4* colors, int a_size);
  std::string LightTypeName();

protected:

  float3 pos;
  float3 m_intensity;

  int emissiveTexId;
  int emissiveTexMatrixId;

  thrust::device_vector<float4> m_triPos;
  thrust::device_vector<float2> m_triProb;
  thrust::device_vector<float2> m_triTexCoord;
};


ILight* CreateLight(const RAYTR::Light& a_lightPOD, int a_lightId, bool a_causticMap, bool a_dlMap);


#endif

