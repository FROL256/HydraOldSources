// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#define RTLIB_GUARDIAN

#ifndef __CUDACC__
  #ifndef MGML_GUARDIAN
    #include "../CSL/MGML.h"
  #endif
#endif

#ifndef RTGLOBALS
  #include "../gpu_rt/globals.h"
#endif

#ifndef RTCTRACE
  #include "../gpu_rt/ctrace.h"
#endif


#ifndef CONFIG_GUARDIAN
  #include "../bvh_builder/config.h"
#endif

enum {GPU_RT_MEMORY_SAFE_MODE      = 1, 
      GPU_RT_MEMORY_FULL_SIZE_MODE = 2,
      GPU_RT_NOWINDOW              = 4,
      GPU_RT_HW_LAYER_CUDA         = 8,
      GPU_RT_HW_LAYER_OCL          = 16,
      GPU_RT_HW_LAYER_FRSDK        = 32,
      };

#ifndef ACCEL_STRUCT_GUARDIAN
  #include "../bvh_builder/AccelerationStructure.h"
#endif


#ifndef TRANSIT_PRIMITIVES_GUARDIAN
  #include "Transit_Primitives.h"
#endif

#ifndef MATERIAL_GUARDIAN
  #include "Material.h"
#endif

#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif

namespace RAYTR
{

enum RAY_TYPES {EYE_RAY,
                SHADOW_RAY,
                REFLECTED_RAY,
                REFRACTED_RAY};

enum ACCELERATION_STRUCRURES {ACCEL_STRUCT_KD_TREE,
                              ACCEL_STRUCT_BVH,
                              ACCEL_STRUCT_HIERARHICAL_GRID};


#ifdef __CUDACC__


#ifndef RANDOMC_H
  #include "random_mc.h"
#endif

//#include <curand.h>
//#include <curand_kernel.h>


#else

  //#define __align__(N)

#endif


struct RaySampleOther
{
  float u,v;
};



struct PhotonMapArgs
{
  float3 boxMin;
  float3 boxMax;
  float  gartherRadius;
  float  lightScaleConstant;
  int    treeSize;
  float  INDEX_MAX;
  bool   causticMap;
};



struct LightTableInfo
{
  enum { MAX_PHOTONS_FOR_LIGHT_PER_NODE = 65535 };
  typedef unsigned short PQIndex; // Photon Quantity Intex

  int numLights;    // table size x
  int numNodes;     // table size y
  int pitchInWords; // table pitch (analog of size x) in ints
  PQIndex* data;
};

#define LTWPITCH (sizeof(uint)/sizeof(LightTableInfo::PQIndex))


}

class IPhotonMap;
class IIrradianceMap;

using namespace RAYTR;

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

enum HRT_ERROR_CODES
{
    HRT_NO_MEMORY_AVALIABLE = 1,
    HRT_INCORRECT_SIZE = 2,
    HRT_ZERO_SIZE = 3,
    HRT_INCORRECT_INTERNAL_PARAMETER = 4,
    HRT_UNEXPECTED_FUNCTION_FAIL = 5
};


extern "C" const char* hrtGetErrorMessage(int err_code);
extern "C" int hrtInit(int w,int h, int a_flags);
extern "C" int hrtDelete();
extern "C" int hrtPrintInfo();
extern "C" int hrtCudaDeviceReset();

#ifdef __CUDACC__
  #ifndef GLuint
    typedef unsigned int GLuint;
  #endif
#endif

extern "C" int hrtBeginTrace(uint AA);
extern "C" int hrtEndTrace(GLuint a_pbo, unsigned int* buffer);
extern "C" int hrtRegisterPBO(GLuint a_pbo);
extern "C" int hrtUnregisterPBO();

extern "C" int hrtFillXYBuffer();
extern "C" int hrtFillXYBufferAndClearAccumBuffers();

extern "C" int hrtTraceClientRays1D(const float4* cpu_ray_pos, const float4* cpu_ray_dir, int a_size);
extern "C" int hrtGetColor(float4* cpu_color, int a_size);

extern "C" int hrtMegaBlockTrace1D(float4* rpos, float4* rdir, float4* finalColor, int a_size, int a_deep, uint* a_realThreadsId);

//extern "C" int hrtSetWorldMatrix(const float* matrix);
extern "C" int hrtSetSpheres(const sphere4* spheres,int n);
extern "C" int hrtSetCommonVertexAttributes(const float4* vPos, const float4* vNorm, const float2* vTexCoord, const int* vMaterialIndices, int n);
extern "C" int hrtSetTangentAtrributes(const float4* vTan, int n);
extern "C" int hrtSetIndices32(const unsigned int* indices,int n);

extern "C" int hrtSetCurrAccelStructType(int a_type);
extern "C" int hrtSetWorldObjectListData(const char* in_objListData, uint in_sizeInBytes, uint triNumInList);

extern "C" int hrtSetWorldBVH(const BVHNode* root, unsigned int nodes_count);

extern "C" int hrtSetRegularBBox(float3 vmin, float3 vmax);

extern "C" int hrtSetHydraMaterials(const RAYTR::HydraMaterial* materials,int n);

extern "C" int hrtSetLights(const RAYTR::Light* a_lights, int n);
extern "C" int hrtAddLightMesh(float4* a_triangles, float2* a_texCoords, float2* a_probIntervals, int N);

extern "C" int hrtSetTextureMatrices(const float* a_matrices, int n);

extern "C" int hrtComputeHitPass(int a_size, const float4* rpos, const float4* rdir, const Lite_Hit* in_hits, RayFlags* pt_flags,
                                 HitPosNorm* out_hitPos, HitTexCoord* out_hitNorm, HitMatRef* out_matData, Hit_Part4* out_hitTangent);

extern "C" int hrtTraverseRays1D(float4* gpu_rpos, float4* gpu_rdir, Lite_Hit* gpu_out_hit, int a_size, Timer& a_timer, const RayFlags* pt_flags);
extern "C" int hrtTraverseMegaBlock(float4* gpu_rpos, float4* gpu_rdir, Lite_Hit* gpu_out_hit, int a_size);




extern "C" int hrtSetWindowResolution(int w, int h);
extern "C" int hrtVerifySystem();
extern "C" int hrtGetPerfInfo(float*, int index);
extern "C" size_t hrtGetAvaliableMemoryAmount(bool all = false);

extern "C" int hrtGetMegaBlockSize();
extern "C" int hrtSetFlags(int bits,int value);
extern "C" int hrtSetAllFlags(int a_flags);
extern "C" int hrtGetFlags();

extern "C" int hrtPushAllFlags();
extern "C" int hrtPopAllFlags();
extern "C" int hrtPushAllVars();
extern "C" int hrtPopAllVars();

extern "C" int   hrtSetVariableF(int name, float value);
extern "C" int   hrtSetVariableI(int name, int value);
extern "C" float hrtGetVariableF(int name);
extern "C" int   hrtGetVariableI(int name);

extern "C" int hrtDumpFloat4Buffer(const float4* a_gpu_buff, int size, const char* fileName);
extern "C" int hrtDumpInt2Buffer(const int2* a_gpu_buff, int size, const char* fileName);
extern "C" int hrtDumpBuffer(const void* a_gpu_buff, int byteSize, const char* fileName);
extern "C" int hrtLoadBuffer(const char* a_gpu_buff, int byteSize, const char* fileName);

extern "C" int hrtBeginAnyncLDRImageCopy(void* data);
extern "C" int hrtEndAnyncLDRImageCopy();

extern "C" int hrtGetBuffer(const char* a_buffName, void* data, int byteSize, GLuint a_pbo);
extern "C" int hrtGetBufferSize(const char* a_buffName);

extern "C" void  hrtResetCounters();
extern "C" MRaysStat hrtGetRaysStat();

extern "C" bool hrtIfSortNow(int a_bounce);
extern "C" bool hrtIfCompactNow(int a_bounce);

extern "C" int hrtStorePositionsAndNormalsForIC(int a_size, const RayFlags* a_flags);
extern "C" int hlmAllocIrradianceCacheFullScreenBuffers(int size, int allocPart = 2);
extern "C" int hlmFreeIrradianceCacheFullScreenBuffers();
extern "C" int hlmCalcSurfaceDiscontinuity(float* discontinuityMips, float* pixelSize, bool noDithering);
extern "C" int hlmGetFullScreenRadiance(float3* a_radianceCPU);
extern "C" int hlmCalcRadianceDiscontinuity(float* a_discontinuityCPU, int a_size, int a_minPixelStep);

extern "C" int hrtClearMegaTextures();
extern "C" int hrtAddMegaTexture4ub(const char* usage, bool outOfCore, const char* data, int width, int height, const float4* lut, int lutSize);
extern "C" int hrtAddMegaTexture1ub(const char* usage, bool outOfCore, const char* data, int width, int height, const float4* lut, int lutSize);
extern "C" int hrtAddMegaTexture4f(const char* usage, bool outOfCore, const float*, int width, int height, const float4* lut, int lutSize);

extern "C" int hrtCreateEnvLightMapCube(int w, int h, const void* data[6]);

extern "C" int hrtFindBoundingBox(float4* a_inBufferMin, float3* a_pMinCPU, float3* a_pMaxCPU, int a_dataSize);
extern "C" int hrtFindBoundingBoxRef(float4* a_inBufferMin, float3* a_pMinCPU, float3* a_pMaxCPU, int a_dataSize);


// helpers to get more memory
// use them if you are strongly out of memory inside some algorithm
//
extern "C" int hrtAllocScreenBuffersData(int w = -1, int h = -1);
extern "C" int hrtFreeScreenBuffersData();

extern "C" int hrtFreePerRayData();
extern "C" int hrtAllocPerRayData(int a_size = -1);

extern "C" int hrtPTAllocPerRayData(int a_size = -1);
extern "C" int hrtPTFreePerRayData();


extern "C" int hrtPhotonMapSetActiveMap(const char* usage, IPhotonMap* pPhotonMap, bool a_active);
extern "C" int hrtRadianceCacheSetGlobalAlpha(float a_alpha);
extern "C" int hrtSetActiveIrradianceMap(IIrradianceMap* a_pIrradMap);

extern "C" int hrtClearPrimitiveIndicesFromFGFlags(int a_flag);

extern "C" int hrtThreadSynchronize();
extern "C" int hrtNextSwizzlePattern();

extern "C" int hrtGetFullScreenBoundaryPixels(const float4* a_normAndDepth, int2* a_outBuffer);
extern "C" int hrtSaveBoundarySubSamples(const char* out_fileName, const char* out_fileName2);

extern "C" float hrtEstimateAvgPixelSize();
extern "C" float2 hrtPixelsSizeSumm(HitPosNorm* a_hitPositions, HitMatRef* a_materials, int a_size);

extern "C" int hrtSetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16]);
extern "C" int hrtInitMortonTableGPU(ushort** a_ppTable);

extern "C" int testMinMax();
extern "C" int testMinMaxBig();

// crap

extern "C" const char* sga_cudaMemcpyToSymbol(const char* name, void* data, int a_size);


// globals for GPU


static __constant__ unsigned short MortonTable256[] =
{
  0x0000, 0x0001, 0x0004, 0x0005, 0x0010, 0x0011, 0x0014, 0x0015,
  0x0040, 0x0041, 0x0044, 0x0045, 0x0050, 0x0051, 0x0054, 0x0055,
  0x0100, 0x0101, 0x0104, 0x0105, 0x0110, 0x0111, 0x0114, 0x0115,
  0x0140, 0x0141, 0x0144, 0x0145, 0x0150, 0x0151, 0x0154, 0x0155,
  0x0400, 0x0401, 0x0404, 0x0405, 0x0410, 0x0411, 0x0414, 0x0415,
  0x0440, 0x0441, 0x0444, 0x0445, 0x0450, 0x0451, 0x0454, 0x0455,
  0x0500, 0x0501, 0x0504, 0x0505, 0x0510, 0x0511, 0x0514, 0x0515,
  0x0540, 0x0541, 0x0544, 0x0545, 0x0550, 0x0551, 0x0554, 0x0555,
  0x1000, 0x1001, 0x1004, 0x1005, 0x1010, 0x1011, 0x1014, 0x1015,
  0x1040, 0x1041, 0x1044, 0x1045, 0x1050, 0x1051, 0x1054, 0x1055,
  0x1100, 0x1101, 0x1104, 0x1105, 0x1110, 0x1111, 0x1114, 0x1115,
  0x1140, 0x1141, 0x1144, 0x1145, 0x1150, 0x1151, 0x1154, 0x1155,
  0x1400, 0x1401, 0x1404, 0x1405, 0x1410, 0x1411, 0x1414, 0x1415,
  0x1440, 0x1441, 0x1444, 0x1445, 0x1450, 0x1451, 0x1454, 0x1455,
  0x1500, 0x1501, 0x1504, 0x1505, 0x1510, 0x1511, 0x1514, 0x1515,
  0x1540, 0x1541, 0x1544, 0x1545, 0x1550, 0x1551, 0x1554, 0x1555,
  0x4000, 0x4001, 0x4004, 0x4005, 0x4010, 0x4011, 0x4014, 0x4015,
  0x4040, 0x4041, 0x4044, 0x4045, 0x4050, 0x4051, 0x4054, 0x4055,
  0x4100, 0x4101, 0x4104, 0x4105, 0x4110, 0x4111, 0x4114, 0x4115,
  0x4140, 0x4141, 0x4144, 0x4145, 0x4150, 0x4151, 0x4154, 0x4155,
  0x4400, 0x4401, 0x4404, 0x4405, 0x4410, 0x4411, 0x4414, 0x4415,
  0x4440, 0x4441, 0x4444, 0x4445, 0x4450, 0x4451, 0x4454, 0x4455,
  0x4500, 0x4501, 0x4504, 0x4505, 0x4510, 0x4511, 0x4514, 0x4515,
  0x4540, 0x4541, 0x4544, 0x4545, 0x4550, 0x4551, 0x4554, 0x4555,
  0x5000, 0x5001, 0x5004, 0x5005, 0x5010, 0x5011, 0x5014, 0x5015,
  0x5040, 0x5041, 0x5044, 0x5045, 0x5050, 0x5051, 0x5054, 0x5055,
  0x5100, 0x5101, 0x5104, 0x5105, 0x5110, 0x5111, 0x5114, 0x5115,
  0x5140, 0x5141, 0x5144, 0x5145, 0x5150, 0x5151, 0x5154, 0x5155,
  0x5400, 0x5401, 0x5404, 0x5405, 0x5410, 0x5411, 0x5414, 0x5415,
  0x5440, 0x5441, 0x5444, 0x5445, 0x5450, 0x5451, 0x5454, 0x5455,
  0x5500, 0x5501, 0x5504, 0x5505, 0x5510, 0x5511, 0x5514, 0x5515,
  0x5540, 0x5541, 0x5544, 0x5545, 0x5550, 0x5551, 0x5554, 0x5555
};


static inline int calcMegaBlockSize(int w, int h, size_t memAmount)
{
  int MEGA_BLOCK_SIZE = w*h;

  if (w*h <= 640 * 480)
  {
    MEGA_BLOCK_SIZE = w*h;

    if (memAmount < 400 * 1024 * 1024)
      MEGA_BLOCK_SIZE = w*h / 2;
  }
  else if (w*h <= 1024 * 768)
  {
    MEGA_BLOCK_SIZE = w*h / 2;
    if (memAmount < 400 * 1024 * 1024)
      MEGA_BLOCK_SIZE = w*h / 4;
  }
  else if (w*h <= 1920*1200)
  {
    MEGA_BLOCK_SIZE = w*h / 4;
    if (memAmount < 600 * 1024 * 1024)
      MEGA_BLOCK_SIZE = w*h / 8;
  }
  else
  {
    MEGA_BLOCK_SIZE = w*h / 8;
  }

  return MEGA_BLOCK_SIZE;

}


#ifdef __CUDACC__

#include <cuda.h>
#include <cuda_runtime.h>
//#include <curand.h>
//#include <curand_kernel.h>

#include "cutilStuff.h"

#include <iostream>
#include <stack>
#include <fstream>

class ITextureCache
{
public:

  ITextureCache();
  virtual ~ITextureCache();

  virtual int GetNumLines() const = 0;
  virtual void SetNumLines(int a_lines) = 0;

  virtual int GetNumBinsX() const {return 0;}
  virtual int GetNumBinsY() const {return 0;}

  virtual void BeginObtainHitMissTable(){}
  virtual void EndObtainHitMissTable(){}

protected:
  ITextureCache(const ITextureCache& rhs){}
  ITextureCache& operator=(const ITextureCache& rhs) {return *this;}

};

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>
#include <thrust/sort.h>
#include <thrust/copy.h>

struct LightMeshData
{
  thrust::device_vector<float4> positions;
  thrust::device_vector<float2> intervals;
  thrust::device_vector<float2> texcoords;
};

template<typename T> static inline T* get_pointer(thrust::device_vector<T>& rhs) { return thrust::raw_pointer_cast(&rhs[0]); }
template<typename T> static inline const T* get_pointer(const thrust::device_vector<T>& rhs) { return thrust::raw_pointer_cast(&rhs[0]); }

template<typename T> static inline T* get_pointer(thrust::host_vector<T>& rhs) { return &rhs[0]; }
template<typename T> static inline const T* get_pointer(const thrust::host_vector<T>& rhs) { return &rhs[0]; }

struct Hardware_Ray_Tracer
{
  Hardware_Ray_Tracer();
  ~Hardware_Ray_Tracer();

  void InitTexRefs();
  void BindAllTexRefs();
  void UnbindAllTexRefs();

  void SetCurrLight(const int in_lightIndex);

  int GpuMemSet(void* in_gpuBuffer,int value, int size);
  int GpuMemSetF(void* in_gpuBuffer, float value, int in_size);
  int CalcPersistentThreadsAndResetWarpCounter(int size, int regCount, int myThreadCount, bool debugOutput = false);

  int width, height;
  struct cudaGraphicsResource* m_screenBuffPixels;
  int m_initFlags;

  int numSpheres;
  int numVertices;
  int numIndices;

  RAYTR::Light* m_lights;
  RAYTR::Light* m_lightsGPU;
  int m_numLights;

  bool m_colorShadows;

  sphere4* sphere_memory;
  int*     index_memory;
  float4*  m_triangleMatrices;

  // ACCEL STRUCTURES
  char* world_kd_tree_memory;
  char* m_primListMemory;
  BVHNode* m_worldBVH;

  int m_kdTreeSize;
  int m_bvhSize;
  int m_primListSize;
  int m_triNumInObjList;

  float4* m_vertPositionsAndMatIndex; // x,y,z - positions; __float_as_int(w) - material id
  float4* m_vertNormals;
  float4* m_vertTangent;
  float2* m_vertTexCoord;
  uint*   m_vertCompressedNormals;

  thrust::device_vector<float4x4> m_texMatrices;

  struct PlainMemoryManager
  {
    PlainMemoryManager() : data(NULL), m_sizeInBytes(0) {}

    void* data;
    int   m_sizeInBytes;

    struct Buffer
    {
      Buffer(void** a_ppData, int a_size) : ppData(a_ppData), m_sizeInBytes(a_size) {}
      void** ppData;
      int m_sizeInBytes;
    };

    std::vector<Buffer> m_buffers;

    void registerBuffer(void** a_pData, int a_size) 
    {
      if(a_size % 4096 != 0) a_size = (a_size/4096 + 1)*4096; // align to 4KB 
      m_buffers.push_back(Buffer(a_pData, a_size)); 
    }

    void freeAll() { for(int i=0;i<m_buffers.size();i++) (*m_buffers[i].ppData) = NULL; cudaFree(data); data = NULL; m_buffers.clear(); }
    void allocAll()
    {
      int totalSize = 0;
      for(int i=0;i<m_buffers.size();i++) totalSize += m_buffers[i].m_sizeInBytes;
      m_sizeInBytes = totalSize;
 
      checkCudaErrors(cudaFree(data)); 
      checkCudaErrors(cudaMalloc((void**)&data, totalSize)); 

      char* currPointer = (char*)data;
      for(int i=0;i<m_buffers.size();i++)
      {
        (*m_buffers[i].ppData) = currPointer;
        currPointer += m_buffers[i].m_sizeInBytes;
      }
    }

    // using the same memory for different purposes
    //
    int m_viewOfMemTop;
    std::vector<Buffer> m_viewBuffers;

    void viewOfMemoryClear() 
    { 
      m_viewOfMemTop = 0; 
      m_viewBuffers.clear(); 
      cudaMemset(data, 0, m_sizeInBytes);
    }

    int  viewOfMemoryAvaliableMemoryAmount() { return m_sizeInBytes - m_viewOfMemTop;}

    void* viewOfMemoryAlloc(int a_size) 
    { 
      if(m_viewOfMemTop + a_size > m_sizeInBytes) 
        return NULL;

      char* currData = (char*)(data) + m_viewOfMemTop; 

      if(a_size % 4096 != 0) 
        a_size = (a_size/4096 + 1)*4096; // align to 4KB 
      
      m_viewBuffers.push_back(Buffer(NULL, a_size));
      m_viewOfMemTop += a_size;
     
      return currData;
    }

    void viewOfMemoryFreeLast()
    {
      int i = m_viewBuffers.size()-1;
      m_viewOfMemTop -= m_viewBuffers[i].m_sizeInBytes;
      m_viewBuffers.pop_back();
    }

  };

  PlainMemoryManager m_rayMem;
 
  // per ray data ?
  //
  float4*   m_pathTraceColor;
  float4*   m_pathTraceColor2;
  float4*   m_pathTraceSquareSumm;

  float4*   m_raysPos;
  float4*   m_raysDir;

  float4*   m_raysPos2;
  float4*   m_raysDir2;

  uint*     m_compactionIndices[2];
  // \\ used for rays compaction and sorting

  ushort2*  m_xy; // full screen

  //curandGenerator_t m_qrng; // for one seed QMC
  
  float* m_randsQMC;
  //curandDirectionVectors32_t* m_sobolDirections;
  //curandStateSobol32_t* m_sobolStates;
  int m_qmcTop;
  //curandGenerator_t m_qrng;

  //
  //
  uint*        m_shadowLightVector;
  Lite_Hit*	   hits;
  HitPosNorm*  m_hitPos;
  HitTexCoord* m_hitUV0;
  HitMatRef*   m_hitMaterial;
  Hit_Part4*   m_hitTangent;
  uint*        m_flatNorm;
  float*       m_frustumDepth;
  float4*      m_photonsTempColor;
  ushort4*     shadows;
  uint*        m_rayXYOffsets;

  IPhotonMap*     m_pCurrPhMap;    // for photons storing
  IPhotonMap*     m_pDiffusePhMap; // for gather diffuse photons
  IPhotonMap*     m_pCausticPhMap; // for gather caustics
  IPhotonMap*     m_pDirectPhMap;  // for effective lights sampling 
  IIrradianceMap* m_pIrradMap;

  enum {MAX_LEAFES_INTERSECT = 32};
  enum {POINT_LIGHT_SHADING_TYPE,
        SPOT_LIGHT_SHADING_TYPE,
        FLAT_LIGHT_SAMPLE_SHADING_TYPE};

  float4*  m_color;
  float4*  m_colorAux;
  uint*    m_tidCopy;

  // pack
  //
  float4*   m_shadeColor1;  // summ of direct light from point sources
  float4*   m_auxNextColor; // store path throughput
  float4*   m_irradiance;
  float4*   m_translucent;
  MisData*  m_misData;

  ushort4*  m_shadowMatte;
  ushort4*  m_transpAuxData;

  HydraMaterial* m_hydraMaterials;
  uint m_hydraMaterialsSize;

  RayFlags* m_pathFlags;

  int m_currAccelStruct;
  bool m_useInputRays;
  bool m_colectIrradiance;
  bool m_storeDepth;

  bool  m_estimateAvgPixelSize;
  float m_avgPixelSize;
  float m_avgPixelsSizeNum;

  int m_gpuNumber;
  int MEGA_BLOCK_SIZE;

  IrradianceCachePoint_Part1* m_cpu_lightCache1;
  IrradianceCachePoint_Part2* m_cpu_lightCache2;
  int m_lastCacheOffset;

  ushort4* m_fullScreenIrradiance;


  int g_flags;
  std::stack<int> m_flagsStack;

  cudaDeviceProp m_devProp;

  ushort* m_tempBuffers[16];
  float4* m_tempCachePosBuffer;
  int     m_tempCachePosBufferSize;

  enum {MEGA_TEX_MAX_NUMBER = 4};
  cudaArray* m_megaTexturesData[MEGA_TEX_MAX_NUMBER];
  void*      m_megaTexPinnedData[MEGA_TEX_MAX_NUMBER];
  float4*    m_megaTexLUTs[MEGA_TEX_MAX_NUMBER];
  int        m_megaTexDataTop;

  bool m_shadingTextureSWEnabled;
  bool m_normalmapTextureSWEnabled;
  ITextureCache* m_texCache;
  ITextureCache* m_texCacheNormalmaps;

  cudaArray* m_pEnvMap;

  inline bool RaySamplesSavingEnabled() const { return ((g_flags & HRT_STORE_RAY_SAMPLES) && (g_flags & HRT_USE_RANDOM_RAYS));}
  int m_raySampleNumber;

  std::vector<LightMeshData> m_meshLightsData;

  int m_currBounce;
  int m_warpSwizzleCounter;

  enum {MAXVARS = GMAXVARS};
  int   m_varsI[MAXVARS];
  float m_varsF[MAXVARS];

  struct InternalVars
  {
    int   m_varsI[MAXVARS];
    float m_varsF[MAXVARS];
  };

  std::stack<InternalVars> m_varsStack;

  size_t memoryFreeAtStart;

  float4x4 mProjInverse;
  float4x4 mWorldViewInverse;

  //
  //
  ushort* m_mortonTableGPU;
  int*    m_gpuVarsI;
  float*  m_gpuVarsF;

  MRaysStat m_stat;
};

typedef Hardware_Ray_Tracer HRT;

__constant__ int   g_ivars[Hardware_Ray_Tracer::MAXVARS];
__constant__ float g_fvars[Hardware_Ray_Tracer::MAXVARS];


__constant__ int  window_size[2];
__constant__ float pWorldKdTreeBox[sizeof(box3)/sizeof(float)];

__constant__ float g_sceneBoundingSphereDiameter;
__constant__ int g_currLightId = 0;

__constant__ int cm_maxThread;

__constant__ int cm_megaBlockSize;
__constant__ int cm_multiSampleBlockSize[2];

__constant__ int g_currBounce;

__constant__ int g_threadZeroOffset;

__constant__ float cm_gamma[2];
__constant__ float cm_koefGamma[2];

__constant__ float3  cm_icache_kd_tree_box[2];

// path tracing and irradiance cache constants
//
__constant__ int cm_zBlocks;


__constant__ int cm_hemisphereRaysSize[4];
__constant__ int cm_hemRaysIndex = 1;

__constant__ float3 cm_octreeCenter;
__constant__ float  cm_octreeSize;
__constant__ float  g_serchRadiusSquare;
__constant__ float  g_searchRadius;
__constant__ float  g_searchRadiusInv;

__constant__ float  g_cubemapSize;
__constant__ int    g_areaLightNum = 0;

__constant__ float3 g_regularBMin;
__constant__ float3 g_regularBMax;
__constant__ float3 g_regularBCenter;
__constant__ float  g_regularBSizeInv;

__constant__ float4x4 g_mViewProjInv;
__constant__ float4x4 g_mWorldViewInv;

__constant__ int g_warpSwizzleCounter;

static __device__ int g_warpCounter; // Work counter for persistent threads.

static __device__ int g_stencilMask[32] = {
  0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010, 0x00000020, 0x00000040, 0x00000080,
  0x00000100, 0x00000200, 0x00000400, 0x00000800, 0x00001000, 0x00002000, 0x00004000, 0x00008000,
  0x00010000, 0x00020000, 0x00040000, 0x00080000, 0x00100000, 0x00200000, 0x00400000, 0x00800000,
  0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000, 0x20000000, 0x40000000, 0x80000000
};

__constant__ int g_disablePOMbecauseOfSpeed = 0;
__constant__ int g_envmapUseSHReconstruction = 0;
__constant__ int g_debugLayerDraw = 0;
__constant__ float3 g_envMapColor;


#define PERSISTENT_THREAD_ID(tid,BLOCK_SIZE)    \
__shared__ int s_nextWarpId[(BLOCK_SIZE)/32];   \
int& nextWarpId = s_nextWarpId[threadIdx.x/32]; \
if(threadIdx.x % 32 == 0)                       \
nextWarpId = atomicAdd(&g_warpCounter, 32);     \
tid = nextWarpId + threadIdx.x % 32;            \
if(tid >= cm_maxThread) return;



IDH_CALL uint IndexZBlock2DSwizzedWithPattern(int x, int y, const ushort* a_mortonTable)
{
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint randParam = g_warpSwizzleCounter;

  uint zIndex = ZIndex(zOrderX, zOrderY, a_mortonTable);

  if(randParam % 2 == 1)
    zIndex = ZIndex(zOrderY, zOrderX, a_mortonTable);
 
  const int N = 16;

  if(randParam % N <= 2)
  {
    zIndex = zOrderY*16 + zOrderX;
  }
  else if(randParam % N == 4)
  {
    zIndex = zOrderX*16 + zOrderY;
  }
  if(randParam % N <= 8)
  {
    zIndex = zIndex/2;
    if( (zOrderY + zOrderX) % 2 == 1)
      zIndex += 128;
  }
  else
  {
   
  }

  zIndex = zIndex + randParam;
  if(zIndex >= 256)
    zIndex = zIndex - 256;

  uint wBlocks = window_size[0]/Z_ORDER_BLOCK_SIZE;
  uint blockX = x/Z_ORDER_BLOCK_SIZE;
  uint blockY = y/Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
}

IDH_CALL uint Index2DSwizzled(uint x, uint y, const ushort* a_mortonTable)
{
  if((g_flags & HRT_ENABLE_COHERENT_PT) && (g_flags & HRT_USE_RANDOM_RAYS) && !(g_flags & (HRT_IRRDAIANCE_CACHE_FIND_SECONDARY | HRT_COMPUTE_IRRADIANCE_CACHE | HRT_ENABLE_QMC_ONE_SEED)) )
    return IndexZBlock2DSwizzedWithPattern(x,y,a_mortonTable);
  else
    return IndexZBlock2D(x, y, window_size[0], a_mortonTable);

}


//////////////////////////////////////////////////////////////////////////////////
////
__host__ void SafeGpuMemSet(void* in_gpuBuffer,int value, int size, char* file, int line);
#define SAFE_GPU_MEMSET(buff,value,size) SafeGpuMemSet((buff),(value),(size),__FILE__,__LINE__)


texture<uint4 , 1, cudaReadModeElementType> sph_tex;

texture<float4, 1, cudaReadModeElementType> vert_pos_tex;
texture<float4, 1, cudaReadModeElementType> vert_tangent_tex;
texture<float2, 1, cudaReadModeElementType> vert_texCoord_tex;
texture<uint , 1, cudaReadModeElementType>  vert_indices_tex;
texture<uint, 1, cudaReadModeElementType>   vertNormCompressed_tex;

texture<float4, 1, cudaReadModeElementType> bvh_rc_tex;
texture<float4, 1, cudaReadModeElementType> rcRecords_tex;
texture<float,  1, cudaReadModeElementType> shmat_tex;


// path tracing and irradiance cache textures
//
texture<float4, 1, cudaReadModeElementType> icache1_tex;
texture<float4, 1, cudaReadModeElementType> icache2_tex;

texture<uint4, 1, cudaReadModeElementType> zblocks_tex;

texture<float4, 1, cudaReadModeElementType> pathTracingColor_tex;

texture<float4, 1, cudaReadModeElementType> hemisphereRaysDir_tex;

texture<float4, 1, cudaReadModeElementType> iCachePos_tex;
texture<float4, 1, cudaReadModeElementType> iCacheNorm_tex;
texture<float4, 1, cudaReadModeElementType> iCacheColor_tex;

texture<float4, 1, cudaReadModeElementType> iCacheCompressed1_tex;
texture<uint4,  1, cudaReadModeElementType> iCacheCompressed2_tex;

texture<float2, 1, cudaReadModeElementType> octree_tex;
texture<uint,   1, cudaReadModeElementType> icache_indices_tex;


texture<float4, 2, cudaReadModeElementType>          input4fTemp1_tex;
texture<float, 2, cudaReadModeElementType>           input1fTemp1_tex;
texture<unsigned short, 2, cudaReadModeElementType>  input1hTemp1_tex;

texture<float, 2, cudaReadModeElementType>  surfDiscMip0_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip1_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip2_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip3_tex;
texture<float, 2, cudaReadModeElementType>  surfDiscMip4_tex;

texture<uchar4, cudaTextureTypeCubemap, cudaReadModeNormalizedFloat>  envMapCube;

const int MTCBINSIZE = 16;
__device__ int g_cacheBins1[MTCBINSIZE*MTCBINSIZE];
__device__ int g_cacheBins2[MTCBINSIZE*MTCBINSIZE];
__constant__ int g_collectCacheMissInfo = 1;
__constant__ int g_oddEvenBinStorage = 0;

struct TexCacheLine
{
  enum {LINE_IS_BUSY = 1};

  float2 vmin;
  float2 vmax;
  float2 rectSize;
  int    flags;
};

template<class Data>
struct SWTexture
{
  float width;
  float height;
  const Data* data;

  float binsX;
  float binsY;
  TexCacheLine lines[4];
};

__constant__ SWTexture<uchar4> shadingTextureSW;
__constant__ SWTexture<uchar4> normalmapTextureSW;

texture<float4, 2, cudaReadModeElementType>      shadingTextureHDR;
texture<uchar4, 2, cudaReadModeNormalizedFloat>  shadingTexture;
texture<uchar4, 2, cudaReadModeNormalizedFloat>  shadingTextureCache; // for out of core textures
texture<unsigned char, 2, cudaReadModeNormalizedFloat>  opacityTexture;
texture<uchar4, 2, cudaReadModeNormalizedFloat>  normalmapTexture;

texture<float4, 1, cudaReadModeElementType> shadingTextureHDRLUT;
texture<float4, 1, cudaReadModeElementType> shadingTextureLUT;
texture<float4, 1, cudaReadModeElementType> opacityTextureLUT;
texture<float4, 1, cudaReadModeElementType> normalmapTextureLUT;

texture<float4, 1, cudaReadModeElementType> texMatricesTexture;



//__constant__ float



#endif
