#ifndef OCTREE_GUARDIAN
  #include "Octree.h"
#endif

#ifndef MGML_GUARDIAN
  #include "../CSL/MGML.h"
#endif

#include <fstream>

//using namespace MGML;

/////////////////////////////////////////////////////////////////////////////////////////////////
////

IC_Octree::IC_Octree()
{
  cubeVertPos[0] = float3(1,1,1);
  cubeVertPos[1] = float3(-1,1,1);
  cubeVertPos[2] = float3(1,-1,1);
  cubeVertPos[3] = float3(-1,-1,1);
  cubeVertPos[4] = float3(1,1,-1);
  cubeVertPos[5] = float3(-1,1,-1);
  cubeVertPos[6] = float3(1,-1,-1);
  cubeVertPos[7] = float3(-1,-1,-1);

  m_root2 = NULL;
  m_root3 = NULL;
  m_clampingFactor = 1.0f;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
IC_Octree::~IC_Octree()
{
  //delete [] m_root;
}

const OctreeNode* IC_Octree::GetRoot() { return &m_root[0]; }

int IC_Octree::GetNumNodes() { return int(m_root.size()); }

const IC_Octree::Part1* IC_Octree::GetPointsDataPart1() { return &m_recordsData1[0]; }
const IC_Octree::Part2* IC_Octree::GetPointsDataPart2() { return &m_recordsData2[0]; }
const IC_Octree::Part3* IC_Octree::GetPointsDataPart3() { return &m_recordsData3[0]; }

/////////////////////////////////////////////////////////////////////////////////////////////////
////
const int* IC_Octree::GetOctreePointIndices() const
{
  return &m_allPointsIndices[0];
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
int IC_Octree::GetOctreeIndicesNum() const
{
  return int(m_allPointsIndices.size());
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
int IC_Octree::New8Nodes()
{
  int nodesOffset = int(m_root.size());
  for(int i=0;i<8;i++)
    m_root.push_back(OctreeNode());
  return nodesOffset;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::VerifyAndOutStatistic()
{
  m_stat.avgPointsInNode = 0;
  m_stat.emptyNodesNum = 0;
  m_stat.maxDeep = 0;
  m_stat.maxPointsInNode = 0;
  m_stat.nodesNum = 0;

  //m_debugBoxesFile.open("points.txt");
  CollectStatictic(0,0,m_centerPos,m_boxSize);
  //DebudOutTreeBoxes(m_root3, m_centerPos, m_boxSize);
  //CollectStatictic(m_root3,0,m_centerPos,m_boxSize);
  //m_debugBoxesFile.close();

  m_stat.avgPointsInNode /= (float)(m_stat.nodesNum-m_stat.emptyNodesNum);
 

  float MBytes = float(m_root.size()*sizeof(OctreeNode))/(1024.0f*1024.0f);
  float MBytesTotal = (m_nodesPool.size()*sizeof(Node) + m_tempNodesPool.size()*sizeof(Node) + MBytes)/(1024.0f*1024.0f);
  float MBytesTotalWasAllocated = (m_nodesPool.capacity()*sizeof(Node) + m_tempNodesPool.capacity()*sizeof(Node) + MBytes)/(1024.0f*1024.0f);


  std::cerr << std::endl;
  std::cerr << "Octree info: " << std::endl;

  //std::cerr << "sizeof(Octree::Node)     " << sizeof(Octree::Node) << std::endl;
  //std::cerr << "sizeof(OctreeNode)       " << sizeof(OctreeNode) << std::endl;
  //std::cerr << "sizeof(PointArray)       " << sizeof(PointArray) << std::endl;
  std::cerr << "DOctree pool size total  " << m_nodesPool.capacity() << std::endl;
  std::cerr << "DOctree2 pool size total " << m_tempNodesPool.capacity() << std::endl;
  std::cerr << "SOctree pool size        " << m_root.size() << std::endl;
  std::cerr << "memory           (in MB) " << MBytes << std::endl;
  std::cerr << "memory total     (in MB) " << MBytesTotal << std::endl;
  std::cerr << "memory allocated (in MB) " << MBytesTotalWasAllocated << std::endl;
  std::cerr << "avg points in node       " << m_stat.avgPointsInNode << std::endl;
  std::cerr << "max points in node       " << m_stat.maxPointsInNode << std::endl;
  std::cerr << "nodes curr               " << m_nodesPool.size() << std::endl;
  std::cerr << "nodes max                " << m_nodesPool.capacity() << std::endl;
  std::cerr << "empty nodes              " << m_stat.emptyNodesNum << std::endl;
  std::cerr << "max deep                 " << m_stat.maxDeep << std::endl;
  std::cerr << "references num:          " << m_allPointsIndices.size() << std::endl;

}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::DebugSave()
{
  std::ofstream info("z_octree_info.txt");
  std::ofstream octree("z_octree.bin",     std::ios::out | std::ios::binary);
  std::ofstream points1("z_points_p1.bin", std::ios::out | std::ios::binary);
  std::ofstream points2("z_points_p2.bin", std::ios::out | std::ios::binary);
  std::ofstream points3("z_points_p3.bin", std::ios::out | std::ios::binary);

  info << this->m_recordsData1.size() << std::endl;
  info << this->m_root.size() << std::endl;
  info << this->m_boxSize << std::endl;
  info << this->m_centerPos << std::endl;
  //info << this->m_searchRadius << std::endl;

  octree.write((const char*)&m_root[0], m_root.size()*sizeof(OctreeNode));

  points1.write((const char*)&m_recordsData1[0], m_recordsData1.size()*sizeof(Part1));
  points2.write((const char*)&m_recordsData2[0], m_recordsData1.size()*sizeof(Part2));
  points3.write((const char*)&m_recordsData3[0], m_recordsData1.size()*sizeof(Part3));

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::DebugLoad()
{
  std::ifstream info("z_octree_info.txt");
  std::ifstream octree("z_octree.bin",     std::ios::in | std::ios::binary);
  std::ifstream points1("z_points_p1.bin", std::ios::in | std::ios::binary);
  std::ifstream points2("z_points_p2.bin", std::ios::in | std::ios::binary);
  std::ifstream points3("z_points_p3.bin", std::ios::in | std::ios::binary);

  int pointsNum;
  int treeTop;

  info >> pointsNum;
  info >> treeTop; 
  info >> this->m_boxSize;
  info >> this->m_centerPos.x >> this->m_centerPos.y >> this->m_centerPos.z;
  //info >> this->m_searchRadius;

  m_root.resize(treeTop);

  m_recordsData1.resize(pointsNum);
  m_recordsData2.resize(pointsNum);
  m_recordsData3.resize(pointsNum);

  octree.read((char*)&m_root[0], treeTop*sizeof(OctreeNode));

  points1.read((char*)&m_recordsData1[0], m_recordsData1.size()*sizeof(Part1));
  points2.read((char*)&m_recordsData2[0], m_recordsData2.size()*sizeof(Part2));
  points3.read((char*)&m_recordsData3[0], m_recordsData3.size()*sizeof(Part3));
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::DebugDrawLookUpResult(float3 pos)
{  
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_LIGHTING);

   glColor3f(0.5,0.5,0.0);

   OctreeNode* node = &m_root[0];
   float3 nodePos = m_centerPos;
   float nodeSize = m_boxSize;

   while(!node->Leaf())
   {   
     int childOffset = GetOctIndex(pos - nodePos);
     node = &m_root[node->GetOffsetToChild() + childOffset];
     nodePos += 0.25f*nodeSize*cubeVertPos[childOffset];
     nodeSize *= 0.5f;
   }

   glColor3f(0.0,0.0,0.75);

   glPushMatrix();
     glTranslatef(nodePos.x, nodePos.y, nodePos.z);
     glutWireCube(nodeSize);
   glPopMatrix();

   int start = node->GetOffsetToPoints();
   int end   = node->GetOffsetToPoints()+node->GetNumPoints();

   glColor3f(0.0,0.75,0.0);

   glBegin(GL_POINTS);
   for(int index = start; index < end; index++)
   {
     int offset = m_allPointsIndices[index];

     float3 pointPos = m_recordsData1[offset].pos;
     float radius = m_recordsData3[offset].validityRadius;
     
     glVertex3fv(pointPos.M);

     //glPushMatrix();
     //  glTranslatef(pointPos.x, pointPos.y, pointPos.z);
     //  glutWireSphere(radius, 16, 16);
     //glPopMatrix();
   }
   glEnd();

   glEnable(GL_TEXTURE_2D);
   glEnable(GL_LIGHTING);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::ConvertLayoutToLinearArray()
{
  m_root.reserve(m_nodesPool.size()+10);
  m_root.resize(0);
  m_root.push_back(OctreeNode());
  m_allPointsIndices.resize(0);
  ConvertLayoutRec(m_root2,0);
}


void IC_Octree::ConvertLayoutRec(Node* node, int a_nodeOffset)
{
  OctreeNode* currNode = &m_root[a_nodeOffset];

  if(node->Leaf())
  {
    currNode->SetOffsetToPoints(int(m_allPointsIndices.size()));
    currNode->SetNumPoints(int(node->points.size()));
    currNode->SetLeaf(true);

    for(int i=0;i<node->points.size();i++)
      m_allPointsIndices.push_back(node->points[i].GetIndex());
  }
  else
  {
    int baseOffset = New8Nodes();
    currNode->SetLeaf(false);
    currNode->SetOffsetToChild(baseOffset);

    for(int i=0;i<8;i++)
      ConvertLayoutRec(node->Childs(i), baseOffset+i);
  }
}


void IC_Octree::CollectStatictic(Node* a_node, int currDeep, float3 a_pos, float a_size)
{
  Node* node = a_node;

  m_stat.nodesNum++;
  m_stat.avgPointsInNode += node->points.size();

  if(node->points.size() > m_stat.maxPointsInNode)
    m_stat.maxPointsInNode = int(node->points.size());

  if(node->points.size() == 0)
    m_stat.emptyNodesNum++;
  else
  {

  }

  if(currDeep > m_stat.maxDeep)
    m_stat.maxDeep = currDeep;

  if(node->Childs(0)==NULL)
  {
    //AABB3f box(a_pos-a_size*float3(0.5f,0.5f,0.5f), a_pos+a_size*float3(0.5f,0.5f,0.5f));
    //m_debugBoxesFile << box.vmin << "\n";
    //m_debugBoxesFile << box.vmax << "\n";
    return;
  }

  for(int i=0;i<8;i++)
  {
    float3 nodePos = a_pos + cubeVertPos[i]*a_size/4.0f;
    CollectStatictic(node->Childs(i), currDeep+1, nodePos, a_size/2.0f);
  }

}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::CollectStatictic(int octreeNodeOffset, int currDeep, float3 a_pos, float size)
{
  OctreeNode* node = &m_root[octreeNodeOffset];

  m_stat.nodesNum++;
  m_stat.avgPointsInNode += node->GetNumPoints();

  if(node->GetNumPoints() > m_stat.maxPointsInNode)
    m_stat.maxPointsInNode = node->GetNumPoints();

  if(node->GetNumPoints() == 0)
    m_stat.emptyNodesNum++;

  if(currDeep > m_stat.maxDeep)
    m_stat.maxDeep = currDeep;

  if(node->Leaf())
  {
    //AABB3f box(a_pos-size*float3(0.5f,0.5f,0.5f), a_pos+size*float3(0.5f,0.5f,0.5f));
    //m_debugBoxesFile << box.vmin << "\n";
    //m_debugBoxesFile << box.vmax << "\n";
    return;
  }

  ASSERT(node->GetOffsetToChild() > 0);

  for(int i=0;i<8;i++)
  {
    float3 nodePos = a_pos + cubeVertPos[i]*size/4.0f;
    CollectStatictic(node->GetOffsetToChild() + i, currDeep+1, nodePos, size/2.0f);
  }

}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void IC_Octree::DebudOutTreeBoxes(Node* node, const float3& a_pos, float a_size)
{
  if(node->Leaf())
  {
    AABB3f box(a_pos-a_size*float3(0.5f,0.5f,0.5f), a_pos+a_size*float3(0.5f,0.5f,0.5f));
    //m_debugBoxesFile << box.vmin << "\n";
    //m_debugBoxesFile << box.vmax << "\n";
    return;
  }

  for(int i=0;i<8;i++)
  {
    float3 nodePos = a_pos + cubeVertPos[i]*a_size*0.25f;
    DebudOutTreeBoxes(node->Childs(i), nodePos, a_size*0.5f);
  }
}




