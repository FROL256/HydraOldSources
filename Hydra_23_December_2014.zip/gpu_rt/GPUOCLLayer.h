#include "GPUAbstractLayer.h"

#ifndef RTLIB_GUARDIAN
#include "rtlib.h"
#endif

#ifndef PATH_TRACING_GUARDIAN
#include "path_tracing.h"
#endif

#include <CL/cl.h>
#include <CL/cl_gl.h>

#include "../vsgl3/clHelper.h"

class GPUOCLLayer : public IHWLayer
{

public:

  GPUOCLLayer(int w, int h, int a_flags);
  ~GPUOCLLayer();

  void Clear(IGraphicsEngine::CLEAR_FLAGS a_flags);

  void SetGeom(InputGeom a_input);
  void SetBVH(InputGeomBVH a_input);

  void SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum); // set All PlainMaterials, including intermediate and auxilary
  void SetAllPODLights(RAYTR::Light* a_materialsAll, PlainLight* a_lights2, size_t a_number);     // unlike materials, lights always represented as POD
  void SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data);
  void SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats);
  void SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16]);

  void SetAllFlagsAndVars(const AllRenderVarialbes& a_vars);
  AllRenderVarialbes GetAllFlagsAndVars() const;

  //
  //
  unsigned int AddLightMesh(LightMeshData a_lmesh);

  //
  //
  void GetLDRImageToGL(GLuint ogl_buffer) const;
  void GetLDRImage(uint* data, int width, int height) const;
  void GetHDRImage(float4* data, int width, int height) const;

  void ResetPerfCounters();

  void BeginTracingPass();
  void EndTracingPass();
  void InitPathTracing(int seed);

  bool ImplementBlocksPT();
  void BeginBlocksPTPass(BlockList& a_list, int a_minRaysPerPixel, int a_maxRaysPerPixel);
  void EndBlocksPTPass();

  void ResizeScreen(int w, int h, int a_flags);

  void RegisterOutputGLBuffer(GLuint ogl_buffer);
  void UnregisterOutputGLBuffer();

  size_t GetAvaliableMemoryAmount(bool allMem);
  MRaysStat GetRaysStat();

protected:

  void memsetu32(cl_mem buff, uint a_val, size_t a_size);
  void memsetf4(cl_mem buff, float4 a_val, size_t a_size);

  void trace1DPrimaryOnly(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, size_t a_size);
  void trace1D(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, size_t a_size);

  void simpleBlockTrace(std::vector<ZBlock>& a_blocks);

  int m_width;
  int m_height;

  struct CL_SCREEN_BUFFERS
  {
    CL_SCREEN_BUFFERS() : ptColorSummBuff(0), ptColorSummSquareBuff(0), xyCoord(0), pbo(0), subBuffersNum(0), zblocks(0)
    {
      for (auto i = 0; i < MAX_MEGA_BLOCKS; i++)
        colorSubBuffers[i] = 0;
    }

    void free();

    cl_mem ptColorSummBuff;          // float4, full screen size
    cl_mem ptColorSummSquareBuff;    // float4, full screen size

    cl_mem xyCoord;                  // ushort2, full screen size
    cl_mem pbo;                      // uint,    full screen size

    enum { MAX_MEGA_BLOCKS = 8 };
    cl_mem colorSubBuffers[MAX_MEGA_BLOCKS];
    cl_mem xySubBuffers[MAX_MEGA_BLOCKS];
    cl_int subBuffersNum;

    cl_mem zblocks;

  } m_screen;

  struct CL_BUFFERS_RAYS
  {
    CL_BUFFERS_RAYS() : rayPos(0), rayDir(0), hits(0), rayFlags(0), hitPosNorm(0), hitTexCoord(0), hitMatId(0), hitTangent(0), hitFlatNorm(0), 
                        pathThoroughput(0), pathMisDataPrev(0), pathShadeColor(0), pathIrradColor(0), pathTempColor(0), randGenState(0), MEGABLOCKSIZE(0) {}

    void free();
    void resize(cl_context ctx, cl_command_queue cmdQueue, size_t a_size);

    cl_mem rayPos;                   // float4, MEGABLOCKSIZE size
    cl_mem rayDir;                   // float4, MEGABLOCKSIZE size 
    cl_mem hits;
    cl_mem rayFlags;

    cl_mem hitPosNorm;
    cl_mem hitTexCoord;
    cl_mem hitMatId;
    cl_mem hitTangent;
    cl_mem hitFlatNorm;

    cl_mem pathThoroughput;
    cl_mem pathMisDataPrev;
    cl_mem pathShadeColor;
    cl_mem pathIrradColor;

    cl_mem pathTempColor;
    cl_mem randGenState;

    size_t MEGABLOCKSIZE;

  } m_rays;

  struct CL_GLOBALS
  {
    CL_GLOBALS() : ctx(0), cmdQueue(0), platform(0), device(0) {}

    cl_context       ctx;        // OpenCL context
    cl_command_queue cmdQueue;   // OpenCL command que
    cl_platform_id   platform;   // OpenCL platform
    cl_device_id     device;     // OpenCL device

    cl_mem cMortonTable;
    cl_mem cVarsIF;
    cl_mem cVarsI;
    cl_mem cVarsF;

  } m_globals;


  struct CL_SCENE_DATA
  {
    CL_SCENE_DATA() : bvhBuff(0), objListBuff(0), vertNormsCompressed(0), vertTexCoord(0), vertIndices(0), materialData(0), materialOffsets(0), lightData(0) {}

    void free();

    cl_mem bvhBuff;
    cl_mem objListBuff;

    cl_mem vertNormsCompressed;
    cl_mem vertTexCoord;
    cl_mem vertIndices;

    cl_mem materialData;
    cl_mem materialOffsets;

    cl_mem lightData;

  } m_scene;


  struct PROGS
  {
    CLProgram screen;
    CLProgram trace;

  } m_progs;

  int m_flags;

  float m_mProjInverse[16];
  float m_mWorldViewInverse[16];

  Timer m_timer;
  MRaysStat m_stat;
  int m_statTimesAccount;

  void runKernelInitRandomGen(cl_mem a_buffer, size_t a_size, int a_seed);

  void runKernelRememberXY();
  void runKernelMakeEyeRaysBlocks(cl_mem a_rpos, cl_mem a_rdir, size_t a_size, cl_mem a_zblocks, int a_offset);
  void runKernelBlocksStoreColor(cl_mem a_inColor, size_t a_size, cl_mem a_zblocks, int a_offset);

  void runKernelTrace(cl_mem a_rpos, cl_mem a_rdir, size_t a_size);
  void runKernelComputeHit(cl_mem a_rpos, cl_mem a_rdir, size_t a_size);
  void runKernelNextBounce(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, size_t a_size);

  void runKernelShadowTrace(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, cl_mem a_outShadow, size_t a_size);

  std::vector<ZBlock> m_tempBlocks;

};


