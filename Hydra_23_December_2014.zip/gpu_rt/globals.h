#ifndef RTGLOBALS
#define RTGLOBALS

#define BLOCK_SIZE_X 16
#define BLOCK_SIZE_Y 16
#define WARP_SIZE 32

#define Z_ORDER_BLOCK_SIZE 16
#define CMP_RESULTS_BLOCK_SIZE 256


#define HRT_RAY_MISS 0xFFFFFFFE
#define HRT_RAY_HIT 0xFFFFFFFF

#define DELTA_RAY 1e-5f
#define MIS_PURE_SPECULAR_PDF 1e10f

#define HEMISPHERE_SEQUENCE_NUM 4
#define RC_CUBE_SIZE 4

#define GMAXVARS 32

#define INVALID_TEXTURE  0x80000000
#define HDR_TEXT_TYPE    0x40000000

#define TEX_TYPE_MASK    0xff000000
#define TEX_ID_MASK      0x007fffff

// they are related because data are storen in one int32 variable triAlphaTest
//
#define ALPHA_MATERIAL_MASK   0x00FFFFFF
#define ALPHA_LIGHTMESH_MASK  0xFF000000
#define ALPHA_LIGHTMESH_SHIFT 24

#define TEXMATRIX_ID_MASK     0x00FFFFFF // for texture slots - 'color_texMatrixId' and e.t.c
#define TEXSAMPLER_TYPE_MASK  0xFF000000 // for texture slots - 'color_texMatrixId' and e.t.c

#define INFINITY (1e38f)

#define M_PI          3.14159265358979323846f
#define INV_PI        0.31830988618379067154f
#define INV_TWOPI     0.15915494309189533577f
#define INV_FOURPI    0.07957747154594766788f

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef __CUDACC__ 

  #include "float4.cuh"              // CUDA

  #define ushort unsigned short
  #define uint   unsigned int

  #define __global
  #define __constant const
  #define __private

  #define __kernel __global__
 
  #define GLOBAL_ID_X blockDim.x * blockIdx.x + threadIdx.x
  #define GLOBAL_ID_Y blockDim.y * blockIdx.y + threadIdx.y

  #define LOCAL_ID_X threadIdx.x
  #define LOCAL_ID_Y threadIdx.y

  #define SYNCTHREADS __syncthreads()

  #define ID_CALL inline __device__

  typedef int image1d_t;
  typedef int image2d_t;

  #define __read_only const

  #define _PACKED


#else
  
  #ifdef OCL_COMPILER                // OpenCL
   
   #define __device__
   #define IDH_CALL inline
   #define ID_CALL  inline

   inline ushort2 make_ushort2(ushort x, ushort y) { ushort2 res; res.x = x; res.y = y; return res; }

   #define GLOBAL_ID_X get_global_id(0)
   #define GLOBAL_ID_Y get_global_id(1)

   #define LOCAL_ID_X  get_local_id(0)
   #define LOCAL_ID_Y  get_local_id(1)

   #define _PACKED __attribute__ ((packed))

   #define SYNCTHREADS barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE)

   IDH_CALL float maxcomp(float3 v) { return fmax(v.x, fmax(v.y, v.z)); }

  #else                              // Common C++
    
    #ifndef MGML_GPU_GUARDIAN
      #include "../CSL/MGML_GPU.h"
    #endif

    using RAYTR::float2;
    using RAYTR::float3;
    using RAYTR::float4;

    using RAYTR::uint2;
    using RAYTR::uint4;

    #define IDH_CALL static inline
    #define ID_CALL  static inline

    #define __global
    #define __constant const

    #define __private


    #define COMMON_CPLUS_PLUS_CODE 1

    ID_CALL int   __float_as_int(float x) { return *( (int*)&x ); }
    ID_CALL float __int_as_float(int x) { return *( (float*)&x ); }
    //ID_CALL uint  __float_as_uint(float x) { return *((uint*)&x); }

    #define _PACKED

#endif

#endif




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct MatSampleT
{
  float3 color;
  float3 direction;
  float  pdf;
  bool   pureSpecular;
} MatSample;


enum FLAG_BITS{HRT_COMPUTE_SHADOWS                 = 1,
               HRT_DISABLE_SHADING                 = 2, // need this flag for photon trace and bidirectional path tracing
               HRT_DIFFUSE_REFLECTION              = 4,
               HRT_USE_RANDOM_RAYS                 = 8,
               HRT_SAVE_SURFACE_DATA               = 16,
               HRT_FINAL_GARTHER                   = 32,
               HRT_COMPUTE_IRRADIANCE_CACHE        = 64,
               HRT_USE_MIS                         = 128,
               HRT_IRRDAIANCE_CACHE_FIND_SECONDARY = 256,
               HRT_DUMMY_THIS_FLAG_IS_FREE         = 512,
               HRT_DISABLE_BUMP                    = 1024,
               HRT_ENV_MAP_CUBEMAP_ACTIVE          = 2048,
               HRT_ENV_MAP_SPHEREMAP_ACTIVE        = 4096,
               HRT_STORE_RAY_SAMPLES               = 8192,
               HRT_USE_HDR_ESTIMATION              = 16384,
               HRT_RC_HARMONICS                    = 32768,
               HRT_IC_ESTIMATE_SS_IRRAD            = 65536,
               HRT_DIFFUSE_PHOTON_TRACING          = 65536*2,
               HRT_CAUSTIC_PHOTON_TRACING          = 65536*4,
               HRT_STUPID_PT_MODE                  = 65536*8,
               HRT_NO_RANDOM_LIGHTS_SELECT         = 65536*16,
               HRT_MARK_SURFACES_FG                = 65536*32, // 
               HRT_LDIRECT_PHOTON_TRACING          = 65536*64, // tracing photons to form spetial photonmap to speed-up direct light sampling
               HRT_DEBUG_DRAW_LIGHT_PHOTONS        = 65536*128,
               HRT_PHOTONS_STORE_MULTIPLY_COLORS   = 65536*256,
               HRT_GARTHER_CAUSTICS                = 65536*512,
               HRT_TRANSFORM_IC_TO_PHMAP           = 65536*1024,
               HRT_ENABLE_PT_CAUSTICS              = 65536*2048,
               HRT_ENABLE_SR_OCTREE                = 65536*4096,
               HRT_ENABLE_QMC_ONE_SEED             = 65536*8192, // !!!!!!!! DONT MOVE THIS FLAG !!!! See random generator implementation
               HRT_ENABLE_COHERENT_PT              = 65536*16384,
               HRT_USE_BOTH_PHOTON_MAPS            = 65536*32768
              };

enum SURFACE_MARKERS {SURF_FRONT = 0x80000000, 
                      SURF_BACK  = 0x40000000}; // we can use other 30 bits for index or sms like that


enum VARIABLE_NAMES { // int vars
                      //
                      HRT_ENABLE_DOF               = 0,
                      HRT_DEBUG_DRAW_LAYER         = 1,
                      HRT_FIRST_BOUNCE_STORE_CACHE = 2,
                      HRT_ENABLE_MRAYS_COUNTERS    = 3,
                      HRT_DEBUG_OUTPUT             = 4,
                      HRT_MEASURE_RAYS_TYPE        = 5,
                      HRT_DEBUG_SH_ENVIRONMENT     = 6,
                      HRT_IC_HARMONIC_MEAN         = 7,
                      HRT_TEXCACHE_MAX_MEMORY      = 8,
                      HRT_TRACE_DEPTH              = 9,
                      HRT_PHOTONS_STORE_BOUNCE     = 10,
                      HRT_PHOTONS_GARTHER_BOUNCE   = 11,
                      HRT_RAYS_APPENDBUFFER_SIZE   = 12,
                      HRT_DIFFUSE_TRACE_DEPTH      = 13,
                      HRT_DISPLAY_IC_INTERMEDIATE  = 14,
                      HRT_PT_FILTER_TYPE           = 15,
                      HRT_RAY_REORDER_TYPE         = 16,
                      HRT_RAY_REORDER_PATTERN      = 17,
                      HRT_VAR_ENABLE_RR            = 18,
                      HRT_RENDER_LAYER             = 19,
                      HRT_RENDER_LAYER_DEPTH       = 20,
                      HRT_IC_ENABLED               = 21,
                      HRT_IMAP_ENABLED             = 22,
                      HRT_SPHEREMAP_TEXID0         = 23,
                      HRT_SPHEREMAP_TEXID1         = 24,
                      HRT_USE_GAMMA_FOR_ENV        = 25,
                      HRT_IC_BOUNCE                = 26,
                      HRT_SPHEREMAP_TEXMATRIXID0   = 27,
                      HRT_SPHEREMAP_TEXMATRIXID1   = 28,
};

enum VARIABLE_FLOAT_NAMES{ // float vars
                           //
                           HRT_DOF_LENS_RADIUS                     = 0,
                           HRT_DOF_FOCAL_PLANE_DIST                = 1,
                           HRT_IC_WS_ERROR_TRESHOLD                = 2,
                           HRT_TRACE_PROCEEDINGS_TRESHOLD          = 3, 
                           HRT_DUMMY_TEMP_IS_FREE                  = 4,
                           HRT_CAUSTIC_POWER_MULT                  = 5,
                           HRT_IMAGE_GAMMA                         = 6,
                           HRT_TEXINPUT_GAMMA                      = 7,
                           HRT_ENV_COLOR_X                         = 8,
                           HRT_ENV_COLOR_Y                         = 9,
                           HRT_ENV_COLOR_Z                         = 10,
                           HRT_ENV_COLOR2_X                        = 11,
                           HRT_ENV_COLOR2_Y                        = 12,
                           HRT_ENV_COLOR2_Z                        = 13,
                           HRT_CAM_FOV                             = 14,
                           HRT_PATH_TRACE_ERROR                    = 15,     
};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

IDH_CALL uint ZIndex(ushort x, ushort y, __constant ushort* a_mortonTable256)
{
  return	(a_mortonTable256[y >> 8]   << 17) |
          (a_mortonTable256[x >> 8]   << 16) |
          (a_mortonTable256[y & 0xFF] << 1 ) |
          (a_mortonTable256[x & 0xFF]      );
}

IDH_CALL ushort ExtractXFromZIndex(uint zIndex)
{
  uint result = 0;
  for (int i = 0; i<16; i++)
    result |= ((1 << 2 * i) & zIndex) >> i;
  return (ushort)result;
}


IDH_CALL ushort ExtractYFromZIndex(uint zIndex)
{
  uint result = 0;
  for (int i = 0; i<16; i++)
    result |= ((1 << (2 * i + 1)) & zIndex) >> i;
  return (ushort)(result >> 1);
}

IDH_CALL int blocks(int elems, int threadsPerBlock)
{
  if (elems % threadsPerBlock == 0 && elems >= threadsPerBlock)
    return elems / threadsPerBlock;
  else
    return (elems / threadsPerBlock) + 1;
}

IDH_CALL uint Index2D(uint x, uint y, int pitch) { return y*pitch + x; }

IDH_CALL uint IndexZBlock2D(int x, int y, int pitch, __constant ushort* a_mortonTable) // window_size[0]
{
  uint zOrderX = x % Z_ORDER_BLOCK_SIZE;
  uint zOrderY = y % Z_ORDER_BLOCK_SIZE;

  uint zIndex = ZIndex(zOrderX, zOrderY, a_mortonTable);

  uint wBlocks = pitch / Z_ORDER_BLOCK_SIZE;
  uint blockX = x / Z_ORDER_BLOCK_SIZE;
  uint blockY = y / Z_ORDER_BLOCK_SIZE;

  return (blockX + (blockY)*(wBlocks))*Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE + zIndex;
}


//#ifndef OCL_COMPILER

IDH_CALL float3 to_float3(float4 f4)
{
  float3 res;
  res.x = f4.x;
  res.y = f4.y;
  res.z = f4.z;
  return res;
}

IDH_CALL float4 to_float4(float3 v, float w) 
{
  float4 res;
  res.x = v.x;
  res.y = v.y;
  res.z = v.z;
  res.w = w;
  return res;
}

//#endif



#ifndef __CUDACC__

IDH_CALL float2 make_float2(float a, float b)
{
  float2 res;
  res.x = a;
  res.y = b;
  return res;
}

IDH_CALL float3 make_float3(float a, float b, float c) 
{ 
  float3 res;
  res.x = a;
  res.y = b;
  res.z = c;
  return res;
}

IDH_CALL float4 make_float4(float a, float b, float c, float d) 
{ 
  float4 res;
  res.x = a;
  res.y = b;
  res.z = c;
  res.w = d;
  return res;
}

#endif

IDH_CALL float3 reflect(float3 dir, float3 normal) { return normalize((normal * dot(dir, normal) * (-2.0f)) + dir); }


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///// a simple tone mapping
IDH_CALL float3 ToneMapping(float3 color)  { return make_float3(fmin(color.x, 1.0f), fmin(color.y, 1.0f), fmin(color.z, 1.0f)); }
IDH_CALL float4 ToneMapping4(float4 color) { return make_float4(fmin(color.x, 1.0f), fmin(color.y, 1.0f), fmin(color.z, 1.0f), fmin(color.w, 1.0f)); }

/////////////////////////////////////////////////////////////////////////////////////////////////////////
////
IDH_CALL uint RealColorToUint32_f3(float3 real_color)
{
  float  r = real_color.x*255.0f;
  float  g = real_color.y*255.0f;
  float  b = real_color.z*255.0f;
  unsigned char red = (unsigned char)r, green = (unsigned char)g, blue = (unsigned char)b;
  return red | (green << 8) | (blue << 16) | 0xFF000000;
}


IDH_CALL uint RealColorToUint32(float4 real_color)
{
  float  r = real_color.x*255.0f;
  float  g = real_color.y*255.0f;
  float  b = real_color.z*255.0f;
  float  a = real_color.w*255.0f;

  unsigned char red   = (unsigned char)r;
  unsigned char green = (unsigned char)g;
  unsigned char blue  = (unsigned char)b;
  unsigned char alpha = (unsigned char)a;

  return red | (green << 8) | (blue << 16) | (alpha << 24);
}

IDH_CALL float3 SafeInverse(float3 d)
{
  float ooeps = exp2(-80.0f); // Avoid div by zero.

  float3 res;
  res.x = 1.0f / (fabs(d.x) > ooeps ? d.x : copysign(ooeps, d.x));
  res.y = 1.0f / (fabs(d.x) > ooeps ? d.y : copysign(ooeps, d.y));
  res.z = 1.0f / (fabs(d.x) > ooeps ? d.z : copysign(ooeps, d.z));
  return res;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct float4x3
{
  float4 row[3];
};

struct float4x4
{
  float4 row[4];
};

struct float3x3
{
  float3 row[3];
};



IDH_CALL float3 mul4x3x3(struct float4x3 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
  return res;
}

IDH_CALL float4 mul4x4x4(struct float4x4 m, float4 v)
{
  float4 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w*v.w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w*v.w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w*v.w;
  res.w = m.row[3].x*v.x + m.row[3].y*v.y + m.row[3].z*v.z + m.row[3].w*v.w;
  return res;
}

IDH_CALL float3 mul(struct float4x4 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
  return res;
}

IDH_CALL float3 mul3x4(struct float4x3 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z + m.row[0].w;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z + m.row[1].w;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z + m.row[2].w;
  return res;
}

IDH_CALL float3 mul3x3(struct float4x3 m, float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
  return res;
}

IDH_CALL struct float3x3 make_float3x3(float3 a, float3 b, float3 c)
{
  struct float3x3 m;
  m.row[0] = a;
  m.row[1] = b;
  m.row[2] = c;
  return m;
}

IDH_CALL struct float3x3 make_float3x3_by_columns(float3 a, float3 b, float3 c)
{
  struct float3x3 m;
  m.row[0].x = a.x;
  m.row[1].x = a.y;
  m.row[2].x = a.z;

  m.row[0].y = b.x;
  m.row[1].y = b.y;
  m.row[2].y = b.z;

  m.row[0].z = c.x;
  m.row[1].z = c.y;
  m.row[2].z = c.z;
  return m;
}

IDH_CALL float3 mul3x3x3(struct float3x3 m, const float3 v)
{
  float3 res;
  res.x = m.row[0].x*v.x + m.row[0].y*v.y + m.row[0].z*v.z;
  res.y = m.row[1].x*v.x + m.row[1].y*v.y + m.row[1].z*v.z;
  res.z = m.row[2].x*v.x + m.row[2].y*v.y + m.row[2].z*v.z;
  return res;
}

IDH_CALL struct float3x3 mul3x3x3x3(struct float3x3 m1, struct float3x3 m2)
{
  float3 column1 = mul3x3x3(m1, make_float3(m2.row[0].x, m2.row[1].x, m2.row[2].x));
  float3 column2 = mul3x3x3(m1, make_float3(m2.row[0].y, m2.row[1].y, m2.row[2].y));
  float3 column3 = mul3x3x3(m1, make_float3(m2.row[0].z, m2.row[1].z, m2.row[2].z));

  return make_float3x3_by_columns(column1, column2, column3);
}

IDH_CALL struct float3x3 inverse(struct float3x3 a)
{
  float det = a.row[0].x * (a.row[1].y * a.row[2].z - a.row[1].z * a.row[2].y) -
              a.row[0].y * (a.row[1].x * a.row[2].z - a.row[1].z * a.row[2].x) +
              a.row[0].z * (a.row[1].x * a.row[2].y - a.row[1].y * a.row[2].x);

  struct float3x3 b;
  b.row[0].x = (a.row[1].y * a.row[2].z - a.row[1].z * a.row[2].y);
  b.row[0].y = -(a.row[0].y * a.row[2].z - a.row[0].z * a.row[2].y);
  b.row[0].z = (a.row[0].y * a.row[1].z - a.row[0].z * a.row[1].y);
  b.row[1].x = -(a.row[1].x * a.row[2].z - a.row[1].z * a.row[2].x);
  b.row[1].y = (a.row[0].x * a.row[2].z - a.row[0].z * a.row[2].x);
  b.row[1].z = -(a.row[0].x * a.row[1].z - a.row[0].z * a.row[1].x);
  b.row[2].x = (a.row[1].x * a.row[2].y - a.row[1].y * a.row[2].x);
  b.row[2].y = -(a.row[0].x * a.row[2].y - a.row[0].y * a.row[2].x);
  b.row[2].z = (a.row[0].x * a.row[1].y - a.row[0].y * a.row[1].x);

  float s = 1.0f / det;
  b.row[0] *= s;
  b.row[1] *= s;
  b.row[2] *= s;

  return b;
}


IDH_CALL struct float4x4 inverse4x4(struct float4x4 m1)
{
  float tmp[12]; // temp array for pairs
  struct float4x4 m;

  // calculate pairs for first 8 elements (cofactors)
  //
  tmp[0] = m1.row[2].z * m1.row[3].w;
  tmp[1] = m1.row[2].w * m1.row[3].z;
  tmp[2] = m1.row[2].y * m1.row[3].w;
  tmp[3] = m1.row[2].w * m1.row[3].y;
  tmp[4] = m1.row[2].y * m1.row[3].z;
  tmp[5] = m1.row[2].z * m1.row[3].y;
  tmp[6] = m1.row[2].x * m1.row[3].w;
  tmp[7] = m1.row[2].w * m1.row[3].x;
  tmp[8] = m1.row[2].x * m1.row[3].z;
  tmp[9] = m1.row[2].z * m1.row[3].x;
  tmp[10] = m1.row[2].x * m1.row[3].y;
  tmp[11] = m1.row[2].y * m1.row[3].x;

  // calculate first 8 m1.rowents (cofactors)
  //
  m.row[0].x = tmp[0] * m1.row[1].y + tmp[3] * m1.row[1].z + tmp[4] * m1.row[1].w;
  m.row[0].x -= tmp[1] * m1.row[1].y + tmp[2] * m1.row[1].z + tmp[5] * m1.row[1].w;
  m.row[1].x = tmp[1] * m1.row[1].x + tmp[6] * m1.row[1].z + tmp[9] * m1.row[1].w;
  m.row[1].x -= tmp[0] * m1.row[1].x + tmp[7] * m1.row[1].z + tmp[8] * m1.row[1].w;
  m.row[2].x = tmp[2] * m1.row[1].x + tmp[7] * m1.row[1].y + tmp[10] * m1.row[1].w;
  m.row[2].x -= tmp[3] * m1.row[1].x + tmp[6] * m1.row[1].y + tmp[11] * m1.row[1].w;
  m.row[3].x = tmp[5] * m1.row[1].x + tmp[8] * m1.row[1].y + tmp[11] * m1.row[1].z;
  m.row[3].x -= tmp[4] * m1.row[1].x + tmp[9] * m1.row[1].y + tmp[10] * m1.row[1].z;
  m.row[0].y = tmp[1] * m1.row[0].y + tmp[2] * m1.row[0].z + tmp[5] * m1.row[0].w;
  m.row[0].y -= tmp[0] * m1.row[0].y + tmp[3] * m1.row[0].z + tmp[4] * m1.row[0].w;
  m.row[1].y = tmp[0] * m1.row[0].x + tmp[7] * m1.row[0].z + tmp[8] * m1.row[0].w;
  m.row[1].y -= tmp[1] * m1.row[0].x + tmp[6] * m1.row[0].z + tmp[9] * m1.row[0].w;
  m.row[2].y = tmp[3] * m1.row[0].x + tmp[6] * m1.row[0].y + tmp[11] * m1.row[0].w;
  m.row[2].y -= tmp[2] * m1.row[0].x + tmp[7] * m1.row[0].y + tmp[10] * m1.row[0].w;
  m.row[3].y = tmp[4] * m1.row[0].x + tmp[9] * m1.row[0].y + tmp[10] * m1.row[0].z;
  m.row[3].y -= tmp[5] * m1.row[0].x + tmp[8] * m1.row[0].y + tmp[11] * m1.row[0].z;

  // calculate pairs for second 8 m1.rowents (cofactors)
  //
  tmp[0] = m1.row[0].z * m1.row[1].w;
  tmp[1] = m1.row[0].w * m1.row[1].z;
  tmp[2] = m1.row[0].y * m1.row[1].w;
  tmp[3] = m1.row[0].w * m1.row[1].y;
  tmp[4] = m1.row[0].y * m1.row[1].z;
  tmp[5] = m1.row[0].z * m1.row[1].y;
  tmp[6] = m1.row[0].x * m1.row[1].w;
  tmp[7] = m1.row[0].w * m1.row[1].x;
  tmp[8] = m1.row[0].x * m1.row[1].z;
  tmp[9] = m1.row[0].z * m1.row[1].x;
  tmp[10] = m1.row[0].x * m1.row[1].y;
  tmp[11] = m1.row[0].y * m1.row[1].x;

  // calculate second 8 m1 (cofactors)
  //
  m.row[0].z = tmp[0] * m1.row[3].y + tmp[3] * m1.row[3].z + tmp[4] * m1.row[3].w;
  m.row[0].z -= tmp[1] * m1.row[3].y + tmp[2] * m1.row[3].z + tmp[5] * m1.row[3].w;
  m.row[1].z = tmp[1] * m1.row[3].x + tmp[6] * m1.row[3].z + tmp[9] * m1.row[3].w;
  m.row[1].z -= tmp[0] * m1.row[3].x + tmp[7] * m1.row[3].z + tmp[8] * m1.row[3].w;
  m.row[2].z = tmp[2] * m1.row[3].x + tmp[7] * m1.row[3].y + tmp[10] * m1.row[3].w;
  m.row[2].z -= tmp[3] * m1.row[3].x + tmp[6] * m1.row[3].y + tmp[11] * m1.row[3].w;
  m.row[3].z = tmp[5] * m1.row[3].x + tmp[8] * m1.row[3].y + tmp[11] * m1.row[3].z;
  m.row[3].z -= tmp[4] * m1.row[3].x + tmp[9] * m1.row[3].y + tmp[10] * m1.row[3].z;
  m.row[0].w = tmp[2] * m1.row[2].z + tmp[5] * m1.row[2].w + tmp[1] * m1.row[2].y;
  m.row[0].w -= tmp[4] * m1.row[2].w + tmp[0] * m1.row[2].y + tmp[3] * m1.row[2].z;
  m.row[1].w = tmp[8] * m1.row[2].w + tmp[0] * m1.row[2].x + tmp[7] * m1.row[2].z;
  m.row[1].w -= tmp[6] * m1.row[2].z + tmp[9] * m1.row[2].w + tmp[1] * m1.row[2].x;
  m.row[2].w = tmp[6] * m1.row[2].y + tmp[11] * m1.row[2].w + tmp[3] * m1.row[2].x;
  m.row[2].w -= tmp[10] * m1.row[2].w + tmp[2] * m1.row[2].x + tmp[7] * m1.row[2].y;
  m.row[3].w = tmp[10] * m1.row[2].z + tmp[4] * m1.row[2].x + tmp[9] * m1.row[2].y;
  m.row[3].w -= tmp[8] * m1.row[2].y + tmp[11] * m1.row[2].z + tmp[5] * m1.row[2].x;

  // calculate matrix inverse
  //
  float k = 1.0f / (m1.row[0].x * m.row[0].x + m1.row[0].y * m.row[1].x + m1.row[0].z * m.row[2].x + m1.row[0].w * m.row[3].x);

  for (int i = 0; i<4; i++)
  {
    m.row[i].x *= k;
    m.row[i].y *= k;
    m.row[i].z *= k;
    m.row[i].w *= k;
  }

  return m;
}

// Look At matrix creation
// return the inverse view matrix
//

IDH_CALL struct float4x4 lookAt(float3 eye, float3 center, float3 up)
{
  float3 x, y, z; // basis; will make a rotation matrix

  z.x = eye.x - center.x;
  z.y = eye.y - center.y;
  z.z = eye.z - center.z;
  z = normalize(z);

  y.x = up.x;
  y.y = up.y;
  y.z = up.z;

  x = cross(y, z); // X vector = Y cross Z
  y = cross(z, x); // Recompute Y = Z cross X

  // cross product gives area of parallelogram, which is < 1.0 for
  // non-perpendicular unit-length vectors; so normalize x, y here
  x = normalize(x);
  y = normalize(y);

  struct float4x4 M;
  M.row[0].x = x.x; M.row[1].x = x.y; M.row[2].x = x.z; M.row[3].x = -x.x * eye.x - x.y * eye.y - x.z*eye.z;
  M.row[0].y = y.x; M.row[1].y = y.y; M.row[2].y = y.z; M.row[3].y = -y.x * eye.x - y.y * eye.y - y.z*eye.z;
  M.row[0].z = z.x; M.row[1].z = z.y; M.row[2].z = z.z; M.row[3].z = -z.x * eye.x - z.y * eye.y - z.z*eye.z;
  M.row[0].w = 0.0; M.row[1].w = 0.0; M.row[2].w = 0.0; M.row[3].w = 1.0;
  return M;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

IDH_CALL float3 EyeRayDir(float x, float y, float w, float h, struct float4x4 a_mViewProjInv) // g_mViewProjInv
{
  float4 pos = make_float4( 2.0f * (x + 0.5f) / w - 1.0f, 
                           -2.0f * (y + 0.5f) / h + 1.0f, 
                            0.0f, 
                            1.0f );

  pos = mul4x4x4(a_mViewProjInv, pos);
  pos /= pos.w;

  pos.y *= (-1.0f);

  return normalize(to_float3(pos));
}


IDH_CALL void matrix4x4f_mult_ray3(struct float4x4 a_mWorldViewInv, __private float3* ray_pos, __private float3* ray_dir) // g_mWorldViewInv
{
  float3 pos  = mul(a_mWorldViewInv, (*ray_pos));
  float3 pos2 = mul(a_mWorldViewInv, ((*ray_pos) + 100.0f*(*ray_dir)));

  float3 diff = pos2 - pos;

  (*ray_pos)  = pos;
  (*ray_dir)  = normalize(diff);
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ��������� ����� �����:
// ������ 16 ���� - ���� ���������� ObjectList
// ������� ���� ������������, ����� �����. ������ ����������� ��������� �� float4 (��� uint4)
//

struct ObjectListTriangle
{
  float4 v1;
  float4 v2;
  float4 v3;
};

struct ObjectListSphere
{
  float3 pos;
  float r;
};

enum HIT_PRIMITIVE_TYPES { HIT_TRIANGLE = 0, HIT_SPHERE = 1, HIT_BOX = 2, HIT_NONE = 3 };

struct ObjectList
{

#ifndef OCL_COMPILER
#ifndef __CUDACC__

  ObjectList() { m_triangleCount = m_offset = dummy1 = dummy2 = 0; }

  inline ObjectListTriangle* GetTriangles() const { return  (ObjectListTriangle*)(((char*)this) + sizeof(ObjectList)); }
  inline const ObjectListSphere* GetSpheres() const { return  (const ObjectListSphere*)((char*)this + sizeof(ObjectList) + m_triangleCount*sizeof(ObjectListTriangle)); }

#endif
#endif

  int m_offset;
  int m_triangleCount;
  int dummy1;
  int dummy2;
};

IDH_CALL int GetNumTriangles(struct ObjectList ol)  { return ol.m_triangleCount; }
IDH_CALL int GetOffset(struct ObjectList ol)        { return ol.m_offset; }
IDH_CALL int GetNumPrimitives(struct ObjectList ol) { return GetNumTriangles(ol); }


struct Lite_HitT
{
  float t;
  unsigned int  object_id; // we can use 2 bits of object_id to store object_type
};

typedef struct Lite_HitT Lite_Hit;


IDH_CALL unsigned int GetObjectId(Lite_Hit lh)    { return (lh.object_id & 0x3FFFFFFF); }
IDH_CALL unsigned int GetObjectType(Lite_Hit lh)  { return (lh.object_id & 0xC0000000) >> 30; }

IDH_CALL unsigned int MakeObjectId(unsigned int a_id, unsigned int a_objType)   { return (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000); }

IDH_CALL Lite_Hit Make_Lite_Hit(float t, unsigned int a_id, unsigned int a_objType)
{
  Lite_Hit hit;
  hit.t = t;
  hit.object_id = (a_id & 0x3FFFFFFF) | ((a_objType << 30) & 0xC0000000);
  return hit;
}


IDH_CALL int IS_LEAF(int a_leftOffsetAndLeaf) { return a_leftOffsetAndLeaf & 0x80000000; }
IDH_CALL int EXTRACT_OFFSET(int a_leftOffsetAndLeaf) { return a_leftOffsetAndLeaf & 0x7fffffff; }
IDH_CALL int PACK_LEAF_AND_OFFSET(int a_leftOffset, int leaf) { return (a_leftOffset & 0x7fffffff) | (leaf & 0x80000000); }


// a know about bit fields, but in CUDA they didn't work
//
struct BVHNodeT
{

#ifndef __CUDACC__
#ifndef OCL_COMPILER

  BVHNodeT() { m_leftOffsetAndLeaf = 0xffffffff; }

  inline void SetLeaf(unsigned int a_Leaf) { m_leftOffsetAndLeaf = (m_leftOffsetAndLeaf & 0x7fffffff) | ((a_Leaf) << 31); }
  inline unsigned int Leaf() const  { return (m_leftOffsetAndLeaf & 0x80000000) >> 31; }
  inline void SetLeftOffset(unsigned int in_offset) { m_leftOffsetAndLeaf = (m_leftOffsetAndLeaf & 0x80000000) | (in_offset & 0x7fffffff); }

  inline void SetObjectListOffset(unsigned int in_offset)
  {
    if (Leaf())
      SetLeftOffset(in_offset);
  }

  inline unsigned int GetLeftOffset()       const { return m_leftOffsetAndLeaf & 0x7fffffff; }
  inline unsigned int GetRightOffset()      const { return GetLeftOffset() + 1; }
  inline unsigned int GetObjectListOffset() const { return GetLeftOffset(); }

#endif
#endif

  float3 m_boxMin;
  unsigned int m_leftOffsetAndLeaf;

  float3 m_boxMax;
  unsigned int m_escapeIndex;

};

typedef struct BVHNodeT BVHNode;


struct _PACKED RayFlagsT
{
  unsigned char  diffuseBounceNum;
  unsigned char  bounceNum;
  unsigned short otherFlags;
};

typedef struct RayFlagsT RayFlags;

enum {
  RAY_GRAMMAR_SPECULAR             = 1,
  RAY_GRAMMAR_DIFFUSE_REFLECTION   = 2,
  RAY_GRAMMAR_REFLECTION           = 4,
  RAY_GRAMMAR_REFRACTION           = 8,
  RAY_GRAMMAR_CAUSTIC              = 16,
  RAY_GRAMMAR_OUT_OF_SCENE         = 32,
  RAY_GRAMMAR_PHOTON_STORED        = 64,
  RAY_IS_INSIDE_TRANSPARENT_OBJECT = 128,
  RAY_WAS_SAMPLE_SKY_PORTAL        = 256,
  RAY_GRAMMAR_MAY_CAUSE_CAUSTIC    = 512,
  RAY_GRAMMAR_FORCE_CAUSTIC_PHOTON = 1024,
  RAY_HIT_SURFACE_FROM_OTHER_SIDE  = 2048,
  RAY_IS_DEAD                      = 4096, // set when ray had account environment or dien on the surface
};

IDH_CALL uint unpackRayFlags(uint a_flags)                       { return ((a_flags & 0xFFFF0000) >> 16); } // ## must be checked
IDH_CALL uint packRayFlags(uint a_oldData, uint a_flags)         { return (a_oldData & 0x0000FFFF) | (a_flags << 16); } // ## must be checked

IDH_CALL uint unpackBounceNum(uint a_flags)     { return ((a_flags & 0x0000FF00) >> 8); }          // ## must be cheched
IDH_CALL uint unpackBounceNumDiff(uint a_flags) { return (a_flags & 0x000000FF); }                 // ## must be cheched

IDH_CALL bool rayIsActiveS(RayFlags a_flags) { return (a_flags.otherFlags & (RAY_GRAMMAR_OUT_OF_SCENE | RAY_IS_DEAD)) == 0; }
IDH_CALL bool rayIsActiveU(uint     a_flags) { return ( ((a_flags & 0xFFFF0000) >> 16) & (RAY_GRAMMAR_OUT_OF_SCENE | RAY_IS_DEAD)) == 0; }

typedef struct MisDataT
{
  float matSamplePdf;
  float lightPickProb;
} MisData;



IDH_CALL uint encodeNormal(float3 n)
{
  short x = (short)(n.x*32767.0f);
  short y = (short)(n.y*32767.0f);

  ushort sign = (n.z >= 0) ? 0 : 1;

  int sx = ((int)(x & 0xfffe) | sign);
  int sy = ((int)(y & 0xfffe) << 16);

  return (sx | sy);
}

IDH_CALL float3 decodeNormal(uint a_data)
{
  const float divInv = 1.0f / 32767.0f;

  short a_enc_x, a_enc_y;

  a_enc_x = (short)(a_data & 0x0000FFFF);
  a_enc_y = (short)((int)(a_data & 0xFFFF0000) >> 16);

  float sign = (a_enc_x & 0x0001) ? -1.0f : 1.0f;

  float x = (short)(a_enc_x & 0xfffe)*divInv;
  float y = (short)(a_enc_y & 0xfffe)*divInv;
  float z = sign*sqrt(fmax(1.0f - x*x - y*y, 0.0f));

  return make_float3(x, y, z);
}

struct _PACKED HitPosNormT
{
  float  pos_x;
  float  pos_y;
  float  pos_z;
  uint   norm_xy;

#ifdef __CUDACC__

  __device__ float3 GetNormal() const { return decodeNormal(norm_xy); }
  __device__ void SetNormal(float3 a_norm) { norm_xy = encodeNormal(normalize(a_norm)); }

#endif

};

typedef struct HitPosNormT HitPosNorm;

ID_CALL HitPosNorm make_HitPosNorm(float4 a_data)
{
  HitPosNorm res;
  res.pos_x   = a_data.x;
  res.pos_y   = a_data.y;
  res.pos_z   = a_data.z;
  res.norm_xy = (uint)(__float_as_int(a_data.w));
  return res;
}

IDH_CALL float3 GetPos(HitPosNorm a_data) { return make_float3(a_data.pos_x, a_data.pos_y, a_data.pos_z); }
IDH_CALL void   SetPos(__private HitPosNorm* a_pData, float3 a_pos) { a_pData->pos_x = a_pos.x; a_pData->pos_y = a_pos.y; a_pData->pos_z = a_pos.z; }

struct _PACKED HitTexCoordT
{
  float  tex_u;
  float  tex_v;
};

typedef struct HitTexCoordT HitTexCoord;


struct _PACKED HitMatRefT
{
  int m_data;
};

typedef struct HitMatRefT HitMatRef;

IDH_CALL int GetHitType(HitMatRef a_hitMat)    { return (a_hitMat.m_data & 0xF0000000) >> 28; }
IDH_CALL int GetMaterialId(HitMatRef a_hitMat) { return a_hitMat.m_data & 0x0FFFFFFF; }

IDH_CALL void SetHitType(__private HitMatRef* a_pHitMat, int a_id)
{
  int mask = a_id << 28;
  int m_data2 = a_pHitMat->m_data & 0x0FFFFFFF;
  a_pHitMat->m_data = m_data2 | mask;
}


IDH_CALL void SetMaterialId(__private HitMatRef* a_pHitMat, int a_mat_id)
{
  int mask = a_mat_id & 0x0FFFFFFF;
  int m_data2 = a_pHitMat->m_data & 0xF0000000;
  a_pHitMat->m_data = m_data2 | mask;
}


struct _PACKED Hit_Part4T
{
  uint tangentCompressed;
  uint bitangentCompressed;
};

typedef struct Hit_Part4T Hit_Part4;









IDH_CALL void CoordinateSystem(float3 v1, __private float3* v2, __private float3* v3)
{
  float invLen = 1.0f;

  if (fabs(v1.x) > fabs(v1.y))
  {
    invLen = 1.0f / sqrt(v1.x*v1.x + v1.z*v1.z);
    (*v2) = make_float3(-v1.z * invLen, 0.0f, v1.x * invLen);
  }
  else
  {
    invLen = 1.0f / sqrt(v1.y*v1.y + v1.z*v1.z);
    (*v2) = make_float3(0.0f, v1.z * invLen, -v1.y * invLen);
  }

  (*v3) = cross(v1, (*v2));
}


IDH_CALL float3 MapSampleToCosineDistribution(float r1, float r2, float3 direction, float3 hit_norm, float power)
{
  if(power >= 1e6f)
    return direction;

  float sin_phi = sin(2.0f*r1*3.141592654f);
  float cos_phi = cos(2.0f*r1*3.141592654f);

  //sincos(2.0f*r1*3.141592654f, &sin_phi, &cos_phi);

  float cos_theta = pow(1.0f - r2, 1.0f / (power + 1.0f));
  float sin_theta = sqrt(1.0f - cos_theta*cos_theta);

  float3 deviation;
  deviation.x = sin_theta*cos_phi;
  deviation.y = sin_theta*sin_phi;
  deviation.z = cos_theta;

  float3 ny = direction, nx, nz;
  CoordinateSystem(ny, &nx, &nz);

  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  float3 res = nx*deviation.x + ny*deviation.y + nz*deviation.z;

  float invSign = dot(direction, hit_norm) > 0.0f ? 1.0f : -1.0f;

  if (invSign*dot(res, hit_norm) < 0.0f) // reflected ray is below surface #CHECK_THIS
  {
    res = (-1.0f)*nx*deviation.x + ny*deviation.y - nz*deviation.z;
    //belowSurface = true;
  }

  return res;
}


// Using the modified Phong reflectance model for physically based rendering
//
IDH_CALL float3 MapSampleToModifiedCosineDistribution(float r1, float r2, float3 direction, float3 hit_norm, float power)
{
  if (power >= 1e6f)
    return direction;

  // float sin_phi, cos_phi;
  // sincosf(2 * r1*3.141592654f, &sin_phi, &cos_phi);
  float sin_phi = sin(2.0f*r1*3.141592654f);
  float cos_phi = cos(2.0f*r1*3.141592654f);

  float sin_theta = sqrt(1.0f - pow(r2, 2.0f / (power + 1.0f)));

  float3 deviation;
  deviation.x = sin_theta*cos_phi;
  deviation.y = sin_theta*sin_phi;
  deviation.z = pow(r2, 1.0f / (power + 1.0f));

  float3 ny = direction, nx, nz;
  CoordinateSystem(ny, &nx, &nz);

  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  float3 res = nx*deviation.x + ny*deviation.y + nz*deviation.z;

  float invSign = dot(direction, hit_norm) > 0.0f ? 1.0f : -1.0f;

  if (invSign*dot(res, hit_norm) < 0.0f) // reflected ray is below surface #CHECK_THIS
  {
    res = (-1.0f)*nx*deviation.x + ny*deviation.y - nz*deviation.z;
    //belowSurface = true;
  }

  return res;
}

IDH_CALL float2 MapSamplesToDisc(float2 xy)
{
  float x = xy.x;
  float y = xy.y;

  float r = 0;
  float phi = 0;

  float2 res = xy;

  if (x>y && x>-y)
  {
    r = x;
    phi = 0.25f*3.141592654f*(y / x);
  }

  if (x < y && x > -y)
  {
    r = y;
    phi = 0.25f*3.141592654f*(2.0f - x / y);
  }

  if (x < y && x < -y)
  {
    r = -x;
    phi = 0.25f*3.141592654f*(4.0f + y / x);
  }

  if (x >y && x<-y)
  {
    r = -y;
    phi = 0.25f*3.141592654f*(6 - x / y);
  }

  //float sin_phi, cos_phi;
  //sincosf(phi, &sin_phi, &cos_phi);
  float sin_phi = sin(phi);
  float cos_phi = cos(phi);

  res.x = r*sin_phi;
  res.y = r*cos_phi;

  return res;
}


IDH_CALL float3 MapSamplesToCone(float cosCutoff, float2 sample, float3 direction)
{
  float cosTheta = (1 - sample.x) + sample.x * cosCutoff;
  float sinTheta = sqrt(1.0f - cosTheta * cosTheta);

  //float sinPhi, cosPhi;
  //sincosf(2.0f * M_PI * sample.y, &sinPhi, &cosPhi);
  float sinPhi = sin(2.0f * M_PI * sample.y);
  float cosPhi = cos(2.0f * M_PI * sample.y);

  float3 deviation = make_float3(cosPhi * sinTheta, sinPhi * sinTheta, cosTheta);

  // transform to different basis
  //
  float3 ny = direction;
  float3 nx = normalize(cross(ny, make_float3(1.04, 2.93f, -0.6234f)));
  float3 nz = normalize(cross(nx, ny));
  //swap(ny, nz);
  {
    float3 temp = ny;
    ny = nz;
    nz = temp;
  }

  return nx*deviation.x + ny*deviation.y + nz*deviation.z;
}



struct ZBlockT
{

#ifndef OCL_COMPILER  
#ifndef __CUDACC__

  ZBlockT() { index = 0; diff = diff2 = 100; counter = 0; }
  
  ZBlockT(int a_index, float a_diff)
  {
    index = a_index;
    diff = a_diff;
    diff2 = 0.01f*a_diff;
    counter = 0;
  }

#endif

  inline __host__ __device__ static int GetSize() { return Z_ORDER_BLOCK_SIZE*Z_ORDER_BLOCK_SIZE; }
  inline __host__ __device__ int GetOffset() const { return index*GetSize(); }
  inline __host__ __device__ bool operator<(const ZBlockT& rhs) const { return (diff < rhs.diff); }
#endif

  int index;   // just block offset
  int counter; // how many times this block was traced?
  float diff;  // difference with color buffer. the stop criterion as a matter of fact
  float diff2; // relative difference (in %)
};

typedef struct ZBlockT ZBlock;


static bool BlockFinished(ZBlock block, int a_minRaysPerPixel, int a_maxRaysPerPixel, float* a_outDiff) // for use on the cpu side ... for current
{
  int samplesPerPixel = block.counter; // was *2 due to odd and even staff

  if(a_outDiff!=NULL)
    *a_outDiff = block.diff;

  float acceptedBadPixels = sqrt((float)(CMP_RESULTS_BLOCK_SIZE));
  int minRaysPerPixel     = a_minRaysPerPixel;

  bool summErrorOk = (block.diff <= acceptedBadPixels);
  bool maxErrorOk = false;

  return ((summErrorOk || maxErrorOk) && samplesPerPixel >= minRaysPerPixel) || (samplesPerPixel >= a_maxRaysPerPixel);
}

IDH_CALL uint ThreadSwizzle1D(uint pixelId, uint zBlockIndex)
{
  uint indexInsideZBlock = pixelId%CMP_RESULTS_BLOCK_SIZE;
  return zBlockIndex*CMP_RESULTS_BLOCK_SIZE + indexInsideZBlock;
}


IDH_CALL float PdfAtoW(const float aPdfA, const float aDist, const float aCosThere)
{
  return (aPdfA*aDist*aDist) / fmax(aCosThere, 1e-12f);
}

struct MRaysStat
{
  int   traceTimePerCent;
  float raysPerSec;
  float samplesPerSec;

  float reorderTimeMs;

  float traversalTimeMs;
  float shadowTimeMs;
  float bounceTimeMS;

  float sampleTimeMS;
};


#ifdef __CUDACC__ 

  #undef ushort
  #undef uint

#endif


#endif

