#pragma once

#ifndef RTLIB_GUARDIAN
  #include "rtlib.h"
#endif

#ifndef ABSTRACT_MATERIAL_GUARDIAN
  #include "AbstractMaterial.h"
#endif

#ifndef LIGHT_GUARDIAN
  #include "Light.h"
#endif

#include "IGraphicsEngine.h"

#include <vector>
#include <stack>


struct InputGeom
{
  const float4* vertPos;
  const float4* vertNorm;
  const float2* vertTexCoord;
  const float4* vertTangent;
  size_t vertNum;

  const unsigned int* indices;         // of size == numIndices
  const unsigned int* materialIndices; // of size == numIndices/3
  size_t numIndices;
};


struct InputGeomBVH
{
  const BVHNode* nodes;
  size_t numNodes;

  const char* primListData;
  size_t primListSizeInBytes;

  size_t triNumInList;

};


struct MegaTexData
{
  int w, h; 
  const char* data;
  bool    outOfCore;          // must be explicitly set if GPU have insuffitient memory fro current texture
  float4* lookUpTable;
  int     lookUpTableSize; 
};


struct LightMeshData
{
  float4* positions;
  float2* texCoords;
  float2* intervals;
  size_t  size;
};

enum MEGATEX_USAGE{ MEGATEX_SHADING      = 1, 
                    MEGATEX_SHADING_HDR  = 2, 
                    MEGATEX_NORMAL       = 3, 
                    MEGATEX_OPACITY      = 4,
};


struct AllRenderVarialbes
{
  AllRenderVarialbes() 
  {
    memset(m_varsI, 0, sizeof(int)*GMAXVARS);
    memset(m_varsF, 0, sizeof(int)*GMAXVARS);
    m_flags = 0;
  }

  int   m_varsI[GMAXVARS];
  float m_varsF[GMAXVARS];
  unsigned int  m_flags;

  void SetVariableI(int a_name, int a_val);
  void SetVariableF(int a_name, float a_val);
  void SetFlags(unsigned int bits, unsigned int a_value);
};

class IHWLayer
{
public:

  IHWLayer(){}
  virtual ~IHWLayer() {}

  // data managment
  //

  virtual void Clear(IGraphicsEngine::CLEAR_FLAGS a_flags) = 0;

  virtual void SetGeom(InputGeom a_input) = 0;
  virtual void SetBVH(InputGeomBVH a_input) = 0;

  //virtual void Clear() = 0;

  virtual void SetAllPODMaterials(PlainMaterial* a_materialsAll, size_t a_number, int* indices, size_t a_matNum) = 0; // set All PlainMaterials, including intermediate and auxilary
  virtual void SetAllPODLights(RAYTR::Light* a_lights1, PlainLight* a_lights2, size_t a_number) = 0; // unlike materials, lights always represented as POD

  virtual void SetMegaTexture(MEGATEX_USAGE usage, const MegaTexData& a_data) = 0;

  virtual void SetAllTextureMatrices(float* a_data, size_t a_sizeInFloats) = 0;
  virtual void SetCamMatrices(float mProjInverse[16], float mWorldViewInverse[16]) = 0;

  // auxilary data structires for light meshes
  //
  virtual unsigned int AddLightMesh(LightMeshData a_lmesh) = 0;

  // render state
  //
 
  virtual void SetAllFlagsAndVars(const AllRenderVarialbes& a_vars);
  virtual AllRenderVarialbes GetAllFlagsAndVars() const;


  virtual void PushState();
  virtual void PopState();

  // rendering and other
  //

  virtual void BeginTracingPass()  = 0;
  virtual void EndTracingPass()    = 0;

  virtual void InitPathTracing(int seed) = 0;
  
  typedef MGML_MEMORY::FastList<ZBlock> BlockList;

  virtual bool ImplementBlocksPT() = 0;
  virtual void BeginBlocksPTPass(BlockList& a_list, int a_minRaysPerPixel, int a_maxRaysPerPixel) = 0;
  virtual void EndBlocksPTPass()   = 0;


  virtual void ResetPerfCounters() = 0;

  virtual void ResizeScreen(int w, int h, int a_flags) = 0;

  virtual void RegisterOutputGLBuffer(GLuint ogl_buffer) = 0;
  virtual void UnregisterOutputGLBuffer() = 0;

  virtual void GetLDRImageToGL(GLuint ogl_buffer) const = 0;
  virtual void GetLDRImage(uint* data, int width, int height) const = 0;
  virtual void GetHDRImage(float4* data, int width, int height) const = 0;

  virtual size_t GetAvaliableMemoryAmount(bool allMem = false) = 0;

  virtual MRaysStat GetRaysStat() = 0;

protected:

  AllRenderVarialbes m_vars;
  unsigned int       m_flags;

  std::stack<AllRenderVarialbes> m_varsStack;
  std::stack<unsigned int>       m_flagsStack;

};


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

IHWLayer* CreateCudaImpl(int w, int h, int a_flags);
IHWLayer* CreateOclImpl(int w, int h, int a_flags);
IHWLayer* CreateFRSDKImpl(int w, int h, int a_flags);


