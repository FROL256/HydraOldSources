#pragma once

#define N_BANDS 4
#define NUM_SH_FUNCTIONS (N_BANDS*N_BANDS)

#ifdef __CUDACC__

#else

#include "Voxelizer.h"
#include "../bvh_builder/BVHBuilderRef_vfrolov.h"


struct RadianceCache
{
public:

  RadianceCache();
  virtual ~RadianceCache();

  virtual void Build(const VoxelStorage<unsigned char>& a_voxels, float* a_pOutVoxelSize = NULL);

  virtual void InsertRecords(const float4* a_recordsData, int a_numRecords); // (x,y,z) -> pos; w -> sphere radius
  virtual void GenerateNewRecordPositions(); 

  virtual void EvaluateRadiance() = 0;

  virtual void BuildRecordsBVH();

protected:

  void DebugCheckBVH(const BVHNode* a_root, const BVHNode* a_node, const float4* fdata);

  std::ofstream m_debugSpheresOut;

  DynamicArray<float4> m_rcPositions;
  AABB3f m_bBox;

  IBVHBuilder* m_pBVHBuilder;

  int m_selfId;
};

struct SHRadianceCache  : public RadianceCache
{
  SHRadianceCache(){}

  void EvaluateRadiance();
};

struct CBMRadianceCache : public RadianceCache
{
  CBMRadianceCache(){}

  void EvaluateRadiance();
};


#endif

