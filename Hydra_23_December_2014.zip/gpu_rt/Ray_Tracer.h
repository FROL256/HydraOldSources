// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once

#include "IGraphicsEngine.h"
#include "Common_Graphics_Engine.h"
#include "rtlib.h"

class DLL_API Ray_Tracer: public Common_Graphics_Engine
{
public:

  Ray_Tracer(int w, int h, int a_flags);
  ~Ray_Tracer();

  virtual void PrintStatInfo(std::ostream& out) {};

  virtual void AddLightsAsGeometry();
  virtual void AddLightsFromEmissiveMaterials(int a_oldMaterialSize);

	class DLL_API RT_Core
	{
	public:
		//typedef Ray3f Ray;
		//typedef RAYTR::Hit Hit;
		
		virtual void SetMatrix(const Matrix4x4f& m);
		//virtual void TraverseRays(Ray* in_out_rays, RAYTR::Hit* out_hits, size_t in_N) = 0;
		//virtual void TraverseRays(Ray* in_out_rays, RAYTR::Hit* out_hits, size_t in_width, size_t in_height) = 0;
	
	protected:
		Matrix4x4f mRaysTransfrom;
	};

	virtual Ray_Tracer::RT_Core* GetRTCore() = 0;

	typedef Common_Graphics_Engine Base;

protected:
 
  void AddSphereAsMesh(RAYTR::Light* pLight, int addedMaterialId);

  std::map<int, std::vector<int> > m_lightMeshIdListByMatId;
};