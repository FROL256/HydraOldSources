#include "ImageSpaceQuadTree.h"

ImageSpaceQuadTree::ImageSpaceQuadTree()
{
  m_currBlockSize  = 16;
  m_startBlockSize = 16;
  m_minBlockSize   = 1;
}

void ImageSpaceQuadTree::BuildFromImage(int a_width, int a_height, const std::vector<float3>& a_image, std::vector<bool>* a_pRecordSet)
{
  m_pImage = &a_image;
  m_pSet   = a_pRecordSet;
  m_width  = a_width;
  m_height = a_height;

  m_pSet->resize(m_width*m_height);

  ProcessRegion(0, 0, m_width, m_height);
}



void ImageSpaceQuadTree::ProcessRegion(int startX, int startY, int endX, int endY)
{
  for(int y=startY;y<endY;y+=m_startBlockSize)
  {
    for(int x=startX;x<endX;x+=m_startBlockSize)
    {
      SubdivideQuadS(x, y, x+m_startBlockSize, y+m_startBlockSize);
    }
  }
}


void ImageSpaceQuadTree::BreadthFirstNextLevel(int a_width, int a_heigt, const std::vector<float3>& a_image, std::vector<bool>* a_pRecordSet)
{

}



int  ImageSpaceQuadTree::ThresholdIndex(int a_size)
{
  if(a_size == 16)
    return 3;
  else if(a_size == 8)
    return 2;
  else if(a_size == 4)
    return 1;
  else return 0;
}

void ImageSpaceQuadTree::SubdivideQuadS(int startX, int startY, int endX, int endY)
{
  InsertRecord(startX, startY);
  InsertRecord(endX, startY);
  InsertRecord(startX, endY);
  InsertRecord(endX, endY);

  int currSize = endX - startX;

  if(currSize <= m_minBlockSize)
    return;

  // S-type subdivision 
  //
  Edge e1(startX, startY, endX, startY); // right
  Edge e2(startX, startY, startX, endY); // down

  Edge e3(startX, endY, endX, endY);     // donw right
  Edge e4(endX, startY, endX, endY);     // right down

  Edge e5(startX, startY, endX, endY);   // cross
  Edge e6(startX, endY, endX, startY);   // cross

  Edge edges   [6] = {e1,e2,e3,e4,e5,e6};
  bool badEdges[6] = {false,false,false,false,false,false};

  int coundBadEdges = 0;
  for(int i=0;i<6;i++)
  {
    float diff = MaxDifferenceLine(edges[i].x1, edges[i].y1, edges[i].x2, edges[i].y2);
    int tindex = ThresholdIndex(currSize);

    if(diff >= m_threshold[tindex])
    {
      badEdges[i] = true;
      coundBadEdges++;
    }
  }

  if(coundBadEdges == 0) // finish
  {
    return;
  }
  if(coundBadEdges == 1) // split just one edge, insert record at center and finish ?
  {
    for(int i=0;i<6;i++)
    {
      if(badEdges[i])
      {
        int cx = (edges[i].x1 + edges[i].x2)/2;
        int cy = (edges[i].y1 + edges[i].y2)/2;
        InsertRecord(cx, cy);
        break;
      }
    }
  }
  else if(coundBadEdges == 2)
  {
    int cx = (startX + endX)/2;
    int cy = (startY + endY)/2;

    if(badEdges[0] && badEdges[1])      // top left
    {
      //InsertRecord(startX, cy);
      //InsertRecord(cx, startY);
      //InsertRecord(cx, cy);

      SubdivideQuadS(startX, startY, cx, cy);
    }
    else if(badEdges[0] && badEdges[3]) // top right
    {
      //InsertRecord(cx, startY);
      //InsertRecord(endX, cy);
      //InsertRecord(cx, cy);

      SubdivideQuadS(cx, startY, endX, cy);
    }
    else if(badEdges[1] && badEdges[2]) // down left
    {
      //InsertRecord(startX, cy);
      //InsertRecord(cx, endY);
      //InsertRecord(cx, cy);

      SubdivideQuadS(startX, cy, cx, endY);
    }
    else if(badEdges[2] && badEdges[3]) // down right
    {
      //InsertRecord(endX, cy);
      //InsertRecord(cx, endY);
      //InsertRecord(cx, cy);

      SubdivideQuadS(cx, cy, endX, endY);
    }
    else
    {
      SubdivideQuadR(startX, startY, endX, endY);
    }

    SubdivideQuadR(startX, startY, endX, endY);

  }
  else
  {
    SubdivideQuadR(startX, startY, endX, endY);
  }

}

void ImageSpaceQuadTree::SubdivideQuadR(int startX, int startY, int endX, int endY)
{
  int cx = (startX + endX)/2;
  int cy = (startY + endY)/2;

  InsertRecord(cx, startY);
  InsertRecord(startX, cy);

  InsertRecord(cx, endY);
  InsertRecord(endX, cy);

  InsertRecord(cx, cy);

  SubdivideQuadS(startX, startY, cx, cy);
  SubdivideQuadS(cx, startY, endX, cy);
  SubdivideQuadS(startX, cy, cx, endY);
  SubdivideQuadS(cx, cy, endX, endY);
}

int signZero(int x) 
{  
  if(x > 0) 
    return 1; 
  else if(x == 0) 
    return 0;
  else 
    return -1;
}


float ImageSpaceQuadTree::MaxDifferenceLine(int x1, int y1, int x2, int y2)
{
  int dx = x2 - x1;
  int dy = y2 - y1;

  int lenSquare = dx*dx + dy*dy;

  dx = signZero(dx);
  dy = signZero(dy);

  if(lenSquare == 0)
  {
    return 0.0f;
  }
  else if(lenSquare == 1)
  {
    return Difference(x1,y1, x2,y2);
  }
  else // find maximum difference along the line
  {
    float maxDiff = 0.0f;

    int px = x1 + dx;
    int py = y1 + dy;

    while(px < x2 || py < y2)
    {
      float diff1 = Difference(x1,y1, px,py);
      float diff2 = Difference(x2,y2, px,py);

      maxDiff = ::fmaxf(maxDiff, ::fmaxf(diff1, diff2));

      px = px + dx;
      py = py + dy;
    }

    return maxDiff;
  }


}


float ImageSpaceQuadTree::Difference(int x1, int y1, int x2, int y2)
{
  if(x1 >= m_width-1)
    x1 = m_width-1;

  if(x2 >= m_width-1)
    x2 = m_width-1;

  if(y1 >= m_height-1)
    y1 = m_height-1;

  if(y2 >= m_height-1)
    y2 = m_height-1;

  float3 val1 = (*m_pImage)[y1*m_width + x1];
  float3 val2 = (*m_pImage)[y2*m_width + x2];

  float2 p1(x1,y1);
  float2 p2(x2,y2);

  //float d = fmaxf(1.0f, 0.5f*length(p1-p2));

  return m_scale*length(val1 - val2);//*d;
}


void ImageSpaceQuadTree::InsertRecord(int x, int y)
{
  if(x >= m_width-1)
    x = m_width-1;

  if(y >= m_height-1)
    y = m_height-1;

  (*m_pSet)[m_width*y+x] = true;
}

