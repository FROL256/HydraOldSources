#include "GPU_Path_Tracer.h"
#include "Fonts.h"
#include "IrradianceCache.h"
#include "ImageSpaceQuadTree.h"

#include <sstream>

using MGML_MATH::EPSILON_E5;
using namespace RAYTR;

float IrradianceCacheDataSet::avgSamplesPerPoint = 0.0f;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
RAYTR::IrradianceCacheDataSet::IrradianceCacheDataSet(int a_maxDataSize, int a_width, int a_height)
{
  m_data1.resize(0); m_data1.reserve(a_maxDataSize);
  m_data2.resize(0); m_data2.reserve(a_maxDataSize);
  m_data3.resize(0); m_data3.reserve(a_maxDataSize);
  m_savedPixelSize.resize(0); m_savedPixelSize.reserve(a_maxDataSize);

  m_screenHasPoint.resize(a_width*a_height);
  for(size_t i=0;i<m_screenHasPoint.size();i++)
    m_screenHasPoint[i] = false;

  m_screenWidth  = a_width;
  m_screenHeight = a_height;
  pointsWithMaxError = 0;

  pHydraMaterials = NULL;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
RAYTR::IrradianceCacheDataSet::~IrradianceCacheDataSet()
{

}

//void RAYTR::IrradianceCacheDataSet::SelectPointsFromFullScreenData(const std::vector<IrradianceCachePoint_Part1>& iTempCache1, 
//                                                                   const std::vector<IrradianceCachePoint_Part2>& iTempCache2,
//                                                                   const std::vector<float>& tempPixelSize)
//{
//
//}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void RAYTR::IrradianceCacheDataSet::AnalizeScreenSpaceSurface(float3 a_camPos)
{
  int width  = m_screenWidth;
  int height = m_screenHeight;

  std::vector<IrradianceCachePoint_Part1> iTempCache1(width*height);
  std::vector<IrradianceCachePoint_Part2> iTempCache2(width*height);

  std::vector<float> tempPixelSize(width*height);
  std::vector<float> tempDiscontinuity(width*height);

  hlmAllocIrradianceCacheFullScreenBuffers(width*height);

  // 1) trace rays from eye; get sample points
  // 2) ���������� ��������� Width*Height ���������. ��������� ������� � ������� �� CPU (������ ��� ��������� �����).
  //
  hrtSetFlags(HRT_TRACE_DEPTH, 1);
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 1);
  hlmIrradianceCahceGetFullScreenPositions(&iTempCache1[0], &iTempCache2[0], width*height);

  hlmCalcSurfaceDiscontinuity(&tempDiscontinuity[0], &tempPixelSize[0], false);

  hlmFreeIrradianceCacheFullScreenBuffers();  
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 0);
  
  m_savedPixelDist.resize(tempPixelSize.size());

  m_data1.resize(0);
  m_data2.resize(0);
  m_data3.resize(0);
  m_savedPixelSize.resize(0);

  for(int x=0;x<width;x++)
  {
    for(int y=0;y<height;y++)
    {
      int i = IndexZBlock2D(x,y);
      int j = Index2D(x,y);

      if(iTempCache1[i].materialId >= 0 && tempDiscontinuity[j] > 0.0f)
      {
        if(!m_screenHasPoint[j] && length(pHydraMaterials[iTempCache1[i].materialId].diffuse.color) > 0.01f)
        {
          IrradianceCachePoint_Part3 temp;
          temp.color = float3(0,0,0);

          m_data1.push_back(iTempCache1[i]);
          m_data2.push_back(iTempCache2[i]);
          m_data3.push_back(temp);
          m_savedPixelSize.push_back(tempPixelSize[j]);
          m_screenHasPoint[j] = true;
          m_savedPixelDist[j] = length(iTempCache1[i].pos - a_camPos);
        }
      }
    }
  }

  m_allPixelsSize = tempPixelSize;
}

void RAYTR::IrradianceCacheDataSet::InitialQuadTreeApproxByNormals(float3 a_camPos, bool ssLowPrecition)
{
  int width  = m_screenWidth;
  int height = m_screenHeight;

  std::vector<IrradianceCachePoint_Part1> iTempCache1(width*height);
  std::vector<IrradianceCachePoint_Part2> iTempCache2(width*height);

  std::vector<float> tempPixelSize(width*height);
  //std::vector<float> tempDiscontinuity(width*height);

  hlmAllocIrradianceCacheFullScreenBuffers(width*height);

  // 1) trace rays from eye; get sample points
  // 2) ���������� ��������� Width*Height ���������. ��������� ������� � ������� �� CPU (������ ��� ��������� �����).
  //
  hrtSetFlags(HRT_TRACE_DEPTH, 1);
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 1);
  hlmIrradianceCahceGetFullScreenPositions(&iTempCache1[0], &iTempCache2[0], width*height);

  //hlmCalcSurfaceDiscontinuity(&tempDiscontinuity[0], &tempPixelSize[0], true); // NO DITHERING enabled to get original surface disc

  hlmFreeIrradianceCacheFullScreenBuffers();  
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 0);
 

  std::vector<float3> normalsImage(width*height);
  std::vector<bool>   normalsSubdiv(width*height);

  if(1)
  {

    for(int y=0;y<height;y++)
    {
      for(int x=0;x<width;x++)
      {
        normalsImage[Index2D(x,y)] = iTempCache2[IndexZBlock2D(x,y)].norm;
      }
    }

    ImageSpaceQuadTree* pQuadTree = new ImageSpaceQuadTree;
    
    float thresholds[4] = {1.0f, 0.75f, 0.25f, 0.1f}; // float thresholds[4] = {0.75f, 0.5f, 0.25f, 0.1f};
    
    if(ssLowPrecition)
      pQuadTree->SetThresholds(1.0f, thresholds);
    else
      pQuadTree->SetThresholds(0.75f, thresholds);
    
    pQuadTree->SetConfig(16, 4);

    pQuadTree->BuildFromImage(width, height, normalsImage, &normalsSubdiv);

    delete pQuadTree; pQuadTree = NULL;
  }


  /////////////////////////////////////////////////////////////////////////////////////////////////////
  //
  m_savedPixelDist.resize(tempPixelSize.size());

  m_data1.resize(0);
  m_data2.resize(0);
  m_data3.resize(0);
  m_savedPixelSize.resize(0);

  for(int y=0;y<height;y++)
  {
    for(int x=0;x<width;x++)
    {
      int i = IndexZBlock2D(x,y);
      int j = Index2D(x,y);

      if(normalsSubdiv[j] && !m_screenHasPoint[j] && iTempCache1[i].materialId >= 0)
      {
        if(length(pHydraMaterials[iTempCache1[i].materialId].diffuse.color) > 0.001f || (x%16 == 0 && y%16 == 0))
        {
          IrradianceCachePoint_Part3 temp;
          temp.color = float3(0,0,0);

          m_data1.push_back(iTempCache1[i]);
          m_data2.push_back(iTempCache2[i]);
          m_data3.push_back(temp);
          m_savedPixelSize.push_back(tempPixelSize[j]);
          m_screenHasPoint[j] = true;
          m_savedPixelDist[j] = length(iTempCache1[i].pos - a_camPos);
        }
      }
    }
  }

  m_allPixelsSize = tempPixelSize;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void RAYTR::IrradianceCacheDataSet::AnalizeScreenSpaceRadiance(float3 a_camPos)
{
  m_data1.resize(0);
  m_data2.resize(0);
  m_data3.resize(0);
  m_savedPixelSize.resize(0);

  int width  = m_screenWidth;
  int height = m_screenHeight;

  std::vector<IrradianceCachePoint_Part1> iTempCache1(width*height);
  std::vector<IrradianceCachePoint_Part2> iTempCache2(width*height);

  std::vector<float> irradianceDiffPoint(width*height);

  hlmAllocIrradianceCacheFullScreenBuffers(width*height);

  // 1) trace rays from eye; get sample points
  // 2) ���������� ��������� Width*Height ���������. ��������� ������� � ������� �� CPU (������ ��� ��������� �����).
  //
  hrtSetFlags(HRT_TRACE_DEPTH, 1);
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 1);
  hlmIrradianceCahceGetFullScreenPositions(&iTempCache1[0], &iTempCache2[0], width*height);

  hlmCalcRadianceDiscontinuity(&irradianceDiffPoint[0], width*height, m_minPixelStep);

  hlmFreeIrradianceCacheFullScreenBuffers();  
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 0);

  for(int x=0;x<width;x++)
  {
    for(int y=0;y<height;y++)
    {
      int i = IndexZBlock2D(x,y);
      int j = Index2D(x,y);

      if(!m_screenHasPoint[j] && iTempCache1[i].materialId >= 0 && irradianceDiffPoint[j] > 0.0f)
      {
        if(length(pHydraMaterials[iTempCache1[i].materialId].diffuse.color) > 0.01f)
        {
          IrradianceCachePoint_Part3 temp;
          temp.color = float3(0,0,0);

          m_data1.push_back(iTempCache1[i]);
          m_data2.push_back(iTempCache2[i]);
          m_data3.push_back(temp);
          m_savedPixelSize.push_back(m_allPixelsSize[j]);
          m_screenHasPoint[j] = true;
          m_savedPixelDist[j] = length(iTempCache1[i].pos - a_camPos);
        }
      }
    }
  }

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void RAYTR::IrradianceCacheDataSet::AnalizeScreenSpaceRadiance2(float3 a_camPos, int a_pass, float a_onePixelScale)
{
  m_data1.resize(0);
  m_data2.resize(0);
  m_data3.resize(0);
  m_savedPixelSize.resize(0);

  int width  = m_screenWidth;
  int height = m_screenHeight;

  std::vector<IrradianceCachePoint_Part1> iTempCache1(width*height);
  std::vector<IrradianceCachePoint_Part2> iTempCache2(width*height);

  std::vector<float3> irradiance(width*height);
  std::vector<bool>   subdiv(width*height);

  hlmAllocIrradianceCacheFullScreenBuffers(width*height);

  // 1) trace rays from eye; get sample points
  // 2) ���������� ��������� Width*Height ���������. ��������� ������� � ������� �� CPU (������ ��� ��������� �����).
  //
  hrtSetFlags(HRT_TRACE_DEPTH, 1);
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 1);
  hlmIrradianceCahceGetFullScreenPositions(&iTempCache1[0], &iTempCache2[0], width*height);

  hlmGetFullScreenRadiance(&irradiance[0]);

  hlmFreeIrradianceCacheFullScreenBuffers();  
  hrtSetFlags(HRT_IC_ESTIMATE_SS_IRRAD, 0);

  if(1)
  {
    ImageSpaceQuadTree* pQuadTree = new ImageSpaceQuadTree;
    
    float thresholds[4] = {0.5f, 0.25f, 0.025f, 0.01f}; // float thresholds[4] = {0.75f, 0.5f, 0.25f, 0.1f};
    
    int nodeStop = 8;
    
    if(a_pass%4 == 0)
      nodeStop = 8;
    else if(a_pass%4 == 1)
      nodeStop = 4;
    else if(a_pass%4 == 2)
      nodeStop = 2;
    else if(a_pass%4 == 3)
      nodeStop = 1;

    pQuadTree->SetThresholds(1.0f, thresholds);
    pQuadTree->SetConfig(16, nodeStop);

    pQuadTree->BuildFromImage(width, height, irradiance, &subdiv);

    delete pQuadTree; pQuadTree = NULL;
  }

  for(int x=0;x<width;x++)
  {
    for(int y=0;y<height;y++)
    {
      int i = IndexZBlock2D(x,y);
      int j = Index2D(x,y);

      if(!m_screenHasPoint[j] && iTempCache1[i].materialId >= 0 && subdiv[j])
      {
        if(length(pHydraMaterials[iTempCache1[i].materialId].diffuse.color) > 0.01f)
        {
          IrradianceCachePoint_Part3 temp;
          temp.color = float3(0,0,0);

          m_data1.push_back(iTempCache1[i]);
          m_data2.push_back(iTempCache2[i]);
          m_data3.push_back(temp);
          m_savedPixelSize.push_back(m_allPixelsSize[j]);
          m_screenHasPoint[j] = true;
          m_savedPixelDist[j] = length(iTempCache1[i].pos - a_camPos);
        }
      }
    }
  }

 

}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void RAYTR::IrradianceCacheDataSet::ComputeRadiance(ICPresets a_presets)
{
  float sampleCount[4] = {1024.0f, 4096.0f, 16384.0f, 65536.0f};
  float avgSamplesPerRecord = 0.0f;
  float acceptableError = a_presets.icError;

  std::vector<float> errors(m_data1.size(), 100.0f);

  hrtSetFlags(HRT_TRACE_DEPTH, 2);
  
  if(a_presets.icProgressiveEvaluation == false)
  {
    int order = 0;

    switch(a_presets.icFixedRays)
    {
    case 1024:
      order = 0;
      break;

    case 4096:
      order = 1;
      break;

    case 16384:
      order = 2;
      break;

    case 65536:
      order = 3;
      break;

    default:
      order = 1;
      break;
    };

    hlmIrradianceCahceComputeIrradiance(order, &m_data1[0], &m_data2[0], &m_data3[0], &errors[0], m_data1.size());
    IrradianceCacheDataSet::avgSamplesPerPoint += m_data1.size()*a_presets.icFixedRays;
    return;
  }

  std::vector<Part1> activeArray1(m_data1.size());
  std::vector<Part2> activeArray2(m_data1.size());
  std::vector<Part3> activeArray3(m_data1.size());

  std::vector<int>    indices(m_data1.size());

  for(int i=0;i<m_data1.size();i++)
    indices[i] = i;

  int startLevel = 0;
  if(acceptableError <= 0.05f)
    startLevel = 1;
  else if(acceptableError <= 0.005f)
    startLevel = 2;

  for(int accurancyLevel = startLevel; accurancyLevel < 4; accurancyLevel++)
  {
    int top = 0;
    int numPointsToCompute = errors.size();

    for(int i=0;i<numPointsToCompute;i++)
    {
      if(errors[i] > acceptableError) // error in %
      {
        activeArray1[top] = m_data1[i];
        activeArray2[top] = m_data2[i];
        activeArray3[top] = m_data3[i];
        indices[top]      = i;
        top++;
      }
    }

    if(top == 0)
      break;

    std::vector<float>  activeErrors(top);
    hlmIrradianceCahceComputeIrradiance(accurancyLevel, &activeArray1[0], &activeArray2[0], &activeArray3[0], &activeErrors[0], top);
    avgSamplesPerRecord += top*sampleCount[accurancyLevel];


    float samplesSumm = 0.0f;
    for(int j=startLevel;j<accurancyLevel;j++)
      samplesSumm += sampleCount[j];

    for(int i=0;i<top;i++)
    {
      int oldIndex = indices[i];

      float3 oldColor = m_data3[oldIndex].color;
      float3 newColor = activeArray3[i].color;

      float totalSumm = samplesSumm + sampleCount[accurancyLevel];
      float w1 = samplesSumm/totalSumm;
      float w2 = sampleCount[accurancyLevel]/totalSumm;

      m_data3[oldIndex].color = oldColor*w1 + newColor*w2;
      errors [oldIndex] = activeErrors[i]*(1.0f-w1/w2);
      m_data3[oldIndex].validityRadius = activeArray3[i].validityRadius;
    }
  }

  IrradianceCacheDataSet::avgSamplesPerPoint += avgSamplesPerRecord;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
float2 RAYTR::IrradianceCacheDataSet::MiniMaximizeValidityRadiuses()
{
  float maxBoxSize = MaxAxisSize(m_bBox);

  for(int i=0;i<m_data3.size();i++)
  {
    if(m_screenHasPoint[i])
    {
      float pixelSize = fmaxf(m_savedPixelSize[i], 0.0001f*maxBoxSize);
      m_data3[i].validityRadius = clamp(m_data3[i].validityRadius, 4.0f*pixelSize, pixelSize*64.0f);
    }
  }

  //m_savedPixelSize = std::vector<float>();

  return float2(0,0);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
float2 RAYTR::IrradianceCacheDataSet::MiniMaximizeValidityRadiuses(float a_minRadius, float a_maxRadius)
{
  for(int i=0;i<m_data3.size();i++)
    m_data3[i].validityRadius = fmaxf(fminf(m_data3[i].validityRadius, a_maxRadius), a_minRadius);

  return float2(0,0);
}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void RAYTR::IrradianceCacheDataSet::SelectCanditatesWithUniqueNormal(const IrradianceCachePoint_Part1* iTempCache1, const IrradianceCachePoint_Part2* iTempCache2, 
                                                                     const std::vector<SortIndices>& sorted, const std::vector<Group>& groups, std::vector<CandidatePoint>& candidates)
{

  pointsWithMaxError = 0.0f;

  for(int i=0;i<groups.size();i++)
  { 
    bool haveUnsplitGroups = true;

    std::vector<bool> killed(groups[i].end - groups[i].begin);
    for(int j=0;j<killed.size();j++) killed[j] = false;

    while(haveUnsplitGroups) // extract all groups
    {
      // find maxError
      //
      bool   nothingInterestingWasFound = true;
      int    jOfMax     = groups[i].begin;
      int    indexOfMax = sorted[jOfMax].oldIndex;
      float  maxError   = -1.0f; 
      float3 normOfMax  = iTempCache2[indexOfMax].norm;

      for(int j=groups[i].begin; j<groups[i].end; j++)
      {
        int   index = sorted[j].oldIndex;
        float error = iTempCache2[index].GetInterpolationError();
        
        if(error >= 100.0f)
          pointsWithMaxError++;

        if(error > maxError && !killed[j-groups[i].begin])
        {
          maxError   = error;
          indexOfMax = index;
          normOfMax  = iTempCache2[index].norm;
          nothingInterestingWasFound = false;
        }
      }

      if(groups[i].end - groups[i].begin > 1 && nothingInterestingWasFound) break;

      CandidatePoint p;
      p.error = maxError;
      p.norm = normOfMax;
      p.pos  = iTempCache1[indexOfMax].pos;
      p.oldIndex = indexOfMax;
      candidates.push_back(p);

      if(groups[i].end - groups[i].begin == 1) break;

      killed[jOfMax-groups[i].begin] = true; // kill current point

      // now kill all other points with the same normal
      //
      haveUnsplitGroups = false;
      for(int j=groups[i].begin; j<groups[i].end; j++)
      {
        int index   = sorted[j].oldIndex;
        float3 norm = iTempCache2[index].norm;

        float  normSimilarity = dot(normOfMax, norm);
        float cos_10 = cosf(MGML_MATH::DEG_TO_RAD(10.0f));

        if(normSimilarity > cos_10)
          killed[j-groups[i].begin] = true;
        else if (!killed[j-groups[i].begin])
          haveUnsplitGroups = true;
      }

    } //  while(haveUnsplitGroups)

  } //  for(int i=0;i<groups.size();i++)

}


/////////////////////////////////////////////////////////////////////////////////////////////////
////
void RAYTR::IrradianceCacheDataSet::GroupPointsWith3DZCurve(IrradianceCachePoint_Part1* a_iTempCache1, IrradianceCachePoint_Part2* a_iTempCache2, int a_recordedPointsNum, std::vector<SortIndices>& sorted, std::vector<Group>& a_groups)
{

  AABB3f bBox;
  for(int i=0;i<a_recordedPointsNum;i++)
  {
    if(a_iTempCache1[i].materialId < 0)
      continue;

    float3 pos = a_iTempCache1[i].pos;
    bBox.vmin.x = fminf(bBox.vmin.x, pos.x);
    bBox.vmin.y = fminf(bBox.vmin.y, pos.y);
    bBox.vmin.z = fminf(bBox.vmin.z, pos.z);

    bBox.vmax.x = fmaxf(bBox.vmax.x, pos.x);
    bBox.vmax.y = fmaxf(bBox.vmax.y, pos.y);
    bBox.vmax.z = fmaxf(bBox.vmax.z, pos.z);
  }

  ASSERT(bBox.vmin.x <= bBox.vmax.x);
  ASSERT(bBox.vmin.y <= bBox.vmax.y);
  ASSERT(bBox.vmin.z <= bBox.vmax.z);

  for(int i=0;i<a_recordedPointsNum;i++)
  {
    float3 pos = a_iTempCache1[i].pos;
    float3 localCoord = (pos - bBox.vmin)/(bBox.vmax - bBox.vmin); 
    sorted[i].oldIndex = i;
    sorted[i].newIndex = GetMortonNumber((int)1023*localCoord.x, (int)1023*localCoord.y, (int)1023*localCoord.z);
  }

  if(a_recordedPointsNum <= 0)
    return;

  std::sort(sorted.begin(), sorted.end());

  float saAllScene = MaxAxisSize(bBox);
  float saEpsilon  = 0.0001f*saAllScene;
  float saMaxGroup = 0.040f*saAllScene;
  
  //if(m_currPassNumber >= 8)
  //{
  //  saMaxGroup *= 0.001f;
  //  saEpsilon  *= 0.1f;
  //}
  //else if(m_currPassNumber >= 6)
  //{
  //  saMaxGroup *= 0.01f;
  //  saEpsilon  *= 0.25f;
  //}


  if(m_currPassNumber >= 8)
  {
    saMaxGroup *= 0.5f;
    saEpsilon  *= 0.75f;
  }
  else if(m_currPassNumber >= 6)
  {
    saMaxGroup *= 0.5f;
    saEpsilon  *= 0.75f;
  }


  AABB3f box(a_iTempCache1[sorted[0].oldIndex].pos);
  int start = 0;
  for(int i=1;i<a_recordedPointsNum;i++)
  {
    int oldIndex = sorted[i].oldIndex;
    float3 pos   = a_iTempCache1[oldIndex].pos;

    AABB3f box2 = box;
    box2.include(pos);

    float sa1 = MaxAxisSize(box);
    float sa2 = MaxAxisSize(box2);

    if ( (sa1 > saEpsilon && sa2 > 4*sa1) || sa2 > saMaxGroup ) // restart group
    {
      a_groups.push_back(Group(start,i,box));
      start = i;
      box = AABB3f(pos);
    }
    else
      box = box2;
  }

  //std::cerr << "problem points were grouped into " << a_groups.size() << " groups \n";
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
int RAYTR::IrradianceCacheDataSet::SelectFewPointsWithLargeError(int maxNewPoints, bool a_lastPass, int icBounce)
{
  int recordedPointsNum = 0;
  int recordedPointsNum2 = 0;

  IrradianceCachePoint_Part1* iTempCache1 = (IrradianceCachePoint_Part1*)_aligned_malloc(sizeof(IrradianceCachePoint_Part1)*maxNewPoints, 16);
  IrradianceCachePoint_Part2* iTempCache2 = (IrradianceCachePoint_Part2*)_aligned_malloc(sizeof(IrradianceCachePoint_Part2)*maxNewPoints, 16);

  hrtPushAllVars();
  hrtPushAllFlags();
  hrtSetFlags(HRT_USE_RANDOM_RAYS, 1);

  if(icBounce == 1)
  {
    hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 1);
    hrtSetFlags(HRT_DIFFUSE_REFLECTION, 1);
  }
  else
    hrtSetVariableI(HRT_DIFFUSE_TRACE_DEPTH, 0);

  hlmIrradianceCacheFindMoreCandidates(iTempCache1, iTempCache2, maxNewPoints, &recordedPointsNum);
  
  hrtPopAllFlags();
  hrtPopAllVars();

  if(0)
  {
    std::ofstream fout1((std::string("spheres") + ToString(0) + std::string(".txt")).c_str());
    for(int i=recordedPointsNum;i<recordedPointsNum+recordedPointsNum2;i++)
    {
      fout1 << iTempCache1[i].pos << " ";
      fout1 << 0.0f << std::endl;
    }
  }


  //std::cerr << recordedPointsNum <<  " problem points found (1)" << std::endl;
  //std::cerr << recordedPointsNum2 << " problem points found (2)" << std::endl;

  //recordedPointsNum = recordedPointsNum + recordedPointsNum2;

  if(recordedPointsNum == 0)
  {
    m_data1.resize(0);
    m_data2.resize(0);
    m_data3.resize(0);
    return 0;
  }

  std::vector<CandidatePoint> candidates;  candidates.reserve(recordedPointsNum);

  int maxPoints = a_lastPass ? 2000 : 500;

  if(recordedPointsNum > maxPoints)
  {
    std::vector<SortIndices> sorted(recordedPointsNum); 
    std::vector<Group> groups; groups.reserve(recordedPointsNum/2);

    GroupPointsWith3DZCurve(iTempCache1, iTempCache2, recordedPointsNum, sorted, groups); 
    SelectCanditatesWithUniqueNormal(iTempCache1, iTempCache2, sorted, groups, candidates);
  }
  else
  {
    candidates.resize(recordedPointsNum);
    for(int i=0;i<candidates.size();i++)
      candidates[i].oldIndex = i;
  }

  m_data1.resize(candidates.size());
  m_data2.resize(candidates.size());
  m_data3.resize(candidates.size());

  for(int i=0;i<candidates.size();i++)
  {
    m_data1[i] = iTempCache1[candidates[i].oldIndex];
    m_data2[i] = iTempCache2[candidates[i].oldIndex];
    m_data3[i].color = float3(0,0,0);
  }

  _aligned_free(iTempCache1);
  _aligned_free(iTempCache2);

  return candidates.size();
}



/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::InsertPointsInOctree(const RAYTR::IrradianceCacheDataSet& a_data, IrradCacheOctreeAPI* pOctree)
{
  pOctree->Insert(a_data.GetData1(), a_data.GetData2(), a_data.GetData3(), a_data.size());
  pOctree->ConvertLayoutToLinearArray();

  hlmIrradianceCahceSetRecordsData(pOctree->GetPointsDataPart1(), pOctree->GetPointsDataPart2(), pOctree->GetPointsDataPart3(), pOctree->GetPointNum());
  hlmIrradianceCahceSetOctree(pOctree->GetRoot(), pOctree->GetNumNodes(), pOctree->GetOctreePointIndices(), pOctree->GetOctreeIndicesNum(), pOctree->GetBoxCenter(), pOctree->GetBoxSize()); 
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::SetICPresets(const ICPresets& a_presets)
{
  m_icPresets = a_presets;
  hrtSetVariableF(HRT_IC_WS_ERROR_TRESHOLD, m_icPresets.icWSErrorTreshold);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::ComputeIrradianceCache()
{ 
  IrradianceCacheDataSet::avgSamplesPerPoint = 0.0f;

  float maxBoxSize = MaxAxisSize(m_bBox);  

  GPU_Ray_Tracer::UpdateComplete();

  //hrtSetVariableI(HRT_IC_BOUNCE, m_lastRenderState.icBounce);
  bool ssLowPrecition = (m_lastRenderState.icBounce == 1);

  hrtPushAllFlags();
  hrtSetFlags(HRT_DISABLE_BUMP, 1);
  hrtSetFlags(HRT_COMPUTE_IRRADIANCE_CACHE, 1);
  hrtSetFlags(HRT_DIFFUSE_REFLECTION, 0);
  hrtSetVariableI(HRT_IC_HARMONIC_MEAN, 0);
  hrtSetVariableI(HRT_DISPLAY_IC_INTERMEDIATE, 1);

  Matrix4x4f mRayTransform(m_worldViewInvMatrixData); //*(this->pWorld_matrix);
  float3 camPos = mRayTransform*float3(0,0,0);

  if(m_debugOutput)
  {
    std::cerr << std::endl;
    std::cerr << "irradiance cache info:" << std::endl;
  }

  Timer irradCacheTimer;
  irradCacheTimer.start();
  float timeStart = irradCacheTimer.getElapsed();

  IrradCacheOctreeAPI* pOctree = new IC_Octree;
  float octreeConstructionTime = 0.0f;
  IrradianceCacheDataSet screenSpaceSet(40000, width, height);

  // the very first pass
  //
  if(1)
  {
    screenSpaceSet.pHydraMaterials = &m_hydraMaterials[0];

    screenSpaceSet.m_bBox = m_bBox;
    //screenSpaceSet.AnalizeScreenSpaceSurface(camPos);
    screenSpaceSet.InitialQuadTreeApproxByNormals(camPos, ssLowPrecition);
    screenSpaceSet.ComputeRadiance(m_icPresets);
    screenSpaceSet.MiniMaximizeValidityRadiuses();

    pOctree->SetBoundingBox(m_bBox);
    pOctree->SetClampingFactor(1.5f);  //  

    if(m_debugICacheFileOutput)
    {
      std::ofstream fout1((std::string("spheres") + ToString(0) + std::string(".txt")).c_str());
      for(int i=0;i<screenSpaceSet.size();i++)
      {
        fout1 << screenSpaceSet.GetData1()[i].pos << " ";
        fout1 << screenSpaceSet.GetData3()[i].validityRadius << std::endl;
      }
    }

    float computeRadianceTime = irradCacheTimer.getElapsed();

    InsertPointsInOctree(screenSpaceSet, pOctree);

    octreeConstructionTime = irradCacheTimer.getElapsed() - computeRadianceTime;

    float constructionTime = irradCacheTimer.getElapsed() - computeRadianceTime;
    float totalTime = irradCacheTimer.getElapsed() - timeStart;

    if(m_debugOutput)
    {
      std::cerr << "construction time (first pass):  " << constructionTime << std::endl;
      std::cerr << std::endl;
      std::cerr << "Total cache time  (first pass):  " << totalTime << std::endl;
      std::cerr << "Number of selected points(0)  :  " << screenSpaceSet.size() << std::endl;
      std::cerr << std::endl;
    }
  }

  m_updateProgressCall("Building Irradiance Cache", 0.1f);

  // show result on the screen
  //
  EndDrawScene(); 
  m_updateImageCall(this, NULL, false);
  if(!(m_initFlags & GPU_RT_NOWINDOW))
  {
    glClear(GL_DEPTH_BUFFER_BIT);  
    DrawICRecords();
    glutSwapBuffers();
  }

  IrradianceCacheDataSet worldSpaceSet(100000, width, height);
  worldSpaceSet.pHydraMaterials = &m_hydraMaterials[0];

  std::vector<int> maxErrorPointsSequence; maxErrorPointsSequence.reserve(40);

  float startSecondPassTime = irradCacheTimer.getElapsed();

  float imageSpaceDiscScale = 1.0f;
  float scaleArray[4]   = {16.0f, m_icPresets.icErrorSS[0], m_icPresets.icErrorSS[1], m_icPresets.icErrorSS[2]};  // special case for one pixel
  int   minPixelStep[4] = {8, 4, 2, 1};

  bool lastPass = false;
  bool firstToPixel = true;

  if(ssLowPrecition)
  {
    for(int i=0;i<4;i++)
      scaleArray[i] *= 0.25f;
  }

  int numPasses = m_icPresets.icMaxPasses;
  for(int pass = 0; pass < numPasses; pass++)
  {
    if(pass == numPasses-1)
      lastPass = true;

    int passId = pass;

    if(passId >= 4)
      passId = passId % 4;

    // screen space stage
    //
    if(!(ssLowPrecition && passId > 1) && pass <= (numPasses/2 + 1))
    {
      hrtSetVariableI(HRT_FIRST_BOUNCE_STORE_CACHE, 0); 

      float scale = scaleArray[passId]*imageSpaceDiscScale;
      int   step  = minPixelStep[passId];

      if(firstToPixel)
      {
        scale *= 0.25f;
        firstToPixel = false;
      } 

      sga_cudaMemcpyToSymbol("g_radianceDiffScale", &scale, sizeof(float));

      screenSpaceSet.m_currPassNumber = pass;
      screenSpaceSet.SetMinPixelStep(step);
      
      if(pass == 7 && !ssLowPrecition)
      {
        screenSpaceSet.AnalizeScreenSpaceRadiance2(camPos, pass, 1.0f/m_icPresets.icErrorSS[2]);
        if(m_debugOutput)
           std::cerr << "Quad tree pass enabled " << std::endl;
      }
      else
        screenSpaceSet.AnalizeScreenSpaceRadiance(camPos);

      screenSpaceSet.m_bBox = pOctree->GetBoundingBox();

      if(m_debugOutput)
        std::cerr << "Number of selected points(1): " << screenSpaceSet.size() << "\t step " << step << std::endl;
    
      if(screenSpaceSet.size() > 0) 
      {
        screenSpaceSet.ComputeRadiance(m_icPresets);

        float myTime1 = irradCacheTimer.getElapsed();
        screenSpaceSet.MiniMaximizeValidityRadiuses();
        InsertPointsInOctree(screenSpaceSet, pOctree);
        octreeConstructionTime += irradCacheTimer.getElapsed()  - myTime1;
      }
    }

    // world space stage
    //
    if(1)
    {
      hrtSetVariableI(HRT_FIRST_BOUNCE_STORE_CACHE, 1); 

      worldSpaceSet.m_maxPassNumber  = numPasses;
      worldSpaceSet.m_currPassNumber = pass;
      worldSpaceSet.SelectFewPointsWithLargeError(width*height/2, lastPass, m_lastRenderState.icBounce);

      if(m_debugOutput)
      {
        std::cerr << "Number of selected points(2): " << worldSpaceSet.size() <<"\t pass " << pass+1 << std::endl;
      }

      if(worldSpaceSet.pointsWithMaxError > 0)
        maxErrorPointsSequence.push_back(worldSpaceSet.pointsWithMaxError);

      if(worldSpaceSet.size() > 0) 
      {
        float maxBoxSize = pOctree->GetBoxSize();

        worldSpaceSet.ComputeRadiance(m_icPresets);

        float myTime1 = irradCacheTimer.getElapsed();
        worldSpaceSet.MiniMaximizeValidityRadiuses(0.005f*maxBoxSize, 0.1f*maxBoxSize);
        InsertPointsInOctree(worldSpaceSet, pOctree);
        octreeConstructionTime += irradCacheTimer.getElapsed() - myTime1;
      }
    }

    if(m_debugOutput)
      std::cerr << std::endl;

    if(m_debugICacheFileOutput)
    {
      std::ofstream fout2((std::string("spheres") + ToString(pass+1) + std::string(".txt")).c_str());
      for(int i=0;i<screenSpaceSet.size();i++)
      {
        fout2 << screenSpaceSet.GetData1()[i].pos << " ";
        fout2 << screenSpaceSet.GetData3()[i].validityRadius << std::endl;
      }
    }

    // estimate whether we can stop building irradiance cache
    //
    if(worldSpaceSet.size() < 1000 && pass > 10 && worldSpaceSet.pointsWithMaxError < 50) 
    {
      int lastElem = maxErrorPointsSequence.size()-1; 
      bool finish = true;
     
      if(lastElem-1 >=0 ) finish = finish && (maxErrorPointsSequence[lastElem-1] > maxErrorPointsSequence[lastElem]);
      if(lastElem-2 >=0 ) finish = finish && (maxErrorPointsSequence[lastElem-2] > maxErrorPointsSequence[lastElem-1]);

      if(finish)
        lastPass = true; // finish on last pass
    }

    // show result on the screen
    //
    EndDrawScene(); 
    m_updateImageCall(this, NULL, false);
    if(!(m_initFlags & GPU_RT_NOWINDOW))
    {
      glClear(GL_DEPTH_BUFFER_BIT);  
      DrawICRecords();
      glutSwapBuffers();
    }

    float progressAprox = ::fminf(float(pass+1)/float(numPasses), 1.0f);
    progressAprox = ::fmaxf(progressAprox, 0.1f);
    progressAprox = powf(progressAprox, 0.4f);
    m_updateProgressCall("Building Irradiance Cache", progressAprox);

    if(lastPass)
      break;

    if(ssLowPrecition && pass > numPasses/2+1)
      break;
  }

  //m_selectedIrradianceCachePoints = screenSpaceSet.m_screenHasPoint;

  if(m_debugOutput)
    std::cerr << "smoothing out indirrect illumination..." << std::endl;
  
  
  pOctree->SmoothOutIllum(2.0f);
  pOctree->ConvertLayoutToLinearArray();

  m_icAverageValidityRadius = 0.0f;
  for(int i=0;i<pOctree->GetPointNum();i++)
    m_icAverageValidityRadius += pOctree->GetPointsDataPart3()[i].validityRadius;
  m_icAverageValidityRadius /= float(pOctree->GetPointNum());

  hlmIrradianceCahceSetRecordsData(pOctree->GetPointsDataPart1(), pOctree->GetPointsDataPart2(), pOctree->GetPointsDataPart3(), pOctree->GetPointNum());
  hlmIrradianceCahceSetOctree(pOctree->GetRoot(), pOctree->GetNumNodes(), pOctree->GetOctreePointIndices(), pOctree->GetOctreeIndicesNum(), pOctree->GetBoxCenter(), pOctree->GetBoxSize());
  

  //float secondPass = irradCacheTimer.getElapsed() - startSecondPassTime;
  //std::cerr << "second pass time :  "       << secondPass << std::endl;
  float totalTime2 = irradCacheTimer.getElapsed() - timeStart;
  std::cerr << std::endl;
  std::cerr << "Total cache time (all):  " << totalTime2 << std::endl;
  std::cerr << "Octree time        (%):  " << 100.0f*(octreeConstructionTime/totalTime2) << std::endl;
  std::cerr << "IC records     (total):  " << pOctree->GetPointNum() << std::endl;

  if(m_debugOutput)
  {
    std::cerr << std::endl;
    std::cerr << "avg samples per record " << IrradianceCacheDataSet::avgSamplesPerPoint/float( pOctree->GetPointNum() ) << std::endl;
  }

  m_octreeAABB = pOctree->GetBoundingBox();

  pOctree->VerifyAndOutStatistic();
  delete pOctree; pOctree = NULL;

  hrtPopAllFlags();
  hrtSetVariableI(HRT_DISPLAY_IC_INTERMEDIATE, 0);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
////
void GPU_Path_Tracer::FreeIrradianceCache()
{
  hlmIrradianceCahceSetOctree(NULL,0,NULL,0,float3(0,0,0),0);
  hlmIrradianceCahceAssign(NULL,NULL,NULL,0);
}
