#ifndef RTCRANDOM
#define RTCRANDOM

#include "globals.h"


#if 0

typedef unsigned int uint32_t;
typedef unsigned long long int uint64_t;

typedef struct RandomGenT
{

  uint32_t x[5];

} RandomGen;


IDH_CALL uint32_t RandomGenBRandom(__private RandomGen* pGen)
{
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// !!! optimise this crap with 32 bit integer math. fuck!
  uint64_t sum = (uint64_t)2111111111UL * (uint64_t)pGen->x[3] +
                 (uint64_t)1492 * (uint64_t)(pGen->x[2]) +
                 (uint64_t)1776 * (uint64_t)(pGen->x[1]) +
                 (uint64_t)5115 * (uint64_t)(pGen->x[0]) +
                 (uint64_t)pGen->x[4];
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  pGen->x[3] = pGen->x[2];  pGen->x[2] = pGen->x[1];  pGen->x[1] = pGen->x[0];
  pGen->x[4] = (uint32_t)(sum >> 32);                  // Carry
  pGen->x[0] = (uint32_t)sum;                          // Low 32 bits of sum

  return pGen->x[0];
}


IDH_CALL RandomGen RandomGenInit(int a_seed)
{
  RandomGen gen;

  uint32_t s = a_seed;

  // make random numbers and put them into the buffer
  //
  for (int i = 0; i < 5; i++)
  {
    s = s * 29943829 - 1;
    gen.x[i] = s;
  }

  // randomize some more
  //
  for (int i = 0; i<19; i++)
    RandomGenBRandom(&gen);

  return gen;
}

IDH_CALL float rndFloat(__private RandomGen* pGen)
{
  return (float) (RandomGenBRandom(pGen) * (1. / (65536.*65536.)));
}

IDH_CALL float rndUniform(__private RandomGen* pGen, float a, float b)
{
  float t = rndFloat(pGen);
  return a + t*(b - a);
}

IDH_CALL float4 rndFloat4(__private RandomGen* pGen)
{
  float t1 = rndFloat(pGen);
  float t2 = rndFloat(pGen);
  float t3 = rndFloat(pGen);
  float t4 = rndFloat(pGen);

  return make_float4(t1, t2, t3, t4);
}


#elif 0

ID_CALL float noise(uint x)
{
  x = (x<<13) ^ x;
  //return (((x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / (1073741824.0f*2.0f) );
  return 0.5f + 0.5f*(1.0f - ((x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f);
}

typedef struct RandomGenT
{

  uint state;

} RandomGen;

ID_CALL RandomGen RandomGenInit(int a_seed)
{
  RandomGen gen;
  gen.state = __float_as_int(noise(a_seed));
  return gen;
}


ID_CALL float4 rndFloat4(__private RandomGen* gen)
{
  uint seed = gen->state;

  float4 random;
 
  random.x = noise(seed)                     + 0.0f;
  random.y = noise(__float_as_int(random.x)) + 0.0f;
  random.z = noise(__float_as_int(random.y)) + 0.0f;
  random.w = noise(__float_as_int(random.z)) + 0.0f;

  gen->state = __float_as_int(random.w);

  return random;
}



#else


typedef struct RandomGenT
{

  uint2 state;

} RandomGen;

IDH_CALL RandomGen RandomGenInit(int a_seed)
{
  RandomGen gen;

  gen.state.x = (a_seed * (a_seed * a_seed * 15731 + 74323) + 871483);
  gen.state.y = (a_seed * (a_seed * a_seed * 13734 + 37828) + 234234);

  uint x = (gen.state).x * 17 + (gen.state).y * 13123;
  (gen.state).x = (x << 13) ^ x;
  (gen.state).y ^= (x << 7);

  return gen;
}


IDH_CALL float4 rndFloat4(RandomGen* gen)
{
  uint x = (gen->state).x * 17 + (gen->state).y * 13123;
  (gen->state).x = (x << 13) ^ x;
  (gen->state).y ^= (x << 7);

  uint4 tmp;

  tmp.x = (x * (x * x * 15731 + 74323) + 871483);
  tmp.y = (x * (x * x * 13734 + 37828) + 234234);
  tmp.z = (x * (x * x * 11687 + 26461) + 137589);
  tmp.w = (x * (x * x * 15707 + 789221) + 1376312589);

  const float scale = (1.0f / 4294967296.0f);

  float4 res;

  res.x = ((float)(tmp.x))*scale;
  res.y = ((float)(tmp.y))*scale;
  res.z = ((float)(tmp.z))*scale;
  res.w = ((float)(tmp.w))*scale;

  return res;
}



#endif



IDH_CALL float4 rndUniform(RandomGen* gen, float a, float b)
{
  return make_float4(a, a, a, a) + (b - a)*rndFloat4(gen);
}


#endif

