#include "GPUOCLLayer.h"

void GPUOCLLayer::runKernelRememberXY()
{
  cl_kernel rememberXYKern = m_progs.screen.kernel("RememberXY");

  size_t global_item_size[2] = { m_width, m_height };
  size_t local_item_size[2] = { 16, 16 };

  CHECK_CL(clSetKernelArg(rememberXYKern, 0, sizeof(cl_mem), (void*)&m_screen.xyCoord));
  CHECK_CL(clSetKernelArg(rememberXYKern, 1, sizeof(cl_int), (void*)&m_width));
  CHECK_CL(clSetKernelArg(rememberXYKern, 2, sizeof(cl_int), (void*)&m_height));
  CHECK_CL(clSetKernelArg(rememberXYKern, 3, sizeof(cl_mem), (void*)&m_globals.cMortonTable));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, rememberXYKern, 2, NULL, global_item_size, local_item_size, 0, NULL, NULL));
}

void GPUOCLLayer::runKernelMakeEyeRaysBlocks(cl_mem a_rpos, cl_mem a_rdir, size_t a_size, cl_mem a_zblocks, int a_offset)
{
  cl_kernel makeRaysKern = m_progs.screen.kernel("MakeEyeRaysBlocks");
  size_t localWorkSize   = CMP_RESULTS_BLOCK_SIZE;
  int iSize              = int(a_size);

  CHECK_CL(clSetKernelArg(makeRaysKern, 0, sizeof(cl_mem), (void*)&m_screen.xyCoord));
  CHECK_CL(clSetKernelArg(makeRaysKern, 1, sizeof(cl_mem), (void*)&a_rpos));
  CHECK_CL(clSetKernelArg(makeRaysKern, 2, sizeof(cl_mem), (void*)&a_rdir));

  CHECK_CL(clSetKernelArg(makeRaysKern, 3, sizeof(cl_mem), (void*)&a_zblocks));
  CHECK_CL(clSetKernelArg(makeRaysKern, 4, sizeof(cl_int), (void*)&a_offset));

  CHECK_CL(clSetKernelArg(makeRaysKern, 5, sizeof(cl_mem), (void*)&m_rays.randGenState));
  CHECK_CL(clSetKernelArg(makeRaysKern, 6, sizeof(cl_mem), (void*)&m_globals.cVarsI));
  CHECK_CL(clSetKernelArg(makeRaysKern, 7, sizeof(cl_mem), (void*)&m_globals.cVarsF));

  CHECK_CL(clSetKernelArg(makeRaysKern, 8, sizeof(cl_int), (void*)&m_width));
  CHECK_CL(clSetKernelArg(makeRaysKern, 9, sizeof(cl_int), (void*)&m_height));
  CHECK_CL(clSetKernelArg(makeRaysKern,10, sizeof(cl_int), (void*)&m_flags));
  CHECK_CL(clSetKernelArg(makeRaysKern,11, sizeof(float4x4), (void*)&m_mProjInverse));
  CHECK_CL(clSetKernelArg(makeRaysKern,12, sizeof(float4x4), (void*)&m_mWorldViewInverse));
  CHECK_CL(clSetKernelArg(makeRaysKern,13, sizeof(cl_int), (void*)&iSize));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, makeRaysKern, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
}

void GPUOCLLayer::runKernelBlocksStoreColor(cl_mem a_inColor, size_t a_size, cl_mem a_zblocks, int a_offset)
{
  cl_kernel makeRaysKern = m_progs.screen.kernel("BlocksStoreColor");

  size_t localWorkSize = CMP_RESULTS_BLOCK_SIZE;
  int iSize = int(a_size);

  CHECK_CL(clSetKernelArg(makeRaysKern, 0, sizeof(cl_mem), (void*)&m_screen.xyCoord));
  CHECK_CL(clSetKernelArg(makeRaysKern, 1, sizeof(cl_mem), (void*)&m_screen.ptColorSummBuff));
  CHECK_CL(clSetKernelArg(makeRaysKern, 2, sizeof(cl_mem), (void*)&m_screen.ptColorSummSquareBuff));
  CHECK_CL(clSetKernelArg(makeRaysKern, 3, sizeof(cl_mem), (void*)&a_inColor));
  CHECK_CL(clSetKernelArg(makeRaysKern, 4, sizeof(cl_mem), (void*)&a_zblocks));
  CHECK_CL(clSetKernelArg(makeRaysKern, 5, sizeof(cl_int), (void*)&a_offset));
  CHECK_CL(clSetKernelArg(makeRaysKern, 6, sizeof(cl_int), (void*)&iSize));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, makeRaysKern, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
}


void GPUOCLLayer::runKernelTrace(cl_mem a_rpos, cl_mem a_rdir, size_t a_size)
{
  cl_kernel kernTrace = m_progs.trace.kernel("BVHTraversalKenrel");

  size_t localWorkSize = 256;
  int    isize = int(a_size);

  CHECK_CL(clSetKernelArg(kernTrace, 0, sizeof(cl_mem), (void*)&a_rpos));
  CHECK_CL(clSetKernelArg(kernTrace, 1, sizeof(cl_mem), (void*)&a_rdir));
  CHECK_CL(clSetKernelArg(kernTrace, 2, sizeof(cl_mem), (void*)&m_rays.hits));
  CHECK_CL(clSetKernelArg(kernTrace, 3, sizeof(cl_mem), (void*)&m_rays.rayFlags));
  CHECK_CL(clSetKernelArg(kernTrace, 4, sizeof(cl_int), (void*)&isize));
  CHECK_CL(clSetKernelArg(kernTrace, 5, sizeof(cl_mem), (void*)&m_scene.bvhBuff));
  CHECK_CL(clSetKernelArg(kernTrace, 6, sizeof(cl_mem), (void*)&m_scene.objListBuff));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernTrace, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));

}

void GPUOCLLayer::runKernelComputeHit(cl_mem a_rpos, cl_mem a_rdir, size_t a_size)
{
  cl_kernel kernHit = m_progs.trace.kernel("ComputeHit");

  size_t localWorkSize = 256;
  int    isize = int(a_size);

  CHECK_CL(clSetKernelArg(kernHit, 0, sizeof(cl_mem), (void*)&a_rpos));
  CHECK_CL(clSetKernelArg(kernHit, 1, sizeof(cl_mem), (void*)&a_rdir));
  CHECK_CL(clSetKernelArg(kernHit, 2, sizeof(cl_mem), (void*)&m_rays.hits));

  CHECK_CL(clSetKernelArg(kernHit, 3, sizeof(cl_mem), (void*)&m_scene.vertIndices));
  CHECK_CL(clSetKernelArg(kernHit, 4, sizeof(cl_mem), (void*)&m_scene.vertTexCoord));
  CHECK_CL(clSetKernelArg(kernHit, 5, sizeof(cl_mem), (void*)&m_scene.vertNormsCompressed));

  CHECK_CL(clSetKernelArg(kernHit, 6, sizeof(cl_mem), (void*)&m_rays.rayFlags));
  CHECK_CL(clSetKernelArg(kernHit, 7, sizeof(cl_mem), (void*)&m_rays.hitPosNorm));
  CHECK_CL(clSetKernelArg(kernHit, 8, sizeof(cl_mem), (void*)&m_rays.hitTexCoord));
  CHECK_CL(clSetKernelArg(kernHit, 9, sizeof(cl_mem), (void*)&m_rays.hitFlatNorm));
  CHECK_CL(clSetKernelArg(kernHit, 10, sizeof(cl_mem), (void*)&m_rays.hitMatId));
  CHECK_CL(clSetKernelArg(kernHit, 11, sizeof(cl_mem), (void*)&m_rays.hitTangent));

  CHECK_CL(clSetKernelArg(kernHit, 12, sizeof(cl_mem), (void*)&m_scene.objListBuff));

  CHECK_CL(clSetKernelArg(kernHit, 13, sizeof(cl_int), (void*)&isize));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernHit, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
}

void GPUOCLLayer::runKernelNextBounce(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, size_t a_size)
{
  cl_kernel kernX = m_progs.trace.kernel("NextBounce");

  size_t localWorkSize = 256;
  int    isize = int(a_size);

  CHECK_CL(clSetKernelArg(kernX, 0, sizeof(cl_mem), (void*)&a_rpos));
  CHECK_CL(clSetKernelArg(kernX, 1, sizeof(cl_mem), (void*)&a_rdir));
  CHECK_CL(clSetKernelArg(kernX, 2, sizeof(cl_mem), (void*)&m_rays.rayFlags));
  CHECK_CL(clSetKernelArg(kernX, 3, sizeof(cl_mem), (void*)&m_rays.randGenState));

  CHECK_CL(clSetKernelArg(kernX, 4, sizeof(cl_mem), (void*)&m_rays.hitPosNorm));
  CHECK_CL(clSetKernelArg(kernX, 5, sizeof(cl_mem), (void*)&m_rays.hitTexCoord));
  CHECK_CL(clSetKernelArg(kernX, 6, sizeof(cl_mem), (void*)&m_rays.hitFlatNorm));
  CHECK_CL(clSetKernelArg(kernX, 7, sizeof(cl_mem), (void*)&m_rays.hitMatId));
  CHECK_CL(clSetKernelArg(kernX, 8, sizeof(cl_mem), (void*)&m_rays.hitTangent));

  CHECK_CL(clSetKernelArg(kernX, 9,  sizeof(cl_mem), (void*)&a_outColor));
  CHECK_CL(clSetKernelArg(kernX, 10, sizeof(cl_mem), (void*)&m_rays.pathThoroughput)); // a_thoroughput
  CHECK_CL(clSetKernelArg(kernX, 11, sizeof(cl_mem), (void*)&m_rays.pathMisDataPrev)); // a_misDataPrev
  CHECK_CL(clSetKernelArg(kernX, 12, sizeof(cl_mem), (void*)&m_rays.pathShadeColor)); // in_shadeColor
  CHECK_CL(clSetKernelArg(kernX, 13, sizeof(cl_mem), (void*)&m_rays.pathIrradColor)); // in_irradColor

  CHECK_CL(clSetKernelArg(kernX, 14, sizeof(cl_mem), (void*)&m_scene.lightData));
  CHECK_CL(clSetKernelArg(kernX, 15, sizeof(cl_mem), (void*)&m_scene.materialData));    // in_plainData
  CHECK_CL(clSetKernelArg(kernX, 16, sizeof(cl_mem), (void*)&m_scene.materialOffsets)); // in_plainMatId
  CHECK_CL(clSetKernelArg(kernX, 17, sizeof(cl_int), (void*)&isize));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernX, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
}

void GPUOCLLayer::runKernelShadowTrace(cl_mem a_rpos, cl_mem a_rdir, cl_mem a_outColor, cl_mem a_outShadow, size_t a_size)
{
  cl_kernel kernX = m_progs.trace.kernel("ShadowTrace");

  size_t localWorkSize = 256;
  int    isize = int(a_size);

  CHECK_CL(clSetKernelArg(kernX, 0, sizeof(cl_mem), (void*)&a_rpos));
  CHECK_CL(clSetKernelArg(kernX, 1, sizeof(cl_mem), (void*)&a_rdir));
  CHECK_CL(clSetKernelArg(kernX, 2, sizeof(cl_mem), (void*)&m_rays.rayFlags));
  CHECK_CL(clSetKernelArg(kernX, 3, sizeof(cl_mem), (void*)&m_rays.randGenState));

  CHECK_CL(clSetKernelArg(kernX, 4, sizeof(cl_mem), (void*)&m_rays.hitPosNorm));
  CHECK_CL(clSetKernelArg(kernX, 5, sizeof(cl_mem), (void*)&m_rays.hitTexCoord));
  CHECK_CL(clSetKernelArg(kernX, 6, sizeof(cl_mem), (void*)&m_rays.hitFlatNorm));
  CHECK_CL(clSetKernelArg(kernX, 7, sizeof(cl_mem), (void*)&m_rays.hitMatId));
  CHECK_CL(clSetKernelArg(kernX, 8, sizeof(cl_mem), (void*)&m_rays.hitTangent));

  CHECK_CL(clSetKernelArg(kernX, 9,  sizeof(cl_mem), (void*)&a_outColor));
  CHECK_CL(clSetKernelArg(kernX, 10, sizeof(cl_mem), (void*)&a_outShadow));            // a_thoroughput
  CHECK_CL(clSetKernelArg(kernX, 11, sizeof(cl_mem), (void*)&m_rays.pathMisDataPrev)); // a_misDataPrev

  CHECK_CL(clSetKernelArg(kernX, 12, sizeof(cl_mem), (void*)&m_scene.lightData));       // in_plainData1
  CHECK_CL(clSetKernelArg(kernX, 13, sizeof(cl_mem), (void*)&m_scene.materialData));    // in_plainData2
  CHECK_CL(clSetKernelArg(kernX, 14, sizeof(cl_mem), (void*)&m_scene.materialOffsets)); // in_plainMatId
  CHECK_CL(clSetKernelArg(kernX, 15, sizeof(cl_mem), (void*)&m_scene.bvhBuff));
  CHECK_CL(clSetKernelArg(kernX, 16, sizeof(cl_mem), (void*)&m_scene.objListBuff));
  CHECK_CL(clSetKernelArg(kernX, 17, sizeof(cl_int), (void*)&isize));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernX, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));

}


void GPUOCLLayer::runKernelInitRandomGen(cl_mem a_buffer, size_t a_size, int a_seed)
{
  cl_kernel kernInitR = m_progs.trace.kernel("InitRandomGen");

  size_t localWorkSize = 256;
  int    isize = int(a_size);

  CHECK_CL(clSetKernelArg(kernInitR, 0, sizeof(cl_mem), (void*)&a_buffer));
  CHECK_CL(clSetKernelArg(kernInitR, 1, sizeof(cl_int), (void*)&a_seed));
  CHECK_CL(clSetKernelArg(kernInitR, 2, sizeof(cl_int), (void*)&isize));

  CHECK_CL(clEnqueueNDRangeKernel(m_globals.cmdQueue, kernInitR, 1, NULL, &a_size, &localWorkSize, 0, NULL, NULL));
}


