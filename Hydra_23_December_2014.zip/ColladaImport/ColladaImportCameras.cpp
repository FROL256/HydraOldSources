#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportCameras(ObjectDataList* pOut_list)
{
  ObjectDataList& plist = *pOut_list;
  plist.clear();


  TiXmlElement* cameras_lib = m_root->FirstChildElement("library_cameras");
  if(cameras_lib)
  {

    TiXmlNode* nextCameraInLib = 0;
    for(TiXmlNode* nextCameraInLib = cameras_lib->FirstChild("camera"); nextCameraInLib!=0; nextCameraInLib = cameras_lib->IterateChildren("camera", nextCameraInLib))
    {
      ObjectData cameraParams; 
      // <camera id="Camera-camera" name="Camera-camera"> 
      // name: cameraParams["COLLADA_name"] = nextCameraInLib->ToElement()->Attribute("name");
      //
      cameraParams["id"] = nextCameraInLib->ToElement()->Attribute("id");    
      plist[ cameraParams["id"] ] = cameraParams;

    }

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      string cameraId = p->second["id"];
      //string cam_url = "#" + p->second["id"];
      TiXmlElement* pCameraElement = FindElemByAttribute(cameras_lib, "camera", "id", cameraId);

      if(pCameraElement == 0)
        RUN_TIME_ERROR("Camera with id " + cameraId + "not found in COLLADA XML");

      TiXmlElement* pProjectionType = pCameraElement->FirstChildElement("optics")->FirstChildElement("technique_common")->FirstChildElement();

      p->second["projection_type"] = pProjectionType->ValueStr();

      for(TiXmlNode* pParam = pProjectionType->FirstChildElement(); pParam != 0; pParam = pProjectionType->IterateChildren(pParam))
      {
        TiXmlElement* pElem = pParam->ToElement();
        p->second[pElem->ValueStr()] = pElem->GetText();
      }

      string cut_camId;

      // cut tails
      //
      if(cameraId.substr(cameraId.size()-7,cameraId.size()) == "-camera")
        cut_camId = cameraId.substr(0,cameraId.size()-7);
      else if(cameraId.substr(cameraId.size()-4,cameraId.size()) == "-lib")
        cut_camId = cameraId.substr(0,cameraId.size()-4);
      else
        cut_camId = cameraId;
      //
      //RUN_TIME_ERROR("cameraId have incorrect tail");

      std::string camId = ""; 

      TiXmlElement* pScenes = m_root->FirstChildElement("library_visual_scenes");
      TiXmlNode* nextScene = 0;
      for(TiXmlNode* nextScene = pScenes->FirstChild("visual_scene"); nextScene!=0; nextScene = pScenes->IterateChildren("visual_scene", nextScene))
      {
        TiXmlElement* pCurrScene = nextScene->ToElement();
        for(TiXmlNode* nextNode = pCurrScene->FirstChild("node"); nextNode!=0; nextNode = pCurrScene->IterateChildren("node", nextNode))
        {
          
          camId = ""; 
          TiXmlElement* instCam = nextNode->FirstChildElement("instance_camera");
          if(instCam!=NULL)
          {
            camId = instCam->Attribute("url");
            if(camId[0] == '#')
              camId = camId.substr(1, camId.size());
          }

          if(camId != cut_camId)
            continue;

          std::string nodeName = nextNode->ToElement()->Attribute("id");
          if(nodeName.find(".Target") != std::string::npos) // this is a target node
            continue;

          Matrix4x4f mTransform      = GetTransformFromNode(nextNode);
          p->second["matrix"]        = MatrixToString(mTransform);
          p->second["translate"]     = GetText(nextNode,"translate");
          p->second["target_matrix"] = FindTargetTransform(pCurrScene, nextNode);
  
        }

      }

    }


    //cerr << endl;
    //for(p=plist.begin();p!=plist.end();++p)
    //{
    //  cerr << "Collada cameras: "<< p->second["id"] << endl;
    //  map<string,string>::const_iterator attr;
    //  for(attr = p->begin(); attr!=p->end(); ++attr)
    //    cerr << attr->first.c_str() << ": " << attr->second.c_str() << endl; 
    //  cerr << "------------------------------------" << endl;
    //}
  }

}



//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ReplaceCamerasWithProfile(ColladaParser::ObjectDataList& a_camList, TiXmlElement* lib)
{

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportCamerasFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_cameras, Camera* a_camera, const Matrix4x4f& a_mat, HashMapI& a_camIds, std::vector<Camera>& a_outCameras)
{
  ColladaParser::ObjectDataList::iterator p;

  a_outCameras.resize(0);
  for (p=a_cameras.begin(); p!=a_cameras.end(); ++p)
  {  
    Camera camera;

    if(p->second["matrix"] != "")
    {
      Matrix4x4f cameraPosTransform = StringTo<Matrix4x4f>(p->second["matrix"]);
      camera.pos = a_mat*cameraPosTransform*float4(0,0,0,1);

      if(p->second["target_matrix"] != "")
      {
        Matrix4x4f cameraTargetTransform = StringTo<Matrix4x4f>(p->second["target_matrix"]);
        float4 target = a_mat*cameraTargetTransform*float4(0,0,0,1);
        camera.LookAt(to_float3(camera.pos), to_float3(target));
      }
    }
    else if(p->second["position"] != "" && p->second["look_at"] != "")
    {
      //float3 posCamT  = GetFloat3(p, "position");
      //float3 posTargT = GetFloat3(p, "look_at");
      //camera.LookAt(posCamT, posTargT);
    }
    else
      camera.pos = float4(0,0,10,1);


    float fov    = GetFloat(p, "xfov");
    float aspect = GetFloat(p, "aspect_ratio"); 
    float zNear  = GetFloat(p, "znear"); 
    float zFar   = GetFloat(p, "zfar");

    if(zNear  == 0.0f) zNear  = 0.01f;
    if(zFar == 0.0f)   zFar   = 10000;
    if(fov == 0.0f)    fov    = 45.0f;
    if(aspect == 0.0f) aspect = 1.3f;

    camera.SetPerspectiveProjection(fov, aspect, zNear, zFar);


    a_outCameras.push_back(camera);
    a_camIds[p->first] = a_outCameras.size()-1;
  }

  if(a_outCameras.size() == 0)
    a_outCameras.push_back(*a_camera);
  else if(a_outCameras.size() > 0)
    (*a_camera) = a_outCameras[0];

}

#include "../HydraAppLib/Input.h"
extern Input input;

void ImportCamFromXMLNode(Camera* pCam, TiXmlElement* camElem)
{
  float fov           = GetFloatFromXMLNode(camElem, "fov");
  float nearClipPlane = GetFloatFromXMLNode(camElem, "nearClipPlane");
  float farClipPlane  = GetFloatFromXMLNode(camElem, "farClipPlane");

  float3 posCamT  = GetFloat3FromXMLNode(camElem, "position");
  float3 posTargT = GetFloat3FromXMLNode(camElem, "look_at");

  pCam->SetPerspectiveProjection(fov, pCam->GetAspect(), nearClipPlane, farClipPlane);
  pCam->LookAt(posCamT, posTargT);

  input.cam_rot = pCam->GetRotation();
}

