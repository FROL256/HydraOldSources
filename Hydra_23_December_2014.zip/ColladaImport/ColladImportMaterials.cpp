#include "ColladaImport.h"
#include "StrToken.h"
#include <algorithm>
#include <string>
#include <direct.h>

//#include "../HydraServer/ImportStructs.h"
float GetCosPowerFromMaxShiness(float glosiness)
{
  float cMin = 1.0f;
  float cMax = 100000.0f;

  if(glosiness >= 0.99f)
    return 1000000.0f;

  return powf(cMax, glosiness);
}


using std::cout;
using std::cerr;
using std::endl;
using std::string;
using STR_CNV::StringTo;
using STR_CNV::TransformToLowerCase;
using STR_CNV::ToLowerCase;


void ColladaParser::ParseXmlNodeRec(ColladaParser::ObjectData& params, TiXmlElement* pNode, const std::string& a_prefix)
{
  for(TiXmlNode* p = pNode->FirstChild(); p != NULL; p = pNode->IterateChildren(p))
  {
    TiXmlElement* elem = p->ToElement();
    if(elem != NULL)
    {
      std::string newPrefix = a_prefix + "_" + p->ValueStr();
      const char* pText = elem->GetText();

      if(pText!=NULL)
        params[newPrefix] = pText;
      else
        ParseXmlNodeRec(params, elem, newPrefix);
    }
  }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseHydraMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel)
{  
  for(TiXmlNode* pParam = pMaterialModel->FirstChild(); pParam != 0; pParam = pMaterialModel->IterateChildren(pParam))
  {
    TiXmlElement* pElem = pParam->ToElement();
    if(pElem != NULL)
    {
      std::string firstPart = pElem->ValueStr();
      ParseXmlNodeRec(params, pElem, firstPart);
    }
  }

  params["shading_model"] = "hydra";
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseStandartMaterial(ColladaParser::ObjectData& params, TiXmlElement* pMaterialModel, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData)
{
  for(TiXmlNode* pParam = pMaterialModel->FirstChild(); pParam != 0; pParam = pMaterialModel->IterateChildren(pParam))
  {
    TiXmlElement* pElem = pParam->ToElement();
    std::string paramName = pElem->ValueStr();

    // parsing for custom tag attributes
    //
    if(pElem->ValueStr() == "transparent")
    {
      if(pElem->Attribute("opaque") != NULL)
        params["opaque_type"] = pElem->Attribute("opaque");
      else
        params["opaque_type"] = "A_ONE";
    }

    // ��� �������� ����������� ��������
    //
    if(pElem->FirstChildElement()->ValueStr() == "texture")
    {
      //# virtual exporterType(!)
      TiXmlElement* pTextureElem = pMaterialModel->FirstChildElement(paramName)->FirstChildElement("texture");

      std::string colladaTexName = pTextureElem->Attribute("texture");
      std::string texturePath    = FindTexturePath(texturesData, "id", colladaTexName, "init_from");

      if(texturePath == "")
      {
        if(colladaTexName.size() > 8 && colladaTexName.substr(colladaTexName.size()-8, colladaTexName.size()) == "-sampler")
          colladaTexName = colladaTexName.substr(0, colladaTexName.size()-8);
        texturePath = FindTexturePath(texturesData, "id", colladaTexName, "init_from");
      }

      if(texturePath == "")
        std::cerr << "'init_from' param for texture with name " << colladaTexName << " was not found in textures param list" <<std::endl;

      params[paramName] = GetText(pMaterialModel, paramName.c_str(), "color");
      params[paramName+"_texture"]      = texturePath;
      params[paramName+"_texcoord_set"] = pTextureElem->Attribute("texcoord");
    }
    else
      params[paramName] = pElem->FirstChildElement()->GetText();
  }

  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if(pMaterialElement->FirstChildElement("profile_COMMON")->FirstChildElement("newparam") != 0)
  {
    TiXmlElement* profCommon = pMaterialElement->FirstChildElement("profile_COMMON");

    for(TiXmlNode* nextNewParam = profCommon->FirstChild("newparam"); nextNewParam != NULL; nextNewParam = profCommon->IterateChildren("newparam", nextNewParam))
    {

      TiXmlElement* pSurface = nextNewParam->FirstChildElement("surface");
      TiXmlElement* pNewParamElem = nextNewParam->ToElement();

      if(pSurface != 0)
      {
        params["surface_type"] = pSurface->Attribute("type");
        params["newparam_sur_id"] = pNewParamElem->Attribute("sid");

        for(TiXmlNode* pParam = pSurface->FirstChildElement(); pParam != 0; pParam = pSurface->IterateChildren(pParam))
        {
          TiXmlElement* pElem = pParam->ToElement();

          if(pElem->ValueStr() != "format_hint")
          {
            params[pElem->ValueStr()] = pElem->GetText();
          }

        }
      }

      TiXmlElement* pSampler2D = nextNewParam->FirstChildElement("sampler2D");

      if(pSampler2D != 0)
      {
        params["newparam_samp_id"] = pNewParamElem->Attribute("sid");
        for(TiXmlNode* pParam = pSampler2D->FirstChildElement(); pParam != 0; pParam = pSampler2D->IterateChildren(pParam))
        {
          TiXmlElement* pElem = pParam->ToElement();
          params[pElem->ValueStr()] = pElem->GetText();
        }
      }

    } // for

  }

  //TiXmlElement* extraData = pMaterialElement->FirstChildElement("profile_COMMON");


}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ParseExtraMaterialData(ColladaParser::ObjectData& params, TiXmlElement* pExtraMaterial, TiXmlElement* pMaterialElement, const ObjectDataList& texturesData)
{
  TiXmlElement* pTechnique = pExtraMaterial->FirstChildElement("technique");
  if(pTechnique != NULL)
  {
    TiXmlElement* pBumpMap = pTechnique->FirstChildElement("bump");
    if(pBumpMap != NULL) //&& pBumpMap->Attribute("bumptype") == "HEIGHTFIELD"
    {
       TiXmlElement* pTexture = pBumpMap->FirstChildElement("texture");
       if(pTexture != NULL && pTexture->Attribute("texture") != NULL)
       {
         std::string colladaTexName = pTexture->Attribute("texture");
         std::string texturePath    = FindTexturePath(texturesData, "id", colladaTexName, "init_from");

         if(texturePath == "")
         {
           if(colladaTexName.size() > 8 && colladaTexName.substr(colladaTexName.size()-8, colladaTexName.size()) == "-sampler")
             colladaTexName = colladaTexName.substr(0, colladaTexName.size()-8);
           texturePath = FindTexturePath(texturesData, "id", colladaTexName, "init_from");
         }

         params["displacement_height_texture"] = texturePath;
         params["displacement_height"] = "0";
       }
    }
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
std::string ColladaParser::CutOffColladaEffectsShit(const std::string& mat_name)
{
  int posZero = 0;

  if(mat_name.size() > 0 && mat_name[0] == '#')
    posZero = 1;

  if(mat_name.size() > 7 && mat_name.substr(mat_name.size()-7,mat_name.size()) == "-effect")
    return mat_name.substr(posZero, mat_name.size() - 8);
  else if(mat_name.size() > 3 && mat_name.substr(mat_name.size()-3, mat_name.size()) == "-fx")
    return mat_name.substr(posZero, mat_name.size() - 4);
  else
    return mat_name.substr(posZero, mat_name.size());
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
TiXmlElement* ColladaParser::FindNodeByName(TiXmlElement* pEffectsLib, const std::string& materialName)
{
  TiXmlElement* pMaterialElement = FindElemByAttribute(pEffectsLib, "effect", "name", materialName);

  if(pMaterialElement == NULL)
    pMaterialElement = FindElemByAttribute(pEffectsLib, "effect", "id", materialName);

  if(pMaterialElement == NULL)
    pMaterialElement = FindElemByAttribute(pEffectsLib, "effect", "id", materialName+"-effect");

  return pMaterialElement;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ColladaParser::ImportMaterials(ObjectDataList* pOut_list)
{
  ColladaParser::ObjectDataList texturesData;
  ImportTextures(&texturesData);

  ObjectDataList& plist = *pOut_list;
  plist.clear();

  TiXmlElement* materials_lib = m_root->FirstChildElement("library_materials");
  if(materials_lib)
  {
    TiXmlNode* nextMaterialInLib = NULL;

    // ������� ��� ����� ���������� �� ���� library_materials
    //
    for(TiXmlNode* nextMaterialInLib = materials_lib->FirstChild("material"); nextMaterialInLib!=0; nextMaterialInLib = materials_lib->IterateChildren("material", nextMaterialInLib))
    {
      ColladaParser::ObjectData materialParams;

      string urlName = nextMaterialInLib->FirstChild("instance_effect")->ToElement()->Attribute("url");
      string matName = CutOffColladaEffectsShit(urlName);

      materialParams["name"] = matName;
      plist[matName] = materialParams;
    }

    // and now import other material parameters from library_effects
    //
    TiXmlElement* pEffectsLib = m_root->FirstChildElement("library_effects");
    if(!pEffectsLib)
      throw std::runtime_error(" 'library_effects' not found in XML");

    ObjectDataList::iterator p;
    for(p=plist.begin();p!=plist.end();++p)
    {
      ColladaParser::ObjectData& params = p->second;
      string materialName = params["name"];

      //# virtual exporterType(!)
      TiXmlElement* pMaterialElement = FindNodeByName(pEffectsLib, materialName);
      if(pMaterialElement == NULL)
        RUN_TIME_ERROR("Material with name " + materialName + " not found in COLLADA XML");


      TiXmlElement* pTechnique = pMaterialElement->FirstChildElement("profile_COMMON")->FirstChildElement("technique");
      TiXmlElement* pMaterialModel = pTechnique->FirstChildElement();

      params["shading_model"] = pMaterialModel->ValueStr();

      if(params["shading_model"] == "hydra")
        ParseHydraMaterial(params, pMaterialModel);
      else
        ParseStandartMaterial(params, pMaterialModel, pMaterialElement, texturesData);

      TiXmlElement* pExtraMaterial = pTechnique->FirstChildElement("extra");

      if(pExtraMaterial!= NULL)
        ParseExtraMaterialData(params, pExtraMaterial, pMaterialElement, texturesData);

    }

  }

  // add default material for objects that hve no materials
  //
  ColladaParser::ObjectData defaultMat;

  defaultMat["shading_model"] = "phong";
  defaultMat["ambient"]       = "0.0 0.0 0.0";
  defaultMat["diffuse"]       = "0.5 0.5 0.5";
  defaultMat["specular"]      = "0.0 0.0 0.0";
  defaultMat["shininess"]     = "80.0";
  defaultMat["name"]          = "hydra_default_material";

  plist["hydra_default_material"] = defaultMat;


  // remember materials for the case
  //
  m_materialsRemembered = plist;

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
/*
void ReplaceMaterialsWithProfile(ColladaParser::ObjectDataList& a_materialsList, TiXmlElement* materials_lib)
{
  if(materials_lib == NULL)
    return;

  for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
  {
    TiXmlElement* matElem = nextMat->ToElement();
    std::string name = "";

    if(matElem->Attribute("id") != NULL)
      name = matElem->Attribute("id");
    else if(matElem->Attribute("name") != NULL)
      name = matElem->Attribute("name");

    if(a_materialsList.find(name) == a_materialsList.end())
    {
      fprintf(stderr, "Warning: model don't have material called %s \n", name.c_str());
      continue;
    }

    ColladaParser::ObjectData params;

    TiXmlElement* pMaterialModel = matElem->FirstChildElement();
    if(ToLowerCase(pMaterialModel->ValueStr()) == "hydra")
    {
      ColladaParser::ParseHydraMaterial(params, pMaterialModel);
      params["name"] = name; // IMPORTANT!!!

      a_materialsList[name] = params;
    }
    else
      fprintf(stderr, "Warning: Hydra profile has unknown material model %s \n", pMaterialModel->ValueStr().c_str());

  }

  // now make global fixes
  //
  IHydraMaterialImportProfile* pProfileFix = new ColladaMaterialImportProfile(materials_lib);

  ColladaParser::ObjectDataList::iterator p;

  for(p = a_materialsList.begin(); p!= a_materialsList.end(); ++p)
    pProfileFix->Transform(p->second);

  delete pProfileFix;

}*/

//////////////////////////////////////////////////////////////////////////////////////////////////////
////
IMaterialImporter* CreateMaterialImporter(TiXmlNode* a_xmlRoot)
{
  std::string importerName = GetText(a_xmlRoot, "asset", "contributor", "authoring_tool");

  if(importerName != "")
  {
    if(importerName.find("OpenCOLLADA") != std::string::npos)
      return new OpenColladaMaterialImporter;
  }

  return new IMaterialImporter;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
float3 OpenColladaMaterialImporter::GetTransparency(ColladaParser::ObjectData& params)
{
  float transparent_k = 0;
  if(params["transparency"]!="")
    transparent_k = 1.0f-StringTo<float>(params["transparency"]);

  float3 refr_color(1,1,1);
  if(params["transparent"]!="")
    refr_color = StringTo<float3>(params["transparent"]);

  return refr_color*transparent_k;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
RAYTR::HydraMaterial StdColladaMaterialFromStringMap(ColladaParser::ObjectDataList::iterator p, IGraphicsEngine* pRender,
                                                     ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter)
{
  ColladaParser::ObjectData& params = p->second;

  std::string name = p->second["name"];

  HydraMaterial material;

  if(params["shading_model"]=="phong" || params["shading_model"]=="lambert")
  {
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_PHONG;
    if(params["shininess"]!="")
      material.specular.cosPower = StringTo<float>(params["shininess"]);
  }
  else if (params["shading_model"]=="blinn")
  {
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_BLINN;
    if(params["shininess"]!="")
      material.specular.cosPower = StringTo<float>(params["shininess"]);
  }
  else if (params["shading_model"]=="cook-torrance")
  {
    //material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_COOK_TORRANCE;
    //material.specular.glosiness = 0.0f;
  }
  else
    material.specular.brdf_id = RAYTR::HydraMaterial::BRDF_PHONG;


  material.ambient.color = float3(0,0,0); //StringTo<float3>(params["ambient"]);

  float3 emission = GetFloat3(p, "emission");
  if(length(emission) > 0.01f)
  {
    material.flags |= RAYTR::HydraMaterial::THIS_IS_LIGHT;
    material.ambient.color = emission;
    material.ambient.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"emission_texture"), pRender);
    material.ambient.light_multiplyer = GetFloat(p, "emission_magnitude");
  }

  if(params["vray"] == "1.0")
  {
    float3 diffuse = GetFloat3(p, "diffuse"); //StringTo<float3>(params["diffuse"]);
    float3 reflect = GetFloat3(p, "specular"); //StringTo<float3>(params["specular"]);
    float3 one(1,1,1);

    material.diffuse.color.x = diffuse.x*(one.x-reflect.x);
    material.diffuse.color.y = diffuse.y*(one.y-reflect.y);
    material.diffuse.color.z = diffuse.z*(one.z-reflect.z);
    material.reflection.color = reflect;
  }
  else
  {

    material.diffuse.color = GetFloat3(p, "diffuse");

    float3 reflColor(1,1,1);
    if(params["reflective"]!="")
      reflColor = StringTo<float3>(params["reflective"]);

    float k_reflect  = GetFloat(p,"reflectivity");
    material.reflection.color = k_reflect*reflColor;
  }

  EmptyDataConverter* pTransparencyConverter = new AlphaFromRedChannel();

  material.ambient.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"ambient_texture"), pRender);
  material.diffuse.color_texId      = pTexImporter->AddTextureIfExists(GetString(p,"diffuse_texture"), pRender);
  material.specular.color_texId     = pTexImporter->AddTextureIfExists(GetString(p,"specular_texture"), pRender);
  material.reflection.color_texId   = pTexImporter->AddTextureIfExists(GetString(p,"reflective_texture"), pRender);
  material.transparency.color_texId = pTexImporter->AddTextureIfExists(GetString(p,"transparent_texture"), pRender, pTransparencyConverter);

  //if(material.transparency.color_texId != INVALID_TEXTURE)
    //material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  // VRay parameters
  if(params["glossiness"]!="")
    material.reflection.cosPower = GetCosPowerFromMaxShiness(StringTo<float>(params["glossiness"]));
  else
    material.reflection.cosPower = 1000000.0f;

  if(params["IOR"]!="")
    material.transparency.IOR = StringTo<float>(params["IOR"]);

  float3 transparent  = GetFloat3(p, "transparent");
  float  transparency = GetFloat(p, "transparency");
  std::string opaque_type = GetString(p, "opaque_type");

  float3 transparecyValue = transparent*transparency;
  if(opaque_type == "RGB_ZERO")
    transparecyValue = transparent*transparency;
  else if(opaque_type == "A_ONE")
    transparecyValue = (float3(1,1,1) - transparent)*transparency;

  material.transparency.color     = transparecyValue;
  material.transparency.fogColor  = material.transparency.color;
  material.transparency.exitColor = material.transparency.color;
  material.transparency.fogMultiplyer = 0.1f;
  material.transparency.IOR = 1.5f;

  if(length(material.transparency.color) > 0.001f)
    material.flags |= HydraMaterial::TRANSPARENCY_THIN_SURFACE;

  // displacement
  //

  std::string pathToHeightTex = GetString(p, "displacement_height_texture");
  std::string pathToNormalTex = GetString(p, "displacement_normals_texture");

  material.displacement.height        = GetFloat(p, "displacement_height");
  material.displacement.height_texId  = pTexImporter->AddTextureIfExists(pathToHeightTex, pRender, NULL, false);
  material.displacement.normals_texId = pTexImporter->AddTextureIfExists(pathToNormalTex, pRender, NULL);

  if(material.displacement.normals_texId == INVALID_TEXTURE && material.displacement.height_texId != INVALID_TEXTURE)
  {
    float bumpAmt = 0.5f; //GetFloat(p, "displacement_bump_amount"); 
    material.displacement.normals_texId = pTexImporter->GetNormalMapFromFisplacement(material.displacement.height_texId, pRender, pathToHeightTex, bumpAmt, 1.0f, 1.5f, true);
  }

  delete pTransparencyConverter; pTransparencyConverter = NULL;

  return material;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
////


//////////////////////////////////////////////////////////////////////////////////////////////////////
////
void ImportHydraMaterialsFromCollada(IGraphicsEngine* pRender, ColladaParser::ObjectDataList a_materials, GeometryStorage& a_geomStorage,
                                     ITextureImporter* pTexImporter, IMaterialImporter* pMatImporter, HashMapI& a_matIds)
{
  ColladaParser::ObjectDataList::iterator p;
  int mat_size = int(a_materials.size());

  for (p=a_materials.begin(); p!=a_materials.end(); ++p)
  {
    ColladaParser::ObjectData& params = p->second;

    RAYTR::HydraMaterial material;

    if(params["shading_model"]=="hydra")
      material = HydraMaterialFromStringMap(p, pRender, pTexImporter, NULL);
    else
      material = StdColladaMaterialFromStringMap(p, pRender, pTexImporter, pMatImporter);

    int ind = pRender->AddMaterial(material);

    string mat_name = ColladaParser::CutOffColladaEffectsShit(params["name"]);
    a_geomStorage.mat_indices[mat_name] = ind;
    a_matIds[mat_name] = ind;
  }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
////

void ReplaceMaterialsWithAliases(IGraphicsEngine* pRender, ITextureImporter* pTexImporter, ColladaParser::ObjectDataList& materialList, TiXmlElement* a_materialsGroups)
{
  if(a_materialsGroups == NULL)
    return;

  for(TiXmlNode* pGroup = a_materialsGroups->FirstChild("group"); pGroup != NULL; pGroup = a_materialsGroups->IterateChildren("group", pGroup))
  {
    TiXmlElement* pMaterialModel = pGroup->FirstChildElement("material");
    if(pMaterialModel == NULL)
      continue;

    // remember all bound materials
    //
    HashMapI boundMaterials;
    for(TiXmlNode* pMaterialBinding = pGroup->FirstChild("bind_material"); pMaterialBinding != NULL; pMaterialBinding = pGroup->IterateChildren("bind_material", pMaterialBinding))
    {
      std::string name = pMaterialBinding->ToElement()->GetText();
      if(name != "")
        boundMaterials[name] = 1;
    }

    // get our replacement data
    //
    ColladaParser::ObjectData paramsR;
    ColladaParser::ParseHydraMaterial(paramsR, pMaterialModel->FirstChildElement());

    // replace
    //
    for(ColladaParser::ObjectDataList::iterator p=materialList.begin(); p!=materialList.end(); ++p)
    {
      ColladaParser::ObjectData& params = p->second;
      if(boundMaterials.find(p->first) == boundMaterials.end())
        continue;

      for(ColladaParser::ObjectData::iterator f = paramsR.begin(); f != paramsR.end(); ++f)
      {
        ColladaParser::ObjectData::iterator q = params.find(f->first);

        if(q != params.end())
          q->second = f->second;
        else
          params[f->first] = f->second;

      }
    }

  }

}


void MakeHydraMaterialMapFromXMLNode(TiXmlElement* materials_lib, IGraphicsEngine* pRender, HydraMaterialMap* pResult, HashMapImportParams* pHashMapImportParams, HashMapI* pMaxIds, const std::string& inColladaFile)
{
  if(materials_lib == NULL)
    return;

  ITextureImporter* pTexImporter  = new ColladaTextureImporter;
  
  //std::cerr << " inColladaFile =  " << inColladaFile.c_str() << std::endl;

  pTexImporter->SetCurrentPathToMainFile(inColladaFile);
  pTexImporter->SetTexPathStorage(&(LastImportedScene()->texpaths)); // all texture paths will be saved here
  
  ColladaParser::ObjectDataList allData;

  for(TiXmlNode* nextMat = materials_lib->FirstChild("material"); nextMat!=0; nextMat = materials_lib->IterateChildren("material", nextMat))
  {
    TiXmlElement* matElem = nextMat->ToElement();
    std::string name =  "";

    if(matElem->Attribute("id") != NULL)
      name = matElem->Attribute("id");
    else if(matElem->Attribute("name") != NULL)
      name = matElem->Attribute("name");

    std::string maxId = "-1";
    if(matElem->Attribute("maxid") != NULL)
      maxId = matElem->Attribute("maxid");

    ColladaParser::ObjectData params;

    TiXmlElement* pMaterialModel = matElem->FirstChildElement();
    if(STR_CNV::ToLowerCase(pMaterialModel->ValueStr()) == "hydra")
    {
      ColladaParser::ParseHydraMaterial(params, pMaterialModel);
      params["name"]  = name; // IMPORTANT!!!
      params["maxid"] = maxId;

      allData   [name] = params;
      (*pMaxIds)[name] = atoi(maxId.c_str());
    }
    else
      fprintf(stderr, "Warning: Hydra profile has unknown material model %s \n", pMaterialModel->ValueStr().c_str());

  }

  // now make global fixes
  //
  IHydraMaterialImportProfile* pProfileFix = new ColladaMaterialImportProfile(materials_lib);

  ColladaParser::ObjectDataList::iterator p;

  for(p = allData.begin(); p!= allData.end(); ++p)
    pProfileFix->Transform(p->second);

  delete pProfileFix;

  // and now transform all this shit to HydraMaterial
  //
  HydraMaterialMap& a_map = (*pResult);

  for(p = allData.begin(); p!= allData.end(); ++p)
    a_map[p->first] = HydraMaterialFromStringMap(p, pRender, pTexImporter, pHashMapImportParams);


  pTexImporter->ResetCurrentPath();
  delete pTexImporter;
}


