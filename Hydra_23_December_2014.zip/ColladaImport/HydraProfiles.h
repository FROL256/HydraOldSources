#pragma once

#include <iostream>
#include <map>
#include <string>

#define TIXML_USE_STL
#include "../tinyxml/tinyxml.h"






