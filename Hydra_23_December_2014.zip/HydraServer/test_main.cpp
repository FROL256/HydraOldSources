#include "../HydraAppLib/main.h"

using namespace std;

//extern int WinWidth;
//extern int WinHeight;
extern Input input;  

int main(int argc, char** argv)
{
  HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
  SetConsoleTextAttribute(h, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
  
  if(argc > 1)
  {
    input.inColladaFile = argv[1];
    
    if(argc>2)
      input.inColladaProfile = argv[2];

    if(argc>3)
      input.ReadXMLFromFile(argv[3]);

    for(int i=0;i<argc;i++)
      std::cout << "agrv[" << i << "] = " << argv[i] << std::endl;
  }
  
  //input.ReadXMLFromSharedMemory();
}


