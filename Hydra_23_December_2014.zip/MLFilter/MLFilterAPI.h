#pragma once

#include <stdio.h>

#ifdef NODLLFORFILTER
  #define ML_DLL_API 
#else
  #ifdef ML_DLL_EXPORTS
	  #define ML_DLL_API __declspec(dllexport)
  #else
	  #define ML_DLL_API __declspec(dllimport)
  #endif
#endif

struct ML_DLL_API MLSettings
{
  MLSettings() : filterSize(5), filterPrimary(false), sigma(2.0f) {}

  int   filterSize;
  bool  filterPrimary;
  float sigma;
};


struct ML_DLL_API MLAllData
{
  MLAllData(): w(0), h(0), normals(NULL), txcolor(NULL), primary(NULL), secondary(NULL), out_res(NULL) {}

  const void* normals;
  const void* txcolor;

  const void* primary;
  const void* secondary;

  void*       out_res;

  int w,h;
};

class ML_DLL_API IMLFilter
{
public:

  IMLFilter(){}
  virtual ~IMLFilter(){}

  virtual void SetPresets(MLSettings a_presets) { m_settings = a_presets; }
  virtual void SetAllInputData(MLAllData a_data) { }
   
  virtual void FilterIrradiance() = 0;

protected:

  MLSettings m_settings;
};

ML_DLL_API IMLFilter* CreateFilter(const char* a_filterClassname);
ML_DLL_API void DeleteFilter(IMLFilter* a_filter);

