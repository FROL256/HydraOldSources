#include "MLFilter.h"
#include "LiteMath.h"

IMLFilter* CreateFilter(const char* a_filterClassname) { return new SimpleMLFilter; }
void DeleteFilter(IMLFilter* a_filter) { delete a_filter; }


void SimpleMLFilter::SetAllInputData(MLAllData a_data)
{
  m_allData.w = a_data.w;
  m_allData.h = a_data.h;

  m_allData.primary   = (const float4*)a_data.primary;
  m_allData.secondary = (const float4*)a_data.secondary;
  m_allData.txcolor   = (const float4*)a_data.txcolor;
  m_allData.normals   = (const float4*)a_data.normals;
  m_allData.out_res   = (float4*)      a_data.out_res;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
float3 tex2D(const float4* data, int x, int y, int w, int h)
{
  if(data == NULL)
    return float3(0,0,0);

  if(x < 0) x = 0;
  if(y < 0) y = 0;

  if(x >= w) x = w-1;
  if(y >= h) y = h-1;

  return to_float3(data[y*w+x]);
}

float4 tex2Df4(const float4* data, int x, int y, int w, int h)
{
  if(x < 0) x = 0;
  if(y < 0) y = 0;

  if(x >= w) x = w-1;
  if(y >= h) y = h-1;

  return data[y*w+x];
}

float tex2D(const float* data, int x, int y, int w, int h)
{
  if(x < 0) x = 0;
  if(y < 0) y = 0;

  if(x >= w) x = w-1;
  if(y >= h) y = h-1;

  return data[y*w+x];
}


float3 sample2D(const float4* data, float x, float y, int w, int h)
{
  if(x < 0) x = 0;
  if(y < 0) y = 0;

  if(x >= w) x = w-1;
  if(y >= h) y = h-1;

  float u = x;
  float v = y;

  float4 color(0,0,0,0);

  // simple texture fetch
 
  int ui11 = int(u+0.5f);
  int vi11 = int(v+0.5f);

  ui11 = (ui11 >= w) ? ui11-1 : ui11;
  vi11 = (vi11 >= h) ? vi11-1 : vi11;

  float4 tmp;

  int ui = int(u);
  int vi = int(v);

  float du = u - float(ui);
  float dv = v - float(vi);

  int ui1 = (ui+1 >= w) ? ui : ui+1;
  int vi1 = (vi+1 >= h) ? vi : vi+1;

  tmp = data[vi*int(w) + ui]; 
  color += float4(float(tmp.x), float(tmp.y), float(tmp.z), float(tmp.w))*(1.0f-du)*(1.0f-dv);

  tmp = data[vi*int(w) + ui1]; 
  color += float4(float(tmp.x), float(tmp.y), float(tmp.z), float(tmp.w))*(du)*(1.0f-dv);

  tmp = data[vi1*int(w) + ui1]; 
  color += float4(float(tmp.x), float(tmp.y), float(tmp.z), float(tmp.w))*(du)*(dv);

  tmp = data[vi1*int(w) + ui]; 
  color += float4(float(tmp.x), float(tmp.y), float(tmp.z), float(tmp.w))*(1.0f-du)*(dv);

  return to_float3(color);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////


float SimpleMLFilter::tex2DDepth(int x, int y)
{  
  int w = m_allData.w;
  int h = m_allData.h;

  if(x < 0) x = 0;
  if(y < 0) y = 0;

  if(x >= w) x = w-1;
  if(y >= h) y = h-1;

  return m_allData.normals[w*y+x].w;
}

float SimpleMLFilter::pixelSimilarity(float4 data1, float4 data2)
{
  const float MANXDIFF = 0.1;
  const float MADXDIFF = 0.02f*(m_depthMax-m_depthMin);

  float3 n1 = to_float3(data1);
  float3 n2 = to_float3(data2);

  float dist = length(n1-n2);
  if(dist >= MANXDIFF)
    return 0.0f;

  float d1 = data1.w;
  float d2 = data2.w;

  if(abs(d1-d2) >= MADXDIFF)
    return 0.0f;

  float normalDiff = sqrtf(1.0f - (dist/MANXDIFF));
  float depthDiff  = sqrtf(1.0f - abs(d1-d2)/MADXDIFF);

  return normalDiff*depthDiff;
}

SimpleMLFilter::GaussResult SimpleMLFilter::gaussFilterColor(int bSize, int x, int y, const float4* colors, float4 sampleData)
{
  float3 cPixel = float3(0,0,0); 

  int w = m_allData.w;
  int h = m_allData.h;

  // gaussian filter with simple threshold
  //
  int counterMatch = 0;
  {
    float summW = 0.0f;

    int y2 = 0;
    for(int y1=y-bSize;y1<=y+bSize;y1++)
    {
      int x2 = 0;
      for(int x1=x-bSize;x1<=x+bSize;x1++)
      {
        float3 c1 = tex2D(colors,x1,y1,w,h);
        float4 n1 = tex2Df4(m_allData.normals,x1,y1,w,h);

        float match = pixelSimilarity(sampleData,n1);

        if(match > 0.0f)
        {
          int aSize = 2*bSize+1;
          float w   = m_gaussKernel[y2*aSize + x2]*match;
          
          cPixel    += c1*w;
          summW     += w;

          counterMatch++;
        }

        x2++;
      }

      y2++;
    }

    if(summW <= 1e-5f)
      cPixel = tex2D(colors,x,y,w,h);
    else
      cPixel = cPixel*(1.0f/float(summW));

  }
  // \\

  GaussResult res;
  res.pixelColor = cPixel;
  res.matchTimes = counterMatch;
  res.isBoundary = (counterMatch < 3);
  res.isStrongBoundary = false;
  return res;
}

// simple bilateral (?) gauss filtering for primary and secondary
//

float3 SimpleMLFilter::gaussFilterCombine(int bSize, int x, int y)
{
  int w = m_allData.w;
  int h = m_allData.h;

  float4 thisPixelFeatures = tex2Df4(m_allData.normals,x,y,w,h);

  float3 secColorFiltered = gaussFilterColor(bSize, x, y, m_allData.secondary, thisPixelFeatures).pixelColor;

  float3 p1 = tex2D(m_allData.primary, x, y, w, h);
  float3 tx = tex2D(m_allData.txcolor, x, y, w, h);

  if(m_settings.filterPrimary && m_allData.primary != NULL)
    p1 = gaussFilterColor(bSize, x, y, m_allData.primary, thisPixelFeatures).pixelColor;

  return (secColorFiltered + p1)*tx;
}

float3 SimpleMLFilter::gaussFilterCombineSS(int bSize, int x, int y, int ssOffset)
{
  int w = m_allData.w;
  int h = m_allData.h;

  //float3 p1 = tex2D(m_allData.primary, x, y, w, h);

  float4* ssnd = ((float4*)&( m_subSamples.m_ssnd.data()[0]) + ssOffset*16);
  float4* sstx = ((float4*)&( m_subSamples.m_sstc.data()[0]) + ssOffset*16);

  int ssNum = m_subSamples.m_ssnd.width();
  int ssNumReal = 0;

  float3 avgColor(0,0,0);
  for(int i=0;i<ssNum;i++)
  {
    float4 sampleFeature = ssnd[i];
    float3 tx = to_float3(sstx[i]);

    auto res = gaussFilterColor(bSize, x, y, m_allData.secondary, sampleFeature);

    //if(res.matchTimes < 3)
      //continue;

    float3 p1(0,0,0);

    if(m_allData.primary != NULL)
      p1 = gaussFilterColor(bSize, x, y, m_allData.primary, sampleFeature).pixelColor; // must always filter primary to find actual surface

    avgColor += (res.pixelColor + p1)*tx;
    ssNumReal++;
  }

  if(ssNumReal > 0)
    avgColor *= 1.0f/float(ssNumReal);
  else
    avgColor = float3(1.0f, 0.0f, 0.0f);

  return avgColor;
}



void SimpleMLFilter::FilterIrradiance()
{
  if(m_allData.normals == NULL)
  {
    std::cerr << "SimpleMLFilter::FilterImage: normals image not set" << std::endl;
    return;
  }

  if(m_allData.secondary == NULL)
  {
    std::cerr << "SimpleMLFilter::FilterImage: input secondary image is NULL" << std::endl;
    return;
  }

  if(m_allData.out_res == NULL)
  {
    std::cerr << "SimpleMLFilter::FilterImage: output image is NULL" << std::endl;
    return;
  }

  int w = m_allData.w;
  int h = m_allData.h;

  calcDepthImageParams(); // calm min and max depth

  m_subSamples.LoadFromFiles("C:\\[Hydra]\\filter\\input_bin\\bad_pixels.arrayi2",
                             "C:\\[Hydra]\\filter\\input_bin\\subsamples_normdepth.imagef4",
                             "C:\\[Hydra]\\filter\\input_bin\\subsamples_texcolor.imagef4");

  //m_subSamples.TestSaveImages2(w,h);

  buildLookUpTable(m_subSamplesOffset, m_subSamples);

  ///////////////////////////////////////////////////////////////////
 
  // filter size
  //
  int bSize = m_settings.filterSize;
  int aSize = 2*bSize+1;
  
  createGaussKernelWeights(aSize, m_gaussKernel, m_settings.sigma);
 
  ////////////////////////////////////////////////////////////////////
  
  #pragma omp parallel for
  for(int y=0;y<h;y++)
  {
    for(int x=0;x<w;x++)
    {
      int ssOffset = m_subSamplesOffset[y*w+x];

      float3 cPixel; 

      if(ssOffset < 0) 
        cPixel = gaussFilterCombine(bSize,x,y);             // --> good pixel
      else
        cPixel = gaussFilterCombineSS(bSize,x,y,ssOffset);  // --> bad pixel

      m_allData.out_res[y*w+x] = to_float4(cPixel, 0.0f);
    }
  }

  //out_res[(h-78-1)*w+154] = float4(1,1,1,1);

}




void SimpleMLFilter::calcDepthImageParams()
{
  if(m_allData.normals == NULL)
  {
    std::cerr << "SimpleMLFilter::FilterImage: 'normnal&depth' image not set" << std::endl;
    return;
  }

  int w = m_allData.w;
  int h = m_allData.h;

  m_depthMin = 1e38f;
  m_depthMax = 0.0f;

  const float4* normals = m_allData.normals;

  for(int y=0;y<h;y++)
  {
    int offset = y*w;
    for(int x=0;x<w;x++)
    {
      float depth = normals[offset+x].w;

      m_depthMin = fminf(m_depthMin, depth);
      m_depthMax = fmaxf(m_depthMax, depth);
    }
  }

}


void SimpleMLFilter::SubSamplesArray::LoadFromFiles(const std::string& fname1, const std::string& fname2, const std::string& fname3)
{
  std::ifstream fPixels(fname1.c_str(), std::ios::binary);
  std::ifstream fNormals(fname2.c_str(), std::ios::binary);
  std::ifstream fColors(fname3.c_str(), std::ios::binary);

  if(!fPixels.is_open() || !fNormals.is_open() || !fColors.is_open())
  {
    std::cerr << "SubSamplesArray::LoadFromFiles: cant open files ... " << std::endl;
    if(!fPixels.is_open())
      std::cerr << "--> file " << fname1.c_str() << std::endl;
    if(!fNormals.is_open())
      std::cerr << "--> file " << fname2.c_str() << std::endl;
    if(!fColors.is_open())
      std::cerr << "--> file " << fname3.c_str() << std::endl;
    return;
  }

  int pixelsNum = 0;
  fPixels.read((char*)&pixelsNum, sizeof(int));
  pixelsCoord.resize(pixelsNum);
  fPixels.read((char*)&pixelsCoord[0], sizeof(int2)*pixelsNum);
  fPixels.close();

  fNormals.close();
  fColors.close();
  
  m_ssnd.loadFromImage4f(fname2);
  m_sstc.loadFromImage4f(fname3);
}

