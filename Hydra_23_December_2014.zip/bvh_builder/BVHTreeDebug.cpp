#include "BVHTree.h"


using MGML_MATH::MIN;
using MGML_MATH::MAX;

using namespace RAYTR;


////////////////////////////////////////////////////////////////////////////
////
void BVHTree::Draw() const
{
  glColor3f(0,1,0);
  DrawNode(GetRoot());

  glColor3f(0,0,1);
}

void BVHTree::DrawNode(const BVHNode* a_node) const
{
  if(a_node==NULL)
    return;

  AABB3f box = GetBoundingBoxData(a_node);
  
  int offset = a_node - GetRoot();

  if(offset == m_degugNodeIndex)
    glColor3f(1,0,0);
  else 
    glColor3f(0,1,0);
  DrawBox(box);

  if(!a_node->Leaf())
  {
    const BVHNode* left  = GetRoot() + a_node->GetLeftOffset();
    const BVHNode* right = GetRoot() + a_node->GetRightOffset();
    DrawNode(left);
    DrawNode(right);
  }
  else
  {
    if(offset == m_degugNodeIndex)
    {
      glColor3f(1,1,0);
      DebugLeafDrawGeometry(a_node);
      glColor3f(0,1,0);
    }
  }
}

////////////////////////////////////////////////////////////////////////////
////
float BVHTree::GetExactSahRec(int a_nodeOffset)
{
  return 0.0f;
}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::DebugCollectStatistics()
{
  if(m_debugOutBVH)
    m_outFile.open("bvh.txt");

  DebugCollectStatistics(GetRoot(), 0);

  m_stat.relativeSAH = 1000*GetExactSahRec(0)/(SurfaceArea(m_bBox)*GetTotalPrims());
  m_stat.avgPrimInLeaf /= m_stat.notEmptyLeafesNum;
  m_stat.avgDeep /= m_stat.totalNodes;

  if(m_debugOutBVH)
    m_outFile.close();
}

////////////////////////////////////////////////////////////////////////////
////
void BVHTree::DebugCollectStatistics(const BVHNode* node, int curr_deep)
{
  if(m_debugOutBVH)
    for(int i=0;i<curr_deep;i++)
      m_outFile << "--";

  m_stat.totalNodes++;
  m_stat.avgDeep += curr_deep;

  if(curr_deep > m_stat.maxDeep)
    m_stat.maxDeep = curr_deep;

  //std::cerr <<"common index: " << node - m_root <<  std::endl;
  //std::cerr <<"escape index: " << node->m_escapeIndex <<  std::endl;
  //std::cerr << std::endl;

  if(!node->Leaf())
  {
    if(m_debugOutBVH)
    {
      //
      //
    }

    //int offs = node->GetLeftOffset(); // for debug only
    const BVHNode* left  = GetRoot() + node->GetLeftOffset();
    const BVHNode* right = GetRoot() + node->GetRightOffset();

    DebugCollectStatistics(left,curr_deep+1);
    DebugCollectStatistics(right,curr_deep+1);
  }
  else
  {
    m_stat.leafes++;

    int offs = 	node->GetObjectListOffset()*sizeof(float4);
    if(offs >= 0)
    {/*
      ObjectList* pList = (ObjectList*)(&m_objListData[0] + offs);

      int N_tri = GetNumTriangles(*pList);
      int N_sph = GetNumSpheres(*pList);

      m_stat.avgPrimInLeaf += N_tri + N_sph;
      m_stat.notEmptyLeafesNum++;
      if(m_stat.maxPrimsInLeaf < N_tri + N_sph)
        m_stat.maxPrimsInLeaf = N_tri + N_sph;

      if(N_tri + N_sph == 0)
        m_stat.emptyNodes++;

      if(m_debugOutBVH)
        m_outFile << "leaf: " <<  N_tri + N_sph << ", deep = " << curr_deep << std::endl; 
        */
    }
    else
    {
      m_stat.emptyNodes++;
      if(m_debugOutBVH)
        m_outFile << "leaf: empty" << std::endl; 
    }
  }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
////
void BVHTree::DebugLeafDrawGeometry(const BVHNode* node) const
{
  if(!node->Leaf())
    return;

  int offs = 	node->GetObjectListOffset()*sizeof(float4);
  if(offs >= 0)
  {
    /*
    ObjectList* pList = (ObjectList*)(&m_objListData[0] + offs);
    
    int N_tri = GetNumTriangles(*pList);
    int N_sph = GetNumSpheres(*pList);

    const ObjectListTriangle* pTriangles = pList->GetTriangles();
   

    const ObjectListSphere* pSpheres = pList->GetSpheres();
    for(int i=0;i<N_sph;i++)
    {
      glPushMatrix();
      float3 pos = pSpheres[i].pos;
      glTranslatef(pos.x, pos.y, pos.z);
      glutSolidSphere(pSpheres[i].r, 20, 20);
      glPopMatrix();
    }
    */
  }
  else
    RUN_TIME_ERROR("BVH leafs must always have correct offset to object list");

  /*
  if(node->pPrimitiveList==NULL)
  return;

  PrimitiveList& plist = *(node->pPrimitiveList);

  glColor3f(1,1,0);

  for(int i=0;i<plist.size();i++)
  {
  if(plist[i].GetPrimType() == ObjectList::TRIANGLE)
  {
  typedef MGML_MATH::TRIANGLE<3,float> MyTriangle;

  MyTriangle t;
  GetTriangleVertices(plist[i].GetPrimIndex(), &t.A, &t.B, &t.C);

  glBegin(GL_TRIANGLES);
  glVertex3fv(t.A.M);
  glVertex3fv(t.B.M);
  glVertex3fv(t.C.M);
  glEnd();
  }
  else if(plist[i].GetPrimType() == ObjectList::SPHERE)
  {
  Sphere sph;
  m_pInputData->GetSphere(plist[i].GetPrimIndex(), sph.pos.M, &sph.r);

  glPushMatrix();
  vec4f pos = sph.pos;
  glTranslatef(sph.pos.x, sph.pos.y, sph.pos.z);
  gluSphere(QuadrObj, sph.r, 20, 20);
  glPopMatrix();
  }
  else
  throw Error("DebugLeafDrawGeometry, undefined type");
  }
  */

}


