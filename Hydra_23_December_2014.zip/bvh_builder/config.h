#pragma once
#define CONFIG_GUARDIAN

#define INDEX_TRIANGLE_LAYOUT  1
#define VERTEX_TRIANGLE_LAYOUT 2
#define MATRIX_TRIANGLE_LAYOUT 3

#define TRIANGLE_LAYOUT VERTEX_TRIANGLE_LAYOUT
#define BLOCK_SIZE      256

#define SUPPORT_SPHERES 1
#define SUPPORT_ALPHA_TEST 1



namespace RAYTR
{


enum RENDER_LAYER {LAYER_COLOR                     = 0, 
                   LAYER_POSITIONS                 = 1, 
                   LAYER_NORMALS                   = 2,
                   LAYER_TEXCOORD                  = 3,
                   LAYER_TEXCOLOR_AND_MATERIAL     = 4,   // material mask
                   LAYER_INCOMING_PRIMARY          = 5,   // incoming primary
                   LAYER_INCOMING_RADIANCE         = 6,   // incoming secondary
                   LAYER_COLOR_PRIMARY_AND_REST    = 7,   // primary + refractions and other bounces
                   LAYER_COLOR_THE_REST            = 8 }; // refractions, and other bounces






}

typedef void (*RTE_PROGRESSBAR_CALLBACK)(const char* message, float a_progress);

