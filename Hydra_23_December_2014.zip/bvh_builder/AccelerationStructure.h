// � Copyright 2008 Vladimir Frolov, Moscow State University Graphics & Media Lab
#pragma once
#define ACCEL_STRUCT_GUARDIAN

#pragma warning(disable:4800) // cobversion int to bool, performance warning
#pragma warning(disable:4018) //  warning C4018: <: �������������� ����� �� ������ � ��� �����

#ifndef __CUDACC__
  #ifndef MGML_GUARDIAN
    #include "../CSL/MGML.h"
  #endif
#endif

#ifndef RTGLOBALS
  #include "../gpu_rt/globals.h"
#endif

#ifndef RTCTRACE
  #include "../gpu_rt/ctrace.h"
#endif

#ifndef __CUDACC__

  #ifndef TIMER_GUARDIAN
    #include "../CSL/Timer.h"
  #endif

  using MGML::vec3f;
  using MGML::vec4f;
  using MGML::vec2i;
  using MGML::AABB3f;
  using MGML::AABB4f;
  using MGML::PackedSphere3f;
  using MGML::to_vec3f;

  using MGML_MATH::SurfaceArea;
  using MGML_MATH::Volume;

  #include <memory>
  #include <list>
  #include <vector>
  #include <map>
  #include <algorithm>

  using std::vector;
  using std::map;
  using namespace MGML_ERROR;

#endif


#ifndef CONFIG_GUARDIAN
  #include "config.h"
#endif

#ifndef MGML_GPU_GUARDIAN
  #include "../CSL/MGML_GPU.h"
#endif


namespace RAYTR
{

  struct AccelStructSettings
  {
    enum POSSIBLE_FLAGS {
      INPUT_TRIANGLES        = 1,
      INPUT_SPHERES          = 2,
      INPUT_POINTS           = 4,
      INPUT_BOXES            = 8,
      INPUT_CUSTOM_PRIMITIVE = 16,
      CONSTRUCT_QUALITY      = 32,
      CONSTRUCT_FAST         = 64,
      CONSTRUCT_VERY_FAST    = 128,
      BOUNDARY_PRIMS_BOTH_LEFT_AND_RIGHT = 256, // ���� ���� ����������, �� ������� �������� ��������� ��������� � ��� ��������� (kd-tree)
      DISABLE_EARLY_SPLIT_CLIPPING = 512
    };

    int maxDeep;
    int maxPrimInLeaf;
    int recomendedPrimInLeaf;
    int flags;
  };

  struct AccelStructStatistics
  {
    int emptyNodes;
    int totalNodes;
    int leafes;
    float avgPrimInLeaf;
    float avgDeep;
    float relativeSAH; //  = (1000*exactSAH_Value) / (SurfaceArea(root)*totalPrims)

    int notEmptyLeafesNum;
    int maxDeep;
    int maxPrimsInLeaf;
    int primitiveListMemorySize;
    int dublicates;
    int totalPrims;
  };

  struct InputData
  {
    InputData() : progressBar(NULL) {}

    virtual int  GetNumTriangles() const { return 0; }
    virtual void GetTriangle(int index, float A[3], float B[3], float C[3]) const {}

    virtual int  GetNumBoxes() const { return 0; }
    virtual void GetBox(int index, float vmin[3], float vmax[3]) const {}

    virtual int  GetNumPoints() const { return 0; }
    virtual void GetPoint(int index, float verts[3]) const { }

    virtual int  GetNumSpheres() const { return 0; }
    virtual void GetSphere(int index, float sph_pos[3], float* sph_r) const { }

    RTE_PROGRESSBAR_CALLBACK progressBar;
  };


#ifndef __CUDACC__

  struct BvhLeafInfo
  {
    BvhLeafInfo() : begin(0), end(0), leafOffset(0) {}
    BvhLeafInfo(int a_beg, int a_end, int a_offs) : begin(a_beg), end(a_end), leafOffset(a_offs) {}

    inline int size() { return (end - begin); }

    int begin;
    int end;
    int leafOffset;
  };

  struct BvhOutData
  {

    BvhOutData(){}

    void freeMem()
    {
      nodes      = std::vector<BVHNode>();
      leafesInfo = std::vector<BvhLeafInfo>();
      indices    = std::vector<int>();
    }

    std::vector<BVHNode>     nodes;
    std::vector<BvhLeafInfo> leafesInfo;
    std::vector<int>         indices;

    float3 boxMin;
    float3 boxMax;
  };

#endif

  inline universal_call int GetOctIndex(float3 pos)
  {
    int x1 = (int)(pos.x < 0);
    int y1 = (int)(pos.y < 0);
    int z1 = (int)(pos.z < 0);

    return x1 + (y1 << 1) + (z1 << 2);
  }

  inline universal_call int GetOctIndex(int3 pos)
  {
    int x1 = (int)(pos.x < 0);
    int y1 = (int)(pos.y < 0);
    int z1 = (int)(pos.z < 0);

    return x1 + (y1 << 1) + (z1 << 2);
  }


enum {KD_TREE_CONSTRUCT_QUALITY, KD_TREE_CONSTRUCT_FAST, KD_TREE_CONSTRUCT_VERY_FAST,
      BVH_CONSTRUCT_QUALITY, BVH_CONSTRUCT_FAST, BVH_CONSTRUCT_VERY_FAST};


#ifndef __CUDACC__

static int CalcKdTreeMemoryExpansionFactor(AccelStructSettings settings)
{
  return 15;
}

static float CalcBVHMemoryExpansionFactor(AccelStructSettings settings, size_t a_primListSize)
{
  if(a_primListSize      <= 1000000)
    return 4.0f;
  else if(a_primListSize <= 2000000)
    return 2.0f;
  else if(a_primListSize <= 4000000)
    return 1.75f;
  else if(a_primListSize <= 6000000)
    return 1.5f;
  else if(a_primListSize <= 10000000)
    return 1.25f;
  else
    return 1.15f;
}

#endif




///////////////////////////////////////////////////////////////////////////////////////////
struct IrradianceCachePoint_Part1
{
  float3 pos;
  int materialId;
};

struct IrradianceCachePoint_Part2
{
  float3 norm;
  int    active; // add point in irradiance cache if it's active

#ifndef __CUDACC__
  __host__ float GetInterpolationError () const { return *( (float*)(&active));}
  __host__ void  SetInterpolationError (float a_val) {  *( (float*)(&active)) = a_val;  }
#else
  __device__ float GetInterpolationError () const { return __int_as_float(active); }
  __device__ void  SetInterpolationError (float a_val) {  active = __float_as_int(a_val);  }
#endif
};

struct IrradianceCachePoint_Part3
{
  float3 color;
  float  validityRadius;
};


struct IrradianceCacheCompressed
{
  ushort3 norm;
  ushort3 color;
  float   validityRadius;
};




#ifndef __CUDACC__

#include "../csl/MGML_MEMORY.h"

////////////////////////////////////////////////////////////////////////////
////
static void DrawBox(const AABB4f& a_box)
{
  vec4f cent  = a_box.center();
  vec4f scale = a_box.vmax - a_box.vmin;

  glPushMatrix();
  glTranslatef(cent.x,cent.y,cent.z);
  glScalef(scale.x,scale.y,scale.z);
  glutWireCube(1);
  glPopMatrix();
}

////////////////////////////////////////////////////////////////////////////
////
static void DrawBox(const AABB3f& a_box)
{
  vec3f cent  = a_box.center();
  vec3f scale = a_box.vmax - a_box.vmin;

  glPushMatrix();
  glTranslatef(cent.x,cent.y,cent.z);
  glScalef(scale.x,scale.y,scale.z);
  glutWireCube(1);
  glPopMatrix();
}

static inline bool SplitCloseToBoxBoundary(float split, int axis, const AABB3f& a_box)
{
  float3 boxSize = a_box.vmax - a_box.vmin;
  float maxBoxSize = MGML_MATH::MAX(boxSize.x, boxSize.y, boxSize.z);
  float epsilon = boxSize[axis]==0 ? 1e-3f*maxBoxSize : 1e-2f*boxSize[axis];

  if(split < a_box.vmin[axis] || split > a_box.vmax[axis])
    return true;

  ASSERT(split >= a_box.vmin[axis] && split <= a_box.vmax[axis]);

  return ( (split-a_box.vmin[axis]) < epsilon || (a_box.vmax[axis]-split) < epsilon );
}

static inline bool SplitCloseToBoxBoundary(float split, int axis, const AABB4f& a_box)
{
  AABB3f box(to_float3(a_box.vmin), to_float3(a_box.vmax));
  return SplitCloseToBoxBoundary(split, axis, box);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


class AccelerationStructure
{

protected:

  typedef MGML_MATH::SPHERE<4,float>    Sphere;
  typedef MGML_MATH::TRIANGLE<3,float>  Triangle;
	typedef MGML_MATH::AABB<4,float>		  AABB;

  enum {MAX_DEPTH = 64,
		    MAX_NUM_NODES = 10000000,
		    MAX_PRIMS_IN_LEAF = 1024};

public:

  AccelerationStructure();
  virtual ~AccelerationStructure();

  virtual const AABB4f GetBoundingBox() const;
  virtual void SetBoundingBox(const AABB4f& a_box) { m_bBox = AABB3f(to_float3(a_box.vmin), to_float3(a_box.vmax)); }

  virtual void Build(RAYTR::BvhOutData* pOutData) = 0;
  virtual void Draw() const = 0;

  int GetTotalPrims() const {return m_pInputData->GetNumTriangles() + m_pInputData->GetNumSpheres();}

  void SetInputData(const InputData* a_pInputData) {m_pInputData = a_pInputData;}
  void SetSettings(AccelStructSettings settings) {m_settings = settings;}

  AccelStructStatistics GetStatistics() const { return *(&m_stat); }


 
protected:

  AccelerationStructure(const AccelerationStructure& rhs) {}
  AccelerationStructure& operator=(const AccelerationStructure& rhs) { return *this; }

  struct SplitData
	{
    SplitData()
    {
      pos = 1e38f;
      sah = 1e38f;
      axis = -1;
      subdivideNext = false;
      primsOnLeftSide = primsOnRightSide = 0;
    }

		float	pos;
		int		axis;
    float sah;
		bool	subdivideNext;
    int   primsOnLeftSide;
    int   primsOnRightSide;

    // for BVH only
    //
    AABB3f leftBounds;
    AABB3f rightBounds;
	};

  struct PrimitiveRef;
  template<int axis>
  struct MyBoxLessMax
  {
    inline bool operator()(const PrimitiveRef& p1, const PrimitiveRef& p2) const { return (p1.Box().vmax[axis] < p2.Box().vmax[axis]); }
  };

  struct VPrimitive;

  struct PrimitiveRef
  {
    PrimitiveRef() {m_prim=NULL; }
    PrimitiveRef(VPrimitive* pPrim)
    {
      m_prim = pPrim;
      m_box.vmin = pPrim->m_box.vmin;
      m_box.vmax = pPrim->m_box.vmax;
    }

    inline AABB3f& Box() {return m_box;}
    inline const AABB3f& Box() const {return m_box;}

    inline bool AxisAligned(int axis, float split) const           { return (Box().vmin[axis] == Box().vmax[axis]) && (Box().vmin[axis]==split); }
    inline bool ExistSplitOnThatPlane(int axis, float split) const { return (m_flags & HAS_SPLIT) && AxisAligned(axis, split);}
    inline void MemorizeExistSplit(int axis, float split)          { if(AxisAligned(axis, split)) m_flags = m_flags | HAS_SPLIT; }

    VPrimitive* operator->() {return m_prim;}
    const VPrimitive* operator->() const {return m_prim;}

    inline int GetPrimIndex() const {return m_prim->GetPrimIndex();}
    inline int GetPrimType() const {return m_prim->GetPrimType();}
    inline int SizeInBytes() const {return m_prim->SizeInBytes();}
    inline bool IntersectWithAABB(const AABB3f& b) const {return m_prim->IntersectWithAABB(b);}
    
    inline bool Valid() const {return m_prim->IntersectWithAABB(Box());}

    enum {HAS_SPLIT=1, IN_LEFT_BOX=2, IN_RIGHT_BOX=4};

    inline void MemorizeInLeftBox() {m_flags = m_flags | IN_LEFT_BOX;}
    inline void MemorizeInRightBox() {m_flags = m_flags | IN_RIGHT_BOX;}

    inline bool InLeftBox() const { return (bool)(m_flags & IN_LEFT_BOX);}
    inline bool InRightBox() const { return (bool)(m_flags & IN_RIGHT_BOX);}

    inline VPrimitive* GetRealPrimitivePointer() {return m_prim;}
    inline const VPrimitive* GetRealPrimitivePointer() const {return m_prim;}

  protected:

    AABB3f m_box;
    VPrimitive* m_prim;
    int m_flags;
  };

  friend struct PrimitiveRef;

  struct VPrimitive
  {
    VPrimitive(){m_inLeftBox = false; thisAccelStruct = NULL; m_primitiveIndex = (uint)-1;}

    virtual int GetPrimType() const = 0;
		virtual int SizeInBytes() const = 0;
    virtual bool IntersectWithAABB(const AABB3f& b) const = 0;
    virtual vec2i IntersectAxisAlignedPlane(float coord, int axis) const = 0;
    virtual bool Valid() const {return true;}

    inline int GetPrimIndex() const {return m_primitiveIndex;}

    inline void MemorizeInLeftBox() {m_inLeftBox = true;}
    inline void MemorizeInRightBox() {m_inLeftBox = false;}

    inline bool InLeftBox() const { return m_inLeftBox; }
    inline bool InRightBox() const {return !m_inLeftBox; }

    AABB3f m_box;
    uint m_primitiveIndex;
    AccelerationStructure* thisAccelStruct;
    bool m_inLeftBox;
    float m_aux;
  };

  struct VTriangle : public VPrimitive
  {
    VTriangle(){}
    VTriangle(int a_id, AccelerationStructure* t);
    void ConstructTriangle(int a_id, AccelerationStructure* t);

    int GetPrimType() const;
    int SizeInBytes() const;
    bool  IntersectWithAABB(const AABB3f& b) const;
    vec2i IntersectAxisAlignedPlane(float coord, int axis) const;
    bool Valid() const;

    void GetVertexPositions(Triangle* t) const;
  };

  struct VSphere : public VPrimitive
  {
    VSphere(){}
    VSphere(int a_id, AccelerationStructure* t);
    void ConstructSphere(int a_id, AccelerationStructure* t);

    int GetPrimType() const;
    int SizeInBytes() const;
    bool IntersectWithAABB(const AABB3f& b) const;
    vec2i IntersectAxisAlignedPlane(float coord, int axis) const;
    bool Valid() const;
  };

  VTriangle* m_vtrianglesMemory;
  VSphere* m_vspheresMemory;


  // new simplified BVH bilder
  //

  std::vector<BvhLeafInfo>* m_pBeginEndArray;
  std::vector<int>*         m_pIndexArray;

public:

  typedef std::vector<PrimitiveRef> PrimitiveList;
  typedef MGML_MEMORY::ArraySlice<PrimitiveList> PrimitiveListSlice;


  float EstimateCost(const AABB& box, float split_pos, int split_axis, size_t lsumm, size_t rsumm) const;
  float EMPTY_NODE_COST_TRAVERSE;


protected:

  virtual uint GetContructionMode();
  virtual int PushListInIndexListBuffer(const PrimitiveList& plist, int leafOffs);

  //virtual int PushListInObjectListBuffer(PrimitiveListSlice& plist);
  virtual AABB3f CalcBindingBox(const PrimitiveList& plist);
  void FreeList(PrimitiveList& pList);

  bool FoundAlreadySplitedAAReferences(const AABB3f& a_box, PrimitiveList& plist, float min_split, int min_axis);
  void SplitReference(const PrimitiveRef& ref, PrimitiveRef* left, PrimitiveRef* right, float splitPos, int splitAxis);

  void EarlySplitClipping(PrimitiveList& plist, const AABB3f& boundingBoxOfScene, float avgPrimSurfaceArea);
  PrimitiveList SubdividePrimitive(PrimitiveRef triRef, double memExpansion);
  inline bool HaveToBeToSplited(const PrimitiveRef& prim) const { return SurfaceArea(prim.Box()) > m_minPrimSA_OK;}
  float SurfaceAreaOfTriangle(const PrimitiveRef& prim);
  float SubdivMetric(PrimitiveRef triRef);

  virtual float MemoryExpansionFactor(AccelStructSettings settings, size_t a_primListSize) const = 0;

  const InputData* m_pInputData;
  AccelStructSettings m_settings;

  AABB3f m_bBox;

  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  static const int BVHMAXTHREADS = 16;

 
  struct ThreadMemData
  {
    void FreeData();

    PrimitiveList       auxThreadPrimList;
    std::vector<AABB3f> rightBounds_FindObjectSplit;
    std::vector<float>  keys;

    std::vector<int>    tempIntArray;

  };

  ThreadMemData m_memData[BVHMAXTHREADS];
  float m_threadProgress[BVHMAXTHREADS];


  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


  Timer m_buildTimer;

  //std::vector<AABB3f> m_debugBoxes;
  std::ofstream m_outFile;

  struct StatInfo : public AccelStructStatistics
	{
		StatInfo();

    virtual void Clear();
    virtual void Print(std::ostream& out, int totalPrimsNum);

    AccelerationStructure* m_pAccelStruct;
	} m_stat;

  friend struct StatInfo;

  float m_progressBar;
  float SAH_OVERSPLIT_TRESHOLD;
  float m_minPrimSA_OK;
  float m_sceneBBoxSA;

  int m_primsCountBeforeEarlySplitClipping;
};





#endif


};

