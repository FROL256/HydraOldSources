// � Copyright 2008 �������� ������
#define MGML_GLOBALS

#ifndef INFINITY
#define INFINITY		1e38f
#endif

#define EPSILON			1e-12f
#define DELTA			  1e-5f

#define EPSILON_E5M		1e-5f
#define EPSILON_E6M		1e-6f
#define EPSILON_E7M		1e-7f
#define EPSILON_E8M		1e-8f
#define EPSILON_E9M		1e-9f
#define EPSILON_E10M	1e-10f
#define EPSILON_E32M	1e-32f

#ifndef __CUDACC__

#ifdef __GNUC__
  #define __align__(N) __attribute__((aligned(N))) 
#else
  #define __align__(N) __declspec(align(N))
#endif

#endif

#define SSE_ALIGNED __align__(16)

#include <stdexcept>


enum {HAL_NONE=0,
	  HAL_CUDA=1,
	  HAL_STREAM=2,
	  HAL_LARABEE=3};

#ifndef __CUDACC__
	#ifndef __device__
		#define __device__
	#endif

	#ifndef __host__
		#define __host__
	#endif

	#ifndef __constant__
		#define __constant__
	#endif

	const int HAL = HAL_NONE;
#else

	#ifndef ASSERT
		#define ASSERT(_expression) ((void)0)
	#endif

	typedef float4 __m128;

	const int HAL = HAL_CUDA;

#endif

#ifndef universal_call
  #define universal_call __device__ __host__
#endif

#ifndef __CUDACC__
	#include <new>
#endif


