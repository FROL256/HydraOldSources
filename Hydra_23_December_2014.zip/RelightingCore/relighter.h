#pragma once

#include <culapack.h>
#include "cublas.h"

class Relighter
{
public:

	Relighter(int in_iWidth, int in_iHeight, int imageCount);

	~Relighter();

	bool Relight(float * in_fpInputImages, float * in_fpLights,int in_iImageCount, 
		int in_iWidth, int in_iHeight);

	bool ResetAll(int in_iWidth, int in_iHeight, int imageCount);

	//not used
	//bool AddImageForRelight(float * in_fpInputImage, float * in_fpLight);

	//also we can set current image too
	bool GetResultingImage(float ** in_fpOutputImage);
	   
private:

	bool static initCuda();
	void static shutdownCuda();
	bool static checkStatus(culaStatus status);

private:

	int m_width, m_height;
	float * m_currentImage;
	float * m_gpuImage;
	float * m_gpuLights;
	float * m_gpuRes;
	bool imageAdded;
};