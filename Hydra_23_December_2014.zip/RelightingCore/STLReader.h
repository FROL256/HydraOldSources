#pragma once

#include "ISerializer.h"
#include <fstream>
#include <string>

class STLReader: public ISerializer
{
public:
	virtual bool Init(std::string& filename);
	virtual bool SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight);
	virtual bool Close();
private:
	std::ifstream fin;
};