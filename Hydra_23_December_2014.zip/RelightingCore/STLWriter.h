#pragma once

#include "ISerializer.h"
#include <fstream>

class STLWriter: public ISerializer
{
public:
	virtual bool Init(std::string& filename);
	virtual bool SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight);
	virtual bool Close();
private:
	std::ofstream fout;
};