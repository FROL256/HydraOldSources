#pragma once

#include "ISerializer.h"

class JPEGWriter: public ISerializer
{
public:
	virtual bool Init(std::string& filename);
	virtual bool SerializeFloatImage(float * in_fpImage, int in_iWidth, int in_iHeight);
	virtual bool Close();
private:
	std::string m_fileName;
};